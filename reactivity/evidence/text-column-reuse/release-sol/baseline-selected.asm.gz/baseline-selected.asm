
text_column_public_control::ack::<text_column_public_control::Input> code=273 fixed_stack=136

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006b5c90 <text_column_public_control::ack::<text_column_public_control::Input>>:
  6b5c90:	push   %r14
  6b5c92:	push   %rbx
  6b5c93:	sub    $0x78,%rsp
  6b5c97:	test   %rsi,%rsi
  6b5c9a:	je     6b5cef <text_column_public_control::ack::<text_column_public_control::Input>+0x5f>
  6b5c9c:	cmpb   $0x0,0x74e(%rsi)
  6b5ca3:	jne    6b5cf6 <text_column_public_control::ack::<text_column_public_control::Input>+0x66>
  6b5ca5:	mov    0x6b0(%rsi),%rdx
  6b5cac:	test   %rdx,%rdx
  6b5caf:	je     6b5cfd <text_column_public_control::ack::<text_column_public_control::Input>+0x6d>
  6b5cb1:	mov    %rdi,%rbx
  6b5cb4:	mov    0x6b8(%rsi),%rcx
  6b5cbb:	lea    0x8(%rsp),%rdi
  6b5cc0:	call   6fdef0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge>
  6b5cc5:	cmpq   $0xfffffffffffffffe,0x8(%rsp)
  6b5ccb:	jne    6b5d3a <text_column_public_control::ack::<text_column_public_control::Input>+0xaa>
  6b5ccd:	movups 0x10(%rsp),%xmm0
  6b5cd2:	movups 0x20(%rsp),%xmm1
  6b5cd7:	movups 0x30(%rsp),%xmm2
  6b5cdc:	movups %xmm2,0x20(%rbx)
  6b5ce0:	movups %xmm1,0x10(%rbx)
  6b5ce4:	movups %xmm0,(%rbx)
  6b5ce7:	add    $0x78,%rsp
  6b5ceb:	pop    %rbx
  6b5cec:	pop    %r14
  6b5cee:	ret
  6b5cef:	mov    $0xd,%eax
  6b5cf4:	jmp    6b5d02 <text_column_public_control::ack::<text_column_public_control::Input>+0x72>
  6b5cf6:	mov    $0xe,%eax
  6b5cfb:	jmp    6b5d02 <text_column_public_control::ack::<text_column_public_control::Input>+0x72>
  6b5cfd:	mov    $0x14,%eax
  6b5d02:	mov    %rax,0x40(%rsp)
  6b5d07:	movq   $0x0,0x48(%rsp)
  6b5d10:	lea    -0x668638(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6b5d17:	lea    0x36d00a(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6b5d1e:	lea    0x36bdd3(%rip),%r8        # a21af8 <__frame_dummy_init_array_entry+0x8>
  6b5d25:	lea    0x40(%rsp),%rbx
  6b5d2a:	mov    $0x2b,%esi
  6b5d2f:	mov    %rbx,%rdx
  6b5d32:	call   *0x38c4f8(%rip)        # a42230 <_DYNAMIC+0x240>
  6b5d38:	jmp    6b5d8a <text_column_public_control::ack::<text_column_public_control::Input>+0xfa>
  6b5d3a:	mov    0x38(%rsp),%rax
  6b5d3f:	mov    %rax,0x70(%rsp)
  6b5d44:	movups 0x8(%rsp),%xmm0
  6b5d49:	movups 0x18(%rsp),%xmm1
  6b5d4e:	movups 0x28(%rsp),%xmm2
  6b5d53:	movaps %xmm2,0x60(%rsp)
  6b5d58:	movaps %xmm1,0x50(%rsp)
  6b5d5d:	movaps %xmm0,0x40(%rsp)
  6b5d62:	lea    -0x66868a(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6b5d69:	lea    0x36cfb8(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6b5d70:	lea    0x36bd99(%rip),%r8        # a21b10 <__frame_dummy_init_array_entry+0x20>
  6b5d77:	lea    0x40(%rsp),%rbx
  6b5d7c:	mov    $0x2b,%esi
  6b5d81:	mov    %rbx,%rdx
  6b5d84:	call   *0x38c4a6(%rip)        # a42230 <_DYNAMIC+0x240>
  6b5d8a:	ud2
  6b5d8c:	jmp    6b5d8e <text_column_public_control::ack::<text_column_public_control::Input>+0xfe>
  6b5d8e:	mov    %rax,%r14
  6b5d91:	mov    %rbx,%rdi
  6b5d94:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6b5d99:	mov    %r14,%rdi
  6b5d9c:	call   a20740 <_Unwind_Resume@plt>

text_column_public_control::ack::<text_column_public_control::Model> code=273 fixed_stack=136

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006b5db0 <text_column_public_control::ack::<text_column_public_control::Model>>:
  6b5db0:	push   %r14
  6b5db2:	push   %rbx
  6b5db3:	sub    $0x78,%rsp
  6b5db7:	test   %rsi,%rsi
  6b5dba:	je     6b5e0f <text_column_public_control::ack::<text_column_public_control::Model>+0x5f>
  6b5dbc:	cmpb   $0x0,0x78e(%rsi)
  6b5dc3:	jne    6b5e16 <text_column_public_control::ack::<text_column_public_control::Model>+0x66>
  6b5dc5:	mov    0x6f0(%rsi),%rdx
  6b5dcc:	test   %rdx,%rdx
  6b5dcf:	je     6b5e1d <text_column_public_control::ack::<text_column_public_control::Model>+0x6d>
  6b5dd1:	mov    %rdi,%rbx
  6b5dd4:	mov    0x6f8(%rsi),%rcx
  6b5ddb:	lea    0x8(%rsp),%rdi
  6b5de0:	call   70d5d0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge>
  6b5de5:	cmpq   $0xfffffffffffffffe,0x8(%rsp)
  6b5deb:	jne    6b5e5a <text_column_public_control::ack::<text_column_public_control::Model>+0xaa>
  6b5ded:	movups 0x10(%rsp),%xmm0
  6b5df2:	movups 0x20(%rsp),%xmm1
  6b5df7:	movups 0x30(%rsp),%xmm2
  6b5dfc:	movups %xmm2,0x20(%rbx)
  6b5e00:	movups %xmm1,0x10(%rbx)
  6b5e04:	movups %xmm0,(%rbx)
  6b5e07:	add    $0x78,%rsp
  6b5e0b:	pop    %rbx
  6b5e0c:	pop    %r14
  6b5e0e:	ret
  6b5e0f:	mov    $0xd,%eax
  6b5e14:	jmp    6b5e22 <text_column_public_control::ack::<text_column_public_control::Model>+0x72>
  6b5e16:	mov    $0xe,%eax
  6b5e1b:	jmp    6b5e22 <text_column_public_control::ack::<text_column_public_control::Model>+0x72>
  6b5e1d:	mov    $0x14,%eax
  6b5e22:	mov    %rax,0x40(%rsp)
  6b5e27:	movq   $0x0,0x48(%rsp)
  6b5e30:	lea    -0x668758(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6b5e37:	lea    0x36ceea(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6b5e3e:	lea    0x36bcb3(%rip),%r8        # a21af8 <__frame_dummy_init_array_entry+0x8>
  6b5e45:	lea    0x40(%rsp),%rbx
  6b5e4a:	mov    $0x2b,%esi
  6b5e4f:	mov    %rbx,%rdx
  6b5e52:	call   *0x38c3d8(%rip)        # a42230 <_DYNAMIC+0x240>
  6b5e58:	jmp    6b5eaa <text_column_public_control::ack::<text_column_public_control::Model>+0xfa>
  6b5e5a:	mov    0x38(%rsp),%rax
  6b5e5f:	mov    %rax,0x70(%rsp)
  6b5e64:	movups 0x8(%rsp),%xmm0
  6b5e69:	movups 0x18(%rsp),%xmm1
  6b5e6e:	movups 0x28(%rsp),%xmm2
  6b5e73:	movaps %xmm2,0x60(%rsp)
  6b5e78:	movaps %xmm1,0x50(%rsp)
  6b5e7d:	movaps %xmm0,0x40(%rsp)
  6b5e82:	lea    -0x6687aa(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6b5e89:	lea    0x36ce98(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6b5e90:	lea    0x36bc79(%rip),%r8        # a21b10 <__frame_dummy_init_array_entry+0x20>
  6b5e97:	lea    0x40(%rsp),%rbx
  6b5e9c:	mov    $0x2b,%esi
  6b5ea1:	mov    %rbx,%rdx
  6b5ea4:	call   *0x38c386(%rip)        # a42230 <_DYNAMIC+0x240>
  6b5eaa:	ud2
  6b5eac:	jmp    6b5eae <text_column_public_control::ack::<text_column_public_control::Model>+0xfe>
  6b5eae:	mov    %rax,%r14
  6b5eb1:	mov    %rbx,%rdi
  6b5eb4:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6b5eb9:	mov    %r14,%rdi
  6b5ebc:	call   a20740 <_Unwind_Resume@plt>

text_column_public_control::observe::<text_column_public_control::Model> code=1653 fixed_stack=376

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006b5ed0 <text_column_public_control::observe::<text_column_public_control::Model>>:
  6b5ed0:	push   %rbp
  6b5ed1:	push   %r15
  6b5ed3:	push   %r14
  6b5ed5:	push   %r13
  6b5ed7:	push   %r12
  6b5ed9:	push   %rbx
  6b5eda:	sub    $0x148,%rsp
  6b5ee1:	test   %rsi,%rsi
  6b5ee4:	je     6b64dc <text_column_public_control::observe::<text_column_public_control::Model>+0x60c>
  6b5eea:	mov    %rsi,%rbx
  6b5eed:	cmpb   $0x0,0x78e(%rsi)
  6b5ef4:	jne    6b64e3 <text_column_public_control::observe::<text_column_public_control::Model>+0x613>
  6b5efa:	cmpb   $0x1,0x78c(%rbx)
  6b5f01:	jne    6b64ea <text_column_public_control::observe::<text_column_public_control::Model>+0x61a>
  6b5f07:	mov    0x708(%rbx),%rdx
  6b5f0e:	mov    0x6e0(%rbx),%r12
  6b5f15:	mov    0x5e8(%rbx),%rbp
  6b5f1c:	mov    0x5f0(%rbx),%rax
  6b5f23:	mov    %rax,0x8(%rsp)
  6b5f28:	movups 0x658(%rbx),%xmm1
  6b5f2f:	mov    0x680(%rbx),%r13
  6b5f36:	test   %r13,%r13
  6b5f39:	mov    %rdi,0x80(%rsp)
  6b5f41:	je     6b5f83 <text_column_public_control::observe::<text_column_public_control::Model>+0xb3>
  6b5f43:	mov    0xe0(%r13),%rax
  6b5f4a:	test   %rax,%rax
  6b5f4d:	je     6b5f9f <text_column_public_control::observe::<text_column_public_control::Model>+0xcf>
  6b5f4f:	mov    0x38(%rax),%ecx
  6b5f52:	mov    %ecx,0x20(%rsp)
  6b5f56:	movups 0x28(%rax),%xmm0
  6b5f5a:	movaps %xmm0,0x10(%rsp)
  6b5f5f:	movzbl 0x3c(%rax),%r15d
  6b5f64:	movzbl 0x3f(%rax),%ecx
  6b5f68:	mov    %cl,0x62(%rsp)
  6b5f6c:	movzwl 0x3d(%rax),%eax
  6b5f70:	mov    %ax,0x60(%rsp)
  6b5f75:	mov    0x100(%r13),%rsi
  6b5f7c:	test   %rsi,%rsi
  6b5f7f:	jne    6b5fae <text_column_public_control::observe::<text_column_public_control::Model>+0xde>
  6b5f81:	jmp    6b5f86 <text_column_public_control::observe::<text_column_public_control::Model>+0xb6>
  6b5f83:	mov    $0x2,%r15b
  6b5f86:	movq   $0x4,0x100(%rsp)
  6b5f92:	xorps  %xmm0,%xmm0
  6b5f95:	movups %xmm0,0x108(%rsp)
  6b5f9d:	jmp    6b5fcc <text_column_public_control::observe::<text_column_public_control::Model>+0xfc>
  6b5f9f:	mov    $0x2,%r15b
  6b5fa2:	mov    0x100(%r13),%rsi
  6b5fa9:	test   %rsi,%rsi
  6b5fac:	je     6b5f86 <text_column_public_control::observe::<text_column_public_control::Model>+0xb6>
  6b5fae:	lea    0x100(%rsp),%rdi
  6b5fb6:	mov    %rdx,%r14
  6b5fb9:	movaps %xmm1,0x50(%rsp)
  6b5fbe:	call   *0x38c274(%rip)        # a42238 <_DYNAMIC+0x248>
  6b5fc4:	movaps 0x50(%rsp),%xmm1
  6b5fc9:	mov    %r14,%rdx
  6b5fcc:	movabs $0xcbf29ce484222325,%r14
  6b5fd6:	add    $0x620,%rbx
  6b5fdd:	mov    %rbx,0xe0(%rsp)
  6b5fe5:	mov    %rdx,0xb0(%rsp)
  6b5fed:	mov    %r12,0xb8(%rsp)
  6b5ff5:	mov    %rbp,0xa0(%rsp)
  6b5ffd:	mov    0x8(%rsp),%rcx
  6b6002:	mov    %rcx,0xa8(%rsp)
  6b600a:	movaps %xmm1,0x90(%rsp)
  6b6012:	mov    %r13,0xc0(%rsp)
  6b601a:	mov    0x100(%rsp),%rax
  6b6022:	mov    %rax,0xc8(%rsp)
  6b602a:	mov    0x108(%rsp),%rax
  6b6032:	mov    %rax,0xd0(%rsp)
  6b603a:	mov    0x110(%rsp),%rax
  6b6042:	mov    %rax,0xd8(%rsp)
  6b604a:	movaps 0x10(%rsp),%xmm0
  6b604f:	movups %xmm0,0xe8(%rsp)
  6b6057:	mov    0x20(%rsp),%eax
  6b605b:	mov    %eax,0xf8(%rsp)
  6b6062:	mov    %r15b,0xfc(%rsp)
  6b606a:	movzwl 0x60(%rsp),%eax
  6b606f:	mov    %ax,0xfd(%rsp)
  6b6077:	movzbl 0x62(%rsp),%eax
  6b607c:	mov    %al,0xff(%rsp)
  6b6083:	test   %rcx,%rcx
  6b6086:	je     6b64a6 <text_column_public_control::observe::<text_column_public_control::Model>+0x5d6>
  6b608c:	movabs $0x100000001b3,%r13
  6b6096:	xor    %edx,%edx
  6b6098:	lea    0x10(%rsp),%rdi
  6b609d:	lea    0x100(%rsp),%r12
  6b60a5:	movq   $0x0,(%rsp)
  6b60ad:	mov    %rbp,0x88(%rsp)
  6b60b5:	jmp    6b60e7 <text_column_public_control::observe::<text_column_public_control::Model>+0x217>
  6b60b7:	nopw   0x0(%rax,%rax,1)
  6b60c0:	mov    %rbx,%r14
  6b60c3:	incq   (%rsp)
  6b60c7:	mov    0x88(%rsp),%rbp
  6b60cf:	mov    0x50(%rsp),%rdx
  6b60d4:	inc    %rdx
  6b60d7:	cmp    0x8(%rsp),%rdx
  6b60dc:	lea    0x10(%rsp),%rdi
  6b60e1:	je     6b64ae <text_column_public_control::observe::<text_column_public_control::Model>+0x5de>
  6b60e7:	mov    %rdx,%r15
  6b60ea:	shl    $0x6,%r15
  6b60ee:	movzbl 0x3d(%rbp,%r15,1),%eax
  6b60f4:	sub    $0x2,%al
  6b60f6:	movzbl %al,%eax
  6b60f9:	mov    $0x8,%ecx
  6b60fe:	cmovb  %ecx,%eax
  6b6101:	movzbl %al,%eax
  6b6104:	xor    %r14,%rax
  6b6107:	imul   %r13,%rax
  6b610b:	mov    0x10(%rbp,%r15,1),%ecx
  6b6110:	xor    %rax,%rcx
  6b6113:	mov    0x14(%rbp,%r15,1),%eax
  6b6118:	mov    0x18(%rbp,%r15,1),%r8d
  6b611d:	mov    0x1c(%rbp,%r15,1),%esi
  6b6122:	imul   %r13,%rcx
  6b6126:	xor    %rax,%rcx
  6b6129:	imul   %r13,%rcx
  6b612d:	xor    %r8,%rcx
  6b6130:	imul   %r13,%rcx
  6b6134:	xor    %rsi,%rcx
  6b6137:	movabs $0x8a97b0004e7feab,%rax
  6b6141:	imul   %rax,%rcx
  6b6145:	mov    0x8(%rbp,%r15,1),%ebx
  6b614a:	mov    0xc(%rbp,%r15,1),%eax
  6b614f:	xor    %rcx,%rbx
  6b6152:	imul   %r13,%rbx
  6b6156:	xor    %rax,%rbx
  6b6159:	imul   %r13,%rbx
  6b615d:	lea    0x90(%rsp),%rsi
  6b6165:	mov    %rdx,0x50(%rsp)
  6b616a:	call   *0x38c0d0(%rip)        # a42240 <_DYNAMIC+0x250>
  6b6170:	cmpl   $0x1,0x10(%rsp)
  6b6175:	jne    6b61be <text_column_public_control::observe::<text_column_public_control::Model>+0x2ee>
  6b6177:	mov    0x14(%rsp),%eax
  6b617b:	mov    0x18(%rsp),%ecx
  6b617f:	mov    0x1c(%rsp),%edx
  6b6183:	mov    0x20(%rsp),%esi
  6b6187:	mov    0x24(%rsp),%edi
  6b618b:	mov    0x28(%rsp),%r8d
  6b6190:	xor    $0x1,%rbx
  6b6194:	imul   %r13,%rbx
  6b6198:	xor    %rax,%rbx
  6b619b:	imul   %r13,%rbx
  6b619f:	xor    %rcx,%rbx
  6b61a2:	imul   %r13,%rbx
  6b61a6:	xor    %rdx,%rbx
  6b61a9:	imul   %r13,%rbx
  6b61ad:	xor    %rsi,%rbx
  6b61b0:	imul   %r13,%rbx
  6b61b4:	xor    %rdi,%rbx
  6b61b7:	imul   %r13,%rbx
  6b61bb:	xor    %r8,%rbx
  6b61be:	add    %rbp,%r15
  6b61c1:	mov    0x28(%r15),%rcx
  6b61c5:	test   %rcx,%rcx
  6b61c8:	je     6b6300 <text_column_public_control::observe::<text_column_public_control::Model>+0x430>
  6b61ce:	imul   %r13,%rbx
  6b61d2:	mov    (%rcx),%rdx
  6b61d5:	mov    %rdx,%rdi
  6b61d8:	shr    $1,%rdi
  6b61db:	movzbl 0x3d(%r15),%r8d
  6b61e0:	xor    $0x1,%rbx
  6b61e4:	imul   %r13,%rbx
  6b61e8:	test   %rdi,%rdi
  6b61eb:	je     6b6310 <text_column_public_control::observe::<text_column_public_control::Model>+0x440>
  6b61f1:	lea    0x10(%rcx),%rax
  6b61f5:	mov    %rdi,%rsi
  6b61f8:	and    $0x7,%rsi
  6b61fc:	lea    0x138(%rsp),%r15
  6b6204:	je     6b6409 <text_column_public_control::observe::<text_column_public_control::Model>+0x539>
  6b620a:	mov    %rsi,%r10
  6b620d:	mov    %rax,%r9
  6b6210:	movzbl (%r9),%r14d
  6b6214:	inc    %r9
  6b6217:	xor    %rbx,%r14
  6b621a:	imul   %r13,%r14
  6b621e:	mov    %r14,%rbx
  6b6221:	dec    %r10
  6b6224:	jne    6b6210 <text_column_public_control::observe::<text_column_public_control::Model>+0x340>
  6b6226:	add    %rdi,%rcx
  6b6229:	add    $0x10,%rcx
  6b622d:	cmp    $0x10,%rdx
  6b6231:	jb     6b62a8 <text_column_public_control::observe::<text_column_public_control::Model>+0x3d8>
  6b6233:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6b6240:	movzbl (%r9),%r10d
  6b6244:	xor    %r14,%r10
  6b6247:	imul   %r13,%r10
  6b624b:	movzbl 0x1(%r9),%r11d
  6b6250:	xor    %r10,%r11
  6b6253:	imul   %r13,%r11
  6b6257:	movzbl 0x2(%r9),%r10d
  6b625c:	xor    %r11,%r10
  6b625f:	imul   %r13,%r10
  6b6263:	movzbl 0x3(%r9),%r11d
  6b6268:	xor    %r10,%r11
  6b626b:	imul   %r13,%r11
  6b626f:	movzbl 0x4(%r9),%r10d
  6b6274:	xor    %r11,%r10
  6b6277:	imul   %r13,%r10
  6b627b:	movzbl 0x5(%r9),%r11d
  6b6280:	xor    %r10,%r11
  6b6283:	imul   %r13,%r11
  6b6287:	movzbl 0x6(%r9),%r10d
  6b628c:	xor    %r11,%r10
  6b628f:	imul   %r13,%r10
  6b6293:	movzbl 0x7(%r9),%r14d
  6b6298:	add    $0x8,%r9
  6b629c:	xor    %r10,%r14
  6b629f:	imul   %r13,%r14
  6b62a3:	cmp    %rcx,%r9
  6b62a6:	jne    6b6240 <text_column_public_control::observe::<text_column_public_control::Model>+0x370>
  6b62a8:	cmp    $0x4,%r8b
  6b62ac:	jne    6b6327 <text_column_public_control::observe::<text_column_public_control::Model>+0x457>
  6b62ae:	xor    $0x1,%r14
  6b62b2:	mov    %r14,%r8
  6b62b5:	imul   %r13,%r8
  6b62b9:	test   $0x7,%dil
  6b62bd:	je     6b6425 <text_column_public_control::observe::<text_column_public_control::Model>+0x555>
  6b62c3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6b62d0:	movzbl (%rax),%r14d
  6b62d4:	inc    %rax
  6b62d7:	xor    %r8,%r14
  6b62da:	imul   %r13,%r14
  6b62de:	mov    %r14,%r8
  6b62e1:	dec    %rsi
  6b62e4:	jne    6b62d0 <text_column_public_control::observe::<text_column_public_control::Model>+0x400>
  6b62e6:	cmp    $0x10,%rdx
  6b62ea:	mov    0x50(%rsp),%rdx
  6b62ef:	jae    6b6440 <text_column_public_control::observe::<text_column_public_control::Model>+0x570>
  6b62f5:	jmp    6b6330 <text_column_public_control::observe::<text_column_public_control::Model>+0x460>
  6b62f7:	nopw   0x0(%rax,%rax,1)
  6b6300:	movabs $0x366000002e329,%rax
  6b630a:	imul   %rax,%rbx
  6b630e:	jmp    6b631c <text_column_public_control::observe::<text_column_public_control::Model>+0x44c>
  6b6310:	xor    %eax,%eax
  6b6312:	cmp    $0x4,%r8b
  6b6316:	sete   %al
  6b6319:	xor    %rax,%rbx
  6b631c:	mov    %rbx,%r14
  6b631f:	lea    0x138(%rsp),%r15
  6b6327:	imul   %r13,%r14
  6b632b:	mov    0x50(%rsp),%rdx
  6b6330:	lea    0x60(%rsp),%rdi
  6b6335:	lea    0x90(%rsp),%rsi
  6b633d:	call   *0x38bf05(%rip)        # a42248 <_DYNAMIC+0x258>
  6b6343:	cmpq   $0x0,0x60(%rsp)
  6b6349:	je     6b60cf <text_column_public_control::observe::<text_column_public_control::Model>+0x1ff>
  6b634f:	mov    0x70(%rsp),%rsi
  6b6354:	mov    0x78(%rsp),%eax
  6b6358:	mov    0x7c(%rsp),%ecx
  6b635c:	xor    %rax,%r14
  6b635f:	imul   %r13,%r14
  6b6363:	xor    %rcx,%r14
  6b6366:	imul   %r13,%r14
  6b636a:	mov    0x48(%rsi),%ebx
  6b636d:	xor    %r14,%rbx
  6b6370:	imul   %r13,%rbx
  6b6374:	mov    %r12,%rdi
  6b6377:	call   *0x38bed3(%rip)        # a42250 <_DYNAMIC+0x260>
  6b637d:	lea    0x10(%rsp),%rdi
  6b6382:	mov    %r12,%rsi
  6b6385:	mov    %r15,%rdx
  6b6388:	call   6d9de0 <<core::iter::adapters::zip::Zip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>, core::iter::adapters::skip::Skip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>>> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::find_map::check<(&[gpui_canvas::text::layout::Stop], &[gpui_canvas::text::layout::Stop]), gpui_canvas::text::layout::interaction::TextGrapheme, &mut <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#1}>::{closure#0}, core::ops::control_flow::ControlFlow<gpui_canvas::text::layout::interaction::TextGrapheme>>>
  6b638d:	cmpb   $0x2,0x14(%rsp)
  6b6392:	je     6b60c0 <text_column_public_control::observe::<text_column_public_control::Model>+0x1f0>
  6b6398:	lea    0x10(%rsp),%rbp
  6b639d:	nopl   (%rax)
  6b63a0:	mov    0x10(%rsp),%r14d
  6b63a5:	mov    0x18(%rsp),%eax
  6b63a9:	xor    %rbx,%r14
  6b63ac:	mov    0x20(%rsp),%ecx
  6b63b0:	mov    0x24(%rsp),%edx
  6b63b4:	mov    0x28(%rsp),%esi
  6b63b8:	mov    0x2c(%rsp),%edi
  6b63bc:	imul   %r13,%r14
  6b63c0:	xor    %rax,%r14
  6b63c3:	imul   %r13,%r14
  6b63c7:	xor    %rcx,%r14
  6b63ca:	imul   %r13,%r14
  6b63ce:	xor    %rdx,%r14
  6b63d1:	imul   %r13,%r14
  6b63d5:	xor    %rsi,%r14
  6b63d8:	imul   %r13,%r14
  6b63dc:	xor    %rdi,%r14
  6b63df:	imul   %r13,%r14
  6b63e3:	xor    0x30(%rsp),%r14
  6b63e8:	imul   %r13,%r14
  6b63ec:	mov    %rbp,%rdi
  6b63ef:	mov    %r12,%rsi
  6b63f2:	mov    %r15,%rdx
  6b63f5:	call   6d9de0 <<core::iter::adapters::zip::Zip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>, core::iter::adapters::skip::Skip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>>> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::find_map::check<(&[gpui_canvas::text::layout::Stop], &[gpui_canvas::text::layout::Stop]), gpui_canvas::text::layout::interaction::TextGrapheme, &mut <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#1}>::{closure#0}, core::ops::control_flow::ControlFlow<gpui_canvas::text::layout::interaction::TextGrapheme>>>
  6b63fa:	cmpb   $0x2,0x14(%rsp)
  6b63ff:	mov    %r14,%rbx
  6b6402:	jne    6b63a0 <text_column_public_control::observe::<text_column_public_control::Model>+0x4d0>
  6b6404:	jmp    6b60c3 <text_column_public_control::observe::<text_column_public_control::Model>+0x1f3>
  6b6409:	mov    %rbx,%r14
  6b640c:	mov    %rax,%r9
  6b640f:	add    %rdi,%rcx
  6b6412:	add    $0x10,%rcx
  6b6416:	cmp    $0x10,%rdx
  6b641a:	jae    6b6240 <text_column_public_control::observe::<text_column_public_control::Model>+0x370>
  6b6420:	jmp    6b62a8 <text_column_public_control::observe::<text_column_public_control::Model>+0x3d8>
  6b6425:	mov    %r8,%r14
  6b6428:	cmp    $0x10,%rdx
  6b642c:	mov    0x50(%rsp),%rdx
  6b6431:	jb     6b6330 <text_column_public_control::observe::<text_column_public_control::Model>+0x460>
  6b6437:	nopw   0x0(%rax,%rax,1)
  6b6440:	movzbl (%rax),%edi
  6b6443:	xor    %r14,%rdi
  6b6446:	imul   %r13,%rdi
  6b644a:	movzbl 0x1(%rax),%esi
  6b644e:	xor    %rdi,%rsi
  6b6451:	imul   %r13,%rsi
  6b6455:	movzbl 0x2(%rax),%edi
  6b6459:	xor    %rsi,%rdi
  6b645c:	imul   %r13,%rdi
  6b6460:	movzbl 0x3(%rax),%esi
  6b6464:	xor    %rdi,%rsi
  6b6467:	imul   %r13,%rsi
  6b646b:	movzbl 0x4(%rax),%edi
  6b646f:	xor    %rsi,%rdi
  6b6472:	imul   %r13,%rdi
  6b6476:	movzbl 0x5(%rax),%esi
  6b647a:	xor    %rdi,%rsi
  6b647d:	imul   %r13,%rsi
  6b6481:	movzbl 0x6(%rax),%edi
  6b6485:	xor    %rsi,%rdi
  6b6488:	imul   %r13,%rdi
  6b648c:	movzbl 0x7(%rax),%r14d
  6b6491:	add    $0x8,%rax
  6b6495:	xor    %rdi,%r14
  6b6498:	imul   %r13,%r14
  6b649c:	cmp    %rcx,%rax
  6b649f:	jne    6b6440 <text_column_public_control::observe::<text_column_public_control::Model>+0x570>
  6b64a1:	jmp    6b6330 <text_column_public_control::observe::<text_column_public_control::Model>+0x460>
  6b64a6:	movq   $0x0,(%rsp)
  6b64ae:	mov    0x80(%rsp),%rax
  6b64b6:	mov    0x8(%rsp),%rcx
  6b64bb:	mov    %rcx,(%rax)
  6b64be:	mov    (%rsp),%rcx
  6b64c2:	mov    %rcx,0x8(%rax)
  6b64c6:	mov    %r14,0x10(%rax)
  6b64ca:	add    $0x148,%rsp
  6b64d1:	pop    %rbx
  6b64d2:	pop    %r12
  6b64d4:	pop    %r13
  6b64d6:	pop    %r14
  6b64d8:	pop    %r15
  6b64da:	pop    %rbp
  6b64db:	ret
  6b64dc:	mov    $0xd,%eax
  6b64e1:	jmp    6b64ef <text_column_public_control::observe::<text_column_public_control::Model>+0x61f>
  6b64e3:	mov    $0xe,%eax
  6b64e8:	jmp    6b64ef <text_column_public_control::observe::<text_column_public_control::Model>+0x61f>
  6b64ea:	mov    $0x12,%eax
  6b64ef:	mov    %rax,0x90(%rsp)
  6b64f7:	movq   $0x0,0x98(%rsp)
  6b6503:	lea    -0x668e2b(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6b650a:	lea    0x36c817(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6b6511:	lea    0x36b610(%rip),%r8        # a21b28 <__frame_dummy_init_array_entry+0x38>
  6b6518:	lea    0x90(%rsp),%rdx
  6b6520:	mov    $0x2b,%esi
  6b6525:	call   *0x38bd05(%rip)        # a42230 <_DYNAMIC+0x240>
  6b652b:	ud2
  6b652d:	mov    %rax,%rbx
  6b6530:	lea    0x90(%rsp),%rdi
  6b6538:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6b653d:	mov    %rbx,%rdi
  6b6540:	call   a20740 <_Unwind_Resume@plt>

<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#37}> code=105 fixed_stack=0

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006b6600 <<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#37}>>:
  6b6600:	cmpq   $0xffffffffffffffff,(%rsi)
  6b6604:	je     6b662f <<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#37}>+0x2f>
  6b6606:	mov    0x10(%rsi),%rax
  6b660a:	mov    %rax,0x10(%rdi)
  6b660e:	movups (%rsi),%xmm0
  6b6611:	movups %xmm0,(%rdi)
  6b6614:	mov    (%rdx),%rsi
  6b6617:	test   %rsi,%rsi
  6b661a:	je     6b664a <<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#37}>+0x4a>
  6b661c:	mov    0x8(%rdx),%rdi
  6b6620:	shl    $0x4,%rsi
  6b6624:	mov    $0x4,%edx
  6b6629:	jmp    *0x38bc29(%rip)        # a42258 <_DYNAMIC+0x268>
  6b662f:	mov    (%rdx),%rsi
  6b6632:	mov    0x8(%rdx),%rax
  6b6636:	mov    0x10(%rdx),%rcx
  6b663a:	test   %rcx,%rcx
  6b663d:	je     6b664b <<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#37}>+0x4b>
  6b663f:	mov    %rsi,(%rdi)
  6b6642:	mov    %rax,0x8(%rdi)
  6b6646:	mov    %rcx,0x10(%rdi)
  6b664a:	ret
  6b664b:	movq   $0xffffffffffffffff,(%rdi)
  6b6652:	test   %rsi,%rsi
  6b6655:	je     6b664a <<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#37}>+0x4a>
  6b6657:	shl    $0x4,%rsi
  6b665b:	mov    $0x4,%edx
  6b6660:	mov    %rax,%rdi
  6b6663:	jmp    *0x38bbef(%rip)        # a42258 <_DYNAMIC+0x268>

<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}> code=1105 fixed_stack=344

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006b8010 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>>:
  6b8010:	test   %rdi,%rdi
  6b8013:	je     6b8382 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x372>
  6b8019:	push   %rbp
  6b801a:	push   %r15
  6b801c:	push   %r14
  6b801e:	push   %r13
  6b8020:	push   %r12
  6b8022:	push   %rbx
  6b8023:	sub    $0x128,%rsp
  6b802a:	mov    %rsi,%r12
  6b802d:	mov    %rdi,%r15
  6b8030:	lea    0x10(%rdi),%r14
  6b8034:	mov    (%rdx),%rbp
  6b8037:	mov    0x8(%rdx),%rbx
  6b803b:	mov    0x10(%rdx),%rax
  6b803f:	mov    %rax,0x48(%rsp)
  6b8044:	mov    0x18(%rdx),%rax
  6b8048:	mov    %rax,0x40(%rsp)
  6b804d:	mov    0x20(%rdx),%rax
  6b8051:	mov    %rax,0x50(%rsp)
  6b8056:	mov    0x28(%rdx),%rax
  6b805a:	mov    %rax,0x58(%rsp)
  6b805f:	mov    %r14,%rdi
  6b8062:	call   *0x38a250(%rip)        # a422b8 <_DYNAMIC+0x2c8>
  6b8068:	test   %al,%al
  6b806a:	je     6b8385 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x375>
  6b8070:	mov    (%r12),%esi
  6b8074:	mov    0x8(%r12),%ecx
  6b8079:	mov    $0x1,%al
  6b807b:	cmp    %esi,%ecx
  6b807d:	je     6b844f <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x43f>
  6b8083:	mov    %rbx,0x38(%rsp)
  6b8088:	mov    %esi,%edx
  6b808a:	cmova  %ecx,%edx
  6b808d:	cmovb  %ecx,%esi
  6b8090:	mov    %r14,%rdi
  6b8093:	call   *0x38a227(%rip)        # a422c0 <_DYNAMIC+0x2d0>
  6b8099:	mov    %rdx,%rcx
  6b809c:	movss  0x5c(%r15),%xmm0
  6b80a2:	mulss  -0x67821a(%rip),%xmm0        # 3fe90 <GCC_except_table0+0xec>
  6b80aa:	lea    0xe0(%rsp),%r15
  6b80b2:	mov    %r15,%rdi
  6b80b5:	mov    %r14,%rsi
  6b80b8:	mov    %rax,%rdx
  6b80bb:	call   *0x38a207(%rip)        # a422c8 <_DYNAMIC+0x2d8>
  6b80c1:	lea    0x118(%rsp),%r14
  6b80c9:	lea    0x70(%rsp),%rdi
  6b80ce:	mov    %r15,%rsi
  6b80d1:	mov    %r14,%rdx
  6b80d4:	call   6d9de0 <<core::iter::adapters::zip::Zip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>, core::iter::adapters::skip::Skip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>>> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::find_map::check<(&[gpui_canvas::text::layout::Stop], &[gpui_canvas::text::layout::Stop]), gpui_canvas::text::layout::interaction::TextGrapheme, &mut <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#1}>::{closure#0}, core::ops::control_flow::ControlFlow<gpui_canvas::text::layout::interaction::TextGrapheme>>>
  6b80d9:	cmpb   $0x2,0x74(%rsp)
  6b80de:	je     6b844d <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x43d>
  6b80e4:	xor    %eax,%eax
  6b80e6:	lea    0x70(%rsp),%r15
  6b80eb:	lea    0xe0(%rsp),%r12
  6b80f3:	test   $0x1,%al
  6b80f5:	je     6b8100 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0xf0>
  6b80f7:	movaps %xmm0,0x60(%rsp)
  6b80fc:	jmp    6b8163 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x153>
  6b80fe:	xchg   %ax,%ax
  6b8100:	movss  0x88(%rsp),%xmm1
  6b8109:	xorps  %xmm0,%xmm0
  6b810c:	ucomiss %xmm0,%xmm1
  6b810f:	jne    6b8233 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x223>
  6b8115:	jp     6b8233 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x223>
  6b811b:	mov    %r15,%rdi
  6b811e:	mov    %r12,%rsi
  6b8121:	mov    %r14,%rdx
  6b8124:	call   6d9de0 <<core::iter::adapters::zip::Zip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>, core::iter::adapters::skip::Skip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>>> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::find_map::check<(&[gpui_canvas::text::layout::Stop], &[gpui_canvas::text::layout::Stop]), gpui_canvas::text::layout::interaction::TextGrapheme, &mut <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#1}>::{closure#0}, core::ops::control_flow::ControlFlow<gpui_canvas::text::layout::interaction::TextGrapheme>>>
  6b8129:	cmpb   $0x2,0x74(%rsp)
  6b812e:	jne    6b8100 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0xf0>
  6b8130:	jmp    6b844d <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x43d>
  6b8135:	data16 cs nopw 0x0(%rax,%rax,1)
  6b8140:	movaps %xmm5,0x10(%rsp)
  6b8145:	mov    %r15,%rdi
  6b8148:	mov    %r12,%rsi
  6b814b:	mov    %r14,%rdx
  6b814e:	call   6d9de0 <<core::iter::adapters::zip::Zip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>, core::iter::adapters::skip::Skip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>>> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::find_map::check<(&[gpui_canvas::text::layout::Stop], &[gpui_canvas::text::layout::Stop]), gpui_canvas::text::layout::interaction::TextGrapheme, &mut <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#1}>::{closure#0}, core::ops::control_flow::ControlFlow<gpui_canvas::text::layout::interaction::TextGrapheme>>>
  6b8153:	cmpb   $0x2,0x74(%rsp)
  6b8158:	movaps 0x10(%rsp),%xmm5
  6b815d:	je     6b838c <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x37c>
  6b8163:	movss  0x88(%rsp),%xmm2
  6b816c:	xorps  %xmm0,%xmm0
  6b816f:	ucomiss %xmm0,%xmm2
  6b8172:	jne    6b8176 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x166>
  6b8174:	jnp    6b8140 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x130>
  6b8176:	movsd  0x80(%rsp),%xmm3
  6b817f:	movss  0x8c(%rsp),%xmm4
  6b8188:	mov    0x90(%rsp),%r13
  6b8190:	cmp    %r13,%rbx
  6b8193:	jne    6b8266 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x256>
  6b8199:	movaps %xmm3,%xmm0
  6b819c:	shufps $0x55,%xmm3,%xmm0
  6b81a0:	movaps 0xb0(%rsp),%xmm1
  6b81a8:	ucomiss %xmm0,%xmm1
  6b81ab:	jne    6b8266 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x256>
  6b81b1:	jp     6b8266 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x256>
  6b81b7:	movss  0x4(%rsp),%xmm0
  6b81bd:	ucomiss %xmm4,%xmm0
  6b81c0:	jne    6b8266 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x256>
  6b81c6:	jp     6b8266 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x256>
  6b81cc:	movaps %xmm3,%xmm0
  6b81cf:	addss  %xmm2,%xmm0
  6b81d3:	ucomiss %xmm5,%xmm0
  6b81d6:	jb     6b8263 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x253>
  6b81dc:	movaps 0x60(%rsp),%xmm1
  6b81e1:	addss  %xmm5,%xmm1
  6b81e5:	ucomiss %xmm3,%xmm1
  6b81e8:	jb     6b8263 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x253>
  6b81ea:	movaps %xmm1,%xmm2
  6b81ed:	maxss  %xmm0,%xmm2
  6b81f1:	movaps %xmm2,%xmm4
  6b81f4:	cmpunordss %xmm2,%xmm4
  6b81f9:	movaps %xmm4,%xmm0
  6b81fc:	andnps %xmm2,%xmm0
  6b81ff:	andps  %xmm1,%xmm4
  6b8202:	orps   %xmm0,%xmm4
  6b8205:	movaps %xmm5,%xmm0
  6b8208:	minss  %xmm3,%xmm0
  6b820c:	movaps %xmm0,%xmm1
  6b820f:	cmpunordss %xmm0,%xmm1
  6b8214:	movaps %xmm1,%xmm2
  6b8217:	andnps %xmm0,%xmm2
  6b821a:	andps  %xmm5,%xmm1
  6b821d:	orps   %xmm2,%xmm1
  6b8220:	subss  %xmm1,%xmm4
  6b8224:	movaps %xmm4,0x60(%rsp)
  6b8229:	movaps %xmm1,0x10(%rsp)
  6b822e:	jmp    6b8145 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x135>
  6b8233:	movss  %xmm1,0xc(%rsp)
  6b8239:	movsd  0x80(%rsp),%xmm0
  6b8242:	movaps %xmm0,0x10(%rsp)
  6b8247:	movss  0x8c(%rsp),%xmm0
  6b8250:	movss  %xmm0,0x8(%rsp)
  6b8256:	mov    0x90(%rsp),%r13
  6b825e:	jmp    6b8336 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x326>
  6b8263:	mov    %rbx,%r13
  6b8266:	movss  %xmm4,0x8(%rsp)
  6b826c:	movss  %xmm2,0xc(%rsp)
  6b8272:	movaps %xmm3,0x10(%rsp)
  6b8277:	cmpl   $0xffffffff,0x0(%rbp)
  6b827b:	jne    6b8336 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x326>
  6b8281:	unpcklps 0xb0(%rsp),%xmm5
  6b8289:	mov    0x40(%rsp),%rax
  6b828e:	movss  (%rax),%xmm0
  6b8292:	mov    0x48(%rsp),%rax
  6b8297:	movss  (%rax),%xmm1
  6b829b:	unpcklps %xmm0,%xmm1
  6b829e:	addps  %xmm5,%xmm1
  6b82a1:	movlps %xmm1,0xc0(%rsp)
  6b82a9:	movaps 0x60(%rsp),%xmm0
  6b82ae:	movss  %xmm0,0xc8(%rsp)
  6b82b7:	movss  0x4(%rsp),%xmm0
  6b82bd:	movss  %xmm0,0xcc(%rsp)
  6b82c6:	mov    0x50(%rsp),%rcx
  6b82cb:	mov    0x10(%rcx),%rax
  6b82cf:	mov    %rax,0x80(%rsp)
  6b82d7:	movups (%rcx),%xmm0
  6b82da:	movaps %xmm0,0x70(%rsp)
  6b82df:	mov    0x58(%rsp),%rax
  6b82e4:	movups (%rax),%xmm0
  6b82e7:	movaps %xmm0,0x20(%rsp)
  6b82ec:	lea    0xd0(%rsp),%rbx
  6b82f4:	mov    %rbx,%rdi
  6b82f7:	mov    $0x46,%esi
  6b82fc:	mov    $0x82,%edx
  6b8301:	mov    $0xf0,%ecx
  6b8306:	mov    $0x60,%r8d
  6b830c:	call   *0x389fbe(%rip)        # a422d0 <_DYNAMIC+0x2e0>
  6b8312:	mov    0x38(%rsp),%rdi
  6b8317:	lea    0xc0(%rsp),%rsi
  6b831f:	mov    %r15,%rdx
  6b8322:	lea    0x20(%rsp),%rcx
  6b8327:	mov    %rbx,%r8
  6b832a:	call   *0x389fa8(%rip)        # a422d8 <_DYNAMIC+0x2e8>
  6b8330:	mov    %eax,0x0(%rbp)
  6b8333:	mov    %edx,0x4(%rbp)
  6b8336:	mov    %r15,%rdi
  6b8339:	mov    %r12,%rsi
  6b833c:	mov    %r14,%rdx
  6b833f:	call   6d9de0 <<core::iter::adapters::zip::Zip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>, core::iter::adapters::skip::Skip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>>> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::find_map::check<(&[gpui_canvas::text::layout::Stop], &[gpui_canvas::text::layout::Stop]), gpui_canvas::text::layout::interaction::TextGrapheme, &mut <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#1}>::{closure#0}, core::ops::control_flow::ControlFlow<gpui_canvas::text::layout::interaction::TextGrapheme>>>
  6b8344:	cmpb   $0x2,0x74(%rsp)
  6b8349:	movaps 0x10(%rsp),%xmm2
  6b834e:	movaps %xmm2,%xmm0
  6b8351:	shufps $0x55,%xmm2,%xmm0
  6b8355:	movaps %xmm0,0xb0(%rsp)
  6b835d:	mov    $0x1,%al
  6b835f:	mov    %r13,%rbx
  6b8362:	movss  0x8(%rsp),%xmm4
  6b8368:	movss  %xmm4,0x4(%rsp)
  6b836e:	movss  0xc(%rsp),%xmm3
  6b8374:	movaps %xmm3,%xmm0
  6b8377:	movaps %xmm2,%xmm5
  6b837a:	jne    6b80f3 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0xe3>
  6b8380:	jmp    6b83a2 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x392>
  6b8382:	xor    %eax,%eax
  6b8384:	ret
  6b8385:	xor    %eax,%eax
  6b8387:	jmp    6b844f <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x43f>
  6b838c:	unpcklps 0xb0(%rsp),%xmm5
  6b8394:	movss  0x4(%rsp),%xmm4
  6b839a:	movaps 0x60(%rsp),%xmm3
  6b839f:	movaps %xmm5,%xmm2
  6b83a2:	cmpl   $0xffffffff,0x0(%rbp)
  6b83a6:	jne    6b844d <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x43d>
  6b83ac:	mov    0x40(%rsp),%rax
  6b83b1:	movss  (%rax),%xmm0
  6b83b5:	mov    0x48(%rsp),%rax
  6b83ba:	movss  (%rax),%xmm1
  6b83be:	unpcklps %xmm0,%xmm1
  6b83c1:	addps  %xmm1,%xmm2
  6b83c4:	movlps %xmm2,0x20(%rsp)
  6b83c9:	movss  %xmm3,0x28(%rsp)
  6b83cf:	movss  %xmm4,0x2c(%rsp)
  6b83d5:	mov    0x50(%rsp),%rcx
  6b83da:	mov    0x10(%rcx),%rax
  6b83de:	mov    %rax,0xf0(%rsp)
  6b83e6:	movups (%rcx),%xmm0
  6b83e9:	movaps %xmm0,0xe0(%rsp)
  6b83f1:	mov    0x58(%rsp),%rax
  6b83f6:	movups (%rax),%xmm0
  6b83f9:	movaps %xmm0,0xd0(%rsp)
  6b8401:	lea    0x70(%rsp),%r14
  6b8406:	mov    %r14,%rdi
  6b8409:	mov    $0x46,%esi
  6b840e:	mov    $0x82,%edx
  6b8413:	mov    $0xf0,%ecx
  6b8418:	mov    $0x60,%r8d
  6b841e:	call   *0x389eac(%rip)        # a422d0 <_DYNAMIC+0x2e0>
  6b8424:	lea    0x20(%rsp),%rsi
  6b8429:	lea    0xe0(%rsp),%rdx
  6b8431:	lea    0xd0(%rsp),%rcx
  6b8439:	mov    0x38(%rsp),%rdi
  6b843e:	mov    %r14,%r8
  6b8441:	call   *0x389e91(%rip)        # a422d8 <_DYNAMIC+0x2e8>
  6b8447:	mov    %eax,0x0(%rbp)
  6b844a:	mov    %edx,0x4(%rbp)
  6b844d:	mov    $0x1,%al
  6b844f:	add    $0x128,%rsp
  6b8456:	pop    %rbx
  6b8457:	pop    %r12
  6b8459:	pop    %r13
  6b845b:	pop    %r14
  6b845d:	pop    %r15
  6b845f:	pop    %rbp
  6b8460:	ret

<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}> code=1391 fixed_stack=120

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006b84d0 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>>:
  6b84d0:	push   %rbp
  6b84d1:	push   %r15
  6b84d3:	push   %r14
  6b84d5:	push   %r13
  6b84d7:	push   %r12
  6b84d9:	push   %rbx
  6b84da:	sub    $0x48,%rsp
  6b84de:	mov    %rdx,0x10(%rsp)
  6b84e3:	mov    %rdi,0x18(%rsp)
  6b84e8:	mov    0x10(%rsi),%rbx
  6b84ec:	test   %rbx,%rbx
  6b84ef:	mov    %rsi,0x8(%rsp)
  6b84f4:	je     6b8539 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x69>
  6b84f6:	mov    0x8(%rsi),%rbp
  6b84fa:	lea    -0x1(%rbx),%r15
  6b84fe:	mov    $0x28,%r13d
  6b8504:	xor    %r14d,%r14d
  6b8507:	nopw   0x0(%rax,%rax,1)
  6b8510:	mov    -0x28(%rbp,%r13,1),%rsi
  6b8515:	mov    0x10(%rsp),%rdi
  6b851a:	call   6daf00 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>
  6b851f:	test   $0x1,%al
  6b8521:	je     6b853e <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x6e>
  6b8523:	mov    %edx,-0x4(%rbp,%r13,1)
  6b8528:	inc    %r14
  6b852b:	add    $0x28,%r13
  6b852f:	cmp    %r14,%rbx
  6b8532:	jne    6b8510 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x40>
  6b8534:	mov    %rbx,%r14
  6b8537:	jmp    6b85a1 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0xd1>
  6b8539:	xor    %r14d,%r14d
  6b853c:	jmp    6b85a1 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0xd1>
  6b853e:	lea    0x1(%r14),%rax
  6b8542:	cmp    %rbx,%rax
  6b8545:	jae    6b85a1 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0xd1>
  6b8547:	sub    %r14,%r15
  6b854a:	jmp    6b8559 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x89>
  6b854c:	nopl   0x0(%rax)
  6b8550:	add    $0x28,%r13
  6b8554:	dec    %r15
  6b8557:	je     6b85a1 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0xd1>
  6b8559:	mov    %rbp,%r12
  6b855c:	add    %r13,%r12
  6b855f:	mov    0x0(%rbp,%r13,1),%rsi
  6b8564:	mov    0x10(%rsp),%rdi
  6b8569:	call   6daf00 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>
  6b856e:	cmp    $0x1,%rax
  6b8572:	jne    6b8550 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x80>
  6b8574:	mov    %edx,0x24(%rbp,%r13,1)
  6b8579:	lea    (%r14,%r14,4),%rax
  6b857d:	mov    0x20(%r12),%rcx
  6b8582:	mov    %rcx,0x20(%rbp,%rax,8)
  6b8587:	movups (%r12),%xmm0
  6b858c:	movups 0x10(%r12),%xmm1
  6b8592:	movups %xmm1,0x10(%rbp,%rax,8)
  6b8597:	movups %xmm0,0x0(%rbp,%rax,8)
  6b859c:	inc    %r14
  6b859f:	jmp    6b8550 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x80>
  6b85a1:	mov    0x8(%rsp),%rax
  6b85a6:	mov    0x28(%rax),%rbp
  6b85aa:	test   %rbp,%rbp
  6b85ad:	mov    %r14,0x20(%rsp)
  6b85b2:	je     6b85f9 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x129>
  6b85b4:	mov    0x20(%rax),%r13
  6b85b8:	lea    -0x1(%rbp),%r15
  6b85bc:	mov    $0x40,%ebx
  6b85c1:	xor    %r12d,%r12d
  6b85c4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6b85d0:	mov    -0x10(%r13,%rbx,1),%rsi
  6b85d5:	mov    0x10(%rsp),%rdi
  6b85da:	call   6daf00 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>
  6b85df:	test   $0x1,%al
  6b85e1:	je     6b85fe <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x12e>
  6b85e3:	mov    %edx,-0x8(%r13,%rbx,1)
  6b85e8:	inc    %r12
  6b85eb:	add    $0x40,%rbx
  6b85ef:	cmp    %r12,%rbp
  6b85f2:	jne    6b85d0 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x100>
  6b85f4:	mov    %rbp,%r12
  6b85f7:	jmp    6b8671 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x1a1>
  6b85f9:	xor    %r12d,%r12d
  6b85fc:	jmp    6b8671 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x1a1>
  6b85fe:	lea    0x1(%r12),%rax
  6b8603:	cmp    %rbp,%rax
  6b8606:	jae    6b8671 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x1a1>
  6b8608:	sub    %r12,%r15
  6b860b:	jmp    6b861c <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x14c>
  6b860d:	nopl   (%rax)
  6b8610:	mov    %r14,%rbp
  6b8613:	add    $0x40,%rbx
  6b8617:	dec    %r15
  6b861a:	je     6b8671 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x1a1>
  6b861c:	mov    %rbp,%r14
  6b861f:	lea    (%rbx,%r13,1),%rbp
  6b8623:	mov    0x30(%r13,%rbx,1),%rsi
  6b8628:	mov    0x10(%rsp),%rdi
  6b862d:	call   6daf00 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>
  6b8632:	cmp    $0x1,%rax
  6b8636:	jne    6b8610 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x140>
  6b8638:	mov    %edx,0x38(%r13,%rbx,1)
  6b863d:	mov    %r12,%rax
  6b8640:	shl    $0x6,%rax
  6b8644:	movups 0x0(%rbp),%xmm0
  6b8648:	movups 0x10(%rbp),%xmm1
  6b864c:	movups 0x20(%rbp),%xmm2
  6b8650:	movups 0x30(%rbp),%xmm3
  6b8654:	movups %xmm3,0x30(%r13,%rax,1)
  6b865a:	movups %xmm2,0x20(%r13,%rax,1)
  6b8660:	movups %xmm1,0x10(%r13,%rax,1)
  6b8666:	movups %xmm0,0x0(%r13,%rax,1)
  6b866c:	inc    %r12
  6b866f:	jmp    6b8610 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x140>
  6b8671:	mov    0x20(%rsp),%r14
  6b8676:	test   %r14,%r14
  6b8679:	je     6b86e0 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x210>
  6b867b:	test   %r12,%r12
  6b867e:	je     6b873a <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x26a>
  6b8684:	mov    0x8(%rsp),%rcx
  6b8689:	mov    (%rcx),%rax
  6b868c:	mov    0x8(%rcx),%rbx
  6b8690:	cmp    %r14,%rax
  6b8693:	jbe    6b8793 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x2c3>
  6b8699:	shl    $0x3,%rax
  6b869d:	lea    (%rax,%rax,4),%r13
  6b86a1:	lea    0x0(,%r14,8),%rax
  6b86a9:	lea    (%rax,%rax,4),%rbp
  6b86ad:	mov    $0x8,%edx
  6b86b2:	mov    %rbx,%rdi
  6b86b5:	mov    %r13,%rsi
  6b86b8:	mov    %rbp,%rcx
  6b86bb:	call   *0x389c1f(%rip)        # a422e0 <_DYNAMIC+0x2f0>
  6b86c1:	mov    %rax,%r15
  6b86c4:	test   %rax,%rax
  6b86c7:	jne    6b8796 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x2c6>
  6b86cd:	mov    $0x8,%edi
  6b86d2:	mov    %rbp,%rsi
  6b86d5:	call   *0x389c0d(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  6b86db:	jmp    6b88fe <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x42e>
  6b86e0:	test   %r12,%r12
  6b86e3:	je     6b883b <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x36b>
  6b86e9:	mov    0x8(%rsp),%r14
  6b86ee:	mov    0x18(%r14),%r15
  6b86f2:	mov    0x20(%r14),%rbx
  6b86f6:	cmp    %r12,%r15
  6b86f9:	jbe    6b8854 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x384>
  6b86ff:	shl    $0x6,%r15
  6b8703:	mov    %r12,%r13
  6b8706:	shl    $0x6,%r13
  6b870a:	mov    $0x8,%edx
  6b870f:	mov    %rbx,%rdi
  6b8712:	mov    %r15,%rsi
  6b8715:	mov    %r13,%rcx
  6b8718:	call   *0x389bc2(%rip)        # a422e0 <_DYNAMIC+0x2f0>
  6b871e:	test   %rax,%rax
  6b8721:	jne    6b8857 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x387>
  6b8727:	mov    $0x8,%edi
  6b872c:	mov    %r13,%rsi
  6b872f:	call   *0x389bb3(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  6b8735:	jmp    6b88fe <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x42e>
  6b873a:	mov    0x8(%rsp),%rcx
  6b873f:	mov    (%rcx),%rax
  6b8742:	mov    0x8(%rcx),%r15
  6b8746:	cmp    %r14,%rax
  6b8749:	jbe    6b88ba <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x3ea>
  6b874f:	shl    $0x3,%rax
  6b8753:	lea    (%rax,%rax,4),%r12
  6b8757:	lea    0x0(,%r14,8),%rax
  6b875f:	lea    (%rax,%rax,4),%r13
  6b8763:	mov    $0x8,%edx
  6b8768:	mov    %r15,%rdi
  6b876b:	mov    %r12,%rsi
  6b876e:	mov    %r13,%rcx
  6b8771:	call   *0x389b69(%rip)        # a422e0 <_DYNAMIC+0x2f0>
  6b8777:	test   %rax,%rax
  6b877a:	jne    6b88bd <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x3ed>
  6b8780:	mov    $0x8,%edi
  6b8785:	mov    %r13,%rsi
  6b8788:	call   *0x389b5a(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  6b878e:	jmp    6b88fe <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x42e>
  6b8793:	mov    %rbx,%r15
  6b8796:	mov    0x8(%rsp),%rax
  6b879b:	mov    0x18(%rax),%rbp
  6b879f:	mov    0x20(%rax),%rbx
  6b87a3:	cmp    %r12,%rbp
  6b87a6:	jbe    6b87df <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x30f>
  6b87a8:	shl    $0x6,%rbp
  6b87ac:	mov    %r12,%r13
  6b87af:	shl    $0x6,%r13
  6b87b3:	mov    $0x8,%edx
  6b87b8:	mov    %rbx,%rdi
  6b87bb:	mov    %rbp,%rsi
  6b87be:	mov    %r13,%rcx
  6b87c1:	call   *0x389b19(%rip)        # a422e0 <_DYNAMIC+0x2f0>
  6b87c7:	test   %rax,%rax
  6b87ca:	jne    6b87e2 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x312>
  6b87cc:	mov    $0x8,%edi
  6b87d1:	mov    %r13,%rsi
  6b87d4:	call   *0x389b0e(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  6b87da:	jmp    6b88fe <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x42e>
  6b87df:	mov    %rbx,%rax
  6b87e2:	mov    %r15,0x28(%rsp)
  6b87e7:	mov    %r14,0x30(%rsp)
  6b87ec:	mov    %rax,0x38(%rsp)
  6b87f1:	mov    %r12,0x40(%rsp)
  6b87f6:	call   *0x389a64(%rip)        # a42260 <_DYNAMIC+0x270>
  6b87fc:	mov    $0x20,%edi
  6b8801:	mov    $0x8,%esi
  6b8806:	call   *0x389a5c(%rip)        # a42268 <_DYNAMIC+0x278>
  6b880c:	test   %rax,%rax
  6b880f:	je     6b88ee <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x41e>
  6b8815:	movups 0x28(%rsp),%xmm0
  6b881a:	movups 0x38(%rsp),%xmm1
  6b881f:	movups %xmm1,0x10(%rax)
  6b8823:	movups %xmm0,(%rax)
  6b8826:	mov    0x18(%rsp),%rcx
  6b882b:	mov    %rax,0x8(%rcx)
  6b882f:	movq   $0x3,(%rcx)
  6b8836:	jmp    6b88df <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x40f>
  6b883b:	xor    %eax,%eax
  6b883d:	mov    0x8(%rsp),%r14
  6b8842:	mov    0x18(%rsp),%rcx
  6b8847:	mov    %rax,(%rcx)
  6b884a:	mov    (%r14),%rax
  6b884d:	test   %rax,%rax
  6b8850:	jne    6b8874 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x3a4>
  6b8852:	jmp    6b888b <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x3bb>
  6b8854:	mov    %rbx,%rax
  6b8857:	mov    0x18(%rsp),%rcx
  6b885c:	mov    %rax,0x8(%rcx)
  6b8860:	mov    %r12,0x10(%rcx)
  6b8864:	mov    $0x2,%eax
  6b8869:	mov    %rax,(%rcx)
  6b886c:	mov    (%r14),%rax
  6b886f:	test   %rax,%rax
  6b8872:	je     6b888b <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x3bb>
  6b8874:	mov    0x8(%r14),%rdi
  6b8878:	shl    $0x3,%rax
  6b887c:	lea    (%rax,%rax,4),%rsi
  6b8880:	mov    $0x8,%edx
  6b8885:	call   *0x3899cd(%rip)        # a42258 <_DYNAMIC+0x268>
  6b888b:	test   %r12,%r12
  6b888e:	jne    6b88df <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x40f>
  6b8890:	mov    0x18(%r14),%rsi
  6b8894:	test   %rsi,%rsi
  6b8897:	je     6b88df <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x40f>
  6b8899:	mov    0x20(%r14),%rdi
  6b889d:	shl    $0x6,%rsi
  6b88a1:	mov    $0x8,%edx
  6b88a6:	add    $0x48,%rsp
  6b88aa:	pop    %rbx
  6b88ab:	pop    %r12
  6b88ad:	pop    %r13
  6b88af:	pop    %r14
  6b88b1:	pop    %r15
  6b88b3:	pop    %rbp
  6b88b4:	jmp    *0x38999e(%rip)        # a42258 <_DYNAMIC+0x268>
  6b88ba:	mov    %r15,%rax
  6b88bd:	mov    0x18(%rsp),%rcx
  6b88c2:	mov    %rax,0x8(%rcx)
  6b88c6:	mov    %r14,0x10(%rcx)
  6b88ca:	movq   $0x1,(%rcx)
  6b88d1:	mov    0x8(%rsp),%r14
  6b88d6:	mov    0x18(%r14),%rsi
  6b88da:	test   %rsi,%rsi
  6b88dd:	jne    6b8899 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x3c9>
  6b88df:	add    $0x48,%rsp
  6b88e3:	pop    %rbx
  6b88e4:	pop    %r12
  6b88e6:	pop    %r13
  6b88e8:	pop    %r14
  6b88ea:	pop    %r15
  6b88ec:	pop    %rbp
  6b88ed:	ret
  6b88ee:	mov    $0x8,%edi
  6b88f3:	mov    $0x20,%esi
  6b88f8:	call   *0x389972(%rip)        # a42270 <_DYNAMIC+0x280>
  6b88fe:	ud2
  6b8900:	mov    %rax,%r14
  6b8903:	mov    $0x8,%edx
  6b8908:	mov    %r15,%rdi
  6b890b:	mov    %r12,%rsi
  6b890e:	jmp    6b896e <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x49e>
  6b8910:	mov    %rax,0x10(%rsp)
  6b8915:	mov    $0x8,%edx
  6b891a:	mov    %rbx,%rdi
  6b891d:	mov    %r15,%rsi
  6b8920:	call   *0x389932(%rip)        # a42258 <_DYNAMIC+0x268>
  6b8926:	xor    %ebx,%ebx
  6b8928:	jmp    6b89ca <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x4fa>
  6b892d:	mov    %rax,%r13
  6b8930:	mov    0x389921(%rip),%r12        # a42258 <_DYNAMIC+0x268>
  6b8937:	mov    $0x8,%edx
  6b893c:	mov    %rbx,%rdi
  6b893f:	mov    %rbp,%rsi
  6b8942:	call   *%r12
  6b8945:	shl    $0x3,%r14
  6b8949:	lea    (%r14,%r14,4),%rsi
  6b894d:	mov    $0x8,%edx
  6b8952:	mov    %r15,%rdi
  6b8955:	call   *%r12
  6b8958:	mov    %r13,%rdi
  6b895b:	call   a20740 <_Unwind_Resume@plt>
  6b8960:	mov    %rax,%r14
  6b8963:	mov    $0x8,%edx
  6b8968:	mov    %rbx,%rdi
  6b896b:	mov    %r13,%rsi
  6b896e:	call   *0x3898e4(%rip)        # a42258 <_DYNAMIC+0x268>
  6b8974:	jmp    6b89fc <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x52c>
  6b8979:	mov    %rax,0x10(%rsp)
  6b897e:	shl    $0x6,%r12
  6b8982:	add    %r12,%r13
  6b8985:	shl    $0x6,%r14
  6b8989:	sub    %rbx,%r14
  6b898c:	mov    %r13,%rdi
  6b898f:	mov    %rbp,%rsi
  6b8992:	mov    %r14,%rdx
  6b8995:	jmp    6b89b9 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x4e9>
  6b8997:	mov    %rax,0x10(%rsp)
  6b899c:	lea    (%r14,%r14,4),%rax
  6b89a0:	lea    0x0(,%rax,8),%rdi
  6b89a8:	add    %rbp,%rdi
  6b89ab:	shl    $0x3,%rbx
  6b89af:	lea    (%rbx,%rbx,4),%rdx
  6b89b3:	sub    %r13,%rdx
  6b89b6:	mov    %r12,%rsi
  6b89b9:	call   *0x3898e9(%rip)        # a422a8 <memmove@GLIBC_2.2.5>
  6b89bf:	jmp    6b89c8 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x4f8>
  6b89c1:	jmp    6b89c3 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x4f3>
  6b89c3:	mov    %rax,0x10(%rsp)
  6b89c8:	mov    $0x1,%bl
  6b89ca:	mov    0x8(%rsp),%rax
  6b89cf:	mov    (%rax),%rax
  6b89d2:	test   %rax,%rax
  6b89d5:	je     6b89f3 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x523>
  6b89d7:	mov    0x8(%rsp),%rcx
  6b89dc:	mov    0x8(%rcx),%rdi
  6b89e0:	shl    $0x3,%rax
  6b89e4:	lea    (%rax,%rax,4),%rsi
  6b89e8:	mov    $0x8,%edx
  6b89ed:	call   *0x389865(%rip)        # a42258 <_DYNAMIC+0x268>
  6b89f3:	test   %bl,%bl
  6b89f5:	mov    0x10(%rsp),%r14
  6b89fa:	je     6b8a37 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x567>
  6b89fc:	mov    0x8(%rsp),%rax
  6b8a01:	mov    0x18(%rax),%rsi
  6b8a05:	test   %rsi,%rsi
  6b8a08:	je     6b8a37 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x567>
  6b8a0a:	mov    0x8(%rsp),%rax
  6b8a0f:	mov    0x20(%rax),%rdi
  6b8a13:	shl    $0x6,%rsi
  6b8a17:	mov    $0x8,%edx
  6b8a1c:	call   *0x389836(%rip)        # a42258 <_DYNAMIC+0x268>
  6b8a22:	mov    %r14,%rdi
  6b8a25:	call   a20740 <_Unwind_Resume@plt>
  6b8a2a:	mov    %rax,%r14
  6b8a2d:	lea    0x28(%rsp),%rdi
  6b8a32:	call   6c7390 <core::ptr::drop_glue::<gpui::runtime::scroll::Columns>>
  6b8a37:	mov    %r14,%rdi
  6b8a3a:	call   a20740 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9} code=1503 fixed_stack=248

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006da920 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}>:
  6da920:	push   %rbp
  6da921:	push   %r15
  6da923:	push   %r14
  6da925:	push   %r13
  6da927:	push   %r12
  6da929:	push   %rbx
  6da92a:	sub    $0xc8,%rsp
  6da931:	mov    %rcx,%r14
  6da934:	mov    %rsi,%r15
  6da937:	mov    (%rcx),%ecx
  6da939:	mov    0x10(%r14),%ebx
  6da93d:	test   %ebx,%ebx
  6da93f:	je     6da963 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x43>
  6da941:	cmp    $0x1,%ebx
  6da944:	jne    6dab3a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x21a>
  6da94a:	movss  -0x69a956(%rip),%xmm0        # 3fffc <GCC_except_table0+0x258>
  6da952:	mov    %ebx,%ebp
  6da954:	movss  0x4(%r14),%xmm1
  6da95a:	movaps %xmm1,%xmm2
  6da95d:	test   %ecx,%ecx
  6da95f:	je     6da97b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x5b>
  6da961:	jmp    6da97e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x5e>
  6da963:	movss  0x14(%r14),%xmm0
  6da969:	mov    $0x1,%ebp
  6da96e:	movss  0x4(%r14),%xmm1
  6da974:	movaps %xmm1,%xmm2
  6da977:	test   %ecx,%ecx
  6da979:	jne    6da97e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x5e>
  6da97b:	movaps %xmm0,%xmm2
  6da97e:	mov    $0x1,%eax
  6da983:	cmovne %eax,%ebp
  6da986:	mov    (%r15),%rax
  6da989:	mov    0x10(%rax),%rsi
  6da98d:	test   %rsi,%rsi
  6da990:	je     6dae61 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x541>
  6da996:	mov    %ecx,0x1c(%rsp)
  6da99a:	mov    %rdi,0x10(%rsp)
  6da99f:	mov    0x8(%rax),%rax
  6da9a3:	mov    (%rdx),%rcx
  6da9a6:	cmp    $0x1,%rsi
  6da9aa:	jne    6daa71 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x151>
  6da9b0:	xor    %r12d,%r12d
  6da9b3:	mov    %r12,%rdi
  6da9b6:	shl    $0x4,%rdi
  6da9ba:	mov    (%rax,%rdi,1),%r8
  6da9be:	cmp    %rcx,%r8
  6da9c1:	seta   %sil
  6da9c5:	sbb    $0x0,%sil
  6da9c9:	cmp    %rcx,%r8
  6da9cc:	jne    6da9f3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0xd3>
  6da9ce:	add    %rdi,%rax
  6da9d1:	mov    0x8(%rax),%ecx
  6da9d4:	mov    0x8(%rdx),%edi
  6da9d7:	cmp    %edi,%ecx
  6da9d9:	seta   %sil
  6da9dd:	sbb    $0x0,%sil
  6da9e1:	cmp    %edi,%ecx
  6da9e3:	jne    6da9f3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0xd3>
  6da9e5:	mov    0xc(%rax),%eax
  6da9e8:	cmp    0xc(%rdx),%eax
  6da9eb:	seta   %sil
  6da9ef:	sbb    $0x0,%sil
  6da9f3:	test   %sil,%sil
  6da9f6:	jne    6dae66 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x546>
  6da9fc:	movss  %xmm2,0x8(%rsp)
  6daa02:	movss  %xmm1,0xc(%rsp)
  6daa08:	mov    0x8(%r15),%rax
  6daa0c:	mov    0x10(%rax),%rsi
  6daa10:	cmp    %rsi,%r12
  6daa13:	jae    6dae9c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x57c>
  6daa19:	mov    0x8(%rax),%rax
  6daa1d:	lea    (%r12,%r12,4),%rcx
  6daa21:	mov    0x20(%rax,%rcx,8),%r13d
  6daa26:	mov    %r13d,%edi
  6daa29:	call   *0x367a21(%rip)        # a42450 <_DYNAMIC+0x460>
  6daa2f:	cmp    $0x2,%dl
  6daa32:	jne    6daac9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x1a9>
  6daa38:	mov    0x18(%r15),%rdx
  6daa3c:	cmpq   $0x0,(%rdx)
  6daa40:	je     6dae15 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x4f5>
  6daa46:	mov    %r13d,%eax
  6daa49:	and    $0xf,%eax
  6daa4c:	cmp    $0x9,%eax
  6daa4f:	ja     6dae48 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x528>
  6daa55:	cmp    $0x6,%eax
  6daa58:	je     6daa64 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x144>
  6daa5a:	shr    $0x4,%r13d
  6daa5e:	jne    6dab69 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x249>
  6daa64:	lea    0x347965(%rip),%rdi        # a223d0 <__frame_dummy_init_array_entry+0x8e0>
  6daa6b:	call   *0x367887(%rip)        # a422f8 <_DYNAMIC+0x308>
  6daa71:	mov    0x8(%rdx),%edi
  6daa74:	mov    0xc(%rdx),%r8d
  6daa78:	xor    %r9d,%r9d
  6daa7b:	jmp    6daa97 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x177>
  6daa7d:	nopl   (%rax)
  6daa80:	test   %r13b,%r13b
  6daa83:	cmovne %r9,%r12
  6daa87:	sub    %r10,%rsi
  6daa8a:	mov    %r12,%r9
  6daa8d:	cmp    $0x1,%rsi
  6daa91:	jbe    6da9b3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x93>
  6daa97:	mov    %rsi,%r10
  6daa9a:	shr    $1,%r10
  6daa9d:	lea    (%r10,%r9,1),%r12
  6daaa1:	mov    %r12,%r11
  6daaa4:	shl    $0x4,%r11
  6daaa8:	cmp    %rcx,(%rax,%r11,1)
  6daaac:	seta   %r13b
  6daab0:	jne    6daa80 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x160>
  6daab2:	add    %rax,%r11
  6daab5:	cmp    %edi,0x8(%r11)
  6daab9:	seta   %r13b
  6daabd:	jne    6daa80 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x160>
  6daabf:	cmp    %r8d,0xc(%r11)
  6daac3:	seta   %r13b
  6daac7:	jmp    6daa80 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x160>
  6daac9:	mov    0x10(%r15),%rcx
  6daacd:	mov    (%rcx),%rcx
  6daad0:	test   %rcx,%rcx
  6daad3:	je     6dae2e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x50e>
  6daad9:	mov    %eax,%edi
  6daadb:	mov    0x10(%rcx),%rsi
  6daadf:	cmp    %rdi,%rsi
  6daae2:	jbe    6daeac <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x58c>
  6daae8:	mov    0x8(%rcx),%rax
  6daaec:	mov    (%rax,%rdi,8),%rax
  6daaf0:	mov    0x30(%rax),%ecx
  6daaf3:	mov    0x34(%rax),%eax
  6daaf6:	xorps  %xmm0,%xmm0
  6daaf9:	cvtsi2ss %rcx,%xmm0
  6daafe:	xorps  %xmm1,%xmm1
  6dab01:	cvtsi2ss %rax,%xmm1
  6dab06:	movaps %xmm0,%xmm2
  6dab09:	divss  %xmm1,%xmm2
  6dab0d:	movzbl 0x8(%r14),%ecx
  6dab12:	movss  0xc(%r14),%xmm3
  6dab18:	cmpb   $0x0,0x1c(%rsp)
  6dab1d:	mov    0x10(%rsp),%rax
  6dab22:	je     6dab52 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x232>
  6dab24:	test   %cl,%cl
  6dab26:	je     6dabfc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x2dc>
  6dab2c:	movss  0xc(%rsp),%xmm0
  6dab32:	movaps %xmm3,%xmm1
  6dab35:	jmp    6dac09 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x2e9>
  6dab3a:	xor    %ebp,%ebp
  6dab3c:	movss  0x4(%r14),%xmm1
  6dab42:	movaps %xmm1,%xmm2
  6dab45:	test   %ecx,%ecx
  6dab47:	je     6da97b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x5b>
  6dab4d:	jmp    6da97e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x5e>
  6dab52:	test   %cl,%cl
  6dab54:	je     6dac09 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x2e9>
  6dab5a:	mulss  %xmm3,%xmm2
  6dab5e:	movaps %xmm2,%xmm0
  6dab61:	movaps %xmm3,%xmm1
  6dab64:	jmp    6dac09 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x2e9>
  6dab69:	mov    0x20(%r15),%rax
  6dab6d:	mov    0x10(%rax),%rsi
  6dab71:	dec    %r13d
  6dab74:	cmp    %r13,%rsi
  6dab77:	jbe    6daeb9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x599>
  6dab7d:	mov    0x8(%rax),%rsi
  6dab81:	lea    0x0(%r13,%r13,4),%r13
  6dab86:	shl    $0x4,%r13
  6dab8a:	cmpq   $0xfffffffffffffffe,(%rsi,%r13,1)
  6dab8f:	je     6dae3b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x51b>
  6dab95:	mov    0x28(%r15),%rcx
  6dab99:	mov    (%rcx),%rax
  6dab9c:	lea    -0x699113(%rip),%rdi        # 41a90 <GCC_except_table0+0x1cec>
  6daba3:	movslq (%rdi,%rax,4),%rax
  6daba7:	add    %rdi,%rax
  6dabaa:	jmp    *%rax
  6dabac:	movups -0x68da43(%rip),%xmm0        # 4d170 <GCC_except_table0+0xd3cc>
  6dabb3:	movaps %xmm0,0x60(%rsp)
  6dabb8:	movups -0x68da5f(%rip),%xmm0        # 4d160 <GCC_except_table0+0xd3bc>
  6dabbf:	movaps %xmm0,0x50(%rsp)
  6dabc4:	movups -0x68da7b(%rip),%xmm0        # 4d150 <GCC_except_table0+0xd3ac>
  6dabcb:	movaps %xmm0,0x40(%rsp)
  6dabd0:	movups -0x68da97(%rip),%xmm0        # 4d140 <GCC_except_table0+0xd39c>
  6dabd7:	movaps %xmm0,0x30(%rsp)
  6dabdc:	movups -0x68dab3(%rip),%xmm0        # 4d130 <GCC_except_table0+0xd38c>
  6dabe3:	movaps %xmm0,0x20(%rsp)
  6dabe8:	movabs $0x3000100000000,%rax
  6dabf2:	mov    %rax,0x70(%rsp)
  6dabf7:	jmp    6dacd2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x3b2>
  6dabfc:	movss  0xc(%rsp),%xmm0
  6dac02:	movaps %xmm0,%xmm1
  6dac05:	divss  %xmm2,%xmm1
  6dac09:	movss  %xmm0,0x10(%rax)
  6dac0e:	movss  %xmm1,0x14(%rax)
  6dac13:	xorps  %xmm0,%xmm0
  6dac16:	movups %xmm0,(%rax)
  6dac19:	jmp    6dae03 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x4e3>
  6dac1e:	mov    0x20(%rcx),%rax
  6dac22:	cmp    %rax,%r12
  6dac25:	jae    6daec9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x5a9>
  6dac2b:	mov    0x10(%rcx),%rax
  6dac2f:	mov    0x18(%rcx),%rdi
  6dac33:	movzbl (%rdi,%r12,1),%edi
  6dac38:	cmp    %rdi,%rax
  6dac3b:	jbe    6daeef <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x5cf>
  6dac41:	mov    0x8(%rcx),%rax
  6dac45:	imul   $0x58,%rdi,%rcx
  6dac49:	jmp    6dac97 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x377>
  6dac4b:	mov    0x8(%rcx),%rax
  6dac4f:	lea    0x20(%rsp),%rdi
  6dac54:	mov    %rsi,0x88(%rsp)
  6dac5c:	mov    %rax,%rsi
  6dac5f:	mov    %rdx,0x80(%rsp)
  6dac67:	mov    %r12,%rdx
  6dac6a:	call   *0x367778(%rip)        # a423e8 <_DYNAMIC+0x3f8>
  6dac70:	mov    0x88(%rsp),%rsi
  6dac78:	mov    0x80(%rsp),%rdx
  6dac80:	jmp    6dacd2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x3b2>
  6dac82:	mov    0x18(%rcx),%rax
  6dac86:	cmp    %rax,%r12
  6dac89:	jae    6daedc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x5bc>
  6dac8f:	mov    0x10(%rcx),%rax
  6dac93:	imul   $0x58,%r12,%rcx
  6dac97:	mov    0x50(%rax,%rcx,1),%rdi
  6dac9c:	mov    %rdi,0x70(%rsp)
  6daca1:	movups 0x40(%rax,%rcx,1),%xmm0
  6daca6:	movaps %xmm0,0x60(%rsp)
  6dacab:	movups (%rax,%rcx,1),%xmm0
  6dacaf:	movups 0x10(%rax,%rcx,1),%xmm1
  6dacb4:	movups 0x20(%rax,%rcx,1),%xmm2
  6dacb9:	movups 0x30(%rax,%rcx,1),%xmm3
  6dacbe:	movaps %xmm3,0x50(%rsp)
  6dacc3:	movaps %xmm2,0x40(%rsp)
  6dacc8:	movaps %xmm1,0x30(%rsp)
  6daccd:	movaps %xmm0,0x20(%rsp)
  6dacd2:	mov    0x10(%rsp),%r12
  6dacd7:	movss  0x8(%rsp),%xmm1
  6dacdd:	add    %r13,%rsi
  6dace0:	movss  0x38(%rsp),%xmm0
  6dace6:	test   %ebx,%ebx
  6dace8:	sete   %al
  6daceb:	mov    0x1c(%rsp),%ebx
  6dacef:	or     %bl,%al
  6dacf1:	movzbl %al,%r8d
  6dacf5:	lea    0x90(%rsp),%rdi
  6dacfd:	mov    %ebp,%ecx
  6dacff:	call   *0x367753(%rip)        # a42458 <_DYNAMIC+0x468>
  6dad05:	cmpl   $0xfffffffe,0x90(%rsp)
  6dad0d:	jne    6dad72 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x452>
  6dad0f:	mov    0x98(%rsp),%rax
  6dad17:	movss  0x30(%rax),%xmm0
  6dad1c:	test   %bl,%bl
  6dad1e:	movss  0xc(%rsp),%xmm2
  6dad24:	jne    6dad2b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x40b>
  6dad26:	movss  0x28(%rax),%xmm2
  6dad2b:	add    $0x2c,%rax
  6dad2f:	lea    0xc(%r14),%rcx
  6dad33:	cmpb   $0x0,0x8(%r14)
  6dad38:	cmove  %rax,%rcx
  6dad3c:	movss  (%rcx),%xmm1
  6dad40:	movss  %xmm2,0x10(%r12)
  6dad47:	movss  %xmm1,0x14(%r12)
  6dad4e:	movl   $0x1,(%r12)
  6dad56:	movss  %xmm0,0x4(%r12)
  6dad5d:	movl   $0x1,0x8(%r12)
  6dad66:	movss  %xmm0,0xc(%r12)
  6dad6d:	jmp    6dae00 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x4e0>
  6dad72:	mov    0x30(%r15),%rbx
  6dad76:	mov    (%rbx),%rax
  6dad79:	cmp    $0xfffffffffffffffe,%rax
  6dad7d:	je     6dadc0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x4a0>
  6dad7f:	sub    $0xd,%rax
  6dad83:	mov    $0x14,%ecx
  6dad88:	cmovge %rax,%rcx
  6dad8c:	cmp    $0x14,%rcx
  6dad90:	je     6dada3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x483>
  6dad92:	cmp    $0x19,%rcx
  6dad96:	jne    6dadc0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x4a0>
  6dad98:	mov    0x8(%rbx),%rsi
  6dad9c:	mov    $0x10,%eax
  6dada1:	jmp    6dadac <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x48c>
  6dada3:	mov    0x18(%rbx),%rsi
  6dada7:	mov    $0x20,%eax
  6dadac:	test   %rsi,%rsi
  6dadaf:	je     6dadc0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x4a0>
  6dadb1:	mov    (%rbx,%rax,1),%rdi
  6dadb5:	mov    $0x1,%edx
  6dadba:	call   *0x367498(%rip)        # a42258 <_DYNAMIC+0x268>
  6dadc0:	mov    0xc0(%rsp),%rax
  6dadc8:	mov    %rax,0x30(%rbx)
  6dadcc:	movups 0x90(%rsp),%xmm0
  6dadd4:	movups 0xa0(%rsp),%xmm1
  6daddc:	movups 0xb0(%rsp),%xmm2
  6dade4:	movups %xmm2,0x20(%rbx)
  6dade8:	movups %xmm1,0x10(%rbx)
  6dadec:	movups %xmm0,(%rbx)
  6dadef:	xorps  %xmm0,%xmm0
  6dadf2:	movups %xmm0,(%r12)
  6dadf7:	movq   $0x0,0x10(%r12)
  6dae00:	mov    %r12,%rax
  6dae03:	add    $0xc8,%rsp
  6dae0a:	pop    %rbx
  6dae0b:	pop    %r12
  6dae0d:	pop    %r13
  6dae0f:	pop    %r14
  6dae11:	pop    %r15
  6dae13:	pop    %rbp
  6dae14:	ret
  6dae15:	lea    -0x68d9f2(%rip),%rdi        # 4d42a <GCC_except_table0+0xd686>
  6dae1c:	lea    0x347595(%rip),%rdx        # a223b8 <__frame_dummy_init_array_entry+0x8c8>
  6dae23:	mov    $0x28,%esi
  6dae28:	call   *0x3675ca(%rip)        # a423f8 <_DYNAMIC+0x408>
  6dae2e:	lea    0x347553(%rip),%rdi        # a22388 <__frame_dummy_init_array_entry+0x898>
  6dae35:	call   *0x3674bd(%rip)        # a422f8 <_DYNAMIC+0x308>
  6dae3b:	lea    0x34749e(%rip),%rdi        # a222e0 <__frame_dummy_init_array_entry+0x7f0>
  6dae42:	call   *0x3674b0(%rip)        # a422f8 <_DYNAMIC+0x308>
  6dae48:	lea    -0x68abed(%rip),%rdi        # 50262 <GCC_except_table0+0x104be>
  6dae4f:	lea    0x34879a(%rip),%rdx        # a235f0 <__frame_dummy_init_array_entry+0x1b00>
  6dae56:	mov    $0x83,%esi
  6dae5b:	call   *0x36742f(%rip)        # a42290 <_DYNAMIC+0x2a0>
  6dae61:	xor    %r12d,%r12d
  6dae64:	jmp    6dae72 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x552>
  6dae66:	xor    %eax,%eax
  6dae68:	cmp    $0xff,%sil
  6dae6c:	sete   %al
  6dae6f:	add    %rax,%r12
  6dae72:	mov    %r12,0x20(%rsp)
  6dae77:	lea    -0x68da88(%rip),%rdi        # 4d3f6 <GCC_except_table0+0xd652>
  6dae7e:	lea    0x347f63(%rip),%rcx        # a22de8 <__frame_dummy_init_array_entry+0x12f8>
  6dae85:	lea    0x3474cc(%rip),%r8        # a22358 <__frame_dummy_init_array_entry+0x868>
  6dae8c:	lea    0x20(%rsp),%rdx
  6dae91:	mov    $0x34,%esi
  6dae96:	call   *0x367394(%rip)        # a42230 <_DYNAMIC+0x240>
  6dae9c:	lea    0x3474cd(%rip),%rdx        # a22370 <__frame_dummy_init_array_entry+0x880>
  6daea3:	mov    %r12,%rdi
  6daea6:	call   *0x3673dc(%rip)        # a42288 <_DYNAMIC+0x298>
  6daeac:	lea    0x3474ed(%rip),%rdx        # a223a0 <__frame_dummy_init_array_entry+0x8b0>
  6daeb3:	call   *0x3673cf(%rip)        # a42288 <_DYNAMIC+0x298>
  6daeb9:	lea    0x347408(%rip),%rdx        # a222c8 <__frame_dummy_init_array_entry+0x7d8>
  6daec0:	mov    %r13,%rdi
  6daec3:	call   *0x3673bf(%rip)        # a42288 <_DYNAMIC+0x298>
  6daec9:	lea    0x348030(%rip),%rdx        # a22f00 <__frame_dummy_init_array_entry+0x1410>
  6daed0:	mov    %r12,%rdi
  6daed3:	mov    %rax,%rsi
  6daed6:	call   *0x3673ac(%rip)        # a42288 <_DYNAMIC+0x298>
  6daedc:	lea    0x348005(%rip),%rdx        # a22ee8 <__frame_dummy_init_array_entry+0x13f8>
  6daee3:	mov    %r12,%rdi
  6daee6:	mov    %rax,%rsi
  6daee9:	call   *0x367399(%rip)        # a42288 <_DYNAMIC+0x298>
  6daeef:	lea    0x348022(%rip),%rdx        # a22f18 <__frame_dummy_init_array_entry+0x1428>
  6daef6:	mov    %rax,%rsi
  6daef9:	call   *0x367389(%rip)        # a42288 <_DYNAMIC+0x298>

<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39} code=415 fixed_stack=8

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006daf00 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>:
  6daf00:	push   %rax
  6daf01:	mov    (%rdi),%rdx
  6daf04:	mov    (%rdx),%rax
  6daf07:	test   %rax,%rax
  6daf0a:	je     6daf56 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x56>
  6daf0c:	cmp    $0x1,%eax
  6daf0f:	jne    6daf72 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x72>
  6daf11:	mov    0x8(%rdx),%rcx
  6daf15:	mov    0x10(%rdx),%rdx
  6daf19:	cmp    $0x1,%rdx
  6daf1d:	je     6dafc8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0xc8>
  6daf23:	test   %rdx,%rdx
  6daf26:	je     6db070 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x170>
  6daf2c:	xor    %eax,%eax
  6daf2e:	xchg   %ax,%ax
  6daf30:	mov    %rax,%r8
  6daf33:	mov    %rdx,%r9
  6daf36:	shr    $1,%r9
  6daf39:	add    %r9,%rax
  6daf3c:	mov    %rax,%r10
  6daf3f:	shl    $0x4,%r10
  6daf43:	cmp    %rsi,(%rcx,%r10,1)
  6daf47:	cmova  %r8,%rax
  6daf4b:	sub    %r9,%rdx
  6daf4e:	cmp    $0x1,%rdx
  6daf52:	ja     6daf30 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x30>
  6daf54:	jmp    6dafca <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0xca>
  6daf56:	mov    %rsi,%rax
  6daf59:	sub    0x8(%rdx),%rax
  6daf5d:	jb     6db070 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x170>
  6daf63:	cmp    0x10(%rdx),%rax
  6daf67:	jb     6db002 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x102>
  6daf6d:	jmp    6db070 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x170>
  6daf72:	mov    0x8(%rdx),%rax
  6daf76:	mov    0x10(%rdx),%rcx
  6daf7a:	cmp    $0x1,%rcx
  6daf7e:	je     6db048 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x148>
  6daf84:	test   %rcx,%rcx
  6daf87:	je     6db070 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x170>
  6daf8d:	xor    %edx,%edx
  6daf8f:	nop
  6daf90:	mov    %rdx,%r8
  6daf93:	mov    %rcx,%r9
  6daf96:	shr    $1,%r9
  6daf99:	add    %r9,%rdx
  6daf9c:	lea    (%rdx,%rdx,2),%r10
  6dafa0:	cmp    %rsi,(%rax,%r10,4)
  6dafa4:	cmova  %r8,%rdx
  6dafa8:	sub    %r9,%rcx
  6dafab:	cmp    $0x1,%rcx
  6dafaf:	ja     6daf90 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x90>
  6dafb1:	lea    (%rdx,%rdx,2),%rcx
  6dafb5:	cmp    %rsi,(%rax,%rcx,4)
  6dafb9:	jne    6db070 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x170>
  6dafbf:	lea    (%rax,%rcx,4),%rax
  6dafc3:	jmp    6db04d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x14d>
  6dafc8:	xor    %eax,%eax
  6dafca:	mov    %rax,%r8
  6dafcd:	shl    $0x4,%r8
  6dafd1:	xor    %edx,%edx
  6dafd3:	cmp    %rsi,(%rcx,%r8,1)
  6dafd7:	setbe  %dl
  6dafda:	add    %rax,%rdx
  6dafdd:	je     6db070 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x170>
  6dafe3:	shl    $0x4,%rdx
  6dafe7:	mov    %rsi,%rax
  6dafea:	sub    -0x10(%rcx,%rdx,1),%rax
  6dafef:	mov    -0x4(%rcx,%rdx,1),%r8d
  6daff4:	cmp    %r8,%rax
  6daff7:	jae    6db070 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x170>
  6daff9:	add    %rdx,%rcx
  6daffc:	mov    -0x8(%rcx),%ecx
  6dafff:	add    %rcx,%rax
  6db002:	mov    0x8(%rdi),%rdx
  6db006:	mov    0x10(%rdx),%rcx
  6db00a:	cmp    %rcx,%rax
  6db00d:	jae    6db05d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x15d>
  6db00f:	mov    0x8(%rdx),%rcx
  6db013:	mov    (%rcx,%rax,4),%edx
  6db016:	mov    $0xffffffff,%eax
  6db01b:	cmp    %rax,%rdx
  6db01e:	je     6db044 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x144>
  6db020:	mov    0x10(%rdi),%rcx
  6db024:	mov    0x10(%rcx),%rax
  6db028:	cmp    %rdx,%rax
  6db02b:	jbe    6db089 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x189>
  6db02d:	mov    0x8(%rcx),%rcx
  6db031:	mov    %rdx,%rdi
  6db034:	shl    $0x6,%rdi
  6db038:	xor    %eax,%eax
  6db03a:	cmp    %rsi,0x20(%rcx,%rdi,1)
  6db03f:	sete   %al
  6db042:	pop    %rcx
  6db043:	ret
  6db044:	xor    %eax,%eax
  6db046:	pop    %rcx
  6db047:	ret
  6db048:	cmp    %rsi,(%rax)
  6db04b:	jne    6db070 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x170>
  6db04d:	mov    0x8(%rax),%eax
  6db050:	mov    0x8(%rdi),%rdx
  6db054:	mov    0x10(%rdx),%rcx
  6db058:	cmp    %rcx,%rax
  6db05b:	jb     6db00f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x10f>
  6db05d:	lea    0x347384(%rip),%rdx        # a223e8 <__frame_dummy_init_array_entry+0x8f8>
  6db064:	mov    %rax,%rdi
  6db067:	mov    %rcx,%rsi
  6db06a:	call   *0x367218(%rip)        # a42288 <_DYNAMIC+0x298>
  6db070:	lea    -0x68dcd9(%rip),%rdi        # 4d39e <GCC_except_table0+0xd5fa>
  6db077:	lea    0x346f32(%rip),%rdx        # a21fb0 <__frame_dummy_init_array_entry+0x4c0>
  6db07e:	mov    $0x15,%esi
  6db083:	call   *0x36736f(%rip)        # a423f8 <_DYNAMIC+0x408>
  6db089:	lea    0x3470b8(%rip),%rcx        # a22148 <__frame_dummy_init_array_entry+0x658>
  6db090:	mov    %rdx,%rdi
  6db093:	mov    %rax,%rsi
  6db096:	mov    %rcx,%rdx
  6db099:	call   *0x3671e9(%rip)        # a42288 <_DYNAMIC+0x298>

<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13} code=130 fixed_stack=8

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006db0a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}>:
  6db0a0:	push   %rax
  6db0a1:	cmp    %rsi,%rdx
  6db0a4:	jae    6db10f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}+0x6f>
  6db0a6:	lea    (%rdx,%rdx,4),%rax
  6db0aa:	mov    0x20(%rdi,%rax,8),%eax
  6db0ae:	and    $0xf,%eax
  6db0b1:	cmp    $0x9,%eax
  6db0b4:	ja     6db0f6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}+0x56>
  6db0b6:	lea    -0x69961d(%rip),%rcx        # 41aa0 <GCC_except_table0+0x1cfc>
  6db0bd:	movslq (%rcx,%rax,4),%rax
  6db0c1:	add    %rcx,%rax
  6db0c4:	jmp    *%rax
  6db0c6:	mov    $0x8,%al
  6db0c8:	jmp    6db0e8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}+0x48>
  6db0ca:	mov    $0x4,%al
  6db0cc:	jmp    6db0e8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}+0x48>
  6db0ce:	mov    $0x2,%al
  6db0d0:	jmp    6db0e8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}+0x48>
  6db0d2:	mov    $0x3,%al
  6db0d4:	jmp    6db0e8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}+0x48>
  6db0d6:	mov    $0x7,%al
  6db0d8:	jmp    6db0e8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}+0x48>
  6db0da:	xor    %eax,%eax
  6db0dc:	jmp    6db0e8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}+0x48>
  6db0de:	mov    $0x1,%al
  6db0e0:	jmp    6db0e8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}+0x48>
  6db0e2:	mov    $0x5,%al
  6db0e4:	jmp    6db0e8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}+0x48>
  6db0e6:	mov    $0x6,%al
  6db0e8:	cmp    $0x4,%al
  6db0ea:	sete   %cl
  6db0ed:	cmp    $0x7,%al
  6db0ef:	sete   %al
  6db0f2:	or     %cl,%al
  6db0f4:	pop    %rcx
  6db0f5:	ret
  6db0f6:	lea    -0x68ae9b(%rip),%rdi        # 50262 <GCC_except_table0+0x104be>
  6db0fd:	lea    0x3484ec(%rip),%rdx        # a235f0 <__frame_dummy_init_array_entry+0x1b00>
  6db104:	mov    $0x83,%esi
  6db109:	call   *0x367181(%rip)        # a42290 <_DYNAMIC+0x2a0>
  6db10f:	lea    0x3472ea(%rip),%rax        # a22400 <__frame_dummy_init_array_entry+0x910>
  6db116:	mov    %rdx,%rdi
  6db119:	mov    %rax,%rdx
  6db11c:	call   *0x367166(%rip)        # a42288 <_DYNAMIC+0x298>

<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#23} code=143 fixed_stack=24

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006db130 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#23}>:
  6db130:	push   %r14
  6db132:	push   %rbx
  6db133:	push   %rax
  6db134:	mov    %rdx,%rbx
  6db137:	and    $0xf,%esi
  6db13a:	cmp    $0x7,%esi
  6db13d:	jb     6db147 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#23}+0x17>
  6db13f:	lea    -0x8(%rsi),%eax
  6db142:	cmp    $0x2,%eax
  6db145:	jae    6db16d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#23}+0x3d>
  6db147:	mov    0x30(%rbx),%rax
  6db14b:	mov    %rax,0x30(%rdi)
  6db14f:	movups (%rbx),%xmm0
  6db152:	movups 0x10(%rbx),%xmm1
  6db156:	movups 0x20(%rbx),%xmm2
  6db15a:	movups %xmm2,0x20(%rdi)
  6db15e:	movups %xmm1,0x10(%rdi)
  6db162:	movups %xmm0,(%rdi)
  6db165:	add    $0x8,%rsp
  6db169:	pop    %rbx
  6db16a:	pop    %r14
  6db16c:	ret
  6db16d:	cmp    $0x7,%esi
  6db170:	jne    6db191 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#23}+0x61>
  6db172:	cmpl   $0x27,(%rbx)
  6db175:	jne    6db147 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#23}+0x17>
  6db177:	cmpq   $0xb,0x8(%rbx)
  6db17c:	jne    6db147 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#23}+0x17>
  6db17e:	movb   $0x5,0x8(%rdi)
  6db182:	movq   $0x28,(%rdi)
  6db189:	add    $0x8,%rsp
  6db18d:	pop    %rbx
  6db18e:	pop    %r14
  6db190:	ret
  6db191:	lea    -0x68af36(%rip),%rdi        # 50262 <GCC_except_table0+0x104be>
  6db198:	lea    0x348451(%rip),%rdx        # a235f0 <__frame_dummy_init_array_entry+0x1b00>
  6db19f:	mov    $0x83,%esi
  6db1a4:	call   *0x3670e6(%rip)        # a42290 <_DYNAMIC+0x2a0>
  6db1aa:	ud2
  6db1ac:	mov    %rax,%r14
  6db1af:	mov    %rbx,%rdi
  6db1b2:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6db1b7:	mov    %r14,%rdi
  6db1ba:	call   a20740 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#24} code=61 fixed_stack=72

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006db1c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#24}>:
  6db1c0:	sub    $0x48,%rsp
  6db1c4:	cvtps2pd (%rdx),%xmm0
  6db1c7:	cvtps2pd 0x8(%rdx),%xmm1
  6db1cb:	movaps %xmm0,0x10(%rsp)
  6db1d0:	movaps %xmm1,0x20(%rsp)
  6db1d5:	cvtps2pd 0x10(%rdx),%xmm0
  6db1d9:	movaps %xmm0,0x30(%rsp)
  6db1de:	movb   $0x0,0x40(%rsp)
  6db1e3:	movups (%rsi),%xmm0
  6db1e6:	movaps %xmm0,(%rsp)
  6db1ea:	lea    0x10(%rsp),%rsi
  6db1ef:	mov    %rsp,%rdx
  6db1f2:	call   *0x367268(%rip)        # a42460 <_DYNAMIC+0x470>
  6db1f8:	add    $0x48,%rsp
  6db1fc:	ret

<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36} code=884 fixed_stack=136

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006db200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}>:
  6db200:	push   %rbp
  6db201:	push   %r15
  6db203:	push   %r14
  6db205:	push   %r13
  6db207:	push   %r12
  6db209:	push   %rbx
  6db20a:	sub    $0x58,%rsp
  6db20e:	mov    (%rsi),%rax
  6db211:	mov    0x10(%rax),%rcx
  6db215:	mov    %rcx,0x10(%rsp)
  6db21a:	movups (%rax),%xmm0
  6db21d:	movaps %xmm0,(%rsp)
  6db221:	movq   $0x0,(%rax)
  6db228:	movq   $0x4,0x8(%rax)
  6db230:	movq   $0x0,0x10(%rax)
  6db238:	mov    0x8(%rsi),%r13
  6db23c:	mov    0x10(%rsi),%rbp
  6db240:	mov    0x18(%rsi),%rax
  6db244:	mov    %rax,0x30(%rsp)
  6db249:	mov    0x20(%rsi),%rax
  6db24d:	mov    %rax,0x28(%rsp)
  6db252:	mov    0x8(%rdx),%r12
  6db256:	mov    0x10(%rdx),%rbx
  6db25a:	mov    (%rsp),%r15
  6db25e:	mov    0x10(%rsp),%rsi
  6db263:	mov    %r15,%rax
  6db266:	sub    %rsi,%rax
  6db269:	cmp    %rax,%rbx
  6db26c:	mov    %rdi,0x38(%rsp)
  6db271:	ja     6db4de <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x2de>
  6db277:	test   %rbx,%rbx
  6db27a:	je     6db4ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x2ba>
  6db280:	shl    $0x4,%rbx
  6db284:	add    %r12,%rbx
  6db287:	mov    %rsp,%rdi
  6db28a:	jmp    6db2c9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc9>
  6db28c:	mov    0x8(%rsp),%rax
  6db291:	mov    %rsi,%rcx
  6db294:	shl    $0x4,%rcx
  6db298:	movl   $0x7fc00000,(%rax,%rcx,1)
  6db29f:	mov    %r15d,0x4(%rax,%rcx,1)
  6db2a4:	mov    %r14,0x8(%rax,%rcx,1)
  6db2a9:	inc    %rsi
  6db2ac:	mov    %rsi,0x10(%rsp)
  6db2b1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6db2c0:	cmp    %rbx,%r12
  6db2c3:	je     6db4ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x2ba>
  6db2c9:	mov    %r12,%rax
  6db2cc:	add    $0x10,%r12
  6db2d0:	mov    0x8(%rax),%r15d
  6db2d4:	test   %r15d,%r15d
  6db2d7:	je     6db2c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db2d9:	mov    (%rax),%r14
  6db2dc:	cmpb   $0x1,0x0(%r13)
  6db2e1:	jne    6db437 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x237>
  6db2e7:	mov    0x0(%rbp),%rax
  6db2eb:	test   %rax,%rax
  6db2ee:	je     6db3a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x1a0>
  6db2f4:	cmp    $0x1,%eax
  6db2f7:	jne    6db3c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x1c0>
  6db2fd:	mov    0x10(%rbp),%rcx
  6db301:	test   %rcx,%rcx
  6db304:	je     6db2c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db306:	mov    0x8(%rbp),%rax
  6db30a:	xor    %edx,%edx
  6db30c:	cmp    $0x1,%rcx
  6db310:	je     6db344 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x144>
  6db312:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6db320:	mov    %rdx,%r9
  6db323:	mov    %rcx,%r10
  6db326:	shr    $1,%r10
  6db329:	add    %r10,%rdx
  6db32c:	mov    %rdx,%r8
  6db32f:	shl    $0x4,%r8
  6db333:	cmp    %r14,(%rax,%r8,1)
  6db337:	cmova  %r9,%rdx
  6db33b:	sub    %r10,%rcx
  6db33e:	cmp    $0x1,%rcx
  6db342:	ja     6db320 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x120>
  6db344:	mov    %rdx,%rcx
  6db347:	shl    $0x4,%rcx
  6db34b:	xor    %r8d,%r8d
  6db34e:	cmp    %r14,(%rax,%rcx,1)
  6db352:	setbe  %r8b
  6db356:	add    %rdx,%r8
  6db359:	je     6db2c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db35f:	shl    $0x4,%r8
  6db363:	mov    %r14,%rcx
  6db366:	sub    -0x10(%rax,%r8,1),%rcx
  6db36b:	mov    -0x4(%rax,%r8,1),%edx
  6db370:	cmp    %rdx,%rcx
  6db373:	jae    6db2c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db379:	add    %r8,%rax
  6db37c:	mov    -0x8(%rax),%eax
  6db37f:	add    %rax,%rcx
  6db382:	mov    0x30(%rsp),%rax
  6db387:	cmp    0x10(%rax),%rcx
  6db38b:	jae    6db2c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db391:	jmp    6db3f6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x1f6>
  6db393:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6db3a0:	mov    %r14,%rcx
  6db3a3:	sub    0x8(%rbp),%rcx
  6db3a7:	jb     6db2c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db3ad:	cmp    0x10(%rbp),%rcx
  6db3b1:	jae    6db2c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db3b7:	jmp    6db3e7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x1e7>
  6db3b9:	nopl   0x0(%rax)
  6db3c0:	mov    0x10(%rbp),%rcx
  6db3c4:	test   %rcx,%rcx
  6db3c7:	je     6db2c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db3cd:	mov    0x8(%rbp),%rax
  6db3d1:	cmp    $0x1,%rcx
  6db3d5:	jne    6db468 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x268>
  6db3db:	cmp    %r14,(%rax)
  6db3de:	jne    6db2c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db3e4:	mov    0x8(%rax),%ecx
  6db3e7:	mov    0x30(%rsp),%rax
  6db3ec:	cmp    0x10(%rax),%rcx
  6db3f0:	jae    6db2c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db3f6:	mov    0x30(%rsp),%rax
  6db3fb:	mov    0x8(%rax),%rax
  6db3ff:	mov    (%rax,%rcx,4),%eax
  6db402:	mov    $0xffffffff,%ecx
  6db407:	cmp    %rcx,%rax
  6db40a:	je     6db2c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db410:	mov    0x28(%rsp),%rcx
  6db415:	cmp    %rax,0x10(%rcx)
  6db419:	jbe    6db2c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db41f:	mov    0x28(%rsp),%rcx
  6db424:	mov    0x8(%rcx),%rcx
  6db428:	shl    $0x6,%rax
  6db42c:	cmp    %r14,0x20(%rcx,%rax,1)
  6db431:	jne    6db2c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db437:	cmp    (%rsp),%rsi
  6db43b:	jne    6db28c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x8c>
  6db441:	mov    $0x1,%edx
  6db446:	mov    $0x4,%ecx
  6db44b:	mov    $0x10,%r8d
  6db451:	mov    %rsi,0x20(%rsp)
  6db456:	call   6d91d0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  6db45b:	mov    %rsp,%rdi
  6db45e:	mov    0x20(%rsp),%rsi
  6db463:	jmp    6db28c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x8c>
  6db468:	xor    %edx,%edx
  6db46a:	nopw   0x0(%rax,%rax,1)
  6db470:	mov    %rdx,%r9
  6db473:	mov    %rcx,%r10
  6db476:	shr    $1,%r10
  6db479:	add    %r10,%rdx
  6db47c:	lea    (%rdx,%rdx,2),%r8
  6db480:	cmp    %r14,(%rax,%r8,4)
  6db484:	cmova  %r9,%rdx
  6db488:	sub    %r10,%rcx
  6db48b:	cmp    $0x1,%rcx
  6db48f:	ja     6db470 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x270>
  6db491:	lea    (%rdx,%rdx,2),%rcx
  6db495:	cmp    %r14,(%rax,%rcx,4)
  6db499:	jne    6db2c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db49f:	lea    (%rax,%rcx,4),%rax
  6db4a3:	mov    0x8(%rax),%ecx
  6db4a6:	mov    0x30(%rsp),%rax
  6db4ab:	cmp    0x10(%rax),%rcx
  6db4af:	jae    6db2c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db4b5:	jmp    6db3f6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x1f6>
  6db4ba:	mov    0x10(%rsp),%rax
  6db4bf:	mov    0x38(%rsp),%rcx
  6db4c4:	mov    %rax,0x10(%rcx)
  6db4c8:	movaps (%rsp),%xmm0
  6db4cc:	movups %xmm0,(%rcx)
  6db4cf:	add    $0x58,%rsp
  6db4d3:	pop    %rbx
  6db4d4:	pop    %r12
  6db4d6:	pop    %r13
  6db4d8:	pop    %r14
  6db4da:	pop    %r15
  6db4dc:	pop    %rbp
  6db4dd:	ret
  6db4de:	mov    %rsi,0x20(%rsp)
  6db4e3:	mov    %rsi,%rax
  6db4e6:	add    %rbx,%rax
  6db4e9:	jb     6db52e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x32e>
  6db4eb:	mov    0x8(%rsp),%rdx
  6db4f0:	lea    0x40(%rsp),%rdi
  6db4f5:	mov    $0x4,%r8d
  6db4fb:	mov    $0x10,%r9d
  6db501:	mov    %r15,%rsi
  6db504:	mov    %rax,%r14
  6db507:	mov    %rax,%rcx
  6db50a:	call   6f4a50 <<alloc::raw_vec::RawVecInner>::finish_grow>
  6db50f:	cmpl   $0x1,0x40(%rsp)
  6db514:	je     6db538 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x338>
  6db516:	mov    0x48(%rsp),%rax
  6db51b:	mov    %rax,0x8(%rsp)
  6db520:	mov    %r14,(%rsp)
  6db524:	mov    0x20(%rsp),%rsi
  6db529:	jmp    6db280 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x80>
  6db52e:	xor    %edi,%edi
  6db530:	call   *0x366db2(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  6db536:	ud2
  6db538:	mov    0x48(%rsp),%rdi
  6db53d:	mov    0x50(%rsp),%rsi
  6db542:	jmp    6db530 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x330>
  6db544:	mov    %rax,%rbx
  6db547:	mov    (%rsp),%r15
  6db54b:	jmp    6db550 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x350>
  6db54d:	mov    %rax,%rbx
  6db550:	test   %r15,%r15
  6db553:	je     6db56c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x36c>
  6db555:	mov    0x8(%rsp),%rdi
  6db55a:	shl    $0x4,%r15
  6db55e:	mov    $0x4,%edx
  6db563:	mov    %r15,%rsi
  6db566:	call   *0x366cec(%rip)        # a42258 <_DYNAMIC+0x268>
  6db56c:	mov    %rbx,%rdi
  6db56f:	call   a20740 <_Unwind_Resume@plt>

<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9} as core::ops::function::FnOnce<(gpui_reactivity_core::tree::NodeId, cephal::tree::traits::MeasureInput)>>::call_once::{shim:vtable#0} code=57 fixed_stack=56

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006db970 <<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9} as core::ops::function::FnOnce<(gpui_reactivity_core::tree::NodeId, cephal::tree::traits::MeasureInput)>>::call_once::{shim:vtable#0}>:
  6db970:	push   %rbx
  6db971:	sub    $0x30,%rsp
  6db975:	mov    %rdi,%rbx
  6db978:	lea    0x10(%rsp),%rax
  6db97d:	movups (%rcx),%xmm0
  6db980:	movups 0x10(%rcx),%xmm1
  6db984:	movaps %xmm1,0x20(%rsp)
  6db989:	movaps %xmm0,0x10(%rsp)
  6db98e:	movups (%rdx),%xmm0
  6db991:	movaps %xmm0,(%rsp)
  6db995:	mov    %rsp,%rdx
  6db998:	mov    %rax,%rcx
  6db99b:	call   6da920 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}>
  6db9a0:	mov    %rbx,%rax
  6db9a3:	add    $0x30,%rsp
  6db9a7:	pop    %rbx
  6db9a8:	ret

text_column_public_control::emit_state code=5501 fixed_stack=712

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006db9b0 <text_column_public_control::emit_state>:
  6db9b0:	push   %rbp
  6db9b1:	push   %r15
  6db9b3:	push   %r14
  6db9b5:	push   %r13
  6db9b7:	push   %r12
  6db9b9:	push   %rbx
  6db9ba:	sub    $0x298,%rsp
  6db9c1:	mov    %edx,0xcc(%rsp)
  6db9c8:	mov    %esi,0xc8(%rsp)
  6db9cf:	mov    %rdi,%rbp
  6db9d2:	mov    %rcx,0x270(%rsp)
  6db9da:	mov    %r8,0x278(%rsp)
  6db9e2:	lea    0xd0(%rsp),%rdi
  6db9ea:	mov    %rbp,%rsi
  6db9ed:	call   6b5ed0 <text_column_public_control::observe::<text_column_public_control::Model>>
  6db9f2:	mov    0xd0(%rsp),%rax
  6db9fa:	mov    0xd8(%rsp),%rcx
  6dba02:	mov    %rax,0x1f8(%rsp)
  6dba0a:	mov    %rcx,0x200(%rsp)
  6dba12:	mov    0xe0(%rsp),%rax
  6dba1a:	mov    %rax,0x208(%rsp)
  6dba22:	test   %rbp,%rbp
  6dba25:	je     6dcd39 <text_column_public_control::emit_state+0x1389>
  6dba2b:	mov    0x5f0(%rbp),%r15
  6dba32:	mov    %r15,%rax
  6dba35:	shl    $0x7,%rax
  6dba39:	lea    (%rax,%r15,8),%rbx
  6dba3d:	movabs $0xf0f0f0f0f0f0f0,%rax
  6dba47:	cmp    %rax,%r15
  6dba4a:	jbe    6dba5b <text_column_public_control::emit_state+0xab>
  6dba4c:	xor    %r14d,%r14d
  6dba4f:	mov    %r14,%rdi
  6dba52:	mov    %rbx,%rsi
  6dba55:	call   *0x36688d(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  6dba5b:	test   %rbx,%rbx
  6dba5e:	je     6dba84 <text_column_public_control::emit_state+0xd4>
  6dba60:	call   *0x3667fa(%rip)        # a42260 <_DYNAMIC+0x270>
  6dba66:	mov    $0x8,%r14d
  6dba6c:	mov    $0x8,%esi
  6dba71:	mov    %rbx,%rdi
  6dba74:	call   *0x3667ee(%rip)        # a42268 <_DYNAMIC+0x278>
  6dba7a:	test   %rax,%rax
  6dba7d:	je     6dba4f <text_column_public_control::emit_state+0x9f>
  6dba7f:	mov    %rax,%r12
  6dba82:	jmp    6dba8d <text_column_public_control::emit_state+0xdd>
  6dba84:	mov    $0x8,%r12d
  6dba8a:	xor    %r15d,%r15d
  6dba8d:	mov    %r15,0x88(%rsp)
  6dba95:	mov    %r12,0x90(%rsp)
  6dba9d:	movq   $0x0,0x98(%rsp)
  6dbaa9:	mov    0x680(%rbp),%rax
  6dbab0:	test   %rax,%rax
  6dbab3:	je     6dbace <text_column_public_control::emit_state+0x11e>
  6dbab5:	mov    0x100(%rax),%rsi
  6dbabc:	test   %rsi,%rsi
  6dbabf:	je     6dbace <text_column_public_control::emit_state+0x11e>
  6dbac1:	lea    0x30(%rsp),%rdi
  6dbac6:	call   *0x36676c(%rip)        # a42238 <_DYNAMIC+0x248>
  6dbacc:	jmp    6dbadf <text_column_public_control::emit_state+0x12f>
  6dbace:	movq   $0x4,0x30(%rsp)
  6dbad7:	xorps  %xmm0,%xmm0
  6dbada:	movups %xmm0,0x38(%rsp)
  6dbadf:	mov    0x5f0(%rbp),%rax
  6dbae6:	mov    %rax,0xb0(%rsp)
  6dbaee:	test   %rax,%rax
  6dbaf1:	mov    %rbp,0x80(%rsp)
  6dbaf9:	je     6dc001 <text_column_public_control::emit_state+0x651>
  6dbaff:	lea    0x620(%rbp),%rax
  6dbb06:	mov    %rax,0x18(%rsp)
  6dbb0b:	xor    %r14d,%r14d
  6dbb0e:	lea    0x347b23(%rip),%rax        # a23638 <__frame_dummy_init_array_entry+0x1b48>
  6dbb15:	mov    %rax,0x10(%rsp)
  6dbb1a:	jmp    6dbb66 <text_column_public_control::emit_state+0x1b6>
  6dbb1c:	nopl   0x0(%rax)
  6dbb20:	mov    0x90(%rsp),%r12
  6dbb28:	lea    0x1(%r14),%rbx
  6dbb2c:	mov    %r14,%rax
  6dbb2f:	shl    $0x7,%rax
  6dbb33:	lea    (%rax,%r14,8),%rdi
  6dbb37:	add    %r12,%rdi
  6dbb3a:	mov    $0x88,%edx
  6dbb3f:	lea    0xd0(%rsp),%rsi
  6dbb47:	call   *0x36672b(%rip)        # a42278 <memcpy@GLIBC_2.14>
  6dbb4d:	mov    %rbx,0x98(%rsp)
  6dbb55:	mov    %rbx,%r14
  6dbb58:	cmp    0xb0(%rsp),%rbx
  6dbb60:	je     6dc001 <text_column_public_control::emit_state+0x651>
  6dbb66:	mov    0x5f0(%rbp),%rsi
  6dbb6d:	cmp    %rsi,%r14
  6dbb70:	jae    6dccd6 <text_column_public_control::emit_state+0x1326>
  6dbb76:	mov    0x5e8(%rbp),%r15
  6dbb7d:	mov    %r14,%rbx
  6dbb80:	shl    $0x6,%rbx
  6dbb84:	mov    0x20(%r15,%rbx,1),%r8
  6dbb89:	cmpb   $0x0,0x78a(%rbp)
  6dbb90:	mov    %r8,0x8(%rsp)
  6dbb95:	je     6dbba4 <text_column_public_control::emit_state+0x1f4>
  6dbb97:	cmpb   $0x0,0x78e(%rbp)
  6dbb9e:	je     6dbcb0 <text_column_public_control::emit_state+0x300>
  6dbba4:	xor    %r13d,%r13d
  6dbba7:	add    %rbx,%r15
  6dbbaa:	mov    0x38(%r15),%ebx
  6dbbae:	and    $0x1ffff,%ebx
  6dbbb4:	xor    %ebp,%ebp
  6dbbb6:	cmp    $0x1ffff,%rbx
  6dbbbd:	setne  0xb8(%rsp)
  6dbbc5:	movzbl 0x3d(%r15),%eax
  6dbbca:	sub    $0x2,%al
  6dbbcc:	movzbl %al,%eax
  6dbbcf:	mov    $0x8,%ecx
  6dbbd4:	cmovb  %ecx,%eax
  6dbbd7:	mov    %al,0x1a0(%rsp)
  6dbbde:	lea    0x1a0(%rsp),%rax
  6dbbe6:	mov    %rax,0x218(%rsp)
  6dbbee:	lea    0x4beeb(%rip),%rax        # 727ae0 <<gpui::element::Role as core::fmt::Debug>::fmt>
  6dbbf5:	mov    %rax,0x220(%rsp)
  6dbbfd:	lea    0xd0(%rsp),%rdi
  6dbc05:	lea    -0x6969d8(%rip),%rsi        # 45234 <GCC_except_table0+0x5490>
  6dbc0c:	lea    0x218(%rsp),%rdx
  6dbc14:	call   *0x36685e(%rip)        # a42478 <_DYNAMIC+0x488>
  6dbc1a:	mov    %r14,0xc0(%rsp)
  6dbc22:	mov    %r12,0x70(%rsp)
  6dbc27:	mov    0xd0(%rsp),%rax
  6dbc2f:	mov    %rax,0x20(%rsp)
  6dbc34:	mov    0xd8(%rsp),%rax
  6dbc3c:	mov    %rax,0x78(%rsp)
  6dbc41:	mov    0xe0(%rsp),%rax
  6dbc49:	mov    %rax,0x68(%rsp)
  6dbc4e:	mov    0x28(%r15),%r14
  6dbc52:	test   %r14,%r14
  6dbc55:	je     6dbca0 <text_column_public_control::emit_state+0x2f0>
  6dbc57:	mov    (%r14),%r12
  6dbc5a:	shr    $1,%r12
  6dbc5d:	je     6dbd00 <text_column_public_control::emit_state+0x350>
  6dbc63:	call   *0x3665f7(%rip)        # a42260 <_DYNAMIC+0x270>
  6dbc69:	mov    $0x1,%esi
  6dbc6e:	mov    %r12,%rdi
  6dbc71:	call   *0x3665f1(%rip)        # a42268 <_DYNAMIC+0x278>
  6dbc77:	test   %rax,%rax
  6dbc7a:	je     6dccfe <text_column_public_control::emit_state+0x134e>
  6dbc80:	add    $0x10,%r14
  6dbc84:	mov    %rax,0x50(%rsp)
  6dbc89:	mov    %rax,%rdi
  6dbc8c:	mov    %r14,%rsi
  6dbc8f:	mov    %r12,%rdx
  6dbc92:	call   *0x3665e0(%rip)        # a42278 <memcpy@GLIBC_2.14>
  6dbc98:	mov    %r12,0x60(%rsp)
  6dbc9d:	jmp    6dbd16 <text_column_public_control::emit_state+0x366>
  6dbc9f:	nop
  6dbca0:	mov    $0xffffffffffffffff,%r12
  6dbca7:	jmp    6dbd16 <text_column_public_control::emit_state+0x366>
  6dbca9:	nopl   0x0(%rax)
  6dbcb0:	mov    0x1e8(%rbp),%rax
  6dbcb7:	test   %rax,%rax
  6dbcba:	je     6dbe6e <text_column_public_control::emit_state+0x4be>
  6dbcc0:	cmp    $0x1,%eax
  6dbcc3:	jne    6dbe90 <text_column_public_control::emit_state+0x4e0>
  6dbcc9:	mov    0x1f8(%rbp),%r13
  6dbcd0:	test   %r13,%r13
  6dbcd3:	je     6dbec0 <text_column_public_control::emit_state+0x510>
  6dbcd9:	mov    0x1f0(%rbp),%rax
  6dbce0:	xor    %ecx,%ecx
  6dbce2:	cmp    $0x1,%r13
  6dbce6:	jne    6dbec5 <text_column_public_control::emit_state+0x515>
  6dbcec:	mov    0x8(%rsp),%r8
  6dbcf1:	jmp    6dbef4 <text_column_public_control::emit_state+0x544>
  6dbcf6:	cs nopw 0x0(%rax,%rax,1)
  6dbd00:	mov    $0x1,%eax
  6dbd05:	mov    %rax,0x50(%rsp)
  6dbd0a:	xor    %r12d,%r12d
  6dbd0d:	movq   $0x0,0x60(%rsp)
  6dbd16:	movups 0x10(%r15),%xmm0
  6dbd1b:	movaps %xmm0,0x190(%rsp)
  6dbd23:	lea    0x30(%rsp),%rdi
  6dbd28:	call   *0x366752(%rip)        # a42480 <_DYNAMIC+0x490>
  6dbd2e:	mov    0xc0(%rsp),%r14
  6dbd36:	mov    %rdx,%rcx
  6dbd39:	lea    0xd0(%rsp),%rdi
  6dbd41:	mov    %r15,%rsi
  6dbd44:	mov    %rax,%rdx
  6dbd47:	call   *0x36673b(%rip)        # a42488 <_DYNAMIC+0x498>
  6dbd4d:	mov    0xd0(%rsp),%eax
  6dbd54:	test   %eax,%eax
  6dbd56:	jne    6dbd70 <text_column_public_control::emit_state+0x3c0>
  6dbd58:	movaps 0x1c0(%rsp),%xmm0
  6dbd60:	movaps 0x1b0(%rsp),%xmm1
  6dbd68:	jmp    6dbd81 <text_column_public_control::emit_state+0x3d1>
  6dbd6a:	nopw   0x0(%rax,%rax,1)
  6dbd70:	movups 0xd4(%rsp),%xmm0
  6dbd78:	movsd  0xe4(%rsp),%xmm1
  6dbd81:	movaps 0x190(%rsp),%xmm2
  6dbd89:	movzbl 0xb8(%rsp),%ecx
  6dbd91:	mov    %cl,%bpl
  6dbd94:	mov    0x8(%rsp),%rcx
  6dbd99:	mov    %rcx,0x110(%rsp)
  6dbda1:	mov    %rbp,0xd0(%rsp)
  6dbda9:	mov    %rbx,0xd8(%rsp)
  6dbdb1:	mov    0x20(%rsp),%rcx
  6dbdb6:	mov    %rcx,0xe0(%rsp)
  6dbdbe:	mov    0x78(%rsp),%rcx
  6dbdc3:	mov    %rcx,0xe8(%rsp)
  6dbdcb:	mov    0x68(%rsp),%rcx
  6dbdd0:	mov    %rcx,0xf0(%rsp)
  6dbdd8:	mov    %r12,0xf8(%rsp)
  6dbde0:	mov    0x50(%rsp),%rcx
  6dbde5:	mov    %rcx,0x100(%rsp)
  6dbded:	mov    0x60(%rsp),%rcx
  6dbdf2:	mov    %rcx,0x108(%rsp)
  6dbdfa:	movups %xmm2,0x118(%rsp)
  6dbe02:	mov    %eax,0x138(%rsp)
  6dbe09:	movaps %xmm0,0x1c0(%rsp)
  6dbe11:	movups %xmm0,0x13c(%rsp)
  6dbe19:	movaps %xmm1,0x1b0(%rsp)
  6dbe21:	movlps %xmm1,0x14c(%rsp)
  6dbe29:	mov    %r13,0x128(%rsp)
  6dbe31:	mov    0xa8(%rsp),%rax
  6dbe39:	mov    %rax,0x130(%rsp)
  6dbe41:	cmp    0x88(%rsp),%r14
  6dbe49:	mov    0x80(%rsp),%rbp
  6dbe51:	mov    0x70(%rsp),%r12
  6dbe56:	jne    6dbb28 <text_column_public_control::emit_state+0x178>
  6dbe5c:	lea    0x88(%rsp),%rdi
  6dbe64:	call   6f4740 <<alloc::raw_vec::RawVec<gpui::runtime::SnapshotNode>>::grow_one>
  6dbe69:	jmp    6dbb20 <text_column_public_control::emit_state+0x170>
  6dbe6e:	mov    %r8,%rcx
  6dbe71:	sub    0x1f0(%rbp),%rcx
  6dbe78:	jb     6dbba4 <text_column_public_control::emit_state+0x1f4>
  6dbe7e:	cmp    0x1f8(%rbp),%rcx
  6dbe85:	jae    6dbba4 <text_column_public_control::emit_state+0x1f4>
  6dbe8b:	jmp    6dbf76 <text_column_public_control::emit_state+0x5c6>
  6dbe90:	mov    0x1f8(%rbp),%r13
  6dbe97:	test   %r13,%r13
  6dbe9a:	je     6dbec0 <text_column_public_control::emit_state+0x510>
  6dbe9c:	mov    0x1f0(%rbp),%rax
  6dbea3:	cmp    $0x1,%r13
  6dbea7:	jne    6dbf31 <text_column_public_control::emit_state+0x581>
  6dbead:	mov    0x8(%rsp),%r8
  6dbeb2:	cmp    %r8,(%rax)
  6dbeb5:	jne    6dbba4 <text_column_public_control::emit_state+0x1f4>
  6dbebb:	jmp    6dbf73 <text_column_public_control::emit_state+0x5c3>
  6dbec0:	jmp    6dbba7 <text_column_public_control::emit_state+0x1f7>
  6dbec5:	mov    0x8(%rsp),%r8
  6dbeca:	nopw   0x0(%rax,%rax,1)
  6dbed0:	mov    %rcx,%rdx
  6dbed3:	mov    %r13,%rsi
  6dbed6:	shr    $1,%rsi
  6dbed9:	add    %rsi,%rcx
  6dbedc:	mov    %rcx,%rdi
  6dbedf:	shl    $0x4,%rdi
  6dbee3:	cmp    %r8,(%rax,%rdi,1)
  6dbee7:	cmova  %rdx,%rcx
  6dbeeb:	sub    %rsi,%r13
  6dbeee:	cmp    $0x1,%r13
  6dbef2:	ja     6dbed0 <text_column_public_control::emit_state+0x520>
  6dbef4:	mov    %rcx,%rsi
  6dbef7:	shl    $0x4,%rsi
  6dbefb:	xor    %edx,%edx
  6dbefd:	cmp    %r8,(%rax,%rsi,1)
  6dbf01:	setbe  %dl
  6dbf04:	add    %rcx,%rdx
  6dbf07:	je     6dbba4 <text_column_public_control::emit_state+0x1f4>
  6dbf0d:	shl    $0x4,%rdx
  6dbf11:	mov    %r8,%rcx
  6dbf14:	sub    -0x10(%rax,%rdx,1),%rcx
  6dbf19:	mov    -0x4(%rax,%rdx,1),%esi
  6dbf1d:	cmp    %rsi,%rcx
  6dbf20:	jae    6dbba4 <text_column_public_control::emit_state+0x1f4>
  6dbf26:	add    %rdx,%rax
  6dbf29:	mov    -0x8(%rax),%eax
  6dbf2c:	add    %rax,%rcx
  6dbf2f:	jmp    6dbf76 <text_column_public_control::emit_state+0x5c6>
  6dbf31:	xor    %ecx,%ecx
  6dbf33:	mov    0x8(%rsp),%r8
  6dbf38:	nopl   0x0(%rax,%rax,1)
  6dbf40:	mov    %rcx,%rdx
  6dbf43:	mov    %r13,%rsi
  6dbf46:	shr    $1,%rsi
  6dbf49:	add    %rsi,%rcx
  6dbf4c:	lea    (%rcx,%rcx,2),%rdi
  6dbf50:	cmp    %r8,(%rax,%rdi,4)
  6dbf54:	cmova  %rdx,%rcx
  6dbf58:	sub    %rsi,%r13
  6dbf5b:	cmp    $0x1,%r13
  6dbf5f:	ja     6dbf40 <text_column_public_control::emit_state+0x590>
  6dbf61:	lea    (%rcx,%rcx,2),%rcx
  6dbf65:	cmp    %r8,(%rax,%rcx,4)
  6dbf69:	jne    6dbba4 <text_column_public_control::emit_state+0x1f4>
  6dbf6f:	lea    (%rax,%rcx,4),%rax
  6dbf73:	mov    0x8(%rax),%ecx
  6dbf76:	mov    0x310(%rbp),%rsi
  6dbf7d:	cmp    %rsi,%rcx
  6dbf80:	jae    6dcd7b <text_column_public_control::emit_state+0x13cb>
  6dbf86:	mov    0x308(%rbp),%rax
  6dbf8d:	lea    (%rcx,%rcx,4),%rcx
  6dbf91:	cmpq   $0x0,0x8(%rax,%rcx,8)
  6dbf97:	je     6dbfb7 <text_column_public_control::emit_state+0x607>
  6dbf99:	mov    0x18(%rsp),%rdi
  6dbf9e:	mov    %r8,%rsi
  6dbfa1:	call   *0x3664e9(%rip)        # a42490 <_DYNAMIC+0x4a0>
  6dbfa7:	mov    %rdx,0xa8(%rsp)
  6dbfaf:	mov    %rax,%r13
  6dbfb2:	jmp    6dbba7 <text_column_public_control::emit_state+0x1f7>
  6dbfb7:	lea    (%rax,%rcx,8),%rax
  6dbfbb:	mov    0x20(%rax),%eax
  6dbfbe:	and    $0xf,%eax
  6dbfc1:	lea    -0x3(%rax),%ecx
  6dbfc4:	cmp    $0x7,%ecx
  6dbfc7:	jb     6dbba4 <text_column_public_control::emit_state+0x1f4>
  6dbfcd:	mov    $0x0,%r13d
  6dbfd3:	cmp    $0x2,%eax
  6dbfd6:	jb     6dbba7 <text_column_public_control::emit_state+0x1f7>
  6dbfdc:	mov    0x8(%rsp),%r8
  6dbfe1:	je     6dbf99 <text_column_public_control::emit_state+0x5e9>
  6dbfe3:	lea    -0x68bd88(%rip),%rdi        # 50262 <GCC_except_table0+0x104be>
  6dbfea:	lea    0x3475ff(%rip),%rdx        # a235f0 <__frame_dummy_init_array_entry+0x1b00>
  6dbff1:	mov    $0x83,%esi
  6dbff6:	call   *0x366294(%rip)        # a42290 <_DYNAMIC+0x2a0>
  6dbffc:	jmp    6dcde2 <text_column_public_control::emit_state+0x1432>
  6dc001:	lea    0x90(%rsp),%rdx
  6dc009:	movups 0x6d0(%rbp),%xmm0
  6dc010:	movzbl 0x78c(%rbp),%ecx
  6dc017:	mov    0x6f0(%rbp),%rax
  6dc01e:	test   %rax,%rax
  6dc021:	je     6dc040 <text_column_public_control::emit_state+0x690>
  6dc023:	test   %cl,%cl
  6dc025:	je     6dc031 <text_column_public_control::emit_state+0x681>
  6dc027:	cmpq   $0xffffffffffffffff,0x5f8(%rbp)
  6dc02f:	je     6dc040 <text_column_public_control::emit_state+0x690>
  6dc031:	mov    0x700(%rbp),%r10
  6dc038:	mov    $0x1,%r11d
  6dc03e:	jmp    6dc043 <text_column_public_control::emit_state+0x693>
  6dc040:	xor    %r11d,%r11d
  6dc043:	movzbl 0x78e(%rbp),%esi
  6dc04a:	movups (%rdx),%xmm1
  6dc04d:	mov    0x88(%rsp),%rdx
  6dc055:	movups %xmm1,0x230(%rsp)
  6dc05d:	mov    %r11,0x218(%rsp)
  6dc065:	mov    %r10,0x220(%rsp)
  6dc06d:	mov    %rdx,0x228(%rsp)
  6dc075:	movups %xmm0,0x240(%rsp)
  6dc07d:	movups 0x6e0(%rbp),%xmm0
  6dc084:	movups %xmm0,0x250(%rsp)
  6dc08c:	movsd  0x780(%rbp),%xmm0
  6dc094:	shufps $0xe1,%xmm0,%xmm0
  6dc098:	movlps %xmm0,0x260(%rsp)
  6dc0a0:	mov    %cl,0x268(%rsp)
  6dc0a7:	mov    %sil,0x269(%rsp)
  6dc0af:	test   %rax,%rax
  6dc0b2:	je     6dcd8f <text_column_public_control::emit_state+0x13df>
  6dc0b8:	test   %sil,%sil
  6dc0bb:	jne    6dcd8f <text_column_public_control::emit_state+0x13df>
  6dc0c1:	mov    0x1a8(%rbp),%ecx
  6dc0c7:	mov    0x1b0(%rbp),%rax
  6dc0ce:	mov    0x1b8(%rbp),%r8d
  6dc0d5:	mov    0x1bc(%rbp),%edi
  6dc0db:	mov    0x1c0(%rbp),%esi
  6dc0e1:	mov    0x1c4(%rbp),%edx
  6dc0e7:	mov    0x118(%rbp),%r9
  6dc0ee:	test   %r9,%r9
  6dc0f1:	je     6dc108 <text_column_public_control::emit_state+0x758>
  6dc0f3:	mov    0x10(%r9),%r9
  6dc0f7:	mov    %r9,0xd0(%rsp)
  6dc0ff:	test   %r9,%r9
  6dc102:	jne    6dccb1 <text_column_public_control::emit_state+0x1301>
  6dc108:	mov    %r11,0x1d8(%rsp)
  6dc110:	mov    %r10,0x1d0(%rsp)
  6dc118:	movabs $0xcbf29ce484222325,%rbx
  6dc122:	movabs $0x100000001b3,%r14
  6dc12c:	mov    %eax,%r9d
  6dc12f:	mov    %rcx,%r15
  6dc132:	xor    %rbx,%r15
  6dc135:	imul   %r14,%r15
  6dc139:	xor    %r9,%r15
  6dc13c:	imul   %r14,%r15
  6dc140:	xor    %r8,%r15
  6dc143:	imul   %r14,%r15
  6dc147:	xor    %rdi,%r15
  6dc14a:	imul   %r14,%r15
  6dc14e:	xor    %rsi,%r15
  6dc151:	imul   %r14,%r15
  6dc155:	xor    %rdx,%r15
  6dc158:	imul   %r14,%r15
  6dc15c:	mov    0x80(%rbp),%rdx
  6dc163:	test   %rdx,%rdx
  6dc166:	je     6dc806 <text_column_public_control::emit_state+0xe56>
  6dc16c:	movzwl %cx,%ecx
  6dc16f:	movd   %ecx,%xmm0
  6dc173:	pinsrw $0x2,%eax,%xmm0
  6dc178:	cvtdq2ps %xmm0,%xmm0
  6dc17b:	mov    0x78(%rbp),%r13
  6dc17f:	lea    0x0(%r13,%rdx,4),%rax
  6dc184:	mov    %rax,0x1e8(%rsp)
  6dc18c:	lea    0xb8(%rbp),%rax
  6dc193:	mov    %rax,0x1f0(%rsp)
  6dc19b:	xorps  %xmm1,%xmm1
  6dc19e:	movlhps %xmm0,%xmm1
  6dc1a1:	movaps %xmm1,0x280(%rsp)
  6dc1a9:	lea    0x3470e8(%rip),%rax        # a23298 <__frame_dummy_init_array_entry+0x17a8>
  6dc1b0:	mov    %rax,0x48(%rsp)
  6dc1b5:	jmp    6dc201 <text_column_public_control::emit_state+0x851>
  6dc1b7:	nopw   0x0(%rax,%rax,1)
  6dc1c0:	xorps  %xmm1,%xmm1
  6dc1c3:	ucomiss %xmm1,%xmm0
  6dc1c6:	jne    6dc1ce <text_column_public_control::emit_state+0x81e>
  6dc1c8:	jnp    6dc762 <text_column_public_control::emit_state+0xdb2>
  6dc1ce:	imul   %r14,%rdi
  6dc1d2:	xor    $0x1,%rdi
  6dc1d6:	imul   %r14,%rdi
  6dc1da:	movd   %xmm0,%eax
  6dc1de:	xor    %rdi,%rax
  6dc1e1:	imul   %r14,%rax
  6dc1e5:	mov    %rax,%rdi
  6dc1e8:	imul   %r14,%rdi
  6dc1ec:	mov    %rdi,%r15
  6dc1ef:	add    $0x4,%r13
  6dc1f3:	cmp    0x1e8(%rsp),%r13
  6dc1fb:	je     6dc806 <text_column_public_control::emit_state+0xe56>
  6dc201:	movslq 0x0(%r13),%rdi
  6dc205:	movdqa 0x280(%rsp),%xmm0
  6dc20e:	movdqu %xmm0,0x88(%rsp)
  6dc217:	test   %rdi,%rdi
  6dc21a:	js     6dc280 <text_column_public_control::emit_state+0x8d0>
  6dc21c:	mov    0xf8(%rbp),%rsi
  6dc223:	cmp    %rdi,%rsi
  6dc226:	jbe    6dccf5 <text_column_public_control::emit_state+0x1345>
  6dc22c:	mov    0xb0(%rbp),%rsi
  6dc233:	mov    0xf0(%rbp),%r12
  6dc23a:	shl    $0x5,%rdi
  6dc23e:	mov    0x18(%r12,%rdi,1),%eax
  6dc243:	cmp    %rax,%rsi
  6dc246:	jbe    6dcce9 <text_column_public_control::emit_state+0x1339>
  6dc24c:	add    %rdi,%r12
  6dc24f:	mov    0xa8(%rbp),%rcx
  6dc256:	shl    $0x5,%rax
  6dc25a:	mov    0x10(%rcx,%rax,1),%rdx
  6dc25f:	mov    %rdx,0x40(%rsp)
  6dc264:	movups (%rcx,%rax,1),%xmm0
  6dc268:	movaps %xmm0,0x30(%rsp)
  6dc26d:	lea    0x1c(%r12),%rax
  6dc272:	jmp    6dc2c3 <text_column_public_control::emit_state+0x913>
  6dc274:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6dc280:	and    $0x7fffffff,%edi
  6dc286:	mov    0x98(%rbp),%rsi
  6dc28d:	cmp    %rdi,%rsi
  6dc290:	jbe    6dcd29 <text_column_public_control::emit_state+0x1379>
  6dc296:	mov    0x90(%rbp),%rax
  6dc29d:	imul   $0x38,%rdi,%rcx
  6dc2a1:	mov    0x10(%rax,%rcx,1),%rdx
  6dc2a6:	mov    %rdx,0x40(%rsp)
  6dc2ab:	movups (%rax,%rcx,1),%xmm0
  6dc2af:	movaps %xmm0,0x30(%rsp)
  6dc2b4:	lea    (%rax,%rcx,1),%r12
  6dc2b8:	add    $0x18,%r12
  6dc2bc:	add    %rcx,%rax
  6dc2bf:	add    $0x30,%rax
  6dc2c3:	movslq (%rax),%rbp
  6dc2c6:	xor    %r8d,%r8d
  6dc2c9:	cmp    $0x40000000,%rbp
  6dc2d0:	setge  %r8b
  6dc2d4:	lea    0xd0(%rsp),%rdi
  6dc2dc:	mov    0x1f0(%rsp),%rsi
  6dc2e4:	lea    0x30(%rsp),%rdx
  6dc2e9:	lea    0x88(%rsp),%rcx
  6dc2f1:	call   *0x3661a1(%rip)        # a42498 <_DYNAMIC+0x4a8>
  6dc2f7:	mov    0xd0(%rsp),%eax
  6dc2fe:	mov    %rax,0x60(%rsp)
  6dc303:	mov    0xd4(%rsp),%eax
  6dc30a:	mov    %rax,0x50(%rsp)
  6dc30f:	mov    0xd8(%rsp),%eax
  6dc316:	mov    %rax,0x190(%rsp)
  6dc31e:	mov    0xdc(%rsp),%eax
  6dc325:	mov    %rax,0x68(%rsp)
  6dc32a:	mov    0xe0(%rsp),%rax
  6dc332:	mov    %rax,0x70(%rsp)
  6dc337:	mov    0xe8(%rsp),%r9
  6dc33f:	mov    0xf0(%rsp),%rsi
  6dc347:	mov    0xf8(%rsp),%rdi
  6dc34f:	mov    0x100(%rsp),%r10
  6dc357:	mov    0x108(%rsp),%r8
  6dc35f:	movd   0x110(%rsp),%xmm0
  6dc368:	mov    0x114(%rsp),%eax
  6dc36f:	mov    0x118(%rsp),%ecx
  6dc376:	mov    0x11c(%rsp),%edx
  6dc37d:	mov    0x10(%r12),%r11
  6dc382:	cmp    $0xffffffff,%ebp
  6dc385:	mov    %rdi,0xc0(%rsp)
  6dc38d:	mov    %rsi,0x78(%rsp)
  6dc392:	mov    %r9,0xb8(%rsp)
  6dc39a:	je     6dc3e0 <text_column_public_control::emit_state+0xa30>
  6dc39c:	test   %ebp,%ebp
  6dc39e:	js     6dc3f0 <text_column_public_control::emit_state+0xa40>
  6dc3a0:	cmp    $0x40000000,%ebp
  6dc3a6:	jae    6dc402 <text_column_public_control::emit_state+0xa52>
  6dc3a8:	mov    0x80(%rsp),%rdi
  6dc3b0:	mov    0x110(%rdi),%rsi
  6dc3b7:	cmp    %rbp,%rsi
  6dc3ba:	jbe    6dcd11 <text_column_public_control::emit_state+0x1361>
  6dc3c0:	mov    0x108(%rdi),%rsi
  6dc3c7:	mov    (%rsi,%rbp,8),%rdi
  6dc3cb:	add    $0x10,%rdi
  6dc3cf:	mov    $0x2,%r9d
  6dc3d5:	jmp    6dc449 <text_column_public_control::emit_state+0xa99>
  6dc3d7:	nopw   0x0(%rax,%rax,1)
  6dc3e0:	xor    %r9d,%r9d
  6dc3e3:	jmp    6dc449 <text_column_public_control::emit_state+0xa99>
  6dc3e5:	data16 cs nopw 0x0(%rax,%rax,1)
  6dc3f0:	and    $0x7fffffff,%ebp
  6dc3f6:	movd   %ebp,%xmm1
  6dc3fa:	mov    $0x1,%r9d
  6dc400:	jmp    6dc449 <text_column_public_control::emit_state+0xa99>
  6dc402:	mov    0x80(%rsp),%rsi
  6dc40a:	mov    0x118(%rsi),%r9
  6dc411:	test   %r9,%r9
  6dc414:	je     6dcc9f <text_column_public_control::emit_state+0x12ef>
  6dc41a:	mov    %ebp,%edi
  6dc41c:	and    $0x1fffffff,%edi
  6dc422:	mov    0x10(%r9),%rsi
  6dc426:	cmp    %rdi,%rsi
  6dc429:	jbe    6dcd1d <text_column_public_control::emit_state+0x136d>
  6dc42f:	shl    $0x3,%edi
  6dc432:	add    0x8(%r9),%rdi
  6dc436:	and    $0x20000000,%ebp
  6dc43c:	cmp    $0x1,%ebp
  6dc43f:	mov    $0x0,%r9d
  6dc445:	adc    $0x3,%r9d
  6dc449:	mov    $0x3f800000,%ebp
  6dc44e:	mov    $0x3f800000,%esi
  6dc453:	mov    %rsi,0x8(%rsp)
  6dc458:	mov    %rsi,0x20(%rsp)
  6dc45d:	cmp    $0x2,%r9d
  6dc461:	ja     6dc474 <text_column_public_control::emit_state+0xac4>
  6dc463:	movd   %xmm0,%esi
  6dc467:	mov    %rdx,%rbp
  6dc46a:	mov    %rcx,0x8(%rsp)
  6dc46f:	mov    %rax,0x20(%rsp)
  6dc474:	mov    %rbp,0x1b0(%rsp)
  6dc47c:	mov    %r11,%rax
  6dc47f:	shr    $0x20,%rax
  6dc483:	movzwl %ax,%ebp
  6dc486:	movzwl %r11w,%edx
  6dc48a:	mov    %r9d,%eax
  6dc48d:	lea    -0x69a9cc(%rip),%rcx        # 41ac8 <GCC_except_table0+0x1d24>
  6dc494:	movslq (%rcx,%rax,4),%rax
  6dc498:	add    %rcx,%rax
  6dc49b:	jmp    *%rax
  6dc49d:	mov    (%rdi),%rax
  6dc4a0:	mov    $0x1,%ecx
  6dc4a5:	cmpb   $0x0,0x10(%rax)
  6dc4a9:	jne    6dc4b2 <text_column_public_control::emit_state+0xb02>
  6dc4ab:	movzwl 0x11(%rax),%ecx
  6dc4af:	shl    $0x8,%ecx
  6dc4b2:	mov    %rcx,0x58(%rsp)
  6dc4b7:	mov    0x30(%rax),%ecx
  6dc4ba:	mov    %rcx,0x18(%rsp)
  6dc4bf:	mov    0x34(%rax),%ecx
  6dc4c2:	mov    %rcx,0x10(%rsp)
  6dc4c7:	mov    0x18(%rax),%rax
  6dc4cb:	mov    %rax,0xa0(%rsp)
  6dc4d3:	mov    $0x3,%cl
  6dc4d5:	xor    %edi,%edi
  6dc4d7:	xor    %r9d,%r9d
  6dc4da:	jmp    6dc539 <text_column_public_control::emit_state+0xb89>
  6dc4dc:	mov    0x28(%rdi),%rcx
  6dc4e0:	mov    0x30(%rdi),%rax
  6dc4e4:	mov    %rax,0x1e0(%rsp)
  6dc4ec:	mov    0x8(%rdi),%rax
  6dc4f0:	mov    %rax,0x58(%rsp)
  6dc4f5:	mov    0x10(%rdi),%rax
  6dc4f9:	mov    %rax,0xa0(%rsp)
  6dc501:	mov    %rcx,0x18(%rsp)
  6dc506:	shr    $0x20,%rcx
  6dc50a:	mov    %rcx,0x10(%rsp)
  6dc50f:	mov    $0x2,%cl
  6dc511:	mov    $0x1,%r9b
  6dc514:	xor    %edi,%edi
  6dc516:	jmp    6dc539 <text_column_public_control::emit_state+0xb89>
  6dc518:	mov    $0x1,%edi
  6dc51d:	xor    %r9d,%r9d
  6dc520:	xor    %ecx,%ecx
  6dc522:	jmp    6dc52f <text_column_public_control::emit_state+0xb7f>
  6dc524:	mov    $0x1,%cl
  6dc526:	xor    %edi,%edi
  6dc528:	movdqa %xmm1,%xmm0
  6dc52c:	xor    %r9d,%r9d
  6dc52f:	mov    %rax,0x18(%rsp)
  6dc534:	mov    %rax,0x10(%rsp)
  6dc539:	mov    %r13,0x1c0(%rsp)
  6dc541:	sub    %rdx,%rbp
  6dc544:	mov    %rcx,0xb0(%rsp)
  6dc54c:	mov    %r9,0xa8(%rsp)
  6dc554:	mov    %r10,%r13
  6dc557:	mov    %r8,%rcx
  6dc55a:	js     6dc570 <text_column_public_control::emit_state+0xbc0>
  6dc55c:	xorps  %xmm1,%xmm1
  6dc55f:	cvtsi2ss %ebp,%xmm1
  6dc563:	jmp    6dc588 <text_column_public_control::emit_state+0xbd8>
  6dc565:	data16 cs nopw 0x0(%rax,%rax,1)
  6dc570:	mov    %rbp,%rax
  6dc573:	shr    $1,%rax
  6dc576:	and    $0x1,%ebp
  6dc579:	or     %rax,%rbp
  6dc57c:	xorps  %xmm1,%xmm1
  6dc57f:	cvtsi2ss %rbp,%xmm1
  6dc584:	addss  %xmm1,%xmm1
  6dc588:	mov    %r11d,%r8d
  6dc58b:	shr    $0x10,%r8d
  6dc58f:	mov    (%r12),%r10d
  6dc593:	mov    0x4(%r12),%eax
  6dc598:	mov    0x8(%r12),%ebp
  6dc59d:	mov    0xc(%r12),%r9d
  6dc5a2:	shr    $0x30,%r11
  6dc5a6:	cvtsi2ss %edx,%xmm4
  6dc5aa:	cvtsi2ss %r8d,%xmm2
  6dc5af:	sub    %r8,%r11
  6dc5b2:	js     6dc5c0 <text_column_public_control::emit_state+0xc10>
  6dc5b4:	cvtsi2ss %r11d,%xmm3
  6dc5b9:	jmp    6dc5d6 <text_column_public_control::emit_state+0xc26>
  6dc5bb:	nopl   0x0(%rax,%rax,1)
  6dc5c0:	mov    %r11,%rdx
  6dc5c3:	shr    $1,%rdx
  6dc5c6:	and    $0x1,%r11d
  6dc5ca:	or     %rdx,%r11
  6dc5cd:	cvtsi2ss %r11,%xmm3
  6dc5d2:	addss  %xmm3,%xmm3
  6dc5d6:	mov    0x70(%rsp),%r11
  6dc5db:	mov    0x68(%rsp),%r12
  6dc5e0:	xor    %r10,%r15
  6dc5e3:	imul   %r14,%r15
  6dc5e7:	xor    %rax,%r15
  6dc5ea:	imul   %r14,%r15
  6dc5ee:	xor    %rbp,%r15
  6dc5f1:	imul   %r14,%r15
  6dc5f5:	xor    %r9,%r15
  6dc5f8:	imul   %r14,%r15
  6dc5fc:	movd   %xmm4,%eax
  6dc600:	xor    %r15,%rax
  6dc603:	imul   %r14,%rax
  6dc607:	movd   %xmm2,%edx
  6dc60b:	xor    %rax,%rdx
  6dc60e:	imul   %r14,%rdx
  6dc612:	movd   %xmm1,%r8d
  6dc617:	xor    %rdx,%r8
  6dc61a:	imul   %r14,%r8
  6dc61e:	movd   %xmm3,%eax
  6dc622:	xor    %r8,%rax
  6dc625:	imul   %r14,%rax
  6dc629:	xor    0x60(%rsp),%rax
  6dc62e:	imul   %r14,%rax
  6dc632:	xor    0x50(%rsp),%rax
  6dc637:	imul   %r14,%rax
  6dc63b:	xor    0x190(%rsp),%rax
  6dc643:	imul   %r14,%rax
  6dc647:	xor    %r12,%rax
  6dc64a:	imul   %r14,%rax
  6dc64e:	xor    %r11,%rax
  6dc651:	imul   %r14,%rax
  6dc655:	xor    0xb8(%rsp),%rax
  6dc65d:	imul   %r14,%rax
  6dc661:	xor    0x78(%rsp),%rax
  6dc666:	imul   %r14,%rax
  6dc66a:	xor    0xc0(%rsp),%rax
  6dc672:	imul   %r14,%rax
  6dc676:	xor    %r13,%rax
  6dc679:	imul   %r14,%rax
  6dc67d:	xor    %rcx,%rax
  6dc680:	imul   %r14,%rax
  6dc684:	xor    %rax,%rsi
  6dc687:	imul   %r14,%rsi
  6dc68b:	xor    0x20(%rsp),%rsi
  6dc690:	imul   %r14,%rsi
  6dc694:	xor    0x8(%rsp),%rsi
  6dc699:	imul   %r14,%rsi
  6dc69d:	xor    0x1b0(%rsp),%rsi
  6dc6a5:	imul   %r14,%rsi
  6dc6a9:	xor    %rsi,%rdi
  6dc6ac:	mov    0xb0(%rsp),%rax
  6dc6b4:	cmp    $0x1,%al
  6dc6b6:	mov    0x80(%rsp),%rbp
  6dc6be:	mov    0x1c0(%rsp),%r13
  6dc6c6:	je     6dc1ce <text_column_public_control::emit_state+0x81e>
  6dc6cc:	movzbl %al,%eax
  6dc6cf:	cmp    $0x3,%eax
  6dc6d2:	je     6dc1c0 <text_column_public_control::emit_state+0x810>
  6dc6d8:	movabs $0x366000002e329,%rax
  6dc6e2:	imul   %rax,%rdi
  6dc6e6:	cmpb   $0x0,0xa8(%rsp)
  6dc6ee:	je     6dc1e8 <text_column_public_control::emit_state+0x838>
  6dc6f4:	mov    0x10(%rsp),%rcx
  6dc6f9:	shl    $0x20,%rcx
  6dc6fd:	mov    0x18(%rsp),%eax
  6dc701:	or     %rcx,%rax
  6dc704:	xor    %rdi,%rax
  6dc707:	imul   %r14,%rax
  6dc70b:	xor    0x1e0(%rsp),%rax
  6dc713:	imul   %r14,%rax
  6dc717:	mov    0xa0(%rsp),%rdi
  6dc71f:	test   %rdi,%rdi
  6dc722:	je     6dc775 <text_column_public_control::emit_state+0xdc5>
  6dc724:	mov    %rdi,%rdx
  6dc727:	and    $0x7,%rdx
  6dc72b:	je     6dc77d <text_column_public_control::emit_state+0xdcd>
  6dc72d:	mov    0x58(%rsp),%rsi
  6dc732:	mov    %rsi,%rcx
  6dc735:	data16 cs nopw 0x0(%rax,%rax,1)
  6dc740:	movzbl (%rcx),%r15d
  6dc744:	inc    %rcx
  6dc747:	xor    %rax,%r15
  6dc74a:	imul   %r14,%r15
  6dc74e:	mov    %r15,%rax
  6dc751:	dec    %rdx
  6dc754:	jne    6dc740 <text_column_public_control::emit_state+0xd90>
  6dc756:	cmp    $0x8,%rdi
  6dc75a:	jb     6dc1ef <text_column_public_control::emit_state+0x83f>
  6dc760:	jmp    6dc792 <text_column_public_control::emit_state+0xde2>
  6dc762:	movabs $0x366000002e329,%rax
  6dc76c:	imul   %rax,%rdi
  6dc770:	jmp    6dc1e8 <text_column_public_control::emit_state+0x838>
  6dc775:	mov    %rax,%r15
  6dc778:	jmp    6dc1ef <text_column_public_control::emit_state+0x83f>
  6dc77d:	mov    %rax,%r15
  6dc780:	mov    0x58(%rsp),%rsi
  6dc785:	mov    %rsi,%rcx
  6dc788:	cmp    $0x8,%rdi
  6dc78c:	jb     6dc1ef <text_column_public_control::emit_state+0x83f>
  6dc792:	add    %rdi,%rsi
  6dc795:	data16 cs nopw 0x0(%rax,%rax,1)
  6dc7a0:	movzbl (%rcx),%eax
  6dc7a3:	xor    %r15,%rax
  6dc7a6:	imul   %r14,%rax
  6dc7aa:	movzbl 0x1(%rcx),%edx
  6dc7ae:	xor    %rax,%rdx
  6dc7b1:	imul   %r14,%rdx
  6dc7b5:	movzbl 0x2(%rcx),%eax
  6dc7b9:	xor    %rdx,%rax
  6dc7bc:	imul   %r14,%rax
  6dc7c0:	movzbl 0x3(%rcx),%edx
  6dc7c4:	xor    %rax,%rdx
  6dc7c7:	imul   %r14,%rdx
  6dc7cb:	movzbl 0x4(%rcx),%eax
  6dc7cf:	xor    %rdx,%rax
  6dc7d2:	imul   %r14,%rax
  6dc7d6:	movzbl 0x5(%rcx),%edx
  6dc7da:	xor    %rax,%rdx
  6dc7dd:	imul   %r14,%rdx
  6dc7e1:	movzbl 0x6(%rcx),%eax
  6dc7e5:	xor    %rdx,%rax
  6dc7e8:	imul   %r14,%rax
  6dc7ec:	movzbl 0x7(%rcx),%r15d
  6dc7f1:	add    $0x8,%rcx
  6dc7f5:	xor    %rax,%r15
  6dc7f8:	imul   %r14,%r15
  6dc7fc:	cmp    %rsi,%rcx
  6dc7ff:	jne    6dc7a0 <text_column_public_control::emit_state+0xdf0>
  6dc801:	jmp    6dc1ef <text_column_public_control::emit_state+0x83f>
  6dc806:	mov    %r15,0x210(%rsp)
  6dc80e:	mov    %rbx,0x28(%rsp)
  6dc813:	mov    0x238(%rsp),%rax
  6dc81b:	test   %rax,%rax
  6dc81e:	je     6dc94c <text_column_public_control::emit_state+0xf9c>
  6dc824:	mov    0x230(%rsp),%rsi
  6dc82c:	mov    %rax,%rcx
  6dc82f:	shl    $0x7,%rcx
  6dc833:	lea    (%rcx,%rax,8),%rcx
  6dc837:	add    $0xffffffffffffff78,%rcx
  6dc83e:	movabs $0xf0f0f0f0f0f0f0f1,%rdx
  6dc848:	mov    %rcx,%rax
  6dc84b:	mul    %rdx
  6dc84e:	shr    $0x7,%rdx
  6dc852:	inc    %rdx
  6dc855:	mov    %edx,%eax
  6dc857:	and    $0x3,%eax
  6dc85a:	cmp    $0x198,%rcx
  6dc861:	jb     6dc914 <text_column_public_control::emit_state+0xf64>
  6dc867:	and    $0xfffffffffffffffc,%rdx
  6dc86b:	jmp    6dc88d <text_column_public_control::emit_state+0xedd>
  6dc86d:	nopl   (%rax)
  6dc870:	add    $0x220,%rsi
  6dc877:	xor    %rcx,%rbx
  6dc87a:	imul   %r14,%rbx
  6dc87e:	mov    %rbx,0x28(%rsp)
  6dc883:	add    $0xfffffffffffffffc,%rdx
  6dc887:	je     6dc90f <text_column_public_control::emit_state+0xf5f>
  6dc88d:	cmpb   $0x0,(%rsi)
  6dc890:	mov    $0xffffffffffffffff,%rcx
  6dc897:	mov    $0xffffffffffffffff,%rdi
  6dc89e:	je     6dc8a4 <text_column_public_control::emit_state+0xef4>
  6dc8a0:	mov    0x8(%rsi),%rdi
  6dc8a4:	xor    %rdi,%rbx
  6dc8a7:	imul   %r14,%rbx
  6dc8ab:	mov    %rbx,0x28(%rsp)
  6dc8b0:	cmpb   $0x0,0x88(%rsi)
  6dc8b7:	mov    $0xffffffffffffffff,%rdi
  6dc8be:	je     6dc8c7 <text_column_public_control::emit_state+0xf17>
  6dc8c0:	mov    0x90(%rsi),%rdi
  6dc8c7:	xor    %rdi,%rbx
  6dc8ca:	imul   %r14,%rbx
  6dc8ce:	mov    %rbx,0x28(%rsp)
  6dc8d3:	cmpb   $0x0,0x110(%rsi)
  6dc8da:	mov    $0xffffffffffffffff,%rdi
  6dc8e1:	je     6dc8ea <text_column_public_control::emit_state+0xf3a>
  6dc8e3:	mov    0x118(%rsi),%rdi
  6dc8ea:	xor    %rdi,%rbx
  6dc8ed:	imul   %r14,%rbx
  6dc8f1:	mov    %rbx,0x28(%rsp)
  6dc8f6:	cmpb   $0x0,0x198(%rsi)
  6dc8fd:	je     6dc870 <text_column_public_control::emit_state+0xec0>
  6dc903:	mov    0x1a0(%rsi),%rcx
  6dc90a:	jmp    6dc870 <text_column_public_control::emit_state+0xec0>
  6dc90f:	test   %rax,%rax
  6dc912:	je     6dc94c <text_column_public_control::emit_state+0xf9c>
  6dc914:	mov    %eax,%ecx
  6dc916:	shl    $0x7,%eax
  6dc919:	lea    (%rax,%rcx,8),%eax
  6dc91c:	xor    %ecx,%ecx
  6dc91e:	jmp    6dc938 <text_column_public_control::emit_state+0xf88>
  6dc920:	xor    %rdx,%rbx
  6dc923:	imul   %r14,%rbx
  6dc927:	mov    %rbx,0x28(%rsp)
  6dc92c:	add    $0x88,%rcx
  6dc933:	cmp    %rcx,%rax
  6dc936:	je     6dc94c <text_column_public_control::emit_state+0xf9c>
  6dc938:	cmpb   $0x0,(%rsi,%rcx,1)
  6dc93c:	mov    $0xffffffffffffffff,%rdx
  6dc943:	je     6dc920 <text_column_public_control::emit_state+0xf70>
  6dc945:	mov    0x8(%rsi,%rcx,1),%rdx
  6dc94a:	jmp    6dc920 <text_column_public_control::emit_state+0xf70>
  6dc94c:	movzbl 0xc8(%rsp),%eax
  6dc954:	shl    $0x3,%eax
  6dc957:	lea    0x347a72(%rip),%rcx        # a243d0 <__frame_dummy_init_array_entry+0x28e0>
  6dc95e:	mov    (%rax,%rcx,1),%rcx
  6dc962:	lea    -0x68bd61(%rip),%rdx        # 50c08 <GCC_except_table0+0x10e64>
  6dc969:	mov    (%rax,%rdx,1),%rax
  6dc96d:	mov    %rcx,0x1a0(%rsp)
  6dc975:	mov    %rax,0x1a8(%rsp)
  6dc97d:	lea    -0x68f4e2(%rip),%rax        # 4d4a2 <GCC_except_table0+0xd6fe>
  6dc984:	lea    -0x68f4ef(%rip),%rcx        # 4d49c <GCC_except_table0+0xd6f8>
  6dc98b:	mov    0xcc(%rsp),%edx
  6dc992:	test   %dl,%dl
  6dc994:	cmovne %rax,%rcx
  6dc998:	movzbl %dl,%eax
  6dc99b:	mov    $0x6,%edx
  6dc9a0:	sub    %rax,%rdx
  6dc9a3:	mov    %rcx,0x88(%rsp)
  6dc9ab:	mov    %rdx,0x90(%rsp)
  6dc9b3:	call   *0x3658a7(%rip)        # a42260 <_DYNAMIC+0x270>
  6dc9b9:	mov    $0x4,%edi
  6dc9be:	mov    $0x1,%esi
  6dc9c3:	call   *0x36589f(%rip)        # a42268 <_DYNAMIC+0x278>
  6dc9c9:	test   %rax,%rax
  6dc9cc:	je     6dcdd2 <text_column_public_control::emit_state+0x1422>
  6dc9d2:	mov    %rax,%rbx
  6dc9d5:	movl   $0x6c6c756e,(%rax)
  6dc9db:	cmpq   $0x0,0x1d8(%rsp)
  6dc9e4:	je     6dca1d <text_column_public_control::emit_state+0x106d>
  6dc9e6:	lea    0xd0(%rsp),%rsi
  6dc9ee:	mov    $0x14,%edx
  6dc9f3:	mov    0x1d0(%rsp),%rdi
  6dc9fb:	call   *0x365a9f(%rip)        # a424a0 <_DYNAMIC+0x4b0>
  6dca01:	mov    %rdx,%r14
  6dca04:	test   %rdx,%rdx
  6dca07:	jns    6dca36 <text_column_public_control::emit_state+0x1086>
  6dca09:	xor    %r13d,%r13d
  6dca0c:	mov    %r13,%rdi
  6dca0f:	mov    %r14,%rsi
  6dca12:	call   *0x3658d0(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  6dca18:	jmp    6dcde2 <text_column_public_control::emit_state+0x1432>
  6dca1d:	movq   $0x4,0x30(%rsp)
  6dca26:	mov    %rbx,0x38(%rsp)
  6dca2b:	movq   $0x4,0x40(%rsp)
  6dca34:	jmp    6dca99 <text_column_public_control::emit_state+0x10e9>
  6dca36:	test   %r14,%r14
  6dca39:	je     6dca71 <text_column_public_control::emit_state+0x10c1>
  6dca3b:	mov    %rax,%r12
  6dca3e:	call   *0x36581c(%rip)        # a42260 <_DYNAMIC+0x270>
  6dca44:	mov    $0x1,%r13d
  6dca4a:	mov    $0x1,%esi
  6dca4f:	mov    %r14,%rdi
  6dca52:	call   *0x365810(%rip)        # a42268 <_DYNAMIC+0x278>
  6dca58:	test   %rax,%rax
  6dca5b:	je     6dca0c <text_column_public_control::emit_state+0x105c>
  6dca5d:	mov    %rax,%r15
  6dca60:	mov    %rax,%rdi
  6dca63:	mov    %r12,%rsi
  6dca66:	mov    %r14,%rdx
  6dca69:	call   *0x365809(%rip)        # a42278 <memcpy@GLIBC_2.14>
  6dca6f:	jmp    6dca77 <text_column_public_control::emit_state+0x10c7>
  6dca71:	mov    $0x1,%r15d
  6dca77:	mov    %r14,0x30(%rsp)
  6dca7c:	mov    %r15,0x38(%rsp)
  6dca81:	mov    %r14,0x40(%rsp)
  6dca86:	mov    $0x4,%esi
  6dca8b:	mov    $0x1,%edx
  6dca90:	mov    %rbx,%rdi
  6dca93:	call   *0x3657bf(%rip)        # a42258 <_DYNAMIC+0x268>
  6dca99:	lea    0x240(%rsp),%rdx
  6dcaa1:	lea    0x248(%rsp),%rcx
  6dcaa9:	lea    0x268(%rsp),%rax
  6dcab1:	lea    0x1a0(%rsp),%rsi
  6dcab9:	mov    %rsi,0xd0(%rsp)
  6dcac1:	lea    0x4a2c8(%rip),%rsi        # 726d90 <<&str as core::fmt::Display>::fmt>
  6dcac8:	mov    %rsi,0xd8(%rsp)
  6dcad0:	lea    0x88(%rsp),%rdi
  6dcad8:	mov    %rdi,0xe0(%rsp)
  6dcae0:	mov    %rsi,0xe8(%rsp)
  6dcae8:	lea    0x270(%rsp),%rdi
  6dcaf0:	mov    %rdi,0xf0(%rsp)
  6dcaf8:	mov    %rsi,0xf8(%rsp)
  6dcb00:	lea    0x1f8(%rsp),%rsi
  6dcb08:	mov    %rsi,0x100(%rsp)
  6dcb10:	mov    0x365991(%rip),%rsi        # a424a8 <_DYNAMIC+0x4b8>
  6dcb17:	mov    %rsi,0x108(%rsp)
  6dcb1f:	lea    0x200(%rsp),%rdi
  6dcb27:	mov    %rdi,0x110(%rsp)
  6dcb2f:	mov    %rsi,0x118(%rsp)
  6dcb37:	lea    0x208(%rsp),%rsi
  6dcb3f:	mov    %rsi,0x120(%rsp)
  6dcb47:	mov    0x365962(%rip),%rsi        # a424b0 <_DYNAMIC+0x4c0>
  6dcb4e:	mov    %rsi,0x128(%rsp)
  6dcb56:	lea    0x28(%rsp),%rdi
  6dcb5b:	mov    %rdi,0x130(%rsp)
  6dcb63:	mov    %rsi,0x138(%rsp)
  6dcb6b:	lea    0x210(%rsp),%rdi
  6dcb73:	mov    %rdi,0x140(%rsp)
  6dcb7b:	mov    %rsi,0x148(%rsp)
  6dcb83:	mov    %rdx,0x150(%rsp)
  6dcb8b:	mov    %rsi,0x158(%rsp)
  6dcb93:	mov    %rcx,0x160(%rsp)
  6dcb9b:	mov    %rsi,0x168(%rsp)
  6dcba3:	lea    0x30(%rsp),%rcx
  6dcba8:	mov    %rcx,0x170(%rsp)
  6dcbb0:	lea    0x4c7a9(%rip),%rcx        # 729360 <<alloc::string::String as core::fmt::Display>::fmt>
  6dcbb7:	mov    %rcx,0x178(%rsp)
  6dcbbf:	mov    %rax,0x180(%rsp)
  6dcbc7:	mov    0x3658ea(%rip),%rax        # a424b8 <_DYNAMIC+0x4c8>
  6dcbce:	mov    %rax,0x188(%rsp)
  6dcbd6:	lea    -0x69909e(%rip),%rdi        # 43b3f <GCC_except_table0+0x3d9b>
  6dcbdd:	lea    0xd0(%rsp),%rsi
  6dcbe5:	call   *0x3658d5(%rip)        # a424c0 <_DYNAMIC+0x4d0>
  6dcbeb:	mov    0x30(%rsp),%rsi
  6dcbf0:	test   %rsi,%rsi
  6dcbf3:	je     6dcc05 <text_column_public_control::emit_state+0x1255>
  6dcbf5:	mov    0x38(%rsp),%rdi
  6dcbfa:	mov    $0x1,%edx
  6dcbff:	call   *0x365653(%rip)        # a42258 <_DYNAMIC+0x268>
  6dcc05:	mov    0x230(%rsp),%rbx
  6dcc0d:	mov    0x238(%rsp),%r14
  6dcc15:	test   %r14,%r14
  6dcc18:	je     6dcc67 <text_column_public_control::emit_state+0x12b7>
  6dcc1a:	lea    0x30(%rbx),%r15
  6dcc1e:	mov    0x365633(%rip),%r12        # a42258 <_DYNAMIC+0x268>
  6dcc25:	jmp    6dcc3c <text_column_public_control::emit_state+0x128c>
  6dcc27:	nopw   0x0(%rax,%rax,1)
  6dcc30:	add    $0x88,%r15
  6dcc37:	dec    %r14
  6dcc3a:	je     6dcc67 <text_column_public_control::emit_state+0x12b7>
  6dcc3c:	mov    -0x20(%r15),%rsi
  6dcc40:	test   %rsi,%rsi
  6dcc43:	je     6dcc51 <text_column_public_control::emit_state+0x12a1>
  6dcc45:	mov    -0x18(%r15),%rdi
  6dcc49:	mov    $0x1,%edx
  6dcc4e:	call   *%r12
  6dcc51:	mov    -0x8(%r15),%rsi
  6dcc55:	test   %rsi,%rsi
  6dcc58:	jle    6dcc30 <text_column_public_control::emit_state+0x1280>
  6dcc5a:	mov    (%r15),%rdi
  6dcc5d:	mov    $0x1,%edx
  6dcc62:	call   *%r12
  6dcc65:	jmp    6dcc30 <text_column_public_control::emit_state+0x1280>
  6dcc67:	mov    0x228(%rsp),%rax
  6dcc6f:	test   %rax,%rax
  6dcc72:	je     6dcc8d <text_column_public_control::emit_state+0x12dd>
  6dcc74:	mov    %rax,%rcx
  6dcc77:	shl    $0x7,%rcx
  6dcc7b:	lea    (%rcx,%rax,8),%rsi
  6dcc7f:	mov    $0x8,%edx
  6dcc84:	mov    %rbx,%rdi
  6dcc87:	call   *0x3655cb(%rip)        # a42258 <_DYNAMIC+0x268>
  6dcc8d:	add    $0x298,%rsp
  6dcc94:	pop    %rbx
  6dcc95:	pop    %r12
  6dcc97:	pop    %r13
  6dcc99:	pop    %r14
  6dcc9b:	pop    %r15
  6dcc9d:	pop    %rbp
  6dcc9e:	ret
  6dcc9f:	lea    0x346592(%rip),%rdi        # a23238 <__frame_dummy_init_array_entry+0x1748>
  6dcca6:	call   *0x36564c(%rip)        # a422f8 <_DYNAMIC+0x308>
  6dccac:	jmp    6dcde2 <text_column_public_control::emit_state+0x1432>
  6dccb1:	lea    -0x69b4c8(%rip),%rdx        # 417f0 <GCC_except_table0+0x1a4c>
  6dccb8:	lea    0x3454a1(%rip),%r9        # a22160 <__frame_dummy_init_array_entry+0x670>
  6dccbf:	lea    0xd0(%rsp),%rsi
  6dccc7:	xor    %edi,%edi
  6dccc9:	xor    %ecx,%ecx
  6dcccb:	call   *0x3657f7(%rip)        # a424c8 <_DYNAMIC+0x4d8>
  6dccd1:	jmp    6dcde2 <text_column_public_control::emit_state+0x1432>
  6dccd6:	mov    %r14,%rdi
  6dccd9:	mov    0x10(%rsp),%rdx
  6dccde:	call   *0x3655a4(%rip)        # a42288 <_DYNAMIC+0x298>
  6dcce4:	jmp    6dcde2 <text_column_public_control::emit_state+0x1432>
  6dcce9:	mov    %rax,%rdi
  6dccec:	lea    0x34658d(%rip),%rax        # a23280 <__frame_dummy_init_array_entry+0x1790>
  6dccf3:	jmp    6dcd24 <text_column_public_control::emit_state+0x1374>
  6dccf5:	lea    0x34656c(%rip),%rax        # a23268 <__frame_dummy_init_array_entry+0x1778>
  6dccfc:	jmp    6dcd24 <text_column_public_control::emit_state+0x1374>
  6dccfe:	mov    $0x1,%edi
  6dcd03:	mov    %r12,%rsi
  6dcd06:	call   *0x3655dc(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  6dcd0c:	jmp    6dcde2 <text_column_public_control::emit_state+0x1432>
  6dcd11:	mov    %rbp,%rdi
  6dcd14:	lea    0x346505(%rip),%rax        # a23220 <__frame_dummy_init_array_entry+0x1730>
  6dcd1b:	jmp    6dcd24 <text_column_public_control::emit_state+0x1374>
  6dcd1d:	lea    0x34652c(%rip),%rax        # a23250 <__frame_dummy_init_array_entry+0x1760>
  6dcd24:	mov    %rax,0x48(%rsp)
  6dcd29:	mov    0x48(%rsp),%rdx
  6dcd2e:	call   *0x365554(%rip)        # a42288 <_DYNAMIC+0x298>
  6dcd34:	jmp    6dcde2 <text_column_public_control::emit_state+0x1432>
  6dcd39:	movq   $0xd,0xd0(%rsp)
  6dcd45:	movq   $0x0,0xd8(%rsp)
  6dcd51:	lea    -0x68f679(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6dcd58:	lea    0x345fc9(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6dcd5f:	lea    0x3458aa(%rip),%r8        # a22610 <__frame_dummy_init_array_entry+0xb20>
  6dcd66:	lea    0xd0(%rsp),%rdx
  6dcd6e:	mov    $0x2b,%esi
  6dcd73:	call   *0x3654b7(%rip)        # a42230 <_DYNAMIC+0x240>
  6dcd79:	jmp    6dcde2 <text_column_public_control::emit_state+0x1432>
  6dcd7b:	mov    %rcx,%rdi
  6dcd7e:	lea    0x3468cb(%rip),%rax        # a23650 <__frame_dummy_init_array_entry+0x1b60>
  6dcd85:	mov    %rax,0x10(%rsp)
  6dcd8a:	jmp    6dccd9 <text_column_public_control::emit_state+0x1329>
  6dcd8f:	test   %sil,%sil
  6dcd92:	mov    $0xe,%eax
  6dcd97:	mov    $0x14,%ecx
  6dcd9c:	cmovne %rax,%rcx
  6dcda0:	mov    %rcx,0xd0(%rsp)
  6dcda8:	lea    -0x68f6d0(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6dcdaf:	lea    0x345f72(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6dcdb6:	lea    0x34586b(%rip),%r8        # a22628 <__frame_dummy_init_array_entry+0xb38>
  6dcdbd:	lea    0xd0(%rsp),%rdx
  6dcdc5:	mov    $0x2b,%esi
  6dcdca:	call   *0x365460(%rip)        # a42230 <_DYNAMIC+0x240>
  6dcdd0:	jmp    6dcde2 <text_column_public_control::emit_state+0x1432>
  6dcdd2:	mov    $0x1,%edi
  6dcdd7:	mov    $0x4,%esi
  6dcddc:	call   *0x365506(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  6dcde2:	ud2
  6dcde4:	mov    %rax,%r15
  6dcde7:	mov    0x30(%rsp),%rsi
  6dcdec:	test   %rsi,%rsi
  6dcdef:	je     6dcf18 <text_column_public_control::emit_state+0x1568>
  6dcdf5:	mov    0x38(%rsp),%rdi
  6dcdfa:	mov    $0x1,%edx
  6dcdff:	call   *0x365453(%rip)        # a42258 <_DYNAMIC+0x268>
  6dce05:	lea    0x218(%rsp),%rdi
  6dce0d:	call   6c5390 <core::ptr::drop_glue::<gpui::runtime::Snapshot>>
  6dce12:	mov    %r15,%rdi
  6dce15:	call   a20740 <_Unwind_Resume@plt>
  6dce1a:	mov    %rax,%r15
  6dce1d:	lea    0xd0(%rsp),%rdi
  6dce25:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6dce2a:	lea    0x218(%rsp),%rdi
  6dce32:	call   6c5390 <core::ptr::drop_glue::<gpui::runtime::Snapshot>>
  6dce37:	mov    %r15,%rdi
  6dce3a:	call   a20740 <_Unwind_Resume@plt>
  6dce3f:	mov    %rax,%r15
  6dce42:	lea    0xd0(%rsp),%rdi
  6dce4a:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6dce4f:	mov    %r15,%rdi
  6dce52:	call   a20740 <_Unwind_Resume@plt>
  6dce57:	mov    %rax,%r15
  6dce5a:	jmp    6dcea0 <text_column_public_control::emit_state+0x14f0>
  6dce5c:	mov    %rax,%r15
  6dce5f:	lea    0xd0(%rsp),%rdi
  6dce67:	call   6c5300 <core::ptr::drop_glue::<gpui::runtime::SnapshotNode>>
  6dce6c:	lea    0x88(%rsp),%rdi
  6dce74:	call   6c1080 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::SnapshotNode>>>
  6dce79:	mov    %r15,%rdi
  6dce7c:	call   a20740 <_Unwind_Resume@plt>
  6dce81:	jmp    6dceea <text_column_public_control::emit_state+0x153a>
  6dce83:	jmp    6dced2 <text_column_public_control::emit_state+0x1522>
  6dce85:	mov    %rax,%r15
  6dce88:	test   %r12,%r12
  6dce8b:	jle    6dcea0 <text_column_public_control::emit_state+0x14f0>
  6dce8d:	mov    $0x1,%edx
  6dce92:	mov    0x50(%rsp),%rdi
  6dce97:	mov    %r12,%rsi
  6dce9a:	call   *0x3653b8(%rip)        # a42258 <_DYNAMIC+0x268>
  6dcea0:	cmpq   $0x0,0x20(%rsp)
  6dcea6:	je     6dced5 <text_column_public_control::emit_state+0x1525>
  6dcea8:	mov    $0x1,%edx
  6dcead:	mov    0x78(%rsp),%rdi
  6dceb2:	mov    0x20(%rsp),%rsi
  6dceb7:	call   *0x36539b(%rip)        # a42258 <_DYNAMIC+0x268>
  6dcebd:	lea    0x88(%rsp),%rdi
  6dcec5:	call   6c1080 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::SnapshotNode>>>
  6dceca:	mov    %r15,%rdi
  6dcecd:	call   a20740 <_Unwind_Resume@plt>
  6dced2:	mov    %rax,%r15
  6dced5:	lea    0x88(%rsp),%rdi
  6dcedd:	call   6c1080 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::SnapshotNode>>>
  6dcee2:	mov    %r15,%rdi
  6dcee5:	call   a20740 <_Unwind_Resume@plt>
  6dceea:	mov    %rax,%r15
  6dceed:	lea    0x218(%rsp),%rdi
  6dcef5:	call   6c5390 <core::ptr::drop_glue::<gpui::runtime::Snapshot>>
  6dcefa:	mov    %r15,%rdi
  6dcefd:	call   a20740 <_Unwind_Resume@plt>
  6dcf02:	mov    %rax,%r15
  6dcf05:	mov    $0x4,%esi
  6dcf0a:	mov    $0x1,%edx
  6dcf0f:	mov    %rbx,%rdi
  6dcf12:	call   *0x365340(%rip)        # a42258 <_DYNAMIC+0x268>
  6dcf18:	lea    0x218(%rsp),%rdi
  6dcf20:	call   6c5390 <core::ptr::drop_glue::<gpui::runtime::Snapshot>>
  6dcf25:	mov    %r15,%rdi
  6dcf28:	call   a20740 <_Unwind_Resume@plt>

text_column_public_control::public_hit code=264 fixed_stack=72

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006dcf30 <text_column_public_control::public_hit>:
  6dcf30:	push   %rbx
  6dcf31:	sub    $0x40,%rsp
  6dcf35:	test   %rdi,%rdi
  6dcf38:	je     6dcfe2 <text_column_public_control::public_hit+0xb2>
  6dcf3e:	mov    %rdi,%rbx
  6dcf41:	cmpb   $0x0,0x74e(%rdi)
  6dcf48:	jne    6dcfe9 <text_column_public_control::public_hit+0xb9>
  6dcf4e:	mov    $0x12,%eax
  6dcf53:	cmpb   $0x1,0x74a(%rbx)
  6dcf5a:	jne    6dcfee <text_column_public_control::public_hit+0xbe>
  6dcf60:	cmpb   $0x0,0x74b(%rbx)
  6dcf67:	jne    6dcfee <text_column_public_control::public_hit+0xbe>
  6dcf6d:	cmpb   $0x0,0x74c(%rbx)
  6dcf74:	je     6dcfee <text_column_public_control::public_hit+0xbe>
  6dcf76:	cmpq   $0xffffffffffffffff,0x5b8(%rbx)
  6dcf7e:	jne    6dcfee <text_column_public_control::public_hit+0xbe>
  6dcf80:	mov    0x690(%rbx),%rcx
  6dcf87:	cmp    0x698(%rbx),%rcx
  6dcf8e:	jne    6dcfee <text_column_public_control::public_hit+0xbe>
  6dcf90:	mov    0x6a8(%rbx),%rcx
  6dcf97:	cmp    0x6a0(%rbx),%rcx
  6dcf9e:	jne    6dcfee <text_column_public_control::public_hit+0xbe>
  6dcfa0:	movss  0x740(%rbx),%xmm2
  6dcfa8:	ucomiss 0x744(%rbx),%xmm2
  6dcfaf:	jne    6dcfee <text_column_public_control::public_hit+0xbe>
  6dcfb1:	jp     6dcfee <text_column_public_control::public_hit+0xbe>
  6dcfb3:	mov    %rbx,%rdi
  6dcfb6:	call   70cd60 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit>
  6dcfbb:	cmp    $0x1,%rax
  6dcfbf:	jne    6dcfda <text_column_public_control::public_hit+0xaa>
  6dcfc1:	add    $0x5e0,%rbx
  6dcfc8:	mov    %rbx,%rdi
  6dcfcb:	mov    %rdx,%rsi
  6dcfce:	call   *0x3654bc(%rip)        # a42490 <_DYNAMIC+0x4a0>
  6dcfd4:	add    $0x40,%rsp
  6dcfd8:	pop    %rbx
  6dcfd9:	ret
  6dcfda:	xor    %eax,%eax
  6dcfdc:	add    $0x40,%rsp
  6dcfe0:	pop    %rbx
  6dcfe1:	ret
  6dcfe2:	mov    $0xd,%eax
  6dcfe7:	jmp    6dcfee <text_column_public_control::public_hit+0xbe>
  6dcfe9:	mov    $0xe,%eax
  6dcfee:	mov    %rax,0x8(%rsp)
  6dcff3:	movq   $0x0,0x10(%rsp)
  6dcffc:	lea    -0x68f924(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6dd003:	lea    0x345d1e(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6dd00a:	lea    0x34562f(%rip),%r8        # a22640 <__frame_dummy_init_array_entry+0xb50>
  6dd011:	lea    0x8(%rsp),%rdx
  6dd016:	mov    $0x2b,%esi
  6dd01b:	call   *0x36520f(%rip)        # a42230 <_DYNAMIC+0x240>
  6dd021:	ud2
  6dd023:	mov    %rax,%rbx
  6dd026:	lea    0x8(%rsp),%rdi
  6dd02b:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6dd030:	mov    %rbx,%rdi
  6dd033:	call   a20740 <_Unwind_Resume@plt>

text_column_public_control::public_query code=1653 fixed_stack=376

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006dd040 <text_column_public_control::public_query>:
  6dd040:	push   %rbp
  6dd041:	push   %r15
  6dd043:	push   %r14
  6dd045:	push   %r13
  6dd047:	push   %r12
  6dd049:	push   %rbx
  6dd04a:	sub    $0x148,%rsp
  6dd051:	test   %rsi,%rsi
  6dd054:	je     6dd64c <text_column_public_control::public_query+0x60c>
  6dd05a:	mov    %rsi,%rbx
  6dd05d:	cmpb   $0x0,0x74e(%rsi)
  6dd064:	jne    6dd653 <text_column_public_control::public_query+0x613>
  6dd06a:	cmpb   $0x1,0x74c(%rbx)
  6dd071:	jne    6dd65a <text_column_public_control::public_query+0x61a>
  6dd077:	mov    0x6c8(%rbx),%rdx
  6dd07e:	mov    0x6a0(%rbx),%r12
  6dd085:	mov    0x5a8(%rbx),%rbp
  6dd08c:	mov    0x5b0(%rbx),%rax
  6dd093:	mov    %rax,0x8(%rsp)
  6dd098:	movups 0x618(%rbx),%xmm1
  6dd09f:	mov    0x640(%rbx),%r13
  6dd0a6:	test   %r13,%r13
  6dd0a9:	mov    %rdi,0x80(%rsp)
  6dd0b1:	je     6dd0f3 <text_column_public_control::public_query+0xb3>
  6dd0b3:	mov    0xe0(%r13),%rax
  6dd0ba:	test   %rax,%rax
  6dd0bd:	je     6dd10f <text_column_public_control::public_query+0xcf>
  6dd0bf:	mov    0x38(%rax),%ecx
  6dd0c2:	mov    %ecx,0x20(%rsp)
  6dd0c6:	movups 0x28(%rax),%xmm0
  6dd0ca:	movaps %xmm0,0x10(%rsp)
  6dd0cf:	movzbl 0x3c(%rax),%r15d
  6dd0d4:	movzbl 0x3f(%rax),%ecx
  6dd0d8:	mov    %cl,0x62(%rsp)
  6dd0dc:	movzwl 0x3d(%rax),%eax
  6dd0e0:	mov    %ax,0x60(%rsp)
  6dd0e5:	mov    0x100(%r13),%rsi
  6dd0ec:	test   %rsi,%rsi
  6dd0ef:	jne    6dd11e <text_column_public_control::public_query+0xde>
  6dd0f1:	jmp    6dd0f6 <text_column_public_control::public_query+0xb6>
  6dd0f3:	mov    $0x2,%r15b
  6dd0f6:	movq   $0x4,0x100(%rsp)
  6dd102:	xorps  %xmm0,%xmm0
  6dd105:	movups %xmm0,0x108(%rsp)
  6dd10d:	jmp    6dd13c <text_column_public_control::public_query+0xfc>
  6dd10f:	mov    $0x2,%r15b
  6dd112:	mov    0x100(%r13),%rsi
  6dd119:	test   %rsi,%rsi
  6dd11c:	je     6dd0f6 <text_column_public_control::public_query+0xb6>
  6dd11e:	lea    0x100(%rsp),%rdi
  6dd126:	mov    %rdx,%r14
  6dd129:	movaps %xmm1,0x50(%rsp)
  6dd12e:	call   *0x365104(%rip)        # a42238 <_DYNAMIC+0x248>
  6dd134:	movaps 0x50(%rsp),%xmm1
  6dd139:	mov    %r14,%rdx
  6dd13c:	movabs $0xcbf29ce484222325,%r14
  6dd146:	add    $0x5e0,%rbx
  6dd14d:	mov    %rbx,0xe0(%rsp)
  6dd155:	mov    %rdx,0xb0(%rsp)
  6dd15d:	mov    %r12,0xb8(%rsp)
  6dd165:	mov    %rbp,0xa0(%rsp)
  6dd16d:	mov    0x8(%rsp),%rcx
  6dd172:	mov    %rcx,0xa8(%rsp)
  6dd17a:	movaps %xmm1,0x90(%rsp)
  6dd182:	mov    %r13,0xc0(%rsp)
  6dd18a:	mov    0x100(%rsp),%rax
  6dd192:	mov    %rax,0xc8(%rsp)
  6dd19a:	mov    0x108(%rsp),%rax
  6dd1a2:	mov    %rax,0xd0(%rsp)
  6dd1aa:	mov    0x110(%rsp),%rax
  6dd1b2:	mov    %rax,0xd8(%rsp)
  6dd1ba:	movaps 0x10(%rsp),%xmm0
  6dd1bf:	movups %xmm0,0xe8(%rsp)
  6dd1c7:	mov    0x20(%rsp),%eax
  6dd1cb:	mov    %eax,0xf8(%rsp)
  6dd1d2:	mov    %r15b,0xfc(%rsp)
  6dd1da:	movzwl 0x60(%rsp),%eax
  6dd1df:	mov    %ax,0xfd(%rsp)
  6dd1e7:	movzbl 0x62(%rsp),%eax
  6dd1ec:	mov    %al,0xff(%rsp)
  6dd1f3:	test   %rcx,%rcx
  6dd1f6:	je     6dd616 <text_column_public_control::public_query+0x5d6>
  6dd1fc:	movabs $0x100000001b3,%r13
  6dd206:	xor    %edx,%edx
  6dd208:	lea    0x10(%rsp),%rdi
  6dd20d:	lea    0x100(%rsp),%r12
  6dd215:	movq   $0x0,(%rsp)
  6dd21d:	mov    %rbp,0x88(%rsp)
  6dd225:	jmp    6dd257 <text_column_public_control::public_query+0x217>
  6dd227:	nopw   0x0(%rax,%rax,1)
  6dd230:	mov    %rbx,%r14
  6dd233:	incq   (%rsp)
  6dd237:	mov    0x88(%rsp),%rbp
  6dd23f:	mov    0x50(%rsp),%rdx
  6dd244:	inc    %rdx
  6dd247:	cmp    0x8(%rsp),%rdx
  6dd24c:	lea    0x10(%rsp),%rdi
  6dd251:	je     6dd61e <text_column_public_control::public_query+0x5de>
  6dd257:	mov    %rdx,%r15
  6dd25a:	shl    $0x6,%r15
  6dd25e:	movzbl 0x3d(%rbp,%r15,1),%eax
  6dd264:	sub    $0x2,%al
  6dd266:	movzbl %al,%eax
  6dd269:	mov    $0x8,%ecx
  6dd26e:	cmovb  %ecx,%eax
  6dd271:	movzbl %al,%eax
  6dd274:	xor    %r14,%rax
  6dd277:	imul   %r13,%rax
  6dd27b:	mov    0x10(%rbp,%r15,1),%ecx
  6dd280:	xor    %rax,%rcx
  6dd283:	mov    0x14(%rbp,%r15,1),%eax
  6dd288:	mov    0x18(%rbp,%r15,1),%r8d
  6dd28d:	mov    0x1c(%rbp,%r15,1),%esi
  6dd292:	imul   %r13,%rcx
  6dd296:	xor    %rax,%rcx
  6dd299:	imul   %r13,%rcx
  6dd29d:	xor    %r8,%rcx
  6dd2a0:	imul   %r13,%rcx
  6dd2a4:	xor    %rsi,%rcx
  6dd2a7:	movabs $0x8a97b0004e7feab,%rax
  6dd2b1:	imul   %rax,%rcx
  6dd2b5:	mov    0x8(%rbp,%r15,1),%ebx
  6dd2ba:	mov    0xc(%rbp,%r15,1),%eax
  6dd2bf:	xor    %rcx,%rbx
  6dd2c2:	imul   %r13,%rbx
  6dd2c6:	xor    %rax,%rbx
  6dd2c9:	imul   %r13,%rbx
  6dd2cd:	lea    0x90(%rsp),%rsi
  6dd2d5:	mov    %rdx,0x50(%rsp)
  6dd2da:	call   *0x364f60(%rip)        # a42240 <_DYNAMIC+0x250>
  6dd2e0:	cmpl   $0x1,0x10(%rsp)
  6dd2e5:	jne    6dd32e <text_column_public_control::public_query+0x2ee>
  6dd2e7:	mov    0x14(%rsp),%eax
  6dd2eb:	mov    0x18(%rsp),%ecx
  6dd2ef:	mov    0x1c(%rsp),%edx
  6dd2f3:	mov    0x20(%rsp),%esi
  6dd2f7:	mov    0x24(%rsp),%edi
  6dd2fb:	mov    0x28(%rsp),%r8d
  6dd300:	xor    $0x1,%rbx
  6dd304:	imul   %r13,%rbx
  6dd308:	xor    %rax,%rbx
  6dd30b:	imul   %r13,%rbx
  6dd30f:	xor    %rcx,%rbx
  6dd312:	imul   %r13,%rbx
  6dd316:	xor    %rdx,%rbx
  6dd319:	imul   %r13,%rbx
  6dd31d:	xor    %rsi,%rbx
  6dd320:	imul   %r13,%rbx
  6dd324:	xor    %rdi,%rbx
  6dd327:	imul   %r13,%rbx
  6dd32b:	xor    %r8,%rbx
  6dd32e:	add    %rbp,%r15
  6dd331:	mov    0x28(%r15),%rcx
  6dd335:	test   %rcx,%rcx
  6dd338:	je     6dd470 <text_column_public_control::public_query+0x430>
  6dd33e:	imul   %r13,%rbx
  6dd342:	mov    (%rcx),%rdx
  6dd345:	mov    %rdx,%rdi
  6dd348:	shr    $1,%rdi
  6dd34b:	movzbl 0x3d(%r15),%r8d
  6dd350:	xor    $0x1,%rbx
  6dd354:	imul   %r13,%rbx
  6dd358:	test   %rdi,%rdi
  6dd35b:	je     6dd480 <text_column_public_control::public_query+0x440>
  6dd361:	lea    0x10(%rcx),%rax
  6dd365:	mov    %rdi,%rsi
  6dd368:	and    $0x7,%rsi
  6dd36c:	lea    0x138(%rsp),%r15
  6dd374:	je     6dd579 <text_column_public_control::public_query+0x539>
  6dd37a:	mov    %rsi,%r10
  6dd37d:	mov    %rax,%r9
  6dd380:	movzbl (%r9),%r14d
  6dd384:	inc    %r9
  6dd387:	xor    %rbx,%r14
  6dd38a:	imul   %r13,%r14
  6dd38e:	mov    %r14,%rbx
  6dd391:	dec    %r10
  6dd394:	jne    6dd380 <text_column_public_control::public_query+0x340>
  6dd396:	add    %rdi,%rcx
  6dd399:	add    $0x10,%rcx
  6dd39d:	cmp    $0x10,%rdx
  6dd3a1:	jb     6dd418 <text_column_public_control::public_query+0x3d8>
  6dd3a3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6dd3b0:	movzbl (%r9),%r10d
  6dd3b4:	xor    %r14,%r10
  6dd3b7:	imul   %r13,%r10
  6dd3bb:	movzbl 0x1(%r9),%r11d
  6dd3c0:	xor    %r10,%r11
  6dd3c3:	imul   %r13,%r11
  6dd3c7:	movzbl 0x2(%r9),%r10d
  6dd3cc:	xor    %r11,%r10
  6dd3cf:	imul   %r13,%r10
  6dd3d3:	movzbl 0x3(%r9),%r11d
  6dd3d8:	xor    %r10,%r11
  6dd3db:	imul   %r13,%r11
  6dd3df:	movzbl 0x4(%r9),%r10d
  6dd3e4:	xor    %r11,%r10
  6dd3e7:	imul   %r13,%r10
  6dd3eb:	movzbl 0x5(%r9),%r11d
  6dd3f0:	xor    %r10,%r11
  6dd3f3:	imul   %r13,%r11
  6dd3f7:	movzbl 0x6(%r9),%r10d
  6dd3fc:	xor    %r11,%r10
  6dd3ff:	imul   %r13,%r10
  6dd403:	movzbl 0x7(%r9),%r14d
  6dd408:	add    $0x8,%r9
  6dd40c:	xor    %r10,%r14
  6dd40f:	imul   %r13,%r14
  6dd413:	cmp    %rcx,%r9
  6dd416:	jne    6dd3b0 <text_column_public_control::public_query+0x370>
  6dd418:	cmp    $0x4,%r8b
  6dd41c:	jne    6dd497 <text_column_public_control::public_query+0x457>
  6dd41e:	xor    $0x1,%r14
  6dd422:	mov    %r14,%r8
  6dd425:	imul   %r13,%r8
  6dd429:	test   $0x7,%dil
  6dd42d:	je     6dd595 <text_column_public_control::public_query+0x555>
  6dd433:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6dd440:	movzbl (%rax),%r14d
  6dd444:	inc    %rax
  6dd447:	xor    %r8,%r14
  6dd44a:	imul   %r13,%r14
  6dd44e:	mov    %r14,%r8
  6dd451:	dec    %rsi
  6dd454:	jne    6dd440 <text_column_public_control::public_query+0x400>
  6dd456:	cmp    $0x10,%rdx
  6dd45a:	mov    0x50(%rsp),%rdx
  6dd45f:	jae    6dd5b0 <text_column_public_control::public_query+0x570>
  6dd465:	jmp    6dd4a0 <text_column_public_control::public_query+0x460>
  6dd467:	nopw   0x0(%rax,%rax,1)
  6dd470:	movabs $0x366000002e329,%rax
  6dd47a:	imul   %rax,%rbx
  6dd47e:	jmp    6dd48c <text_column_public_control::public_query+0x44c>
  6dd480:	xor    %eax,%eax
  6dd482:	cmp    $0x4,%r8b
  6dd486:	sete   %al
  6dd489:	xor    %rax,%rbx
  6dd48c:	mov    %rbx,%r14
  6dd48f:	lea    0x138(%rsp),%r15
  6dd497:	imul   %r13,%r14
  6dd49b:	mov    0x50(%rsp),%rdx
  6dd4a0:	lea    0x60(%rsp),%rdi
  6dd4a5:	lea    0x90(%rsp),%rsi
  6dd4ad:	call   *0x364d95(%rip)        # a42248 <_DYNAMIC+0x258>
  6dd4b3:	cmpq   $0x0,0x60(%rsp)
  6dd4b9:	je     6dd23f <text_column_public_control::public_query+0x1ff>
  6dd4bf:	mov    0x70(%rsp),%rsi
  6dd4c4:	mov    0x78(%rsp),%eax
  6dd4c8:	mov    0x7c(%rsp),%ecx
  6dd4cc:	xor    %rax,%r14
  6dd4cf:	imul   %r13,%r14
  6dd4d3:	xor    %rcx,%r14
  6dd4d6:	imul   %r13,%r14
  6dd4da:	mov    0x48(%rsi),%ebx
  6dd4dd:	xor    %r14,%rbx
  6dd4e0:	imul   %r13,%rbx
  6dd4e4:	mov    %r12,%rdi
  6dd4e7:	call   *0x364d63(%rip)        # a42250 <_DYNAMIC+0x260>
  6dd4ed:	lea    0x10(%rsp),%rdi
  6dd4f2:	mov    %r12,%rsi
  6dd4f5:	mov    %r15,%rdx
  6dd4f8:	call   6d9de0 <<core::iter::adapters::zip::Zip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>, core::iter::adapters::skip::Skip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>>> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::find_map::check<(&[gpui_canvas::text::layout::Stop], &[gpui_canvas::text::layout::Stop]), gpui_canvas::text::layout::interaction::TextGrapheme, &mut <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#1}>::{closure#0}, core::ops::control_flow::ControlFlow<gpui_canvas::text::layout::interaction::TextGrapheme>>>
  6dd4fd:	cmpb   $0x2,0x14(%rsp)
  6dd502:	je     6dd230 <text_column_public_control::public_query+0x1f0>
  6dd508:	lea    0x10(%rsp),%rbp
  6dd50d:	nopl   (%rax)
  6dd510:	mov    0x10(%rsp),%r14d
  6dd515:	mov    0x18(%rsp),%eax
  6dd519:	xor    %rbx,%r14
  6dd51c:	mov    0x20(%rsp),%ecx
  6dd520:	mov    0x24(%rsp),%edx
  6dd524:	mov    0x28(%rsp),%esi
  6dd528:	mov    0x2c(%rsp),%edi
  6dd52c:	imul   %r13,%r14
  6dd530:	xor    %rax,%r14
  6dd533:	imul   %r13,%r14
  6dd537:	xor    %rcx,%r14
  6dd53a:	imul   %r13,%r14
  6dd53e:	xor    %rdx,%r14
  6dd541:	imul   %r13,%r14
  6dd545:	xor    %rsi,%r14
  6dd548:	imul   %r13,%r14
  6dd54c:	xor    %rdi,%r14
  6dd54f:	imul   %r13,%r14
  6dd553:	xor    0x30(%rsp),%r14
  6dd558:	imul   %r13,%r14
  6dd55c:	mov    %rbp,%rdi
  6dd55f:	mov    %r12,%rsi
  6dd562:	mov    %r15,%rdx
  6dd565:	call   6d9de0 <<core::iter::adapters::zip::Zip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>, core::iter::adapters::skip::Skip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>>> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::find_map::check<(&[gpui_canvas::text::layout::Stop], &[gpui_canvas::text::layout::Stop]), gpui_canvas::text::layout::interaction::TextGrapheme, &mut <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#1}>::{closure#0}, core::ops::control_flow::ControlFlow<gpui_canvas::text::layout::interaction::TextGrapheme>>>
  6dd56a:	cmpb   $0x2,0x14(%rsp)
  6dd56f:	mov    %r14,%rbx
  6dd572:	jne    6dd510 <text_column_public_control::public_query+0x4d0>
  6dd574:	jmp    6dd233 <text_column_public_control::public_query+0x1f3>
  6dd579:	mov    %rbx,%r14
  6dd57c:	mov    %rax,%r9
  6dd57f:	add    %rdi,%rcx
  6dd582:	add    $0x10,%rcx
  6dd586:	cmp    $0x10,%rdx
  6dd58a:	jae    6dd3b0 <text_column_public_control::public_query+0x370>
  6dd590:	jmp    6dd418 <text_column_public_control::public_query+0x3d8>
  6dd595:	mov    %r8,%r14
  6dd598:	cmp    $0x10,%rdx
  6dd59c:	mov    0x50(%rsp),%rdx
  6dd5a1:	jb     6dd4a0 <text_column_public_control::public_query+0x460>
  6dd5a7:	nopw   0x0(%rax,%rax,1)
  6dd5b0:	movzbl (%rax),%edi
  6dd5b3:	xor    %r14,%rdi
  6dd5b6:	imul   %r13,%rdi
  6dd5ba:	movzbl 0x1(%rax),%esi
  6dd5be:	xor    %rdi,%rsi
  6dd5c1:	imul   %r13,%rsi
  6dd5c5:	movzbl 0x2(%rax),%edi
  6dd5c9:	xor    %rsi,%rdi
  6dd5cc:	imul   %r13,%rdi
  6dd5d0:	movzbl 0x3(%rax),%esi
  6dd5d4:	xor    %rdi,%rsi
  6dd5d7:	imul   %r13,%rsi
  6dd5db:	movzbl 0x4(%rax),%edi
  6dd5df:	xor    %rsi,%rdi
  6dd5e2:	imul   %r13,%rdi
  6dd5e6:	movzbl 0x5(%rax),%esi
  6dd5ea:	xor    %rdi,%rsi
  6dd5ed:	imul   %r13,%rsi
  6dd5f1:	movzbl 0x6(%rax),%edi
  6dd5f5:	xor    %rsi,%rdi
  6dd5f8:	imul   %r13,%rdi
  6dd5fc:	movzbl 0x7(%rax),%r14d
  6dd601:	add    $0x8,%rax
  6dd605:	xor    %rdi,%r14
  6dd608:	imul   %r13,%r14
  6dd60c:	cmp    %rcx,%rax
  6dd60f:	jne    6dd5b0 <text_column_public_control::public_query+0x570>
  6dd611:	jmp    6dd4a0 <text_column_public_control::public_query+0x460>
  6dd616:	movq   $0x0,(%rsp)
  6dd61e:	mov    0x80(%rsp),%rax
  6dd626:	mov    0x8(%rsp),%rcx
  6dd62b:	mov    %rcx,(%rax)
  6dd62e:	mov    (%rsp),%rcx
  6dd632:	mov    %rcx,0x8(%rax)
  6dd636:	mov    %r14,0x10(%rax)
  6dd63a:	add    $0x148,%rsp
  6dd641:	pop    %rbx
  6dd642:	pop    %r12
  6dd644:	pop    %r13
  6dd646:	pop    %r14
  6dd648:	pop    %r15
  6dd64a:	pop    %rbp
  6dd64b:	ret
  6dd64c:	mov    $0xd,%eax
  6dd651:	jmp    6dd65f <text_column_public_control::public_query+0x61f>
  6dd653:	mov    $0xe,%eax
  6dd658:	jmp    6dd65f <text_column_public_control::public_query+0x61f>
  6dd65a:	mov    $0x12,%eax
  6dd65f:	mov    %rax,0x90(%rsp)
  6dd667:	movq   $0x0,0x98(%rsp)
  6dd673:	lea    -0x68ff9b(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6dd67a:	lea    0x3456a7(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6dd681:	lea    0x3444a0(%rip),%r8        # a21b28 <__frame_dummy_init_array_entry+0x38>
  6dd688:	lea    0x90(%rsp),%rdx
  6dd690:	mov    $0x2b,%esi
  6dd695:	call   *0x364b95(%rip)        # a42230 <_DYNAMIC+0x240>
  6dd69b:	ud2
  6dd69d:	mov    %rax,%rbx
  6dd6a0:	lea    0x90(%rsp),%rdi
  6dd6a8:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6dd6ad:	mov    %rbx,%rdi
  6dd6b0:	call   a20740 <_Unwind_Resume@plt>

text_column_public_control::public_prepare code=316 fixed_stack=152

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006dd6c0 <text_column_public_control::public_prepare>:
  6dd6c0:	push   %rbx
  6dd6c1:	sub    $0x90,%rsp
  6dd6c8:	mov    (%rsi),%rax
  6dd6cb:	test   %rax,%rax
  6dd6ce:	je     6dd7cc <text_column_public_control::public_prepare+0x10c>
  6dd6d4:	add    $0x8,%rsi
  6dd6d8:	mov    %rax,0x40(%rsp)
  6dd6dd:	mov    %rsi,0x48(%rsp)
  6dd6e2:	movq   $0x0,0x50(%rsp)
  6dd6eb:	cmpb   $0x0,0x74e(%rax)
  6dd6f2:	jne    6dd7e0 <text_column_public_control::public_prepare+0x120>
  6dd6f8:	mov    0x690(%rax),%rcx
  6dd6ff:	cmp    $0xffffffffffffffff,%rcx
  6dd703:	je     6dd770 <text_column_public_control::public_prepare+0xb0>
  6dd705:	mov    %rdi,%rbx
  6dd708:	inc    %rcx
  6dd70b:	movss  %xmm0,0x2b8(%rax)
  6dd713:	mov    %rcx,0x690(%rax)
  6dd71a:	incq   0x6e0(%rax)
  6dd721:	movq   $0x0,0x738(%rax)
  6dd72c:	lea    0x8(%rsp),%rdi
  6dd731:	lea    0x40(%rsp),%rsi
  6dd736:	lea    0x50(%rsp),%rcx
  6dd73b:	xor    %edx,%edx
  6dd73d:	xor    %r8d,%r8d
  6dd740:	call   6e6190 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::after_source_changed>
  6dd745:	cmpq   $0xfffffffffffffffe,0x8(%rsp)
  6dd74b:	jne    6dd77a <text_column_public_control::public_prepare+0xba>
  6dd74d:	movups 0x10(%rsp),%xmm0
  6dd752:	movups 0x20(%rsp),%xmm1
  6dd757:	movups 0x30(%rsp),%xmm2
  6dd75c:	movups %xmm2,0x20(%rbx)
  6dd760:	movups %xmm1,0x10(%rbx)
  6dd764:	movups %xmm0,(%rbx)
  6dd767:	add    $0x90,%rsp
  6dd76e:	pop    %rbx
  6dd76f:	ret
  6dd770:	mov    $0x1f,%eax
  6dd775:	mov    %rax,0x8(%rsp)
  6dd77a:	mov    0x38(%rsp),%rax
  6dd77f:	mov    %rax,0x80(%rsp)
  6dd787:	movups 0x8(%rsp),%xmm0
  6dd78c:	movups 0x18(%rsp),%xmm1
  6dd791:	movups 0x28(%rsp),%xmm2
  6dd796:	movaps %xmm2,0x70(%rsp)
  6dd79b:	movaps %xmm1,0x60(%rsp)
  6dd7a0:	movaps %xmm0,0x50(%rsp)
  6dd7a5:	lea    -0x6900cd(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6dd7ac:	lea    0x345575(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6dd7b3:	lea    0x34504e(%rip),%r8        # a22808 <__frame_dummy_init_array_entry+0xd18>
  6dd7ba:	lea    0x50(%rsp),%rdx
  6dd7bf:	mov    $0x2b,%esi
  6dd7c4:	call   *0x364a66(%rip)        # a42230 <_DYNAMIC+0x240>
  6dd7ca:	ud2
  6dd7cc:	movq   $0xd,0x8(%rsp)
  6dd7d5:	movq   $0x0,0x10(%rsp)
  6dd7de:	jmp    6dd77a <text_column_public_control::public_prepare+0xba>
  6dd7e0:	mov    $0xe,%eax
  6dd7e5:	jmp    6dd775 <text_column_public_control::public_prepare+0xb5>
  6dd7e7:	mov    %rax,%rbx
  6dd7ea:	lea    0x50(%rsp),%rdi
  6dd7ef:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6dd7f4:	mov    %rbx,%rdi
  6dd7f7:	call   a20740 <_Unwind_Resume@plt>

text_column_public_control::edit code=7730 fixed_stack=392

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006dd800 <text_column_public_control::edit>:
  6dd800:	push   %rbp
  6dd801:	push   %r15
  6dd803:	push   %r14
  6dd805:	push   %r13
  6dd807:	push   %r12
  6dd809:	push   %rbx
  6dd80a:	sub    $0x158,%rsp
  6dd811:	mov    %rsi,%r14
  6dd814:	mov    %rdi,%rbx
  6dd817:	movzbl %dl,%eax
  6dd81a:	lea    -0x69bd45(%rip),%rsi        # 41adc <GCC_except_table0+0x1d38>
  6dd821:	movslq (%rsi,%rax,4),%rax
  6dd825:	add    %rsi,%rax
  6dd828:	jmp    *%rax
  6dd82a:	xor    %eax,%eax
  6dd82c:	test   $0x1,%r8b
  6dd830:	sete   %al
  6dd833:	lea    -0x69beaa(%rip),%rdx        # 41990 <GCC_except_table0+0x1bec>
  6dd83a:	movss  (%rdx,%rax,4),%xmm0
  6dd83f:	jmp    6ddb3d <text_column_public_control::edit+0x33d>
  6dd844:	and    $0x1,%r8d
  6dd848:	lea    0x12(%r8),%rax
  6dd84c:	test   %r8,%r8
  6dd84f:	lea    -0x690329(%rip),%rdx        # 4d52d <GCC_except_table0+0xd789>
  6dd856:	lea    -0x6903b6(%rip),%rsi        # 4d4a7 <GCC_except_table0+0xd703>
  6dd85d:	cmove  %rdx,%rsi
  6dd861:	mov    %rsi,0x60(%rsp)
  6dd866:	mov    %rax,0x68(%rsp)
  6dd86b:	lea    0x60(%rsp),%rax
  6dd870:	mov    0x68(%rsp),%r12
  6dd875:	test   %r12,%r12
  6dd878:	jns    6de048 <text_column_public_control::edit+0x848>
  6dd87e:	xor    %ebp,%ebp
  6dd880:	mov    %rbp,%rdi
  6dd883:	mov    %r12,%rsi
  6dd886:	call   *0x364a5c(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  6dd88c:	mov    %r8d,%eax
  6dd88f:	and    $0x1,%eax
  6dd892:	shl    $0xe,%eax
  6dd895:	add    $0x4000,%rax
  6dd89b:	movsd  -0x69c173(%rip),%xmm0        # 41730 <GCC_except_table0+0x198c>
  6dd8a3:	not    %r8b
  6dd8a6:	cmp    $0x7,%dl
  6dd8a9:	sete   %dl
  6dd8ac:	and    %r8b,%dl
  6dd8af:	mov    %rax,0x100(%rsp)
  6dd8b7:	movsd  %xmm0,0x108(%rsp)
  6dd8c0:	mov    %dl,0x110(%rsp)
  6dd8c7:	lea    0x100(%rsp),%rax
  6dd8cf:	test   %cl,%cl
  6dd8d1:	je     6de29f <text_column_public_control::edit+0xa9f>
  6dd8d7:	mov    0x100(%rsp),%rax
  6dd8df:	mov    %rax,0x18(%rsp)
  6dd8e4:	mov    0x108(%rsp),%rax
  6dd8ec:	mov    %rax,0x10(%rsp)
  6dd8f1:	movzbl 0x110(%rsp),%eax
  6dd8f9:	mov    %al,0x8(%rsp)
  6dd8fd:	lea    0x111(%rsp),%rax
  6dd905:	mov    0x114(%rsp),%ecx
  6dd90c:	mov    %ecx,0x153(%rsp)
  6dd913:	mov    0x111(%rsp),%ecx
  6dd91a:	mov    %ecx,0x150(%rsp)
  6dd921:	mov    (%r14),%r15
  6dd924:	test   %r15,%r15
  6dd927:	je     6debb2 <text_column_public_control::edit+0x13b2>
  6dd92d:	mov    (%rax),%ecx
  6dd92f:	mov    0x3(%rax),%eax
  6dd932:	mov    %eax,0xcb(%rsp)
  6dd939:	mov    %ecx,0xc8(%rsp)
  6dd940:	mov    0x6d0(%r15),%rax
  6dd947:	cmpb   $0x0,0x78e(%r15)
  6dd94f:	mov    %rax,0x120(%rsp)
  6dd957:	jne    6debef <text_column_public_control::edit+0x13ef>
  6dd95d:	add    $0x8,%r14
  6dd961:	mov    %r14,0x58(%rsp)
  6dd966:	movabs $0x400000001,%r12
  6dd970:	mov    0x248(%r15),%r13
  6dd977:	mov    0x250(%r15),%rbp
  6dd97e:	shl    $0x4,%rbp
  6dd982:	xor    %r14d,%r14d
  6dd985:	data16 cs nopw 0x0(%rax,%rax,1)
  6dd990:	cmp    %r14,%rbp
  6dd993:	je     6de9be <text_column_public_control::edit+0x11be>
  6dd999:	mov    0x0(%r13,%r14,1),%rdi
  6dd99e:	mov    0x8(%r13,%r14,1),%rax
  6dd9a3:	call   *0x18(%rax)
  6dd9a6:	add    $0x10,%r14
  6dd9aa:	cmp    %r12,%rax
  6dd9ad:	jne    6dd990 <text_column_public_control::edit+0x190>
  6dd9af:	mov    -0x10(%r13,%r14,1),%rdi
  6dd9b4:	mov    -0x8(%r13,%r14,1),%rax
  6dd9b9:	lea    0x290(%r15),%rsi
  6dd9c0:	call   *0x28(%rax)
  6dd9c3:	mov    %rax,%rdi
  6dd9c6:	mov    %rdx,%rax
  6dd9c9:	lea    0x345a18(%rip),%rdx        # a233e8 <__frame_dummy_init_array_entry+0x18f8>
  6dd9d0:	lea    0x2b0(%r15),%rsi
  6dd9d7:	call   *0x20(%rax)
  6dd9da:	mov    %r12,0x68(%rsp)
  6dd9df:	mov    0x68(%rsp),%rcx
  6dd9e4:	mov    %rcx,0xd0(%rsp)
  6dd9ec:	mov    0x70(%rsp),%rcx
  6dd9f1:	mov    %rcx,0xd8(%rsp)
  6dd9f9:	test   %al,%al
  6dd9fb:	mov    0x58(%rsp),%rdx
  6dda00:	mov    0x10(%rsp),%rsi
  6dda05:	mov    0x18(%rsp),%rdi
  6dda0a:	je     6dec08 <text_column_public_control::edit+0x1408>
  6dda10:	movq   $0x0,0xd0(%rsp)
  6dda1c:	cmpb   $0x0,0x78e(%r15)
  6dda24:	jne    6dec12 <text_column_public_control::edit+0x1412>
  6dda2a:	mov    0x6d0(%r15),%rax
  6dda31:	inc    %rax
  6dda34:	je     6de68b <text_column_public_control::edit+0xe8b>
  6dda3a:	mov    0x2c8(%r15),%ecx
  6dda41:	cmp    $0xffffffff,%ecx
  6dda44:	je     6de6b4 <text_column_public_control::edit+0xeb4>
  6dda4a:	inc    %ecx
  6dda4c:	mov    %ecx,0x2c8(%r15)
  6dda53:	movzbl 0x8(%rsp),%ecx
  6dda58:	cmp    $0x2,%cl
  6dda5b:	je     6de6c9 <text_column_public_control::edit+0xec9>
  6dda61:	mov    %rdi,0x2b0(%r15)
  6dda68:	mov    %rsi,0x2b8(%r15)
  6dda6f:	mov    %cl,0x2c0(%r15)
  6dda76:	mov    0x150(%rsp),%ecx
  6dda7d:	mov    0x153(%rsp),%esi
  6dda84:	mov    %ecx,0x2c1(%r15)
  6dda8b:	mov    %esi,0x2c4(%r15)
  6dda92:	mov    %rax,0x6d0(%r15)
  6dda99:	incq   0x720(%r15)
  6ddaa0:	movq   $0x0,0x778(%r15)
  6ddaab:	lea    0x20(%rsp),%rdi
  6ddab0:	lea    0xd0(%rsp),%r8
  6ddab8:	mov    %r15,%rsi
  6ddabb:	mov    %r12,%rcx
  6ddabe:	call   6e92a0 <<gpui::runtime::RuntimeMut<text_column_public_control::Model, ()>>::after_source_with_editing>
  6ddac3:	mov    0x20(%rsp),%r13
  6ddac8:	mov    0x28(%rsp),%rax
  6ddacd:	cmp    $0xfffffffffffffffe,%r13
  6ddad1:	jne    6dec1d <text_column_public_control::edit+0x141d>
  6ddad7:	mov    0x40(%rsp),%rcx
  6ddadc:	movzbl 0x48(%rsp),%edx
  6ddae1:	mov    0x49(%rsp),%esi
  6ddae5:	mov    %esi,0xf8(%rsp)
  6ddaec:	mov    0x4c(%rsp),%esi
  6ddaf0:	mov    %esi,0xfb(%rsp)
  6ddaf7:	mov    0x50(%rsp),%rsi
  6ddafc:	movups 0x30(%rsp),%xmm0
  6ddb01:	mov    %rax,(%rbx)
  6ddb04:	movups %xmm0,0x8(%rbx)
  6ddb08:	mov    %rcx,0x18(%rbx)
  6ddb0c:	mov    %dl,0x20(%rbx)
  6ddb0f:	mov    0xf8(%rsp),%eax
  6ddb16:	mov    0xfb(%rsp),%ecx
  6ddb1d:	mov    %eax,0x21(%rbx)
  6ddb20:	mov    %ecx,0x24(%rbx)
  6ddb23:	mov    %rsi,0x28(%rbx)
  6ddb27:	jmp    6de468 <text_column_public_control::edit+0xc68>
  6ddb2c:	and    $0x3,%r8d
  6ddb30:	lea    -0x69ca47(%rip),%rax        # 410f0 <GCC_except_table0+0x134c>
  6ddb37:	movss  (%rax,%r8,4),%xmm0
  6ddb3d:	movaps -0x69c594(%rip),%xmm1        # 415b0 <GCC_except_table0+0x180c>
  6ddb44:	movaps %xmm1,0x100(%rsp)
  6ddb4c:	movss  %xmm0,0x110(%rsp)
  6ddb55:	movl   $0x0,0x114(%rsp)
  6ddb60:	lea    0x100(%rsp),%rax
  6ddb68:	test   %cl,%cl
  6ddb6a:	je     6ddda3 <text_column_public_control::edit+0x5a3>
  6ddb70:	mov    0x100(%rsp),%rax
  6ddb78:	mov    %rax,0x8(%rsp)
  6ddb7d:	mov    0x108(%rsp),%rax
  6ddb85:	mov    %rax,0x10(%rsp)
  6ddb8a:	movzbl 0x110(%rsp),%r12d
  6ddb93:	mov    0x114(%rsp),%eax
  6ddb9a:	mov    %eax,0xcb(%rsp)
  6ddba1:	mov    0x111(%rsp),%eax
  6ddba8:	mov    %eax,0xc8(%rsp)
  6ddbaf:	mov    (%r14),%r15
  6ddbb2:	test   %r15,%r15
  6ddbb5:	je     6deaa8 <text_column_public_control::edit+0x12a8>
  6ddbbb:	mov    %r12b,0x18(%rsp)
  6ddbc0:	cmpb   $0x0,0x78e(%r15)
  6ddbc8:	jne    6deaec <text_column_public_control::edit+0x12ec>
  6ddbce:	add    $0x8,%r14
  6ddbd2:	mov    %r14,0x58(%rsp)
  6ddbd7:	mov    0x6d0(%r15),%rax
  6ddbde:	mov    %rax,0x120(%rsp)
  6ddbe6:	movabs $0x100000001,%r12
  6ddbf0:	mov    0x248(%r15),%r13
  6ddbf7:	mov    0x250(%r15),%rbp
  6ddbfe:	shl    $0x4,%rbp
  6ddc02:	xor    %r14d,%r14d
  6ddc05:	data16 cs nopw 0x0(%rax,%rax,1)
  6ddc10:	cmp    %r14,%rbp
  6ddc13:	je     6de975 <text_column_public_control::edit+0x1175>
  6ddc19:	mov    0x0(%r13,%r14,1),%rdi
  6ddc1e:	mov    0x8(%r13,%r14,1),%rax
  6ddc23:	call   *0x18(%rax)
  6ddc26:	add    $0x10,%r14
  6ddc2a:	cmp    %r12,%rax
  6ddc2d:	jne    6ddc10 <text_column_public_control::edit+0x410>
  6ddc2f:	mov    -0x10(%r13,%r14,1),%rdi
  6ddc34:	mov    -0x8(%r13,%r14,1),%rax
  6ddc39:	lea    0x290(%r15),%rsi
  6ddc40:	call   *0x28(%rax)
  6ddc43:	mov    %rax,%rdi
  6ddc46:	mov    %rdx,%rax
  6ddc49:	lea    0x3457e8(%rip),%rdx        # a23438 <__frame_dummy_init_array_entry+0x1948>
  6ddc50:	lea    0x2e0(%r15),%rsi
  6ddc57:	call   *0x20(%rax)
  6ddc5a:	mov    %r12,0x68(%rsp)
  6ddc5f:	mov    0x68(%rsp),%rcx
  6ddc64:	mov    %rcx,0xd0(%rsp)
  6ddc6c:	mov    0x70(%rsp),%rcx
  6ddc71:	mov    %rcx,0xd8(%rsp)
  6ddc79:	test   %al,%al
  6ddc7b:	mov    0x58(%rsp),%rdx
  6ddc80:	je     6deb0b <text_column_public_control::edit+0x130b>
  6ddc86:	movq   $0x0,0xd0(%rsp)
  6ddc92:	cmpb   $0x0,0x78e(%r15)
  6ddc9a:	jne    6deb15 <text_column_public_control::edit+0x1315>
  6ddca0:	mov    0x6d0(%r15),%rax
  6ddca7:	inc    %rax
  6ddcaa:	je     6de4e5 <text_column_public_control::edit+0xce5>
  6ddcb0:	mov    0x2f8(%r15),%ecx
  6ddcb7:	cmp    $0xffffffff,%ecx
  6ddcba:	je     6de602 <text_column_public_control::edit+0xe02>
  6ddcc0:	inc    %ecx
  6ddcc2:	mov    %ecx,0x2f8(%r15)
  6ddcc9:	mov    0x8(%rsp),%rcx
  6ddcce:	mov    %rcx,0x2e0(%r15)
  6ddcd5:	mov    0x10(%rsp),%rcx
  6ddcda:	mov    %rcx,0x2e8(%r15)
  6ddce1:	movzbl 0x18(%rsp),%ecx
  6ddce6:	mov    %cl,0x2f0(%r15)
  6ddced:	mov    0xc8(%rsp),%ecx
  6ddcf4:	mov    0xcb(%rsp),%esi
  6ddcfb:	mov    %ecx,0x2f1(%r15)
  6ddd02:	mov    %esi,0x2f4(%r15)
  6ddd09:	mov    %rax,0x6d0(%r15)
  6ddd10:	incq   0x720(%r15)
  6ddd17:	movq   $0x0,0x778(%r15)
  6ddd22:	lea    0x20(%rsp),%rdi
  6ddd27:	lea    0xd0(%rsp),%r8
  6ddd2f:	mov    %r15,%rsi
  6ddd32:	mov    %r12,%rcx
  6ddd35:	call   6e92a0 <<gpui::runtime::RuntimeMut<text_column_public_control::Model, ()>>::after_source_with_editing>
  6ddd3a:	mov    0x20(%rsp),%r13
  6ddd3f:	mov    0x28(%rsp),%r14
  6ddd44:	cmp    $0xfffffffffffffffe,%r13
  6ddd48:	jne    6deb20 <text_column_public_control::edit+0x1320>
  6ddd4e:	mov    0x40(%rsp),%rax
  6ddd53:	movzbl 0x48(%rsp),%ecx
  6ddd58:	mov    0x49(%rsp),%edx
  6ddd5c:	mov    %edx,0x130(%rsp)
  6ddd63:	mov    0x4c(%rsp),%edx
  6ddd67:	mov    %edx,0x133(%rsp)
  6ddd6e:	mov    0x50(%rsp),%rdx
  6ddd73:	movups 0x30(%rsp),%xmm0
  6ddd78:	mov    %r14,(%rbx)
  6ddd7b:	movups %xmm0,0x8(%rbx)
  6ddd7f:	mov    %rax,0x18(%rbx)
  6ddd83:	mov    %cl,0x20(%rbx)
  6ddd86:	mov    0x130(%rsp),%eax
  6ddd8d:	mov    0x133(%rsp),%ecx
  6ddd94:	mov    %eax,0x21(%rbx)
  6ddd97:	mov    %ecx,0x24(%rbx)
  6ddd9a:	mov    %rdx,0x28(%rbx)
  6ddd9e:	jmp    6de468 <text_column_public_control::edit+0xc68>
  6ddda3:	mov    (%r14),%r15
  6ddda6:	test   %r15,%r15
  6ddda9:	je     6dead5 <text_column_public_control::edit+0x12d5>
  6dddaf:	movq   $0x0,0xd0(%rsp)
  6dddbb:	cmpb   $0x1,0x78e(%r15)
  6dddc3:	je     6deafd <text_column_public_control::edit+0x12fd>
  6dddc9:	mov    0x6d0(%r15),%rax
  6dddd0:	inc    %rax
  6dddd3:	je     6de47a <text_column_public_control::edit+0xc7a>
  6dddd9:	mov    0x2f8(%r15),%ecx
  6ddde0:	cmp    $0xffffffff,%ecx
  6ddde3:	je     6de5e4 <text_column_public_control::edit+0xde4>
  6ddde9:	add    $0x8,%r14
  6ddded:	inc    %ecx
  6dddef:	mov    %ecx,0x2f8(%r15)
  6dddf6:	movaps 0x100(%rsp),%xmm0
  6dddfe:	movups %xmm0,0x2e0(%r15)
  6dde06:	mov    0x110(%rsp),%rcx
  6dde0e:	mov    %rcx,0x2f0(%r15)
  6dde15:	mov    %rax,0x6d0(%r15)
  6dde1c:	incq   0x720(%r15)
  6dde23:	movq   $0x0,0x778(%r15)
  6dde2e:	lea    0x20(%rsp),%rdi
  6dde33:	lea    0xd0(%rsp),%r8
  6dde3b:	mov    %r15,%rsi
  6dde3e:	mov    %r14,%rdx
  6dde41:	xor    %ecx,%ecx
  6dde43:	call   6e92a0 <<gpui::runtime::RuntimeMut<text_column_public_control::Model, ()>>::after_source_with_editing>
  6dde48:	cmpq   $0xfffffffffffffffe,0x20(%rsp)
  6dde4e:	je     6de44e <text_column_public_control::edit+0xc4e>
  6dde54:	jmp    6de483 <text_column_public_control::edit+0xc83>
  6dde59:	test   %cl,%cl
  6dde5b:	je     6de355 <text_column_public_control::edit+0xb55>
  6dde61:	xor    %eax,%eax
  6dde63:	test   $0x1,%r8b
  6dde67:	sete   %al
  6dde6a:	lea    -0x69d1e1(%rip),%rcx        # 40c90 <GCC_except_table0+0xeec>
  6dde71:	movsd  (%rcx,%rax,8),%xmm0
  6dde76:	movsd  %xmm0,0x60(%rsp)
  6dde7c:	lea    0x60(%rsp),%rax
  6dde81:	movsd  0x60(%rsp),%xmm0
  6dde87:	movsd  %xmm0,0x8(%rsp)
  6dde8d:	mov    (%r14),%r15
  6dde90:	test   %r15,%r15
  6dde93:	je     6dec43 <text_column_public_control::edit+0x1443>
  6dde99:	cmpb   $0x0,0x78e(%r15)
  6ddea1:	jne    6dec5a <text_column_public_control::edit+0x145a>
  6ddea7:	mov    %rax,0x18(%rsp)
  6ddeac:	mov    $0x2,%eax
  6ddeb1:	mov    %rax,0x10(%rsp)
  6ddeb6:	add    $0x8,%r14
  6ddeba:	mov    %r14,0x58(%rsp)
  6ddebf:	mov    0x6d0(%r15),%rax
  6ddec6:	mov    %rax,0x120(%rsp)
  6ddece:	movabs $0x300000001,%r12
  6dded8:	mov    0x248(%r15),%r13
  6ddedf:	mov    0x250(%r15),%rbp
  6ddee6:	shl    $0x4,%rbp
  6ddeea:	xor    %r14d,%r14d
  6ddeed:	nopl   (%rax)
  6ddef0:	cmp    %r14,%rbp
  6ddef3:	je     6dea07 <text_column_public_control::edit+0x1207>
  6ddef9:	mov    0x0(%r13,%r14,1),%rdi
  6ddefe:	mov    0x8(%r13,%r14,1),%rax
  6ddf03:	call   *0x18(%rax)
  6ddf06:	add    $0x10,%r14
  6ddf0a:	cmp    %r12,%rax
  6ddf0d:	jne    6ddef0 <text_column_public_control::edit+0x6f0>
  6ddf0f:	mov    -0x10(%r13,%r14,1),%rdi
  6ddf14:	mov    -0x8(%r13,%r14,1),%rax
  6ddf19:	lea    0x290(%r15),%rsi
  6ddf20:	call   *0x28(%rax)
  6ddf23:	mov    %rax,%rdi
  6ddf26:	mov    %rdx,%rax
  6ddf29:	lea    0x345530(%rip),%rdx        # a23460 <__frame_dummy_init_array_entry+0x1970>
  6ddf30:	lea    0x2d0(%r15),%rsi
  6ddf37:	call   *0x20(%rax)
  6ddf3a:	mov    %r12,0x68(%rsp)
  6ddf3f:	mov    0x68(%rsp),%rcx
  6ddf44:	mov    %rcx,0xd0(%rsp)
  6ddf4c:	mov    0x70(%rsp),%rcx
  6ddf51:	mov    %rcx,0xd8(%rsp)
  6ddf59:	test   %al,%al
  6ddf5b:	mov    0x58(%rsp),%rdx
  6ddf60:	je     6dec6f <text_column_public_control::edit+0x146f>
  6ddf66:	movq   $0x0,0xd0(%rsp)
  6ddf72:	cmpb   $0x0,0x78e(%r15)
  6ddf7a:	jne    6dec79 <text_column_public_control::edit+0x1479>
  6ddf80:	mov    0x6d0(%r15),%rax
  6ddf87:	inc    %rax
  6ddf8a:	je     6de6ec <text_column_public_control::edit+0xeec>
  6ddf90:	mov    0x2d8(%r15),%ecx
  6ddf97:	cmp    $0xffffffff,%ecx
  6ddf9a:	je     6de857 <text_column_public_control::edit+0x1057>
  6ddfa0:	inc    %ecx
  6ddfa2:	mov    %ecx,0x2d8(%r15)
  6ddfa9:	movsd  0x8(%rsp),%xmm0
  6ddfaf:	movsd  %xmm0,0x2d0(%r15)
  6ddfb8:	mov    %rax,0x6d0(%r15)
  6ddfbf:	incq   0x720(%r15)
  6ddfc6:	movq   $0x0,0x778(%r15)
  6ddfd1:	lea    0x20(%rsp),%rdi
  6ddfd6:	lea    0xd0(%rsp),%r8
  6ddfde:	mov    %r15,%rsi
  6ddfe1:	mov    %r12,%rcx
  6ddfe4:	call   6e92a0 <<gpui::runtime::RuntimeMut<text_column_public_control::Model, ()>>::after_source_with_editing>
  6ddfe9:	mov    0x20(%rsp),%r13
  6ddfee:	mov    0x28(%rsp),%r14
  6ddff3:	cmp    $0xfffffffffffffffe,%r13
  6ddff7:	jne    6ded05 <text_column_public_control::edit+0x1505>
  6ddffd:	mov    0x40(%rsp),%rax
  6de002:	movzbl 0x48(%rsp),%ecx
  6de007:	mov    0x49(%rsp),%edx
  6de00b:	mov    %edx,0x138(%rsp)
  6de012:	mov    0x4c(%rsp),%edx
  6de016:	mov    %edx,0x13b(%rsp)
  6de01d:	mov    0x50(%rsp),%rdx
  6de022:	movups 0x30(%rsp),%xmm0
  6de027:	mov    %r14,(%rbx)
  6de02a:	movups %xmm0,0x8(%rbx)
  6de02e:	mov    %rax,0x18(%rbx)
  6de032:	mov    %cl,0x20(%rbx)
  6de035:	mov    0x138(%rsp),%eax
  6de03c:	mov    0x13b(%rsp),%ecx
  6de043:	jmp    6ddd94 <text_column_public_control::edit+0x594>
  6de048:	je     6de371 <text_column_public_control::edit+0xb71>
  6de04e:	mov    %r14,0x58(%rsp)
  6de053:	mov    %ecx,%r14d
  6de056:	mov    0x60(%rsp),%r13
  6de05b:	call   *0x3641ff(%rip)        # a42260 <_DYNAMIC+0x270>
  6de061:	mov    $0x1,%ebp
  6de066:	mov    $0x1,%esi
  6de06b:	mov    %r12,%rdi
  6de06e:	call   *0x3641f4(%rip)        # a42268 <_DYNAMIC+0x278>
  6de074:	test   %rax,%rax
  6de077:	je     6dd880 <text_column_public_control::edit+0x80>
  6de07d:	mov    %rax,%r15
  6de080:	mov    %rax,%rdi
  6de083:	mov    %r13,%rsi
  6de086:	mov    %r12,%rdx
  6de089:	call   *0x3641e9(%rip)        # a42278 <memcpy@GLIBC_2.14>
  6de08f:	mov    %r14d,%ecx
  6de092:	mov    0x58(%rsp),%r14
  6de097:	test   %cl,%cl
  6de099:	mov    %r12,0x8(%rsp)
  6de09e:	je     6de384 <text_column_public_control::edit+0xb84>
  6de0a4:	mov    (%r14),%r13
  6de0a7:	test   %r13,%r13
  6de0aa:	mov    %r15,0x10(%rsp)
  6de0af:	je     6dec84 <text_column_public_control::edit+0x1484>
  6de0b5:	cmpb   $0x0,0x78e(%r13)
  6de0bd:	jne    6decb8 <text_column_public_control::edit+0x14b8>
  6de0c3:	mov    $0x2,%eax
  6de0c8:	mov    %rax,0x18(%rsp)
  6de0cd:	add    $0x8,%r14
  6de0d1:	mov    %r14,0x58(%rsp)
  6de0d6:	mov    0x6d0(%r13),%rax
  6de0dd:	mov    %rax,0x120(%rsp)
  6de0e5:	movabs $0x200000001,%r12
  6de0ef:	mov    0x248(%r13),%rbp
  6de0f6:	mov    0x250(%r13),%r15
  6de0fd:	shl    $0x4,%r15
  6de101:	xor    %r14d,%r14d
  6de104:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6de110:	cmp    %r14,%r15
  6de113:	je     6dea50 <text_column_public_control::edit+0x1250>
  6de119:	mov    0x0(%rbp,%r14,1),%rdi
  6de11e:	mov    0x8(%rbp,%r14,1),%rax
  6de123:	call   *0x18(%rax)
  6de126:	add    $0x10,%r14
  6de12a:	cmp    %r12,%rax
  6de12d:	jne    6de110 <text_column_public_control::edit+0x910>
  6de12f:	mov    -0x10(%rbp,%r14,1),%rdi
  6de134:	mov    -0x8(%rbp,%r14,1),%rax
  6de139:	lea    0x290(%r13),%r14
  6de140:	mov    %r14,%rsi
  6de143:	call   *0x28(%rax)
  6de146:	mov    %rax,%rdi
  6de149:	mov    %rdx,%rax
  6de14c:	lea    0x3452bd(%rip),%rdx        # a23410 <__frame_dummy_init_array_entry+0x1920>
  6de153:	mov    %r14,%rsi
  6de156:	call   *0x20(%rax)
  6de159:	mov    %r12,0x68(%rsp)
  6de15e:	mov    0x68(%rsp),%rcx
  6de163:	mov    %rcx,0xd0(%rsp)
  6de16b:	mov    0x70(%rsp),%rcx
  6de170:	mov    %rcx,0xd8(%rsp)
  6de178:	test   %al,%al
  6de17a:	mov    0x58(%rsp),%r14
  6de17f:	mov    0x10(%rsp),%r15
  6de184:	je     6decfb <text_column_public_control::edit+0x14fb>
  6de18a:	movq   $0x0,0xd0(%rsp)
  6de196:	cmpb   $0x0,0x78e(%r13)
  6de19e:	jne    6decc2 <text_column_public_control::edit+0x14c2>
  6de1a4:	mov    0x6d0(%r13),%r12
  6de1ab:	inc    %r12
  6de1ae:	je     6de875 <text_column_public_control::edit+0x1075>
  6de1b4:	mov    0x2a8(%r13),%eax
  6de1bb:	cmp    $0xffffffff,%eax
  6de1be:	je     6de957 <text_column_public_control::edit+0x1157>
  6de1c4:	inc    %eax
  6de1c6:	mov    %eax,0x2a8(%r13)
  6de1cd:	mov    0x290(%r13),%rsi
  6de1d4:	test   %rsi,%rsi
  6de1d7:	je     6de1eb <text_column_public_control::edit+0x9eb>
  6de1d9:	mov    0x298(%r13),%rdi
  6de1e0:	mov    $0x1,%edx
  6de1e5:	call   *0x36406d(%rip)        # a42258 <_DYNAMIC+0x268>
  6de1eb:	mov    0x8(%rsp),%rax
  6de1f0:	mov    %rax,0x290(%r13)
  6de1f7:	mov    %r15,0x298(%r13)
  6de1fe:	mov    %rax,0x2a0(%r13)
  6de205:	mov    %r12,0x6d0(%r13)
  6de20c:	incq   0x720(%r13)
  6de213:	movq   $0x0,0x778(%r13)
  6de21e:	mov    $0xffffffffffffffff,%r15
  6de225:	lea    0x20(%rsp),%rdi
  6de22a:	movabs $0x200000001,%rcx
  6de234:	lea    0xd0(%rsp),%r8
  6de23c:	mov    %r13,%rsi
  6de23f:	mov    %r14,%rdx
  6de242:	call   6e92a0 <<gpui::runtime::RuntimeMut<text_column_public_control::Model, ()>>::after_source_with_editing>
  6de247:	mov    0x20(%rsp),%r14
  6de24c:	mov    0x28(%rsp),%rbp
  6de251:	cmp    $0xfffffffffffffffe,%r14
  6de255:	jne    6ded70 <text_column_public_control::edit+0x1570>
  6de25b:	mov    0x40(%rsp),%rax
  6de260:	movzbl 0x48(%rsp),%ecx
  6de265:	mov    0x49(%rsp),%edx
  6de269:	movzwl 0x4d(%rsp),%esi
  6de26e:	movzbl 0x4f(%rsp),%edi
  6de273:	mov    0x50(%rsp),%r8
  6de278:	movups 0x30(%rsp),%xmm0
  6de27d:	mov    %rbp,(%rbx)
  6de280:	movups %xmm0,0x8(%rbx)
  6de284:	mov    %rax,0x18(%rbx)
  6de288:	mov    %cl,0x20(%rbx)
  6de28b:	mov    %dil,0x27(%rbx)
  6de28f:	mov    %si,0x25(%rbx)
  6de293:	mov    %edx,0x21(%rbx)
  6de296:	mov    %r8,0x28(%rbx)
  6de29a:	jmp    6de468 <text_column_public_control::edit+0xc68>
  6de29f:	mov    (%r14),%r15
  6de2a2:	test   %r15,%r15
  6de2a5:	je     6debd8 <text_column_public_control::edit+0x13d8>
  6de2ab:	movq   $0x0,0xd0(%rsp)
  6de2b7:	cmpb   $0x1,0x78e(%r15)
  6de2bf:	je     6debfa <text_column_public_control::edit+0x13fa>
  6de2c5:	mov    0x6d0(%r15),%rax
  6de2cc:	inc    %rax
  6de2cf:	je     6de620 <text_column_public_control::edit+0xe20>
  6de2d5:	mov    0x2c8(%r15),%ecx
  6de2dc:	cmp    $0xffffffff,%ecx
  6de2df:	je     6de696 <text_column_public_control::edit+0xe96>
  6de2e5:	add    $0x8,%r14
  6de2e9:	inc    %ecx
  6de2eb:	mov    %ecx,0x2c8(%r15)
  6de2f2:	movups 0x100(%rsp),%xmm0
  6de2fa:	movups %xmm0,0x2b0(%r15)
  6de302:	mov    0x110(%rsp),%rcx
  6de30a:	mov    %rcx,0x2c0(%r15)
  6de311:	mov    %rax,0x6d0(%r15)
  6de318:	incq   0x720(%r15)
  6de31f:	movq   $0x0,0x778(%r15)
  6de32a:	lea    0x20(%rsp),%rdi
  6de32f:	lea    0xd0(%rsp),%r8
  6de337:	mov    %r15,%rsi
  6de33a:	mov    %r14,%rdx
  6de33d:	xor    %ecx,%ecx
  6de33f:	call   6e92a0 <<gpui::runtime::RuntimeMut<text_column_public_control::Model, ()>>::after_source_with_editing>
  6de344:	cmpq   $0xfffffffffffffffe,0x20(%rsp)
  6de34a:	je     6de44e <text_column_public_control::edit+0xc4e>
  6de350:	jmp    6de629 <text_column_public_control::edit+0xe29>
  6de355:	mov    $0x8000,%eax
  6de35a:	test   $0x1,%r8b
  6de35e:	jne    6dd89b <text_column_public_control::edit+0x9b>
  6de364:	movsd  -0x69caec(%rip),%xmm0        # 41880 <GCC_except_table0+0x1adc>
  6de36c:	jmp    6dd8a3 <text_column_public_control::edit+0xa3>
  6de371:	mov    $0x1,%r15d
  6de377:	test   %cl,%cl
  6de379:	mov    %r12,0x8(%rsp)
  6de37e:	jne    6de0a4 <text_column_public_control::edit+0x8a4>
  6de384:	mov    (%r14),%r13
  6de387:	test   %r13,%r13
  6de38a:	je     6dec9b <text_column_public_control::edit+0x149b>
  6de390:	movq   $0x0,0xd0(%rsp)
  6de39c:	cmpb   $0x0,0x78e(%r13)
  6de3a4:	jne    6deccd <text_column_public_control::edit+0x14cd>
  6de3aa:	mov    0x6d0(%r13),%r12
  6de3b1:	inc    %r12
  6de3b4:	je     6de7df <text_column_public_control::edit+0xfdf>
  6de3ba:	mov    0x2a8(%r13),%eax
  6de3c1:	cmp    $0xffffffff,%eax
  6de3c4:	je     6de939 <text_column_public_control::edit+0x1139>
  6de3ca:	add    $0x8,%r14
  6de3ce:	inc    %eax
  6de3d0:	mov    %eax,0x2a8(%r13)
  6de3d7:	mov    0x290(%r13),%rsi
  6de3de:	test   %rsi,%rsi
  6de3e1:	je     6de3f5 <text_column_public_control::edit+0xbf5>
  6de3e3:	mov    0x298(%r13),%rdi
  6de3ea:	mov    $0x1,%edx
  6de3ef:	call   *0x363e63(%rip)        # a42258 <_DYNAMIC+0x268>
  6de3f5:	mov    0x8(%rsp),%rax
  6de3fa:	mov    %rax,0x290(%r13)
  6de401:	mov    %r15,0x298(%r13)
  6de408:	mov    %rax,0x2a0(%r13)
  6de40f:	mov    %r12,0x6d0(%r13)
  6de416:	incq   0x720(%r13)
  6de41d:	movq   $0x0,0x778(%r13)
  6de428:	lea    0x20(%rsp),%rdi
  6de42d:	lea    0xd0(%rsp),%r8
  6de435:	mov    %r13,%rsi
  6de438:	mov    %r14,%rdx
  6de43b:	xor    %ecx,%ecx
  6de43d:	call   6e92a0 <<gpui::runtime::RuntimeMut<text_column_public_control::Model, ()>>::after_source_with_editing>
  6de442:	cmpq   $0xfffffffffffffffe,0x20(%rsp)
  6de448:	jne    6de7f5 <text_column_public_control::edit+0xff5>
  6de44e:	movups 0x28(%rsp),%xmm0
  6de453:	movups 0x38(%rsp),%xmm1
  6de458:	movups 0x48(%rsp),%xmm2
  6de45d:	movups %xmm2,0x20(%rbx)
  6de461:	movups %xmm1,0x10(%rbx)
  6de465:	movups %xmm0,(%rbx)
  6de468:	add    $0x158,%rsp
  6de46f:	pop    %rbx
  6de470:	pop    %r12
  6de472:	pop    %r13
  6de474:	pop    %r14
  6de476:	pop    %r15
  6de478:	pop    %rbp
  6de479:	ret
  6de47a:	movq   $0x1f,0x20(%rsp)
  6de483:	mov    0x50(%rsp),%rax
  6de488:	mov    %rax,0x90(%rsp)
  6de490:	mov    0x20(%rsp),%rax
  6de495:	mov    0x28(%rsp),%rcx
  6de49a:	movups 0x30(%rsp),%xmm0
  6de49f:	movups 0x40(%rsp),%xmm1
  6de4a4:	movaps %xmm1,0x80(%rsp)
  6de4ac:	movaps %xmm0,0x70(%rsp)
  6de4b1:	mov    %rax,0x60(%rsp)
  6de4b6:	mov    %rcx,0x68(%rsp)
  6de4bb:	lea    -0x690de3(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6de4c2:	lea    0x34485f(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6de4c9:	lea    0x344350(%rip),%r8        # a22820 <__frame_dummy_init_array_entry+0xd30>
  6de4d0:	lea    0x60(%rsp),%rdx
  6de4d5:	mov    $0x2b,%esi
  6de4da:	call   *0x363d50(%rip)        # a42230 <_DYNAMIC+0x240>
  6de4e0:	jmp    6df532 <text_column_public_control::edit+0x1d32>
  6de4e5:	mov    $0x1f,%r13d
  6de4eb:	movzbl 0x18(%rsp),%r12d
  6de4f1:	mov    0x30(%rsp),%r8
  6de4f6:	mov    0x38(%rsp),%r9
  6de4fb:	mov    0xc8(%rsp),%ecx
  6de502:	mov    0xcb(%rsp),%edx
  6de509:	mov    %edx,0x12b(%rsp)
  6de510:	mov    %ecx,0x128(%rsp)
  6de517:	mov    $0x2,%esi
  6de51c:	mov    %rsi,0x60(%rsp)
  6de521:	mov    %r13,0x68(%rsp)
  6de526:	mov    %rax,0x70(%rsp)
  6de52b:	mov    %r8,0x78(%rsp)
  6de530:	mov    %r9,0x80(%rsp)
  6de538:	mov    %dil,0x88(%rsp)
  6de540:	mov    0x130(%rsp),%eax
  6de547:	mov    0x133(%rsp),%esi
  6de54e:	mov    %eax,0x89(%rsp)
  6de555:	mov    %esi,0x8c(%rsp)
  6de55c:	mov    %r11,0x90(%rsp)
  6de564:	mov    %r10,0x98(%rsp)
  6de56c:	mov    0x8(%rsp),%rax
  6de571:	mov    %rax,0xa0(%rsp)
  6de579:	mov    0x10(%rsp),%rax
  6de57e:	mov    %rax,0xa8(%rsp)
  6de586:	mov    %r12b,0xb0(%rsp)
  6de58e:	mov    0x128(%rsp),%eax
  6de595:	mov    0x12b(%rsp),%esi
  6de59c:	mov    %eax,0xb1(%rsp)
  6de5a3:	mov    %esi,0xb4(%rsp)
  6de5aa:	mov    %rcx,0xb8(%rsp)
  6de5b2:	mov    %rdx,0xc0(%rsp)
  6de5ba:	lea    -0x690ee2(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6de5c1:	lea    0x3447c0(%rip),%rcx        # a22d88 <__frame_dummy_init_array_entry+0x1298>
  6de5c8:	lea    0x344291(%rip),%r8        # a22860 <__frame_dummy_init_array_entry+0xd70>
  6de5cf:	lea    0x60(%rsp),%rdx
  6de5d4:	mov    $0x2b,%esi
  6de5d9:	call   *0x363c51(%rip)        # a42230 <_DYNAMIC+0x240>
  6de5df:	jmp    6df532 <text_column_public_control::edit+0x1d32>
  6de5e4:	lea    -0x68df1d(%rip),%rdi        # 506ce <GCC_except_table0+0x1092a>
  6de5eb:	lea    0x3458f6(%rip),%rdx        # a23ee8 <__frame_dummy_init_array_entry+0x23f8>
  6de5f2:	mov    $0x19,%esi
  6de5f7:	call   *0x363dfb(%rip)        # a423f8 <_DYNAMIC+0x408>
  6de5fd:	jmp    6df532 <text_column_public_control::edit+0x1d32>
  6de602:	lea    -0x68df3b(%rip),%rdi        # 506ce <GCC_except_table0+0x1092a>
  6de609:	lea    0x3458d8(%rip),%rdx        # a23ee8 <__frame_dummy_init_array_entry+0x23f8>
  6de610:	mov    $0x19,%esi
  6de615:	call   *0x363ddd(%rip)        # a423f8 <_DYNAMIC+0x408>
  6de61b:	jmp    6df532 <text_column_public_control::edit+0x1d32>
  6de620:	movq   $0x1f,0x20(%rsp)
  6de629:	mov    0x50(%rsp),%rax
  6de62e:	mov    %rax,0x90(%rsp)
  6de636:	mov    0x20(%rsp),%rax
  6de63b:	mov    0x28(%rsp),%rcx
  6de640:	movups 0x30(%rsp),%xmm0
  6de645:	movups 0x40(%rsp),%xmm1
  6de64a:	movaps %xmm1,0x80(%rsp)
  6de652:	movaps %xmm0,0x70(%rsp)
  6de657:	mov    %rax,0x60(%rsp)
  6de65c:	mov    %rcx,0x68(%rsp)
  6de661:	lea    -0x690f89(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6de668:	lea    0x3446b9(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6de66f:	lea    0x34429a(%rip),%r8        # a22910 <__frame_dummy_init_array_entry+0xe20>
  6de676:	lea    0x60(%rsp),%rdx
  6de67b:	mov    $0x2b,%esi
  6de680:	call   *0x363baa(%rip)        # a42230 <_DYNAMIC+0x240>
  6de686:	jmp    6df532 <text_column_public_control::edit+0x1d32>
  6de68b:	mov    $0x1f,%r13d
  6de691:	jmp    6df342 <text_column_public_control::edit+0x1b42>
  6de696:	lea    -0x68dfcf(%rip),%rdi        # 506ce <GCC_except_table0+0x1092a>
  6de69d:	lea    0x345844(%rip),%rdx        # a23ee8 <__frame_dummy_init_array_entry+0x23f8>
  6de6a4:	mov    $0x19,%esi
  6de6a9:	call   *0x363d49(%rip)        # a423f8 <_DYNAMIC+0x408>
  6de6af:	jmp    6df532 <text_column_public_control::edit+0x1d32>
  6de6b4:	lea    0x34582d(%rip),%rdx        # a23ee8 <__frame_dummy_init_array_entry+0x23f8>
  6de6bb:	mov    $0x19,%esi
  6de6c0:	lea    -0x68dff9(%rip),%rdi        # 506ce <GCC_except_table0+0x1092a>
  6de6c7:	jmp    6de6e1 <text_column_public_control::edit+0xee1>
  6de6c9:	lea    0x343a48(%rip),%rdx        # a22118 <__frame_dummy_init_array_entry+0x628>
  6de6d0:	mov    $0x1b,%esi
  6de6d5:	lea    -0x691301(%rip),%rdi        # 4d3db <GCC_except_table0+0xd637>
  6de6dc:	movb   $0x2,0x8(%rsp)
  6de6e1:	call   *0x363d11(%rip)        # a423f8 <_DYNAMIC+0x408>
  6de6e7:	jmp    6df532 <text_column_public_control::edit+0x1d32>
  6de6ec:	mov    $0x1f,%r13d
  6de6f2:	movsd  0x30(%rsp),%xmm0
  6de6f8:	mov    0x38(%rsp),%r9
  6de6fd:	mov    0x60(%rsp),%ecx
  6de701:	mov    0x63(%rsp),%edx
  6de705:	mov    %ecx,0xd0(%rsp)
  6de70c:	mov    %edx,0xd3(%rsp)
  6de713:	mov    0x10(%rsp),%rbx
  6de718:	mov    %rbx,0x60(%rsp)
  6de71d:	mov    %r13,0x68(%rsp)
  6de722:	mov    %rax,0x70(%rsp)
  6de727:	movsd  %xmm0,0x78(%rsp)
  6de72d:	mov    %r9,0x80(%rsp)
  6de735:	mov    %r8b,0x88(%rsp)
  6de73d:	mov    0x138(%rsp),%eax
  6de744:	mov    0x13b(%rsp),%r8d
  6de74c:	mov    %eax,0x89(%rsp)
  6de753:	mov    %r8d,0x8c(%rsp)
  6de75b:	mov    %r10,0x90(%rsp)
  6de763:	mov    %r11,0x98(%rsp)
  6de76b:	movsd  0x8(%rsp),%xmm0
  6de771:	movsd  %xmm0,0xa0(%rsp)
  6de77a:	mov    %rdi,0xa8(%rsp)
  6de782:	mov    %cl,0xb0(%rsp)
  6de789:	mov    0xd0(%rsp),%eax
  6de790:	mov    0xd3(%rsp),%ecx
  6de797:	mov    %eax,0xb1(%rsp)
  6de79e:	mov    %ecx,0xb4(%rsp)
  6de7a5:	mov    %rdx,0xb8(%rsp)
  6de7ad:	mov    %rsi,0xc0(%rsp)
  6de7b5:	lea    -0x6910dd(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6de7bc:	lea    0x3445e5(%rip),%rcx        # a22da8 <__frame_dummy_init_array_entry+0x12b8>
  6de7c3:	lea    0x34412e(%rip),%r8        # a228f8 <__frame_dummy_init_array_entry+0xe08>
  6de7ca:	lea    0x60(%rsp),%rdx
  6de7cf:	mov    $0x2b,%esi
  6de7d4:	call   *0x363a56(%rip)        # a42230 <_DYNAMIC+0x240>
  6de7da:	jmp    6df532 <text_column_public_control::edit+0x1d32>
  6de7df:	mov    $0x1f,%eax
  6de7e4:	mov    %rax,0x20(%rsp)
  6de7e9:	cmpq   $0x0,0x8(%rsp)
  6de7ef:	jne    6dece3 <text_column_public_control::edit+0x14e3>
  6de7f5:	mov    0x50(%rsp),%rax
  6de7fa:	mov    %rax,0x90(%rsp)
  6de802:	mov    0x20(%rsp),%rax
  6de807:	mov    0x28(%rsp),%rcx
  6de80c:	movups 0x30(%rsp),%xmm0
  6de811:	movups 0x40(%rsp),%xmm1
  6de816:	movaps %xmm1,0x80(%rsp)
  6de81e:	movaps %xmm0,0x70(%rsp)
  6de823:	mov    %rax,0x60(%rsp)
  6de828:	mov    %rcx,0x68(%rsp)
  6de82d:	lea    -0x691155(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6de834:	lea    0x3444ed(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6de83b:	lea    0x344036(%rip),%r8        # a22878 <__frame_dummy_init_array_entry+0xd88>
  6de842:	lea    0x60(%rsp),%rdx
  6de847:	mov    $0x2b,%esi
  6de84c:	call   *0x3639de(%rip)        # a42230 <_DYNAMIC+0x240>
  6de852:	jmp    6df532 <text_column_public_control::edit+0x1d32>
  6de857:	lea    -0x68e190(%rip),%rdi        # 506ce <GCC_except_table0+0x1092a>
  6de85e:	lea    0x345683(%rip),%rdx        # a23ee8 <__frame_dummy_init_array_entry+0x23f8>
  6de865:	mov    $0x19,%esi
  6de86a:	call   *0x363b88(%rip)        # a423f8 <_DYNAMIC+0x408>
  6de870:	jmp    6df532 <text_column_public_control::edit+0x1d32>
  6de875:	mov    $0x1f,%r14d
  6de87b:	mov    0x8(%rsp),%r12
  6de880:	mov    0x18(%rsp),%r15
  6de885:	mov    %r15,0x60(%rsp)
  6de88a:	mov    %r14,0x68(%rsp)
  6de88f:	mov    %rsi,0x70(%rsp)
  6de894:	mov    %r9,0x78(%rsp)
  6de899:	mov    %rdi,0x80(%rsp)
  6de8a1:	mov    %r8b,0x88(%rsp)
  6de8a9:	mov    %r11d,0x89(%rsp)
  6de8b1:	mov    %r11,%rsi
  6de8b4:	shr    $0x30,%rsi
  6de8b8:	mov    %sil,0x8f(%rsp)
  6de8c0:	shr    $0x20,%r11
  6de8c4:	mov    %r11w,0x8d(%rsp)
  6de8cd:	mov    %rbx,0x90(%rsp)
  6de8d5:	mov    %r10,0x98(%rsp)
  6de8dd:	mov    %r12,0xa0(%rsp)
  6de8e5:	mov    0x10(%rsp),%rdx
  6de8ea:	mov    %rdx,0xa8(%rsp)
  6de8f2:	mov    0x8(%rsp),%rdx
  6de8f7:	mov    %rdx,0xb0(%rsp)
  6de8ff:	mov    %rcx,0xb8(%rsp)
  6de907:	mov    %rax,0xc0(%rsp)
  6de90f:	lea    -0x691237(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6de916:	lea    0x34444b(%rip),%rcx        # a22d68 <__frame_dummy_init_array_entry+0x1278>
  6de91d:	lea    0x343f94(%rip),%r8        # a228b8 <__frame_dummy_init_array_entry+0xdc8>
  6de924:	lea    0x60(%rsp),%rdx
  6de929:	mov    $0x2b,%esi
  6de92e:	call   *0x3638fc(%rip)        # a42230 <_DYNAMIC+0x240>
  6de934:	jmp    6df532 <text_column_public_control::edit+0x1d32>
  6de939:	lea    -0x68e272(%rip),%rdi        # 506ce <GCC_except_table0+0x1092a>
  6de940:	lea    0x3455a1(%rip),%rdx        # a23ee8 <__frame_dummy_init_array_entry+0x23f8>
  6de947:	mov    $0x19,%esi
  6de94c:	call   *0x363aa6(%rip)        # a423f8 <_DYNAMIC+0x408>
  6de952:	jmp    6df532 <text_column_public_control::edit+0x1d32>
  6de957:	lea    -0x68e290(%rip),%rdi        # 506ce <GCC_except_table0+0x1092a>
  6de95e:	lea    0x345583(%rip),%rdx        # a23ee8 <__frame_dummy_init_array_entry+0x23f8>
  6de965:	mov    $0x19,%esi
  6de96a:	call   *0x363a88(%rip)        # a423f8 <_DYNAMIC+0x408>
  6de970:	jmp    6df532 <text_column_public_control::edit+0x1d32>
  6de975:	mov    %r12,0x68(%rsp)
  6de97a:	mov    0x68(%rsp),%rax
  6de97f:	mov    %rax,0xd0(%rsp)
  6de987:	mov    0x70(%rsp),%rax
  6de98c:	mov    %rax,0xd8(%rsp)
  6de994:	mov    $0xb,%eax
  6de999:	mov    0xd0(%rsp),%rcx
  6de9a1:	mov    %rcx,0x30(%rsp)
  6de9a6:	mov    0xd8(%rsp),%rcx
  6de9ae:	mov    %rcx,0x38(%rsp)
  6de9b3:	mov    $0x20,%r13d
  6de9b9:	jmp    6de4eb <text_column_public_control::edit+0xceb>
  6de9be:	mov    %r12,0x68(%rsp)
  6de9c3:	mov    0x68(%rsp),%rax
  6de9c8:	mov    %rax,0xd0(%rsp)
  6de9d0:	mov    0x70(%rsp),%rax
  6de9d5:	mov    %rax,0xd8(%rsp)
  6de9dd:	mov    $0xb,%eax
  6de9e2:	mov    0xd0(%rsp),%rcx
  6de9ea:	mov    %rcx,0x30(%rsp)
  6de9ef:	mov    0xd8(%rsp),%rcx
  6de9f7:	mov    %rcx,0x38(%rsp)
  6de9fc:	mov    $0x20,%r13d
  6dea02:	jmp    6df342 <text_column_public_control::edit+0x1b42>
  6dea07:	mov    %r12,0x68(%rsp)
  6dea0c:	mov    0x68(%rsp),%rax
  6dea11:	mov    %rax,0xd0(%rsp)
  6dea19:	mov    0x70(%rsp),%rax
  6dea1e:	mov    %rax,0xd8(%rsp)
  6dea26:	mov    $0xb,%eax
  6dea2b:	mov    0xd0(%rsp),%rcx
  6dea33:	mov    %rcx,0x30(%rsp)
  6dea38:	mov    0xd8(%rsp),%rcx
  6dea40:	mov    %rcx,0x38(%rsp)
  6dea45:	mov    $0x20,%r13d
  6dea4b:	jmp    6de6f2 <text_column_public_control::edit+0xef2>
  6dea50:	mov    %r12,0x68(%rsp)
  6dea55:	mov    0x68(%rsp),%rax
  6dea5a:	mov    %rax,0xd0(%rsp)
  6dea62:	mov    0x70(%rsp),%rax
  6dea67:	mov    %rax,0xd8(%rsp)
  6dea6f:	mov    $0xb,%esi
  6dea74:	mov    0xd0(%rsp),%rax
  6dea7c:	mov    %rax,0x30(%rsp)
  6dea81:	mov    0xd8(%rsp),%rax
  6dea89:	mov    %rax,0x38(%rsp)
  6dea8e:	mov    0x30(%rsp),%r9
  6dea93:	mov    0x38(%rsp),%rdi
  6dea98:	mov    $0x20,%r14d
  6dea9e:	mov    0x8(%rsp),%r12
  6deaa3:	jmp    6de880 <text_column_public_control::edit+0x1080>
  6deaa8:	lea    0x111(%rsp),%rax
  6deab0:	mov    (%rax),%ecx
  6deab2:	mov    0x3(%rax),%eax
  6deab5:	mov    %eax,0x12b(%rsp)
  6deabc:	mov    %ecx,0x128(%rsp)
  6deac3:	mov    $0xd,%r13d
  6deac9:	xor    %eax,%eax
  6deacb:	mov    $0x2,%esi
  6dead0:	jmp    6de51c <text_column_public_control::edit+0xd1c>
  6dead5:	movq   $0xd,0x20(%rsp)
  6deade:	movq   $0x0,0x28(%rsp)
  6deae7:	jmp    6de483 <text_column_public_control::edit+0xc83>
  6deaec:	mov    $0xe,%r13d
  6deaf2:	movzbl 0x18(%rsp),%r12d
  6deaf8:	jmp    6de4fb <text_column_public_control::edit+0xcfb>
  6deafd:	movq   $0xe,0x20(%rsp)
  6deb06:	jmp    6de483 <text_column_public_control::edit+0xc83>
  6deb0b:	mov    $0xa,%eax
  6deb10:	jmp    6de999 <text_column_public_control::edit+0x1199>
  6deb15:	mov    $0xe,%r13d
  6deb1b:	jmp    6de4eb <text_column_public_control::edit+0xceb>
  6deb20:	movzbl 0x40(%rsp),%r12d
  6deb26:	mov    0x48(%rsp),%rcx
  6deb2b:	mov    0x50(%rsp),%rdx
  6deb30:	mov    0x30(%rsp),%rax
  6deb35:	mov    %rax,0x8(%rsp)
  6deb3a:	mov    0x38(%rsp),%rax
  6deb3f:	mov    %rax,0x10(%rsp)
  6deb44:	lea    0x41(%rsp),%rbx
  6deb49:	mov    0x6d0(%r15),%rax
  6deb50:	cmp    0x120(%rsp),%rax
  6deb58:	jne    6deb82 <text_column_public_control::edit+0x1382>
  6deb5a:	mov    $0x4,%esi
  6deb5f:	lea    0x130(%rsp),%r15
  6deb67:	mov    %rdx,%r10
  6deb6a:	mov    %rcx,%r11
  6deb6d:	mov    %r14,%rax
  6deb70:	mov    0x8(%rsp),%r8
  6deb75:	mov    0x10(%rsp),%r9
  6deb7a:	mov    %r12d,%edi
  6deb7d:	jmp    6dedf9 <text_column_public_control::edit+0x15f9>
  6deb82:	movzbl 0x78c(%r15),%edi
  6deb8a:	cmpq   $0x0,0x6f0(%r15)
  6deb92:	je     6debab <text_column_public_control::edit+0x13ab>
  6deb94:	test   %dil,%dil
  6deb97:	je     6dedce <text_column_public_control::edit+0x15ce>
  6deb9d:	cmpq   $0xffffffffffffffff,0x5f8(%r15)
  6deba5:	jne    6dedce <text_column_public_control::edit+0x15ce>
  6debab:	xor    %esi,%esi
  6debad:	jmp    6dedda <text_column_public_control::edit+0x15da>
  6debb2:	mov    (%rax),%ecx
  6debb4:	mov    0x3(%rax),%eax
  6debb7:	mov    %eax,0x143(%rsp)
  6debbe:	mov    %ecx,0x140(%rsp)
  6debc5:	mov    $0xd,%r13d
  6debcb:	mov    $0x2,%r9d
  6debd1:	xor    %eax,%eax
  6debd3:	jmp    6df45e <text_column_public_control::edit+0x1c5e>
  6debd8:	movq   $0xd,0x20(%rsp)
  6debe1:	movq   $0x0,0x28(%rsp)
  6debea:	jmp    6de629 <text_column_public_control::edit+0xe29>
  6debef:	mov    $0xe,%r13d
  6debf5:	jmp    6df34c <text_column_public_control::edit+0x1b4c>
  6debfa:	movq   $0xe,0x20(%rsp)
  6dec03:	jmp    6de629 <text_column_public_control::edit+0xe29>
  6dec08:	mov    $0xa,%eax
  6dec0d:	jmp    6de9e2 <text_column_public_control::edit+0x11e2>
  6dec12:	mov    $0xe,%r13d
  6dec18:	jmp    6df342 <text_column_public_control::edit+0x1b42>
  6dec1d:	movzbl 0x40(%rsp),%esi
  6dec22:	mov    0x48(%rsp),%rcx
  6dec27:	mov    %rcx,0x148(%rsp)
  6dec2f:	movb   $0x2,0x8(%rsp)
  6dec34:	mov    0x50(%rsp),%rcx
  6dec39:	mov    %rcx,0x58(%rsp)
  6dec3e:	jmp    6df342 <text_column_public_control::edit+0x1b42>
  6dec43:	mov    $0x2,%eax
  6dec48:	mov    %rax,0x10(%rsp)
  6dec4d:	mov    $0xd,%r13d
  6dec53:	xor    %eax,%eax
  6dec55:	jmp    6de713 <text_column_public_control::edit+0xf13>
  6dec5a:	mov    $0x2,%eax
  6dec5f:	mov    %rax,0x10(%rsp)
  6dec64:	mov    $0xe,%r13d
  6dec6a:	jmp    6de6fd <text_column_public_control::edit+0xefd>
  6dec6f:	mov    $0xa,%eax
  6dec74:	jmp    6dea2b <text_column_public_control::edit+0x122b>
  6dec79:	mov    $0xe,%r13d
  6dec7f:	jmp    6de6f2 <text_column_public_control::edit+0xef2>
  6dec84:	mov    $0x2,%eax
  6dec89:	mov    %rax,0x18(%rsp)
  6dec8e:	mov    $0xd,%r14d
  6dec94:	xor    %esi,%esi
  6dec96:	jmp    6de880 <text_column_public_control::edit+0x1080>
  6dec9b:	movq   $0xd,0x20(%rsp)
  6deca4:	movq   $0x0,0x28(%rsp)
  6decad:	test   %r12,%r12
  6decb0:	je     6de7f5 <text_column_public_control::edit+0xff5>
  6decb6:	jmp    6dece3 <text_column_public_control::edit+0x14e3>
  6decb8:	mov    $0x2,%eax
  6decbd:	mov    %rax,0x18(%rsp)
  6decc2:	mov    $0xe,%r14d
  6decc8:	jmp    6de87b <text_column_public_control::edit+0x107b>
  6deccd:	mov    $0xe,%eax
  6decd2:	mov    %rax,0x20(%rsp)
  6decd7:	cmpq   $0x0,0x8(%rsp)
  6decdd:	je     6de7f5 <text_column_public_control::edit+0xff5>
  6dece3:	mov    $0x1,%edx
  6dece8:	mov    %r15,%rdi
  6deceb:	mov    0x8(%rsp),%rsi
  6decf0:	call   *0x363562(%rip)        # a42258 <_DYNAMIC+0x268>
  6decf6:	jmp    6de7f5 <text_column_public_control::edit+0xff5>
  6decfb:	mov    $0xa,%esi
  6ded00:	jmp    6dea74 <text_column_public_control::edit+0x1274>
  6ded05:	movzbl 0x40(%rsp),%ecx
  6ded0a:	mov    0x48(%rsp),%rdx
  6ded0f:	mov    0x50(%rsp),%rsi
  6ded14:	movsd  0x30(%rsp),%xmm0
  6ded1a:	movsd  %xmm0,0x8(%rsp)
  6ded20:	mov    0x38(%rsp),%rdi
  6ded25:	lea    0x41(%rsp),%rbx
  6ded2a:	mov    0x6d0(%r15),%rax
  6ded31:	cmp    0x120(%rsp),%rax
  6ded39:	jne    6dee0a <text_column_public_control::edit+0x160a>
  6ded3f:	mov    $0x4,%eax
  6ded44:	mov    %rax,0x10(%rsp)
  6ded49:	lea    0x138(%rsp),%rax
  6ded51:	mov    %rax,0x18(%rsp)
  6ded56:	mov    %rdx,%r10
  6ded59:	mov    %rsi,%r11
  6ded5c:	mov    %r14,%rax
  6ded5f:	movsd  0x8(%rsp),%xmm0
  6ded65:	mov    %rdi,%r9
  6ded68:	mov    %ecx,%r8d
  6ded6b:	jmp    6dee8d <text_column_public_control::edit+0x168d>
  6ded70:	mov    0x40(%rsp),%rax
  6ded75:	mov    %rax,0x8(%rsp)
  6ded7a:	mov    0x48(%rsp),%rcx
  6ded7f:	mov    0x50(%rsp),%rax
  6ded84:	mov    0x30(%rsp),%r12
  6ded89:	mov    0x38(%rsp),%rdi
  6ded8e:	mov    0x6d0(%r13),%rsi
  6ded95:	cmp    0x120(%rsp),%rsi
  6ded9d:	jne    6dee36 <text_column_public_control::edit+0x1636>
  6deda3:	mov    0x8(%rsp),%rsi
  6deda8:	mov    %rsi,%r11
  6dedab:	shr    $0x8,%r11
  6dedaf:	mov    $0x4,%r8d
  6dedb5:	mov    %r8,0x18(%rsp)
  6dedba:	mov    %rax,%r10
  6dedbd:	mov    %rcx,%rbx
  6dedc0:	mov    %esi,%r8d
  6dedc3:	mov    %r12,%r9
  6dedc6:	mov    %rbp,%rsi
  6dedc9:	jmp    6de880 <text_column_public_control::edit+0x1080>
  6dedce:	mov    0x700(%r15),%rbp
  6dedd5:	mov    $0x1,%esi
  6dedda:	mov    0x6d8(%r15),%r8
  6dede1:	mov    0x778(%r15),%r9
  6dede8:	lea    0x128(%rsp),%r15
  6dedf0:	mov    %r14,%r10
  6dedf3:	mov    %r13,%r11
  6dedf6:	mov    %rbp,%r13
  6dedf9:	mov    (%rbx),%ebp
  6dedfb:	mov    0x3(%rbx),%ebx
  6dedfe:	mov    %ebx,0x3(%r15)
  6dee02:	mov    %ebp,(%r15)
  6dee05:	jmp    6de51c <text_column_public_control::edit+0xd1c>
  6dee0a:	movzbl 0x78c(%r15),%r8d
  6dee12:	cmpq   $0x0,0x6f0(%r15)
  6dee1a:	je     6dee2b <text_column_public_control::edit+0x162b>
  6dee1c:	test   %r8b,%r8b
  6dee1f:	je     6dee62 <text_column_public_control::edit+0x1662>
  6dee21:	cmpq   $0xffffffffffffffff,0x5f8(%r15)
  6dee29:	jne    6dee62 <text_column_public_control::edit+0x1662>
  6dee2b:	movq   $0x0,0x10(%rsp)
  6dee34:	jmp    6dee74 <text_column_public_control::edit+0x1674>
  6dee36:	movzbl 0x78c(%r13),%r8d
  6dee3e:	cmpq   $0x0,0x6f0(%r13)
  6dee46:	je     6dee57 <text_column_public_control::edit+0x1657>
  6dee48:	test   %r8b,%r8b
  6dee4b:	je     6deeb9 <text_column_public_control::edit+0x16b9>
  6dee4d:	cmpq   $0xffffffffffffffff,0x5f8(%r13)
  6dee55:	jne    6deeb9 <text_column_public_control::edit+0x16b9>
  6dee57:	movq   $0x0,0x18(%rsp)
  6dee60:	jmp    6deecb <text_column_public_control::edit+0x16cb>
  6dee62:	mov    0x700(%r15),%r12
  6dee69:	mov    $0x1,%r9d
  6dee6f:	mov    %r9,0x10(%rsp)
  6dee74:	movsd  0x6d8(%r15),%xmm0
  6dee7d:	mov    0x778(%r15),%r9
  6dee84:	mov    %r13,%r10
  6dee87:	mov    %r14,%r11
  6dee8a:	mov    %r12,%r13
  6dee8d:	mov    (%rbx),%ebp
  6dee8f:	mov    0x3(%rbx),%ebx
  6dee92:	mov    0x18(%rsp),%r14
  6dee97:	mov    %ebx,0x3(%r14)
  6dee9b:	mov    %ebp,(%r14)
  6dee9e:	mov    0x60(%rsp),%ebx
  6deea2:	mov    0x63(%rsp),%ebp
  6deea6:	mov    %ebp,0xd3(%rsp)
  6deead:	mov    %ebx,0xd0(%rsp)
  6deeb4:	jmp    6de713 <text_column_public_control::edit+0xf13>
  6deeb9:	mov    0x700(%r13),%r15
  6deec0:	mov    $0x1,%r9d
  6deec6:	mov    %r9,0x18(%rsp)
  6deecb:	mov    0x6d8(%r13),%r9
  6deed2:	mov    %rdi,0x10(%rsp)
  6deed7:	mov    0x778(%r13),%rdi
  6deede:	mov    %rbp,%r10
  6deee1:	mov    %r14,%rbx
  6deee4:	mov    %r15,%r14
  6deee7:	jmp    6de880 <text_column_public_control::edit+0x1080>
  6deeec:	jmp    6deefd <text_column_public_control::edit+0x16fd>
  6deeee:	jmp    6def96 <text_column_public_control::edit+0x1796>
  6deef3:	jmp    6df018 <text_column_public_control::edit+0x1818>
  6deef8:	jmp    6df093 <text_column_public_control::edit+0x1893>
  6deefd:	mov    %rax,%rdi
  6def00:	call   *0x3635ca(%rip)        # a424d0 <_DYNAMIC+0x4e0>
  6def06:	mov    %rax,%r15
  6def09:	mov    %rdx,%rbp
  6def0c:	mov    %rax,0x68(%rsp)
  6def11:	mov    %rdx,0x70(%rsp)
  6def16:	movq   $0xfffffffffffffffe,0x60(%rsp)
  6def1f:	mov    %r13,%rdi
  6def22:	call   71cf00 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6def27:	mov    0x0(%rbp),%rax
  6def2b:	test   %rax,%rax
  6def2e:	je     6def35 <text_column_public_control::edit+0x1735>
  6def30:	mov    %r15,%rdi
  6def33:	call   *%rax
  6def35:	mov    0x8(%rbp),%rsi
  6def39:	mov    $0xf,%r14d
  6def3f:	test   %rsi,%rsi
  6def42:	je     6def51 <text_column_public_control::edit+0x1751>
  6def44:	mov    0x10(%rbp),%rdx
  6def48:	mov    %r15,%rdi
  6def4b:	call   *0x363307(%rip)        # a42258 <_DYNAMIC+0x268>
  6def51:	jmp    6dea9e <text_column_public_control::edit+0x129e>
  6def56:	mov    %rax,%rbx
  6def59:	mov    0x8(%rbp),%rsi
  6def5d:	test   %rsi,%rsi
  6def60:	je     6df18c <text_column_public_control::edit+0x198c>
  6def66:	mov    0x10(%rbp),%rdx
  6def6a:	mov    %r15,%rdi
  6def6d:	call   *0x3632e5(%rip)        # a42258 <_DYNAMIC+0x268>
  6def73:	jmp    6df18c <text_column_public_control::edit+0x198c>
  6def78:	mov    %rax,%rbx
  6def7b:	lea    0x60(%rsp),%rdi
  6def80:	call   6bf710 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6def85:	jmp    6df18c <text_column_public_control::edit+0x198c>
  6def8a:	call   *0x3632f0(%rip)        # a42280 <_DYNAMIC+0x290>
  6def90:	call   *0x363542(%rip)        # a424d8 <_DYNAMIC+0x4e8>
  6def96:	mov    %rax,%rdi
  6def99:	call   *0x363531(%rip)        # a424d0 <_DYNAMIC+0x4e0>
  6def9f:	mov    %rax,%r14
  6defa2:	mov    %rdx,%r12
  6defa5:	mov    %rax,0x68(%rsp)
  6defaa:	mov    %rdx,0x70(%rsp)
  6defaf:	movq   $0xfffffffffffffffe,0x60(%rsp)
  6defb8:	mov    %r15,%rdi
  6defbb:	call   71cf00 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6defc0:	mov    (%r12),%rax
  6defc4:	test   %rax,%rax
  6defc7:	je     6defce <text_column_public_control::edit+0x17ce>
  6defc9:	mov    %r14,%rdi
  6defcc:	call   *%rax
  6defce:	mov    0x8(%r12),%rsi
  6defd3:	mov    $0xf,%r13d
  6defd9:	test   %rsi,%rsi
  6defdc:	je     6de6f2 <text_column_public_control::edit+0xef2>
  6defe2:	mov    0x10(%r12),%rdx
  6defe7:	mov    %r14,%rdi
  6defea:	call   *0x363268(%rip)        # a42258 <_DYNAMIC+0x268>
  6deff0:	jmp    6de6f2 <text_column_public_control::edit+0xef2>
  6deff5:	jmp    6df0f2 <text_column_public_control::edit+0x18f2>
  6deffa:	mov    %rax,%rbx
  6deffd:	lea    0x60(%rsp),%rdi
  6df002:	call   6bf710 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df007:	jmp    6df5f4 <text_column_public_control::edit+0x1df4>
  6df00c:	call   *0x36326e(%rip)        # a42280 <_DYNAMIC+0x290>
  6df012:	call   *0x3634c0(%rip)        # a424d8 <_DYNAMIC+0x4e8>
  6df018:	mov    %rax,%rdi
  6df01b:	call   *0x3634af(%rip)        # a424d0 <_DYNAMIC+0x4e0>
  6df021:	mov    %rax,%r14
  6df024:	mov    %rdx,%r12
  6df027:	mov    %rax,0x68(%rsp)
  6df02c:	mov    %rdx,0x70(%rsp)
  6df031:	movq   $0xfffffffffffffffe,0x60(%rsp)
  6df03a:	mov    %r15,%rdi
  6df03d:	call   71cf00 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6df042:	mov    (%r12),%rax
  6df046:	test   %rax,%rax
  6df049:	je     6df050 <text_column_public_control::edit+0x1850>
  6df04b:	mov    %r14,%rdi
  6df04e:	call   *%rax
  6df050:	mov    0x8(%r12),%rsi
  6df055:	mov    $0xf,%r13d
  6df05b:	test   %rsi,%rsi
  6df05e:	je     6df06e <text_column_public_control::edit+0x186e>
  6df060:	mov    0x10(%r12),%rdx
  6df065:	mov    %r14,%rdi
  6df068:	call   *0x3631ea(%rip)        # a42258 <_DYNAMIC+0x268>
  6df06e:	jmp    6dea02 <text_column_public_control::edit+0x1202>
  6df073:	jmp    6df0f2 <text_column_public_control::edit+0x18f2>
  6df075:	mov    %rax,%rbx
  6df078:	lea    0x60(%rsp),%rdi
  6df07d:	call   6bf710 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df082:	jmp    6df5f4 <text_column_public_control::edit+0x1df4>
  6df087:	call   *0x3631f3(%rip)        # a42280 <_DYNAMIC+0x290>
  6df08d:	call   *0x363445(%rip)        # a424d8 <_DYNAMIC+0x4e8>
  6df093:	mov    %rax,%rdi
  6df096:	call   *0x363434(%rip)        # a424d0 <_DYNAMIC+0x4e0>
  6df09c:	mov    %rax,%r14
  6df09f:	mov    %rdx,%r12
  6df0a2:	mov    %rax,0x68(%rsp)
  6df0a7:	mov    %rdx,0x70(%rsp)
  6df0ac:	movq   $0xfffffffffffffffe,0x60(%rsp)
  6df0b5:	mov    %r15,%rdi
  6df0b8:	call   71cf00 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6df0bd:	mov    (%r12),%rax
  6df0c1:	test   %rax,%rax
  6df0c4:	je     6df0cb <text_column_public_control::edit+0x18cb>
  6df0c6:	mov    %r14,%rdi
  6df0c9:	call   *%rax
  6df0cb:	mov    0x8(%r12),%rsi
  6df0d0:	mov    $0xf,%r13d
  6df0d6:	test   %rsi,%rsi
  6df0d9:	je     6de4eb <text_column_public_control::edit+0xceb>
  6df0df:	mov    0x10(%r12),%rdx
  6df0e4:	mov    %r14,%rdi
  6df0e7:	call   *0x36316b(%rip)        # a42258 <_DYNAMIC+0x268>
  6df0ed:	jmp    6de4eb <text_column_public_control::edit+0xceb>
  6df0f2:	mov    %rax,%rbx
  6df0f5:	mov    0x8(%r12),%rsi
  6df0fa:	test   %rsi,%rsi
  6df0fd:	je     6df5f4 <text_column_public_control::edit+0x1df4>
  6df103:	mov    0x10(%r12),%rdx
  6df108:	mov    %r14,%rdi
  6df10b:	call   *0x363147(%rip)        # a42258 <_DYNAMIC+0x268>
  6df111:	mov    %rbx,%rdi
  6df114:	call   a20740 <_Unwind_Resume@plt>
  6df119:	mov    %rax,%rbx
  6df11c:	lea    0x60(%rsp),%rdi
  6df121:	call   6bf710 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df126:	jmp    6df5f4 <text_column_public_control::edit+0x1df4>
  6df12b:	call   *0x36314f(%rip)        # a42280 <_DYNAMIC+0x290>
  6df131:	call   *0x3633a1(%rip)        # a424d8 <_DYNAMIC+0x4e8>
  6df137:	mov    %rax,%rdi
  6df13a:	call   *0x363390(%rip)        # a424d0 <_DYNAMIC+0x4e0>
  6df140:	mov    %rax,0x68(%rsp)
  6df145:	mov    %rdx,0x70(%rsp)
  6df14a:	movq   $0xfffffffffffffffd,0x60(%rsp)
  6df153:	mov    %r13,%rdi
  6df156:	call   71cf00 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6df15b:	lea    0x60(%rsp),%rdi
  6df160:	mov    0x8(%rsp),%r15
  6df165:	call   6bf780 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df16a:	mov    $0xf,%r14d
  6df170:	jmp    6de87b <text_column_public_control::edit+0x107b>
  6df175:	mov    %r15,0x8(%rsp)
  6df17a:	mov    %rax,%rbx
  6df17d:	jmp    6df18c <text_column_public_control::edit+0x198c>
  6df17f:	mov    %rax,%rbx
  6df182:	lea    0x60(%rsp),%rdi
  6df187:	call   6bf780 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df18c:	cmpq   $0x0,0x8(%rsp)
  6df192:	jle    6df5f4 <text_column_public_control::edit+0x1df4>
  6df198:	mov    $0x1,%edx
  6df19d:	mov    0x10(%rsp),%rdi
  6df1a2:	mov    0x8(%rsp),%rsi
  6df1a7:	call   *0x3630ab(%rip)        # a42258 <_DYNAMIC+0x268>
  6df1ad:	mov    %rbx,%rdi
  6df1b0:	call   a20740 <_Unwind_Resume@plt>
  6df1b5:	call   *0x3630c5(%rip)        # a42280 <_DYNAMIC+0x290>
  6df1bb:	call   *0x363317(%rip)        # a424d8 <_DYNAMIC+0x4e8>
  6df1c1:	mov    %rax,%rbx
  6df1c4:	cmpq   $0x0,0x8(%rsp)
  6df1ca:	je     6df1df <text_column_public_control::edit+0x19df>
  6df1cc:	mov    $0x1,%edx
  6df1d1:	mov    %r15,%rdi
  6df1d4:	mov    0x8(%rsp),%rsi
  6df1d9:	call   *0x363079(%rip)        # a42258 <_DYNAMIC+0x268>
  6df1df:	mov    %rbx,%rdi
  6df1e2:	call   *0x3632e8(%rip)        # a424d0 <_DYNAMIC+0x4e0>
  6df1e8:	mov    %rax,0x68(%rsp)
  6df1ed:	mov    %rdx,0x70(%rsp)
  6df1f2:	movq   $0xfffffffffffffffd,0x60(%rsp)
  6df1fb:	mov    %r13,%rdi
  6df1fe:	call   71cf00 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6df203:	movq   $0xf,0x20(%rsp)
  6df20c:	lea    0x60(%rsp),%rdi
  6df211:	call   6bf780 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df216:	jmp    6de7f5 <text_column_public_control::edit+0xff5>
  6df21b:	mov    %rax,%rbx
  6df21e:	lea    0x60(%rsp),%rdi
  6df223:	call   6bf780 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df228:	jmp    6df5f4 <text_column_public_control::edit+0x1df4>
  6df22d:	call   *0x36304d(%rip)        # a42280 <_DYNAMIC+0x290>
  6df233:	call   *0x36329f(%rip)        # a424d8 <_DYNAMIC+0x4e8>
  6df239:	mov    %rax,%rdi
  6df23c:	call   *0x36328e(%rip)        # a424d0 <_DYNAMIC+0x4e0>
  6df242:	mov    %rax,0x68(%rsp)
  6df247:	mov    %rdx,0x70(%rsp)
  6df24c:	movq   $0xfffffffffffffffd,0x60(%rsp)
  6df255:	mov    %r15,%rdi
  6df258:	call   71cf00 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6df25d:	lea    0x60(%rsp),%rdi
  6df262:	call   6bf780 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df267:	mov    $0xf,%r13d
  6df26d:	jmp    6de6f2 <text_column_public_control::edit+0xef2>
  6df272:	mov    %rax,%rbx
  6df275:	lea    0x60(%rsp),%rdi
  6df27a:	call   6bf780 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df27f:	jmp    6df5f4 <text_column_public_control::edit+0x1df4>
  6df284:	call   *0x362ff6(%rip)        # a42280 <_DYNAMIC+0x290>
  6df28a:	call   *0x363248(%rip)        # a424d8 <_DYNAMIC+0x4e8>
  6df290:	mov    %rax,%rbx
  6df293:	lea    0x60(%rsp),%rdi
  6df298:	call   6c0740 <core::ptr::drop_glue::<gpui::runtime::SetError<alloc::string::String>>>
  6df29d:	mov    %rbx,%rdi
  6df2a0:	call   a20740 <_Unwind_Resume@plt>
  6df2a5:	jmp    6df608 <text_column_public_control::edit+0x1e08>
  6df2aa:	jmp    6df61d <text_column_public_control::edit+0x1e1d>
  6df2af:	mov    %rax,%rdi
  6df2b2:	call   *0x363218(%rip)        # a424d0 <_DYNAMIC+0x4e0>
  6df2b8:	mov    %rax,0x68(%rsp)
  6df2bd:	mov    %rdx,0x70(%rsp)
  6df2c2:	movq   $0xfffffffffffffffd,0x60(%rsp)
  6df2cb:	mov    %r15,%rdi
  6df2ce:	call   71cf00 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6df2d3:	movq   $0xf,0x20(%rsp)
  6df2dc:	lea    0x60(%rsp),%rdi
  6df2e1:	call   6bf780 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df2e6:	jmp    6de629 <text_column_public_control::edit+0xe29>
  6df2eb:	mov    %rax,%rbx
  6df2ee:	lea    0x60(%rsp),%rdi
  6df2f3:	call   6bf780 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df2f8:	jmp    6df5f4 <text_column_public_control::edit+0x1df4>
  6df2fd:	call   *0x362f7d(%rip)        # a42280 <_DYNAMIC+0x290>
  6df303:	call   *0x3631cf(%rip)        # a424d8 <_DYNAMIC+0x4e8>
  6df309:	jmp    6df608 <text_column_public_control::edit+0x1e08>
  6df30e:	mov    %rax,%rdi
  6df311:	call   *0x3631b9(%rip)        # a424d0 <_DYNAMIC+0x4e0>
  6df317:	mov    %rax,0x68(%rsp)
  6df31c:	mov    %rdx,0x70(%rsp)
  6df321:	movq   $0xfffffffffffffffd,0x60(%rsp)
  6df32a:	mov    %r15,%rdi
  6df32d:	call   71cf00 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6df332:	lea    0x60(%rsp),%rdi
  6df337:	call   6bf780 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df33c:	mov    $0xf,%r13d
  6df342:	mov    0x30(%rsp),%rdi
  6df347:	mov    0x38(%rsp),%r8
  6df34c:	lea    0x41(%rsp),%rbx
  6df351:	cmpb   $0x2,0x8(%rsp)
  6df356:	jne    6df391 <text_column_public_control::edit+0x1b91>
  6df358:	mov    0x6d0(%r15),%r10
  6df35f:	cmp    0x120(%rsp),%r10
  6df367:	jne    6df3cb <text_column_public_control::edit+0x1bcb>
  6df369:	mov    $0x4,%r9d
  6df36f:	lea    0xf8(%rsp),%r14
  6df377:	mov    0x148(%rsp),%r15
  6df37f:	mov    0x58(%rsp),%rcx
  6df384:	mov    %rdi,%r12
  6df387:	mov    %r8,%rdx
  6df38a:	mov    %esi,%ebp
  6df38c:	jmp    6df420 <text_column_public_control::edit+0x1c20>
  6df391:	mov    (%rbx),%ecx
  6df393:	mov    0x3(%rbx),%edx
  6df396:	mov    %edx,0xfb(%rsp)
  6df39d:	mov    %ecx,0xf8(%rsp)
  6df3a4:	mov    0xc8(%rsp),%ecx
  6df3ab:	mov    0xcb(%rsp),%edx
  6df3b2:	mov    %ecx,0x140(%rsp)
  6df3b9:	mov    %edx,0x143(%rsp)
  6df3c0:	mov    $0x2,%r9d
  6df3c6:	jmp    6df45e <text_column_public_control::edit+0x1c5e>
  6df3cb:	movzbl 0x78c(%r15),%ebp
  6df3d3:	cmpq   $0x0,0x6f0(%r15)
  6df3db:	je     6df3ec <text_column_public_control::edit+0x1bec>
  6df3dd:	test   %bpl,%bpl
  6df3e0:	je     6df3f1 <text_column_public_control::edit+0x1bf1>
  6df3e2:	cmpq   $0xffffffffffffffff,0x5f8(%r15)
  6df3ea:	jne    6df3f1 <text_column_public_control::edit+0x1bf1>
  6df3ec:	xor    %r9d,%r9d
  6df3ef:	jmp    6df3fe <text_column_public_control::edit+0x1bfe>
  6df3f1:	mov    0x700(%r15),%r11
  6df3f8:	mov    $0x1,%r9d
  6df3fe:	mov    0x6d8(%r15),%r12
  6df405:	mov    0x778(%r15),%rdx
  6df40c:	lea    0x140(%rsp),%r14
  6df414:	mov    %r13,%r15
  6df417:	mov    %rax,%rcx
  6df41a:	mov    %r11,%r13
  6df41d:	mov    %r10,%rax
  6df420:	mov    %sil,0x8(%rsp)
  6df425:	mov    0x58(%rsp),%r10
  6df42a:	mov    0x148(%rsp),%r11
  6df432:	mov    %r8,0x10(%rsp)
  6df437:	mov    (%rbx),%esi
  6df439:	mov    0x3(%rbx),%r8d
  6df43d:	mov    %r8d,0x3(%r14)
  6df441:	mov    %esi,(%r14)
  6df444:	mov    %rdi,0x18(%rsp)
  6df449:	mov    %rcx,0x58(%rsp)
  6df44e:	mov    %r15,0x148(%rsp)
  6df456:	mov    %ebp,%esi
  6df458:	mov    %rdx,%r8
  6df45b:	mov    %r12,%rdi
  6df45e:	mov    %r9,0x60(%rsp)
  6df463:	mov    %r13,0x68(%rsp)
  6df468:	mov    %rax,0x70(%rsp)
  6df46d:	mov    %rdi,0x78(%rsp)
  6df472:	mov    %r8,0x80(%rsp)
  6df47a:	mov    %sil,0x88(%rsp)
  6df482:	mov    0xf8(%rsp),%eax
  6df489:	mov    0xfb(%rsp),%ecx
  6df490:	mov    %eax,0x89(%rsp)
  6df497:	mov    %ecx,0x8c(%rsp)
  6df49e:	mov    0x148(%rsp),%rax
  6df4a6:	mov    %rax,0x90(%rsp)
  6df4ae:	mov    0x58(%rsp),%rax
  6df4b3:	mov    %rax,0x98(%rsp)
  6df4bb:	mov    0x18(%rsp),%rax
  6df4c0:	mov    %rax,0xa0(%rsp)
  6df4c8:	mov    0x10(%rsp),%rax
  6df4cd:	mov    %rax,0xa8(%rsp)
  6df4d5:	movzbl 0x8(%rsp),%eax
  6df4da:	mov    %al,0xb0(%rsp)
  6df4e1:	mov    0x140(%rsp),%eax
  6df4e8:	mov    0x143(%rsp),%ecx
  6df4ef:	mov    %eax,0xb1(%rsp)
  6df4f6:	mov    %ecx,0xb4(%rsp)
  6df4fd:	mov    %r11,0xb8(%rsp)
  6df505:	mov    %r10,0xc0(%rsp)
  6df50d:	lea    -0x691e35(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6df514:	lea    0x34382d(%rip),%rcx        # a22d48 <__frame_dummy_init_array_entry+0x1258>
  6df51b:	lea    0x34342e(%rip),%r8        # a22950 <__frame_dummy_init_array_entry+0xe60>
  6df522:	lea    0x60(%rsp),%rdx
  6df527:	mov    $0x2b,%esi
  6df52c:	call   *0x362cfe(%rip)        # a42230 <_DYNAMIC+0x240>
  6df532:	ud2
  6df534:	mov    %rax,%rbx
  6df537:	lea    0x60(%rsp),%rdi
  6df53c:	call   6bf780 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df541:	jmp    6df5f4 <text_column_public_control::edit+0x1df4>
  6df546:	call   *0x362d34(%rip)        # a42280 <_DYNAMIC+0x290>
  6df54c:	call   *0x362f86(%rip)        # a424d8 <_DYNAMIC+0x4e8>
  6df552:	jmp    6df61d <text_column_public_control::edit+0x1e1d>
  6df557:	mov    %rax,%rdi
  6df55a:	call   *0x362f70(%rip)        # a424d0 <_DYNAMIC+0x4e0>
  6df560:	mov    %rax,0x68(%rsp)
  6df565:	mov    %rdx,0x70(%rsp)
  6df56a:	movq   $0xfffffffffffffffd,0x60(%rsp)
  6df573:	mov    %r15,%rdi
  6df576:	call   71cf00 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6df57b:	lea    0x60(%rsp),%rdi
  6df580:	call   6bf780 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df585:	mov    $0xf,%r13d
  6df58b:	jmp    6de4eb <text_column_public_control::edit+0xceb>
  6df590:	mov    %rax,%rbx
  6df593:	lea    0x60(%rsp),%rdi
  6df598:	call   6bf780 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df59d:	jmp    6df5f4 <text_column_public_control::edit+0x1df4>
  6df59f:	call   *0x362cdb(%rip)        # a42280 <_DYNAMIC+0x290>
  6df5a5:	call   *0x362f2d(%rip)        # a424d8 <_DYNAMIC+0x4e8>
  6df5ab:	mov    %rax,%rdi
  6df5ae:	call   *0x362f1c(%rip)        # a424d0 <_DYNAMIC+0x4e0>
  6df5b4:	mov    %rax,0x68(%rsp)
  6df5b9:	mov    %rdx,0x70(%rsp)
  6df5be:	movq   $0xfffffffffffffffd,0x60(%rsp)
  6df5c7:	mov    %r15,%rdi
  6df5ca:	call   71cf00 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6df5cf:	movq   $0xf,0x20(%rsp)
  6df5d8:	lea    0x60(%rsp),%rdi
  6df5dd:	call   6bf780 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df5e2:	jmp    6de483 <text_column_public_control::edit+0xc83>
  6df5e7:	mov    %rax,%rbx
  6df5ea:	lea    0x60(%rsp),%rdi
  6df5ef:	call   6bf780 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df5f4:	mov    %rbx,%rdi
  6df5f7:	call   a20740 <_Unwind_Resume@plt>
  6df5fc:	call   *0x362c7e(%rip)        # a42280 <_DYNAMIC+0x290>
  6df602:	call   *0x362ed0(%rip)        # a424d8 <_DYNAMIC+0x4e8>
  6df608:	mov    %rax,%rbx
  6df60b:	lea    0x60(%rsp),%rdi
  6df610:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6df615:	mov    %rbx,%rdi
  6df618:	call   a20740 <_Unwind_Resume@plt>
  6df61d:	mov    %rax,%rbx
  6df620:	lea    0x60(%rsp),%rdi
  6df625:	call   6c0680 <core::ptr::drop_glue::<gpui::runtime::SetError<text_column_public_control::Structural>>>
  6df62a:	mov    %rbx,%rdi
  6df62d:	call   a20740 <_Unwind_Resume@plt>

text_column_public_control::main code=21602 fixed_stack=3704

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006df640 <text_column_public_control::main>:
  6df640:	push   %rbp
  6df641:	push   %r15
  6df643:	push   %r14
  6df645:	push   %r13
  6df647:	push   %r12
  6df649:	push   %rbx
  6df64a:	sub    $0xe48,%rsp
  6df651:	lea    0x9c0(%rsp),%rbx
  6df659:	mov    %rbx,%rdi
  6df65c:	call   *0x362e7e(%rip)        # a424e0 <_DYNAMIC+0x4f0>
  6df662:	lea    0x260(%rsp),%rdi
  6df66a:	mov    %rbx,%rsi
  6df66d:	call   *0x362e75(%rip)        # a424e8 <_DYNAMIC+0x4f8>
  6df673:	mov    0x260(%rsp),%r14
  6df67b:	cmp    $0xffffffffffffffff,%r14
  6df67f:	je     6e3571 <text_column_public_control::main+0x3f31>
  6df685:	mov    0x268(%rsp),%r15
  6df68d:	mov    0x9d8(%rsp),%rax
  6df695:	sub    0x9c8(%rsp),%rax
  6df69d:	mov    %rax,%rcx
  6df6a0:	shr    $0x3,%rcx
  6df6a4:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  6df6ae:	imul   %rdx,%rcx
  6df6b2:	cmp    $0x4,%rcx
  6df6b6:	mov    $0x3,%ebp
  6df6bb:	cmovae %rcx,%rbp
  6df6bf:	lea    0x8(,%rbp,8),%rcx
  6df6c7:	lea    (%rcx,%rcx,2),%r12
  6df6cb:	movabs $0x7fffffffffffffe0,%rcx
  6df6d5:	cmp    %rcx,%rax
  6df6d8:	jbe    6df6ee <text_column_public_control::main+0xae>
  6df6da:	xor    %r13d,%r13d
  6df6dd:	mov    %r13,%rdi
  6df6e0:	mov    %r12,%rsi
  6df6e3:	call   *0x362bff(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  6df6e9:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6df6ee:	mov    0x270(%rsp),%rax
  6df6f6:	test   %r12,%r12
  6df6f9:	je     6df72c <text_column_public_control::main+0xec>
  6df6fb:	mov    %rax,0x10(%rsp)
  6df700:	call   *0x362b5a(%rip)        # a42260 <_DYNAMIC+0x270>
  6df706:	mov    $0x8,%r13d
  6df70c:	mov    $0x8,%esi
  6df711:	mov    %r12,%rdi
  6df714:	call   *0x362b4e(%rip)        # a42268 <_DYNAMIC+0x278>
  6df71a:	test   %rax,%rax
  6df71d:	je     6df6dd <text_column_public_control::main+0x9d>
  6df71f:	mov    %rax,%rbx
  6df722:	inc    %rbp
  6df725:	mov    0x10(%rsp),%rax
  6df72a:	jmp    6df733 <text_column_public_control::main+0xf3>
  6df72c:	mov    $0x8,%ebx
  6df731:	xor    %ebp,%ebp
  6df733:	mov    %r14,(%rbx)
  6df736:	mov    %r15,0x8(%rbx)
  6df73a:	mov    %rax,0x10(%rbx)
  6df73e:	mov    %rbp,0x70(%rsp)
  6df743:	mov    %rbx,0x78(%rsp)
  6df748:	movq   $0x1,0x80(%rsp)
  6df754:	movups 0x9c0(%rsp),%xmm0
  6df75c:	movups 0x9d0(%rsp),%xmm1
  6df764:	movaps %xmm1,0x270(%rsp)
  6df76c:	movaps %xmm0,0x260(%rsp)
  6df774:	mov    $0x1,%r14d
  6df77a:	mov    $0x28,%r15d
  6df780:	jmp    6df7b2 <text_column_public_control::main+0x172>
  6df782:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6df790:	mov    0x78(%rsp),%rbx
  6df795:	mov    %rbp,-0x10(%rbx,%r15,1)
  6df79a:	mov    %r13,-0x8(%rbx,%r15,1)
  6df79f:	mov    %r12,(%rbx,%r15,1)
  6df7a3:	inc    %r14
  6df7a6:	mov    %r14,0x80(%rsp)
  6df7ae:	add    $0x18,%r15
  6df7b2:	lea    0xc60(%rsp),%rdi
  6df7ba:	lea    0x260(%rsp),%rsi
  6df7c2:	call   *0x362d20(%rip)        # a424e8 <_DYNAMIC+0x4f8>
  6df7c8:	mov    0xc60(%rsp),%rbp
  6df7d0:	cmp    $0xffffffffffffffff,%rbp
  6df7d4:	je     6df82f <text_column_public_control::main+0x1ef>
  6df7d6:	mov    0xc68(%rsp),%r13
  6df7de:	mov    0xc70(%rsp),%r12
  6df7e6:	cmp    0x70(%rsp),%r14
  6df7eb:	jne    6df795 <text_column_public_control::main+0x155>
  6df7ed:	mov    0x278(%rsp),%rdx
  6df7f5:	sub    0x268(%rsp),%rdx
  6df7fd:	shr    $0x3,%rdx
  6df801:	movabs $0xaaaaaaaaaaaaaaab,%rax
  6df80b:	imul   %rax,%rdx
  6df80f:	inc    %rdx
  6df812:	mov    $0x8,%ecx
  6df817:	mov    $0x18,%r8d
  6df81d:	lea    0x70(%rsp),%rdi
  6df822:	mov    %r14,%rsi
  6df825:	call   6d91d0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  6df82a:	jmp    6df790 <text_column_public_control::main+0x150>
  6df82f:	mov    0x268(%rsp),%r14
  6df837:	mov    0x278(%rsp),%rcx
  6df83f:	mov    %rcx,%rax
  6df842:	sub    %r14,%rax
  6df845:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  6df84f:	mul    %rdx
  6df852:	cmp    %r14,%rcx
  6df855:	je     6df88f <text_column_public_control::main+0x24f>
  6df857:	mov    %rdx,%rbx
  6df85a:	shr    $0x4,%rbx
  6df85e:	add    $0x8,%r14
  6df862:	mov    0x3629ef(%rip),%r15        # a42258 <_DYNAMIC+0x268>
  6df869:	jmp    6df879 <text_column_public_control::main+0x239>
  6df86b:	nopl   0x0(%rax,%rax,1)
  6df870:	add    $0x18,%r14
  6df874:	dec    %rbx
  6df877:	je     6df88f <text_column_public_control::main+0x24f>
  6df879:	mov    -0x8(%r14),%rsi
  6df87d:	test   %rsi,%rsi
  6df880:	je     6df870 <text_column_public_control::main+0x230>
  6df882:	mov    (%r14),%rdi
  6df885:	mov    $0x1,%edx
  6df88a:	call   *%r15
  6df88d:	jmp    6df870 <text_column_public_control::main+0x230>
  6df88f:	mov    0x270(%rsp),%rax
  6df897:	test   %rax,%rax
  6df89a:	je     6df8b7 <text_column_public_control::main+0x277>
  6df89c:	mov    0x260(%rsp),%rdi
  6df8a4:	shl    $0x3,%rax
  6df8a8:	lea    (%rax,%rax,2),%rsi
  6df8ac:	mov    $0x8,%edx
  6df8b1:	call   *0x3629a1(%rip)        # a42258 <_DYNAMIC+0x268>
  6df8b7:	movdqu 0x70(%rsp),%xmm0
  6df8bd:	movdqa %xmm0,0x210(%rsp)
  6df8c6:	mov    0x80(%rsp),%r14
  6df8ce:	mov    %r14,0x220(%rsp)
  6df8d6:	lea    0x34308b(%rip),%rdx        # a22968 <__frame_dummy_init_array_entry+0xe78>
  6df8dd:	mov    $0x65,%esi
  6df8e2:	lea    -0x692394(%rip),%rdi        # 4d555 <GCC_except_table0+0xd7b1>
  6df8e9:	cmp    $0x2,%r14
  6df8ed:	jb     6e35fc <text_column_public_control::main+0x3fbc>
  6df8f3:	mov    0x218(%rsp),%rbx
  6df8fb:	mov    0x20(%rbx),%rax
  6df8ff:	mov    0x28(%rbx),%rcx
  6df903:	cmp    $0x6,%rcx
  6df907:	je     6df99e <text_column_public_control::main+0x35e>
  6df90d:	cmp    $0x9,%rcx
  6df911:	jne    6dfa1d <text_column_public_control::main+0x3dd>
  6df917:	movabs $0x6867696c66657270,%rcx
  6df921:	xor    (%rax),%rcx
  6df924:	movzbl 0x8(%rax),%eax
  6df928:	xor    $0x74,%rax
  6df92c:	or     %rcx,%rax
  6df92f:	jne    6e35fc <text_column_public_control::main+0x3fbc>
  6df935:	cmp    $0x2,%r14
  6df939:	je     6e3725 <text_column_public_control::main+0x40e5>
  6df93f:	mov    0x38(%rbx),%rdi
  6df943:	mov    0x40(%rbx),%rsi
  6df947:	call   6e5660 <<text_column_public_control::Case>::parse>
  6df94c:	mov    %al,0x20(%rsp)
  6df950:	cmp    $0x4,%r14
  6df954:	jb     6e372e <text_column_public_control::main+0x40ee>
  6df95a:	mov    0x50(%rbx),%rax
  6df95e:	mov    0x58(%rbx),%rcx
  6df962:	lea    0x343c0f(%rip),%rdx        # a23578 <__frame_dummy_init_array_entry+0x1a88>
  6df969:	mov    $0x19,%esi
  6df96e:	lea    -0x68f747(%rip),%rdi        # 5022e <GCC_except_table0+0x1048a>
  6df975:	cmp    $0x6,%rcx
  6df979:	jne    6e0196 <text_column_public_control::main+0xb56>
  6df97f:	mov    $0x61647075,%ecx
  6df984:	xor    (%rax),%ecx
  6df986:	movzwl 0x4(%rax),%eax
  6df98a:	xor    $0x6574,%eax
  6df98f:	or     %ecx,%eax
  6df991:	jne    6e35fc <text_column_public_control::main+0x3fbc>
  6df997:	xor    %ebx,%ebx
  6df999:	jmp    6e01b8 <text_column_public_control::main+0xb78>
  6df99e:	mov    $0x706d6173,%ecx
  6df9a3:	xor    (%rax),%ecx
  6df9a5:	movzwl 0x4(%rax),%eax
  6df9a9:	xor    $0x656c,%eax
  6df9ae:	or     %ecx,%eax
  6df9b0:	jne    6e35fc <text_column_public_control::main+0x3fbc>
  6df9b6:	cmp    $0x2,%r14
  6df9ba:	je     6e3737 <text_column_public_control::main+0x40f7>
  6df9c0:	mov    0x38(%rbx),%rdi
  6df9c4:	mov    0x40(%rbx),%rsi
  6df9c8:	call   6e5660 <<text_column_public_control::Case>::parse>
  6df9cd:	cmp    $0x4,%r14
  6df9d1:	jb     6e3745 <text_column_public_control::main+0x4105>
  6df9d7:	mov    %eax,%ebp
  6df9d9:	mov    0x50(%rbx),%rax
  6df9dd:	mov    0x58(%rbx),%rcx
  6df9e1:	lea    0x343b90(%rip),%rdx        # a23578 <__frame_dummy_init_array_entry+0x1a88>
  6df9e8:	mov    $0x19,%esi
  6df9ed:	lea    -0x68f7c6(%rip),%rdi        # 5022e <GCC_except_table0+0x1048a>
  6df9f4:	cmp    $0x6,%rcx
  6df9f8:	jne    6e048a <text_column_public_control::main+0xe4a>
  6df9fe:	mov    $0x61647075,%ecx
  6dfa03:	xor    (%rax),%ecx
  6dfa05:	movzwl 0x4(%rax),%eax
  6dfa09:	xor    $0x6574,%eax
  6dfa0e:	or     %ecx,%eax
  6dfa10:	jne    6e35fc <text_column_public_control::main+0x3fbc>
  6dfa16:	xor    %ebx,%ebx
  6dfa18:	jmp    6e04ac <text_column_public_control::main+0xe6c>
  6dfa1d:	cmp    $0x7,%rcx
  6dfa21:	jne    6e35fc <text_column_public_control::main+0x3fbc>
  6dfa27:	mov    $0x65646f63,%ecx
  6dfa2c:	xor    (%rax),%ecx
  6dfa2e:	mov    $0x6e656765,%r8d
  6dfa34:	xor    0x3(%rax),%r8d
  6dfa38:	or     %ecx,%r8d
  6dfa3b:	jne    6e35fc <text_column_public_control::main+0x3fbc>
  6dfa41:	call   *0x362819(%rip)        # a42260 <_DYNAMIC+0x270>
  6dfa47:	mov    $0x13,%edi
  6dfa4c:	mov    $0x1,%esi
  6dfa51:	call   *0x362811(%rip)        # a42268 <_DYNAMIC+0x278>
  6dfa57:	test   %rax,%rax
  6dfa5a:	je     6e37a4 <text_column_public_control::main+0x4164>
  6dfa60:	mov    %rax,%r14
  6dfa63:	movups -0x6925c3(%rip),%xmm0        # 4d4a7 <GCC_except_table0+0xd703>
  6dfa6a:	movups %xmm0,(%rax)
  6dfa6d:	movl   $0x92d791d7,0xf(%rax)
  6dfa74:	lea    0x260(%rsp),%rdi
  6dfa7c:	movabs $0x19000000190,%rbx
  6dfa86:	movss  -0x69fc86(%rip),%xmm0        # 3fe08 <GCC_except_table0+0x64>
  6dfa8e:	mov    %rbx,%rsi
  6dfa91:	call   *0x362a59(%rip)        # a424f0 <_DYNAMIC+0x500>
  6dfa97:	mov    0x260(%rsp),%r12
  6dfa9f:	cmp    $0xfffffffffffffffe,%r12
  6dfaa3:	jne    6e37b9 <text_column_public_control::main+0x4179>
  6dfaa9:	movq   $0x0,0x278(%rsp)
  6dfab5:	movq   $0x8,0x280(%rsp)
  6dfac1:	xorps  %xmm0,%xmm0
  6dfac4:	movups %xmm0,0x288(%rsp)
  6dfacc:	movq   $0xffffffffffffffff,0x260(%rsp)
  6dfad8:	movq   $0x8,0x298(%rsp)
  6dfae4:	movups %xmm0,0x2a0(%rsp)
  6dfaec:	movq   $0x8,0x2b0(%rsp)
  6dfaf8:	movq   $0x0,0x2b8(%rsp)
  6dfb04:	movq   $0x1,0x2c0(%rsp)
  6dfb10:	mov    $0x1,%edi
  6dfb15:	call   *0x3629dd(%rip)        # a424f8 <_DYNAMIC+0x508>
  6dfb1b:	mov    %rax,%r13
  6dfb1e:	cmp    $0x1,%r13d
  6dfb22:	je     6dfb38 <text_column_public_control::main+0x4f8>
  6dfb24:	movq   $0x0,0x260(%rsp)
  6dfb30:	mov    %r13,0x268(%rsp)
  6dfb38:	call   *0x362722(%rip)        # a42260 <_DYNAMIC+0x270>
  6dfb3e:	mov    $0x28,%edi
  6dfb43:	mov    $0x8,%esi
  6dfb48:	call   *0x36271a(%rip)        # a42268 <_DYNAMIC+0x278>
  6dfb4e:	test   %rax,%rax
  6dfb51:	je     6e31d0 <text_column_public_control::main+0x3b90>
  6dfb57:	mov    %rax,%r15
  6dfb5a:	lea    0x278(%rsp),%r12
  6dfb62:	mov    %r13,(%rax)
  6dfb65:	lea    -0x69262d(%rip),%rax        # 4d53f <GCC_except_table0+0xd79b>
  6dfb6c:	mov    %rax,0x8(%r15)
  6dfb70:	movq   $0x5,0x10(%r15)
  6dfb78:	lea    0x4a3c1(%rip),%rax        # 729f40 <<<text_column_public_control::Input as gpui::View>::sources::{closure#0} as core::ops::function::FnOnce<(&text_column_public_control::Input,)>>::call_once>
  6dfb7f:	mov    %rax,0x18(%r15)
  6dfb83:	lea    0x4a3c6(%rip),%rax        # 729f50 <<<text_column_public_control::Input as gpui::View>::sources::{closure#1} as core::ops::function::FnOnce<(&mut text_column_public_control::Input,)>>::call_once>
  6dfb8a:	mov    %rax,0x20(%r15)
  6dfb8e:	mov    %r12,%rdi
  6dfb91:	call   6f4430 <<alloc::raw_vec::RawVec<[core::option::Option<gpui::source::FieldId>; 2]>>::grow_one>
  6dfb96:	mov    0x280(%rsp),%rax
  6dfb9e:	mov    %r15,(%rax)
  6dfba1:	lea    0x342198(%rip),%rcx        # a21d40 <__frame_dummy_init_array_entry+0x250>
  6dfba8:	mov    %rcx,0x8(%rax)
  6dfbac:	movq   $0x1,0x288(%rsp)
  6dfbb8:	mov    0x260(%rsp),%rax
  6dfbc0:	movups 0x40(%r12),%xmm0
  6dfbc6:	movaps %xmm0,0xa00(%rsp)
  6dfbce:	movups (%r12),%xmm0
  6dfbd3:	movups 0x10(%r12),%xmm1
  6dfbd9:	movups 0x20(%r12),%xmm2
  6dfbdf:	movups 0x30(%r12),%xmm3
  6dfbe5:	movaps %xmm3,0x9f0(%rsp)
  6dfbed:	movaps %xmm2,0x9e0(%rsp)
  6dfbf5:	movaps %xmm1,0x9d0(%rsp)
  6dfbfd:	movupd 0x268(%rsp),%xmm2
  6dfc06:	movups %xmm0,0x88(%rsp)
  6dfc0e:	movups %xmm1,0x98(%rsp)
  6dfc16:	mov    0x9e0(%rsp),%rcx
  6dfc1e:	mov    %rcx,0xa8(%rsp)
  6dfc26:	movups 0x9e8(%rsp),%xmm0
  6dfc2e:	movups %xmm0,0xb0(%rsp)
  6dfc36:	movups 0x9f8(%rsp),%xmm0
  6dfc3e:	movups %xmm0,0xc0(%rsp)
  6dfc46:	mov    0xa08(%rsp),%rcx
  6dfc4e:	mov    %rcx,0xd0(%rsp)
  6dfc56:	mov    %rax,0x70(%rsp)
  6dfc5b:	movupd %xmm2,0x78(%rsp)
  6dfc61:	movl   $0x0,0x9c0(%rsp)
  6dfc6c:	movl   $0x434b0000,0x9c8(%rsp)
  6dfc77:	movw   $0x0,0x9cc(%rsp)
  6dfc81:	lea    0x260(%rsp),%rdi
  6dfc89:	lea    0x9c0(%rsp),%rcx
  6dfc91:	mov    $0x190,%esi
  6dfc96:	mov    $0x190,%edx
  6dfc9b:	call   *0x36285f(%rip)        # a42500 <_DYNAMIC+0x510>
  6dfca1:	mov    0x260(%rsp),%r12
  6dfca9:	mov    0x268(%rsp),%r15d
  6dfcb1:	mov    0x26c(%rsp),%r13d
  6dfcb9:	cmp    $0x2,%r12
  6dfcbd:	je     6e38a4 <text_column_public_control::main+0x4264>
  6dfcc3:	lea    0x270(%rsp),%rsi
  6dfccb:	lea    0xc70(%rsp),%rdi
  6dfcd3:	mov    $0x1d8,%edx
  6dfcd8:	call   *0x36259a(%rip)        # a42278 <memcpy@GLIBC_2.14>
  6dfcde:	mov    %r12,0xc60(%rsp)
  6dfce6:	mov    %r15d,0xc68(%rsp)
  6dfcee:	mov    %r13d,0xc6c(%rsp)
  6dfcf6:	call   *0x36280c(%rip)        # a42508 <_DYNAMIC+0x518>
  6dfcfc:	mov    %rax,%r15
  6dfcff:	lea    0x9c0(%rsp),%rdi
  6dfd07:	call   *0x362803(%rip)        # a42510 <_DYNAMIC+0x520>
  6dfd0d:	movq   $0x13,0x500(%rsp)
  6dfd19:	movl   $0x0,0x508(%rsp)
  6dfd24:	movq   $0x0,0x510(%rsp)
  6dfd30:	movl   $0x0,0x518(%rsp)
  6dfd3b:	movups 0x70(%rsp),%xmm0
  6dfd40:	movups 0x80(%rsp),%xmm1
  6dfd48:	movupd 0x90(%rsp),%xmm2
  6dfd51:	movups 0xa0(%rsp),%xmm3
  6dfd59:	movups %xmm0,0x488(%rsp)
  6dfd61:	movups %xmm1,0x498(%rsp)
  6dfd69:	movupd %xmm2,0x4a8(%rsp)
  6dfd72:	movups %xmm3,0x4b8(%rsp)
  6dfd7a:	movups 0xb0(%rsp),%xmm0
  6dfd82:	movups %xmm0,0x4c8(%rsp)
  6dfd8a:	movups 0xc0(%rsp),%xmm0
  6dfd92:	movups %xmm0,0x4d8(%rsp)
  6dfd9a:	mov    0xd0(%rsp),%rax
  6dfda2:	mov    %rax,0x4e8(%rsp)
  6dfdaa:	lea    0x550(%rsp),%rdi
  6dfdb2:	lea    0x9c0(%rsp),%rsi
  6dfdba:	mov    0x3624b7(%rip),%r12        # a42278 <memcpy@GLIBC_2.14>
  6dfdc1:	mov    $0x298,%edx
  6dfdc6:	call   *%r12
  6dfdc9:	lea    0x260(%rsp),%rdi
  6dfdd1:	lea    0xc60(%rsp),%rsi
  6dfdd9:	mov    $0x1e8,%edx
  6dfdde:	call   *%r12
  6dfde1:	movq   $0x13,0x4f0(%rsp)
  6dfded:	mov    %r14,0x4f8(%rsp)
  6dfdf5:	movq   $0x0,0x520(%rsp)
  6dfe01:	movq   $0x8,0x528(%rsp)
  6dfe0d:	xorps  %xmm0,%xmm0
  6dfe10:	movups %xmm0,0x530(%rsp)
  6dfe18:	movq   $0x8,0x540(%rsp)
  6dfe24:	movq   $0x0,0x548(%rsp)
  6dfe30:	movq   $0x0,0x868(%rsp)
  6dfe3c:	movups %xmm0,0x448(%rsp)
  6dfe44:	movups %xmm0,0x458(%rsp)
  6dfe4c:	movups %xmm0,0x850(%rsp)
  6dfe54:	movq   $0x1,0x870(%rsp)
  6dfe60:	movq   $0x0,0x878(%rsp)
  6dfe6c:	mov    %r15,0x840(%rsp)
  6dfe74:	movq   $0x0,0x888(%rsp)
  6dfe80:	movq   $0x0,0x8d0(%rsp)
  6dfe8c:	movups %xmm0,0x898(%rsp)
  6dfe94:	movq   $0x0,0x8a8(%rsp)
  6dfea0:	movups %xmm0,0x8b8(%rsp)
  6dfea8:	movq   $0x0,0x7e8(%rsp)
  6dfeb4:	movq   $0x8,0x7f0(%rsp)
  6dfec0:	movups %xmm0,0x7f8(%rsp)
  6dfec8:	movq   $0x0,0x8d8(%rsp)
  6dfed4:	movq   $0x0,0x8e8(%rsp)
  6dfee0:	movl   $0x1000101,0x9a8(%rsp)
  6dfeeb:	movw   $0x0,0x9ac(%rsp)
  6dfef5:	movups %xmm0,0x8f0(%rsp)
  6dfefd:	movq   $0x0,0x900(%rsp)
  6dff09:	mov    %rbx,0x908(%rsp)
  6dff11:	movsd  -0x69f589(%rip),%xmm1        # 40990 <GCC_except_table0+0xbec>
  6dff19:	movsd  %xmm1,0x9a0(%rsp)
  6dff22:	movq   $0x1,0x848(%rsp)
  6dff2e:	movq   $0xffffffffffffffff,0x818(%rsp)
  6dff3a:	movq   $0x0,0x910(%rsp)
  6dff46:	movq   $0x0,0x920(%rsp)
  6dff52:	movq   $0x8,0x808(%rsp)
  6dff5e:	movq   $0x0,0x810(%rsp)
  6dff6a:	movb   $0x0,0x9ae(%rsp)
  6dff72:	movups %xmm0,0x988(%rsp)
  6dff7a:	movups %xmm0,0x978(%rsp)
  6dff82:	movups %xmm0,0x968(%rsp)
  6dff8a:	movups %xmm0,0x958(%rsp)
  6dff92:	movups %xmm0,0x948(%rsp)
  6dff9a:	movups %xmm0,0x938(%rsp)
  6dffa2:	movups %xmm0,0x928(%rsp)
  6dffaa:	movq   $0x0,0x998(%rsp)
  6dffb6:	call   *0x3622a4(%rip)        # a42260 <_DYNAMIC+0x270>
  6dffbc:	mov    $0x750,%edi
  6dffc1:	mov    $0x8,%esi
  6dffc6:	call   *0x36229c(%rip)        # a42268 <_DYNAMIC+0x278>
  6dffcc:	test   %rax,%rax
  6dffcf:	je     6e31e5 <text_column_public_control::main+0x3ba5>
  6dffd5:	mov    %rax,%rbx
  6dffd8:	lea    0x260(%rsp),%rsi
  6dffe0:	mov    $0x750,%edx
  6dffe5:	mov    %rax,%rdi
  6dffe8:	call   *0x36228a(%rip)        # a42278 <memcpy@GLIBC_2.14>
  6dffee:	mov    %rbx,0x1e0(%rsp)
  6dfff6:	lea    0x1e8(%rsp),%rdx
  6dfffe:	movq   $0x0,(%rsp)
  6e0006:	lea    0x110(%rsp),%rdi
  6e000e:	mov    $0x8,%r8d
  6e0014:	mov    %rbx,%rsi
  6e0017:	mov    $0x1,%ecx
  6e001c:	xor    %r9d,%r9d
  6e001f:	call   6e8670 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::describe_with_changed>
  6e0024:	mov    0x110(%rsp),%r12
  6e002c:	cmp    $0xfffffffffffffffe,%r12
  6e0030:	jne    6e3693 <text_column_public_control::main+0x4053>
  6e0036:	lea    0x110(%rsp),%rdi
  6e003e:	mov    %rbx,%rsi
  6e0041:	call   70d1e0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present>
  6e0046:	mov    0x110(%rsp),%r12
  6e004e:	cmp    $0xfffffffffffffffe,%r12
  6e0052:	jne    6e3693 <text_column_public_control::main+0x4053>
  6e0058:	mov    0x1e0(%rsp),%rsi
  6e0060:	mov    %rsi,0x30(%rsp)
  6e0065:	lea    0x260(%rsp),%rdi
  6e006d:	call   6b5c90 <text_column_public_control::ack::<text_column_public_control::Input>>
  6e0072:	mov    0x30(%rsp),%rbp
  6e0077:	test   %rbp,%rbp
  6e007a:	je     6e3909 <text_column_public_control::main+0x42c9>
  6e0080:	cmpb   $0x0,0x74e(%rbp)
  6e0087:	jne    6e3910 <text_column_public_control::main+0x42d0>
  6e008d:	mov    $0x12,%eax
  6e0092:	cmpb   $0x1,0x74a(%rbp)
  6e0099:	jne    6e3915 <text_column_public_control::main+0x42d5>
  6e009f:	cmpb   $0x0,0x74b(%rbp)
  6e00a6:	jne    6e3915 <text_column_public_control::main+0x42d5>
  6e00ac:	cmpb   $0x0,0x74c(%rbp)
  6e00b3:	je     6e3915 <text_column_public_control::main+0x42d5>
  6e00b9:	cmpq   $0xffffffffffffffff,0x5b8(%rbp)
  6e00c1:	jne    6e3915 <text_column_public_control::main+0x42d5>
  6e00c7:	mov    0x690(%rbp),%rcx
  6e00ce:	cmp    0x698(%rbp),%rcx
  6e00d5:	jne    6e3915 <text_column_public_control::main+0x42d5>
  6e00db:	mov    0x6a8(%rbp),%rbx
  6e00e2:	cmp    0x6a0(%rbp),%rbx
  6e00e9:	jne    6e3915 <text_column_public_control::main+0x42d5>
  6e00ef:	movss  0x740(%rbp),%xmm0
  6e00f7:	ucomiss 0x744(%rbp),%xmm0
  6e00fe:	jne    6e3915 <text_column_public_control::main+0x42d5>
  6e0104:	jp     6e3915 <text_column_public_control::main+0x42d5>
  6e010a:	mov    0x6c8(%rbp),%rax
  6e0111:	mov    %rax,0x40(%rsp)
  6e0116:	mov    0x5a8(%rbp),%rax
  6e011d:	mov    %rax,0x10(%rsp)
  6e0122:	mov    0x5b0(%rbp),%r12
  6e0129:	movups 0x618(%rbp),%xmm0
  6e0130:	movaps %xmm0,0x20(%rsp)
  6e0135:	mov    0x640(%rbp),%r13
  6e013c:	test   %r13,%r13
  6e013f:	je     6e0af3 <text_column_public_control::main+0x14b3>
  6e0145:	mov    0xe0(%r13),%rax
  6e014c:	test   %rax,%rax
  6e014f:	je     6e0b8d <text_column_public_control::main+0x154d>
  6e0155:	mov    0x38(%rax),%ecx
  6e0158:	mov    %ecx,0xc70(%rsp)
  6e015f:	movups 0x28(%rax),%xmm0
  6e0163:	movaps %xmm0,0xc60(%rsp)
  6e016b:	movzbl 0x3c(%rax),%r15d
  6e0170:	movzbl 0x3f(%rax),%ecx
  6e0174:	mov    %cl,0x72(%rsp)
  6e0178:	movzwl 0x3d(%rax),%eax
  6e017c:	mov    %ax,0x70(%rsp)
  6e0181:	mov    0x100(%r13),%rsi
  6e0188:	test   %rsi,%rsi
  6e018b:	jne    6e0ba0 <text_column_public_control::main+0x1560>
  6e0191:	jmp    6e0af6 <text_column_public_control::main+0x14b6>
  6e0196:	cmp    $0x5,%rcx
  6e019a:	jne    6e35fc <text_column_public_control::main+0x3fbc>
  6e01a0:	mov    $0x65707974,%ecx
  6e01a5:	xor    (%rax),%ecx
  6e01a7:	movzbl 0x4(%rax),%eax
  6e01ab:	xor    $0x64,%eax
  6e01ae:	mov    $0x1,%bl
  6e01b0:	or     %ecx,%eax
  6e01b2:	jne    6e35fc <text_column_public_control::main+0x3fbc>
  6e01b8:	movzbl 0x20(%rsp),%r15d
  6e01be:	movzbl %bl,%edx
  6e01c1:	lea    0x260(%rsp),%rdi
  6e01c9:	mov    %r15d,%esi
  6e01cc:	mov    %edx,0x10(%rsp)
  6e01d0:	call   6e4ab0 <text_column_public_control::mount>
  6e01d5:	mov    0x260(%rsp),%rdi
  6e01dd:	mov    %rdi,0x8(%rsp)
  6e01e2:	movups 0x288(%rsp),%xmm0
  6e01ea:	movaps %xmm0,0x130(%rsp)
  6e01f2:	movups 0x278(%rsp),%xmm0
  6e01fa:	movaps %xmm0,0x120(%rsp)
  6e0202:	movdqu 0x268(%rsp),%xmm0
  6e020b:	movdqa %xmm0,0x110(%rsp)
  6e0214:	lea    0x128(%rsp),%r14
  6e021c:	mov    0x120(%rsp),%r12
  6e0224:	cmp    0x128(%rsp),%r12
  6e022c:	jne    6e3218 <text_column_public_control::main+0x3bd8>
  6e0232:	mov    %ebx,0x40(%rsp)
  6e0236:	cmpq   $0x0,0x110(%rsp)
  6e023f:	jne    6e3248 <text_column_public_control::main+0x3c08>
  6e0245:	lea    -0x692c0c(%rip),%rcx        # 4d640 <GCC_except_table0+0xd89c>
  6e024c:	mov    $0x6,%r8d
  6e0252:	mov    %r15d,%esi
  6e0255:	mov    0x10(%rsp),%edx
  6e0259:	call   6db9b0 <text_column_public_control::emit_state>
  6e025e:	mov    0x8(%rsp),%rsi
  6e0263:	lea    0x1c0(%rsp),%rdi
  6e026b:	call   6b5ed0 <text_column_public_control::observe::<text_column_public_control::Model>>
  6e0270:	mov    0x8(%rsp),%rsi
  6e0275:	lea    0xf8(%rsp),%rdi
  6e027d:	call   6e5380 <text_column_public_control::pointers>
  6e0282:	mov    0x8(%rsp),%rax
  6e0287:	test   %rax,%rax
  6e028a:	je     6e380b <text_column_public_control::main+0x41cb>
  6e0290:	pxor   %xmm0,%xmm0
  6e0294:	movdqu %xmm0,0x760(%rax)
  6e029c:	movdqu %xmm0,0x750(%rax)
  6e02a4:	movdqu %xmm0,0x740(%rax)
  6e02ac:	movdqu %xmm0,0x730(%rax)
  6e02b4:	movdqu %xmm0,0x720(%rax)
  6e02bc:	movdqu %xmm0,0x710(%rax)
  6e02c4:	movq   $0x0,0x770(%rax)
  6e02cf:	lea    0x70(%rsp),%rdi
  6e02d4:	lea    0x8(%rsp),%rsi
  6e02d9:	mov    %r15d,%edx
  6e02dc:	mov    0x10(%rsp),%ecx
  6e02e0:	xor    %r8d,%r8d
  6e02e3:	call   6dd800 <text_column_public_control::edit>
  6e02e8:	mov    0x8(%rsp),%rsi
  6e02ed:	test   %rsi,%rsi
  6e02f0:	je     6e3850 <text_column_public_control::main+0x4210>
  6e02f6:	cmpb   $0x0,0x78e(%rsi)
  6e02fd:	jne    6e3857 <text_column_public_control::main+0x4217>
  6e0303:	mov    0x6f0(%rsi),%rax
  6e030a:	mov    %rax,0x150(%rsp)
  6e0312:	test   %rax,%rax
  6e0315:	je     6e385e <text_column_public_control::main+0x421e>
  6e031b:	mov    0x6f8(%rsi),%rax
  6e0322:	mov    %rax,0x148(%rsp)
  6e032a:	lea    0x260(%rsp),%rbx
  6e0332:	mov    %rbx,%rdi
  6e0335:	call   6b5ed0 <text_column_public_control::observe::<text_column_public_control::Model>>
  6e033a:	mov    0x260(%rsp),%rax
  6e0342:	cmp    0x1c0(%rsp),%rax
  6e034a:	jne    6e3141 <text_column_public_control::main+0x3b01>
  6e0350:	mov    0x268(%rsp),%rax
  6e0358:	cmp    0x1c8(%rsp),%rax
  6e0360:	jne    6e3141 <text_column_public_control::main+0x3b01>
  6e0366:	mov    0x270(%rsp),%rax
  6e036e:	cmp    0x1d0(%rsp),%rax
  6e0376:	jne    6e3141 <text_column_public_control::main+0x3b01>
  6e037c:	lea    0x1(%r12),%rax
  6e0381:	mov    %rax,0x260(%rsp)
  6e0389:	cmp    %rax,0x80(%rsp)
  6e0391:	jne    6e32a8 <text_column_public_control::main+0x3c68>
  6e0397:	cmp    %r12,0x88(%rsp)
  6e039f:	jne    6e3315 <text_column_public_control::main+0x3cd5>
  6e03a5:	mov    %rax,0x268(%rsp)
  6e03ad:	cmp    %rax,0x78(%rsp)
  6e03b2:	movq   $0x1,0x260(%rsp)
  6e03be:	sete   %al
  6e03c1:	cmpb   $0x0,0x70(%rsp)
  6e03c6:	je     6e3164 <text_column_public_control::main+0x3b24>
  6e03cc:	test   %al,%al
  6e03ce:	je     6e316e <text_column_public_control::main+0x3b2e>
  6e03d4:	mov    0x8(%rsp),%rdi
  6e03d9:	lea    -0x69ea10(%rip),%rcx        # 419d0 <GCC_except_table0+0x1c2c>
  6e03e0:	mov    $0x8,%r8d
  6e03e6:	mov    %r15d,%esi
  6e03e9:	mov    0x10(%rsp),%edx
  6e03ed:	call   6db9b0 <text_column_public_control::emit_state>
  6e03f2:	mov    0x8(%rsp),%rsi
  6e03f7:	lea    0xc60(%rsp),%rdi
  6e03ff:	call   6b5db0 <text_column_public_control::ack::<text_column_public_control::Model>>
  6e0404:	mov    0xc70(%rsp),%rax
  6e040c:	cmp    0xc78(%rsp),%rax
  6e0414:	jne    6e333c <text_column_public_control::main+0x3cfc>
  6e041a:	cmpq   $0x0,0xc60(%rsp)
  6e0423:	jne    6e3365 <text_column_public_control::main+0x3d25>
  6e0429:	mov    0x8(%rsp),%rsi
  6e042e:	lea    0x190(%rsp),%rdi
  6e0436:	call   6e5380 <text_column_public_control::pointers>
  6e043b:	mov    0x100(%rsp),%r13
  6e0443:	mov    0x108(%rsp),%rdi
  6e044b:	mov    0x198(%rsp),%r14
  6e0453:	mov    0x1a0(%rsp),%rcx
  6e045b:	cmp    %rdi,%rcx
  6e045e:	mov    %rdi,%rax
  6e0461:	mov    %rcx,0x50(%rsp)
  6e0466:	cmovb  %rcx,%rax
  6e046a:	test   %rax,%rax
  6e046d:	je     6e0b15 <text_column_public_control::main+0x14d5>
  6e0473:	cmp    $0x4,%rax
  6e0477:	mov    0x40(%rsp),%ebp
  6e047b:	jae    6e0b20 <text_column_public_control::main+0x14e0>
  6e0481:	xor    %ebx,%ebx
  6e0483:	xor    %ecx,%ecx
  6e0485:	jmp    6e3fc2 <text_column_public_control::main+0x4982>
  6e048a:	cmp    $0x5,%rcx
  6e048e:	jne    6e35fc <text_column_public_control::main+0x3fbc>
  6e0494:	mov    $0x65707974,%ecx
  6e0499:	xor    (%rax),%ecx
  6e049b:	movzbl 0x4(%rax),%eax
  6e049f:	xor    $0x64,%eax
  6e04a2:	or     %ecx,%eax
  6e04a4:	mov    $0x1,%bl
  6e04a6:	jne    6e35fc <text_column_public_control::main+0x3fbc>
  6e04ac:	movzbl %bpl,%esi
  6e04b0:	movzbl %bl,%r14d
  6e04b4:	lea    0x260(%rsp),%rdi
  6e04bc:	mov    %rsi,0x10(%rsp)
  6e04c1:	mov    %r14d,%edx
  6e04c4:	call   6e4ab0 <text_column_public_control::mount>
  6e04c9:	mov    0x260(%rsp),%rax
  6e04d1:	mov    %rax,0x30(%rsp)
  6e04d6:	cmp    $0x3,%bpl
  6e04da:	jne    6e052b <text_column_public_control::main+0xeeb>
  6e04dc:	lea    0x260(%rsp),%rdi
  6e04e4:	lea    0x30(%rsp),%rsi
  6e04e9:	mov    $0x3,%edx
  6e04ee:	mov    %r14d,%ecx
  6e04f1:	xor    %r8d,%r8d
  6e04f4:	call   6dd800 <text_column_public_control::edit>
  6e04f9:	lea    0x260(%rsp),%rax
  6e0501:	lea    0x260(%rsp),%rdi
  6e0509:	lea    0x30(%rsp),%rsi
  6e050e:	mov    $0x1,%r8d
  6e0514:	mov    $0x3,%edx
  6e0519:	mov    %r14d,%ecx
  6e051c:	call   6dd800 <text_column_public_control::edit>
  6e0521:	lea    0x260(%rsp),%rax
  6e0529:	jmp    6e0550 <text_column_public_control::main+0xf10>
  6e052b:	lea    0x260(%rsp),%rdi
  6e0533:	lea    0x30(%rsp),%rsi
  6e0538:	mov    0x10(%rsp),%rdx
  6e053d:	mov    %r14d,%ecx
  6e0540:	xor    %r8d,%r8d
  6e0543:	call   6dd800 <text_column_public_control::edit>
  6e0548:	lea    0x260(%rsp),%rax
  6e0550:	mov    0x30(%rsp),%rsi
  6e0555:	lea    0x70(%rsp),%rdi
  6e055a:	call   6b5db0 <text_column_public_control::ack::<text_column_public_control::Model>>
  6e055f:	mov    0x30(%rsp),%rax
  6e0564:	test   %rax,%rax
  6e0567:	je     6e375f <text_column_public_control::main+0x411f>
  6e056d:	pxor   %xmm0,%xmm0
  6e0571:	movdqu %xmm0,0x760(%rax)
  6e0579:	movdqu %xmm0,0x750(%rax)
  6e0581:	movdqu %xmm0,0x740(%rax)
  6e0589:	movdqu %xmm0,0x730(%rax)
  6e0591:	movdqu %xmm0,0x720(%rax)
  6e0599:	movdqu %xmm0,0x710(%rax)
  6e05a1:	movq   $0x0,0x770(%rax)
  6e05ac:	movdqu 0x70(%rsp),%xmm0
  6e05b2:	movups 0x80(%rsp),%xmm1
  6e05ba:	movdqu 0x90(%rsp),%xmm2
  6e05c3:	movdqa %xmm2,0xc80(%rsp)
  6e05cc:	movaps %xmm1,0xc70(%rsp)
  6e05d4:	movdqa %xmm0,0xc60(%rsp)
  6e05dd:	call   *0x361f35(%rip)        # a42518 <_DYNAMIC+0x528>
  6e05e3:	mov    %r14,0xd8(%rsp)
  6e05eb:	mov    %ebx,0x20(%rsp)
  6e05ef:	mov    %bpl,0x50(%rsp)
  6e05f4:	mov    %rax,0xf8(%rsp)
  6e05fc:	mov    %edx,0x100(%rsp)
  6e0603:	lea    -0x68fa42(%rip),%rcx        # 50bc8 <GCC_except_table0+0x10e24>
  6e060a:	mov    0x10(%rsp),%rax
  6e060f:	mov    (%rcx,%rax,8),%rax
  6e0613:	mov    $0x1,%r15d
  6e0619:	lea    0x260(%rsp),%r12
  6e0621:	mov    $0x1,%ebx
  6e0626:	mov    %rax,0x40(%rsp)
  6e062b:	nopl   0x0(%rax,%rax,1)
  6e0630:	cmp    %rax,%r15
  6e0633:	adc    $0x0,%rbx
  6e0637:	lea    0x30(%rsp),%rax
  6e063c:	mov    %rax,0x260(%rsp)
  6e0644:	mov    0x260(%rsp),%r13
  6e064c:	mov    0x10(%rsp),%rax
  6e0651:	mov    %al,0x260(%rsp)
  6e0658:	movzbl 0x260(%rsp),%eax
  6e0660:	mov    0x20(%rsp),%ecx
  6e0664:	mov    %cl,0x260(%rsp)
  6e066b:	movzbl 0x260(%rsp),%ecx
  6e0673:	mov    %r15,0x260(%rsp)
  6e067b:	mov    0x260(%rsp),%rbp
  6e0683:	movzbl %cl,%r14d
  6e0687:	cmp    $0x3,%al
  6e0689:	jne    6e06d0 <text_column_public_control::main+0x1090>
  6e068b:	add    %ebp,%ebp
  6e068d:	and    $0x2,%ebp
  6e0690:	mov    %r12,%rdi
  6e0693:	mov    %r13,%rsi
  6e0696:	mov    $0x3,%edx
  6e069b:	mov    %r14d,%ecx
  6e069e:	mov    %rbp,%r8
  6e06a1:	call   6dd800 <text_column_public_control::edit>
  6e06a6:	or     $0x1,%rbp
  6e06aa:	mov    %r12,%rdi
  6e06ad:	mov    %r13,%rsi
  6e06b0:	mov    $0x3,%edx
  6e06b5:	mov    %r14d,%ecx
  6e06b8:	mov    %rbp,%r8
  6e06bb:	call   6dd800 <text_column_public_control::edit>
  6e06c0:	jmp    6e06e4 <text_column_public_control::main+0x10a4>
  6e06c2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6e06d0:	movzbl %al,%edx
  6e06d3:	mov    %r12,%rdi
  6e06d6:	mov    %r13,%rsi
  6e06d9:	mov    %r14d,%ecx
  6e06dc:	mov    %rbp,%r8
  6e06df:	call   6dd800 <text_column_public_control::edit>
  6e06e4:	mov    0x0(%r13),%rsi
  6e06e8:	mov    %r12,%rdi
  6e06eb:	call   6b5db0 <text_column_public_control::ack::<text_column_public_control::Model>>
  6e06f0:	movups 0x260(%rsp),%xmm0
  6e06f8:	movups 0x270(%rsp),%xmm1
  6e0700:	movups 0x280(%rsp),%xmm2
  6e0708:	movaps %xmm2,0x9e0(%rsp)
  6e0710:	movaps %xmm1,0x9d0(%rsp)
  6e0718:	movaps %xmm0,0x9c0(%rsp)
  6e0720:	lea    0x9c0(%rsp),%rax
  6e0728:	movdqa 0x9c0(%rsp),%xmm0
  6e0731:	movaps 0x9d0(%rsp),%xmm1
  6e0739:	movdqa 0x9e0(%rsp),%xmm2
  6e0742:	movdqa %xmm0,0xc60(%rsp)
  6e074b:	movaps %xmm1,0xc70(%rsp)
  6e0753:	movdqa %xmm2,0xc80(%rsp)
  6e075c:	mov    0x40(%rsp),%rax
  6e0761:	cmp    %rax,%r15
  6e0764:	jae    6e0772 <text_column_public_control::main+0x1132>
  6e0766:	mov    %rbx,%r15
  6e0769:	cmp    %rax,%rbx
  6e076c:	jbe    6e0630 <text_column_public_control::main+0xff0>
  6e0772:	lea    0xf8(%rsp),%rdi
  6e077a:	call   *0x361da0(%rip)        # a42520 <_DYNAMIC+0x530>
  6e0780:	movzbl 0x50(%rsp),%edi
  6e0785:	mov    0x20(%rsp),%ebp
  6e0789:	mov    0xd8(%rsp),%r14
  6e0791:	lea    -0x68fbd0(%rip),%r15        # 50bc8 <GCC_except_table0+0x10e24>
  6e0798:	mov    %edx,%esi
  6e079a:	cmp    $0x3,%dil
  6e079e:	sete   %cl
  6e07a1:	mov    $0x3b9aca00,%edx
  6e07a6:	mul    %rdx
  6e07a9:	mov    %esi,%esi
  6e07ab:	add    %rax,%rsi
  6e07ae:	adc    $0x0,%rdx
  6e07b2:	mov    %rsi,0x190(%rsp)
  6e07ba:	mov    %rdx,0x198(%rsp)
  6e07c2:	lea    0x30(%rsp),%rax
  6e07c7:	mov    %rax,0x260(%rsp)
  6e07cf:	lea    0x260(%rsp),%rdx
  6e07d7:	mov    0x10(%rsp),%rax
  6e07dc:	mov    (%r15,%rax,8),%rax
  6e07e0:	shl    %cl,%rax
  6e07e3:	mov    %rax,0x230(%rsp)
  6e07eb:	lea    0xc70(%rsp),%rbx
  6e07f3:	mov    0x80(%rsp),%rcx
  6e07fb:	add    %rax,%rcx
  6e07fe:	mov    %rcx,0x260(%rsp)
  6e0806:	cmp    %rcx,0xc70(%rsp)
  6e080e:	jne    6e3239 <text_column_public_control::main+0x3bf9>
  6e0814:	lea    0xc78(%rsp),%r12
  6e081c:	cmp    %rcx,0xc78(%rsp)
  6e0824:	jne    6e3266 <text_column_public_control::main+0x3c26>
  6e082a:	cmpq   $0x0,0xc60(%rsp)
  6e0833:	jne    6e3275 <text_column_public_control::main+0x3c35>
  6e0839:	cmpb   $0x1,0xc88(%rsp)
  6e0841:	jne    6e328a <text_column_public_control::main+0x3c4a>
  6e0847:	mov    0x30(%rsp),%rsi
  6e084c:	test   %rsi,%rsi
  6e084f:	je     6e38cc <text_column_public_control::main+0x428c>
  6e0855:	mov    0x770(%rsi),%rcx
  6e085c:	mov    %rcx,0xa20(%rsp)
  6e0864:	movups 0x760(%rsi),%xmm0
  6e086b:	movaps %xmm0,0xa10(%rsp)
  6e0873:	movups 0x750(%rsi),%xmm0
  6e087a:	movaps %xmm0,0xa00(%rsp)
  6e0882:	movdqu 0x710(%rsi),%xmm0
  6e088a:	movups 0x720(%rsi),%xmm1
  6e0891:	movdqu 0x730(%rsi),%xmm2
  6e0899:	movdqu 0x740(%rsi),%xmm3
  6e08a1:	movdqa %xmm3,0x9f0(%rsp)
  6e08aa:	movdqa %xmm2,0x9e0(%rsp)
  6e08b3:	movaps %xmm1,0x9d0(%rsp)
  6e08bb:	movdqa %xmm0,0x9c0(%rsp)
  6e08c4:	mov    %rax,0x260(%rsp)
  6e08cc:	cmp    %rax,0x9d0(%rsp)
  6e08d4:	jne    6e32bc <text_column_public_control::main+0x3c7c>
  6e08da:	cmp    $0x7,%dil
  6e08de:	setne  %al
  6e08e1:	test   %bpl,%al
  6e08e4:	je     6e090b <text_column_public_control::main+0x12cb>
  6e08e6:	lea    -0x69f0fd(%rip),%rdx        # 417f0 <GCC_except_table0+0x1a4c>
  6e08ed:	cmpq   $0x0,0x9c8(%rsp)
  6e08f6:	jne    6e340c <text_column_public_control::main+0x3dcc>
  6e08fc:	cmpq   $0x0,0x9c0(%rsp)
  6e0905:	jne    6e341d <text_column_public_control::main+0x3ddd>
  6e090b:	lea    0x260(%rsp),%rdi
  6e0913:	call   6b5ed0 <text_column_public_control::observe::<text_column_public_control::Model>>
  6e0918:	mov    0x260(%rsp),%rax
  6e0920:	mov    0x268(%rsp),%rcx
  6e0928:	mov    %rax,0x160(%rsp)
  6e0930:	mov    %rcx,0x178(%rsp)
  6e0938:	mov    0x270(%rsp),%rax
  6e0940:	mov    %rax,0xe0(%rsp)
  6e0948:	mov    0x10(%rsp),%rdx
  6e094d:	shl    $0x3,%edx
  6e0950:	lea    0x343a79(%rip),%rax        # a243d0 <__frame_dummy_init_array_entry+0x28e0>
  6e0957:	mov    (%rdx,%rax,1),%rax
  6e095b:	lea    -0x68fd5a(%rip),%rcx        # 50c08 <GCC_except_table0+0x10e64>
  6e0962:	mov    (%rdx,%rcx,1),%rcx
  6e0966:	mov    (%rdx,%r15,1),%rdx
  6e096a:	mov    %rax,0x1e0(%rsp)
  6e0972:	mov    %rcx,0x1e8(%rsp)
  6e097a:	lea    -0x6934df(%rip),%rax        # 4d4a2 <GCC_except_table0+0xd6fe>
  6e0981:	lea    -0x6934ec(%rip),%rcx        # 4d49c <GCC_except_table0+0xd6f8>
  6e0988:	test   %bpl,%bpl
  6e098b:	cmovne %rax,%rcx
  6e098f:	mov    $0x6,%eax
  6e0994:	sub    %r14,%rax
  6e0997:	mov    %rcx,0x110(%rsp)
  6e099f:	mov    %rax,0x118(%rsp)
  6e09a7:	mov    %rdx,0x1c0(%rsp)
  6e09af:	lea    0x9c8(%rsp),%rax
  6e09b7:	lea    0x1e0(%rsp),%rcx
  6e09bf:	mov    %rcx,0x260(%rsp)
  6e09c7:	lea    0x463c2(%rip),%rcx        # 726d90 <<&str as core::fmt::Display>::fmt>
  6e09ce:	mov    %rcx,0x268(%rsp)
  6e09d6:	lea    0x110(%rsp),%rdx
  6e09de:	mov    %rdx,0x270(%rsp)
  6e09e6:	mov    %rcx,0x278(%rsp)
  6e09ee:	lea    0x1c0(%rsp),%rcx
  6e09f6:	mov    %rcx,0x280(%rsp)
  6e09fe:	mov    0x361aa3(%rip),%rcx        # a424a8 <_DYNAMIC+0x4b8>
  6e0a05:	mov    %rcx,0x288(%rsp)
  6e0a0d:	lea    0x230(%rsp),%rdx
  6e0a15:	mov    %rdx,0x290(%rsp)
  6e0a1d:	mov    %rcx,0x298(%rsp)
  6e0a25:	lea    0x160(%rsp),%rdx
  6e0a2d:	mov    %rdx,0x2a0(%rsp)
  6e0a35:	mov    %rcx,0x2a8(%rsp)
  6e0a3d:	lea    0x178(%rsp),%rdx
  6e0a45:	mov    %rdx,0x2b0(%rsp)
  6e0a4d:	mov    %rcx,0x2b8(%rsp)
  6e0a55:	lea    0xe0(%rsp),%rcx
  6e0a5d:	mov    %rcx,0x2c0(%rsp)
  6e0a65:	mov    0x361a44(%rip),%rcx        # a424b0 <_DYNAMIC+0x4c0>
  6e0a6c:	mov    %rcx,0x2c8(%rsp)
  6e0a74:	mov    %rbx,0x2d0(%rsp)
  6e0a7c:	mov    %rcx,0x2d8(%rsp)
  6e0a84:	mov    %r12,0x2e0(%rsp)
  6e0a8c:	mov    %rcx,0x2e8(%rsp)
  6e0a94:	mov    %rax,0x2f0(%rsp)
  6e0a9c:	mov    %rcx,0x2f8(%rsp)
  6e0aa4:	lea    0x190(%rsp),%rax
  6e0aac:	mov    %rax,0x300(%rsp)
  6e0ab4:	mov    0x361a6d(%rip),%rax        # a42528 <_DYNAMIC+0x538>
  6e0abb:	mov    %rax,0x308(%rsp)
  6e0ac3:	lea    -0x695924(%rip),%rdi        # 4b1a6 <GCC_except_table0+0xb402>
  6e0aca:	lea    0x260(%rsp),%rsi
  6e0ad2:	call   *0x3619e8(%rip)        # a424c0 <_DYNAMIC+0x4d0>
  6e0ad8:	mov    0x30(%rsp),%r14
  6e0add:	test   %r14,%r14
  6e0ae0:	je     6e47bc <text_column_public_control::main+0x517c>
  6e0ae6:	mov    %r14,%rdi
  6e0ae9:	call   6c00d0 <core::ptr::drop_glue::<gpui::runtime::Runtime<text_column_public_control::Model>>>
  6e0aee:	jmp    6e47a9 <text_column_public_control::main+0x5169>
  6e0af3:	mov    $0x2,%r15b
  6e0af6:	movq   $0x4,0x9c0(%rsp)
  6e0b02:	xorps  %xmm0,%xmm0
  6e0b05:	movups %xmm0,0x9c8(%rsp)
  6e0b0d:	mov    %r12,%r14
  6e0b10:	jmp    6e0bb5 <text_column_public_control::main+0x1575>
  6e0b15:	xor    %ebx,%ebx
  6e0b17:	mov    0x40(%rsp),%ebp
  6e0b1b:	jmp    6e3fdd <text_column_public_control::main+0x499d>
  6e0b20:	mov    %rax,%rcx
  6e0b23:	and    $0xfffffffffffffffc,%rcx
  6e0b27:	pxor   %xmm0,%xmm0
  6e0b2b:	xor    %edx,%edx
  6e0b2d:	xorps  %xmm1,%xmm1
  6e0b30:	movdqu 0x0(%r13,%rdx,8),%xmm2
  6e0b37:	movdqu 0x10(%r13,%rdx,8),%xmm3
  6e0b3e:	movdqu (%r14,%rdx,8),%xmm4
  6e0b44:	pcmpeqd %xmm2,%xmm4
  6e0b48:	movdqu 0x10(%r14,%rdx,8),%xmm2
  6e0b4f:	pcmpeqd %xmm3,%xmm2
  6e0b53:	pshufd $0xb1,%xmm4,%xmm3
  6e0b58:	pand   %xmm4,%xmm3
  6e0b5c:	psubq  %xmm3,%xmm1
  6e0b60:	pshufd $0xb1,%xmm2,%xmm3
  6e0b65:	pand   %xmm2,%xmm3
  6e0b69:	psubq  %xmm3,%xmm0
  6e0b6d:	add    $0x4,%rdx
  6e0b71:	cmp    %rdx,%rcx
  6e0b74:	jne    6e0b30 <text_column_public_control::main+0x14f0>
  6e0b76:	paddq  %xmm1,%xmm0
  6e0b7a:	pshufd $0xee,%xmm0,%xmm1
  6e0b7f:	paddq  %xmm0,%xmm1
  6e0b83:	movq   %xmm1,%rbx
  6e0b88:	jmp    6e3fd8 <text_column_public_control::main+0x4998>
  6e0b8d:	mov    $0x2,%r15b
  6e0b90:	mov    0x100(%r13),%rsi
  6e0b97:	test   %rsi,%rsi
  6e0b9a:	je     6e0af6 <text_column_public_control::main+0x14b6>
  6e0ba0:	lea    0x9c0(%rsp),%rdi
  6e0ba8:	call   *0x36168a(%rip)        # a42238 <_DYNAMIC+0x248>
  6e0bae:	mov    0x5b0(%rbp),%r14
  6e0bb5:	lea    0x5e0(%rbp),%rax
  6e0bbc:	mov    %rax,0x50(%rsp)
  6e0bc1:	mov    %rax,0x2b0(%rsp)
  6e0bc9:	mov    0x40(%rsp),%rax
  6e0bce:	mov    %rax,0x280(%rsp)
  6e0bd6:	mov    %rbx,0x288(%rsp)
  6e0bde:	mov    0x10(%rsp),%rax
  6e0be3:	mov    %rax,0x270(%rsp)
  6e0beb:	mov    %r12,0x278(%rsp)
  6e0bf3:	movaps 0x20(%rsp),%xmm0
  6e0bf8:	movaps %xmm0,0x260(%rsp)
  6e0c00:	mov    %r13,0x290(%rsp)
  6e0c08:	mov    0x9c0(%rsp),%rax
  6e0c10:	mov    %rax,0x298(%rsp)
  6e0c18:	mov    0x9c8(%rsp),%rax
  6e0c20:	mov    %rax,0x2a0(%rsp)
  6e0c28:	mov    0x9d0(%rsp),%rax
  6e0c30:	mov    %rax,0x2a8(%rsp)
  6e0c38:	movaps 0xc60(%rsp),%xmm0
  6e0c40:	movups %xmm0,0x2b8(%rsp)
  6e0c48:	mov    0xc70(%rsp),%eax
  6e0c4f:	mov    %eax,0x2c8(%rsp)
  6e0c56:	mov    %r15b,0x2cc(%rsp)
  6e0c5e:	movzwl 0x70(%rsp),%eax
  6e0c63:	mov    %ax,0x2cd(%rsp)
  6e0c6b:	movzbl 0x72(%rsp),%eax
  6e0c70:	mov    %al,0x2cf(%rsp)
  6e0c77:	test   %r14,%r14
  6e0c7a:	je     6e371b <text_column_public_control::main+0x40db>
  6e0c80:	mov    $0x20,%r12d
  6e0c86:	xor    %r13d,%r13d
  6e0c89:	lea    0x260(%rsp),%r15
  6e0c91:	mov    0x361898(%rip),%rbx        # a42530 <_DYNAMIC+0x540>
  6e0c98:	lea    0x342231(%rip),%rax        # a22ed0 <__frame_dummy_init_array_entry+0x13e0>
  6e0c9f:	mov    %rax,0x40(%rsp)
  6e0ca4:	movq   $0x0,0x20(%rsp)
  6e0cad:	movq   $0x0,0x10(%rsp)
  6e0cb6:	jmp    6e0ccc <text_column_public_control::main+0x168c>
  6e0cb8:	nopl   0x0(%rax,%rax,1)
  6e0cc0:	inc    %r13
  6e0cc3:	add    $0x40,%r12
  6e0cc7:	cmp    %r13,%r14
  6e0cca:	je     6e0d23 <text_column_public_control::main+0x16e3>
  6e0ccc:	mov    %r15,%rdi
  6e0ccf:	mov    %r13,%rsi
  6e0cd2:	call   *%rbx
  6e0cd4:	test   %rax,%rax
  6e0cd7:	setne  %cl
  6e0cda:	cmp    $0x5,%rdx
  6e0cde:	sete   %dl
  6e0ce1:	and    %cl,%dl
  6e0ce3:	cmp    $0x1,%dl
  6e0ce6:	jne    6e0cc0 <text_column_public_control::main+0x1680>
  6e0ce8:	mov    (%rax),%ecx
  6e0cea:	mov    $0x63656863,%edx
  6e0cef:	xor    %edx,%ecx
  6e0cf1:	movzbl 0x4(%rax),%eax
  6e0cf5:	xor    $0x6b,%eax
  6e0cf8:	or     %ecx,%eax
  6e0cfa:	jne    6e0cc0 <text_column_public_control::main+0x1680>
  6e0cfc:	mov    0x5b0(%rbp),%rsi
  6e0d03:	cmp    %rsi,%r13
  6e0d06:	jae    6e3a5f <text_column_public_control::main+0x441f>
  6e0d0c:	mov    0x5a8(%rbp),%rax
  6e0d13:	incq   0x10(%rsp)
  6e0d18:	mov    (%rax,%r12,1),%rax
  6e0d1c:	mov    %rax,0x20(%rsp)
  6e0d21:	jmp    6e0cc0 <text_column_public_control::main+0x1680>
  6e0d23:	mov    0x10(%rsp),%rcx
  6e0d28:	cmp    $0x1,%rcx
  6e0d2c:	jne    6e370d <text_column_public_control::main+0x40cd>
  6e0d32:	mov    0x50(%rsp),%rdi
  6e0d37:	mov    0x20(%rsp),%rsi
  6e0d3c:	call   *0x36174e(%rip)        # a42490 <_DYNAMIC+0x4a0>
  6e0d42:	mov    0x30(%rsp),%r12
  6e0d47:	test   %r12,%r12
  6e0d4a:	je     6e3957 <text_column_public_control::main+0x4317>
  6e0d50:	mov    %rax,%r14
  6e0d53:	lea    0x38(%rsp),%rax
  6e0d58:	mov    %r12,0x70(%rsp)
  6e0d5d:	mov    %rax,0x78(%rsp)
  6e0d62:	cmpb   $0x1,0x74e(%r12)
  6e0d6b:	je     6e3974 <text_column_public_control::main+0x4334>
  6e0d71:	cmp    0x5e0(%r12),%r14
  6e0d79:	jne    6e3985 <text_column_public_control::main+0x4345>
  6e0d7f:	mov    %rdx,%rbx
  6e0d82:	lea    0x260(%rsp),%rdi
  6e0d8a:	mov    %r12,%rsi
  6e0d8d:	call   70ca80 <<gpui::runtime::Runtime<text_column_public_control::Input>>::resolve_identity>
  6e0d92:	mov    0x260(%rsp),%rax
  6e0d9a:	cmp    $0xfffffffffffffffe,%rax
  6e0d9e:	jne    6e398c <text_column_public_control::main+0x434c>
  6e0da4:	cmpb   $0x1,0x74a(%r12)
  6e0dad:	jne    6e3607 <text_column_public_control::main+0x3fc7>
  6e0db3:	cmpb   $0x0,0x74b(%r12)
  6e0dbc:	jne    6e3607 <text_column_public_control::main+0x3fc7>
  6e0dc2:	cmpb   $0x0,0x74c(%r12)
  6e0dcb:	je     6e3607 <text_column_public_control::main+0x3fc7>
  6e0dd1:	cmpq   $0xffffffffffffffff,0x5b8(%r12)
  6e0dda:	jne    6e3607 <text_column_public_control::main+0x3fc7>
  6e0de0:	mov    0x690(%r12),%rax
  6e0de8:	cmp    0x698(%r12),%rax
  6e0df0:	jne    6e3607 <text_column_public_control::main+0x3fc7>
  6e0df6:	mov    0x6a8(%r12),%rax
  6e0dfe:	cmp    0x6a0(%r12),%rax
  6e0e06:	jne    6e3607 <text_column_public_control::main+0x3fc7>
  6e0e0c:	movss  0x740(%r12),%xmm0
  6e0e16:	ucomiss 0x744(%r12),%xmm0
  6e0e1f:	jne    6e3607 <text_column_public_control::main+0x3fc7>
  6e0e25:	jp     6e3607 <text_column_public_control::main+0x3fc7>
  6e0e2b:	mov    0x5a8(%r12),%r13
  6e0e33:	mov    0x5b0(%r12),%rax
  6e0e3b:	lea    -0x38(%r13),%rcx
  6e0e3f:	shl    $0x6,%rax
  6e0e43:	neg    %rax
  6e0e46:	xor    %r15d,%r15d
  6e0e49:	nopl   0x0(%rax)
  6e0e50:	cmp    %r15,%rax
  6e0e53:	je     6e34e8 <text_column_public_control::main+0x3ea8>
  6e0e59:	add    $0xffffffffffffffc0,%r15
  6e0e5d:	lea    0x40(%rcx),%rbp
  6e0e61:	cmp    %rbx,0x58(%rcx)
  6e0e65:	mov    %rbp,%rcx
  6e0e68:	jne    6e0e50 <text_column_public_control::main+0x1810>
  6e0e6a:	mov    0x640(%r12),%rax
  6e0e72:	test   %rax,%rax
  6e0e75:	je     6e0e93 <text_column_public_control::main+0x1853>
  6e0e77:	mov    0x100(%rax),%rsi
  6e0e7e:	test   %rsi,%rsi
  6e0e81:	je     6e0e93 <text_column_public_control::main+0x1853>
  6e0e83:	lea    0x9c0(%rsp),%rdi
  6e0e8b:	call   *0x3613a7(%rip)        # a42238 <_DYNAMIC+0x248>
  6e0e91:	jmp    6e0eaa <text_column_public_control::main+0x186a>
  6e0e93:	movq   $0x4,0x9c0(%rsp)
  6e0e9f:	xorps  %xmm0,%xmm0
  6e0ea2:	movups %xmm0,0x9c8(%rsp)
  6e0eaa:	lea    0x9c0(%rsp),%rdi
  6e0eb2:	mov    %rdi,0x20(%rsp)
  6e0eb7:	call   *0x3615c3(%rip)        # a42480 <_DYNAMIC+0x490>
  6e0ebd:	mov    %rdx,%rcx
  6e0ec0:	sub    %r15,%r13
  6e0ec3:	lea    -0x40(%r13),%rsi
  6e0ec7:	lea    0x260(%rsp),%rdi
  6e0ecf:	mov    %rax,%rdx
  6e0ed2:	call   *0x3615b0(%rip)        # a42488 <_DYNAMIC+0x498>
  6e0ed8:	cmpb   $0x0,0x260(%rsp)
  6e0ee0:	je     6e0f81 <text_column_public_control::main+0x1941>
  6e0ee6:	movss  -0x6a1032(%rip),%xmm0        # 3febc <GCC_except_table0+0x118>
  6e0eee:	movss  0x0(%rbp),%xmm1
  6e0ef3:	mulss  %xmm0,%xmm1
  6e0ef7:	mulss  0x4(%rbp),%xmm0
  6e0efc:	cvtss2sd %xmm1,%xmm1
  6e0f00:	cvtss2sd %xmm0,%xmm0
  6e0f04:	cvtps2pd 0x264(%rsp),%xmm2
  6e0f0c:	movlhps %xmm1,%xmm1
  6e0f0f:	mulpd  %xmm2,%xmm1
  6e0f13:	cvtps2pd 0x26c(%rsp),%xmm2
  6e0f1b:	movlhps %xmm0,%xmm0
  6e0f1e:	mulpd  %xmm2,%xmm0
  6e0f22:	cvtps2pd 0x274(%rsp),%xmm2
  6e0f2a:	addpd  %xmm1,%xmm0
  6e0f2e:	addpd  %xmm0,%xmm2
  6e0f32:	cvtpd2ps %xmm2,%xmm0
  6e0f36:	movapd %xmm0,%xmm1
  6e0f3a:	shufps $0x55,%xmm0,%xmm1
  6e0f3e:	movd   %xmm1,%eax
  6e0f42:	movd   %xmm0,%ecx
  6e0f46:	and    $0x7fffffff,%ecx
  6e0f4c:	cmp    $0x7f800000,%ecx
  6e0f52:	setge  %cl
  6e0f55:	and    $0x7fffffff,%eax
  6e0f5a:	cmp    $0x7f800000,%eax
  6e0f5f:	setge  %al
  6e0f62:	or     %cl,%al
  6e0f64:	jne    6e0f81 <text_column_public_control::main+0x1941>
  6e0f66:	add    $0xffffffffffffffd0,%r13
  6e0f6a:	mov    %r13,%rdi
  6e0f6d:	movaps %xmm0,0x10(%rsp)
  6e0f72:	call   *0x3615c0(%rip)        # a42538 <_DYNAMIC+0x548>
  6e0f78:	test   %al,%al
  6e0f7a:	movaps 0x10(%rsp),%xmm0
  6e0f7f:	jne    6e0fb7 <text_column_public_control::main+0x1977>
  6e0f81:	movss  0x10(%rbp),%xmm3
  6e0f86:	xorpd  %xmm2,%xmm2
  6e0f8a:	ucomiss %xmm2,%xmm3
  6e0f8d:	jne    6e0f95 <text_column_public_control::main+0x1955>
  6e0f8f:	jnp    6e3636 <text_column_public_control::main+0x3ff6>
  6e0f95:	movss  0x14(%rbp),%xmm1
  6e0f9a:	ucomiss %xmm2,%xmm1
  6e0f9d:	jne    6e0fa5 <text_column_public_control::main+0x1965>
  6e0f9f:	jnp    6e3636 <text_column_public_control::main+0x3ff6>
  6e0fa5:	unpcklps %xmm1,%xmm3
  6e0fa8:	mulps  -0x69fc7f(%rip),%xmm3        # 41330 <GCC_except_table0+0x158c>
  6e0faf:	movsd  0x8(%rbp),%xmm0
  6e0fb4:	addps  %xmm3,%xmm0
  6e0fb7:	movaps %xmm0,%xmm1
  6e0fba:	shufps $0x55,%xmm0,%xmm1
  6e0fbe:	mov    %r12,%rdi
  6e0fc1:	movaps %xmm0,0x10(%rsp)
  6e0fc6:	movaps %xmm1,0x40(%rsp)
  6e0fcb:	call   70cd60 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit>
  6e0fd0:	test   $0x1,%al
  6e0fd2:	je     6e3636 <text_column_public_control::main+0x3ff6>
  6e0fd8:	cmp    %rbx,%rdx
  6e0fdb:	jne    6e3636 <text_column_public_control::main+0x3ff6>
  6e0fe1:	cmp    0x5e0(%r12),%r14
  6e0fe9:	jne    6e3a09 <text_column_public_control::main+0x43c9>
  6e0fef:	lea    0x260(%rsp),%rdi
  6e0ff7:	mov    %r12,%rsi
  6e0ffa:	mov    %rbx,%rdx
  6e0ffd:	call   70ca80 <<gpui::runtime::Runtime<text_column_public_control::Input>>::resolve_identity>
  6e1002:	mov    0x260(%rsp),%rax
  6e100a:	mov    0x268(%rsp),%r13
  6e1012:	cmp    $0xfffffffffffffffe,%rax
  6e1016:	jne    6e3a0e <text_column_public_control::main+0x43ce>
  6e101c:	mov    0x2d0(%r12),%rsi
  6e1024:	cmp    %rsi,%r13
  6e1027:	movaps 0x10(%rsp),%xmm0
  6e102c:	jae    6e3a53 <text_column_public_control::main+0x4413>
  6e1032:	mov    0x2c8(%r12),%rax
  6e103a:	lea    0x0(,%r13,4),%rcx
  6e1042:	add    %r13,%rcx
  6e1045:	mov    0x20(%rax,%rcx,8),%eax
  6e1049:	and    $0xf,%eax
  6e104c:	lea    -0x3(%rax),%ecx
  6e104f:	cmp    $0x7,%ecx
  6e1052:	jb     6e105d <text_column_public_control::main+0x1a1d>
  6e1054:	cmp    $0x2,%eax
  6e1057:	jae    6e2f66 <text_column_public_control::main+0x3926>
  6e105d:	cmpb   $0x0,0x74e(%r12)
  6e1066:	je     6e1072 <text_column_public_control::main+0x1a32>
  6e1068:	mov    $0xe,%eax
  6e106d:	jmp    6e11c7 <text_column_public_control::main+0x1b87>
  6e1072:	cmp    0x5e0(%r12),%r14
  6e107a:	jne    6e118e <text_column_public_control::main+0x1b4e>
  6e1080:	mov    0x618(%r12),%rbp
  6e1088:	mov    0x620(%r12),%r15
  6e1090:	lea    0x260(%rsp),%rdi
  6e1098:	mov    %r12,%rsi
  6e109b:	mov    %rbx,%rdx
  6e109e:	call   70ca80 <<gpui::runtime::Runtime<text_column_public_control::Input>>::resolve_identity>
  6e10a3:	mov    0x260(%rsp),%rax
  6e10ab:	mov    0x268(%rsp),%r13
  6e10b3:	cmp    $0xfffffffffffffffe,%rax
  6e10b7:	jne    6e1193 <text_column_public_control::main+0x1b53>
  6e10bd:	mov    0x2d0(%r12),%rsi
  6e10c5:	cmp    %rsi,%r13
  6e10c8:	jae    6e3afd <text_column_public_control::main+0x44bd>
  6e10ce:	lea    0x0(,%r13,4),%rdi
  6e10d6:	add    %r13,%rdi
  6e10d9:	shl    $0x3,%rdi
  6e10dd:	add    0x2c8(%r12),%rdi
  6e10e5:	call   *0x361455(%rip)        # a42540 <_DYNAMIC+0x550>
  6e10eb:	test   %al,%al
  6e10ed:	je     6e2f8f <text_column_public_control::main+0x394f>
  6e10f3:	mov    %r14,0x618(%r12)
  6e10fb:	mov    %rbx,0x620(%r12)
  6e1103:	movq   $0x0,0x738(%r12)
  6e110f:	mov    0x690(%r12),%r13
  6e1117:	mov    0x6b0(%r12),%rax
  6e111f:	mov    %rax,0x10(%rsp)
  6e1124:	mov    0x6b8(%r12),%rax
  6e112c:	mov    %rax,0x40(%rsp)
  6e1131:	lea    0x260(%rsp),%rdi
  6e1139:	mov    %r12,%rsi
  6e113c:	call   6ec150 <<gpui::runtime::Runtime<text_column_public_control::Input>>::active_selection>
  6e1141:	cmpb   $0x2,0x274(%rsp)
  6e1149:	jne    6e2f99 <text_column_public_control::main+0x3959>
  6e114f:	movq   $0x0,0x260(%rsp)
  6e115b:	lea    0x9c0(%rsp),%rdi
  6e1163:	lea    0x70(%rsp),%rsi
  6e1168:	lea    0x260(%rsp),%r8
  6e1170:	mov    %r14,%rdx
  6e1173:	mov    %rbx,%rcx
  6e1176:	call   6e8240 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::activate_with_editing>
  6e117b:	cmpl   $0xfffffffe,0x9c0(%rsp)
  6e1183:	je     6e120a <text_column_public_control::main+0x1bca>
  6e1189:	jmp    6e307c <text_column_public_control::main+0x3a3c>
  6e118e:	mov    $0x11,%eax
  6e1193:	movups 0x270(%rsp),%xmm0
  6e119b:	movups 0x280(%rsp),%xmm1
  6e11a3:	movzbl 0x290(%rsp),%ecx
  6e11ab:	mov    0x291(%rsp),%edx
  6e11b2:	mov    %edx,0x110(%rsp)
  6e11b9:	mov    0x294(%rsp),%edx
  6e11c0:	mov    %edx,0x113(%rsp)
  6e11c7:	mov    0x110(%rsp),%edx
  6e11ce:	mov    0x113(%rsp),%esi
  6e11d5:	mov    %esi,0x9f4(%rsp)
  6e11dc:	mov    %edx,0x9f1(%rsp)
  6e11e3:	mov    %rax,0x9c0(%rsp)
  6e11eb:	mov    %r13,0x9c8(%rsp)
  6e11f3:	movups %xmm0,0x9d0(%rsp)
  6e11fb:	movups %xmm1,0x9e0(%rsp)
  6e1203:	mov    %cl,0x9f0(%rsp)
  6e120a:	cmpq   $0xfffffffffffffffe,0x9c0(%rsp)
  6e1213:	jne    6e34f4 <text_column_public_control::main+0x3eb4>
  6e1219:	mov    0x30(%rsp),%rsi
  6e121e:	lea    0x190(%rsp),%rdi
  6e1226:	call   6b5c90 <text_column_public_control::ack::<text_column_public_control::Input>>
  6e122b:	mov    0x30(%rsp),%rsi
  6e1230:	test   %rsi,%rsi
  6e1233:	je     6e32d0 <text_column_public_control::main+0x3c90>
  6e1239:	cmpq   $0x1,0x2b0(%rsi)
  6e1241:	jne    6e3329 <text_column_public_control::main+0x3ce9>
  6e1247:	movsd  -0x6a07bf(%rip),%xmm0        # 40a90 <GCC_except_table0+0xcec>
  6e124f:	movsd  %xmm0,0x260(%rsp)
  6e1258:	lea    0x260(%rsp),%rax
  6e1260:	movsd  0x260(%rsp),%xmm0
  6e1269:	movaps %xmm0,%xmm1
  6e126c:	shufps $0x55,%xmm0,%xmm1
  6e1270:	lea    0x30(%rsp),%rbp
  6e1275:	mov    %rbp,0x260(%rsp)
  6e127d:	lea    0x260(%rsp),%r12
  6e1285:	mov    0x260(%rsp),%rax
  6e128d:	mov    (%rax),%rdi
  6e1290:	movaps %xmm0,0x10(%rsp)
  6e1295:	call   6dcf30 <text_column_public_control::public_hit>
  6e129a:	mov    %rdx,%rcx
  6e129d:	mov    %rax,0x9c0(%rsp)
  6e12a5:	mov    %rdx,0x9c8(%rsp)
  6e12ad:	mov    %r14,0x260(%rsp)
  6e12b5:	mov    %rbx,0x268(%rsp)
  6e12bd:	lea    0x34140c(%rip),%rdx        # a226d0 <__frame_dummy_init_array_entry+0xbe0>
  6e12c4:	test   %rax,%rax
  6e12c7:	je     6e3391 <text_column_public_control::main+0x3d51>
  6e12cd:	cmp    %r14,%rax
  6e12d0:	jne    6e3391 <text_column_public_control::main+0x3d51>
  6e12d6:	cmp    %rbx,%rcx
  6e12d9:	jne    6e3391 <text_column_public_control::main+0x3d51>
  6e12df:	movsd  -0x6a1117(%rip),%xmm0        # 401d0 <GCC_except_table0+0x42c>
  6e12e7:	movsd  %xmm0,0x260(%rsp)
  6e12f0:	lea    0x260(%rsp),%rax
  6e12f8:	mov    %rax,0x20(%rsp)
  6e12fd:	movss  0x260(%rsp),%xmm0
  6e1306:	movss  0x264(%rsp),%xmm1
  6e130f:	mov    0x30(%rsp),%rdi
  6e1314:	call   6dcf30 <text_column_public_control::public_hit>
  6e1319:	mov    %rax,0x260(%rsp)
  6e1321:	mov    %rdx,0x268(%rsp)
  6e1329:	test   %rax,%rax
  6e132c:	jne    6e3383 <text_column_public_control::main+0x3d43>
  6e1332:	mov    %rbp,0x260(%rsp)
  6e133a:	lea    0x260(%rsp),%rax
  6e1342:	mov    0x260(%rsp),%rax
  6e134a:	mov    (%rax),%rsi
  6e134d:	lea    0x230(%rsp),%rdi
  6e1355:	call   6dd040 <text_column_public_control::public_query>
  6e135a:	movq   $0x3,0x9c8(%rsp)
  6e1366:	lea    0x9d0(%rsp),%rdx
  6e136e:	movl   $0x0,0x9d0(%rsp)
  6e1379:	movdqa 0x10(%rsp),%xmm0
  6e137f:	movq   %xmm0,0x9d4(%rsp)
  6e1388:	movl   $0x2,0x9e8(%rsp)
  6e1393:	movl   $0x5,0xa00(%rsp)
  6e139e:	mov    $0xffffffff,%eax
  6e13a3:	mov    %rax,0x40(%rsp)
  6e13a8:	pxor   %xmm0,%xmm0
  6e13ac:	movd   %xmm0,0x10(%rsp)
  6e13b2:	lea    0x340e97(%rip),%rax        # a22250 <__frame_dummy_init_array_entry+0x760>
  6e13b9:	mov    %rax,0xd8(%rsp)
  6e13c1:	xor    %eax,%eax
  6e13c3:	xor    %ebx,%ebx
  6e13c5:	data16 cs nopw 0x0(%rax,%rax,1)
  6e13d0:	lea    0x1(%rax),%rcx
  6e13d4:	mov    %rcx,0x9c0(%rsp)
  6e13dc:	lea    (%rax,%rax,2),%rcx
  6e13e0:	mov    (%rdx,%rcx,8),%eax
  6e13e3:	cmp    $0xffffffff,%eax
  6e13e6:	je     6e2be9 <text_column_public_control::main+0x35a9>
  6e13ec:	lea    (%rdx,%rcx,8),%rcx
  6e13f0:	mov    %rbp,0x260(%rsp)
  6e13f8:	lea    0x260(%rsp),%rdx
  6e1400:	mov    0x260(%rsp),%r15
  6e1408:	mov    %eax,0x160(%rsp)
  6e140f:	mov    0x14(%rcx),%eax
  6e1412:	lea    0x164(%rsp),%rdx
  6e141a:	mov    %eax,0x10(%rdx)
  6e141d:	movdqu 0x4(%rcx),%xmm0
  6e1422:	movdqu %xmm0,(%rdx)
  6e1426:	lea    0x160(%rsp),%rax
  6e142e:	mov    0x160(%rsp),%r13d
  6e1436:	lea    -0x69f941(%rip),%rcx        # 41afc <GCC_except_table0+0x1d58>
  6e143d:	movslq (%rcx,%r13,4),%rax
  6e1441:	add    %rcx,%rax
  6e1444:	jmp    *%rax
  6e1446:	xor    %r12d,%r12d
  6e1449:	mov    (%r15),%r14
  6e144c:	test   %r14,%r14
  6e144f:	je     6e16d9 <text_column_public_control::main+0x2099>
  6e1455:	add    $0x8,%r15
  6e1459:	mov    %r14,0xf8(%rsp)
  6e1461:	mov    %r15,0x100(%rsp)
  6e1469:	cmpb   $0x1,0x74e(%r14)
  6e1471:	jne    6e1490 <text_column_public_control::main+0x1e50>
  6e1473:	movq   $0xe,0x70(%rsp)
  6e147c:	jmp    6e1c20 <text_column_public_control::main+0x25e0>
  6e1481:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6e1490:	movq   $0x0,0x738(%r14)
  6e149b:	cmp    $0x3,%r13d
  6e149f:	je     6e17f5 <text_column_public_control::main+0x21b5>
  6e14a5:	cmp    $0x2,%r13d
  6e14a9:	je     6e1716 <text_column_public_control::main+0x20d6>
  6e14af:	test   %r13d,%r13d
  6e14b2:	jne    6e1a95 <text_column_public_control::main+0x2455>
  6e14b8:	mov    0x640(%r14),%rax
  6e14bf:	test   %rax,%rax
  6e14c2:	je     6e14da <text_column_public_control::main+0x1e9a>
  6e14c4:	mov    0xd8(%rax),%rax
  6e14cb:	test   %rax,%rax
  6e14ce:	je     6e14da <text_column_public_control::main+0x1e9a>
  6e14d0:	cmpb   $0x0,0x12(%rax)
  6e14d4:	jne    6e1a95 <text_column_public_control::main+0x2455>
  6e14da:	test   %r12,%r12
  6e14dd:	jne    6e1a26 <text_column_public_control::main+0x23e6>
  6e14e3:	xor    %r12d,%r12d
  6e14e6:	jmp    6e1a95 <text_column_public_control::main+0x2455>
  6e14eb:	movd   0x164(%rsp),%xmm1
  6e14f4:	movd   0x168(%rsp),%xmm0
  6e14fd:	movd   %xmm1,%edx
  6e1501:	movd   %xmm0,%eax
  6e1505:	mov    %edx,%ecx
  6e1507:	and    $0x7fffffff,%ecx
  6e150d:	cmp    $0x7f800000,%ecx
  6e1513:	setge  %cl
  6e1516:	and    $0x7fffffff,%eax
  6e151b:	cmp    $0x7f800000,%eax
  6e1520:	setge  %al
  6e1523:	or     %cl,%al
  6e1525:	je     6e16f0 <text_column_public_control::main+0x20b0>
  6e152b:	mov    $0xffffffff,%eax
  6e1530:	mov    %rax,0x40(%rsp)
  6e1535:	xor    %r12d,%r12d
  6e1538:	xor    %ebx,%ebx
  6e153a:	mov    (%r15),%r14
  6e153d:	test   %r14,%r14
  6e1540:	jne    6e1455 <text_column_public_control::main+0x1e15>
  6e1546:	jmp    6e16d9 <text_column_public_control::main+0x2099>
  6e154b:	cmpl   $0xffffffff,0x40(%rsp)
  6e1550:	je     6e16c0 <text_column_public_control::main+0x2080>
  6e1556:	movups 0x168(%rsp),%xmm0
  6e155e:	movaps %xmm0,%xmm1
  6e1561:	unpckhpd %xmm0,%xmm1
  6e1565:	lea    0x260(%rsp),%rdi
  6e156d:	movaps %xmm0,0x50(%rsp)
  6e1572:	call   *0x360fd0(%rip)        # a42548 <_DYNAMIC+0x558>
  6e1578:	cmpl   $0xfffffffe,0x260(%rsp)
  6e1580:	jne    6e1832 <text_column_public_control::main+0x21f2>
  6e1586:	mov    (%r15),%r13
  6e1589:	test   %r13,%r13
  6e158c:	je     6e3ac6 <text_column_public_control::main+0x4486>
  6e1592:	cmpb   $0x1,0x74e(%r13)
  6e159a:	mov    0x40(%rsp),%rdx
  6e159f:	je     6e3add <text_column_public_control::main+0x449d>
  6e15a5:	cmpb   $0x1,0x74a(%r13)
  6e15ad:	jne    6e3647 <text_column_public_control::main+0x4007>
  6e15b3:	cmpb   $0x0,0x74b(%r13)
  6e15bb:	jne    6e3647 <text_column_public_control::main+0x4007>
  6e15c1:	cmpb   $0x0,0x74c(%r13)
  6e15c9:	je     6e3647 <text_column_public_control::main+0x4007>
  6e15cf:	cmpq   $0xffffffffffffffff,0x5b8(%r13)
  6e15d7:	jne    6e3647 <text_column_public_control::main+0x4007>
  6e15dd:	mov    0x690(%r13),%rax
  6e15e4:	cmp    0x698(%r13),%rax
  6e15eb:	jne    6e3647 <text_column_public_control::main+0x4007>
  6e15f1:	mov    0x6a0(%r13),%rax
  6e15f8:	cmp    %rax,0x6a8(%r13)
  6e15ff:	jne    6e3647 <text_column_public_control::main+0x4007>
  6e1605:	movss  0x740(%r13),%xmm0
  6e160e:	ucomiss 0x744(%r13),%xmm0
  6e1616:	jne    6e3647 <text_column_public_control::main+0x4007>
  6e161c:	jp     6e3647 <text_column_public_control::main+0x4007>
  6e1622:	mov    %eax,%ecx
  6e1624:	cvtsi2ss %rcx,%xmm2
  6e1629:	lea    -0x1(%rdx),%ecx
  6e162c:	shr    $0x20,%rax
  6e1630:	mov    %eax,%eax
  6e1632:	xorps  %xmm1,%xmm1
  6e1635:	cvtsi2ss %rax,%xmm1
  6e163a:	movd   %ecx,%xmm0
  6e163e:	movq   $0x0,0x260(%rsp)
  6e164a:	movss  %xmm2,0x268(%rsp)
  6e1653:	movss  %xmm1,0x26c(%rsp)
  6e165c:	lea    0x260(%rsp),%rdi
  6e1664:	movd   %xmm0,0x20(%rsp)
  6e166a:	movss  0x10(%rsp),%xmm1
  6e1670:	call   *0x360ec2(%rip)        # a42538 <_DYNAMIC+0x548>
  6e1676:	test   %al,%al
  6e1678:	je     6e3475 <text_column_public_control::main+0x3e35>
  6e167e:	mov    0x640(%r13),%rax
  6e1685:	test   %rax,%rax
  6e1688:	je     6e1877 <text_column_public_control::main+0x2237>
  6e168e:	mov    0x100(%rax),%rsi
  6e1695:	test   %rsi,%rsi
  6e1698:	je     6e1877 <text_column_public_control::main+0x2237>
  6e169e:	lea    0x178(%rsp),%rdi
  6e16a6:	call   *0x360b8c(%rip)        # a42238 <_DYNAMIC+0x248>
  6e16ac:	jmp    6e1893 <text_column_public_control::main+0x2253>
  6e16b1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6e16c0:	mov    $0xffffffff,%eax
  6e16c5:	mov    %rax,0x40(%rsp)
  6e16ca:	xor    %r12d,%r12d
  6e16cd:	mov    (%r15),%r14
  6e16d0:	test   %r14,%r14
  6e16d3:	jne    6e1455 <text_column_public_control::main+0x1e15>
  6e16d9:	movq   $0xd,0x70(%rsp)
  6e16e2:	movq   $0x0,0x78(%rsp)
  6e16eb:	jmp    6e1c20 <text_column_public_control::main+0x25e0>
  6e16f0:	inc    %edx
  6e16f2:	mov    %rdx,0x40(%rsp)
  6e16f7:	je     6e31fa <text_column_public_control::main+0x3bba>
  6e16fd:	movd   %xmm0,0x10(%rsp)
  6e1703:	mov    %rbx,%r12
  6e1706:	xor    %ebx,%ebx
  6e1708:	mov    (%r15),%r14
  6e170b:	test   %r14,%r14
  6e170e:	jne    6e1455 <text_column_public_control::main+0x1e15>
  6e1714:	jmp    6e16d9 <text_column_public_control::main+0x2099>
  6e1716:	test   %rbx,%rbx
  6e1719:	sete   %r15b
  6e171d:	cmpb   $0x1,0x74a(%r14)
  6e1725:	jne    6e1c17 <text_column_public_control::main+0x25d7>
  6e172b:	cmpb   $0x0,0x74b(%r14)
  6e1733:	jne    6e1c17 <text_column_public_control::main+0x25d7>
  6e1739:	cmpb   $0x0,0x74c(%r14)
  6e1741:	je     6e1c17 <text_column_public_control::main+0x25d7>
  6e1747:	cmpq   $0xffffffffffffffff,0x5b8(%r14)
  6e174f:	jne    6e1c17 <text_column_public_control::main+0x25d7>
  6e1755:	mov    0x690(%r14),%rax
  6e175c:	cmp    0x698(%r14),%rax
  6e1763:	jne    6e1c17 <text_column_public_control::main+0x25d7>
  6e1769:	mov    0x6a8(%r14),%rax
  6e1770:	cmp    0x6a0(%r14),%rax
  6e1777:	jne    6e1c17 <text_column_public_control::main+0x25d7>
  6e177d:	movss  0x740(%r14),%xmm0
  6e1786:	ucomiss 0x744(%r14),%xmm0
  6e178e:	jne    6e1c17 <text_column_public_control::main+0x25d7>
  6e1794:	jp     6e1c17 <text_column_public_control::main+0x25d7>
  6e179a:	mov    0x40(%rsp),%rax
  6e179f:	cmp    $0xffffffff,%eax
  6e17a2:	je     6e1e30 <text_column_public_control::main+0x27f0>
  6e17a8:	dec    %eax
  6e17aa:	movd   %eax,%xmm0
  6e17ae:	mov    0x640(%r14),%rax
  6e17b5:	test   %rax,%rax
  6e17b8:	je     6e1dff <text_column_public_control::main+0x27bf>
  6e17be:	mov    0xd8(%rax),%rax
  6e17c5:	test   %rax,%rax
  6e17c8:	je     6e1dff <text_column_public_control::main+0x27bf>
  6e17ce:	cmpb   $0x0,0x12(%rax)
  6e17d2:	je     6e1dff <text_column_public_control::main+0x27bf>
  6e17d8:	mov    %r14,%rdi
  6e17db:	movd   0x10(%rsp),%xmm1
  6e17e1:	call   6f1770 <<gpui::runtime::Runtime<text_column_public_control::Input>>::inspector_pick>
  6e17e6:	mov    %rax,0x20(%rsp)
  6e17eb:	mov    %rdx,0x50(%rsp)
  6e17f0:	jmp    6e1f5d <text_column_public_control::main+0x291d>
  6e17f5:	test   %rbx,%rbx
  6e17f8:	je     6e1a95 <text_column_public_control::main+0x2455>
  6e17fe:	mov    0x40(%rsp),%rax
  6e1803:	cmp    $0xffffffff,%eax
  6e1806:	je     6e1b06 <text_column_public_control::main+0x24c6>
  6e180c:	dec    %eax
  6e180e:	mov    %eax,0xc64(%rsp)
  6e1815:	movss  0x10(%rsp),%xmm0
  6e181b:	movss  %xmm0,0xc68(%rsp)
  6e1824:	movd   %eax,%xmm0
  6e1828:	mov    $0x1,%eax
  6e182d:	jmp    6e1b08 <text_column_public_control::main+0x24c8>
  6e1832:	mov    0x290(%rsp),%rax
  6e183a:	mov    %rax,0xa0(%rsp)
  6e1842:	movups 0x260(%rsp),%xmm0
  6e184a:	movups 0x270(%rsp),%xmm1
  6e1852:	movups 0x280(%rsp),%xmm2
  6e185a:	movaps %xmm2,0x90(%rsp)
  6e1862:	movaps %xmm1,0x80(%rsp)
  6e186a:	movaps %xmm0,0x70(%rsp)
  6e186f:	xor    %r12d,%r12d
  6e1872:	jmp    6e1c20 <text_column_public_control::main+0x25e0>
  6e1877:	movq   $0x4,0x178(%rsp)
  6e1883:	lea    0x180(%rsp),%rax
  6e188b:	pxor   %xmm0,%xmm0
  6e188f:	movdqu %xmm0,(%rax)
  6e1893:	mov    0x5b0(%r13),%rbp
  6e189a:	test   %rbp,%rbp
  6e189d:	je     6e3475 <text_column_public_control::main+0x3e35>
  6e18a3:	mov    0x5a8(%r13),%r14
  6e18aa:	mov    %rbp,%rbx
  6e18ad:	shl    $0x6,%rbx
  6e18b1:	lea    -0x1(%rbp),%r12
  6e18b5:	jmp    6e18cd <text_column_public_control::main+0x228d>
  6e18b7:	nopw   0x0(%rax,%rax,1)
  6e18c0:	dec    %r12
  6e18c3:	add    $0xffffffffffffffc0,%rbx
  6e18c7:	je     6e3475 <text_column_public_control::main+0x3e35>
  6e18cd:	cmpb   $0x0,-0x2(%r14,%rbx,1)
  6e18d3:	jne    6e1900 <text_column_public_control::main+0x22c0>
  6e18d5:	movzbl -0x3(%r14,%rbx,1),%eax
  6e18db:	sub    $0x2,%al
  6e18dd:	movzbl %al,%eax
  6e18e0:	mov    $0x8,%ecx
  6e18e5:	cmovb  %ecx,%eax
  6e18e8:	cmp    $0x7,%al
  6e18ea:	je     6e1900 <text_column_public_control::main+0x22c0>
  6e18ec:	movzbl %al,%eax
  6e18ef:	cmp    $0x4,%eax
  6e18f2:	jne    6e18c0 <text_column_public_control::main+0x2280>
  6e18f4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6e1900:	mov    0x188(%rsp),%rax
  6e1908:	mov    %rax,0x270(%rsp)
  6e1910:	movups 0x178(%rsp),%xmm0
  6e1918:	movaps %xmm0,0x260(%rsp)
  6e1920:	mov    0x640(%r13),%rax
  6e1927:	test   %rax,%rax
  6e192a:	je     6e1940 <text_column_public_control::main+0x2300>
  6e192c:	cmpq   $0x0,(%rax)
  6e1930:	setne  %al
  6e1933:	jmp    6e1942 <text_column_public_control::main+0x2302>
  6e1935:	data16 cs nopw 0x0(%rax,%rax,1)
  6e1940:	xor    %eax,%eax
  6e1942:	movzbl %al,%ecx
  6e1945:	mov    %r14,%rdi
  6e1948:	mov    %rbp,%rsi
  6e194b:	lea    0x260(%rsp),%rdx
  6e1953:	mov    %r12,%r8
  6e1956:	movd   0x20(%rsp),%xmm0
  6e195c:	movss  0x10(%rsp),%xmm1
  6e1962:	call   *0x360be8(%rip)        # a42550 <_DYNAMIC+0x560>
  6e1968:	test   %al,%al
  6e196a:	je     6e18c0 <text_column_public_control::main+0x2280>
  6e1970:	mov    0x5a8(%r13),%rax
  6e1977:	mov    0x5b0(%r13),%rsi
  6e197e:	mov    $0x1,%cl
  6e1980:	mov    %r12,%rdi
  6e1983:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6e1990:	test   $0x1,%cl
  6e1993:	je     6e3475 <text_column_public_control::main+0x3e35>
  6e1999:	cmp    %rsi,%rdi
  6e199c:	jae    6e3b2a <text_column_public_control::main+0x44ea>
  6e19a2:	shl    $0x6,%rdi
  6e19a6:	movzbl 0x3d(%rax,%rdi,1),%edx
  6e19ab:	mov    0x38(%rax,%rdi,1),%edi
  6e19af:	and    $0x1ffff,%edi
  6e19b5:	cmp    $0x1ffff,%rdi
  6e19bc:	setne  %cl
  6e19bf:	sub    $0x2,%dl
  6e19c2:	movzbl %dl,%edx
  6e19c5:	mov    $0x8,%r8d
  6e19cb:	cmovb  %r8d,%edx
  6e19cf:	cmp    $0x4,%dl
  6e19d2:	je     6e19dc <text_column_public_control::main+0x239c>
  6e19d4:	movzbl %dl,%edx
  6e19d7:	cmp    $0x7,%edx
  6e19da:	jne    6e1990 <text_column_public_control::main+0x2350>
  6e19dc:	mov    (%r15),%rbx
  6e19df:	test   %rbx,%rbx
  6e19e2:	je     6e1a07 <text_column_public_control::main+0x23c7>
  6e19e4:	cmpb   $0x0,0x74e(%rbx)
  6e19eb:	lea    0x30(%rsp),%rbp
  6e19f0:	je     6e1cbb <text_column_public_control::main+0x267b>
  6e19f6:	movq   $0xe,0x70(%rsp)
  6e19ff:	xor    %r12d,%r12d
  6e1a02:	jmp    6e1c20 <text_column_public_control::main+0x25e0>
  6e1a07:	movq   $0xd,0x70(%rsp)
  6e1a10:	movq   $0x0,0x78(%rsp)
  6e1a19:	lea    0x30(%rsp),%rbp
  6e1a1e:	xor    %r12d,%r12d
  6e1a21:	jmp    6e1c20 <text_column_public_control::main+0x25e0>
  6e1a26:	cmp    0x5e0(%r14),%r12
  6e1a2d:	jne    6e14e3 <text_column_public_control::main+0x1ea3>
  6e1a33:	lea    0xc60(%rsp),%rdi
  6e1a3b:	mov    %r14,%rsi
  6e1a3e:	mov    0x68(%rsp),%rdx
  6e1a43:	call   70ca80 <<gpui::runtime::Runtime<text_column_public_control::Input>>::resolve_identity>
  6e1a48:	mov    0xc60(%rsp),%rax
  6e1a50:	cmp    $0xfffffffffffffffe,%rax
  6e1a54:	jne    6e1dab <text_column_public_control::main+0x276b>
  6e1a5a:	mov    0xc68(%rsp),%rdi
  6e1a62:	mov    0x2d0(%r14),%rsi
  6e1a69:	cmp    %rsi,%rdi
  6e1a6c:	jae    6e3b09 <text_column_public_control::main+0x44c9>
  6e1a72:	mov    0x2c8(%r14),%rax
  6e1a79:	lea    (%rdi,%rdi,4),%rcx
  6e1a7d:	mov    0x20(%rax,%rcx,8),%eax
  6e1a81:	and    $0xf,%eax
  6e1a84:	lea    -0x3(%rax),%ecx
  6e1a87:	cmp    $0x7,%ecx
  6e1a8a:	jb     6e1a95 <text_column_public_control::main+0x2455>
  6e1a8c:	cmp    $0x2,%eax
  6e1a8f:	jae    6e2324 <text_column_public_control::main+0x2ce4>
  6e1a95:	movups 0x690(%r14),%xmm0
  6e1a9d:	movzbl 0x74c(%r14),%eax
  6e1aa5:	cmpq   $0x0,0x6b0(%r14)
  6e1aad:	je     6e1abd <text_column_public_control::main+0x247d>
  6e1aaf:	test   %al,%al
  6e1ab1:	je     6e1ac1 <text_column_public_control::main+0x2481>
  6e1ab3:	cmpq   $0xffffffffffffffff,0x5b8(%r14)
  6e1abb:	jne    6e1ac1 <text_column_public_control::main+0x2481>
  6e1abd:	xor    %edx,%edx
  6e1abf:	jmp    6e1acd <text_column_public_control::main+0x248d>
  6e1ac1:	mov    0x6c0(%r14),%rcx
  6e1ac8:	mov    $0x1,%edx
  6e1acd:	mov    0x738(%r14),%rsi
  6e1ad4:	mov    %rdx,0x78(%rsp)
  6e1ad9:	mov    %rcx,0x80(%rsp)
  6e1ae1:	movups %xmm0,0x88(%rsp)
  6e1ae9:	mov    %rsi,0x98(%rsp)
  6e1af1:	mov    %al,0xa0(%rsp)
  6e1af8:	movq   $0xfffffffffffffffe,0x70(%rsp)
  6e1b01:	jmp    6e1c20 <text_column_public_control::main+0x25e0>
  6e1b06:	xor    %eax,%eax
  6e1b08:	mov    %eax,0xc60(%rsp)
  6e1b0f:	movzbl 0x74b(%r14),%ecx
  6e1b17:	xor    $0x1,%cl
  6e1b1a:	and    0x74a(%r14),%cl
  6e1b21:	and    0x74c(%r14),%cl
  6e1b28:	mov    0x5b8(%r14),%rdx
  6e1b2f:	cmp    $0xffffffffffffffff,%rdx
  6e1b33:	sete   %sil
  6e1b37:	and    %cl,%sil
  6e1b3a:	cmp    $0x1,%sil
  6e1b3e:	jne    6e1bd8 <text_column_public_control::main+0x2598>
  6e1b44:	mov    0x690(%r14),%rcx
  6e1b4b:	cmp    0x698(%r14),%rcx
  6e1b52:	jne    6e1c17 <text_column_public_control::main+0x25d7>
  6e1b58:	mov    0x6a8(%r14),%rcx
  6e1b5f:	cmp    0x6a0(%r14),%rcx
  6e1b66:	jne    6e1c17 <text_column_public_control::main+0x25d7>
  6e1b6c:	movss  0x740(%r14),%xmm1
  6e1b75:	ucomiss 0x744(%r14),%xmm1
  6e1b7d:	jne    6e1c17 <text_column_public_control::main+0x25d7>
  6e1b83:	jp     6e1c17 <text_column_public_control::main+0x25d7>
  6e1b89:	test   %eax,%eax
  6e1b8b:	je     6e1f51 <text_column_public_control::main+0x2911>
  6e1b91:	mov    0x640(%r14),%rax
  6e1b98:	test   %rax,%rax
  6e1b9b:	je     6e1f23 <text_column_public_control::main+0x28e3>
  6e1ba1:	mov    0xd8(%rax),%rax
  6e1ba8:	test   %rax,%rax
  6e1bab:	je     6e1f23 <text_column_public_control::main+0x28e3>
  6e1bb1:	cmpb   $0x0,0x12(%rax)
  6e1bb5:	je     6e1f23 <text_column_public_control::main+0x28e3>
  6e1bbb:	mov    %r14,%rdi
  6e1bbe:	movss  0x10(%rsp),%xmm1
  6e1bc4:	call   6f1770 <<gpui::runtime::Runtime<text_column_public_control::Input>>::inspector_pick>
  6e1bc9:	mov    %rax,0x20(%rsp)
  6e1bce:	mov    %rdx,0x50(%rsp)
  6e1bd3:	jmp    6e1f5a <text_column_public_control::main+0x291a>
  6e1bd8:	movq   $0x12,0x260(%rsp)
  6e1be4:	test   %cl,%cl
  6e1be6:	je     6e1c17 <text_column_public_control::main+0x25d7>
  6e1be8:	cmp    $0xffffffffffffffff,%rdx
  6e1bec:	je     6e1c17 <text_column_public_control::main+0x25d7>
  6e1bee:	mov    0x6a8(%r14),%rax
  6e1bf5:	cmp    0x6a0(%r14),%rax
  6e1bfc:	jne    6e1c17 <text_column_public_control::main+0x25d7>
  6e1bfe:	movss  0x740(%r14),%xmm0
  6e1c07:	ucomiss 0x744(%r14),%xmm0
  6e1c0f:	jne    6e1c17 <text_column_public_control::main+0x25d7>
  6e1c11:	jnp    6e1e3e <text_column_public_control::main+0x27fe>
  6e1c17:	movq   $0x12,0x70(%rsp)
  6e1c20:	cmpq   $0xfffffffffffffffe,0x70(%rsp)
  6e1c26:	jne    6e347e <text_column_public_control::main+0x3e3e>
  6e1c2c:	lea    0x78(%rsp),%rax
  6e1c31:	movdqu (%rax),%xmm0
  6e1c35:	movdqu 0x10(%rax),%xmm1
  6e1c3a:	movupd 0x20(%rax),%xmm2
  6e1c3f:	movapd %xmm2,0x200(%rsp)
  6e1c48:	movdqa %xmm1,0x1f0(%rsp)
  6e1c51:	movdqa %xmm0,0x1e0(%rsp)
  6e1c5a:	mov    0x1f0(%rsp),%rax
  6e1c62:	cmp    0x1a0(%rsp),%rax
  6e1c6a:	jne    6e30bd <text_column_public_control::main+0x3a7d>
  6e1c70:	mov    0x1f8(%rsp),%rax
  6e1c78:	cmp    0x1a8(%rsp),%rax
  6e1c80:	jne    6e30d6 <text_column_public_control::main+0x3a96>
  6e1c86:	cmpq   $0x0,0x1e0(%rsp)
  6e1c8f:	jne    6e30fc <text_column_public_control::main+0x3abc>
  6e1c95:	mov    0x9c0(%rsp),%rax
  6e1c9d:	mov    %r12,%rbx
  6e1ca0:	cmp    %rax,0x9c8(%rsp)
  6e1ca8:	lea    0x9d0(%rsp),%rdx
  6e1cb0:	jne    6e13d0 <text_column_public_control::main+0x1d90>
  6e1cb6:	jmp    6e2be9 <text_column_public_control::main+0x35a9>
  6e1cbb:	cmpb   $0x1,0x74a(%rbx)
  6e1cc2:	jne    6e1d9a <text_column_public_control::main+0x275a>
  6e1cc8:	cmpb   $0x0,0x74b(%rbx)
  6e1ccf:	jne    6e1d9a <text_column_public_control::main+0x275a>
  6e1cd5:	cmpb   $0x0,0x74c(%rbx)
  6e1cdc:	je     6e1d9a <text_column_public_control::main+0x275a>
  6e1ce2:	cmpq   $0xffffffffffffffff,0x5b8(%rbx)
  6e1cea:	jne    6e1d9a <text_column_public_control::main+0x275a>
  6e1cf0:	mov    0x690(%rbx),%rax
  6e1cf7:	cmp    0x698(%rbx),%rax
  6e1cfe:	jne    6e1d9a <text_column_public_control::main+0x275a>
  6e1d04:	mov    0x6a8(%rbx),%rcx
  6e1d0b:	cmp    0x6a0(%rbx),%rcx
  6e1d12:	jne    6e1d9a <text_column_public_control::main+0x275a>
  6e1d18:	movss  0x740(%rbx),%xmm0
  6e1d20:	movss  0x744(%rbx),%xmm1
  6e1d28:	movss  %xmm1,0x20(%rsp)
  6e1d2e:	ucomiss %xmm1,%xmm0
  6e1d31:	jne    6e1d9a <text_column_public_control::main+0x275a>
  6e1d33:	jp     6e1d9a <text_column_public_control::main+0x275a>
  6e1d35:	movq   $0x0,0xe0(%rsp)
  6e1d41:	movq   $0x8,0xe8(%rsp)
  6e1d4d:	movq   $0x0,0xf0(%rsp)
  6e1d59:	mov    0x640(%rbx),%r14
  6e1d60:	test   %r14,%r14
  6e1d63:	je     6e22e6 <text_column_public_control::main+0x2ca6>
  6e1d69:	mov    0x5a8(%rbx),%r13
  6e1d70:	mov    0x5b0(%rbx),%rbp
  6e1d77:	mov    0x100(%r14),%rsi
  6e1d7e:	test   %rsi,%rsi
  6e1d81:	je     6e240c <text_column_public_control::main+0x2dcc>
  6e1d87:	lea    0x260(%rsp),%rdi
  6e1d8f:	call   *0x3604a3(%rip)        # a42238 <_DYNAMIC+0x248>
  6e1d95:	jmp    6e2426 <text_column_public_control::main+0x2de6>
  6e1d9a:	movq   $0x12,0x70(%rsp)
  6e1da3:	xor    %r12d,%r12d
  6e1da6:	jmp    6e1c20 <text_column_public_control::main+0x25e0>
  6e1dab:	cmp    $0xd,%rax
  6e1daf:	jl     6e1dd3 <text_column_public_control::main+0x2793>
  6e1db1:	cmp    $0x21,%rax
  6e1db5:	je     6e1dd3 <text_column_public_control::main+0x2793>
  6e1db7:	cmp    $0x26,%rax
  6e1dbb:	jne    6e14e3 <text_column_public_control::main+0x1ea3>
  6e1dc1:	mov    0xc68(%rsp),%rsi
  6e1dc9:	lea    0xc70(%rsp),%rax
  6e1dd1:	jmp    6e1de3 <text_column_public_control::main+0x27a3>
  6e1dd3:	mov    0xc78(%rsp),%rsi
  6e1ddb:	lea    0xc80(%rsp),%rax
  6e1de3:	test   %rsi,%rsi
  6e1de6:	je     6e14e3 <text_column_public_control::main+0x1ea3>
  6e1dec:	mov    (%rax),%rdi
  6e1def:	mov    $0x1,%edx
  6e1df4:	call   *0x36045e(%rip)        # a42258 <_DYNAMIC+0x268>
  6e1dfa:	jmp    6e14e3 <text_column_public_control::main+0x1ea3>
  6e1dff:	mov    %r14,%rdi
  6e1e02:	movd   0x10(%rsp),%xmm1
  6e1e08:	call   70cd60 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit>
  6e1e0d:	test   $0x1,%al
  6e1e0f:	je     6e1e30 <text_column_public_control::main+0x27f0>
  6e1e11:	lea    0x5e0(%r14),%rdi
  6e1e18:	mov    %rdx,%rsi
  6e1e1b:	call   *0x36066f(%rip)        # a42490 <_DYNAMIC+0x4a0>
  6e1e21:	mov    %rax,0x20(%rsp)
  6e1e26:	mov    %rdx,0x50(%rsp)
  6e1e2b:	jmp    6e1f5d <text_column_public_control::main+0x291d>
  6e1e30:	movq   $0x0,0x20(%rsp)
  6e1e39:	jmp    6e1f5d <text_column_public_control::main+0x291d>
  6e1e3e:	mov    0x698(%r14),%rax
  6e1e45:	cmp    $0xffffffffffffffff,%rax
  6e1e49:	je     6e1c17 <text_column_public_control::main+0x25d7>
  6e1e4f:	inc    %rax
  6e1e52:	mov    0x690(%r14),%rcx
  6e1e59:	cmp    %rcx,%rax
  6e1e5c:	jne    6e1c17 <text_column_public_control::main+0x25d7>
  6e1e62:	cmp    %rcx,0x6c0(%r14)
  6e1e69:	jne    6e1c17 <text_column_public_control::main+0x25d7>
  6e1e6f:	cmpq   $0x0,0x60(%rsp)
  6e1e75:	je     6e1c17 <text_column_public_control::main+0x25d7>
  6e1e7b:	cmpq   $0x0,0x6b0(%r14)
  6e1e83:	je     6e1c17 <text_column_public_control::main+0x25d7>
  6e1e89:	mov    0x60(%rsp),%rax
  6e1e8e:	cmp    %rax,0x6b8(%r14)
  6e1e95:	jne    6e1c17 <text_column_public_control::main+0x25d7>
  6e1e9b:	cmp    0x5e0(%r14),%rbx
  6e1ea2:	jne    6e1c17 <text_column_public_control::main+0x25d7>
  6e1ea8:	mov    %r14,%rdi
  6e1eab:	lea    0xc60(%rsp),%rsi
  6e1eb3:	call   6f0490 <<gpui::runtime::Runtime<text_column_public_control::Input>>::pointer_hit>
  6e1eb8:	mov    %rdx,0x50(%rsp)
  6e1ebd:	mov    %rax,%r15
  6e1ec0:	mov    0x640(%r14),%rax
  6e1ec7:	test   %rax,%rax
  6e1eca:	je     6e1f0f <text_column_public_control::main+0x28cf>
  6e1ecc:	cmpq   $0x0,0xd8(%rax)
  6e1ed4:	je     6e1f0f <text_column_public_control::main+0x28cf>
  6e1ed6:	cmp    %rbx,%r15
  6e1ed9:	jne    6e1c17 <text_column_public_control::main+0x25d7>
  6e1edf:	mov    0x50(%rsp),%rax
  6e1ee4:	cmp    0x68(%rsp),%rax
  6e1ee9:	jne    6e1c17 <text_column_public_control::main+0x25d7>
  6e1eef:	mov    %r14,%rdi
  6e1ef2:	mov    %rbx,%rsi
  6e1ef5:	mov    0x68(%rsp),%rdx
  6e1efa:	lea    0xc60(%rsp),%rcx
  6e1f02:	call   6f05c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::inspector_focus_hit>
  6e1f07:	test   %al,%al
  6e1f09:	je     6e1c17 <text_column_public_control::main+0x25d7>
  6e1f0f:	mov    %r15,0x20(%rsp)
  6e1f14:	lea    0x260(%rsp),%rdi
  6e1f1c:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e1f21:	jmp    6e1f5a <text_column_public_control::main+0x291a>
  6e1f23:	mov    %r14,%rdi
  6e1f26:	movss  0x10(%rsp),%xmm1
  6e1f2c:	call   70cd60 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit>
  6e1f31:	test   $0x1,%al
  6e1f33:	je     6e1f51 <text_column_public_control::main+0x2911>
  6e1f35:	lea    0x5e0(%r14),%rdi
  6e1f3c:	mov    %rdx,%rsi
  6e1f3f:	call   *0x36054b(%rip)        # a42490 <_DYNAMIC+0x4a0>
  6e1f45:	mov    %rax,0x20(%rsp)
  6e1f4a:	mov    %rdx,0x50(%rsp)
  6e1f4f:	jmp    6e1f5a <text_column_public_control::main+0x291a>
  6e1f51:	movq   $0x0,0x20(%rsp)
  6e1f5a:	xor    %r15d,%r15d
  6e1f5d:	mov    0x640(%r14),%rax
  6e1f64:	test   %rax,%rax
  6e1f67:	je     6e1f7b <text_column_public_control::main+0x293b>
  6e1f69:	mov    0xd8(%rax),%rax
  6e1f70:	test   %rax,%rax
  6e1f73:	je     6e1f7b <text_column_public_control::main+0x293b>
  6e1f75:	movzbl 0x12(%rax),%eax
  6e1f79:	jmp    6e1f7d <text_column_public_control::main+0x293d>
  6e1f7b:	xor    %eax,%eax
  6e1f7d:	cmp    $0x2,%r13d
  6e1f81:	jne    6e208c <text_column_public_control::main+0x2a4c>
  6e1f87:	mov    0x618(%r14),%rbx
  6e1f8e:	mov    0x620(%r14),%r15
  6e1f95:	mov    0x20(%rsp),%rdx
  6e1f9a:	test   %rdx,%rdx
  6e1f9d:	sete   %cl
  6e1fa0:	or     %al,%cl
  6e1fa2:	test   $0x1,%cl
  6e1fa5:	je     6e20fd <text_column_public_control::main+0x2abd>
  6e1fab:	movq   $0x0,0x618(%r14)
  6e1fb6:	lea    0x260(%rsp),%rdi
  6e1fbe:	mov    %r14,%rsi
  6e1fc1:	mov    %rbx,%rdx
  6e1fc4:	mov    %r15,%rcx
  6e1fc7:	call   6f14c0 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::publish_focus_change>
  6e1fcc:	mov    0x260(%rsp),%rax
  6e1fd4:	lea    0x268(%rsp),%rcx
  6e1fdc:	movups (%rcx),%xmm0
  6e1fdf:	movups 0x10(%rcx),%xmm1
  6e1fe3:	movups 0x20(%rcx),%xmm2
  6e1fe7:	movaps %xmm0,0xc60(%rsp)
  6e1fef:	movaps %xmm1,0xc70(%rsp)
  6e1ff7:	movaps %xmm2,0xc80(%rsp)
  6e1fff:	cmp    $0xfffffffffffffffe,%rax
  6e2003:	jne    6e222f <text_column_public_control::main+0x2bef>
  6e2009:	movaps 0xc60(%rsp),%xmm0
  6e2011:	movaps 0xc70(%rsp),%xmm1
  6e2019:	movaps 0xc80(%rsp),%xmm2
  6e2021:	movaps %xmm2,0x130(%rsp)
  6e2029:	movaps %xmm1,0x120(%rsp)
  6e2031:	movaps %xmm0,0x110(%rsp)
  6e2039:	cmpq   $0xffffffffffffffff,0x5b8(%r14)
  6e2041:	je     6e23be <text_column_public_control::main+0x2d7e>
  6e2047:	mov    0x698(%r14),%rax
  6e204e:	cmp    $0xffffffffffffffff,%rax
  6e2052:	mov    0x20(%rsp),%r12
  6e2057:	je     6e22d8 <text_column_public_control::main+0x2c98>
  6e205d:	inc    %rax
  6e2060:	cmp    0x690(%r14),%rax
  6e2067:	jne    6e22d8 <text_column_public_control::main+0x2c98>
  6e206d:	cmpq   $0x0,0x6b0(%r14)
  6e2075:	je     6e22d8 <text_column_public_control::main+0x2c98>
  6e207b:	mov    0x6b8(%r14),%rax
  6e2082:	mov    %rax,0x60(%rsp)
  6e2087:	jmp    6e23cc <text_column_public_control::main+0x2d8c>
  6e208c:	test   %r15b,%r15b
  6e208f:	mov    0x20(%rsp),%rcx
  6e2094:	jne    6e20ce <text_column_public_control::main+0x2a8e>
  6e2096:	test   %rcx,%rcx
  6e2099:	je     6e20ce <text_column_public_control::main+0x2a8e>
  6e209b:	cmp    %rcx,%rbx
  6e209e:	jne    6e20ce <text_column_public_control::main+0x2a8e>
  6e20a0:	mov    0x50(%rsp),%rcx
  6e20a5:	cmp    %rcx,0x68(%rsp)
  6e20aa:	jne    6e20ce <text_column_public_control::main+0x2a8e>
  6e20ac:	test   %al,%al
  6e20ae:	je     6e22a5 <text_column_public_control::main+0x2c65>
  6e20b4:	lea    0x70(%rsp),%rdi
  6e20b9:	mov    %r14,%rsi
  6e20bc:	mov    %rbx,%rdx
  6e20bf:	mov    0x68(%rsp),%rcx
  6e20c4:	call   6f5810 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::inspector_select>
  6e20c9:	jmp    6e1c20 <text_column_public_control::main+0x25e0>
  6e20ce:	movzbl 0x74c(%r14),%eax
  6e20d6:	cmpq   $0x0,0x6b0(%r14)
  6e20de:	je     6e20f6 <text_column_public_control::main+0x2ab6>
  6e20e0:	test   %al,%al
  6e20e2:	je     6e2261 <text_column_public_control::main+0x2c21>
  6e20e8:	cmpq   $0xffffffffffffffff,0x5b8(%r14)
  6e20f0:	jne    6e2261 <text_column_public_control::main+0x2c21>
  6e20f6:	xor    %edx,%edx
  6e20f8:	jmp    6e226d <text_column_public_control::main+0x2c2d>
  6e20fd:	mov    $0x11,%eax
  6e2102:	cmp    0x5e0(%r14),%rdx
  6e2109:	jne    6e21fc <text_column_public_control::main+0x2bbc>
  6e210f:	lea    0x260(%rsp),%rdi
  6e2117:	mov    %r14,%rsi
  6e211a:	mov    0x50(%rsp),%rdx
  6e211f:	call   70ca80 <<gpui::runtime::Runtime<text_column_public_control::Input>>::resolve_identity>
  6e2124:	mov    0x260(%rsp),%rax
  6e212c:	mov    0x268(%rsp),%rdi
  6e2134:	cmp    $0xfffffffffffffffe,%rax
  6e2138:	jne    6e21fc <text_column_public_control::main+0x2bbc>
  6e213e:	mov    0x2d0(%r14),%rsi
  6e2145:	cmp    %rsi,%rdi
  6e2148:	jae    6e3b1b <text_column_public_control::main+0x44db>
  6e214e:	mov    0x2c8(%r14),%rax
  6e2155:	lea    (%rdi,%rdi,4),%rcx
  6e2159:	mov    0x20(%rax,%rcx,8),%edi
  6e215d:	call   6f81d0 <<gpui::runtime::Node>::kind>
  6e2162:	cmp    $0x4,%al
  6e2164:	jne    6e27bb <text_column_public_control::main+0x317b>
  6e216a:	mov    0x40(%rsp),%rax
  6e216f:	cmp    $0xffffffff,%eax
  6e2172:	mov    0x20(%rsp),%rdx
  6e2177:	je     6e3b4f <text_column_public_control::main+0x450f>
  6e217d:	dec    %eax
  6e217f:	movd   %eax,%xmm0
  6e2183:	lea    0x260(%rsp),%rdi
  6e218b:	mov    %r14,%rsi
  6e218e:	mov    0x50(%rsp),%rcx
  6e2193:	movss  0x10(%rsp),%xmm1
  6e2199:	xor    %r8d,%r8d
  6e219c:	call   6f0ea0 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::select_pointer>
  6e21a1:	mov    0x260(%rsp),%rax
  6e21a9:	lea    0x268(%rsp),%rcx
  6e21b1:	movups (%rcx),%xmm0
  6e21b4:	movups 0x10(%rcx),%xmm1
  6e21b8:	movups 0x20(%rcx),%xmm2
  6e21bc:	lea    0x78(%rsp),%rcx
  6e21c1:	movups %xmm2,0x20(%rcx)
  6e21c5:	movups %xmm1,0x10(%rcx)
  6e21c9:	movups %xmm0,(%rcx)
  6e21cc:	cmp    $0xfffffffffffffffe,%rax
  6e21d0:	jne    6e28cc <text_column_public_control::main+0x328c>
  6e21d6:	movq   $0xfffffffffffffffe,0x70(%rsp)
  6e21df:	mov    0x20(%rsp),%r12
  6e21e4:	mov    0x50(%rsp),%rax
  6e21e9:	mov    %rax,0x68(%rsp)
  6e21ee:	movq   $0x0,0x60(%rsp)
  6e21f7:	jmp    6e1c20 <text_column_public_control::main+0x25e0>
  6e21fc:	lea    0x270(%rsp),%rdx
  6e2204:	mov    0x20(%rdx),%rcx
  6e2208:	lea    0x78(%rsp),%rsi
  6e220d:	mov    %rcx,0x28(%rsi)
  6e2211:	movups (%rdx),%xmm0
  6e2214:	movups 0x10(%rdx),%xmm1
  6e2218:	movups %xmm1,0x18(%rsi)
  6e221c:	movups %xmm0,0x8(%rsi)
  6e2220:	mov    %rax,0x70(%rsp)
  6e2225:	mov    %rdi,0x78(%rsp)
  6e222a:	jmp    6e1c20 <text_column_public_control::main+0x25e0>
  6e222f:	movaps 0xc60(%rsp),%xmm0
  6e2237:	movaps 0xc70(%rsp),%xmm1
  6e223f:	movaps 0xc80(%rsp),%xmm2
  6e2247:	lea    0x78(%rsp),%rcx
  6e224c:	movups %xmm2,0x20(%rcx)
  6e2250:	movups %xmm1,0x10(%rcx)
  6e2254:	movups %xmm0,(%rcx)
  6e2257:	mov    %rax,0x70(%rsp)
  6e225c:	jmp    6e1c20 <text_column_public_control::main+0x25e0>
  6e2261:	mov    0x6c0(%r14),%rcx
  6e2268:	mov    $0x1,%edx
  6e226d:	movups 0x690(%r14),%xmm0
  6e2275:	mov    0x738(%r14),%rsi
  6e227c:	mov    %rdx,0x78(%rsp)
  6e2281:	mov    %rcx,0x80(%rsp)
  6e2289:	movups %xmm0,0x88(%rsp)
  6e2291:	mov    %rsi,0x98(%rsp)
  6e2299:	mov    %al,0xa0(%rsp)
  6e22a0:	jmp    6e1c2c <text_column_public_control::main+0x25ec>
  6e22a5:	movq   $0x0,0x260(%rsp)
  6e22b1:	lea    0x70(%rsp),%rdi
  6e22b6:	lea    0xf8(%rsp),%rsi
  6e22be:	mov    %rbx,%rdx
  6e22c1:	mov    0x68(%rsp),%rcx
  6e22c6:	lea    0x260(%rsp),%r8
  6e22ce:	call   6e8240 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::activate_with_editing>
  6e22d3:	jmp    6e1c20 <text_column_public_control::main+0x25e0>
  6e22d8:	movq   $0x0,0x60(%rsp)
  6e22e1:	jmp    6e23cc <text_column_public_control::main+0x2d8c>
  6e22e6:	mov    0x738(%rbx),%rcx
  6e22ed:	movq   $0x0,0x78(%rsp)
  6e22f6:	mov    %rax,0x88(%rsp)
  6e22fe:	mov    %rax,0x90(%rsp)
  6e2306:	mov    %rcx,0x98(%rsp)
  6e230e:	movb   $0x1,0xa0(%rsp)
  6e2316:	movq   $0xfffffffffffffffe,0x70(%rsp)
  6e231f:	jmp    6e2be1 <text_column_public_control::main+0x35a1>
  6e2324:	jne    6e3618 <text_column_public_control::main+0x3fd8>
  6e232a:	mov    0x40(%rsp),%rax
  6e232f:	cmp    $0xffffffff,%eax
  6e2332:	je     6e3b3d <text_column_public_control::main+0x44fd>
  6e2338:	dec    %eax
  6e233a:	movd   %eax,%xmm0
  6e233e:	lea    0x260(%rsp),%rdi
  6e2346:	mov    %r14,%rsi
  6e2349:	mov    %r12,%rdx
  6e234c:	mov    0x68(%rsp),%rcx
  6e2351:	movd   0x10(%rsp),%xmm1
  6e2357:	mov    $0x1,%r8d
  6e235d:	call   6f0ea0 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::select_pointer>
  6e2362:	mov    0x260(%rsp),%rax
  6e236a:	cmp    $0xfffffffffffffffe,%rax
  6e236e:	je     6e237c <text_column_public_control::main+0x2d3c>
  6e2370:	cmp    $0x11,%eax
  6e2373:	mov    $0x0,%eax
  6e2378:	cmove  %rax,%r12
  6e237c:	mov    0x290(%rsp),%rax
  6e2384:	mov    %rax,0xa0(%rsp)
  6e238c:	movups 0x260(%rsp),%xmm0
  6e2394:	movups 0x270(%rsp),%xmm1
  6e239c:	movups 0x280(%rsp),%xmm2
  6e23a4:	movaps %xmm2,0x90(%rsp)
  6e23ac:	movaps %xmm1,0x80(%rsp)
  6e23b4:	movaps %xmm0,0x70(%rsp)
  6e23b9:	jmp    6e1c20 <text_column_public_control::main+0x25e0>
  6e23be:	movq   $0x0,0x60(%rsp)
  6e23c7:	mov    0x20(%rsp),%r12
  6e23cc:	movaps 0x110(%rsp),%xmm0
  6e23d4:	movaps 0x120(%rsp),%xmm1
  6e23dc:	movaps 0x130(%rsp),%xmm2
  6e23e4:	lea    0x78(%rsp),%rax
  6e23e9:	movups %xmm2,0x20(%rax)
  6e23ed:	movups %xmm1,0x10(%rax)
  6e23f1:	movups %xmm0,(%rax)
  6e23f4:	movq   $0xfffffffffffffffe,0x70(%rsp)
  6e23fd:	mov    0x50(%rsp),%rax
  6e2402:	mov    %rax,0x68(%rsp)
  6e2407:	jmp    6e1c20 <text_column_public_control::main+0x25e0>
  6e240c:	movq   $0x4,0x260(%rsp)
  6e2418:	lea    0x268(%rsp),%rax
  6e2420:	xorps  %xmm0,%xmm0
  6e2423:	movups %xmm0,(%rax)
  6e2426:	add    $0x8,%r15
  6e242a:	movss  0x20(%rsp),%xmm0
  6e2430:	cvtss2sd %xmm0,%xmm2
  6e2434:	mov    0x270(%rsp),%rax
  6e243c:	mov    %rax,0x1d0(%rsp)
  6e2444:	movups 0x260(%rsp),%xmm0
  6e244c:	movaps %xmm0,0x1c0(%rsp)
  6e2454:	movq   $0x3,0x260(%rsp)
  6e2460:	movq   $0x1,0x268(%rsp)
  6e246c:	mov    %r12,0x270(%rsp)
  6e2474:	movaps 0x50(%rsp),%xmm1
  6e2479:	movups %xmm1,0x278(%rsp)
  6e2481:	mov    %r13,0x148(%rsp)
  6e2489:	mov    %r13,0x290(%rsp)
  6e2491:	mov    %rbp,0x9b8(%rsp)
  6e2499:	mov    %rbp,0x298(%rsp)
  6e24a1:	mov    %r14,0x150(%rsp)
  6e24a9:	mov    %r14,0x2a0(%rsp)
  6e24b1:	lea    0x268(%rsp),%rcx
  6e24b9:	mov    %rax,0x50(%rcx)
  6e24bd:	movups %xmm0,0x40(%rcx)
  6e24c1:	movsd  %xmm2,0x9b0(%rsp)
  6e24ca:	movsd  %xmm2,0x2c0(%rsp)
  6e24d3:	mov    $0x8,%ebp
  6e24d8:	xor    %r14d,%r14d
  6e24db:	movq   $0x0,0x20(%rsp)
  6e24e4:	jmp    6e251f <text_column_public_control::main+0x2edf>
  6e24e6:	mov    0xe8(%rsp),%rbp
  6e24ee:	lea    (%r14,%r14,2),%rax
  6e24f2:	movq   $0x1,0x0(%rbp,%rax,8)
  6e24fb:	movsd  0x158(%rsp),%xmm0
  6e2504:	movsd  %xmm0,0x8(%rbp,%rax,8)
  6e250a:	mov    %r13,0x10(%rbp,%rax,8)
  6e250f:	inc    %r14
  6e2512:	mov    %r14,0xf0(%rsp)
  6e251a:	incq   0x20(%rsp)
  6e251f:	lea    0xc60(%rsp),%rdi
  6e2527:	lea    0x260(%rsp),%rsi
  6e252f:	call   *0x360023(%rip)        # a42558 <_DYNAMIC+0x568>
  6e2535:	mov    0xc78(%rsp),%rax
  6e253d:	cmp    $0x2,%rax
  6e2541:	je     6e257d <text_column_public_control::main+0x2f3d>
  6e2543:	test   $0x1,%al
  6e2545:	je     6e251a <text_column_public_control::main+0x2eda>
  6e2547:	mov    0xc80(%rsp),%r13
  6e254f:	movsd  0xc68(%rsp),%xmm0
  6e2558:	movsd  %xmm0,0x158(%rsp)
  6e2561:	cmp    0xe0(%rsp),%r14
  6e2569:	jne    6e24ee <text_column_public_control::main+0x2eae>
  6e256b:	lea    0xe0(%rsp),%rdi
  6e2573:	call   6f4580 <<alloc::raw_vec::RawVec<gpui::style_port::Draft>>::grow_one>
  6e2578:	jmp    6e24e6 <text_column_public_control::main+0x2ea6>
  6e257d:	cmpq   $0x0,0x20(%rsp)
  6e2583:	je     6e277e <text_column_public_control::main+0x313e>
  6e2589:	movq   $0x3,0x260(%rsp)
  6e2595:	movq   $0x1,0x268(%rsp)
  6e25a1:	mov    %r12,0x270(%rsp)
  6e25a9:	movaps 0x50(%rsp),%xmm0
  6e25ae:	movups %xmm0,0x278(%rsp)
  6e25b6:	mov    0x148(%rsp),%rax
  6e25be:	mov    %rax,0x290(%rsp)
  6e25c6:	mov    0x9b8(%rsp),%rax
  6e25ce:	mov    %rax,0x298(%rsp)
  6e25d6:	mov    0x150(%rsp),%rax
  6e25de:	mov    %rax,0x2a0(%rsp)
  6e25e6:	mov    0x1d0(%rsp),%rax
  6e25ee:	lea    0x268(%rsp),%rcx
  6e25f6:	mov    %rax,0x50(%rcx)
  6e25fa:	movaps 0x1c0(%rsp),%xmm0
  6e2602:	movups %xmm0,0x40(%rcx)
  6e2606:	movsd  0x9b0(%rsp),%xmm0
  6e260f:	movsd  %xmm0,0x2c0(%rsp)
  6e2618:	lea    0x30(%rsp),%rbp
  6e261d:	lea    0xc60(%rsp),%rdi
  6e2625:	lea    0x260(%rsp),%rsi
  6e262d:	call   *0x35ff25(%rip)        # a42558 <_DYNAMIC+0x568>
  6e2633:	mov    0xc78(%rsp),%rax
  6e263b:	cmp    $0x2,%rax
  6e263f:	je     6e26f4 <text_column_public_control::main+0x30b4>
  6e2645:	cmp    $0x1,%eax
  6e2648:	je     6e261d <text_column_public_control::main+0x2fdd>
  6e264a:	mov    0x648(%rbx),%rax
  6e2651:	test   %rax,%rax
  6e2654:	je     6e261d <text_column_public_control::main+0x2fdd>
  6e2656:	movdqa 0xc60(%rsp),%xmm0
  6e265f:	mov    0xc70(%rsp),%rcx
  6e2667:	mov    0x650(%rbx),%rdx
  6e266e:	movzwl 0x58a(%rax),%r8d
  6e2676:	lea    0x48(%rax),%rdi
  6e267a:	mov    %r8d,%r9d
  6e267d:	shl    $0x4,%r9d
  6e2681:	mov    $0xffffffffffffffff,%rsi
  6e2688:	xor    %r10d,%r10d
  6e268b:	jmp    6e26ae <text_column_public_control::main+0x306e>
  6e268d:	nopl   (%rax)
  6e2690:	cmp    0x8(%rax,%r10,1),%rcx
  6e2695:	seta   %r11b
  6e2699:	sbb    $0x0,%r11b
  6e269d:	add    $0x70,%rdi
  6e26a1:	inc    %rsi
  6e26a4:	add    $0x10,%r10
  6e26a8:	cmp    $0x1,%r11b
  6e26ac:	jne    6e26bf <text_column_public_control::main+0x307f>
  6e26ae:	cmp    %r10,%r9
  6e26b1:	je     6e26ca <text_column_public_control::main+0x308a>
  6e26b3:	cmpq   $0x0,(%rax,%r10,1)
  6e26b8:	jne    6e2690 <text_column_public_control::main+0x3050>
  6e26ba:	mov    $0x1,%r11b
  6e26bd:	jmp    6e269d <text_column_public_control::main+0x305d>
  6e26bf:	movzbl %r11b,%r8d
  6e26c3:	test   %r8d,%r8d
  6e26c6:	jne    6e26cd <text_column_public_control::main+0x308d>
  6e26c8:	jmp    6e26e1 <text_column_public_control::main+0x30a1>
  6e26ca:	mov    %r8,%rsi
  6e26cd:	sub    $0x1,%rdx
  6e26d1:	jb     6e261d <text_column_public_control::main+0x2fdd>
  6e26d7:	mov    0x590(%rax,%rsi,8),%rax
  6e26df:	jmp    6e266e <text_column_public_control::main+0x302e>
  6e26e1:	cmpl   $0x2,-0x8(%rdi)
  6e26e5:	jne    6e261d <text_column_public_control::main+0x2fdd>
  6e26eb:	movdqu %xmm0,(%rdi)
  6e26ef:	jmp    6e261d <text_column_public_control::main+0x2fdd>
  6e26f4:	test   %r14,%r14
  6e26f7:	je     6e2848 <text_column_public_control::main+0x3208>
  6e26fd:	mov    0xe8(%rsp),%r8
  6e2705:	movq   $0x0,(%rsp)
  6e270d:	lea    0xc60(%rsp),%rdi
  6e2715:	mov    %rbx,%rsi
  6e2718:	mov    %r15,%rdx
  6e271b:	xor    %ecx,%ecx
  6e271d:	mov    %r14,%r9
  6e2720:	call   6e8670 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::describe_with_changed>
  6e2725:	mov    $0x1,%r14b
  6e2728:	cmpl   $0xfffffffe,0xc60(%rsp)
  6e2730:	je     6e293f <text_column_public_control::main+0x32ff>
  6e2736:	mov    0xc90(%rsp),%rax
  6e273e:	mov    %rax,0x290(%rsp)
  6e2746:	movups 0xc60(%rsp),%xmm0
  6e274e:	movups 0xc70(%rsp),%xmm1
  6e2756:	movups 0xc80(%rsp),%xmm2
  6e275e:	movaps %xmm2,0x280(%rsp)
  6e2766:	movaps %xmm1,0x270(%rsp)
  6e276e:	movaps %xmm0,0x260(%rsp)
  6e2776:	mov    $0x1,%r14b
  6e2779:	jmp    6e2962 <text_column_public_control::main+0x3322>
  6e277e:	movzbl 0x74c(%rbx),%eax
  6e2785:	cmpq   $0x0,0x6b0(%rbx)
  6e278d:	lea    0x30(%rsp),%rbp
  6e2792:	je     6e288a <text_column_public_control::main+0x324a>
  6e2798:	test   %al,%al
  6e279a:	je     6e27aa <text_column_public_control::main+0x316a>
  6e279c:	cmpq   $0xffffffffffffffff,0x5b8(%rbx)
  6e27a4:	je     6e288a <text_column_public_control::main+0x324a>
  6e27aa:	mov    0x6c0(%rbx),%rdx
  6e27b1:	mov    $0x1,%ecx
  6e27b6:	jmp    6e288c <text_column_public_control::main+0x324c>
  6e27bb:	lea    0x260(%rsp),%rdi
  6e27c3:	mov    %r14,%rsi
  6e27c6:	mov    0x20(%rsp),%rdx
  6e27cb:	mov    0x50(%rsp),%rcx
  6e27d0:	call   6f0a50 <<gpui::runtime::Runtime<text_column_public_control::Input>>::focus>
  6e27d5:	mov    0x260(%rsp),%rax
  6e27dd:	cmp    $0xfffffffffffffffe,%rax
  6e27e1:	je     6e1fb6 <text_column_public_control::main+0x2976>
  6e27e7:	mov    0x288(%rsp),%rcx
  6e27ef:	movzbl 0x290(%rsp),%edx
  6e27f7:	lea    0x268(%rsp),%rdi
  6e27ff:	mov    0x29(%rdi),%esi
  6e2802:	mov    0x2c(%rdi),%edi
  6e2805:	lea    0x78(%rsp),%r8
  6e280a:	mov    %edi,0x2c(%r8)
  6e280e:	mov    %esi,0x29(%r8)
  6e2812:	movups 0x268(%rsp),%xmm0
  6e281a:	movups 0x278(%rsp),%xmm1
  6e2822:	mov    %rax,0x70(%rsp)
  6e2827:	movups %xmm0,0x78(%rsp)
  6e282c:	movups %xmm1,0x88(%rsp)
  6e2834:	mov    %rcx,0x98(%rsp)
  6e283c:	mov    %dl,0xa0(%rsp)
  6e2843:	jmp    6e1c20 <text_column_public_control::main+0x25e0>
  6e2848:	mov    0x648(%rbx),%rax
  6e284f:	test   %rax,%rax
  6e2852:	je     6e2930 <text_column_public_control::main+0x32f0>
  6e2858:	mov    0x650(%rbx),%rcx
  6e285f:	test   %rcx,%rcx
  6e2862:	je     6e291d <text_column_public_control::main+0x32dd>
  6e2868:	mov    %rcx,%rdx
  6e286b:	and    $0x7,%rdx
  6e286f:	je     6e28d6 <text_column_public_control::main+0x3296>
  6e2871:	xor    %esi,%esi
  6e2873:	mov    0x590(%rax),%rax
  6e287a:	inc    %rsi
  6e287d:	cmp    %rsi,%rdx
  6e2880:	jne    6e2873 <text_column_public_control::main+0x3233>
  6e2882:	mov    %rcx,%rdx
  6e2885:	sub    %rsi,%rdx
  6e2888:	jmp    6e28d9 <text_column_public_control::main+0x3299>
  6e288a:	xor    %ecx,%ecx
  6e288c:	movups 0x690(%rbx),%xmm0
  6e2893:	mov    0x738(%rbx),%rsi
  6e289a:	mov    %rcx,0x78(%rsp)
  6e289f:	mov    %rdx,0x80(%rsp)
  6e28a7:	movups %xmm0,0x88(%rsp)
  6e28af:	mov    %rsi,0x98(%rsp)
  6e28b7:	mov    %al,0xa0(%rsp)
  6e28be:	movq   $0xfffffffffffffffe,0x70(%rsp)
  6e28c7:	jmp    6e2bb9 <text_column_public_control::main+0x3579>
  6e28cc:	mov    %rax,0x70(%rsp)
  6e28d1:	jmp    6e1c20 <text_column_public_control::main+0x25e0>
  6e28d6:	mov    %rcx,%rdx
  6e28d9:	cmp    $0x8,%rcx
  6e28dd:	jb     6e291d <text_column_public_control::main+0x32dd>
  6e28df:	mov    0x590(%rax),%rax
  6e28e6:	mov    0x590(%rax),%rax
  6e28ed:	mov    0x590(%rax),%rax
  6e28f4:	mov    0x590(%rax),%rax
  6e28fb:	mov    0x590(%rax),%rax
  6e2902:	mov    0x590(%rax),%rax
  6e2909:	mov    0x590(%rax),%rax
  6e2910:	mov    0x590(%rax),%rax
  6e2917:	add    $0xfffffffffffffff8,%rdx
  6e291b:	jne    6e28df <text_column_public_control::main+0x329f>
  6e291d:	cmpw   $0x0,0x58a(%rax)
  6e2925:	je     6e2930 <text_column_public_control::main+0x32f0>
  6e2927:	cmpl   $0x1,(%rax)
  6e292a:	jne    6e26fd <text_column_public_control::main+0x30bd>
  6e2930:	movq   $0xfffffffffffffffe,0xc60(%rsp)
  6e293c:	xor    %r14d,%r14d
  6e293f:	movb   $0x1,0x74b(%rbx)
  6e2946:	mov    0x20(%rsp),%rax
  6e294b:	mov    %rax,0x738(%rbx)
  6e2952:	lea    0x260(%rsp),%rdi
  6e295a:	mov    %rbx,%rsi
  6e295d:	call   70d1e0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present>
  6e2962:	cmpq   $0xfffffffffffffffe,0x260(%rsp)
  6e296b:	je     6e2b7c <text_column_public_control::main+0x353c>
  6e2971:	cmpq   $0x0,0x640(%rbx)
  6e2979:	je     6e2b70 <text_column_public_control::main+0x3530>
  6e297f:	mov    0x648(%rbx),%rax
  6e2986:	test   %rax,%rax
  6e2989:	je     6e2b70 <text_column_public_control::main+0x3530>
  6e298f:	mov    0x658(%rbx),%r15
  6e2996:	test   %r15,%r15
  6e2999:	je     6e2b70 <text_column_public_control::main+0x3530>
  6e299f:	mov    0x650(%rbx),%r13
  6e29a6:	xor    %r12d,%r12d
  6e29a9:	jmp    6e29be <text_column_public_control::main+0x337e>
  6e29ab:	mov    $0x0,%eax
  6e29b0:	dec    %r15
  6e29b3:	lea    0x30(%rsp),%rbp
  6e29b8:	je     6e2b70 <text_column_public_control::main+0x3530>
  6e29be:	test   %r12,%r12
  6e29c1:	jne    6e2a40 <text_column_public_control::main+0x3400>
  6e29c3:	test   %r13,%r13
  6e29c6:	je     6e29ee <text_column_public_control::main+0x33ae>
  6e29c8:	mov    %r13,%rcx
  6e29cb:	mov    %rax,%r12
  6e29ce:	and    $0x7,%rcx
  6e29d2:	je     6e29f3 <text_column_public_control::main+0x33b3>
  6e29d4:	xor    %edx,%edx
  6e29d6:	mov    0x590(%r12),%r12
  6e29de:	inc    %rdx
  6e29e1:	cmp    %rdx,%rcx
  6e29e4:	jne    6e29d6 <text_column_public_control::main+0x3396>
  6e29e6:	mov    %r13,%rax
  6e29e9:	sub    %rdx,%rax
  6e29ec:	jmp    6e29f6 <text_column_public_control::main+0x33b6>
  6e29ee:	mov    %rax,%r12
  6e29f1:	jmp    6e2a3b <text_column_public_control::main+0x33fb>
  6e29f3:	mov    %r13,%rax
  6e29f6:	cmp    $0x8,%r13
  6e29fa:	jb     6e2a3b <text_column_public_control::main+0x33fb>
  6e29fc:	mov    0x590(%r12),%rcx
  6e2a04:	mov    0x590(%rcx),%rcx
  6e2a0b:	mov    0x590(%rcx),%rcx
  6e2a12:	mov    0x590(%rcx),%rcx
  6e2a19:	mov    0x590(%rcx),%rcx
  6e2a20:	mov    0x590(%rcx),%rcx
  6e2a27:	mov    0x590(%rcx),%rcx
  6e2a2e:	mov    0x590(%rcx),%r12
  6e2a35:	add    $0xfffffffffffffff8,%rax
  6e2a39:	jne    6e29fc <text_column_public_control::main+0x33bc>
  6e2a3b:	xor    %r13d,%r13d
  6e2a3e:	xor    %eax,%eax
  6e2a40:	movzwl 0x58a(%r12),%ecx
  6e2a49:	cmp    %rcx,%r13
  6e2a4c:	jae    6e2a56 <text_column_public_control::main+0x3416>
  6e2a4e:	mov    %r13,%rdx
  6e2a51:	mov    %r12,%rcx
  6e2a54:	jmp    6e2a7f <text_column_public_control::main+0x343f>
  6e2a56:	mov    0x580(%r12),%rcx
  6e2a5e:	test   %rcx,%rcx
  6e2a61:	je     6e3aeb <text_column_public_control::main+0x44ab>
  6e2a67:	inc    %rax
  6e2a6a:	movzwl 0x588(%r12),%edx
  6e2a73:	mov    %rcx,%r12
  6e2a76:	cmp    0x58a(%rcx),%dx
  6e2a7d:	jae    6e2a56 <text_column_public_control::main+0x3416>
  6e2a7f:	test   %rax,%rax
  6e2a82:	je     6e2ab6 <text_column_public_control::main+0x3476>
  6e2a84:	lea    (%rcx,%rdx,8),%rsi
  6e2a88:	add    $0x598,%rsi
  6e2a8f:	mov    %rax,%rdi
  6e2a92:	and    $0x7,%rdi
  6e2a96:	je     6e2abf <text_column_public_control::main+0x347f>
  6e2a98:	xor    %r8d,%r8d
  6e2a9b:	mov    (%rsi),%r12
  6e2a9e:	lea    0x590(%r12),%rsi
  6e2aa6:	inc    %r8
  6e2aa9:	cmp    %r8,%rdi
  6e2aac:	jne    6e2a9b <text_column_public_control::main+0x345b>
  6e2aae:	mov    %rax,%rdi
  6e2ab1:	sub    %r8,%rdi
  6e2ab4:	jmp    6e2ac2 <text_column_public_control::main+0x3482>
  6e2ab6:	lea    0x1(%rdx),%r13
  6e2aba:	mov    %rcx,%r12
  6e2abd:	jmp    6e2b0d <text_column_public_control::main+0x34cd>
  6e2abf:	mov    %rax,%rdi
  6e2ac2:	cmp    $0x8,%rax
  6e2ac6:	jb     6e2b0a <text_column_public_control::main+0x34ca>
  6e2ac8:	mov    (%rsi),%rax
  6e2acb:	mov    0x590(%rax),%rax
  6e2ad2:	mov    0x590(%rax),%rax
  6e2ad9:	mov    0x590(%rax),%rax
  6e2ae0:	mov    0x590(%rax),%rax
  6e2ae7:	mov    0x590(%rax),%rax
  6e2aee:	mov    0x590(%rax),%rax
  6e2af5:	mov    0x590(%rax),%r12
  6e2afc:	lea    0x590(%r12),%rsi
  6e2b04:	add    $0xfffffffffffffff8,%rdi
  6e2b08:	jne    6e2ac8 <text_column_public_control::main+0x3488>
  6e2b0a:	xor    %r13d,%r13d
  6e2b0d:	mov    %rdx,%rax
  6e2b10:	shl    $0x4,%rax
  6e2b14:	cmpl   $0x1,(%rcx,%rax,1)
  6e2b18:	jne    6e29ab <text_column_public_control::main+0x336b>
  6e2b1e:	imul   $0x70,%rdx,%rdx
  6e2b22:	lea    (%rcx,%rdx,1),%rbp
  6e2b26:	add    $0xb0,%rbp
  6e2b2d:	cmpl   $0x2,0x0(%rbp)
  6e2b31:	jne    6e29ab <text_column_public_control::main+0x336b>
  6e2b37:	mov    0x8(%rcx,%rax,1),%rdx
  6e2b3c:	mov    0x640(%rbx),%rsi
  6e2b43:	lea    0xf8(%rsp),%rdi
  6e2b4b:	call   *0x35fa0f(%rip)        # a42560 <_DYNAMIC+0x570>
  6e2b51:	cmpl   $0x1,0xf8(%rsp)
  6e2b59:	jne    6e29ab <text_column_public_control::main+0x336b>
  6e2b5f:	movups 0x100(%rsp),%xmm0
  6e2b67:	movups %xmm0,0x8(%rbp)
  6e2b6b:	jmp    6e29ab <text_column_public_control::main+0x336b>
  6e2b70:	test   %r14b,%r14b
  6e2b73:	jne    6e2b7c <text_column_public_control::main+0x353c>
  6e2b75:	movb   $0x0,0x74b(%rbx)
  6e2b7c:	mov    0x290(%rsp),%rax
  6e2b84:	mov    %rax,0xa0(%rsp)
  6e2b8c:	movaps 0x260(%rsp),%xmm0
  6e2b94:	movaps 0x270(%rsp),%xmm1
  6e2b9c:	movaps 0x280(%rsp),%xmm2
  6e2ba4:	movaps %xmm2,0x90(%rsp)
  6e2bac:	movaps %xmm1,0x80(%rsp)
  6e2bb4:	movaps %xmm0,0x70(%rsp)
  6e2bb9:	mov    0xe0(%rsp),%rax
  6e2bc1:	test   %rax,%rax
  6e2bc4:	je     6e2be1 <text_column_public_control::main+0x35a1>
  6e2bc6:	mov    0xe8(%rsp),%rdi
  6e2bce:	shl    $0x3,%rax
  6e2bd2:	lea    (%rax,%rax,2),%rsi
  6e2bd6:	mov    $0x8,%edx
  6e2bdb:	call   *0x35f677(%rip)        # a42258 <_DYNAMIC+0x268>
  6e2be1:	xor    %r12d,%r12d
  6e2be4:	jmp    6e1c20 <text_column_public_control::main+0x25e0>
  6e2be9:	mov    0x30(%rsp),%rsi
  6e2bee:	lea    0x260(%rsp),%rbx
  6e2bf6:	mov    %rbx,%rdi
  6e2bf9:	call   6dd040 <text_column_public_control::public_query>
  6e2bfe:	mov    0x260(%rsp),%r12
  6e2c06:	lea    0x33fadb(%rip),%rcx        # a226e8 <__frame_dummy_init_array_entry+0xbf8>
  6e2c0d:	cmp    0x230(%rsp),%r12
  6e2c15:	jne    6e31ab <text_column_public_control::main+0x3b6b>
  6e2c1b:	mov    0x268(%rsp),%r13
  6e2c23:	cmp    0x238(%rsp),%r13
  6e2c2b:	jne    6e31ab <text_column_public_control::main+0x3b6b>
  6e2c31:	mov    %rbp,%rax
  6e2c34:	mov    0x270(%rsp),%rbp
  6e2c3c:	cmp    0x240(%rsp),%rbp
  6e2c44:	jne    6e31ab <text_column_public_control::main+0x3b6b>
  6e2c4a:	mov    0x30(%rsp),%rsi
  6e2c4f:	test   %rsi,%rsi
  6e2c52:	je     6e33a3 <text_column_public_control::main+0x3d63>
  6e2c58:	cmpq   $0x1,0x2b0(%rsi)
  6e2c60:	jne    6e33e8 <text_column_public_control::main+0x3da8>
  6e2c66:	mov    %rax,0x260(%rsp)
  6e2c6e:	lea    0x260(%rsp),%rax
  6e2c76:	mov    0x260(%rsp),%rsi
  6e2c7e:	movl   $0x3e000000,0x260(%rsp)
  6e2c89:	movss  0x260(%rsp),%xmm0
  6e2c92:	lea    0x260(%rsp),%rdi
  6e2c9a:	call   6dd6c0 <text_column_public_control::public_prepare>
  6e2c9f:	mov    0x30(%rsp),%rax
  6e2ca4:	test   %rax,%rax
  6e2ca7:	je     6e3a72 <text_column_public_control::main+0x4432>
  6e2cad:	cmpb   $0x0,0x74e(%rax)
  6e2cb4:	jne    6e3a79 <text_column_public_control::main+0x4439>
  6e2cba:	mov    0x6b0(%rax),%r14
  6e2cc1:	test   %r14,%r14
  6e2cc4:	je     6e3a80 <text_column_public_control::main+0x4440>
  6e2cca:	mov    0x6b8(%rax),%r15
  6e2cd1:	movl   $0x3e800000,0x260(%rsp)
  6e2cdc:	lea    0x260(%rsp),%rax
  6e2ce4:	movd   0x260(%rsp),%xmm0
  6e2ced:	lea    0x260(%rsp),%rdi
  6e2cf5:	lea    0x30(%rsp),%rsi
  6e2cfa:	call   6dd6c0 <text_column_public_control::public_prepare>
  6e2cff:	mov    0x30(%rsp),%rsi
  6e2d04:	lea    0x260(%rsp),%rbx
  6e2d0c:	mov    %rbx,%rdi
  6e2d0f:	call   6dd040 <text_column_public_control::public_query>
  6e2d14:	cmp    %r13,0x268(%rsp)
  6e2d1c:	sete   %al
  6e2d1f:	cmp    %r12,0x260(%rsp)
  6e2d27:	jne    6e3185 <text_column_public_control::main+0x3b45>
  6e2d2d:	cmp    %rbp,0x270(%rsp)
  6e2d35:	sete   %cl
  6e2d38:	test   %al,%al
  6e2d3a:	je     6e319a <text_column_public_control::main+0x3b5a>
  6e2d40:	test   %cl,%cl
  6e2d42:	je     6e31a4 <text_column_public_control::main+0x3b64>
  6e2d48:	mov    0x30(%rsp),%rsi
  6e2d4d:	test   %rsi,%rsi
  6e2d50:	je     6e2d6e <text_column_public_control::main+0x372e>
  6e2d52:	cmpb   $0x0,0x74e(%rsi)
  6e2d59:	je     6e2d8d <text_column_public_control::main+0x374d>
  6e2d5b:	movq   $0xe,0x260(%rsp)
  6e2d67:	mov    $0xe,%ebx
  6e2d6c:	jmp    6e2db2 <text_column_public_control::main+0x3772>
  6e2d6e:	movq   $0xd,0x260(%rsp)
  6e2d7a:	movq   $0x0,0x268(%rsp)
  6e2d86:	mov    $0xd,%ebx
  6e2d8b:	jmp    6e2db2 <text_column_public_control::main+0x3772>
  6e2d8d:	lea    0x260(%rsp),%rdi
  6e2d95:	mov    %r14,%rdx
  6e2d98:	mov    %r15,%rcx
  6e2d9b:	call   6fdef0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge>
  6e2da0:	mov    0x260(%rsp),%rbx
  6e2da8:	cmp    $0xfffffffffffffffe,%rbx
  6e2dac:	je     6e343e <text_column_public_control::main+0x3dfe>
  6e2db2:	lea    -0x6958f9(%rip),%rsi        # 4d4c0 <GCC_except_table0+0xd71c>
  6e2db9:	lea    0x260(%rsp),%rdi
  6e2dc1:	call   727b10 <<gpui::runtime::Error as core::cmp::PartialEq>::eq>
  6e2dc6:	test   %al,%al
  6e2dc8:	je     6e343e <text_column_public_control::main+0x3dfe>
  6e2dce:	sub    $0xd,%rbx
  6e2dd2:	mov    $0x14,%eax
  6e2dd7:	cmovge %rbx,%rax
  6e2ddb:	cmp    $0x14,%rax
  6e2ddf:	je     6e2f48 <text_column_public_control::main+0x3908>
  6e2de5:	cmp    $0x19,%rax
  6e2de9:	jne    6e2e0e <text_column_public_control::main+0x37ce>
  6e2deb:	mov    0x268(%rsp),%rsi
  6e2df3:	lea    0x270(%rsp),%rax
  6e2dfb:	test   %rsi,%rsi
  6e2dfe:	je     6e2e0e <text_column_public_control::main+0x37ce>
  6e2e00:	mov    (%rax),%rdi
  6e2e03:	mov    $0x1,%edx
  6e2e08:	call   *0x35f44a(%rip)        # a42258 <_DYNAMIC+0x268>
  6e2e0e:	mov    0x30(%rsp),%rsi
  6e2e13:	lea    0x9c0(%rsp),%rdi
  6e2e1b:	call   6b5c90 <text_column_public_control::ack::<text_column_public_control::Input>>
  6e2e20:	mov    0x30(%rsp),%rsi
  6e2e25:	lea    0xc60(%rsp),%rbx
  6e2e2d:	mov    %rbx,%rdi
  6e2e30:	call   6dd040 <text_column_public_control::public_query>
  6e2e35:	xor    0xc60(%rsp),%r12
  6e2e3d:	xor    0xc68(%rsp),%r13
  6e2e45:	cmp    %rbp,0xc70(%rsp)
  6e2e4d:	sete   %al
  6e2e50:	or     %r12,%r13
  6e2e53:	je     6e2e57 <text_column_public_control::main+0x3817>
  6e2e55:	xor    %eax,%eax
  6e2e57:	test   %al,%al
  6e2e59:	jne    6e31af <text_column_public_control::main+0x3b6f>
  6e2e5f:	lea    0xc68(%rsp),%rax
  6e2e67:	lea    0x9d8(%rsp),%rcx
  6e2e6f:	lea    0xc60(%rsp),%rdx
  6e2e77:	mov    %rdx,0x260(%rsp)
  6e2e7f:	mov    0x35f622(%rip),%rdx        # a424a8 <_DYNAMIC+0x4b8>
  6e2e86:	mov    %rdx,0x268(%rsp)
  6e2e8e:	mov    %rax,0x270(%rsp)
  6e2e96:	mov    %rdx,0x278(%rsp)
  6e2e9e:	lea    0xc70(%rsp),%rax
  6e2ea6:	mov    %rax,0x280(%rsp)
  6e2eae:	mov    0x35f5fb(%rip),%rax        # a424b0 <_DYNAMIC+0x4c0>
  6e2eb5:	mov    %rax,0x288(%rsp)
  6e2ebd:	lea    0x9d0(%rsp),%rsi
  6e2ec5:	mov    %rsi,0x290(%rsp)
  6e2ecd:	mov    %rax,0x298(%rsp)
  6e2ed5:	mov    %rcx,0x2a0(%rsp)
  6e2edd:	mov    %rax,0x2a8(%rsp)
  6e2ee5:	lea    -0x6a16f4(%rip),%rax        # 417f8 <GCC_except_table0+0x1a54>
  6e2eec:	mov    %rax,0x2b0(%rsp)
  6e2ef4:	mov    %rdx,0x2b8(%rsp)
  6e2efc:	lea    -0x6a187b(%rip),%rax        # 41688 <GCC_except_table0+0x18e4>
  6e2f03:	mov    %rax,0x2c0(%rsp)
  6e2f0b:	mov    %rdx,0x2c8(%rsp)
  6e2f13:	lea    -0x696059(%rip),%rdi        # 4cec1 <GCC_except_table0+0xd11d>
  6e2f1a:	lea    0x260(%rsp),%rsi
  6e2f22:	call   *0x35f598(%rip)        # a424c0 <_DYNAMIC+0x4d0>
  6e2f28:	mov    0x30(%rsp),%r14
  6e2f2d:	test   %r14,%r14
  6e2f30:	je     6e47bc <text_column_public_control::main+0x517c>
  6e2f36:	mov    %r14,%rdi
  6e2f39:	call   6bfb20 <core::ptr::drop_glue::<gpui::runtime::Runtime<text_column_public_control::Input>>>
  6e2f3e:	mov    $0x750,%esi
  6e2f43:	jmp    6e47ae <text_column_public_control::main+0x516e>
  6e2f48:	mov    0x278(%rsp),%rsi
  6e2f50:	test   %rsi,%rsi
  6e2f53:	lea    0x280(%rsp),%rax
  6e2f5b:	jne    6e2e00 <text_column_public_control::main+0x37c0>
  6e2f61:	jmp    6e2e0e <text_column_public_control::main+0x37ce>
  6e2f66:	jne    6e3457 <text_column_public_control::main+0x3e17>
  6e2f6c:	lea    0x9c0(%rsp),%rdi
  6e2f74:	mov    %r12,%rsi
  6e2f77:	mov    %r14,%rdx
  6e2f7a:	mov    %rbx,%rcx
  6e2f7d:	movaps 0x40(%rsp),%xmm1
  6e2f82:	xor    %r8d,%r8d
  6e2f85:	call   6f0ea0 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::select_pointer>
  6e2f8a:	jmp    6e120a <text_column_public_control::main+0x1bca>
  6e2f8f:	mov    $0x16,%eax
  6e2f94:	jmp    6e106d <text_column_public_control::main+0x1a2d>
  6e2f99:	mov    0x260(%rsp),%rcx
  6e2fa1:	test   %rbp,%rbp
  6e2fa4:	je     6e2fbf <text_column_public_control::main+0x397f>
  6e2fa6:	mov    0x5e0(%r12),%rax
  6e2fae:	xor    %rbp,%rax
  6e2fb1:	mov    %r15,%rdx
  6e2fb4:	xor    %rcx,%rdx
  6e2fb7:	or     %rax,%rdx
  6e2fba:	sete   %al
  6e2fbd:	jmp    6e2fc1 <text_column_public_control::main+0x3981>
  6e2fbf:	xor    %eax,%eax
  6e2fc1:	mov    0x268(%rsp),%edx
  6e2fc8:	mov    0x270(%rsp),%esi
  6e2fcf:	mov    0x618(%r12),%rdi
  6e2fd7:	test   %rdi,%rdi
  6e2fda:	je     6e2ff4 <text_column_public_control::main+0x39b4>
  6e2fdc:	xor    0x5e0(%r12),%rdi
  6e2fe4:	xor    0x620(%r12),%rcx
  6e2fec:	or     %rdi,%rcx
  6e2fef:	sete   %cl
  6e2ff2:	jmp    6e2ff6 <text_column_public_control::main+0x39b6>
  6e2ff4:	xor    %ecx,%ecx
  6e2ff6:	cmp    %esi,%edx
  6e2ff8:	jne    6e114f <text_column_public_control::main+0x1b0f>
  6e2ffe:	xor    %cl,%al
  6e3000:	je     6e114f <text_column_public_control::main+0x1b0f>
  6e3006:	movq   $0x2,0x260(%rsp)
  6e3012:	lea    0x9c0(%rsp),%rdi
  6e301a:	lea    0x70(%rsp),%rsi
  6e301f:	lea    0x260(%rsp),%r8
  6e3027:	mov    %r14,%rdx
  6e302a:	mov    %rbx,%rcx
  6e302d:	call   6e8240 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::activate_with_editing>
  6e3032:	cmpl   $0xfffffffe,0x9c0(%rsp)
  6e303a:	jne    6e307c <text_column_public_control::main+0x3a3c>
  6e303c:	mov    0x6b0(%r12),%rax
  6e3044:	test   %rax,%rax
  6e3047:	je     6e311a <text_column_public_control::main+0x3ada>
  6e304d:	cmpq   $0x0,0x10(%rsp)
  6e3053:	je     6e120a <text_column_public_control::main+0x1bca>
  6e3059:	cmp    0x10(%rsp),%rax
  6e305e:	jne    6e120a <text_column_public_control::main+0x1bca>
  6e3064:	mov    0x40(%rsp),%rax
  6e3069:	cmp    %rax,0x6b8(%r12)
  6e3071:	je     6e3126 <text_column_public_control::main+0x3ae6>
  6e3077:	jmp    6e120a <text_column_public_control::main+0x1bca>
  6e307c:	cmp    %r13,0x690(%r12)
  6e3084:	jne    6e120a <text_column_public_control::main+0x1bca>
  6e308a:	cmpb   $0x1,0x74a(%r12)
  6e3093:	jne    6e120a <text_column_public_control::main+0x1bca>
  6e3099:	cmpb   $0x0,0x74e(%r12)
  6e30a2:	jne    6e120a <text_column_public_control::main+0x1bca>
  6e30a8:	mov    %rbp,0x618(%r12)
  6e30b0:	mov    %r15,0x620(%r12)
  6e30b8:	jmp    6e120a <text_column_public_control::main+0x1bca>
  6e30bd:	lea    0x1f0(%rsp),%rsi
  6e30c5:	lea    0x1a0(%rsp),%rdx
  6e30cd:	lea    0x33f6bc(%rip),%r9        # a22790 <__frame_dummy_init_array_entry+0xca0>
  6e30d4:	jmp    6e30ed <text_column_public_control::main+0x3aad>
  6e30d6:	lea    0x1f8(%rsp),%rsi
  6e30de:	lea    0x1a8(%rsp),%rdx
  6e30e6:	lea    0x33f6bb(%rip),%r9        # a227a8 <__frame_dummy_init_array_entry+0xcb8>
  6e30ed:	xor    %edi,%edi
  6e30ef:	xor    %ecx,%ecx
  6e30f1:	call   *0x35f471(%rip)        # a42568 <_DYNAMIC+0x578>
  6e30f7:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e30fc:	lea    -0x695c0b(%rip),%rdi        # 4d4f8 <GCC_except_table0+0xd754>
  6e3103:	lea    0x33f6b6(%rip),%rdx        # a227c0 <__frame_dummy_init_array_entry+0xcd0>
  6e310a:	mov    $0x2c,%esi
  6e310f:	call   *0x35f19b(%rip)        # a422b0 <_DYNAMIC+0x2c0>
  6e3115:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e311a:	cmpq   $0x0,0x10(%rsp)
  6e3120:	jne    6e120a <text_column_public_control::main+0x1bca>
  6e3126:	lea    0x9c0(%rsp),%rdi
  6e312e:	mov    %r12,%rsi
  6e3131:	mov    %rbp,%rdx
  6e3134:	mov    %r15,%rcx
  6e3137:	call   6f14c0 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::publish_focus_change>
  6e313c:	jmp    6e120a <text_column_public_control::main+0x1bca>
  6e3141:	lea    0x33fa00(%rip),%rcx        # a22b48 <__frame_dummy_init_array_entry+0x1058>
  6e3148:	lea    0x260(%rsp),%rsi
  6e3150:	lea    0x1c0(%rsp),%rdx
  6e3158:	xor    %edi,%edi
  6e315a:	call   6c86bd <core::panicking::assert_failed::<(usize, usize, u64), (usize, usize, u64)>>
  6e315f:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3164:	xor    %eax,%eax
  6e3166:	test   %al,%al
  6e3168:	jne    6e03d4 <text_column_public_control::main+0xd94>
  6e316e:	lea    0x70(%rsp),%rdi
  6e3173:	lea    0x260(%rsp),%rsi
  6e317b:	call   6c85dc <core::panicking::assert_failed::<core::option::Option<u64>, core::option::Option<u64>>>
  6e3180:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3185:	xor    %eax,%eax
  6e3187:	cmp    %rbp,0x270(%rsp)
  6e318f:	sete   %cl
  6e3192:	test   %al,%al
  6e3194:	jne    6e2d40 <text_column_public_control::main+0x3700>
  6e319a:	xor    %ecx,%ecx
  6e319c:	test   %cl,%cl
  6e319e:	jne    6e2d48 <text_column_public_control::main+0x3708>
  6e31a4:	lea    0x33f585(%rip),%rcx        # a22730 <__frame_dummy_init_array_entry+0xc40>
  6e31ab:	xor    %eax,%eax
  6e31ad:	jmp    6e31b8 <text_column_public_control::main+0x3b78>
  6e31af:	lea    0x33f5aa(%rip),%rcx        # a22760 <__frame_dummy_init_array_entry+0xc70>
  6e31b6:	mov    $0x1,%al
  6e31b8:	movzbl %al,%edi
  6e31bb:	lea    0x230(%rsp),%rdx
  6e31c3:	mov    %rbx,%rsi
  6e31c6:	call   6c86bd <core::panicking::assert_failed::<(usize, usize, u64), (usize, usize, u64)>>
  6e31cb:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e31d0:	mov    $0x8,%edi
  6e31d5:	mov    $0x28,%esi
  6e31da:	call   *0x35f090(%rip)        # a42270 <_DYNAMIC+0x280>
  6e31e0:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e31e5:	mov    $0x8,%edi
  6e31ea:	mov    $0x750,%esi
  6e31ef:	call   *0x35f07b(%rip)        # a42270 <_DYNAMIC+0x280>
  6e31f5:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e31fa:	lea    -0x69312c(%rip),%rdi        # 500d5 <GCC_except_table0+0x10331>
  6e3201:	lea    0x33ff88(%rip),%rdx        # a23190 <__frame_dummy_init_array_entry+0x16a0>
  6e3208:	mov    $0x22,%esi
  6e320d:	call   *0x35f1e5(%rip)        # a423f8 <_DYNAMIC+0x408>
  6e3213:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3218:	lea    0x120(%rsp),%rsi
  6e3220:	lea    0x33f8c1(%rip),%r9        # a22ae8 <__frame_dummy_init_array_entry+0xff8>
  6e3227:	xor    %edi,%edi
  6e3229:	mov    %r14,%rdx
  6e322c:	xor    %ecx,%ecx
  6e322e:	call   *0x35f334(%rip)        # a42568 <_DYNAMIC+0x578>
  6e3234:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3239:	lea    0x33f7d0(%rip),%r9        # a22a10 <__frame_dummy_init_array_entry+0xf20>
  6e3240:	mov    %rbx,%r12
  6e3243:	jmp    6e342c <text_column_public_control::main+0x3dec>
  6e3248:	lea    -0x695c3c(%rip),%rdi        # 4d613 <GCC_except_table0+0xd86f>
  6e324f:	lea    0x33f8aa(%rip),%rdx        # a22b00 <__frame_dummy_init_array_entry+0x1010>
  6e3256:	mov    $0x2d,%esi
  6e325b:	call   *0x35f04f(%rip)        # a422b0 <_DYNAMIC+0x2c0>
  6e3261:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3266:	lea    0x33f7bb(%rip),%r9        # a22a28 <__frame_dummy_init_array_entry+0xf38>
  6e326d:	mov    %rbx,%rdx
  6e3270:	jmp    6e342c <text_column_public_control::main+0x3dec>
  6e3275:	lea    0x33f7c4(%rip),%rdx        # a22a40 <__frame_dummy_init_array_entry+0xf50>
  6e327c:	mov    $0x37,%esi
  6e3281:	lea    -0x695d01(%rip),%rdi        # 4d587 <GCC_except_table0+0xd7e3>
  6e3288:	jmp    6e329d <text_column_public_control::main+0x3c5d>
  6e328a:	lea    0x33f7c7(%rip),%rdx        # a22a58 <__frame_dummy_init_array_entry+0xf68>
  6e3291:	mov    $0x31,%esi
  6e3296:	lea    -0x695cdf(%rip),%rdi        # 4d5be <GCC_except_table0+0xd81a>
  6e329d:	call   *0x35f00d(%rip)        # a422b0 <_DYNAMIC+0x2c0>
  6e32a3:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e32a8:	lea    0x80(%rsp),%rsi
  6e32b0:	lea    0x33f8a9(%rip),%r9        # a22b60 <__frame_dummy_init_array_entry+0x1070>
  6e32b7:	jmp    6e3353 <text_column_public_control::main+0x3d13>
  6e32bc:	lea    0x9d0(%rsp),%r12
  6e32c4:	lea    0x33f7bd(%rip),%r9        # a22a88 <__frame_dummy_init_array_entry+0xf98>
  6e32cb:	jmp    6e342c <text_column_public_control::main+0x3dec>
  6e32d0:	movq   $0xd,0x260(%rsp)
  6e32dc:	movq   $0x0,0x268(%rsp)
  6e32e8:	lea    -0x695c10(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6e32ef:	lea    0x33fa32(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6e32f6:	lea    0x33f3bb(%rip),%r8        # a226b8 <__frame_dummy_init_array_entry+0xbc8>
  6e32fd:	lea    0x260(%rsp),%rdx
  6e3305:	mov    $0x2b,%esi
  6e330a:	call   *0x35ef20(%rip)        # a42230 <_DYNAMIC+0x240>
  6e3310:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3315:	lea    0x88(%rsp),%rsi
  6e331d:	lea    0x33f854(%rip),%r9        # a22b78 <__frame_dummy_init_array_entry+0x1088>
  6e3324:	mov    %r14,%rbx
  6e3327:	jmp    6e3353 <text_column_public_control::main+0x3d13>
  6e3329:	add    $0x2b0,%rsi
  6e3330:	lea    0x33f4b9(%rip),%r9        # a227f0 <__frame_dummy_init_array_entry+0xd00>
  6e3337:	jmp    6e33f6 <text_column_public_control::main+0x3db6>
  6e333c:	lea    0xc70(%rsp),%rsi
  6e3344:	lea    0xc78(%rsp),%rbx
  6e334c:	lea    0x33f855(%rip),%r9        # a22ba8 <__frame_dummy_init_array_entry+0x10b8>
  6e3353:	xor    %edi,%edi
  6e3355:	mov    %rbx,%rdx
  6e3358:	xor    %ecx,%ecx
  6e335a:	call   *0x35f208(%rip)        # a42568 <_DYNAMIC+0x578>
  6e3360:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3365:	lea    -0x695d26(%rip),%rdi        # 4d646 <GCC_except_table0+0xd8a2>
  6e336c:	lea    0x33f84d(%rip),%rdx        # a22bc0 <__frame_dummy_init_array_entry+0x10d0>
  6e3373:	mov    $0x2d,%esi
  6e3378:	call   *0x35ef32(%rip)        # a422b0 <_DYNAMIC+0x2c0>
  6e337e:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3383:	lea    0x33f44e(%rip),%rdx        # a227d8 <__frame_dummy_init_array_entry+0xce8>
  6e338a:	lea    -0x6a22c1(%rip),%r12        # 410d0 <GCC_except_table0+0x132c>
  6e3391:	mov    0x20(%rsp),%rdi
  6e3396:	mov    %r12,%rsi
  6e3399:	call   6c85ab <core::panicking::assert_failed::<core::option::Option<gpui::identity::Target>, core::option::Option<gpui::identity::Target>>>
  6e339e:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e33a3:	movq   $0xd,0x260(%rsp)
  6e33af:	movq   $0x0,0x268(%rsp)
  6e33bb:	lea    -0x695ce3(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6e33c2:	lea    0x33f95f(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6e33c9:	lea    0x33f330(%rip),%r8        # a22700 <__frame_dummy_init_array_entry+0xc10>
  6e33d0:	lea    0x260(%rsp),%rdx
  6e33d8:	mov    $0x2b,%esi
  6e33dd:	call   *0x35ee4d(%rip)        # a42230 <_DYNAMIC+0x240>
  6e33e3:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e33e8:	add    $0x2b0,%rsi
  6e33ef:	lea    0x33f382(%rip),%r9        # a22778 <__frame_dummy_init_array_entry+0xc88>
  6e33f6:	lea    -0x6a1c2d(%rip),%rdx        # 417d0 <GCC_except_table0+0x1a2c>
  6e33fd:	xor    %edi,%edi
  6e33ff:	xor    %ecx,%ecx
  6e3401:	call   *0x35f0c1(%rip)        # a424c8 <_DYNAMIC+0x4d8>
  6e3407:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e340c:	lea    0x9c8(%rsp),%r12
  6e3414:	lea    0x33f69d(%rip),%r9        # a22ab8 <__frame_dummy_init_array_entry+0xfc8>
  6e341b:	jmp    6e342c <text_column_public_control::main+0x3dec>
  6e341d:	lea    0x33f67c(%rip),%r9        # a22aa0 <__frame_dummy_init_array_entry+0xfb0>
  6e3424:	lea    0x9c0(%rsp),%r12
  6e342c:	xor    %edi,%edi
  6e342e:	mov    %r12,%rsi
  6e3431:	xor    %ecx,%ecx
  6e3433:	call   *0x35f12f(%rip)        # a42568 <_DYNAMIC+0x578>
  6e3439:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e343e:	lea    0x33f303(%rip),%rsi        # a22748 <__frame_dummy_init_array_entry+0xc58>
  6e3445:	lea    0x260(%rsp),%rdi
  6e344d:	call   6c8614 <core::panicking::assert_failed::<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>, core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>>
  6e3452:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3457:	lea    -0x6931fc(%rip),%rdi        # 50262 <GCC_except_table0+0x104be>
  6e345e:	lea    0x34018b(%rip),%rdx        # a235f0 <__frame_dummy_init_array_entry+0x1b00>
  6e3465:	mov    $0x83,%esi
  6e346a:	call   *0x35ee20(%rip)        # a42290 <_DYNAMIC+0x2a0>
  6e3470:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3475:	movq   $0x19,0x70(%rsp)
  6e347e:	mov    0xa0(%rsp),%rax
  6e3486:	mov    %rax,0x290(%rsp)
  6e348e:	movaps 0x70(%rsp),%xmm0
  6e3493:	movaps 0x80(%rsp),%xmm1
  6e349b:	movaps 0x90(%rsp),%xmm2
  6e34a3:	movaps %xmm2,0x280(%rsp)
  6e34ab:	movaps %xmm1,0x270(%rsp)
  6e34b3:	movaps %xmm0,0x260(%rsp)
  6e34bb:	lea    -0x695de3(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6e34c2:	lea    0x33f85f(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6e34c9:	lea    0x33f188(%rip),%r8        # a22658 <__frame_dummy_init_array_entry+0xb68>
  6e34d0:	lea    0x260(%rsp),%rdx
  6e34d8:	mov    $0x2b,%esi
  6e34dd:	call   *0x35ed4d(%rip)        # a42230 <_DYNAMIC+0x240>
  6e34e3:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e34e8:	movq   $0x11,0x9c0(%rsp)
  6e34f4:	mov    0x9f0(%rsp),%rax
  6e34fc:	mov    %rax,0x290(%rsp)
  6e3504:	mov    0x9c0(%rsp),%rax
  6e350c:	mov    0x9c8(%rsp),%rcx
  6e3514:	movups 0x9d0(%rsp),%xmm0
  6e351c:	movups 0x9e0(%rsp),%xmm1
  6e3524:	movaps %xmm1,0x280(%rsp)
  6e352c:	movaps %xmm0,0x270(%rsp)
  6e3534:	mov    %rax,0x260(%rsp)
  6e353c:	mov    %rcx,0x268(%rsp)
  6e3544:	lea    -0x695e6c(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6e354b:	lea    0x33f7d6(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6e3552:	lea    0x33f147(%rip),%r8        # a226a0 <__frame_dummy_init_array_entry+0xbb0>
  6e3559:	lea    0x260(%rsp),%rdx
  6e3561:	mov    $0x2b,%esi
  6e3566:	call   *0x35ecc4(%rip)        # a42230 <_DYNAMIC+0x240>
  6e356c:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3571:	mov    0x9c8(%rsp),%r14
  6e3579:	mov    0x9d8(%rsp),%rcx
  6e3581:	mov    %rcx,%rax
  6e3584:	sub    %r14,%rax
  6e3587:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  6e3591:	mul    %rdx
  6e3594:	movq   $0x0,0x210(%rsp)
  6e35a0:	movq   $0x8,0x218(%rsp)
  6e35ac:	movq   $0x0,0x220(%rsp)
  6e35b8:	cmp    %r14,%rcx
  6e35bb:	jne    6e3655 <text_column_public_control::main+0x4015>
  6e35c1:	mov    0x9d0(%rsp),%rax
  6e35c9:	test   %rax,%rax
  6e35cc:	je     6e35e9 <text_column_public_control::main+0x3fa9>
  6e35ce:	mov    0x9c0(%rsp),%rdi
  6e35d6:	shl    $0x3,%rax
  6e35da:	lea    (%rax,%rax,2),%rsi
  6e35de:	mov    $0x8,%edx
  6e35e3:	call   *0x35ec6f(%rip)        # a42258 <_DYNAMIC+0x268>
  6e35e9:	lea    0x33f378(%rip),%rdx        # a22968 <__frame_dummy_init_array_entry+0xe78>
  6e35f0:	mov    $0x65,%esi
  6e35f5:	lea    -0x6960a7(%rip),%rdi        # 4d555 <GCC_except_table0+0xd7b1>
  6e35fc:	call   *0x35ec8e(%rip)        # a42290 <_DYNAMIC+0x2a0>
  6e3602:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3607:	movq   $0x12,0x9c0(%rsp)
  6e3613:	jmp    6e34f4 <text_column_public_control::main+0x3eb4>
  6e3618:	lea    -0x6933bd(%rip),%rdi        # 50262 <GCC_except_table0+0x104be>
  6e361f:	lea    0x33ffca(%rip),%rdx        # a235f0 <__frame_dummy_init_array_entry+0x1b00>
  6e3626:	mov    $0x83,%esi
  6e362b:	call   *0x35ec5f(%rip)        # a42290 <_DYNAMIC+0x2a0>
  6e3631:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3636:	movq   $0x19,0x9c0(%rsp)
  6e3642:	jmp    6e34f4 <text_column_public_control::main+0x3eb4>
  6e3647:	movq   $0x12,0x70(%rsp)
  6e3650:	jmp    6e347e <text_column_public_control::main+0x3e3e>
  6e3655:	mov    %rdx,%rbx
  6e3658:	shr    $0x4,%rbx
  6e365c:	add    $0x8,%r14
  6e3660:	mov    0x35ebf1(%rip),%r15        # a42258 <_DYNAMIC+0x268>
  6e3667:	jmp    6e367d <text_column_public_control::main+0x403d>
  6e3669:	nopl   0x0(%rax)
  6e3670:	add    $0x18,%r14
  6e3674:	dec    %rbx
  6e3677:	je     6e35c1 <text_column_public_control::main+0x3f81>
  6e367d:	mov    -0x8(%r14),%rsi
  6e3681:	test   %rsi,%rsi
  6e3684:	je     6e3670 <text_column_public_control::main+0x4030>
  6e3686:	mov    (%r14),%rdi
  6e3689:	mov    $0x1,%edx
  6e368e:	call   *%r15
  6e3691:	jmp    6e3670 <text_column_public_control::main+0x4030>
  6e3693:	mov    0x118(%rsp),%r15
  6e369b:	movups 0x120(%rsp),%xmm0
  6e36a3:	movaps %xmm0,0x10(%rsp)
  6e36a8:	movups 0x130(%rsp),%xmm0
  6e36b0:	movaps %xmm0,0x20(%rsp)
  6e36b5:	movzbl 0x140(%rsp),%ebx
  6e36bd:	mov    0x141(%rsp),%eax
  6e36c4:	mov    %eax,0x190(%rsp)
  6e36cb:	mov    0x144(%rsp),%eax
  6e36d2:	mov    %eax,0x193(%rsp)
  6e36d9:	mov    0x1e0(%rsp),%r14
  6e36e1:	test   %r14,%r14
  6e36e4:	je     6e3701 <text_column_public_control::main+0x40c1>
  6e36e6:	mov    %r14,%rdi
  6e36e9:	call   6bfb20 <core::ptr::drop_glue::<gpui::runtime::Runtime<text_column_public_control::Input>>>
  6e36ee:	mov    $0x750,%esi
  6e36f3:	mov    $0x8,%edx
  6e36f8:	mov    %r14,%rdi
  6e36fb:	call   *0x35eb57(%rip)        # a42258 <_DYNAMIC+0x268>
  6e3701:	mov    %r15,%r13
  6e3704:	shr    $0x20,%r13
  6e3708:	jmp    6e3d96 <text_column_public_control::main+0x4756>
  6e370d:	mov    $0x1b,%eax
  6e3712:	test   %rcx,%rcx
  6e3715:	jne    6e3915 <text_column_public_control::main+0x42d5>
  6e371b:	mov    $0x1a,%eax
  6e3720:	jmp    6e3915 <text_column_public_control::main+0x42d5>
  6e3725:	lea    0x33f284(%rip),%rdx        # a229b0 <__frame_dummy_init_array_entry+0xec0>
  6e372c:	jmp    6e373e <text_column_public_control::main+0x40fe>
  6e372e:	lea    0x33f293(%rip),%rdx        # a229c8 <__frame_dummy_init_array_entry+0xed8>
  6e3735:	jmp    6e374c <text_column_public_control::main+0x410c>
  6e3737:	lea    0x33f242(%rip),%rdx        # a22980 <__frame_dummy_init_array_entry+0xe90>
  6e373e:	mov    $0x2,%edi
  6e3743:	jmp    6e3751 <text_column_public_control::main+0x4111>
  6e3745:	lea    0x33f24c(%rip),%rdx        # a22998 <__frame_dummy_init_array_entry+0xea8>
  6e374c:	mov    $0x3,%edi
  6e3751:	mov    %rdi,%rsi
  6e3754:	call   *0x35eb2e(%rip)        # a42288 <_DYNAMIC+0x298>
  6e375a:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e375f:	movq   $0xd,0x260(%rsp)
  6e376b:	movq   $0x0,0x268(%rsp)
  6e3777:	lea    -0x69609f(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6e377e:	lea    0x33f5a3(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6e3785:	lea    0x33f26c(%rip),%r8        # a229f8 <__frame_dummy_init_array_entry+0xf08>
  6e378c:	lea    0x260(%rsp),%rdx
  6e3794:	mov    $0x2b,%esi
  6e3799:	call   *0x35ea91(%rip)        # a42230 <_DYNAMIC+0x240>
  6e379f:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e37a4:	mov    $0x1,%edi
  6e37a9:	mov    $0x13,%esi
  6e37ae:	call   *0x35eb34(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  6e37b4:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e37b9:	mov    0x268(%rsp),%r15
  6e37c1:	mov    %r15,%r13
  6e37c4:	shr    $0x20,%r13
  6e37c8:	movups 0x270(%rsp),%xmm0
  6e37d0:	movaps %xmm0,0x10(%rsp)
  6e37d5:	movups 0x280(%rsp),%xmm0
  6e37dd:	movaps %xmm0,0x20(%rsp)
  6e37e2:	movzbl 0x290(%rsp),%ebx
  6e37ea:	mov    0x291(%rsp),%eax
  6e37f1:	mov    %eax,0x190(%rsp)
  6e37f8:	mov    0x294(%rsp),%eax
  6e37ff:	mov    %eax,0x193(%rsp)
  6e3806:	jmp    6e38b4 <text_column_public_control::main+0x4274>
  6e380b:	movq   $0xd,0x260(%rsp)
  6e3817:	movq   $0x0,0x268(%rsp)
  6e3823:	lea    -0x69614b(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6e382a:	lea    0x33f4f7(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6e3831:	lea    0x33f2e0(%rip),%r8        # a22b18 <__frame_dummy_init_array_entry+0x1028>
  6e3838:	lea    0x260(%rsp),%rdx
  6e3840:	mov    $0x2b,%esi
  6e3845:	call   *0x35e9e5(%rip)        # a42230 <_DYNAMIC+0x240>
  6e384b:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3850:	mov    $0xd,%eax
  6e3855:	jmp    6e3863 <text_column_public_control::main+0x4223>
  6e3857:	mov    $0xe,%eax
  6e385c:	jmp    6e3863 <text_column_public_control::main+0x4223>
  6e385e:	mov    $0x14,%eax
  6e3863:	mov    %rax,0x260(%rsp)
  6e386b:	movq   $0x0,0x268(%rsp)
  6e3877:	lea    -0x69619f(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6e387e:	lea    0x33f4a3(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6e3885:	lea    0x33f2a4(%rip),%r8        # a22b30 <__frame_dummy_init_array_entry+0x1040>
  6e388c:	lea    0x260(%rsp),%rdx
  6e3894:	mov    $0x2b,%esi
  6e3899:	call   *0x35e991(%rip)        # a42230 <_DYNAMIC+0x240>
  6e389f:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e38a4:	lea    0x70(%rsp),%rdi
  6e38a9:	call   6bf910 <core::ptr::drop_glue::<gpui::source::Sources<text_column_public_control::Input>>>
  6e38ae:	mov    $0x23,%r12d
  6e38b4:	mov    $0x13,%esi
  6e38b9:	mov    $0x1,%edx
  6e38be:	mov    %r14,%rdi
  6e38c1:	call   *0x35e991(%rip)        # a42258 <_DYNAMIC+0x268>
  6e38c7:	jmp    6e3d96 <text_column_public_control::main+0x4756>
  6e38cc:	movq   $0xd,0x260(%rsp)
  6e38d8:	movq   $0x0,0x268(%rsp)
  6e38e4:	lea    -0x6962fc(%rip),%rdi        # 4d5ef <GCC_except_table0+0xd84b>
  6e38eb:	lea    0x33f436(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6e38f2:	lea    0x33f177(%rip),%r8        # a22a70 <__frame_dummy_init_array_entry+0xf80>
  6e38f9:	mov    $0x24,%esi
  6e38fe:	call   *0x35e92c(%rip)        # a42230 <_DYNAMIC+0x240>
  6e3904:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3909:	mov    $0xd,%eax
  6e390e:	jmp    6e3915 <text_column_public_control::main+0x42d5>
  6e3910:	mov    $0xe,%eax
  6e3915:	mov    %rax,0x260(%rsp)
  6e391d:	mov    0x10(%rsp),%rax
  6e3922:	mov    %rax,0x268(%rsp)
  6e392a:	lea    -0x696252(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6e3931:	lea    0x33f3f0(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6e3938:	lea    0x33ed49(%rip),%r8        # a22688 <__frame_dummy_init_array_entry+0xb98>
  6e393f:	lea    0x260(%rsp),%rdx
  6e3947:	mov    $0x2b,%esi
  6e394c:	call   *0x35e8de(%rip)        # a42230 <_DYNAMIC+0x240>
  6e3952:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3957:	movq   $0xd,0x9c0(%rsp)
  6e3963:	movq   $0x0,0x9c8(%rsp)
  6e396f:	jmp    6e34f4 <text_column_public_control::main+0x3eb4>
  6e3974:	movq   $0xe,0x9c0(%rsp)
  6e3980:	jmp    6e34f4 <text_column_public_control::main+0x3eb4>
  6e3985:	mov    $0x11,%eax
  6e398a:	jmp    6e39c4 <text_column_public_control::main+0x4384>
  6e398c:	mov    0x268(%rsp),%rcx
  6e3994:	movups 0x270(%rsp),%xmm0
  6e399c:	movaps %xmm0,0xc60(%rsp)
  6e39a4:	movups 0x280(%rsp),%xmm0
  6e39ac:	movaps %xmm0,0xc70(%rsp)
  6e39b4:	mov    0x290(%rsp),%rdx
  6e39bc:	mov    %rdx,0xc80(%rsp)
  6e39c4:	mov    %rax,0x9c0(%rsp)
  6e39cc:	mov    %rcx,0x9c8(%rsp)
  6e39d4:	movaps 0xc60(%rsp),%xmm0
  6e39dc:	movaps 0xc70(%rsp),%xmm1
  6e39e4:	movups %xmm0,0x9d0(%rsp)
  6e39ec:	movups %xmm1,0x9e0(%rsp)
  6e39f4:	mov    0xc80(%rsp),%rax
  6e39fc:	mov    %rax,0x9f0(%rsp)
  6e3a04:	jmp    6e34f4 <text_column_public_control::main+0x3eb4>
  6e3a09:	mov    $0x11,%eax
  6e3a0e:	mov    0x290(%rsp),%rcx
  6e3a16:	mov    %rcx,0x9f0(%rsp)
  6e3a1e:	movups 0x270(%rsp),%xmm0
  6e3a26:	movups 0x280(%rsp),%xmm1
  6e3a2e:	movups %xmm1,0x9e0(%rsp)
  6e3a36:	movups %xmm0,0x9d0(%rsp)
  6e3a3e:	mov    %rax,0x9c0(%rsp)
  6e3a46:	mov    %r13,0x9c8(%rsp)
  6e3a4e:	jmp    6e34f4 <text_column_public_control::main+0x3eb4>
  6e3a53:	lea    0x33fbc6(%rip),%rax        # a23620 <__frame_dummy_init_array_entry+0x1b30>
  6e3a5a:	mov    %rax,0x40(%rsp)
  6e3a5f:	mov    %r13,%rdi
  6e3a62:	mov    0x40(%rsp),%rdx
  6e3a67:	call   *0x35e81b(%rip)        # a42288 <_DYNAMIC+0x298>
  6e3a6d:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3a72:	mov    $0xd,%eax
  6e3a77:	jmp    6e3a85 <text_column_public_control::main+0x4445>
  6e3a79:	mov    $0xe,%eax
  6e3a7e:	jmp    6e3a85 <text_column_public_control::main+0x4445>
  6e3a80:	mov    $0x14,%eax
  6e3a85:	mov    %rax,0x260(%rsp)
  6e3a8d:	movq   $0x0,0x268(%rsp)
  6e3a99:	lea    -0x6963c1(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6e3aa0:	lea    0x33f281(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6e3aa7:	lea    0x33ec6a(%rip),%r8        # a22718 <__frame_dummy_init_array_entry+0xc28>
  6e3aae:	lea    0x260(%rsp),%rdx
  6e3ab6:	mov    $0x2b,%esi
  6e3abb:	call   *0x35e76f(%rip)        # a42230 <_DYNAMIC+0x240>
  6e3ac1:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3ac6:	movq   $0xd,0x70(%rsp)
  6e3acf:	movq   $0x0,0x78(%rsp)
  6e3ad8:	jmp    6e347e <text_column_public_control::main+0x3e3e>
  6e3add:	movq   $0xe,0x70(%rsp)
  6e3ae6:	jmp    6e347e <text_column_public_control::main+0x3e3e>
  6e3aeb:	lea    0x33e81e(%rip),%rdi        # a22310 <__frame_dummy_init_array_entry+0x820>
  6e3af2:	call   *0x35e800(%rip)        # a422f8 <_DYNAMIC+0x308>
  6e3af8:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3afd:	lea    0x33f7ac(%rip),%rax        # a232b0 <__frame_dummy_init_array_entry+0x17c0>
  6e3b04:	jmp    6e3a5a <text_column_public_control::main+0x441a>
  6e3b09:	lea    0x33f698(%rip),%rdx        # a231a8 <__frame_dummy_init_array_entry+0x16b8>
  6e3b10:	call   *0x35e772(%rip)        # a42288 <_DYNAMIC+0x298>
  6e3b16:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3b1b:	lea    0x33f6b6(%rip),%rax        # a231d8 <__frame_dummy_init_array_entry+0x16e8>
  6e3b22:	mov    %rax,0xd8(%rsp)
  6e3b2a:	mov    0xd8(%rsp),%rdx
  6e3b32:	call   *0x35e750(%rip)        # a42288 <_DYNAMIC+0x298>
  6e3b38:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3b3d:	lea    0x33f67c(%rip),%rdi        # a231c0 <__frame_dummy_init_array_entry+0x16d0>
  6e3b44:	call   *0x35e7ae(%rip)        # a422f8 <_DYNAMIC+0x308>
  6e3b4a:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3b4f:	lea    0x33f69a(%rip),%rdi        # a231f0 <__frame_dummy_init_array_entry+0x1700>
  6e3b56:	call   *0x35e79c(%rip)        # a422f8 <_DYNAMIC+0x308>
  6e3b5c:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3b61:	jmp    6e3d09 <text_column_public_control::main+0x46c9>
  6e3b66:	jmp    6e3c83 <text_column_public_control::main+0x4643>
  6e3b6b:	mov    %rax,%rbx
  6e3b6e:	lea    0x260(%rsp),%rdi
  6e3b76:	call   6bf8a0 <core::ptr::drop_glue::<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>>
  6e3b7b:	jmp    6e3b86 <text_column_public_control::main+0x4546>
  6e3b7d:	jmp    6e3b83 <text_column_public_control::main+0x4543>
  6e3b7f:	jmp    6e3b83 <text_column_public_control::main+0x4543>
  6e3b81:	ud2
  6e3b83:	mov    %rax,%rbx
  6e3b86:	mov    0xe0(%rsp),%rax
  6e3b8e:	test   %rax,%rax
  6e3b91:	je     6e3ebc <text_column_public_control::main+0x487c>
  6e3b97:	mov    0xe8(%rsp),%rdi
  6e3b9f:	shl    $0x3,%rax
  6e3ba3:	lea    (%rax,%rax,2),%rsi
  6e3ba7:	mov    $0x8,%edx
  6e3bac:	call   *0x35e6a6(%rip)        # a42258 <_DYNAMIC+0x268>
  6e3bb2:	jmp    6e3ebc <text_column_public_control::main+0x487c>
  6e3bb7:	mov    %rax,%rbx
  6e3bba:	jmp    6e3ed2 <text_column_public_control::main+0x4892>
  6e3bbf:	mov    %rax,%rbx
  6e3bc2:	jmp    6e3ed2 <text_column_public_control::main+0x4892>
  6e3bc7:	jmp    6e4a00 <text_column_public_control::main+0x53c0>
  6e3bcc:	jmp    6e3c0d <text_column_public_control::main+0x45cd>
  6e3bce:	mov    %rax,%rbx
  6e3bd1:	jmp    6e3c4f <text_column_public_control::main+0x460f>
  6e3bd3:	mov    %rax,%rbx
  6e3bd6:	lea    0x33e163(%rip),%rsi        # a21d40 <__frame_dummy_init_array_entry+0x250>
  6e3bdd:	mov    %r15,%rdi
  6e3be0:	call   6c1a60 <core::ptr::drop_glue::<alloc::boxed::Box<dyn for<'a, 'b> core::ops::function::Fn<(&'a mut gpui::element::El<'b>,), Output = ()>>>>
  6e3be5:	jmp    6e3d3c <text_column_public_control::main+0x46fc>
  6e3bea:	call   *0x35e690(%rip)        # a42280 <_DYNAMIC+0x290>
  6e3bf0:	jmp    6e3c69 <text_column_public_control::main+0x4629>
  6e3bf2:	mov    %rax,%rbx
  6e3bf5:	lea    0x260(%rsp),%rdi
  6e3bfd:	call   6bf910 <core::ptr::drop_glue::<gpui::source::Sources<text_column_public_control::Input>>>
  6e3c02:	jmp    6e3d49 <text_column_public_control::main+0x4709>
  6e3c07:	call   *0x35e673(%rip)        # a42280 <_DYNAMIC+0x290>
  6e3c0d:	mov    %rax,%rbx
  6e3c10:	lea    0x260(%rsp),%rdi
  6e3c18:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e3c1d:	jmp    6e3e9a <text_column_public_control::main+0x485a>
  6e3c22:	mov    %rax,%rbx
  6e3c25:	jmp    6e3e37 <text_column_public_control::main+0x47f7>
  6e3c2a:	mov    %rax,%rbx
  6e3c2d:	mov    0x1e0(%rsp),%rdi
  6e3c35:	call   6bfa60 <core::ptr::drop_glue::<gpui::runtime::Win<text_column_public_control::Input>>>
  6e3c3a:	jmp    6e4a87 <text_column_public_control::main+0x5447>
  6e3c3f:	mov    %rax,%rbx
  6e3c42:	lea    0xc60(%rsp),%rdi
  6e3c4a:	call   6c6030 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  6e3c4f:	lea    0x70(%rsp),%rdi
  6e3c54:	call   6bf910 <core::ptr::drop_glue::<gpui::source::Sources<text_column_public_control::Input>>>
  6e3c59:	jmp    6e3e37 <text_column_public_control::main+0x47f7>
  6e3c5e:	call   *0x35e61c(%rip)        # a42280 <_DYNAMIC+0x290>
  6e3c64:	jmp    6e3d09 <text_column_public_control::main+0x46c9>
  6e3c69:	mov    %rax,%rbx
  6e3c6c:	lea    0x260(%rsp),%rdi
  6e3c74:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e3c79:	jmp    6e4a59 <text_column_public_control::main+0x5419>
  6e3c7e:	jmp    6e3eb9 <text_column_public_control::main+0x4879>
  6e3c83:	mov    %rax,%rbx
  6e3c86:	lea    0xc60(%rsp),%rdi
  6e3c8e:	call   6bf8a0 <core::ptr::drop_glue::<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>>
  6e3c93:	jmp    6e3ebc <text_column_public_control::main+0x487c>
  6e3c98:	mov    %rax,%rbx
  6e3c9b:	jmp    6e3f2c <text_column_public_control::main+0x48ec>
  6e3ca0:	jmp    6e3d09 <text_column_public_control::main+0x46c9>
  6e3ca2:	jmp    6e3eb9 <text_column_public_control::main+0x4879>
  6e3ca7:	jmp    6e3eb9 <text_column_public_control::main+0x4879>
  6e3cac:	jmp    6e3d09 <text_column_public_control::main+0x46c9>
  6e3cae:	mov    %rax,%rbx
  6e3cb1:	test   %rbp,%rbp
  6e3cb4:	je     6e3cd3 <text_column_public_control::main+0x4693>
  6e3cb6:	mov    $0x1,%edx
  6e3cbb:	mov    %r13,%rdi
  6e3cbe:	mov    %rbp,%rsi
  6e3cc1:	call   *0x35e591(%rip)        # a42258 <_DYNAMIC+0x268>
  6e3cc7:	jmp    6e3cd3 <text_column_public_control::main+0x4693>
  6e3cc9:	jmp    6e3d09 <text_column_public_control::main+0x46c9>
  6e3ccb:	jmp    6e3e97 <text_column_public_control::main+0x4857>
  6e3cd0:	mov    %rax,%rbx
  6e3cd3:	lea    0x260(%rsp),%rdi
  6e3cdb:	call   6c4e90 <core::ptr::drop_glue::<std::env::Args>>
  6e3ce0:	lea    0x70(%rsp),%rdi
  6e3ce5:	call   6c0da0 <core::ptr::drop_glue::<alloc::vec::Vec<alloc::string::String>>>
  6e3cea:	mov    %rbx,%rdi
  6e3ced:	call   a20740 <_Unwind_Resume@plt>
  6e3cf2:	mov    %rax,%rbx
  6e3cf5:	lea    0x260(%rsp),%rdi
  6e3cfd:	call   6bf8a0 <core::ptr::drop_glue::<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>>
  6e3d02:	jmp    6e3ebc <text_column_public_control::main+0x487c>
  6e3d07:	jmp    6e3d09 <text_column_public_control::main+0x46c9>
  6e3d09:	mov    %rax,%rbx
  6e3d0c:	lea    0x260(%rsp),%rdi
  6e3d14:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e3d19:	jmp    6e3ebc <text_column_public_control::main+0x487c>
  6e3d1e:	mov    %rax,%rbx
  6e3d21:	lea    0x260(%rsp),%rdi
  6e3d29:	call   6bfb20 <core::ptr::drop_glue::<gpui::runtime::Runtime<text_column_public_control::Input>>>
  6e3d2e:	jmp    6e4a87 <text_column_public_control::main+0x5447>
  6e3d33:	call   *0x35e547(%rip)        # a42280 <_DYNAMIC+0x290>
  6e3d39:	mov    %rax,%rbx
  6e3d3c:	lea    0x260(%rsp),%rdi
  6e3d44:	call   6bf910 <core::ptr::drop_glue::<gpui::source::Sources<text_column_public_control::Input>>>
  6e3d49:	mov    %rbx,%rdi
  6e3d4c:	call   *0x35e77e(%rip)        # a424d0 <_DYNAMIC+0x4e0>
  6e3d52:	mov    %rax,%r15
  6e3d55:	mov    %rdx,%r12
  6e3d58:	mov    (%rdx),%rax
  6e3d5b:	test   %rax,%rax
  6e3d5e:	je     6e3d65 <text_column_public_control::main+0x4725>
  6e3d60:	mov    %r15,%rdi
  6e3d63:	call   *%rax
  6e3d65:	mov    0x8(%r12),%rsi
  6e3d6a:	test   %rsi,%rsi
  6e3d6d:	je     6e3d7d <text_column_public_control::main+0x473d>
  6e3d6f:	mov    0x10(%r12),%rdx
  6e3d74:	mov    %r15,%rdi
  6e3d77:	call   *0x35e4db(%rip)        # a42258 <_DYNAMIC+0x268>
  6e3d7d:	mov    $0x13,%esi
  6e3d82:	mov    $0x1,%edx
  6e3d87:	mov    %r14,%rdi
  6e3d8a:	call   *0x35e4c8(%rip)        # a42258 <_DYNAMIC+0x268>
  6e3d90:	mov    $0xf,%r12d
  6e3d96:	mov    %r12,0x9c0(%rsp)
  6e3d9e:	shl    $0x20,%r13
  6e3da2:	mov    %r15d,%eax
  6e3da5:	or     %r13,%rax
  6e3da8:	mov    %rax,0x9c8(%rsp)
  6e3db0:	movaps 0x10(%rsp),%xmm0
  6e3db5:	movups %xmm0,0x9d0(%rsp)
  6e3dbd:	movdqa 0x20(%rsp),%xmm0
  6e3dc3:	movdqu %xmm0,0x9e0(%rsp)
  6e3dcc:	mov    %bl,0x9f0(%rsp)
  6e3dd3:	mov    0x190(%rsp),%eax
  6e3dda:	mov    0x193(%rsp),%ecx
  6e3de1:	mov    %eax,0x9f1(%rsp)
  6e3de8:	mov    %ecx,0x9f4(%rsp)
  6e3def:	lea    -0x696717(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6e3df6:	lea    0x33ef2b(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6e3dfd:	lea    0x33e86c(%rip),%r8        # a22670 <__frame_dummy_init_array_entry+0xb80>
  6e3e04:	lea    0x9c0(%rsp),%rdx
  6e3e0c:	mov    $0x2b,%esi
  6e3e11:	call   *0x35e419(%rip)        # a42230 <_DYNAMIC+0x240>
  6e3e17:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e3e1c:	mov    %rax,%rbx
  6e3e1f:	mov    0x8(%r12),%rsi
  6e3e24:	test   %rsi,%rsi
  6e3e27:	je     6e3e37 <text_column_public_control::main+0x47f7>
  6e3e29:	mov    0x10(%r12),%rdx
  6e3e2e:	mov    %r15,%rdi
  6e3e31:	call   *0x35e421(%rip)        # a42258 <_DYNAMIC+0x268>
  6e3e37:	mov    $0x13,%esi
  6e3e3c:	mov    $0x1,%edx
  6e3e41:	jmp    6e3edc <text_column_public_control::main+0x489c>
  6e3e46:	mov    %rax,%rbx
  6e3e49:	lea    0x9c0(%rsp),%rdi
  6e3e51:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e3e56:	lea    0x210(%rsp),%rdi
  6e3e5e:	call   6c0da0 <core::ptr::drop_glue::<alloc::vec::Vec<alloc::string::String>>>
  6e3e63:	mov    %rbx,%rdi
  6e3e66:	call   a20740 <_Unwind_Resume@plt>
  6e3e6b:	call   *0x35e667(%rip)        # a424d8 <_DYNAMIC+0x4e8>
  6e3e71:	call   *0x35e409(%rip)        # a42280 <_DYNAMIC+0x290>
  6e3e77:	mov    %rax,%rbx
  6e3e7a:	jmp    6e4a7d <text_column_public_control::main+0x543d>
  6e3e7f:	mov    %rax,%rbx
  6e3e82:	lea    0x210(%rsp),%rdi
  6e3e8a:	call   6c0da0 <core::ptr::drop_glue::<alloc::vec::Vec<alloc::string::String>>>
  6e3e8f:	mov    %rbx,%rdi
  6e3e92:	call   a20740 <_Unwind_Resume@plt>
  6e3e97:	mov    %rax,%rbx
  6e3e9a:	mov    0x30(%rsp),%rdi
  6e3e9f:	call   6bfac0 <core::ptr::drop_glue::<gpui::runtime::Win<text_column_public_control::Model>>>
  6e3ea4:	jmp    6e4a87 <text_column_public_control::main+0x5447>
  6e3ea9:	call   *0x35e3d1(%rip)        # a42280 <_DYNAMIC+0x290>
  6e3eaf:	mov    %rax,%rbx
  6e3eb2:	jmp    6e4a59 <text_column_public_control::main+0x5419>
  6e3eb7:	jmp    6e3eb9 <text_column_public_control::main+0x4879>
  6e3eb9:	mov    %rax,%rbx
  6e3ebc:	mov    0x30(%rsp),%r14
  6e3ec1:	test   %r14,%r14
  6e3ec4:	je     6e4a87 <text_column_public_control::main+0x5447>
  6e3eca:	mov    %r14,%rdi
  6e3ecd:	call   6bfb20 <core::ptr::drop_glue::<gpui::runtime::Runtime<text_column_public_control::Input>>>
  6e3ed2:	mov    $0x750,%esi
  6e3ed7:	mov    $0x8,%edx
  6e3edc:	mov    %r14,%rdi
  6e3edf:	call   *0x35e373(%rip)        # a42258 <_DYNAMIC+0x268>
  6e3ee5:	lea    0x210(%rsp),%rdi
  6e3eed:	call   6c0da0 <core::ptr::drop_glue::<alloc::vec::Vec<alloc::string::String>>>
  6e3ef2:	mov    %rbx,%rdi
  6e3ef5:	call   a20740 <_Unwind_Resume@plt>
  6e3efa:	mov    $0x750,%esi
  6e3eff:	mov    $0x8,%edx
  6e3f04:	mov    %r14,%rdi
  6e3f07:	call   *0x35e34b(%rip)        # a42258 <_DYNAMIC+0x268>
  6e3f0d:	call   *0x35e36d(%rip)        # a42280 <_DYNAMIC+0x290>
  6e3f13:	mov    %rax,%rbx
  6e3f16:	test   %r14,%r14
  6e3f19:	je     6e3f2c <text_column_public_control::main+0x48ec>
  6e3f1b:	mov    $0x1,%edx
  6e3f20:	mov    %r15,%rdi
  6e3f23:	mov    %r14,%rsi
  6e3f26:	call   *0x35e32c(%rip)        # a42258 <_DYNAMIC+0x268>
  6e3f2c:	mov    0x9c8(%rsp),%r15
  6e3f34:	mov    0x9d8(%rsp),%rcx
  6e3f3c:	mov    %rcx,%rax
  6e3f3f:	sub    %r15,%rax
  6e3f42:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  6e3f4c:	mul    %rdx
  6e3f4f:	cmp    %r15,%rcx
  6e3f52:	jne    6e3f69 <text_column_public_control::main+0x4929>
  6e3f54:	mov    0x9d0(%rsp),%rax
  6e3f5c:	test   %rax,%rax
  6e3f5f:	jne    6e3f9f <text_column_public_control::main+0x495f>
  6e3f61:	mov    %rbx,%rdi
  6e3f64:	call   a20740 <_Unwind_Resume@plt>
  6e3f69:	mov    %rdx,%r14
  6e3f6c:	shr    $0x4,%r14
  6e3f70:	add    $0x8,%r15
  6e3f74:	mov    0x35e2dd(%rip),%r12        # a42258 <_DYNAMIC+0x268>
  6e3f7b:	jmp    6e3f89 <text_column_public_control::main+0x4949>
  6e3f7d:	nopl   (%rax)
  6e3f80:	add    $0x18,%r15
  6e3f84:	dec    %r14
  6e3f87:	je     6e3f54 <text_column_public_control::main+0x4914>
  6e3f89:	mov    -0x8(%r15),%rsi
  6e3f8d:	test   %rsi,%rsi
  6e3f90:	je     6e3f80 <text_column_public_control::main+0x4940>
  6e3f92:	mov    (%r15),%rdi
  6e3f95:	mov    $0x1,%edx
  6e3f9a:	call   *%r12
  6e3f9d:	jmp    6e3f80 <text_column_public_control::main+0x4940>
  6e3f9f:	mov    0x9c0(%rsp),%rdi
  6e3fa7:	shl    $0x3,%rax
  6e3fab:	lea    (%rax,%rax,2),%rsi
  6e3faf:	mov    $0x8,%edx
  6e3fb4:	call   *0x35e29e(%rip)        # a42258 <_DYNAMIC+0x268>
  6e3fba:	mov    %rbx,%rdi
  6e3fbd:	call   a20740 <_Unwind_Resume@plt>
  6e3fc2:	mov    0x0(%r13,%rcx,8),%rdx
  6e3fc7:	xor    %esi,%esi
  6e3fc9:	cmp    (%r14,%rcx,8),%rdx
  6e3fcd:	lea    0x1(%rcx),%rcx
  6e3fd1:	sete   %sil
  6e3fd5:	add    %rsi,%rbx
  6e3fd8:	cmp    %rcx,%rax
  6e3fdb:	jne    6e3fc2 <text_column_public_control::main+0x4982>
  6e3fdd:	mov    %rbx,0x248(%rsp)
  6e3fe5:	lea    -0x6a24d8(%rip),%rax        # 41b14 <GCC_except_table0+0x1d70>
  6e3fec:	movslq (%rax,%r15,4),%rcx
  6e3ff0:	add    %rax,%rcx
  6e3ff3:	jmp    *%rcx
  6e3ff5:	cmp    0x50(%rsp),%rdi
  6e3ffa:	jne    6e4863 <text_column_public_control::main+0x5223>
  6e4000:	lea    0x0(,%rdi,8),%rdx
  6e4008:	mov    %rdi,%r12
  6e400b:	mov    %r13,%rdi
  6e400e:	mov    %r14,%rsi
  6e4011:	call   *0x35e559(%rip)        # a42570 <bcmp@GLIBC_2.2.5>
  6e4017:	test   %eax,%eax
  6e4019:	jne    6e4863 <text_column_public_control::main+0x5223>
  6e401f:	mov    %r12,%rdi
  6e4022:	cmpb   $0x4,0x20(%rsp)
  6e4027:	je     6e4041 <text_column_public_control::main+0x4a01>
  6e4029:	cmp    $0x5,%r15d
  6e402d:	je     6e4037 <text_column_public_control::main+0x49f7>
  6e402f:	cmp    $0x6,%r15d
  6e4033:	je     6e406f <text_column_public_control::main+0x4a2f>
  6e4035:	jmp    6e407e <text_column_public_control::main+0x4a3e>
  6e4037:	test   %rbx,%rbx
  6e403a:	je     6e407e <text_column_public_control::main+0x4a3e>
  6e403c:	jmp    6e48db <text_column_public_control::main+0x529b>
  6e4041:	movq   $0x7fff,0x260(%rsp)
  6e404d:	cmp    $0x7fff,%rbx
  6e4054:	je     6e407e <text_column_public_control::main+0x4a3e>
  6e4056:	lea    0x33ebab(%rip),%r9        # a22c08 <__frame_dummy_init_array_entry+0x1118>
  6e405d:	lea    0x260(%rsp),%rdx
  6e4065:	jmp    6e48e9 <text_column_public_control::main+0x52a9>
  6e406a:	test   %bpl,%bpl
  6e406d:	je     6e3ff5 <text_column_public_control::main+0x49b5>
  6e406f:	test   %rbx,%rbx
  6e4072:	setne  %al
  6e4075:	test   %al,%bpl
  6e4078:	jne    6e48db <text_column_public_control::main+0x529b>
  6e407e:	mov    %rdi,0x60(%rsp)
  6e4083:	mov    0x8(%rsp),%rdi
  6e4088:	lea    -0x696a1c(%rip),%rcx        # 4d673 <GCC_except_table0+0xd8cf>
  6e408f:	mov    $0x6,%r8d
  6e4095:	mov    %r15d,%esi
  6e4098:	mov    0x10(%rsp),%edx
  6e409c:	call   6db9b0 <text_column_public_control::emit_state>
  6e40a1:	mov    0x8(%rsp),%rsi
  6e40a6:	lea    0x1e0(%rsp),%rdi
  6e40ae:	call   6b5ed0 <text_column_public_control::observe::<text_column_public_control::Model>>
  6e40b3:	lea    0x260(%rsp),%rdi
  6e40bb:	lea    0x8(%rsp),%rsi
  6e40c0:	mov    $0x1,%r8d
  6e40c6:	mov    %r15d,%edx
  6e40c9:	mov    0x10(%rsp),%ecx
  6e40cd:	call   6dd800 <text_column_public_control::edit>
  6e40d2:	mov    0x8(%rsp),%rsi
  6e40d7:	test   %rsi,%rsi
  6e40da:	je     6e4919 <text_column_public_control::main+0x52d9>
  6e40e0:	cmpb   $0x0,0x78e(%rsi)
  6e40e7:	jne    6e4920 <text_column_public_control::main+0x52e0>
  6e40ed:	mov    0x6f0(%rsi),%r12
  6e40f4:	test   %r12,%r12
  6e40f7:	je     6e4927 <text_column_public_control::main+0x52e7>
  6e40fd:	mov    0x6f8(%rsi),%rbx
  6e4104:	mov    %r12,0x30(%rsp)
  6e4109:	mov    %rbx,0x38(%rsp)
  6e410e:	lea    0x260(%rsp),%rbp
  6e4116:	mov    %rbp,%rdi
  6e4119:	call   6b5ed0 <text_column_public_control::observe::<text_column_public_control::Model>>
  6e411e:	mov    0x260(%rsp),%rax
  6e4126:	lea    0x33eb0b(%rip),%rcx        # a22c38 <__frame_dummy_init_array_entry+0x1148>
  6e412d:	cmp    0x1e0(%rsp),%rax
  6e4135:	jne    6e484c <text_column_public_control::main+0x520c>
  6e413b:	mov    %rax,0xd8(%rsp)
  6e4143:	mov    0x268(%rsp),%rax
  6e414b:	mov    %rax,0x158(%rsp)
  6e4153:	cmp    0x1e8(%rsp),%rax
  6e415b:	jne    6e484c <text_column_public_control::main+0x520c>
  6e4161:	mov    0x270(%rsp),%rax
  6e4169:	mov    %rax,0x68(%rsp)
  6e416e:	cmp    0x1f0(%rsp),%rax
  6e4176:	jne    6e484c <text_column_public_control::main+0x520c>
  6e417c:	xor    %r8d,%r8d
  6e417f:	cmp    $0x3,%r15b
  6e4183:	sete   %r8b
  6e4187:	add    %r8d,%r8d
  6e418a:	lea    0x260(%rsp),%rdi
  6e4192:	lea    0x8(%rsp),%rsi
  6e4197:	mov    %r15d,%edx
  6e419a:	mov    0x10(%rsp),%ecx
  6e419e:	call   6dd800 <text_column_public_control::edit>
  6e41a3:	mov    0x8(%rsp),%rsi
  6e41a8:	test   %rsi,%rsi
  6e41ab:	je     6e496d <text_column_public_control::main+0x532d>
  6e41b1:	cmpb   $0x0,0x78e(%rsi)
  6e41b8:	jne    6e4974 <text_column_public_control::main+0x5334>
  6e41be:	mov    0x6f0(%rsi),%rcx
  6e41c5:	test   %rcx,%rcx
  6e41c8:	je     6e497b <text_column_public_control::main+0x533b>
  6e41ce:	mov    0x6f8(%rsi),%rax
  6e41d5:	mov    %rcx,0x230(%rsp)
  6e41dd:	mov    %rax,0x238(%rsp)
  6e41e5:	cmp    %rax,%rbx
  6e41e8:	sete   %al
  6e41eb:	cmp    %rcx,%r12
  6e41ee:	je     6e41f2 <text_column_public_control::main+0x4bb2>
  6e41f0:	xor    %eax,%eax
  6e41f2:	test   %al,%al
  6e41f4:	jne    6e4896 <text_column_public_control::main+0x5256>
  6e41fa:	lea    0x260(%rsp),%rdi
  6e4202:	mov    %r12,%rdx
  6e4205:	mov    %rbx,%rcx
  6e4208:	call   70d5d0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge>
  6e420d:	mov    0x260(%rsp),%rbx
  6e4215:	cmp    $0xfffffffffffffffe,%rbx
  6e4219:	je     6e487d <text_column_public_control::main+0x523d>
  6e421f:	lea    -0x696d66(%rip),%rsi        # 4d4c0 <GCC_except_table0+0xd71c>
  6e4226:	lea    0x260(%rsp),%rdi
  6e422e:	call   727b10 <<gpui::runtime::Error as core::cmp::PartialEq>::eq>
  6e4233:	test   %al,%al
  6e4235:	je     6e487d <text_column_public_control::main+0x523d>
  6e423b:	sub    $0xd,%rbx
  6e423f:	mov    $0x14,%eax
  6e4244:	cmovge %rbx,%rax
  6e4248:	cmp    $0x14,%rax
  6e424c:	je     6e426b <text_column_public_control::main+0x4c2b>
  6e424e:	cmp    $0x19,%rax
  6e4252:	jne    6e428e <text_column_public_control::main+0x4c4e>
  6e4254:	mov    0x268(%rsp),%rsi
  6e425c:	test   %rsi,%rsi
  6e425f:	je     6e428e <text_column_public_control::main+0x4c4e>
  6e4261:	lea    0x270(%rsp),%rax
  6e4269:	jmp    6e4280 <text_column_public_control::main+0x4c40>
  6e426b:	mov    0x278(%rsp),%rsi
  6e4273:	test   %rsi,%rsi
  6e4276:	je     6e428e <text_column_public_control::main+0x4c4e>
  6e4278:	lea    0x280(%rsp),%rax
  6e4280:	mov    (%rax),%rdi
  6e4283:	mov    $0x1,%edx
  6e4288:	call   *0x35dfca(%rip)        # a42258 <_DYNAMIC+0x268>
  6e428e:	mov    0x8(%rsp),%rsi
  6e4293:	test   %rsi,%rsi
  6e4296:	je     6e42b4 <text_column_public_control::main+0x4c74>
  6e4298:	cmpb   $0x0,0x78e(%rsi)
  6e429f:	je     6e42d3 <text_column_public_control::main+0x4c93>
  6e42a1:	movq   $0xe,0x260(%rsp)
  6e42ad:	mov    $0xe,%ebx
  6e42b2:	jmp    6e4302 <text_column_public_control::main+0x4cc2>
  6e42b4:	movq   $0xd,0x260(%rsp)
  6e42c0:	movq   $0x0,0x268(%rsp)
  6e42cc:	mov    $0xd,%ebx
  6e42d1:	jmp    6e4302 <text_column_public_control::main+0x4cc2>
  6e42d3:	lea    0x260(%rsp),%rdi
  6e42db:	mov    0x150(%rsp),%rdx
  6e42e3:	mov    0x148(%rsp),%rcx
  6e42eb:	call   70d5d0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge>
  6e42f0:	mov    0x260(%rsp),%rbx
  6e42f8:	cmp    $0xfffffffffffffffe,%rbx
  6e42fc:	je     6e4900 <text_column_public_control::main+0x52c0>
  6e4302:	lea    -0x696e49(%rip),%rsi        # 4d4c0 <GCC_except_table0+0xd71c>
  6e4309:	lea    0x260(%rsp),%rdi
  6e4311:	call   727b10 <<gpui::runtime::Error as core::cmp::PartialEq>::eq>
  6e4316:	test   %al,%al
  6e4318:	je     6e4900 <text_column_public_control::main+0x52c0>
  6e431e:	sub    $0xd,%rbx
  6e4322:	mov    $0x14,%eax
  6e4327:	cmovge %rbx,%rax
  6e432b:	cmp    $0x14,%rax
  6e432f:	je     6e434e <text_column_public_control::main+0x4d0e>
  6e4331:	cmp    $0x19,%rax
  6e4335:	jne    6e4371 <text_column_public_control::main+0x4d31>
  6e4337:	mov    0x268(%rsp),%rsi
  6e433f:	test   %rsi,%rsi
  6e4342:	je     6e4371 <text_column_public_control::main+0x4d31>
  6e4344:	lea    0x270(%rsp),%rax
  6e434c:	jmp    6e4363 <text_column_public_control::main+0x4d23>
  6e434e:	mov    0x278(%rsp),%rsi
  6e4356:	test   %rsi,%rsi
  6e4359:	je     6e4371 <text_column_public_control::main+0x4d31>
  6e435b:	lea    0x280(%rsp),%rax
  6e4363:	mov    (%rax),%rdi
  6e4366:	mov    $0x1,%edx
  6e436b:	call   *0x35dee7(%rip)        # a42258 <_DYNAMIC+0x268>
  6e4371:	mov    0x8(%rsp),%rsi
  6e4376:	lea    0x260(%rsp),%rbp
  6e437e:	mov    %rbp,%rdi
  6e4381:	call   6b5ed0 <text_column_public_control::observe::<text_column_public_control::Model>>
  6e4386:	mov    0x158(%rsp),%rax
  6e438e:	cmp    %rax,0x268(%rsp)
  6e4396:	sete   %al
  6e4399:	mov    0xd8(%rsp),%rcx
  6e43a1:	cmp    %rcx,0x260(%rsp)
  6e43a9:	jne    6e4834 <text_column_public_control::main+0x51f4>
  6e43af:	mov    0x68(%rsp),%rcx
  6e43b4:	cmp    %rcx,0x270(%rsp)
  6e43bc:	sete   %cl
  6e43bf:	test   %al,%al
  6e43c1:	je     6e483b <text_column_public_control::main+0x51fb>
  6e43c7:	test   %cl,%cl
  6e43c9:	je     6e4845 <text_column_public_control::main+0x5205>
  6e43cf:	mov    0x8(%rsp),%rdi
  6e43d4:	lea    -0x6a2a33(%rip),%rcx        # 419a8 <GCC_except_table0+0x1c04>
  6e43db:	mov    $0x8,%r8d
  6e43e1:	mov    %r15d,%esi
  6e43e4:	mov    0x10(%rsp),%edx
  6e43e8:	call   6db9b0 <text_column_public_control::emit_state>
  6e43ed:	mov    0x8(%rsp),%rsi
  6e43f2:	lea    0x260(%rsp),%rdi
  6e43fa:	call   6b5db0 <text_column_public_control::ack::<text_column_public_control::Model>>
  6e43ff:	mov    0x8(%rsp),%rdi
  6e4404:	lea    -0x696d92(%rip),%rcx        # 4d679 <GCC_except_table0+0xd8d5>
  6e440b:	mov    $0x6,%r8d
  6e4411:	mov    %r15d,%esi
  6e4414:	mov    0x10(%rsp),%edx
  6e4418:	call   6db9b0 <text_column_public_control::emit_state>
  6e441d:	mov    0x8(%rsp),%rax
  6e4422:	test   %rax,%rax
  6e4425:	je     6e49be <text_column_public_control::main+0x537e>
  6e442b:	mov    0x770(%rax),%rcx
  6e4432:	mov    %rcx,0xa20(%rsp)
  6e443a:	movups 0x760(%rax),%xmm0
  6e4441:	movaps %xmm0,0xa10(%rsp)
  6e4449:	movups 0x750(%rax),%xmm0
  6e4450:	movaps %xmm0,0xa00(%rsp)
  6e4458:	movdqu 0x710(%rax),%xmm0
  6e4460:	movups 0x720(%rax),%xmm1
  6e4467:	movdqu 0x730(%rax),%xmm2
  6e446f:	movdqu 0x740(%rax),%xmm3
  6e4477:	movdqa %xmm3,0x9f0(%rsp)
  6e4480:	movdqa %xmm2,0x9e0(%rsp)
  6e4489:	movaps %xmm1,0x9d0(%rsp)
  6e4491:	movdqa %xmm0,0x9c0(%rsp)
  6e449a:	cmpb   $0x7,0x20(%rsp)
  6e449f:	setne  %al
  6e44a2:	lea    0x9c8(%rsp),%rsi
  6e44aa:	mov    0x40(%rsp),%edi
  6e44ae:	test   %dil,%al
  6e44b1:	je     6e44d1 <text_column_public_control::main+0x4e91>
  6e44b3:	cmpq   $0x0,0x9c8(%rsp)
  6e44bc:	jne    6e48ad <text_column_public_control::main+0x526d>
  6e44c2:	cmpq   $0x0,0x9c0(%rsp)
  6e44cb:	jne    6e48b6 <text_column_public_control::main+0x5276>
  6e44d1:	lea    0x0(,%r15,8),%eax
  6e44d9:	lea    0x33fef0(%rip),%rcx        # a243d0 <__frame_dummy_init_array_entry+0x28e0>
  6e44e0:	mov    (%rax,%rcx,1),%rcx
  6e44e4:	lea    -0x6938e3(%rip),%rdx        # 50c08 <GCC_except_table0+0x10e64>
  6e44eb:	mov    (%rax,%rdx,1),%rax
  6e44ef:	mov    %rcx,0x160(%rsp)
  6e44f7:	mov    %rax,0x168(%rsp)
  6e44ff:	lea    0x9d0(%rsp),%rcx
  6e4507:	lea    0xa10(%rsp),%rax
  6e450f:	test   %dil,%dil
  6e4512:	je     6e4564 <text_column_public_control::main+0x4f24>
  6e4514:	lea    -0x697079(%rip),%rdx        # 4d4a2 <GCC_except_table0+0xd6fe>
  6e451b:	mov    %rdx,0x178(%rsp)
  6e4523:	movq   $0x5,0x180(%rsp)
  6e452f:	mov    0x60(%rsp),%rdx
  6e4534:	mov    %rdx,0x250(%rsp)
  6e453c:	mov    0x50(%rsp),%rdx
  6e4541:	mov    %rdx,0x258(%rsp)
  6e4549:	cmpb   $0x6,0x20(%rsp)
  6e454e:	je     6e45a7 <text_column_public_control::main+0x4f67>
  6e4550:	cmp    $0x7,%r15d
  6e4554:	jne    6e45b5 <text_column_public_control::main+0x4f75>
  6e4556:	mov    $0xc,%edx
  6e455b:	lea    -0x696ed9(%rip),%rdi        # 4d689 <GCC_except_table0+0xd8e5>
  6e4562:	jmp    6e45c1 <text_column_public_control::main+0x4f81>
  6e4564:	lea    -0x6970cf(%rip),%rdx        # 4d49c <GCC_except_table0+0xd6f8>
  6e456b:	mov    %rdx,0x178(%rsp)
  6e4573:	movq   $0x6,0x180(%rsp)
  6e457f:	mov    0x60(%rsp),%rdx
  6e4584:	mov    %rdx,0x250(%rsp)
  6e458c:	mov    0x50(%rsp),%rdx
  6e4591:	mov    %rdx,0x258(%rsp)
  6e4599:	mov    $0xa,%edx
  6e459e:	lea    -0x696f26(%rip),%rdi        # 4d67f <GCC_except_table0+0xd8db>
  6e45a5:	jmp    6e45c1 <text_column_public_control::main+0x4f81>
  6e45a7:	mov    $0x1c,%edx
  6e45ac:	lea    -0x696f1e(%rip),%rdi        # 4d695 <GCC_except_table0+0xd8f1>
  6e45b3:	jmp    6e45c1 <text_column_public_control::main+0x4f81>
  6e45b5:	mov    $0xd,%edx
  6e45ba:	lea    -0x696f10(%rip),%rdi        # 4d6b1 <GCC_except_table0+0xd90d>
  6e45c1:	mov    %rdi,0xe0(%rsp)
  6e45c9:	mov    %rdx,0xe8(%rsp)
  6e45d1:	lea    0x160(%rsp),%rdx
  6e45d9:	mov    %rdx,0x260(%rsp)
  6e45e1:	lea    0x427a8(%rip),%rdx        # 726d90 <<&str as core::fmt::Display>::fmt>
  6e45e8:	mov    %rdx,0x268(%rsp)
  6e45f0:	lea    0x178(%rsp),%rdi
  6e45f8:	mov    %rdi,0x270(%rsp)
  6e4600:	mov    %rdx,0x278(%rsp)
  6e4608:	lea    0x250(%rsp),%rdi
  6e4610:	mov    %rdi,0x280(%rsp)
  6e4618:	mov    0x35de89(%rip),%rdi        # a424a8 <_DYNAMIC+0x4b8>
  6e461f:	mov    %rdi,0x288(%rsp)
  6e4627:	lea    0x258(%rsp),%r8
  6e462f:	mov    %r8,0x290(%rsp)
  6e4637:	mov    %rdi,0x298(%rsp)
  6e463f:	lea    0x248(%rsp),%r8
  6e4647:	mov    %r8,0x2a0(%rsp)
  6e464f:	mov    %rdi,0x2a8(%rsp)
  6e4657:	mov    %rsi,0x2b0(%rsp)
  6e465f:	mov    0x35de4a(%rip),%rsi        # a424b0 <_DYNAMIC+0x4c0>
  6e4666:	mov    %rsi,0x2b8(%rsp)
  6e466e:	lea    0x9c0(%rsp),%rdi
  6e4676:	mov    %rdi,0x2c0(%rsp)
  6e467e:	mov    %rsi,0x2c8(%rsp)
  6e4686:	mov    %rcx,0x2d0(%rsp)
  6e468e:	mov    %rsi,0x2d8(%rsp)
  6e4696:	mov    %rax,0x2e0(%rsp)
  6e469e:	mov    %rsi,0x2e8(%rsp)
  6e46a6:	lea    0xe0(%rsp),%rax
  6e46ae:	mov    %rax,0x2f0(%rsp)
  6e46b6:	mov    %rdx,0x2f8(%rsp)
  6e46be:	lea    -0x6a14d5(%rip),%rdi        # 431f0 <GCC_except_table0+0x344c>
  6e46c5:	lea    0x260(%rsp),%rsi
  6e46cd:	call   *0x35dded(%rip)        # a424c0 <_DYNAMIC+0x4d0>
  6e46d3:	cmpb   $0x3,0x20(%rsp)
  6e46d8:	jne    6e473b <text_column_public_control::main+0x50fb>
  6e46da:	lea    0x260(%rsp),%rdi
  6e46e2:	lea    0x8(%rsp),%rsi
  6e46e7:	mov    $0x3,%edx
  6e46ec:	mov    0x10(%rsp),%ecx
  6e46f0:	xor    %r8d,%r8d
  6e46f3:	call   6dd800 <text_column_public_control::edit>
  6e46f8:	lea    0x260(%rsp),%rax
  6e4700:	lea    0x260(%rsp),%rdi
  6e4708:	lea    0x8(%rsp),%rsi
  6e470d:	mov    $0x1,%r8d
  6e4713:	mov    $0x3,%edx
  6e4718:	mov    0x10(%rsp),%ecx
  6e471c:	call   6dd800 <text_column_public_control::edit>
  6e4721:	lea    0x260(%rsp),%rax
  6e4729:	mov    0x8(%rsp),%rsi
  6e472e:	lea    0x260(%rsp),%rdi
  6e4736:	call   6b5db0 <text_column_public_control::ack::<text_column_public_control::Model>>
  6e473b:	mov    0x8(%rsp),%rdi
  6e4740:	lea    -0x697089(%rip),%rcx        # 4d6be <GCC_except_table0+0xd91a>
  6e4747:	mov    $0xc,%r8d
  6e474d:	mov    %r15d,%esi
  6e4750:	mov    0x10(%rsp),%edx
  6e4754:	call   6db9b0 <text_column_public_control::emit_state>
  6e4759:	mov    0x190(%rsp),%rsi
  6e4761:	test   %rsi,%rsi
  6e4764:	je     6e4778 <text_column_public_control::main+0x5138>
  6e4766:	shl    $0x3,%rsi
  6e476a:	mov    $0x8,%edx
  6e476f:	mov    %r14,%rdi
  6e4772:	call   *0x35dae0(%rip)        # a42258 <_DYNAMIC+0x268>
  6e4778:	mov    0xf8(%rsp),%rsi
  6e4780:	test   %rsi,%rsi
  6e4783:	je     6e4797 <text_column_public_control::main+0x5157>
  6e4785:	shl    $0x3,%rsi
  6e4789:	mov    $0x8,%edx
  6e478e:	mov    %r13,%rdi
  6e4791:	call   *0x35dac1(%rip)        # a42258 <_DYNAMIC+0x268>
  6e4797:	mov    0x8(%rsp),%r14
  6e479c:	test   %r14,%r14
  6e479f:	je     6e47bc <text_column_public_control::main+0x517c>
  6e47a1:	mov    %r14,%rdi
  6e47a4:	call   6c00d0 <core::ptr::drop_glue::<gpui::runtime::Runtime<text_column_public_control::Model>>>
  6e47a9:	mov    $0x790,%esi
  6e47ae:	mov    $0x8,%edx
  6e47b3:	mov    %r14,%rdi
  6e47b6:	call   *0x35da9c(%rip)        # a42258 <_DYNAMIC+0x268>
  6e47bc:	mov    0x218(%rsp),%rbx
  6e47c4:	mov    0x220(%rsp),%r14
  6e47cc:	test   %r14,%r14
  6e47cf:	je     6e47ff <text_column_public_control::main+0x51bf>
  6e47d1:	lea    0x8(%rbx),%r15
  6e47d5:	mov    0x35da7c(%rip),%r12        # a42258 <_DYNAMIC+0x268>
  6e47dc:	jmp    6e47e9 <text_column_public_control::main+0x51a9>
  6e47de:	xchg   %ax,%ax
  6e47e0:	add    $0x18,%r15
  6e47e4:	dec    %r14
  6e47e7:	je     6e47ff <text_column_public_control::main+0x51bf>
  6e47e9:	mov    -0x8(%r15),%rsi
  6e47ed:	test   %rsi,%rsi
  6e47f0:	je     6e47e0 <text_column_public_control::main+0x51a0>
  6e47f2:	mov    (%r15),%rdi
  6e47f5:	mov    $0x1,%edx
  6e47fa:	call   *%r12
  6e47fd:	jmp    6e47e0 <text_column_public_control::main+0x51a0>
  6e47ff:	mov    0x210(%rsp),%rax
  6e4807:	test   %rax,%rax
  6e480a:	je     6e4822 <text_column_public_control::main+0x51e2>
  6e480c:	shl    $0x3,%rax
  6e4810:	lea    (%rax,%rax,2),%rsi
  6e4814:	mov    $0x8,%edx
  6e4819:	mov    %rbx,%rdi
  6e481c:	call   *0x35da36(%rip)        # a42258 <_DYNAMIC+0x268>
  6e4822:	add    $0xe48,%rsp
  6e4829:	pop    %rbx
  6e482a:	pop    %r12
  6e482c:	pop    %r13
  6e482e:	pop    %r14
  6e4830:	pop    %r15
  6e4832:	pop    %rbp
  6e4833:	ret
  6e4834:	xor    %eax,%eax
  6e4836:	jmp    6e43af <text_column_public_control::main+0x4d6f>
  6e483b:	xor    %ecx,%ecx
  6e483d:	test   %cl,%cl
  6e483f:	jne    6e43cf <text_column_public_control::main+0x4d8f>
  6e4845:	lea    0x33e44c(%rip),%rcx        # a22c98 <__frame_dummy_init_array_entry+0x11a8>
  6e484c:	lea    0x1e0(%rsp),%rdx
  6e4854:	xor    %edi,%edi
  6e4856:	mov    %rbp,%rsi
  6e4859:	call   6c86bd <core::panicking::assert_failed::<(usize, usize, u64), (usize, usize, u64)>>
  6e485e:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e4863:	lea    0xf8(%rsp),%rdi
  6e486b:	lea    0x190(%rsp),%rsi
  6e4873:	call   6c864c <core::panicking::assert_failed::<alloc::vec::Vec<usize>, alloc::vec::Vec<usize>>>
  6e4878:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e487d:	lea    0x33e3e4(%rip),%rsi        # a22c68 <__frame_dummy_init_array_entry+0x1178>
  6e4884:	lea    0x260(%rsp),%rdi
  6e488c:	call   6c8614 <core::panicking::assert_failed::<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>, core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>>
  6e4891:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e4896:	lea    0x30(%rsp),%rdi
  6e489b:	lea    0x230(%rsp),%rsi
  6e48a3:	call   6c8684 <core::panicking::assert_failed::<gpui::runtime::PresentationToken, gpui::runtime::PresentationToken>>
  6e48a8:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e48ad:	lea    0x33e414(%rip),%r9        # a22cc8 <__frame_dummy_init_array_entry+0x11d8>
  6e48b4:	jmp    6e48c5 <text_column_public_control::main+0x5285>
  6e48b6:	lea    0x33e3f3(%rip),%r9        # a22cb0 <__frame_dummy_init_array_entry+0x11c0>
  6e48bd:	lea    0x9c0(%rsp),%rsi
  6e48c5:	lea    -0x6a30dc(%rip),%rdx        # 417f0 <GCC_except_table0+0x1a4c>
  6e48cc:	xor    %edi,%edi
  6e48ce:	xor    %ecx,%ecx
  6e48d0:	call   *0x35dc92(%rip)        # a42568 <_DYNAMIC+0x578>
  6e48d6:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e48db:	lea    0x33e30e(%rip),%r9        # a22bf0 <__frame_dummy_init_array_entry+0x1100>
  6e48e2:	lea    -0x6a30f9(%rip),%rdx        # 417f0 <GCC_except_table0+0x1a4c>
  6e48e9:	lea    0x248(%rsp),%rsi
  6e48f1:	xor    %edi,%edi
  6e48f3:	xor    %ecx,%ecx
  6e48f5:	call   *0x35dbcd(%rip)        # a424c8 <_DYNAMIC+0x4d8>
  6e48fb:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e4900:	lea    0x33e379(%rip),%rsi        # a22c80 <__frame_dummy_init_array_entry+0x1190>
  6e4907:	lea    0x260(%rsp),%rdi
  6e490f:	call   6c8614 <core::panicking::assert_failed::<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>, core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>>
  6e4914:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e4919:	mov    $0xd,%eax
  6e491e:	jmp    6e492c <text_column_public_control::main+0x52ec>
  6e4920:	mov    $0xe,%eax
  6e4925:	jmp    6e492c <text_column_public_control::main+0x52ec>
  6e4927:	mov    $0x14,%eax
  6e492c:	mov    %rax,0x260(%rsp)
  6e4934:	movq   $0x0,0x268(%rsp)
  6e4940:	lea    -0x697268(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6e4947:	lea    0x33e3da(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6e494e:	lea    0x33e2cb(%rip),%r8        # a22c20 <__frame_dummy_init_array_entry+0x1130>
  6e4955:	lea    0x260(%rsp),%rdx
  6e495d:	mov    $0x2b,%esi
  6e4962:	call   *0x35d8c8(%rip)        # a42230 <_DYNAMIC+0x240>
  6e4968:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e496d:	mov    $0xd,%eax
  6e4972:	jmp    6e4980 <text_column_public_control::main+0x5340>
  6e4974:	mov    $0xe,%eax
  6e4979:	jmp    6e4980 <text_column_public_control::main+0x5340>
  6e497b:	mov    $0x14,%eax
  6e4980:	mov    %rax,0x260(%rsp)
  6e4988:	movq   $0x0,0x268(%rsp)
  6e4994:	lea    -0x6972bc(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6e499b:	lea    0x33e386(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6e49a2:	lea    0x33e2a7(%rip),%r8        # a22c50 <__frame_dummy_init_array_entry+0x1160>
  6e49a9:	lea    0x260(%rsp),%rdx
  6e49b1:	mov    $0x2b,%esi
  6e49b6:	call   *0x35d874(%rip)        # a42230 <_DYNAMIC+0x240>
  6e49bc:	jmp    6e49fe <text_column_public_control::main+0x53be>
  6e49be:	movq   $0xd,0x260(%rsp)
  6e49ca:	movq   $0x0,0x268(%rsp)
  6e49d6:	lea    -0x6973ee(%rip),%rdi        # 4d5ef <GCC_except_table0+0xd84b>
  6e49dd:	lea    0x33e344(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6e49e4:	lea    0x33e085(%rip),%r8        # a22a70 <__frame_dummy_init_array_entry+0xf80>
  6e49eb:	lea    0x260(%rsp),%rdx
  6e49f3:	mov    $0x24,%esi
  6e49f8:	call   *0x35d832(%rip)        # a42230 <_DYNAMIC+0x240>
  6e49fe:	ud2
  6e4a00:	mov    %rax,%rbx
  6e4a03:	mov    $0x790,%esi
  6e4a08:	jmp    6e3ed7 <text_column_public_control::main+0x4897>
  6e4a0d:	jmp    6e4a11 <text_column_public_control::main+0x53d1>
  6e4a0f:	jmp    6e4a11 <text_column_public_control::main+0x53d1>
  6e4a11:	mov    %rax,%rbx
  6e4a14:	lea    0x260(%rsp),%rdi
  6e4a1c:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e4a21:	jmp    6e4a3a <text_column_public_control::main+0x53fa>
  6e4a23:	jmp    6e4a25 <text_column_public_control::main+0x53e5>
  6e4a25:	mov    %rax,%rbx
  6e4a28:	lea    0x260(%rsp),%rdi
  6e4a30:	call   6bf8a0 <core::ptr::drop_glue::<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>>
  6e4a35:	jmp    6e4a3a <text_column_public_control::main+0x53fa>
  6e4a37:	mov    %rax,%rbx
  6e4a3a:	mov    0x190(%rsp),%rsi
  6e4a42:	test   %rsi,%rsi
  6e4a45:	je     6e4a59 <text_column_public_control::main+0x5419>
  6e4a47:	shl    $0x3,%rsi
  6e4a4b:	mov    $0x8,%edx
  6e4a50:	mov    %r14,%rdi
  6e4a53:	call   *0x35d7ff(%rip)        # a42258 <_DYNAMIC+0x268>
  6e4a59:	mov    0xf8(%rsp),%rsi
  6e4a61:	test   %rsi,%rsi
  6e4a64:	je     6e4a7d <text_column_public_control::main+0x543d>
  6e4a66:	mov    0x100(%rsp),%rdi
  6e4a6e:	shl    $0x3,%rsi
  6e4a72:	mov    $0x8,%edx
  6e4a77:	call   *0x35d7db(%rip)        # a42258 <_DYNAMIC+0x268>
  6e4a7d:	mov    0x8(%rsp),%rdi
  6e4a82:	call   6bfac0 <core::ptr::drop_glue::<gpui::runtime::Win<text_column_public_control::Model>>>
  6e4a87:	lea    0x210(%rsp),%rdi
  6e4a8f:	call   6c0da0 <core::ptr::drop_glue::<alloc::vec::Vec<alloc::string::String>>>
  6e4a94:	mov    %rbx,%rdi
  6e4a97:	call   a20740 <_Unwind_Resume@plt>
  6e4a9c:	call   *0x35d7de(%rip)        # a42280 <_DYNAMIC+0x290>

text_column_public_control::mount code=2251 fixed_stack=3416

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006e4ab0 <text_column_public_control::mount>:
  6e4ab0:	push   %rbp
  6e4ab1:	push   %r15
  6e4ab3:	push   %r14
  6e4ab5:	push   %r13
  6e4ab7:	push   %r12
  6e4ab9:	push   %rbx
  6e4aba:	sub    $0xd28,%rsp
  6e4ac1:	mov    %edx,%r13d
  6e4ac4:	mov    %esi,%ebp
  6e4ac6:	mov    %rdi,%rbx
  6e4ac9:	call   *0x35d791(%rip)        # a42260 <_DYNAMIC+0x270>
  6e4acf:	mov    $0x1,%r15d
  6e4ad5:	mov    $0x13,%edi
  6e4ada:	mov    $0x1,%esi
  6e4adf:	call   *0x35d783(%rip)        # a42268 <_DYNAMIC+0x278>
  6e4ae5:	test   %rax,%rax
  6e4ae8:	je     6e514a <text_column_public_control::mount+0x69a>
  6e4aee:	movups -0x69764e(%rip),%xmm0        # 4d4a7 <GCC_except_table0+0xd703>
  6e4af5:	cmp    $0x1,%bpl
  6e4af9:	mov    $0x20,%ecx
  6e4afe:	mov    $0x8000,%r12d
  6e4b04:	cmove  %rcx,%r12
  6e4b08:	movups %xmm0,(%rax)
  6e4b0b:	test   %bpl,%bpl
  6e4b0e:	cmove  %r15,%r12
  6e4b12:	mov    %rax,0x10(%rsp)
  6e4b17:	movl   $0x92d791d7,0xf(%rax)
  6e4b1e:	movups -0x6973d1(%rip),%xmm0        # 4d754 <GCC_except_table0+0xd9b0>
  6e4b25:	movups %xmm0,0xf8(%rsp)
  6e4b2d:	movq   $0x0,0x108(%rsp)
  6e4b39:	lea    0x110(%rsp),%rdi
  6e4b41:	movabs $0x19000000190,%rsi
  6e4b4b:	movss  -0x6a4d4b(%rip),%xmm0        # 3fe08 <GCC_except_table0+0x64>
  6e4b53:	call   *0x35d997(%rip)        # a424f0 <_DYNAMIC+0x500>
  6e4b59:	mov    0x110(%rsp),%r15
  6e4b61:	cmp    $0xfffffffffffffffe,%r15
  6e4b65:	jne    6e515a <text_column_public_control::mount+0x6aa>
  6e4b6b:	mov    %rbx,0x20(%rsp)
  6e4b70:	lea    0x110(%rsp),%rdi
  6e4b78:	call   7251d0 <<text_column_public_control::Model as gpui::View>::sources>
  6e4b7d:	mov    %r13d,%ebx
  6e4b80:	mov    0x110(%rsp),%rax
  6e4b88:	movups 0x168(%rsp),%xmm0
  6e4b90:	movaps %xmm0,0x8e0(%rsp)
  6e4b98:	movups 0x158(%rsp),%xmm0
  6e4ba0:	movaps %xmm0,0x8d0(%rsp)
  6e4ba8:	movups 0x148(%rsp),%xmm0
  6e4bb0:	movaps %xmm0,0x8c0(%rsp)
  6e4bb8:	movups 0x138(%rsp),%xmm0
  6e4bc0:	movaps %xmm0,0x8b0(%rsp)
  6e4bc8:	movups 0x128(%rsp),%xmm1
  6e4bd0:	movaps %xmm1,0x8a0(%rsp)
  6e4bd8:	movups 0x118(%rsp),%xmm2
  6e4be0:	movups %xmm1,0xa0(%rsp)
  6e4be8:	movups %xmm0,0xb0(%rsp)
  6e4bf0:	mov    0x8c0(%rsp),%rcx
  6e4bf8:	mov    %rcx,0xc0(%rsp)
  6e4c00:	mov    0x8e8(%rsp),%rcx
  6e4c08:	mov    %rcx,0xe8(%rsp)
  6e4c10:	movups 0x8d8(%rsp),%xmm0
  6e4c18:	movups %xmm0,0xd8(%rsp)
  6e4c20:	movups 0x8c8(%rsp),%xmm0
  6e4c28:	movups %xmm0,0xc8(%rsp)
  6e4c30:	mov    %rax,0x88(%rsp)
  6e4c38:	movups %xmm2,0x90(%rsp)
  6e4c40:	movl   $0x0,0x8a0(%rsp)
  6e4c4b:	movl   $0x434b0000,0x8a8(%rsp)
  6e4c56:	movw   $0x0,0x8ac(%rsp)
  6e4c60:	lea    0x110(%rsp),%rdi
  6e4c68:	lea    0x8a0(%rsp),%rcx
  6e4c70:	mov    $0x190,%esi
  6e4c75:	mov    $0x190,%edx
  6e4c7a:	call   *0x35d880(%rip)        # a42500 <_DYNAMIC+0x510>
  6e4c80:	mov    0x110(%rsp),%r15
  6e4c88:	mov    0x118(%rsp),%r14d
  6e4c90:	mov    0x11c(%rsp),%r13d
  6e4c98:	cmp    $0x2,%r15
  6e4c9c:	je     6e51a3 <text_column_public_control::mount+0x6f3>
  6e4ca2:	lea    0x120(%rsp),%rsi
  6e4caa:	lea    0xb50(%rsp),%rdi
  6e4cb2:	mov    $0x1d8,%edx
  6e4cb7:	call   *0x35d5bb(%rip)        # a42278 <memcpy@GLIBC_2.14>
  6e4cbd:	mov    %r15,0xb40(%rsp)
  6e4cc5:	mov    %r14d,0xb48(%rsp)
  6e4ccd:	mov    %r13d,0xb4c(%rsp)
  6e4cd5:	call   *0x35d82d(%rip)        # a42508 <_DYNAMIC+0x518>
  6e4cdb:	mov    %rax,%r13
  6e4cde:	lea    0x8a0(%rsp),%rdi
  6e4ce6:	call   *0x35d824(%rip)        # a42510 <_DYNAMIC+0x520>
  6e4cec:	movq   $0x13,0x3b0(%rsp)
  6e4cf8:	movl   $0x0,0x3b8(%rsp)
  6e4d03:	mov    %r12,0x3c0(%rsp)
  6e4d0b:	movabs $0x4000000000000000,%rax
  6e4d15:	mov    %rax,0x3c8(%rsp)
  6e4d1d:	movb   $0x0,0x3d0(%rsp)
  6e4d25:	movl   $0x0,0x3d8(%rsp)
  6e4d30:	mov    %rax,0x3e0(%rsp)
  6e4d38:	movl   $0x0,0x3e8(%rsp)
  6e4d43:	movups 0xf4(%rsp),%xmm0
  6e4d4b:	movups 0x100(%rsp),%xmm1
  6e4d53:	movups %xmm0,0x3ec(%rsp)
  6e4d5b:	movups %xmm1,0x3f8(%rsp)
  6e4d63:	movl   $0x0,0x408(%rsp)
  6e4d6e:	mov    %bl,0x40c(%rsp)
  6e4d75:	mov    %bpl,0x40d(%rsp)
  6e4d7d:	movups 0x88(%rsp),%xmm0
  6e4d85:	movups 0x98(%rsp),%xmm1
  6e4d8d:	movups 0xa8(%rsp),%xmm2
  6e4d95:	movups 0xb8(%rsp),%xmm3
  6e4d9d:	movups %xmm0,0x338(%rsp)
  6e4da5:	movups %xmm1,0x348(%rsp)
  6e4dad:	movups %xmm2,0x358(%rsp)
  6e4db5:	movups %xmm3,0x368(%rsp)
  6e4dbd:	movups 0xc8(%rsp),%xmm0
  6e4dc5:	movups %xmm0,0x378(%rsp)
  6e4dcd:	movups 0xd8(%rsp),%xmm0
  6e4dd5:	movups %xmm0,0x388(%rsp)
  6e4ddd:	mov    0xe8(%rsp),%rax
  6e4de5:	mov    %rax,0x398(%rsp)
  6e4ded:	lea    0x440(%rsp),%rdi
  6e4df5:	lea    0x8a0(%rsp),%rsi
  6e4dfd:	mov    0x35d474(%rip),%r15        # a42278 <memcpy@GLIBC_2.14>
  6e4e04:	mov    $0x298,%edx
  6e4e09:	call   *%r15
  6e4e0c:	lea    0x110(%rsp),%rdi
  6e4e14:	lea    0xb40(%rsp),%rsi
  6e4e1c:	mov    $0x1e8,%edx
  6e4e21:	call   *%r15
  6e4e24:	movq   $0x13,0x3a0(%rsp)
  6e4e30:	mov    0x10(%rsp),%rax
  6e4e35:	mov    %rax,0x3a8(%rsp)
  6e4e3d:	movq   $0x0,0x410(%rsp)
  6e4e49:	movq   $0x8,0x418(%rsp)
  6e4e55:	xorps  %xmm0,%xmm0
  6e4e58:	movups %xmm0,0x420(%rsp)
  6e4e60:	movq   $0x8,0x430(%rsp)
  6e4e6c:	movq   $0x0,0x438(%rsp)
  6e4e78:	movq   $0x0,0x758(%rsp)
  6e4e84:	movups %xmm0,0x2f8(%rsp)
  6e4e8c:	movups %xmm0,0x308(%rsp)
  6e4e94:	movups %xmm0,0x740(%rsp)
  6e4e9c:	movq   $0x1,0x760(%rsp)
  6e4ea8:	movq   $0x0,0x768(%rsp)
  6e4eb4:	mov    %r13,0x730(%rsp)
  6e4ebc:	movq   $0x0,0x778(%rsp)
  6e4ec8:	movq   $0x0,0x7c0(%rsp)
  6e4ed4:	movups %xmm0,0x788(%rsp)
  6e4edc:	movq   $0x0,0x798(%rsp)
  6e4ee8:	movups %xmm0,0x7a8(%rsp)
  6e4ef0:	movq   $0x0,0x6d8(%rsp)
  6e4efc:	movq   $0x8,0x6e0(%rsp)
  6e4f08:	movups %xmm0,0x6e8(%rsp)
  6e4f10:	movq   $0x0,0x7c8(%rsp)
  6e4f1c:	movq   $0x0,0x7d8(%rsp)
  6e4f28:	movl   $0x1000101,0x898(%rsp)
  6e4f33:	movw   $0x0,0x89c(%rsp)
  6e4f3d:	movups %xmm0,0x7e0(%rsp)
  6e4f45:	movq   $0x0,0x7f0(%rsp)
  6e4f51:	movabs $0x19000000190,%rax
  6e4f5b:	mov    %rax,0x7f8(%rsp)
  6e4f63:	movsd  -0x6a45db(%rip),%xmm1        # 40990 <GCC_except_table0+0xbec>
  6e4f6b:	movsd  %xmm1,0x890(%rsp)
  6e4f74:	movq   $0x1,0x738(%rsp)
  6e4f80:	movq   $0xffffffffffffffff,0x708(%rsp)
  6e4f8c:	movq   $0x0,0x800(%rsp)
  6e4f98:	movq   $0x0,0x810(%rsp)
  6e4fa4:	movq   $0x8,0x6f8(%rsp)
  6e4fb0:	movq   $0x0,0x700(%rsp)
  6e4fbc:	movb   $0x0,0x89e(%rsp)
  6e4fc4:	movups %xmm0,0x878(%rsp)
  6e4fcc:	movups %xmm0,0x868(%rsp)
  6e4fd4:	movups %xmm0,0x858(%rsp)
  6e4fdc:	movups %xmm0,0x848(%rsp)
  6e4fe4:	movups %xmm0,0x838(%rsp)
  6e4fec:	movups %xmm0,0x828(%rsp)
  6e4ff4:	movups %xmm0,0x818(%rsp)
  6e4ffc:	movq   $0x0,0x888(%rsp)
  6e5008:	call   *0x35d252(%rip)        # a42260 <_DYNAMIC+0x270>
  6e500e:	mov    $0x790,%edi
  6e5013:	mov    $0x8,%esi
  6e5018:	call   *0x35d24a(%rip)        # a42268 <_DYNAMIC+0x278>
  6e501e:	test   %rax,%rax
  6e5021:	je     6e50d6 <text_column_public_control::mount+0x626>
  6e5027:	mov    %rax,%rbx
  6e502a:	lea    0x110(%rsp),%rsi
  6e5032:	mov    $0x790,%edx
  6e5037:	mov    %rax,%rdi
  6e503a:	call   *0x35d238(%rip)        # a42278 <memcpy@GLIBC_2.14>
  6e5040:	mov    %rbx,0x18(%rsp)
  6e5045:	lea    0x20(%rsp),%rdx
  6e504a:	lea    0x38(%rsp),%rdi
  6e504f:	mov    %rbx,%rsi
  6e5052:	mov    $0x1,%ecx
  6e5057:	call   6e8ca0 <<gpui::runtime::RuntimeMut<text_column_public_control::Model, ()>>::describe_with_changed>
  6e505c:	mov    0x38(%rsp),%r15
  6e5061:	cmp    $0xfffffffffffffffe,%r15
  6e5065:	jne    6e50eb <text_column_public_control::mount+0x63b>
  6e506b:	lea    0x38(%rsp),%rdi
  6e5070:	mov    %rbx,%rsi
  6e5073:	call   71d010 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present>
  6e5078:	mov    0x38(%rsp),%r15
  6e507d:	cmp    $0xfffffffffffffffe,%r15
  6e5081:	jne    6e50eb <text_column_public_control::mount+0x63b>
  6e5083:	mov    0x18(%rsp),%rbx
  6e5088:	lea    0x110(%rsp),%rdi
  6e5090:	mov    %rbx,%rsi
  6e5093:	call   6b5db0 <text_column_public_control::ack::<text_column_public_control::Model>>
  6e5098:	mov    0x20(%rsp),%rax
  6e509d:	mov    %rbx,(%rax)
  6e50a0:	movups 0x110(%rsp),%xmm0
  6e50a8:	movups 0x120(%rsp),%xmm1
  6e50b0:	movups 0x130(%rsp),%xmm2
  6e50b8:	movups %xmm0,0x8(%rax)
  6e50bc:	movups %xmm1,0x18(%rax)
  6e50c0:	movups %xmm2,0x28(%rax)
  6e50c4:	add    $0xd28,%rsp
  6e50cb:	pop    %rbx
  6e50cc:	pop    %r12
  6e50ce:	pop    %r13
  6e50d0:	pop    %r14
  6e50d2:	pop    %r15
  6e50d4:	pop    %rbp
  6e50d5:	ret
  6e50d6:	mov    $0x8,%edi
  6e50db:	mov    $0x790,%esi
  6e50e0:	call   *0x35d18a(%rip)        # a42270 <_DYNAMIC+0x280>
  6e50e6:	jmp    6e5245 <text_column_public_control::mount+0x795>
  6e50eb:	mov    0x40(%rsp),%r14
  6e50f0:	movups 0x48(%rsp),%xmm0
  6e50f5:	movaps %xmm0,0x20(%rsp)
  6e50fa:	movups 0x58(%rsp),%xmm0
  6e50ff:	movaps %xmm0,0x70(%rsp)
  6e5104:	movzbl 0x68(%rsp),%ebp
  6e5109:	mov    0x69(%rsp),%eax
  6e510d:	mov    %eax,0x8(%rsp)
  6e5111:	mov    0x6c(%rsp),%eax
  6e5115:	mov    %eax,0xb(%rsp)
  6e5119:	mov    0x18(%rsp),%rbx
  6e511e:	test   %rbx,%rbx
  6e5121:	je     6e513e <text_column_public_control::mount+0x68e>
  6e5123:	mov    %rbx,%rdi
  6e5126:	call   6c00d0 <core::ptr::drop_glue::<gpui::runtime::Runtime<text_column_public_control::Model>>>
  6e512b:	mov    $0x790,%esi
  6e5130:	mov    $0x8,%edx
  6e5135:	mov    %rbx,%rdi
  6e5138:	call   *0x35d11a(%rip)        # a42258 <_DYNAMIC+0x268>
  6e513e:	mov    %r14,%r13
  6e5141:	shr    $0x20,%r13
  6e5145:	jmp    6e51cb <text_column_public_control::mount+0x71b>
  6e514a:	mov    $0x1,%edi
  6e514f:	mov    $0x13,%esi
  6e5154:	call   *0x35d18e(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  6e515a:	mov    0x118(%rsp),%r13
  6e5162:	mov    %r13,%r14
  6e5165:	shr    $0x20,%r13
  6e5169:	movups 0x120(%rsp),%xmm0
  6e5171:	movaps %xmm0,0x20(%rsp)
  6e5176:	movups 0x130(%rsp),%xmm0
  6e517e:	movaps %xmm0,0x70(%rsp)
  6e5183:	movzbl 0x140(%rsp),%ebp
  6e518b:	mov    0x141(%rsp),%eax
  6e5192:	mov    %eax,0x8(%rsp)
  6e5196:	mov    0x144(%rsp),%eax
  6e519d:	mov    %eax,0xb(%rsp)
  6e51a1:	jmp    6e51b6 <text_column_public_control::mount+0x706>
  6e51a3:	lea    0x88(%rsp),%rdi
  6e51ab:	call   6bf910 <core::ptr::drop_glue::<gpui::source::Sources<text_column_public_control::Input>>>
  6e51b0:	mov    $0x23,%r15d
  6e51b6:	mov    $0x13,%esi
  6e51bb:	mov    $0x1,%edx
  6e51c0:	mov    0x10(%rsp),%rdi
  6e51c5:	call   *0x35d08d(%rip)        # a42258 <_DYNAMIC+0x268>
  6e51cb:	mov    %r15,0x8a0(%rsp)
  6e51d3:	shl    $0x20,%r13
  6e51d7:	mov    %r14d,%eax
  6e51da:	or     %r13,%rax
  6e51dd:	mov    %rax,0x8a8(%rsp)
  6e51e5:	movaps 0x20(%rsp),%xmm0
  6e51ea:	movups %xmm0,0x8b0(%rsp)
  6e51f2:	movaps 0x70(%rsp),%xmm0
  6e51f7:	movups %xmm0,0x8c0(%rsp)
  6e51ff:	mov    %bpl,0x8d0(%rsp)
  6e5207:	mov    0x8(%rsp),%eax
  6e520b:	mov    0xb(%rsp),%ecx
  6e520f:	mov    %eax,0x8d1(%rsp)
  6e5216:	mov    %ecx,0x8d4(%rsp)
  6e521d:	lea    -0x697b45(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6e5224:	lea    0x33dafd(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6e522b:	lea    0x33d7ae(%rip),%r8        # a229e0 <__frame_dummy_init_array_entry+0xef0>
  6e5232:	lea    0x8a0(%rsp),%rdx
  6e523a:	mov    $0x2b,%esi
  6e523f:	call   *0x35cfeb(%rip)        # a42230 <_DYNAMIC+0x240>
  6e5245:	ud2
  6e5247:	mov    %rax,%r14
  6e524a:	mov    $0x790,%esi
  6e524f:	mov    $0x8,%edx
  6e5254:	mov    %rbx,%rdi
  6e5257:	jmp    6e5331 <text_column_public_control::mount+0x881>
  6e525c:	mov    %rax,%r14
  6e525f:	mov    %rbx,%rdi
  6e5262:	call   6bfac0 <core::ptr::drop_glue::<gpui::runtime::Win<text_column_public_control::Model>>>
  6e5267:	jmp    6e536d <text_column_public_control::mount+0x8bd>
  6e526c:	call   *0x35d00e(%rip)        # a42280 <_DYNAMIC+0x290>
  6e5272:	mov    %rax,%r14
  6e5275:	jmp    6e5315 <text_column_public_control::mount+0x865>
  6e527a:	mov    %rax,%rdi
  6e527d:	call   *0x35d24d(%rip)        # a424d0 <_DYNAMIC+0x4e0>
  6e5283:	mov    %rax,%r15
  6e5286:	mov    %rdx,%r12
  6e5289:	mov    (%rdx),%rax
  6e528c:	test   %rax,%rax
  6e528f:	je     6e5296 <text_column_public_control::mount+0x7e6>
  6e5291:	mov    %r15,%rdi
  6e5294:	call   *%rax
  6e5296:	mov    0x8(%r12),%rsi
  6e529b:	test   %rsi,%rsi
  6e529e:	je     6e52ae <text_column_public_control::mount+0x7fe>
  6e52a0:	mov    0x10(%r12),%rdx
  6e52a5:	mov    %r15,%rdi
  6e52a8:	call   *0x35cfaa(%rip)        # a42258 <_DYNAMIC+0x268>
  6e52ae:	mov    $0x13,%esi
  6e52b3:	mov    $0x1,%edx
  6e52b8:	mov    0x10(%rsp),%rdi
  6e52bd:	call   *0x35cf95(%rip)        # a42258 <_DYNAMIC+0x268>
  6e52c3:	mov    $0xf,%r15d
  6e52c9:	jmp    6e51cb <text_column_public_control::mount+0x71b>
  6e52ce:	mov    %rax,%r14
  6e52d1:	mov    0x8(%r12),%rsi
  6e52d6:	test   %rsi,%rsi
  6e52d9:	je     6e5322 <text_column_public_control::mount+0x872>
  6e52db:	mov    0x10(%r12),%rdx
  6e52e0:	mov    %r15,%rdi
  6e52e3:	call   *0x35cf6f(%rip)        # a42258 <_DYNAMIC+0x268>
  6e52e9:	jmp    6e5322 <text_column_public_control::mount+0x872>
  6e52eb:	call   *0x35d1e7(%rip)        # a424d8 <_DYNAMIC+0x4e8>
  6e52f1:	mov    %rax,%r14
  6e52f4:	jmp    6e5322 <text_column_public_control::mount+0x872>
  6e52f6:	mov    %rax,%r14
  6e52f9:	mov    0x18(%rsp),%rdi
  6e52fe:	call   6bfac0 <core::ptr::drop_glue::<gpui::runtime::Win<text_column_public_control::Model>>>
  6e5303:	jmp    6e536d <text_column_public_control::mount+0x8bd>
  6e5305:	mov    %rax,%r14
  6e5308:	lea    0xb40(%rsp),%rdi
  6e5310:	call   6c6030 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  6e5315:	lea    0x88(%rsp),%rdi
  6e531d:	call   6bf910 <core::ptr::drop_glue::<gpui::source::Sources<text_column_public_control::Input>>>
  6e5322:	mov    $0x13,%esi
  6e5327:	mov    $0x1,%edx
  6e532c:	mov    0x10(%rsp),%rdi
  6e5331:	call   *0x35cf21(%rip)        # a42258 <_DYNAMIC+0x268>
  6e5337:	mov    %r14,%rdi
  6e533a:	call   a20740 <_Unwind_Resume@plt>
  6e533f:	call   *0x35cf3b(%rip)        # a42280 <_DYNAMIC+0x290>
  6e5345:	mov    %rax,%r14
  6e5348:	lea    0x8a0(%rsp),%rdi
  6e5350:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e5355:	mov    %r14,%rdi
  6e5358:	call   a20740 <_Unwind_Resume@plt>
  6e535d:	mov    %rax,%r14
  6e5360:	lea    0x110(%rsp),%rdi
  6e5368:	call   6c00d0 <core::ptr::drop_glue::<gpui::runtime::Runtime<text_column_public_control::Model>>>
  6e536d:	mov    %r14,%rdi
  6e5370:	call   a20740 <_Unwind_Resume@plt>
  6e5375:	call   *0x35cf05(%rip)        # a42280 <_DYNAMIC+0x290>

text_column_public_control::pointers code=722 fixed_stack=296

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006e5380 <text_column_public_control::pointers>:
  6e5380:	push   %rbp
  6e5381:	push   %r15
  6e5383:	push   %r14
  6e5385:	push   %r13
  6e5387:	push   %r12
  6e5389:	push   %rbx
  6e538a:	sub    $0xf8,%rsp
  6e5391:	movq   $0x0,0x10(%rsp)
  6e539a:	movq   $0x8,0x18(%rsp)
  6e53a3:	movq   $0x0,0x20(%rsp)
  6e53ac:	test   %rsi,%rsi
  6e53af:	je     6e55c4 <text_column_public_control::pointers+0x244>
  6e53b5:	mov    %rsi,%r14
  6e53b8:	cmpb   $0x0,0x78e(%rsi)
  6e53bf:	jne    6e55cb <text_column_public_control::pointers+0x24b>
  6e53c5:	cmpb   $0x1,0x78c(%r14)
  6e53cd:	jne    6e55d2 <text_column_public_control::pointers+0x252>
  6e53d3:	mov    0x708(%r14),%r12
  6e53da:	mov    0x6e0(%r14),%r13
  6e53e1:	mov    0x5e8(%r14),%r15
  6e53e8:	mov    0x5f0(%r14),%rbp
  6e53ef:	movups 0x658(%r14),%xmm1
  6e53f7:	mov    0x680(%r14),%rbx
  6e53fe:	test   %rbx,%rbx
  6e5401:	mov    %rdi,0x48(%rsp)
  6e5406:	je     6e5447 <text_column_public_control::pointers+0xc7>
  6e5408:	mov    0xe0(%rbx),%rax
  6e540f:	test   %rax,%rax
  6e5412:	je     6e545d <text_column_public_control::pointers+0xdd>
  6e5414:	mov    0x38(%rax),%ecx
  6e5417:	mov    %ecx,0x60(%rsp)
  6e541b:	movups 0x28(%rax),%xmm0
  6e541f:	movaps %xmm0,0x50(%rsp)
  6e5424:	movzbl 0x3c(%rax),%edi
  6e5428:	movzbl 0x3f(%rax),%ecx
  6e542c:	mov    %cl,0xe(%rsp)
  6e5430:	movzwl 0x3d(%rax),%eax
  6e5434:	mov    %ax,0xc(%rsp)
  6e5439:	mov    0x100(%rbx),%rsi
  6e5440:	test   %rsi,%rsi
  6e5443:	jne    6e546c <text_column_public_control::pointers+0xec>
  6e5445:	jmp    6e544a <text_column_public_control::pointers+0xca>
  6e5447:	mov    $0x2,%dil
  6e544a:	movq   $0x4,0x28(%rsp)
  6e5453:	xorps  %xmm0,%xmm0
  6e5456:	movups %xmm0,0x30(%rsp)
  6e545b:	jmp    6e5491 <text_column_public_control::pointers+0x111>
  6e545d:	mov    $0x2,%dil
  6e5460:	mov    0x100(%rbx),%rsi
  6e5467:	test   %rsi,%rsi
  6e546a:	je     6e544a <text_column_public_control::pointers+0xca>
  6e546c:	mov    %dil,0xb(%rsp)
  6e5471:	lea    0x28(%rsp),%rdi
  6e5476:	movaps %xmm1,0xe0(%rsp)
  6e547e:	call   *0x35cdb4(%rip)        # a42238 <_DYNAMIC+0x248>
  6e5484:	movzbl 0xb(%rsp),%edi
  6e5489:	movaps 0xe0(%rsp),%xmm1
  6e5491:	add    $0x620,%r14
  6e5498:	mov    %r14,0xc0(%rsp)
  6e54a0:	mov    %r12,0x90(%rsp)
  6e54a8:	mov    %r13,0x98(%rsp)
  6e54b0:	mov    %r15,0x80(%rsp)
  6e54b8:	mov    %rbp,0x88(%rsp)
  6e54c0:	movaps %xmm1,0x70(%rsp)
  6e54c5:	mov    %rbx,0xa0(%rsp)
  6e54cd:	mov    0x28(%rsp),%rax
  6e54d2:	mov    %rax,0xa8(%rsp)
  6e54da:	mov    0x30(%rsp),%rax
  6e54df:	mov    %rax,0xb0(%rsp)
  6e54e7:	mov    0x38(%rsp),%rax
  6e54ec:	mov    %rax,0xb8(%rsp)
  6e54f4:	movaps 0x50(%rsp),%xmm0
  6e54f9:	movups %xmm0,0xc8(%rsp)
  6e5501:	mov    0x60(%rsp),%eax
  6e5505:	mov    %eax,0xd8(%rsp)
  6e550c:	mov    %dil,0xdc(%rsp)
  6e5514:	movzwl 0xc(%rsp),%eax
  6e5519:	mov    %ax,0xdd(%rsp)
  6e5521:	movzbl 0xe(%rsp),%eax
  6e5526:	mov    %al,0xdf(%rsp)
  6e552d:	test   %rbp,%rbp
  6e5530:	je     6e559c <text_column_public_control::pointers+0x21c>
  6e5532:	xor    %r14d,%r14d
  6e5535:	lea    0x70(%rsp),%r12
  6e553a:	mov    0x35cd07(%rip),%rbx        # a42248 <_DYNAMIC+0x258>
  6e5541:	jmp    6e5569 <text_column_public_control::pointers+0x1e9>
  6e5543:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6e5550:	mov    0x18(%rsp),%rax
  6e5555:	mov    %r15,(%rax,%r13,8)
  6e5559:	inc    %r13
  6e555c:	mov    %r13,0x20(%rsp)
  6e5561:	inc    %r14
  6e5564:	cmp    %r14,%rbp
  6e5567:	je     6e559c <text_column_public_control::pointers+0x21c>
  6e5569:	lea    0x28(%rsp),%rdi
  6e556e:	mov    %r12,%rsi
  6e5571:	mov    %r14,%rdx
  6e5574:	call   *%rbx
  6e5576:	cmpq   $0x0,0x28(%rsp)
  6e557c:	je     6e5561 <text_column_public_control::pointers+0x1e1>
  6e557e:	mov    0x38(%rsp),%r15
  6e5583:	mov    0x20(%rsp),%r13
  6e5588:	cmp    0x10(%rsp),%r13
  6e558d:	jne    6e5550 <text_column_public_control::pointers+0x1d0>
  6e558f:	lea    0x10(%rsp),%rdi
  6e5594:	call   *0x35cfde(%rip)        # a42578 <_DYNAMIC+0x588>
  6e559a:	jmp    6e5550 <text_column_public_control::pointers+0x1d0>
  6e559c:	mov    0x20(%rsp),%rax
  6e55a1:	mov    0x48(%rsp),%rcx
  6e55a6:	mov    %rax,0x10(%rcx)
  6e55aa:	movups 0x10(%rsp),%xmm0
  6e55af:	movups %xmm0,(%rcx)
  6e55b2:	add    $0xf8,%rsp
  6e55b9:	pop    %rbx
  6e55ba:	pop    %r12
  6e55bc:	pop    %r13
  6e55be:	pop    %r14
  6e55c0:	pop    %r15
  6e55c2:	pop    %rbp
  6e55c3:	ret
  6e55c4:	mov    $0xd,%eax
  6e55c9:	jmp    6e55d7 <text_column_public_control::pointers+0x257>
  6e55cb:	mov    $0xe,%eax
  6e55d0:	jmp    6e55d7 <text_column_public_control::pointers+0x257>
  6e55d2:	mov    $0x12,%eax
  6e55d7:	mov    %rax,0x70(%rsp)
  6e55dc:	movq   $0x0,0x78(%rsp)
  6e55e5:	lea    -0x697f0d(%rip),%rdi        # 4d6df <GCC_except_table0+0xd93b>
  6e55ec:	lea    0x33d735(%rip),%rcx        # a22d28 <__frame_dummy_init_array_entry+0x1238>
  6e55f3:	lea    0x33d4d6(%rip),%r8        # a22ad0 <__frame_dummy_init_array_entry+0xfe0>
  6e55fa:	lea    0x70(%rsp),%rdx
  6e55ff:	mov    $0x2b,%esi
  6e5604:	call   *0x35cc26(%rip)        # a42230 <_DYNAMIC+0x240>
  6e560a:	ud2
  6e560c:	mov    %rax,%rbx
  6e560f:	lea    0x70(%rsp),%rdi
  6e5614:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e5619:	mov    %rbx,%rdi
  6e561c:	call   a20740 <_Unwind_Resume@plt>
  6e5621:	mov    %rax,%rbx
  6e5624:	mov    0x10(%rsp),%rsi
  6e5629:	test   %rsi,%rsi
  6e562c:	jne    6e5636 <text_column_public_control::pointers+0x2b6>
  6e562e:	mov    %rbx,%rdi
  6e5631:	call   a20740 <_Unwind_Resume@plt>
  6e5636:	mov    0x18(%rsp),%rdi
  6e563b:	shl    $0x3,%rsi
  6e563f:	mov    $0x8,%edx
  6e5644:	call   *0x35cc0e(%rip)        # a42258 <_DYNAMIC+0x268>
  6e564a:	mov    %rbx,%rdi
  6e564d:	call   a20740 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<text_column_public_control::Input>>::pointer_hit code=93 fixed_stack=8

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006f0490 <<gpui::runtime::Runtime<text_column_public_control::Input>>::pointer_hit>:
  6f0490:	cmpl   $0x1,(%rsi)
  6f0493:	jne    6f04c5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::pointer_hit+0x35>
  6f0495:	push   %rbx
  6f0496:	movss  0x4(%rsi),%xmm0
  6f049b:	movss  0x8(%rsi),%xmm1
  6f04a0:	mov    0x640(%rdi),%rax
  6f04a7:	test   %rax,%rax
  6f04aa:	je     6f04c8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::pointer_hit+0x38>
  6f04ac:	mov    0xd8(%rax),%rax
  6f04b3:	test   %rax,%rax
  6f04b6:	je     6f04c8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::pointer_hit+0x38>
  6f04b8:	cmpb   $0x0,0x12(%rax)
  6f04bc:	je     6f04c8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::pointer_hit+0x38>
  6f04be:	call   6f1770 <<gpui::runtime::Runtime<text_column_public_control::Input>>::inspector_pick>
  6f04c3:	pop    %rbx
  6f04c4:	ret
  6f04c5:	xor    %eax,%eax
  6f04c7:	ret
  6f04c8:	mov    %rdi,%rbx
  6f04cb:	call   70cd60 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit>
  6f04d0:	test   $0x1,%al
  6f04d2:	je     6f04e9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::pointer_hit+0x59>
  6f04d4:	mov    %rbx,%rdi
  6f04d7:	add    $0x5e0,%rdi
  6f04de:	mov    %rdx,%rsi
  6f04e1:	call   *0x351fa9(%rip)        # a42490 <_DYNAMIC+0x4a0>
  6f04e7:	pop    %rbx
  6f04e8:	ret
  6f04e9:	xor    %eax,%eax
  6f04eb:	pop    %rbx
  6f04ec:	ret

<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge code=1452 fixed_stack=184

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006fdef0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge>:
  6fdef0:	push   %r15
  6fdef2:	push   %r14
  6fdef4:	push   %r12
  6fdef6:	push   %rbx
  6fdef7:	sub    $0x98,%rsp
  6fdefe:	mov    %rdi,%r14
  6fdf01:	cmp    %rdx,0x6b0(%rsi)
  6fdf08:	jne    6fe23a <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x34a>
  6fdf0e:	mov    %rsi,%rbx
  6fdf11:	cmp    %rcx,0x6b8(%rsi)
  6fdf18:	jne    6fe23a <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x34a>
  6fdf1e:	lea    0x5f0(%rbx),%rdi
  6fdf25:	mov    %rcx,%rsi
  6fdf28:	call   *0x3447ca(%rip)        # a426f8 <_DYNAMIC+0x708>
  6fdf2e:	mov    0x5d8(%rbx),%rax
  6fdf35:	mov    %rax,0x30(%rsp)
  6fdf3a:	movdqu 0x5b8(%rbx),%xmm0
  6fdf42:	movdqu 0x5c8(%rbx),%xmm1
  6fdf4a:	movdqa %xmm0,0x10(%rsp)
  6fdf50:	movq   $0xffffffffffffffff,0x5b8(%rbx)
  6fdf5b:	movzbl 0x74c(%rbx),%eax
  6fdf62:	xor    $0x1,%rax
  6fdf66:	cmpq   $0xffffffffffffffff,0x10(%rsp)
  6fdf6c:	movdqa %xmm1,0x20(%rsp)
  6fdf72:	mov    $0x1,%r12d
  6fdf78:	cmove  %rax,%r12
  6fdf7c:	je     6fe022 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x132>
  6fdf82:	movdqa 0x30(%rsp),%xmm0
  6fdf88:	movss  0x34(%rsp),%xmm2
  6fdf8e:	movd   %xmm0,%eax
  6fdf92:	pand   -0x6bca5a(%rip),%xmm0        # 41540 <GCC_except_table0+0x179c>
  6fdf9a:	pxor   %xmm1,%xmm1
  6fdf9e:	punpcklwd %xmm1,%xmm0
  6fdfa2:	movq   %xmm0,0x6a0(%rbx)
  6fdfaa:	test   %ax,%ax
  6fdfad:	js     6fe246 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x356>
  6fdfb3:	movss  %xmm2,0xc(%rsp)
  6fdfb9:	lea    0x5a0(%rbx),%r15
  6fdfc0:	mov    %r15,%rdi
  6fdfc3:	call   6c1190 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  6fdfc8:	mov    0x20(%rsp),%rax
  6fdfcd:	mov    %rax,0x10(%r15)
  6fdfd1:	movaps 0x10(%rsp),%xmm0
  6fdfd6:	movups %xmm0,(%r15)
  6fdfda:	mov    0x6c8(%rbx),%rdi
  6fdfe1:	test   %rdi,%rdi
  6fdfe4:	je     6fdfec <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0xfc>
  6fdfe6:	call   *0x344714(%rip)        # a42700 <_DYNAMIC+0x710>
  6fdfec:	mov    0x640(%rbx),%rax
  6fdff3:	test   %rax,%rax
  6fdff6:	je     6fe014 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x124>
  6fdff8:	mov    0xe0(%rax),%rax
  6fdfff:	test   %rax,%rax
  6fe002:	je     6fe014 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x124>
  6fe004:	mov    0x50(%rax),%rcx
  6fe008:	mov    %rcx,0x38(%rax)
  6fe00c:	movups 0x40(%rax),%xmm0
  6fe010:	movups %xmm0,0x28(%rax)
  6fe014:	movd   0xc(%rsp),%xmm0
  6fe01a:	movd   %xmm0,0x744(%rbx)
  6fe022:	mov    0x640(%rbx),%rax
  6fe029:	test   %rax,%rax
  6fe02c:	je     6fe268 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe032:	mov    0x60(%rax),%r15
  6fe036:	movq   $0xffffffffffffffff,0x60(%rax)
  6fe03e:	cmp    $0xffffffffffffffff,%r15
  6fe042:	je     6fe0e6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x1f6>
  6fe048:	mov    0xb8(%rax),%rcx
  6fe04f:	mov    %rcx,0x90(%rsp)
  6fe057:	movups 0xa8(%rax),%xmm0
  6fe05e:	movaps %xmm0,0x80(%rsp)
  6fe066:	movups 0x68(%rax),%xmm0
  6fe06a:	movups 0x78(%rax),%xmm1
  6fe06e:	movups 0x88(%rax),%xmm2
  6fe075:	movups 0x98(%rax),%xmm3
  6fe07c:	movaps %xmm3,0x70(%rsp)
  6fe081:	movaps %xmm2,0x60(%rsp)
  6fe086:	movaps %xmm1,0x50(%rsp)
  6fe08b:	movaps %xmm0,0x40(%rsp)
  6fe090:	mov    0x640(%rbx),%rdi
  6fe097:	call   6c76d0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  6fe09c:	mov    0x640(%rbx),%rax
  6fe0a3:	mov    %r15,(%rax)
  6fe0a6:	movaps 0x40(%rsp),%xmm0
  6fe0ab:	movdqa 0x50(%rsp),%xmm1
  6fe0b1:	movaps 0x60(%rsp),%xmm2
  6fe0b6:	movaps 0x70(%rsp),%xmm3
  6fe0bb:	movups %xmm0,0x8(%rax)
  6fe0bf:	movdqu %xmm1,0x18(%rax)
  6fe0c4:	movups %xmm2,0x28(%rax)
  6fe0c8:	movups %xmm3,0x38(%rax)
  6fe0cc:	movdqa 0x80(%rsp),%xmm0
  6fe0d5:	movdqu %xmm0,0x48(%rax)
  6fe0da:	mov    0x90(%rsp),%rcx
  6fe0e2:	mov    %rcx,0x58(%rax)
  6fe0e6:	mov    0x640(%rbx),%r15
  6fe0ed:	test   %r15,%r15
  6fe0f0:	je     6fe268 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe0f6:	mov    0x100(%r15),%rdi
  6fe0fd:	test   %rdi,%rdi
  6fe100:	je     6fe150 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x260>
  6fe102:	call   *0x344600(%rip)        # a42708 <_DYNAMIC+0x718>
  6fe108:	mov    0x100(%r15),%rax
  6fe10f:	cmpq   $0x0,0x10(%rax)
  6fe114:	jne    6fe150 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x260>
  6fe116:	cmpq   $0x0,0x58(%rax)
  6fe11b:	jne    6fe150 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x260>
  6fe11d:	cmpq   $0x0,0x28(%rax)
  6fe122:	jne    6fe150 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x260>
  6fe124:	cmpq   $0xffffffffffffffff,0x30(%rax)
  6fe129:	jne    6fe150 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x260>
  6fe12b:	mov    0x640(%rbx),%rax
  6fe132:	mov    0x100(%rax),%rdi
  6fe139:	call   6bf280 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::geometry::Geometry>>>>
  6fe13e:	mov    0x640(%rbx),%rax
  6fe145:	movq   $0x0,0x100(%rax)
  6fe150:	mov    0x640(%rbx),%r15
  6fe157:	test   %r15,%r15
  6fe15a:	je     6fe268 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe160:	mov    0xe0(%r15),%rdi
  6fe167:	test   %rdi,%rdi
  6fe16a:	je     6fe1b0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x2c0>
  6fe16c:	cmpb   $0x2,0x24(%rdi)
  6fe170:	jne    6fe1b0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x2c0>
  6fe172:	cmpb   $0x2,0x3c(%rdi)
  6fe176:	jne    6fe1b0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x2c0>
  6fe178:	cmpb   $0x2,0x54(%rdi)
  6fe17c:	jne    6fe1b0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x2c0>
  6fe17e:	mov    $0x58,%esi
  6fe183:	mov    $0x8,%edx
  6fe188:	call   *0x3440ca(%rip)        # a42258 <_DYNAMIC+0x268>
  6fe18e:	mov    0x640(%rbx),%rax
  6fe195:	movq   $0x0,0xe0(%rax)
  6fe1a0:	mov    0x640(%rbx),%r15
  6fe1a7:	test   %r15,%r15
  6fe1aa:	je     6fe268 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe1b0:	cmpq   $0x0,0xd8(%r15)
  6fe1b8:	jne    6fe268 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe1be:	cmpq   $0x0,0xe0(%r15)
  6fe1c6:	jne    6fe268 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe1cc:	cmpq   $0x0,0x100(%r15)
  6fe1d4:	jne    6fe268 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe1da:	cmpq   $0x0,0xd0(%r15)
  6fe1e2:	jne    6fe268 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe1e8:	cmpq   $0x0,0xf8(%r15)
  6fe1f0:	jne    6fe268 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe1f2:	mov    0x60(%r15),%rax
  6fe1f6:	cmp    $0xffffffff,%eax
  6fe1f9:	jne    6fe268 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe1fb:	cmpq   $0x0,0x28(%r15)
  6fe200:	jne    6fe268 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe202:	mov    (%r15),%rax
  6fe205:	or     0x40(%r15),%rax
  6fe209:	jne    6fe268 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe20b:	cmpq   $0x0,0x58(%r15)
  6fe210:	jne    6fe268 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe212:	mov    %r15,%rdi
  6fe215:	call   6c7770 <core::ptr::drop_glue::<gpui::runtime::metadata::Metadata>>
  6fe21a:	mov    $0x108,%esi
  6fe21f:	mov    $0x8,%edx
  6fe224:	mov    %r15,%rdi
  6fe227:	call   *0x34402b(%rip)        # a42258 <_DYNAMIC+0x268>
  6fe22d:	movq   $0x0,0x640(%rbx)
  6fe238:	jmp    6fe268 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe23a:	movq   $0x15,(%r14)
  6fe241:	jmp    6fe3b3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x4c3>
  6fe246:	movss  %xmm2,0x744(%rbx)
  6fe24e:	lea    0x10(%rsp),%rdi
  6fe253:	call   6c1190 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  6fe258:	mov    0x640(%rbx),%rax
  6fe25f:	test   %rax,%rax
  6fe262:	jne    6fe032 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x142>
  6fe268:	mov    0x6c8(%rbx),%rdi
  6fe26f:	test   %rdi,%rdi
  6fe272:	je     6fe299 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x3a9>
  6fe274:	cmpq   $0x0,0x30(%rdi)
  6fe279:	jne    6fe299 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x3a9>
  6fe27b:	cmpq   $0x0,0x10(%rdi)
  6fe280:	jne    6fe299 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x3a9>
  6fe282:	cmpq   $0xffffffffffffffff,0x18(%rdi)
  6fe287:	jne    6fe299 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x3a9>
  6fe289:	call   6bf110 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::text_geometry::TextResources>>>>
  6fe28e:	movq   $0x0,0x6c8(%rbx)
  6fe299:	mov    0x618(%rbx),%rax
  6fe2a0:	test   %rax,%rax
  6fe2a3:	je     6fe34b <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x45b>
  6fe2a9:	cmp    0x5e0(%rbx),%rax
  6fe2b0:	jne    6fe340 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x450>
  6fe2b6:	mov    0x620(%rbx),%rdx
  6fe2bd:	lea    0x40(%rsp),%rdi
  6fe2c2:	mov    %rbx,%rsi
  6fe2c5:	call   70ca80 <<gpui::runtime::Runtime<text_column_public_control::Input>>::resolve_identity>
  6fe2ca:	mov    0x40(%rsp),%rax
  6fe2cf:	mov    0x48(%rsp),%rsi
  6fe2d4:	cmp    $0xfffffffffffffffe,%rax
  6fe2d8:	jne    6fe305 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x415>
  6fe2da:	mov    0x2d0(%rbx),%rax
  6fe2e1:	cmp    %rax,%rsi
  6fe2e4:	jae    6fe3c2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x4d2>
  6fe2ea:	lea    (%rsi,%rsi,4),%rdi
  6fe2ee:	shl    $0x3,%rdi
  6fe2f2:	add    0x2c8(%rbx),%rdi
  6fe2f9:	call   *0x344241(%rip)        # a42540 <_DYNAMIC+0x550>
  6fe2ff:	test   %al,%al
  6fe301:	je     6fe340 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x450>
  6fe303:	jmp    6fe34b <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x45b>
  6fe305:	cmp    $0xd,%rax
  6fe309:	jl     6fe323 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x433>
  6fe30b:	cmp    $0x21,%rax
  6fe30f:	je     6fe323 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x433>
  6fe311:	cmp    $0x26,%rax
  6fe315:	jne    6fe340 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x450>
  6fe317:	test   %rsi,%rsi
  6fe31a:	je     6fe340 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x450>
  6fe31c:	lea    0x50(%rsp),%rax
  6fe321:	jmp    6fe332 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x442>
  6fe323:	mov    0x58(%rsp),%rsi
  6fe328:	test   %rsi,%rsi
  6fe32b:	je     6fe340 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x450>
  6fe32d:	lea    0x60(%rsp),%rax
  6fe332:	mov    (%rax),%rdi
  6fe335:	mov    $0x1,%edx
  6fe33a:	call   *0x343f18(%rip)        # a42258 <_DYNAMIC+0x268>
  6fe340:	movq   $0x0,0x618(%rbx)
  6fe34b:	mov    0x6c0(%rbx),%rax
  6fe352:	mov    %rax,0x698(%rbx)
  6fe359:	movb   $0x1,0x74c(%rbx)
  6fe360:	add    %r12,0x718(%rbx)
  6fe367:	cmpq   $0x0,0x6b0(%rbx)
  6fe36f:	setne  %cl
  6fe372:	cmpq   $0xffffffffffffffff,0x5b8(%rbx)
  6fe37a:	mov    0x690(%rbx),%rdx
  6fe381:	setne  %sil
  6fe385:	and    %cl,%sil
  6fe388:	movzbl %sil,%ecx
  6fe38c:	mov    0x738(%rbx),%rsi
  6fe393:	mov    %rcx,0x8(%r14)
  6fe397:	mov    %rax,0x10(%r14)
  6fe39b:	mov    %rdx,0x18(%r14)
  6fe39f:	mov    %rax,0x20(%r14)
  6fe3a3:	mov    %rsi,0x28(%r14)
  6fe3a7:	movb   $0x1,0x30(%r14)
  6fe3ac:	movq   $0xfffffffffffffffe,(%r14)
  6fe3b3:	add    $0x98,%rsp
  6fe3ba:	pop    %rbx
  6fe3bb:	pop    %r12
  6fe3bd:	pop    %r14
  6fe3bf:	pop    %r15
  6fe3c1:	ret
  6fe3c2:	lea    0x323e57(%rip),%rdx        # a22220 <__frame_dummy_init_array_entry+0x730>
  6fe3c9:	mov    %rsi,%rdi
  6fe3cc:	mov    %rax,%rsi
  6fe3cf:	call   *0x343eb3(%rip)        # a42288 <_DYNAMIC+0x298>
  6fe3d5:	mov    %rax,%r14
  6fe3d8:	mov    $0x108,%esi
  6fe3dd:	mov    $0x8,%edx
  6fe3e2:	mov    %r15,%rdi
  6fe3e5:	call   *0x343e6d(%rip)        # a42258 <_DYNAMIC+0x268>
  6fe3eb:	movq   $0x0,0x640(%rbx)
  6fe3f6:	mov    %r14,%rdi
  6fe3f9:	call   a20740 <_Unwind_Resume@plt>
  6fe3fe:	mov    %rax,%r14
  6fe401:	mov    0x640(%rbx),%rax
  6fe408:	movq   $0x0,0x100(%rax)
  6fe413:	mov    %r14,%rdi
  6fe416:	call   a20740 <_Unwind_Resume@plt>
  6fe41b:	movq   $0x0,0x6c8(%rbx)
  6fe426:	mov    %rax,%rdi
  6fe429:	call   a20740 <_Unwind_Resume@plt>
  6fe42e:	mov    %rax,%r14
  6fe431:	mov    0x640(%rbx),%rax
  6fe438:	mov    %r15,(%rax)
  6fe43b:	movaps 0x40(%rsp),%xmm0
  6fe440:	movaps 0x50(%rsp),%xmm1
  6fe445:	movaps 0x60(%rsp),%xmm2
  6fe44a:	movaps 0x70(%rsp),%xmm3
  6fe44f:	movups %xmm0,0x8(%rax)
  6fe453:	movups %xmm1,0x18(%rax)
  6fe457:	movups %xmm2,0x28(%rax)
  6fe45b:	movups %xmm3,0x38(%rax)
  6fe45f:	movaps 0x80(%rsp),%xmm0
  6fe467:	movups %xmm0,0x48(%rax)
  6fe46b:	mov    0x90(%rsp),%rcx
  6fe473:	mov    %rcx,0x58(%rax)
  6fe477:	mov    %r14,%rdi
  6fe47a:	call   a20740 <_Unwind_Resume@plt>
  6fe47f:	mov    %rax,%r14
  6fe482:	mov    0x20(%rsp),%rax
  6fe487:	mov    %rax,0x10(%r15)
  6fe48b:	movaps 0x10(%rsp),%xmm0
  6fe490:	movups %xmm0,(%r15)
  6fe494:	mov    %r14,%rdi
  6fe497:	call   a20740 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner code=21547 fixed_stack=3624

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006fe4a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner>:
  6fe4a0:	push   %rbp
  6fe4a1:	push   %r15
  6fe4a3:	push   %r14
  6fe4a5:	push   %r13
  6fe4a7:	push   %r12
  6fe4a9:	push   %rbx
  6fe4aa:	sub    $0xdf8,%rsp
  6fe4b1:	mov    %rdi,0x40(%rsp)
  6fe4b6:	mov    0x5e8(%rsi),%rax
  6fe4bd:	mov    %rax,0x308(%rsp)
  6fe4c5:	inc    %rax
  6fe4c8:	je     702a5e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x45be>
  6fe4ce:	mov    %rsi,%r14
  6fe4d1:	mov    %rax,0x820(%rsp)
  6fe4d9:	mov    0x5e0(%rsi),%rax
  6fe4e0:	mov    %rax,0x350(%rsp)
  6fe4e8:	mov    0x6a8(%rsi),%rsi
  6fe4ef:	movq   %rsi,%xmm0
  6fe4f4:	movdqa %xmm0,0x80(%rsp)
  6fe4fd:	pshufd $0x55,%xmm0,%xmm0
  6fe502:	movd   %xmm0,%edx
  6fe506:	movss  0x740(%r14),%xmm0
  6fe50f:	movss  %xmm0,0x9c(%rsp)
  6fe518:	mov    0x1a8(%r14),%eax
  6fe51f:	mov    0x1b0(%r14),%rcx
  6fe526:	shl    $0x20,%rcx
  6fe52a:	or     %rax,%rcx
  6fe52d:	cmp    %rsi,%rcx
  6fe530:	mov    %r14,0x38(%rsp)
  6fe535:	mov    %rsi,0x310(%rsp)
  6fe53d:	mov    %edx,0x194(%rsp)
  6fe544:	jne    6fe56d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xcd>
  6fe546:	movq   $0x2,0xc10(%rsp)
  6fe552:	mov    $0x2,%ebx
  6fe557:	cmpl   $0xffff,0x310(%rsp)
  6fe562:	jbe    6fe60c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x16c>
  6fe568:	jmp    6fe619 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x179>
  6fe56d:	movups 0x138(%r14),%xmm0
  6fe575:	movaps %xmm0,0x8f0(%rsp)
  6fe57d:	lea    0x4b0(%rsp),%rdi
  6fe585:	lea    0x8f0(%rsp),%rcx
  6fe58d:	call   *0x343f6d(%rip)        # a42500 <_DYNAMIC+0x510>
  6fe593:	mov    0x4b0(%rsp),%rbx
  6fe59b:	mov    0x4b8(%rsp),%r14d
  6fe5a3:	mov    0x4bc(%rsp),%ebp
  6fe5aa:	cmp    $0x2,%rbx
  6fe5ae:	jne    6fe5c8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x128>
  6fe5b0:	mov    0x40(%rsp),%rax
  6fe5b5:	movq   $0x23,(%rax)
  6fe5bc:	mov    %r14d,0x8(%rax)
  6fe5c0:	mov    %ebp,0xc(%rax)
  6fe5c3:	jmp    6ffd16 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1876>
  6fe5c8:	lea    0x4c0(%rsp),%rsi
  6fe5d0:	lea    0xc20(%rsp),%rdi
  6fe5d8:	mov    $0x1d8,%edx
  6fe5dd:	call   *0x343c95(%rip)        # a42278 <memcpy@GLIBC_2.14>
  6fe5e3:	mov    %rbx,0xc10(%rsp)
  6fe5eb:	mov    %r14d,0xc18(%rsp)
  6fe5f3:	mov    %ebp,0xc1c(%rsp)
  6fe5fa:	mov    0x38(%rsp),%r14
  6fe5ff:	cmpl   $0xffff,0x310(%rsp)
  6fe60a:	ja     6fe619 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x179>
  6fe60c:	cmpl   $0xffff,0x194(%rsp)
  6fe617:	jbe    6fe63a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x19a>
  6fe619:	mov    0x40(%rsp),%rax
  6fe61e:	movq   $0x23,(%rax)
  6fe625:	movl   $0x0,0x8(%rax)
  6fe62c:	cmp    $0x2,%ebx
  6fe62f:	jne    6ffd09 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1869>
  6fe635:	jmp    6ffd16 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1876>
  6fe63a:	cmpq   $0x0,0x2e8(%r14)
  6fe642:	je     6fe657 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1b7>
  6fe644:	mov    0x6c8(%r14),%rax
  6fe64b:	test   %rax,%rax
  6fe64e:	je     6fe66c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1cc>
  6fe650:	cmpq   $0x0,0x30(%rax)
  6fe655:	je     6fe6b9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x219>
  6fe657:	mov    0x6c8(%r14),%rax
  6fe65e:	test   %rax,%rax
  6fe661:	jne    6fe7b7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x317>
  6fe667:	jmp    6fe814 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x374>
  6fe66c:	call   *0x343bee(%rip)        # a42260 <_DYNAMIC+0x270>
  6fe672:	mov    $0x78,%edi
  6fe677:	mov    $0x8,%esi
  6fe67c:	call   *0x343be6(%rip)        # a42268 <_DYNAMIC+0x278>
  6fe682:	test   %rax,%rax
  6fe685:	je     702e7e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x49de>
  6fe68b:	movq   $0x0,(%rax)
  6fe692:	movq   $0x8,0x8(%rax)
  6fe69a:	movq   $0x0,0x10(%rax)
  6fe6a2:	movq   $0xffffffffffffffff,0x18(%rax)
  6fe6aa:	movq   $0x0,0x30(%rax)
  6fe6b2:	mov    %rax,0x6c8(%r14)
  6fe6b9:	mov    $0x1,%bpl
  6fe6bc:	lea    0x4b0(%rsp),%rdi
  6fe6c4:	call   *0x344046(%rip)        # a42710 <_DYNAMIC+0x720>
  6fe6ca:	mov    0x4b0(%rsp),%r12
  6fe6d2:	mov    0x4b8(%rsp),%r14d
  6fe6da:	mov    0x4bc(%rsp),%ebp
  6fe6e1:	test   %r12,%r12
  6fe6e4:	je     6ffc22 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1782>
  6fe6ea:	mov    0x4f0(%rsp),%rax
  6fe6f2:	mov    %rax,0x920(%rsp)
  6fe6fa:	movups 0x4c0(%rsp),%xmm0
  6fe702:	movups 0x4d0(%rsp),%xmm1
  6fe70a:	movups 0x4e0(%rsp),%xmm2
  6fe712:	movaps %xmm2,0x910(%rsp)
  6fe71a:	movaps %xmm1,0x900(%rsp)
  6fe722:	movaps %xmm0,0x8f0(%rsp)
  6fe72a:	mov    0x38(%rsp),%rax
  6fe72f:	mov    0x6c8(%rax),%r15
  6fe736:	mov    0x30(%r15),%rax
  6fe73a:	test   %rax,%rax
  6fe73d:	je     6fe767 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2c7>
  6fe73f:	lock decq (%rax)
  6fe743:	jne    6fe74f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2af>
  6fe745:	lea    0x30(%r15),%rdi
  6fe749:	call   *0x343bd9(%rip)        # a42328 <_DYNAMIC+0x338>
  6fe74f:	add    $0x38,%r15
  6fe753:	mov    %r15,%rdi
  6fe756:	call   6c5ce0 <core::ptr::drop_glue::<gpui_canvas::text::RasterCache>>
  6fe75b:	mov    0x38(%rsp),%rax
  6fe760:	mov    0x6c8(%rax),%r15
  6fe767:	mov    %r12,0x30(%r15)
  6fe76b:	mov    %r14d,0x38(%r15)
  6fe76f:	mov    %ebp,0x3c(%r15)
  6fe773:	movaps 0x8f0(%rsp),%xmm0
  6fe77b:	movaps 0x900(%rsp),%xmm1
  6fe783:	movaps 0x910(%rsp),%xmm2
  6fe78b:	movups %xmm0,0x40(%r15)
  6fe790:	movups %xmm1,0x50(%r15)
  6fe795:	movups %xmm2,0x60(%r15)
  6fe79a:	mov    0x920(%rsp),%rax
  6fe7a2:	mov    %rax,0x70(%r15)
  6fe7a6:	mov    0x38(%rsp),%r14
  6fe7ab:	mov    0x6c8(%r14),%rax
  6fe7b2:	test   %rax,%rax
  6fe7b5:	je     6fe814 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x374>
  6fe7b7:	mov    0x30(%rax),%rax
  6fe7bb:	test   %rax,%rax
  6fe7be:	je     6fe814 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x374>
  6fe7c0:	lock incq (%rax)
  6fe7c4:	jle    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  6fe7ca:	mov    %rax,0x140(%rsp)
  6fe7d2:	movq   $0x0,0x288(%rsp)
  6fe7de:	movq   $0x8,0x290(%rsp)
  6fe7ea:	movq   $0x0,0x298(%rsp)
  6fe7f6:	lea    0x140(%rsp),%rax
  6fe7fe:	mov    %rax,0x1c8(%rsp)
  6fe806:	movq   $0x0,0x1d0(%rsp)
  6fe812:	jmp    6fe850 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3b0>
  6fe814:	movq   $0x0,0x140(%rsp)
  6fe820:	movq   $0x0,0x288(%rsp)
  6fe82c:	movq   $0x8,0x290(%rsp)
  6fe838:	movq   $0x0,0x298(%rsp)
  6fe844:	movq   $0x0,0x1c8(%rsp)
  6fe850:	lea    0x458(%rsp),%rdi
  6fe858:	mov    %r14,%rsi
  6fe85b:	call   6ec150 <<gpui::runtime::Runtime<text_column_public_control::Input>>::active_selection>
  6fe860:	lea    0x4b0(%rsp),%rdi
  6fe868:	mov    %r14,%rsi
  6fe86b:	call   6ec150 <<gpui::runtime::Runtime<text_column_public_control::Input>>::active_selection>
  6fe870:	movzbl 0x4c4(%rsp),%ebx
  6fe878:	cmp    $0x2,%bl
  6fe87b:	je     6fe8d3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x433>
  6fe87d:	mov    0x4b0(%rsp),%rax
  6fe885:	mov    %rax,0x818(%rsp)
  6fe88d:	test   %rax,%rax
  6fe890:	je     702e60 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x49c0>
  6fe896:	mov    0x4c0(%rsp),%eax
  6fe89d:	mov    %eax,0x370(%rsp)
  6fe8a4:	mov    0x4b8(%rsp),%rax
  6fe8ac:	mov    %rax,0x368(%rsp)
  6fe8b4:	movzwl 0x4c5(%rsp),%eax
  6fe8bc:	mov    %ax,0x12c(%rsp)
  6fe8c4:	movzbl 0x4c7(%rsp),%eax
  6fe8cc:	mov    %al,0x12e(%rsp)
  6fe8d3:	lea    0x2f0(%r14),%rax
  6fe8da:	mov    %rax,0x68(%rsp)
  6fe8df:	cmpb   $0x0,0x748(%r14)
  6fe8e7:	mov    %bl,0x9b(%rsp)
  6fe8ee:	jne    6fec42 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x7a2>
  6fe8f4:	cmpb   $0x0,0x749(%r14)
  6fe8fc:	jne    6fec42 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x7a2>
  6fe902:	cmpb   $0x0,0x580(%r14)
  6fe90a:	jne    6fec42 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x7a2>
  6fe910:	mov    0x648(%r14),%rax
  6fe917:	mov    0x658(%r14),%r15
  6fe91e:	test   %rax,%rax
  6fe921:	setne  %cl
  6fe924:	test   %r15,%r15
  6fe927:	setne  %dl
  6fe92a:	and    %cl,%dl
  6fe92c:	cmp    $0x1,%dl
  6fe92f:	jne    6ff186 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xce6>
  6fe935:	mov    0x38(%rsp),%rcx
  6fe93a:	mov    0x650(%rcx),%r14
  6fe941:	lea    0x1e8(%rcx),%rdx
  6fe948:	mov    %rdx,0x50(%rsp)
  6fe94d:	add    $0x678,%rcx
  6fe954:	mov    %rcx,0x70(%rsp)
  6fe959:	xor    %ebx,%ebx
  6fe95b:	lea    0x324d96(%rip),%rcx        # a236f8 <__frame_dummy_init_array_entry+0x1c08>
  6fe962:	mov    %rcx,0x48(%rsp)
  6fe967:	jmp    6fe98b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4eb>
  6fe969:	nopl   0x0(%rax)
  6fe970:	mov    0x70(%rsp),%rdi
  6fe975:	mov    %r12,%rsi
  6fe978:	call   6fc490 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6fe97d:	mov    $0x0,%eax
  6fe982:	dec    %r15
  6fe985:	je     6ff186 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xce6>
  6fe98b:	test   %rbx,%rbx
  6fe98e:	je     6fe9b0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x510>
  6fe990:	movzwl 0x58a(%rbx),%ecx
  6fe997:	cmp    %rcx,%r14
  6fe99a:	jae    6fea60 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5c0>
  6fe9a0:	mov    %rbx,%rcx
  6fe9a3:	mov    %r14,%rdx
  6fe9a6:	jmp    6fea86 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5e6>
  6fe9ab:	nopl   0x0(%rax,%rax,1)
  6fe9b0:	test   %r14,%r14
  6fe9b3:	je     6fe9ed <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x54d>
  6fe9b5:	mov    %r14,%rcx
  6fe9b8:	mov    %rax,%rbx
  6fe9bb:	and    $0x7,%rcx
  6fe9bf:	je     6fe9f2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x552>
  6fe9c1:	xor    %edx,%edx
  6fe9c3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fe9d0:	mov    0x590(%rbx),%rbx
  6fe9d7:	inc    %rdx
  6fe9da:	cmp    %rdx,%rcx
  6fe9dd:	jne    6fe9d0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x530>
  6fe9df:	mov    %r14,%rax
  6fe9e2:	sub    %rdx,%rax
  6fe9e5:	cmp    $0x8,%r14
  6fe9e9:	jae    6fea00 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x560>
  6fe9eb:	jmp    6fea3e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x59e>
  6fe9ed:	mov    %rax,%rbx
  6fe9f0:	jmp    6fea3e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x59e>
  6fe9f2:	mov    %r14,%rax
  6fe9f5:	cmp    $0x8,%r14
  6fe9f9:	jb     6fea3e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x59e>
  6fe9fb:	nopl   0x0(%rax,%rax,1)
  6fea00:	mov    0x590(%rbx),%rcx
  6fea07:	mov    0x590(%rcx),%rcx
  6fea0e:	mov    0x590(%rcx),%rcx
  6fea15:	mov    0x590(%rcx),%rcx
  6fea1c:	mov    0x590(%rcx),%rcx
  6fea23:	mov    0x590(%rcx),%rcx
  6fea2a:	mov    0x590(%rcx),%rcx
  6fea31:	mov    0x590(%rcx),%rbx
  6fea38:	add    $0xfffffffffffffff8,%rax
  6fea3c:	jne    6fea00 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x560>
  6fea3e:	xor    %eax,%eax
  6fea40:	xor    %r14d,%r14d
  6fea43:	movzwl 0x58a(%rbx),%ecx
  6fea4a:	cmp    %rcx,%r14
  6fea4d:	jb     6fe9a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x500>
  6fea53:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fea60:	mov    0x580(%rbx),%rcx
  6fea67:	test   %rcx,%rcx
  6fea6a:	je     702e96 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x49f6>
  6fea70:	inc    %rax
  6fea73:	movzwl 0x588(%rbx),%edx
  6fea7a:	mov    %rcx,%rbx
  6fea7d:	cmp    0x58a(%rcx),%dx
  6fea84:	jae    6fea60 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5c0>
  6fea86:	test   %rax,%rax
  6fea89:	je     6feb20 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x680>
  6fea8f:	lea    (%rcx,%rdx,8),%rsi
  6fea93:	add    $0x598,%rsi
  6fea9a:	mov    %rax,%rdi
  6fea9d:	and    $0x7,%rdi
  6feaa1:	je     6fec30 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x790>
  6feaa7:	xor    %r8d,%r8d
  6feaaa:	nopw   0x0(%rax,%rax,1)
  6feab0:	mov    (%rsi),%rbx
  6feab3:	lea    0x590(%rbx),%rsi
  6feaba:	inc    %r8
  6feabd:	cmp    %r8,%rdi
  6feac0:	jne    6feab0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x610>
  6feac2:	mov    %rax,%rdi
  6feac5:	sub    %r8,%rdi
  6feac8:	cmp    $0x8,%rax
  6feacc:	jb     6feb11 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x671>
  6feace:	xchg   %ax,%ax
  6fead0:	mov    (%rsi),%rax
  6fead3:	mov    0x590(%rax),%rax
  6feada:	mov    0x590(%rax),%rax
  6feae1:	mov    0x590(%rax),%rax
  6feae8:	mov    0x590(%rax),%rax
  6feaef:	mov    0x590(%rax),%rax
  6feaf6:	mov    0x590(%rax),%rax
  6feafd:	mov    0x590(%rax),%rbx
  6feb04:	lea    0x590(%rbx),%rsi
  6feb0b:	add    $0xfffffffffffffff8,%rdi
  6feb0f:	jne    6fead0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x630>
  6feb11:	xor    %r14d,%r14d
  6feb14:	jmp    6feb27 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x687>
  6feb16:	cs nopw 0x0(%rax,%rax,1)
  6feb20:	lea    0x1(%rdx),%r14
  6feb24:	mov    %rcx,%rbx
  6feb27:	imul   $0x70,%rdx,%rax
  6feb2b:	shl    $0x4,%rdx
  6feb2f:	lea    (%rcx,%rax,1),%rdi
  6feb33:	add    $0xb0,%rdi
  6feb3a:	mov    (%rcx,%rdx,1),%rsi
  6feb3e:	mov    0x8(%rcx,%rdx,1),%rdx
  6feb43:	call   *0x343887(%rip)        # a423d0 <_DYNAMIC+0x3e0>
  6feb49:	mov    %rax,%r12
  6feb4c:	mov    0x50(%rsp),%rdi
  6feb51:	mov    %rax,%rsi
  6feb54:	call   6f7cf0 <<gpui::runtime::identity_index::IdentityIndex>::required>
  6feb59:	mov    %rax,%rbp
  6feb5c:	mov    0x38(%rsp),%rax
  6feb61:	mov    0x2d0(%rax),%r13
  6feb68:	cmp    %r13,%rbp
  6feb6b:	jae    7030c5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c25>
  6feb71:	mov    0x2c8(%rax),%rcx
  6feb78:	lea    0x0(,%rbp,4),%rax
  6feb80:	add    %rbp,%rax
  6feb83:	mov    0x18(%rcx,%rax,8),%ebp
  6feb87:	mov    $0xffffffff,%eax
  6feb8c:	cmp    %rax,%rbp
  6feb8f:	je     6fe97d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4dd>
  6feb95:	cmp    %rbp,%r13
  6feb98:	jbe    703001 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b61>
  6feb9e:	mov    0x70(%rsp),%rax
  6feba3:	mov    (%rax),%rax
  6feba6:	test   %rax,%rax
  6feba9:	je     6fe97d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4dd>
  6febaf:	lea    0x0(,%rbp,4),%rdx
  6febb7:	add    %rbp,%rdx
  6febba:	mov    (%rcx,%rdx,8),%rcx
  6febbe:	mov    0x38(%rsp),%rdx
  6febc3:	mov    0x680(%rdx),%rdx
  6febca:	movzwl 0x62(%rax),%edi
  6febce:	mov    %edi,%r8d
  6febd1:	shl    $0x3,%r8d
  6febd5:	mov    $0xffffffffffffffff,%rsi
  6febdc:	nopl   0x0(%rax)
  6febe0:	test   %r8,%r8
  6febe3:	je     6fec10 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x770>
  6febe5:	cmp    0x10(%rax,%rsi,8),%rcx
  6febea:	seta   %r9b
  6febee:	sbb    $0x0,%r9b
  6febf2:	inc    %rsi
  6febf5:	add    $0xfffffffffffffff8,%r8
  6febf9:	cmp    $0x1,%r9b
  6febfd:	je     6febe0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x740>
  6febff:	movzbl %r9b,%edi
  6fec03:	test   %edi,%edi
  6fec05:	je     6fe970 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d0>
  6fec0b:	jmp    6fec13 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x773>
  6fec0d:	nopl   (%rax)
  6fec10:	mov    %rdi,%rsi
  6fec13:	sub    $0x1,%rdx
  6fec17:	jb     6fe97d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4dd>
  6fec1d:	mov    0x68(%rax,%rsi,8),%rax
  6fec22:	jmp    6febca <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x72a>
  6fec24:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fec30:	mov    %rax,%rdi
  6fec33:	cmp    $0x8,%rax
  6fec37:	jae    6fead0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x630>
  6fec3d:	jmp    6feb11 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x671>
  6fec42:	lea    0x4b0(%rsp),%rdi
  6fec4a:	call   *0x3438c0(%rip)        # a42510 <_DYNAMIC+0x520>
  6fec50:	lea    0x2f0(%r14),%r15
  6fec57:	mov    %r15,%rdi
  6fec5a:	call   6c5550 <core::ptr::drop_glue::<gpui_reactivity_core::layout::LayoutTree>>
  6fec5f:	lea    0x4b0(%rsp),%rsi
  6fec67:	mov    $0x298,%edx
  6fec6c:	mov    %r15,%rdi
  6fec6f:	call   *0x343603(%rip)        # a42278 <memcpy@GLIBC_2.14>
  6fec75:	movq   $0x0,0x598(%r14)
  6fec80:	mov    0x2d0(%r14),%rax
  6fec87:	test   %rax,%rax
  6fec8a:	je     6ff76b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x12cb>
  6fec90:	lea    0x588(%r14),%rcx
  6fec97:	mov    %rcx,0x70(%rsp)
  6fec9c:	mov    0x2c8(%r14),%r12
  6feca3:	lea    (%rax,%rax,4),%rax
  6feca7:	lea    (%r12,%rax,8),%rax
  6fecab:	mov    %rax,0x50(%rsp)
  6fecb0:	xor    %r13d,%r13d
  6fecb3:	lea    0x32366e(%rip),%rax        # a22328 <__frame_dummy_init_array_entry+0x838>
  6fecba:	mov    %rax,0x48(%rsp)
  6fecbf:	xor    %ebx,%ebx
  6fecc1:	jmp    6fed06 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x866>
  6fecc3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fecd0:	add    $0x28,%r12
  6fecd4:	inc    %rbx
  6fecd7:	mov    0x590(%r14),%rax
  6fecde:	mov    %r13,%rcx
  6fece1:	shl    $0x4,%rcx
  6fece5:	movaps 0x8d0(%rsp),%xmm0
  6feced:	movups %xmm0,(%rax,%rcx,1)
  6fecf1:	inc    %r13
  6fecf4:	mov    %r13,0x598(%r14)
  6fecfb:	cmp    0x50(%rsp),%r12
  6fed00:	je     6ff76b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x12cb>
  6fed06:	mov    0x18(%r12),%ebp
  6fed0b:	mov    $0xffffffff,%eax
  6fed10:	cmp    %rax,%rbp
  6fed13:	je     6fed50 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x8b0>
  6fed15:	cmp    %rbp,%r13
  6fed18:	jbe    7030c5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c25>
  6fed1e:	mov    0x590(%r14),%rax
  6fed25:	mov    %rbp,%rcx
  6fed28:	shl    $0x4,%rcx
  6fed2c:	movups (%rax,%rcx,1),%xmm0
  6fed30:	lea    0xbd8(%rsp),%rax
  6fed38:	movups %xmm0,(%rax)
  6fed3b:	mov    $0x1,%eax
  6fed40:	jmp    6fed52 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x8b2>
  6fed42:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fed50:	xor    %eax,%eax
  6fed52:	mov    %rax,0xbd0(%rsp)
  6fed5a:	mov    0x20(%r12),%eax
  6fed5f:	and    $0xf,%eax
  6fed62:	cmp    $0xa,%eax
  6fed65:	jae    702e42 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x49a2>
  6fed6b:	lea    -0x6ae120(%rip),%rcx        # 50c52 <GCC_except_table0+0x10eae>
  6fed72:	movzbl (%rax,%rcx,1),%r15d
  6fed77:	mov    0x38(%rsp),%r14
  6fed7c:	mov    0x200(%r14),%rax
  6fed83:	lea    -0x6bd0fe(%rip),%rcx        # 41c8c <GCC_except_table0+0x1ee8>
  6fed8a:	movslq (%rcx,%rax,4),%rax
  6fed8e:	add    %rcx,%rax
  6fed91:	jmp    *%rax
  6fed93:	movups -0x6b1c2a(%rip),%xmm0        # 4d170 <GCC_except_table0+0xd3cc>
  6fed9a:	movaps %xmm0,0x930(%rsp)
  6feda2:	movups -0x6b1c49(%rip),%xmm0        # 4d160 <GCC_except_table0+0xd3bc>
  6feda9:	movaps %xmm0,0x920(%rsp)
  6fedb1:	movups -0x6b1c68(%rip),%xmm0        # 4d150 <GCC_except_table0+0xd3ac>
  6fedb8:	movaps %xmm0,0x910(%rsp)
  6fedc0:	movups -0x6b1c87(%rip),%xmm0        # 4d140 <GCC_except_table0+0xd39c>
  6fedc7:	movaps %xmm0,0x900(%rsp)
  6fedcf:	movups -0x6b1ca6(%rip),%xmm0        # 4d130 <GCC_except_table0+0xd38c>
  6fedd6:	movaps %xmm0,0x8f0(%rsp)
  6fedde:	movabs $0x3000100000000,%rax
  6fede8:	mov    %rax,0x940(%rsp)
  6fedf0:	cmp    $0xffffffff,%ebp
  6fedf3:	jne    6fee88 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x9e8>
  6fedf9:	jmp    6fef39 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xa99>
  6fedfe:	mov    0x220(%r14),%r13
  6fee05:	cmp    %r13,%rbx
  6fee08:	jae    70307e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4bde>
  6fee0e:	mov    0x210(%r14),%r13
  6fee15:	mov    0x218(%r14),%rax
  6fee1c:	movzbl (%rax,%rbx,1),%eax
  6fee20:	cmp    %rax,%r13
  6fee23:	jbe    70308a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4bea>
  6fee29:	mov    0x208(%r14),%rcx
  6fee30:	imul   $0x58,%rax,%rax
  6fee34:	mov    0x50(%rcx,%rax,1),%rdx
  6fee39:	mov    %rdx,0x940(%rsp)
  6fee41:	movups 0x40(%rcx,%rax,1),%xmm0
  6fee46:	movaps %xmm0,0x930(%rsp)
  6fee4e:	movups (%rcx,%rax,1),%xmm0
  6fee52:	movups 0x10(%rcx,%rax,1),%xmm1
  6fee57:	movups 0x20(%rcx,%rax,1),%xmm2
  6fee5c:	movupd 0x30(%rcx,%rax,1),%xmm3
  6fee62:	jmp    6fef0f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xa6f>
  6fee67:	mov    0x208(%r14),%rsi
  6fee6e:	lea    0x8f0(%rsp),%rdi
  6fee76:	mov    %rbx,%rdx
  6fee79:	call   *0x343569(%rip)        # a423e8 <_DYNAMIC+0x3f8>
  6fee7f:	cmp    $0xffffffff,%ebp
  6fee82:	je     6fef39 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xa99>
  6fee88:	mov    0x200(%r14),%rax
  6fee8f:	lea    -0x6bd1fa(%rip),%rdx        # 41c9c <GCC_except_table0+0x1ef8>
  6fee96:	movslq (%rdx,%rax,4),%rcx
  6fee9a:	add    %rdx,%rcx
  6fee9d:	lea    -0x6b1d74(%rip),%rax        # 4d130 <GCC_except_table0+0xd38c>
  6feea4:	jmp    *%rcx
  6feea6:	mov    0x218(%r14),%r13
  6feead:	cmp    %rbp,%r13
  6feeb0:	jbe    703075 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4bd5>
  6feeb6:	imul   $0x58,%rbp,%rax
  6feeba:	add    0x210(%r14),%rax
  6feec1:	jmp    6fef86 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xae6>
  6feec6:	mov    0x218(%r14),%r13
  6feecd:	cmp    %r13,%rbx
  6feed0:	jae    70308f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4bef>
  6feed6:	mov    0x210(%r14),%rax
  6feedd:	imul   $0x58,%rbx,%rcx
  6feee1:	mov    0x50(%rax,%rcx,1),%rdx
  6feee6:	mov    %rdx,0x940(%rsp)
  6feeee:	movups 0x40(%rax,%rcx,1),%xmm0
  6feef3:	movaps %xmm0,0x930(%rsp)
  6feefb:	movups (%rax,%rcx,1),%xmm0
  6feeff:	movups 0x10(%rax,%rcx,1),%xmm1
  6fef04:	movups 0x20(%rax,%rcx,1),%xmm2
  6fef09:	movupd 0x30(%rax,%rcx,1),%xmm3
  6fef0f:	movapd %xmm3,0x920(%rsp)
  6fef18:	movaps %xmm2,0x910(%rsp)
  6fef20:	movaps %xmm1,0x900(%rsp)
  6fef28:	movaps %xmm0,0x8f0(%rsp)
  6fef30:	cmp    $0xffffffff,%ebp
  6fef33:	jne    6fee88 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x9e8>
  6fef39:	mov    $0x2,%al
  6fef3b:	mov    0x660(%r14),%r8
  6fef42:	test   %r8,%r8
  6fef45:	jne    6ff001 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xb61>
  6fef4b:	jmp    6ff090 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xbf0>
  6fef50:	mov    0x220(%r14),%r13
  6fef57:	cmp    %rbp,%r13
  6fef5a:	jbe    70306c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4bcc>
  6fef60:	mov    0x210(%r14),%r13
  6fef67:	mov    0x218(%r14),%rax
  6fef6e:	movzbl (%rax,%rbp,1),%ebp
  6fef72:	cmp    %rbp,%r13
  6fef75:	jbe    7030b9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c19>
  6fef7b:	imul   $0x58,%rbp,%rax
  6fef7f:	add    0x208(%r14),%rax
  6fef86:	mov    0x50(%rax),%rcx
  6fef8a:	mov    %rcx,0x500(%rsp)
  6fef92:	movups 0x40(%rax),%xmm0
  6fef96:	movaps %xmm0,0x4f0(%rsp)
  6fef9e:	movups (%rax),%xmm0
  6fefa1:	movups 0x10(%rax),%xmm1
  6fefa5:	movups 0x20(%rax),%xmm2
  6fefa9:	movupd 0x30(%rax),%xmm3
  6fefae:	movapd %xmm3,0x4e0(%rsp)
  6fefb7:	movaps %xmm2,0x4d0(%rsp)
  6fefbf:	movaps %xmm1,0x4c0(%rsp)
  6fefc7:	movaps %xmm0,0x4b0(%rsp)
  6fefcf:	jmp    6fefe9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xb49>
  6fefd1:	mov    0x208(%r14),%rsi
  6fefd8:	lea    0x4b0(%rsp),%rdi
  6fefe0:	mov    %rbp,%rdx
  6fefe3:	call   *0x3433ff(%rip)        # a423e8 <_DYNAMIC+0x3f8>
  6fefe9:	movzbl 0x504(%rsp),%eax
  6feff1:	mov    0x660(%r14),%r8
  6feff8:	test   %r8,%r8
  6feffb:	je     6ff090 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xbf0>
  6ff001:	mov    (%r12),%rcx
  6ff005:	mov    0x668(%r14),%rdx
  6ff00c:	movzwl 0x1c2(%r8),%edi
  6ff014:	mov    %edi,%r10d
  6ff017:	shl    $0x5,%r10d
  6ff01b:	mov    $0xffffffffffffffff,%rsi
  6ff022:	xor    %r9d,%r9d
  6ff025:	data16 cs nopw 0x0(%rax,%rax,1)
  6ff030:	mov    %r10,%r11
  6ff033:	add    %r9,%r11
  6ff036:	je     6ff060 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xbc0>
  6ff038:	cmp    0x170(%r8,%rsi,8),%rcx
  6ff040:	seta   %r11b
  6ff044:	sbb    $0x0,%r11b
  6ff048:	add    $0xffffffffffffffe0,%r9
  6ff04c:	inc    %rsi
  6ff04f:	cmp    $0x1,%r11b
  6ff053:	je     6ff030 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xb90>
  6ff055:	movzbl %r11b,%edi
  6ff059:	test   %edi,%edi
  6ff05b:	jne    6ff063 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xbc3>
  6ff05d:	jmp    6ff080 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xbe0>
  6ff05f:	nop
  6ff060:	mov    %rdi,%rsi
  6ff063:	sub    $0x1,%rdx
  6ff067:	jb     6ff090 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xbf0>
  6ff069:	mov    0x1c8(%r8,%rsi,8),%r8
  6ff071:	jmp    6ff00c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xb6c>
  6ff073:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6ff080:	sub    %r9,%r8
  6ff083:	add    $0xffffffffffffffe0,%r8
  6ff087:	jmp    6ff093 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xbf3>
  6ff089:	nopl   0x0(%rax)
  6ff090:	xor    %r8d,%r8d
  6ff093:	movzbl %r15b,%esi
  6ff097:	movzbl %al,%ecx
  6ff09a:	lea    0x4b0(%rsp),%rdi
  6ff0a2:	lea    0x8f0(%rsp),%rdx
  6ff0aa:	call   *0x343668(%rip)        # a42718 <_DYNAMIC+0x728>
  6ff0b0:	lea    0x780(%rsp),%rdi
  6ff0b8:	mov    0x68(%rsp),%rsi
  6ff0bd:	lea    0xbd0(%rsp),%rdx
  6ff0c5:	xor    %ecx,%ecx
  6ff0c7:	lea    0x4b0(%rsp),%r8
  6ff0cf:	call   *0x34364b(%rip)        # a42720 <_DYNAMIC+0x730>
  6ff0d5:	cmpb   $0x0,0x780(%rsp)
  6ff0dd:	jne    6ffc92 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x17f2>
  6ff0e3:	lea    0x788(%rsp),%rax
  6ff0eb:	movups (%rax),%xmm0
  6ff0ee:	lea    0xc6(%rsp),%rax
  6ff0f6:	movups %xmm0,(%rax)
  6ff0f9:	movups (%rax),%xmm0
  6ff0fc:	movaps %xmm0,0x8d0(%rsp)
  6ff104:	mov    0x20(%r12),%ecx
  6ff109:	mov    %ecx,%eax
  6ff10b:	and    $0xf,%eax
  6ff10e:	cmp    $0x9,%eax
  6ff111:	ja     702e42 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x49a2>
  6ff117:	cmp    $0x6,%eax
  6ff11a:	mov    0x38(%rsp),%r14
  6ff11f:	je     6ff131 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xc91>
  6ff121:	cmp    $0x10,%ecx
  6ff124:	setae  %cl
  6ff127:	cmp    $0x6,%eax
  6ff12a:	sete   %al
  6ff12d:	or     %cl,%al
  6ff12f:	je     6ff163 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xcc3>
  6ff131:	movaps 0x8d0(%rsp),%xmm0
  6ff139:	movaps %xmm0,0x4b0(%rsp)
  6ff141:	mov    0x68(%rsp),%rdi
  6ff146:	lea    0x4b0(%rsp),%rsi
  6ff14e:	mov    0x3435d3(%rip),%rdx        # a42728 <_DYNAMIC+0x738>
  6ff155:	call   *0x3435d5(%rip)        # a42730 <_DYNAMIC+0x740>
  6ff15b:	test   $0x1,%al
  6ff15d:	jne    6ffc81 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x17e1>
  6ff163:	mov    0x598(%r14),%r13
  6ff16a:	cmp    0x588(%r14),%r13
  6ff171:	jne    6fecd0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x830>
  6ff177:	mov    0x70(%rsp),%rdi
  6ff17c:	call   6f4430 <<alloc::raw_vec::RawVec<[core::option::Option<gpui::source::FieldId>; 2]>>::grow_one>
  6ff181:	jmp    6fecd0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x830>
  6ff186:	mov    0x38(%rsp),%r14
  6ff18b:	mov    0x678(%r14),%rax
  6ff192:	mov    0x688(%r14),%rdi
  6ff199:	test   %rax,%rax
  6ff19c:	setne  %cl
  6ff19f:	test   %rdi,%rdi
  6ff1a2:	setne  %dl
  6ff1a5:	and    %cl,%dl
  6ff1a7:	cmp    $0x1,%dl
  6ff1aa:	jne    6ff76b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x12cb>
  6ff1b0:	mov    0x680(%r14),%rbx
  6ff1b7:	lea    0x1e8(%r14),%rcx
  6ff1be:	mov    %rcx,0x2b0(%rsp)
  6ff1c6:	xor    %r12d,%r12d
  6ff1c9:	lea    0x3244e0(%rip),%rcx        # a236b0 <__frame_dummy_init_array_entry+0x1bc0>
  6ff1d0:	mov    %rcx,0x48(%rsp)
  6ff1d5:	data16 cs nopw 0x0(%rax,%rax,1)
  6ff1e0:	test   %r12,%r12
  6ff1e3:	je     6ff1fc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xd5c>
  6ff1e5:	movzwl 0x62(%r12),%ecx
  6ff1eb:	cmp    %rcx,%rbx
  6ff1ee:	jae    6ff280 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xde0>
  6ff1f4:	mov    %r12,%r15
  6ff1f7:	jmp    6ff2a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xe00>
  6ff1fc:	test   %rbx,%rbx
  6ff1ff:	je     6ff22b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xd8b>
  6ff201:	mov    %rbx,%rcx
  6ff204:	mov    %rax,%r12
  6ff207:	and    $0x7,%rcx
  6ff20b:	je     6ff230 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xd90>
  6ff20d:	xor    %edx,%edx
  6ff20f:	nop
  6ff210:	mov    0x68(%r12),%r12
  6ff215:	inc    %rdx
  6ff218:	cmp    %rdx,%rcx
  6ff21b:	jne    6ff210 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xd70>
  6ff21d:	mov    %rbx,%rax
  6ff220:	sub    %rdx,%rax
  6ff223:	cmp    $0x8,%rbx
  6ff227:	jae    6ff240 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xda0>
  6ff229:	jmp    6ff267 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xdc7>
  6ff22b:	mov    %rax,%r12
  6ff22e:	jmp    6ff267 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xdc7>
  6ff230:	mov    %rbx,%rax
  6ff233:	cmp    $0x8,%rbx
  6ff237:	jb     6ff267 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xdc7>
  6ff239:	nopl   0x0(%rax)
  6ff240:	mov    0x68(%r12),%rcx
  6ff245:	mov    0x68(%rcx),%rcx
  6ff249:	mov    0x68(%rcx),%rcx
  6ff24d:	mov    0x68(%rcx),%rcx
  6ff251:	mov    0x68(%rcx),%rcx
  6ff255:	mov    0x68(%rcx),%rcx
  6ff259:	mov    0x68(%rcx),%rcx
  6ff25d:	mov    0x68(%rcx),%r12
  6ff261:	add    $0xfffffffffffffff8,%rax
  6ff265:	jne    6ff240 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xda0>
  6ff267:	xor    %eax,%eax
  6ff269:	xor    %ebx,%ebx
  6ff26b:	movzwl 0x62(%r12),%ecx
  6ff271:	cmp    %rcx,%rbx
  6ff274:	jb     6ff1f4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xd54>
  6ff27a:	nopw   0x0(%rax,%rax,1)
  6ff280:	mov    (%r12),%r15
  6ff284:	test   %r15,%r15
  6ff287:	je     702ed2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4a32>
  6ff28d:	inc    %rax
  6ff290:	movzwl 0x60(%r12),%ebx
  6ff296:	mov    %r15,%r12
  6ff299:	cmp    0x62(%r15),%bx
  6ff29e:	jae    6ff280 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xde0>
  6ff2a0:	test   %rax,%rax
  6ff2a3:	mov    %rdi,0x70(%rsp)
  6ff2a8:	je     6ff328 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xe88>
  6ff2aa:	lea    (%r15,%rbx,8),%rcx
  6ff2ae:	add    $0x70,%rcx
  6ff2b2:	mov    %rax,%rdx
  6ff2b5:	and    $0x7,%rdx
  6ff2b9:	je     6ff586 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x10e6>
  6ff2bf:	xor    %esi,%esi
  6ff2c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6ff2d0:	mov    (%rcx),%r12
  6ff2d3:	lea    0x68(%r12),%rcx
  6ff2d8:	inc    %rsi
  6ff2db:	cmp    %rsi,%rdx
  6ff2de:	jne    6ff2d0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xe30>
  6ff2e0:	mov    %rax,%rdx
  6ff2e3:	sub    %rsi,%rdx
  6ff2e6:	cmp    $0x8,%rax
  6ff2ea:	jb     6ff31a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xe7a>
  6ff2ec:	nopl   0x0(%rax)
  6ff2f0:	mov    (%rcx),%rax
  6ff2f3:	mov    0x68(%rax),%rax
  6ff2f7:	mov    0x68(%rax),%rax
  6ff2fb:	mov    0x68(%rax),%rax
  6ff2ff:	mov    0x68(%rax),%rax
  6ff303:	mov    0x68(%rax),%rax
  6ff307:	mov    0x68(%rax),%rax
  6ff30b:	mov    0x68(%rax),%r12
  6ff30f:	lea    0x68(%r12),%rcx
  6ff314:	add    $0xfffffffffffffff8,%rdx
  6ff318:	jne    6ff2f0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xe50>
  6ff31a:	movq   $0x0,0x110(%rsp)
  6ff326:	jmp    6ff337 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xe97>
  6ff328:	lea    0x1(%rbx),%rax
  6ff32c:	mov    %rax,0x110(%rsp)
  6ff334:	mov    %r15,%r12
  6ff337:	mov    0x8(%r15,%rbx,8),%rsi
  6ff33c:	mov    0x2b0(%rsp),%rdi
  6ff344:	call   6f7cf0 <<gpui::runtime::identity_index::IdentityIndex>::required>
  6ff349:	mov    %rax,%rbp
  6ff34c:	mov    0x38(%rsp),%rdx
  6ff351:	mov    0x598(%rdx),%r13
  6ff358:	cmp    %r13,%rax
  6ff35b:	jae    7030c5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c25>
  6ff361:	mov    0x590(%rdx),%rax
  6ff368:	mov    %rbp,%rcx
  6ff36b:	shl    $0x4,%rcx
  6ff36f:	movups (%rax,%rcx,1),%xmm0
  6ff373:	movaps %xmm0,0xc0(%rsp)
  6ff37b:	mov    0x2d0(%rdx),%r13
  6ff382:	cmp    %r13,%rbp
  6ff385:	jae    703031 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b91>
  6ff38b:	mov    0x2c8(%rdx),%rax
  6ff392:	lea    0x0(,%rbp,4),%r14
  6ff39a:	add    %rbp,%r14
  6ff39d:	mov    0x20(%rax,%r14,8),%eax
  6ff3a2:	and    $0xf,%eax
  6ff3a5:	cmp    $0xa,%eax
  6ff3a8:	jae    702e42 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x49a2>
  6ff3ae:	lea    -0x6ae763(%rip),%rcx        # 50c52 <GCC_except_table0+0x10eae>
  6ff3b5:	movzbl (%rax,%rcx,1),%eax
  6ff3b9:	mov    %al,0x50(%rsp)
  6ff3bd:	mov    0x38(%rsp),%rdx
  6ff3c2:	mov    0x200(%rdx),%rax
  6ff3c9:	lea    -0x6bd764(%rip),%rcx        # 41c6c <GCC_except_table0+0x1ec8>
  6ff3d0:	movslq (%rcx,%rax,4),%rax
  6ff3d4:	add    %rcx,%rax
  6ff3d7:	jmp    *%rax
  6ff3d9:	movups -0x6b2270(%rip),%xmm0        # 4d170 <GCC_except_table0+0xd3cc>
  6ff3e0:	movaps %xmm0,0x930(%rsp)
  6ff3e8:	movups -0x6b228f(%rip),%xmm0        # 4d160 <GCC_except_table0+0xd3bc>
  6ff3ef:	movaps %xmm0,0x920(%rsp)
  6ff3f7:	movups -0x6b22ae(%rip),%xmm0        # 4d150 <GCC_except_table0+0xd3ac>
  6ff3fe:	movaps %xmm0,0x910(%rsp)
  6ff406:	movups -0x6b22cd(%rip),%xmm0        # 4d140 <GCC_except_table0+0xd39c>
  6ff40d:	movaps %xmm0,0x900(%rsp)
  6ff415:	movups -0x6b22ec(%rip),%xmm0        # 4d130 <GCC_except_table0+0xd38c>
  6ff41c:	movaps %xmm0,0x8f0(%rsp)
  6ff424:	movabs $0x3000100000000,%rax
  6ff42e:	mov    %rax,0x940(%rsp)
  6ff436:	jmp    6ff503 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1063>
  6ff43b:	mov    0x220(%rdx),%rax
  6ff442:	cmp    %rax,%rbp
  6ff445:	jae    7030a7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c07>
  6ff44b:	mov    0x210(%rdx),%rax
  6ff452:	mov    0x218(%rdx),%rcx
  6ff459:	movzbl (%rcx,%rbp,1),%ecx
  6ff45d:	cmp    %rcx,%rax
  6ff460:	jbe    7030b3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c13>
  6ff466:	mov    0x208(%rdx),%rax
  6ff46d:	imul   $0x58,%rcx,%rcx
  6ff471:	jmp    6ff4b4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1014>
  6ff473:	mov    0x208(%rdx),%rsi
  6ff47a:	lea    0x8f0(%rsp),%rdi
  6ff482:	mov    %rbp,%rdx
  6ff485:	call   *0x342f5d(%rip)        # a423e8 <_DYNAMIC+0x3f8>
  6ff48b:	mov    0x38(%rsp),%rax
  6ff490:	mov    0x2d0(%rax),%r13
  6ff497:	jmp    6ff503 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1063>
  6ff499:	mov    0x218(%rdx),%rax
  6ff4a0:	cmp    %rax,%rbp
  6ff4a3:	jae    70309b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4bfb>
  6ff4a9:	mov    0x210(%rdx),%rax
  6ff4b0:	imul   $0x58,%rbp,%rcx
  6ff4b4:	mov    0x50(%rax,%rcx,1),%rdx
  6ff4b9:	mov    %rdx,0x940(%rsp)
  6ff4c1:	movups 0x40(%rax,%rcx,1),%xmm0
  6ff4c6:	movaps %xmm0,0x930(%rsp)
  6ff4ce:	movups (%rax,%rcx,1),%xmm0
  6ff4d2:	movups 0x10(%rax,%rcx,1),%xmm1
  6ff4d7:	movups 0x20(%rax,%rcx,1),%xmm2
  6ff4dc:	movupd 0x30(%rax,%rcx,1),%xmm3
  6ff4e2:	movapd %xmm3,0x920(%rsp)
  6ff4eb:	movaps %xmm2,0x910(%rsp)
  6ff4f3:	movaps %xmm1,0x900(%rsp)
  6ff4fb:	movaps %xmm0,0x8f0(%rsp)
  6ff503:	cmp    %r13,%rbp
  6ff506:	jae    70303d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b9d>
  6ff50c:	mov    0x38(%rsp),%rdx
  6ff511:	mov    0x2c8(%rdx),%rax
  6ff518:	mov    0x18(%rax,%r14,8),%ebp
  6ff51d:	mov    $0xffffffff,%eax
  6ff522:	cmp    %rax,%rbp
  6ff525:	je     6ff562 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x10c2>
  6ff527:	mov    0x200(%rdx),%rax
  6ff52e:	lea    -0x6bd8b9(%rip),%rsi        # 41c7c <GCC_except_table0+0x1ed8>
  6ff535:	movslq (%rsi,%rax,4),%rcx
  6ff539:	add    %rsi,%rcx
  6ff53c:	lea    -0x6b2413(%rip),%rax        # 4d130 <GCC_except_table0+0xd38c>
  6ff543:	jmp    *%rcx
  6ff545:	mov    0x218(%rdx),%r13
  6ff54c:	cmp    %rbp,%r13
  6ff54f:	jbe    703075 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4bd5>
  6ff555:	imul   $0x58,%rbp,%rax
  6ff559:	add    0x210(%rdx),%rax
  6ff560:	jmp    6ff5ce <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x112e>
  6ff562:	mov    $0x2,%al
  6ff564:	mov    0x38(%rsp),%rdx
  6ff569:	mov    0x660(%rdx),%r8
  6ff570:	test   %r8,%r8
  6ff573:	jne    6ff64e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x11ae>
  6ff579:	xor    %r8d,%r8d
  6ff57c:	movzbl 0x50(%rsp),%ebx
  6ff581:	jmp    6ff6d7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1237>
  6ff586:	mov    %rax,%rdx
  6ff589:	cmp    $0x8,%rax
  6ff58d:	jae    6ff2f0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xe50>
  6ff593:	jmp    6ff31a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xe7a>
  6ff598:	mov    0x220(%rdx),%r13
  6ff59f:	cmp    %rbp,%r13
  6ff5a2:	jbe    70306c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4bcc>
  6ff5a8:	mov    0x210(%rdx),%r13
  6ff5af:	mov    0x218(%rdx),%rax
  6ff5b6:	movzbl (%rax,%rbp,1),%ebp
  6ff5ba:	cmp    %rbp,%r13
  6ff5bd:	jbe    7030b9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c19>
  6ff5c3:	imul   $0x58,%rbp,%rax
  6ff5c7:	add    0x208(%rdx),%rax
  6ff5ce:	mov    0x50(%rax),%rcx
  6ff5d2:	mov    %rcx,0x500(%rsp)
  6ff5da:	movups 0x40(%rax),%xmm0
  6ff5de:	movaps %xmm0,0x4f0(%rsp)
  6ff5e6:	movups (%rax),%xmm0
  6ff5e9:	movups 0x10(%rax),%xmm1
  6ff5ed:	movups 0x20(%rax),%xmm2
  6ff5f1:	movupd 0x30(%rax),%xmm3
  6ff5f6:	movapd %xmm3,0x4e0(%rsp)
  6ff5ff:	movaps %xmm2,0x4d0(%rsp)
  6ff607:	movaps %xmm1,0x4c0(%rsp)
  6ff60f:	movaps %xmm0,0x4b0(%rsp)
  6ff617:	jmp    6ff631 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1191>
  6ff619:	mov    0x208(%rdx),%rsi
  6ff620:	lea    0x4b0(%rsp),%rdi
  6ff628:	mov    %rbp,%rdx
  6ff62b:	call   *0x342db7(%rip)        # a423e8 <_DYNAMIC+0x3f8>
  6ff631:	movzbl 0x504(%rsp),%eax
  6ff639:	mov    0x38(%rsp),%rdx
  6ff63e:	mov    0x660(%rdx),%r8
  6ff645:	test   %r8,%r8
  6ff648:	je     6ff579 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x10d9>
  6ff64e:	mov    0x8(%r15,%rbx,8),%rcx
  6ff653:	mov    0x668(%rdx),%rdx
  6ff65a:	movzbl 0x50(%rsp),%ebx
  6ff65f:	movzwl 0x1c2(%r8),%edi
  6ff667:	mov    %edi,%r10d
  6ff66a:	shl    $0x5,%r10d
  6ff66e:	mov    $0xffffffffffffffff,%rsi
  6ff675:	xor    %r9d,%r9d
  6ff678:	nopl   0x0(%rax,%rax,1)
  6ff680:	mov    %r10,%r11
  6ff683:	add    %r9,%r11
  6ff686:	je     6ff6b0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1210>
  6ff688:	cmp    0x170(%r8,%rsi,8),%rcx
  6ff690:	seta   %r11b
  6ff694:	sbb    $0x0,%r11b
  6ff698:	add    $0xffffffffffffffe0,%r9
  6ff69c:	inc    %rsi
  6ff69f:	cmp    $0x1,%r11b
  6ff6a3:	je     6ff680 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x11e0>
  6ff6a5:	movzbl %r11b,%edi
  6ff6a9:	test   %edi,%edi
  6ff6ab:	jne    6ff6b3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1213>
  6ff6ad:	jmp    6ff6d0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1230>
  6ff6af:	nop
  6ff6b0:	mov    %rdi,%rsi
  6ff6b3:	sub    $0x1,%rdx
  6ff6b7:	jb     6ff763 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x12c3>
  6ff6bd:	mov    0x1c8(%r8,%rsi,8),%r8
  6ff6c5:	jmp    6ff65f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x11bf>
  6ff6c7:	nopw   0x0(%rax,%rax,1)
  6ff6d0:	sub    %r9,%r8
  6ff6d3:	add    $0xffffffffffffffe0,%r8
  6ff6d7:	movzbl %bl,%esi
  6ff6da:	movzbl %al,%ecx
  6ff6dd:	lea    0x4b0(%rsp),%rdi
  6ff6e5:	lea    0x8f0(%rsp),%rdx
  6ff6ed:	call   *0x343025(%rip)        # a42718 <_DYNAMIC+0x728>
  6ff6f3:	movaps 0xc0(%rsp),%xmm0
  6ff6fb:	movaps %xmm0,0x780(%rsp)
  6ff703:	mov    0x68(%rsp),%rdi
  6ff708:	lea    0x780(%rsp),%rsi
  6ff710:	lea    0x4b0(%rsp),%rdx
  6ff718:	call   *0x34301a(%rip)        # a42738 <_DYNAMIC+0x748>
  6ff71e:	test   $0x1,%al
  6ff720:	jne    6ffc81 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x17e1>
  6ff726:	mov    0x68(%rsp),%rdi
  6ff72b:	lea    0xc0(%rsp),%rsi
  6ff733:	call   *0x342f67(%rip)        # a426a0 <_DYNAMIC+0x6b0>
  6ff739:	cmp    $0xff,%al
  6ff73b:	jne    6ffc9a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x17fa>
  6ff741:	mov    $0x0,%eax
  6ff746:	mov    0x70(%rsp),%rdi
  6ff74b:	dec    %rdi
  6ff74e:	mov    0x38(%rsp),%r14
  6ff753:	mov    0x110(%rsp),%rbx
  6ff75b:	jne    6ff1e0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xd40>
  6ff761:	jmp    6ff76b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x12cb>
  6ff763:	xor    %r8d,%r8d
  6ff766:	jmp    6ff6d7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1237>
  6ff76b:	lea    0x2d8(%r14),%rax
  6ff772:	mov    %r14,%rsi
  6ff775:	mov    0x548(%r14),%r14
  6ff77c:	mov    0x568(%rsi),%rbx
  6ff783:	lea    0x588(%rsi),%rcx
  6ff78a:	movq   $0xfffffffffffffffe,0x748(%rsp)
  6ff796:	lea    0x2c0(%rsi),%rdx
  6ff79d:	lea    0x200(%rsi),%r13
  6ff7a4:	lea    0x5f0(%rsi),%r15
  6ff7ab:	mov    %rcx,0xb58(%rsp)
  6ff7b3:	mov    %rdx,0xb60(%rsp)
  6ff7bb:	mov    %r15,0xb68(%rsp)
  6ff7c3:	lea    0x1c8(%rsp),%rcx
  6ff7cb:	mov    %rcx,0xb70(%rsp)
  6ff7d3:	mov    %rax,0xb78(%rsp)
  6ff7db:	mov    %r13,0xb80(%rsp)
  6ff7e3:	lea    0x748(%rsp),%rax
  6ff7eb:	mov    %rax,0xb88(%rsp)
  6ff7f3:	cmpq   $0x0,0x598(%rsi)
  6ff7fb:	je     7030db <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c3b>
  6ff801:	mov    0x590(%rsi),%rax
  6ff808:	movupd (%rax),%xmm0
  6ff80c:	movapd %xmm0,0x8f0(%rsp)
  6ff815:	xorpd  %xmm0,%xmm0
  6ff819:	movapd 0x80(%rsp),%xmm1
  6ff822:	unpcklps %xmm0,%xmm1
  6ff825:	movapd -0x6be8cd(%rip),%xmm0        # 40f60 <GCC_except_table0+0x11bc>
  6ff82d:	orpd   %xmm0,%xmm1
  6ff831:	subpd  %xmm0,%xmm1
  6ff835:	cvtpd2ps %xmm1,%xmm1
  6ff839:	movapd %xmm1,%xmm0
  6ff83d:	shufps $0x55,%xmm1,%xmm0
  6ff841:	movaps %xmm1,0x70(%rsp)
  6ff846:	movss  0x9c(%rsp),%xmm2
  6ff84f:	divss  %xmm2,%xmm1
  6ff853:	divss  %xmm2,%xmm0
  6ff857:	movl   $0x0,0x4b0(%rsp)
  6ff862:	movss  %xmm1,0x4b4(%rsp)
  6ff86b:	movl   $0x0,0x4b8(%rsp)
  6ff876:	movss  %xmm0,0x4bc(%rsp)
  6ff87f:	mov    $0x1,%r12b
  6ff882:	lea    0x323e9f(%rip),%r8        # a23728 <__frame_dummy_init_array_entry+0x1c38>
  6ff889:	lea    0x8f0(%rsp),%rsi
  6ff891:	lea    0x4b0(%rsp),%rdx
  6ff899:	lea    0xb58(%rsp),%rcx
  6ff8a1:	mov    $0x1,%bpl
  6ff8a4:	mov    0x68(%rsp),%rdi
  6ff8a9:	call   *0x342e91(%rip)        # a42740 <_DYNAMIC+0x750>
  6ff8af:	test   $0x1,%al
  6ff8b1:	je     6ff919 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1479>
  6ff8b3:	mov    0x40(%rsp),%rax
  6ff8b8:	movq   $0x22,(%rax)
  6ff8bf:	mov    %dl,0x8(%rax)
  6ff8c2:	mov    0x748(%rsp),%rax
  6ff8ca:	mov    $0x1,%r12b
  6ff8cd:	mov    $0x1,%bpl
  6ff8d0:	cmp    $0xfffffffffffffffe,%rax
  6ff8d4:	je     6ffcaf <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x180f>
  6ff8da:	sub    $0xd,%rax
  6ff8de:	mov    $0x14,%ecx
  6ff8e3:	cmovge %rax,%rcx
  6ff8e7:	cmp    $0x14,%rcx
  6ff8eb:	je     6ffd61 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x18c1>
  6ff8f1:	cmp    $0x19,%rcx
  6ff8f5:	jne    6ffcaf <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x180f>
  6ff8fb:	mov    0x750(%rsp),%rsi
  6ff903:	test   %rsi,%rsi
  6ff906:	je     6ffcaf <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x180f>
  6ff90c:	lea    0x758(%rsp),%rax
  6ff914:	jmp    6ffd7a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x18da>
  6ff919:	mov    0x38(%rsp),%rsi
  6ff91e:	mov    0x548(%rsi),%rax
  6ff925:	sub    %r14,%rax
  6ff928:	mov    0x568(%rsi),%rcx
  6ff92f:	add    %rax,0x708(%rsi)
  6ff936:	sub    %rbx,%rcx
  6ff939:	add    %rcx,0x710(%rsi)
  6ff940:	cmpl   $0xfffffffe,0x748(%rsp)
  6ff948:	jne    6ffc4b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x17ab>
  6ff94e:	lea    0x4b0(%rsp),%rdi
  6ff956:	mov    $0x1,%bpl
  6ff959:	mov    $0x1,%edx
  6ff95e:	call   6f1a10 <<gpui::runtime::Runtime<text_column_public_control::Input>>::refresh_inspector>
  6ff963:	cmpl   $0xfffffffe,0x4b0(%rsp)
  6ff96b:	jne    6ffd28 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1888>
  6ff971:	mov    0x38(%rsp),%r14
  6ff976:	mov    0x2d0(%r14),%rsi
  6ff97d:	lea    0x4b0(%rsp),%rdi
  6ff985:	mov    $0x8,%ecx
  6ff98a:	mov    $0x40,%r8d
  6ff990:	xor    %edx,%edx
  6ff992:	call   6f4b00 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6ff997:	mov    0x4b8(%rsp),%rdi
  6ff99f:	cmpl   $0x1,0x4b0(%rsp)
  6ff9a7:	je     702f04 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4a64>
  6ff9ad:	mov    0x4c0(%rsp),%rax
  6ff9b5:	mov    %rdi,0x1d8(%rsp)
  6ff9bd:	mov    %rax,0x1e0(%rsp)
  6ff9c5:	movq   $0x0,0x1e8(%rsp)
  6ff9d1:	movq   $0x0,0x2d0(%rsp)
  6ff9dd:	movq   $0x4,0x2d8(%rsp)
  6ff9e9:	movq   $0x0,0x2e0(%rsp)
  6ff9f5:	mov    0x2d0(%r14),%rsi
  6ff9fc:	lea    0x4b0(%rsp),%rdi
  6ffa04:	mov    $0x8,%ecx
  6ffa09:	mov    $0x38,%r8d
  6ffa0f:	xor    %edx,%edx
  6ffa11:	call   6f4b00 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6ffa16:	mov    0x4b8(%rsp),%rdi
  6ffa1e:	cmpb   $0x0,0x4b0(%rsp)
  6ffa26:	jne    702f1a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4a7a>
  6ffa2c:	mov    0x4c0(%rsp),%rax
  6ffa34:	mov    %rdi,0x1f8(%rsp)
  6ffa3c:	mov    %rax,0x200(%rsp)
  6ffa44:	movq   $0x0,0x208(%rsp)
  6ffa50:	mov    0x658(%r14),%rbx
  6ffa57:	test   %rbx,%rbx
  6ffa5a:	setne  0x37(%rsp)
  6ffa5f:	je     6ffa68 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x15c8>
  6ffa61:	mov    0x2d0(%r14),%rbx
  6ffa68:	lea    0x4b0(%rsp),%rdi
  6ffa70:	mov    $0x4,%ecx
  6ffa75:	mov    $0x10,%r8d
  6ffa7b:	mov    %rbx,%rsi
  6ffa7e:	xor    %edx,%edx
  6ffa80:	call   6f4b00 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6ffa85:	mov    0x4b8(%rsp),%rdi
  6ffa8d:	cmpb   $0x0,0x4b0(%rsp)
  6ffa95:	jne    702f2d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4a8d>
  6ffa9b:	mov    0x4c0(%rsp),%rax
  6ffaa3:	mov    %rdi,0x220(%rsp)
  6ffaab:	mov    %rax,0x228(%rsp)
  6ffab3:	movq   $0x0,0x230(%rsp)
  6ffabf:	lea    0x4b0(%rsp),%rdi
  6ffac7:	mov    $0x4,%ecx
  6ffacc:	mov    $0x10,%r8d
  6ffad2:	mov    %rbx,%rsi
  6ffad5:	xor    %edx,%edx
  6ffad7:	call   6f4b00 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6ffadc:	mov    0x4b8(%rsp),%rdi
  6ffae4:	cmpb   $0x0,0x4b0(%rsp)
  6ffaec:	jne    702f40 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4aa0>
  6ffaf2:	mov    0x4c0(%rsp),%rax
  6ffafa:	mov    %rdi,0x238(%rsp)
  6ffb02:	mov    %rax,0x240(%rsp)
  6ffb0a:	movq   $0x0,0x248(%rsp)
  6ffb16:	lea    0x4b0(%rsp),%rdi
  6ffb1e:	mov    $0x1,%ecx
  6ffb23:	mov    $0x1,%r8d
  6ffb29:	mov    %rbx,%rsi
  6ffb2c:	xor    %edx,%edx
  6ffb2e:	call   6f4b00 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6ffb33:	mov    0x4b8(%rsp),%rdi
  6ffb3b:	cmpb   $0x0,0x4b0(%rsp)
  6ffb43:	jne    702f53 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4ab3>
  6ffb49:	mov    0x4c0(%rsp),%rax
  6ffb51:	mov    %rdi,0x198(%rsp)
  6ffb59:	mov    %rax,0x1a0(%rsp)
  6ffb61:	movq   $0x0,0x1a8(%rsp)
  6ffb6d:	lea    0x4b0(%rsp),%rdi
  6ffb75:	mov    $0x4,%ecx
  6ffb7a:	mov    $0x4,%r8d
  6ffb80:	mov    %rbx,%rsi
  6ffb83:	xor    %edx,%edx
  6ffb85:	call   6f4b00 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6ffb8a:	mov    0x4b8(%rsp),%rdi
  6ffb92:	cmpb   $0x0,0x4b0(%rsp)
  6ffb9a:	jne    702f66 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4ac6>
  6ffba0:	mov    %r13,0x48(%rsp)
  6ffba5:	mov    %r15,0x280(%rsp)
  6ffbad:	mov    0x4c0(%rsp),%rax
  6ffbb5:	mov    %rdi,0x170(%rsp)
  6ffbbd:	mov    %rax,0x178(%rsp)
  6ffbc5:	movq   $0x0,0x180(%rsp)
  6ffbd1:	movq   $0x0,0x378(%rsp)
  6ffbdd:	movq   $0x0,0x388(%rsp)
  6ffbe9:	mov    0x640(%r14),%rcx
  6ffbf0:	test   %rcx,%rcx
  6ffbf3:	je     6ffd8d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x18ed>
  6ffbf9:	mov    0x2d0(%r14),%rsi
  6ffc00:	mov    0x670(%r14),%rdx
  6ffc07:	mov    $0x1,%r12b
  6ffc0a:	lea    0x780(%rsp),%rdi
  6ffc12:	mov    $0x1,%r13b
  6ffc15:	mov    $0x1,%bpl
  6ffc18:	call   6da240 <<gpui::runtime::Runtime<text_column_public_control::Input>>::metadata_sheet::{closure#0}>
  6ffc1d:	jmp    6ffd99 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x18f9>
  6ffc22:	mov    0x40(%rsp),%rax
  6ffc27:	movq   $0x23,(%rax)
  6ffc2e:	mov    %r14d,0x8(%rax)
  6ffc32:	mov    %ebp,0xc(%rax)
  6ffc35:	mov    0xc10(%rsp),%rbx
  6ffc3d:	cmp    $0x2,%ebx
  6ffc40:	jne    6ffd09 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1869>
  6ffc46:	jmp    6ffd16 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1876>
  6ffc4b:	mov    0x778(%rsp),%rax
  6ffc53:	mov    0x40(%rsp),%rcx
  6ffc58:	mov    %rax,0x30(%rcx)
  6ffc5c:	movups 0x748(%rsp),%xmm0
  6ffc64:	movups 0x758(%rsp),%xmm1
  6ffc6c:	movups 0x768(%rsp),%xmm2
  6ffc74:	movups %xmm2,0x20(%rcx)
  6ffc78:	movups %xmm1,0x10(%rcx)
  6ffc7c:	movups %xmm0,(%rcx)
  6ffc7f:	jmp    6ffca9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1809>
  6ffc81:	mov    0x40(%rsp),%rax
  6ffc86:	movq   $0x22,(%rax)
  6ffc8d:	mov    %dl,0x8(%rax)
  6ffc90:	jmp    6ffca9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1809>
  6ffc92:	movzbl 0x781(%rsp),%eax
  6ffc9a:	mov    0x40(%rsp),%rcx
  6ffc9f:	movq   $0x22,(%rcx)
  6ffca6:	mov    %al,0x8(%rcx)
  6ffca9:	mov    $0x1,%r12b
  6ffcac:	mov    $0x1,%bpl
  6ffcaf:	cmpq   $0x0,0x1c8(%rsp)
  6ffcb8:	je     6ffcc7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1827>
  6ffcba:	mov    0x1d0(%rsp),%rdi
  6ffcc2:	call   6c5a90 <core::ptr::drop_glue::<gpui_canvas::text::TextShaper>>
  6ffcc7:	test   %r12b,%r12b
  6ffcca:	je     6ffcd9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1839>
  6ffccc:	lea    0x288(%rsp),%rdi
  6ffcd4:	call   6c1520 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  6ffcd9:	mov    0x140(%rsp),%rax
  6ffce1:	test   %rax,%rax
  6ffce4:	je     6ffcfa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x185a>
  6ffce6:	lock decq (%rax)
  6ffcea:	jne    6ffcfa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x185a>
  6ffcec:	lea    0x140(%rsp),%rdi
  6ffcf4:	call   *0x34262e(%rip)        # a42328 <_DYNAMIC+0x338>
  6ffcfa:	cmpl   $0x2,0xc10(%rsp)
  6ffd02:	je     6ffd16 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1876>
  6ffd04:	test   %bpl,%bpl
  6ffd07:	je     6ffd16 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1876>
  6ffd09:	lea    0xc10(%rsp),%rdi
  6ffd11:	call   6c6030 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  6ffd16:	add    $0xdf8,%rsp
  6ffd1d:	pop    %rbx
  6ffd1e:	pop    %r12
  6ffd20:	pop    %r13
  6ffd22:	pop    %r14
  6ffd24:	pop    %r15
  6ffd26:	pop    %rbp
  6ffd27:	ret
  6ffd28:	mov    0x4e0(%rsp),%rax
  6ffd30:	mov    0x40(%rsp),%rcx
  6ffd35:	mov    %rax,0x30(%rcx)
  6ffd39:	movups 0x4b0(%rsp),%xmm0
  6ffd41:	movups 0x4c0(%rsp),%xmm1
  6ffd49:	movups 0x4d0(%rsp),%xmm2
  6ffd51:	movups %xmm2,0x20(%rcx)
  6ffd55:	movups %xmm1,0x10(%rcx)
  6ffd59:	movups %xmm0,(%rcx)
  6ffd5c:	jmp    6ff8c2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1422>
  6ffd61:	mov    0x760(%rsp),%rsi
  6ffd69:	test   %rsi,%rsi
  6ffd6c:	je     6ffcaf <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x180f>
  6ffd72:	lea    0x768(%rsp),%rax
  6ffd7a:	mov    (%rax),%rdi
  6ffd7d:	mov    $0x1,%edx
  6ffd82:	call   *0x3424d0(%rip)        # a42258 <_DYNAMIC+0x268>
  6ffd88:	jmp    6ffcaf <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x180f>
  6ffd8d:	movq   $0xffffffffffffffff,0x780(%rsp)
  6ffd99:	mov    0x280(%rsp),%rax
  6ffda1:	mov    (%rax),%rsi
  6ffda4:	test   %rsi,%rsi
  6ffda7:	je     6ffe71 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x19d1>
  6ffdad:	mov    $0x1,%r12b
  6ffdb0:	lea    0x4b0(%rsp),%rdi
  6ffdb8:	mov    $0x1,%al
  6ffdba:	mov    %eax,0x50(%rsp)
  6ffdbe:	mov    $0x1,%r15b
  6ffdc1:	mov    $0x1,%bpl
  6ffdc4:	call   *0x34297e(%rip)        # a42748 <_DYNAMIC+0x758>
  6ffdca:	mov    0x48(%rsp),%rbx
  6ffdcf:	mov    0x4b0(%rsp),%rax
  6ffdd7:	mov    0x4b8(%rsp),%rsi
  6ffddf:	movups 0x4c0(%rsp),%xmm0
  6ffde7:	movaps %xmm0,0xc0(%rsp)
  6ffdef:	movups 0x4d0(%rsp),%xmm1
  6ffdf7:	movaps %xmm1,0x8f0(%rsp)
  6ffdff:	mov    0x4e0(%rsp),%rcx
  6ffe07:	mov    %rcx,0x900(%rsp)
  6ffe0f:	movaps %xmm0,0x470(%rsp)
  6ffe17:	cmp    $0xfffffffffffffffe,%rax
  6ffe1b:	je     6ffe7d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x19dd>
  6ffe1d:	mov    0x900(%rsp),%rcx
  6ffe25:	mov    0x40(%rsp),%rdx
  6ffe2a:	mov    %rcx,0x30(%rdx)
  6ffe2e:	movaps 0x8f0(%rsp),%xmm0
  6ffe36:	movups %xmm0,0x20(%rdx)
  6ffe3a:	movaps 0x470(%rsp),%xmm0
  6ffe42:	movaps %xmm0,0x3a0(%rsp)
  6ffe4a:	movups %xmm0,0x10(%rdx)
  6ffe4e:	mov    %rax,(%rdx)
  6ffe51:	mov    %rsi,0x8(%rdx)
  6ffe55:	mov    $0x1,%r12b
  6ffe58:	cmpl   $0xffffffff,0x780(%rsp)
  6ffe60:	mov    $0x1,%r13b
  6ffe63:	mov    $0x1,%bpl
  6ffe66:	jne    702d2b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x488b>
  6ffe6c:	jmp    702d38 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4898>
  6ffe71:	mov    $0xffffffffffffffff,%rsi
  6ffe78:	mov    0x48(%rsp),%rbx
  6ffe7d:	movaps 0x470(%rsp),%xmm0
  6ffe85:	movups %xmm0,0x830(%rsp)
  6ffe8d:	mov    %rsi,0x278(%rsp)
  6ffe95:	mov    %rsi,0x828(%rsp)
  6ffe9d:	cmpb   $0x0,0x37(%rsp)
  6ffea2:	je     6fff3c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1a9c>
  6ffea8:	lea    0x4b0(%rsp),%rdi
  6ffeb0:	lea    0x1f8(%rsp),%rdx
  6ffeb8:	lea    0x170(%rsp),%rcx
  6ffec0:	mov    %r14,%rsi
  6ffec3:	call   6c8d10 <gpui::runtime::scroll::geometry::<text_column_public_control::Input>>
  6ffec8:	mov    0x4b0(%rsp),%rax
  6ffed0:	movups 0x4b8(%rsp),%xmm0
  6ffed8:	movaps %xmm0,0x8f0(%rsp)
  6ffee0:	movups 0x4c8(%rsp),%xmm0
  6ffee8:	movaps %xmm0,0x900(%rsp)
  6ffef0:	movups 0x4d8(%rsp),%xmm0
  6ffef8:	movaps %xmm0,0x910(%rsp)
  6fff00:	cmp    $0xfffffffffffffffe,%rax
  6fff04:	jne    701d95 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x38f5>
  6fff0a:	movaps 0x8f0(%rsp),%xmm0
  6fff12:	movaps 0x900(%rsp),%xmm1
  6fff1a:	movaps 0x910(%rsp),%xmm2
  6fff22:	movaps %xmm2,0x3c0(%rsp)
  6fff2a:	movaps %xmm1,0x3b0(%rsp)
  6fff32:	movaps %xmm0,0x3a0(%rsp)
  6fff3a:	jmp    6fff77 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1ad7>
  6fff3c:	movq   $0x0,0x3a0(%rsp)
  6fff48:	movq   $0x8,0x3a8(%rsp)
  6fff54:	xorps  %xmm0,%xmm0
  6fff57:	movups %xmm0,0x3b0(%rsp)
  6fff5f:	movq   $0x8,0x3c0(%rsp)
  6fff6b:	movq   $0x0,0x3c8(%rsp)
  6fff77:	lea    0xbe8(%rsp),%rdi
  6fff7f:	mov    %r14,%rsi
  6fff82:	call   6f1850 <<gpui::runtime::Runtime<text_column_public_control::Input>>::inspector_display>
  6fff87:	mov    %rbx,%rdi
  6fff8a:	call   *0x3427c0(%rip)        # a42750 <_DYNAMIC+0x760>
  6fff90:	movzbl 0xbe8(%rsp),%eax
  6fff98:	mov    %al,0x9a(%rsp)
  6fff9f:	cmpl   $0x2,0xc10(%rsp)
  6fffa7:	mov    0xbf0(%rsp),%rax
  6fffaf:	mov    %rax,0x808(%rsp)
  6fffb7:	lea    0xc10(%rsp),%rsi
  6fffbf:	cmove  %r14,%rsi
  6fffc3:	lea    0x8f0(%rsp),%rdi
  6fffcb:	call   *0x342787(%rip)        # a42758 <_DYNAMIC+0x768>
  6fffd1:	movups -0x6bff58(%rip),%xmm0        # 40080 <GCC_except_table0+0x2dc>
  6fffd8:	movaps %xmm0,0x4b0(%rsp)
  6fffe0:	lea    0x8f0(%rsp),%rdi
  6fffe8:	lea    0x4b0(%rsp),%rsi
  6ffff0:	call   *0x34276a(%rip)        # a42760 <_DYNAMIC+0x770>
  6ffff6:	incq   0x720(%r14)
  6ffffd:	lea    0x640(%r14),%rax
  700004:	mov    %rax,0x138(%rsp)
  70000c:	mov    0x2d0(%r14),%rax
  700013:	mov    %rax,0x7f8(%rsp)
  70001b:	test   %rax,%rax
  70001e:	je     701cda <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x383a>
  700024:	movss  0x9c(%rsp),%xmm0
  70002d:	cvtss2sd %xmm0,%xmm0
  700031:	movsd  %xmm0,0x7f0(%rsp)
  70003a:	xorps  %xmm0,%xmm0
  70003d:	unpcklpd 0x70(%rsp),%xmm0
  700043:	movaps %xmm0,0x880(%rsp)
  70004b:	xor    %eax,%eax
  70004d:	movabs $0x8000000000000000,%rcx
  700057:	inc    %rcx
  70005a:	mov    %rcx,0x7e8(%rsp)
  700062:	lea    0x3236ff(%rip),%rcx        # a23768 <__frame_dummy_init_array_entry+0x1c78>
  700069:	mov    %rcx,0x108(%rsp)
  700071:	lea    0x322328(%rip),%rcx        # a223a0 <__frame_dummy_init_array_entry+0x8b0>
  700078:	mov    %rcx,0x348(%rsp)
  700080:	lea    0x323771(%rip),%rcx        # a237f8 <__frame_dummy_init_array_entry+0x1d08>
  700087:	mov    %rcx,0x268(%rsp)
  70008f:	lea    -0x6afdd5(%rip),%rcx        # 502c1 <GCC_except_table0+0x1051d>
  700096:	mov    %rcx,0x270(%rsp)
  70009e:	jmp    7000bb <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1c1b>
  7000a0:	mov    0x810(%rsp),%rax
  7000a8:	cmp    0x7f8(%rsp),%rax
  7000b0:	mov    0x38(%rsp),%r14
  7000b5:	je     701cda <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x383a>
  7000bb:	mov    %rax,%rcx
  7000be:	cmp    0x808(%rsp),%rax
  7000c6:	sete   %al
  7000c9:	test   %al,0x9a(%rsp)
  7000d0:	mov    %rcx,0x80(%rsp)
  7000d8:	je     70014e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1cae>
  7000da:	mov    0x1e0(%rsp),%rdx
  7000e2:	mov    0x1e8(%rsp),%rcx
  7000ea:	mov    0x2d8(%rsp),%r8
  7000f2:	mov    0x2e0(%rsp),%r9
  7000fa:	movups 0x2e0(%r14),%xmm0
  700102:	movups 0x590(%r14),%xmm1
  70010a:	movups %xmm1,0x18(%rsp)
  70010f:	mov    0x68(%rsp),%rax
  700114:	mov    %rax,0x10(%rsp)
  700119:	movups %xmm0,(%rsp)
  70011d:	lea    0x4b0(%rsp),%rdi
  700125:	lea    0xbf0(%rsp),%rsi
  70012d:	call   *0x342635(%rip)        # a42768 <_DYNAMIC+0x778>
  700133:	cmpl   $0xfffffffe,0x4b0(%rsp)
  70013b:	jne    702af4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4654>
  700141:	mov    0x38(%rsp),%r14
  700146:	mov    0x80(%rsp),%rcx
  70014e:	mov    0x598(%r14),%rax
  700155:	cmp    %rax,%rcx
  700158:	jae    7031e7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d47>
  70015e:	mov    0x590(%r14),%rax
  700165:	shl    $0x4,%rcx
  700169:	movups (%rax,%rcx,1),%xmm0
  70016d:	movaps %xmm0,0xc0(%rsp)
  700175:	lea    0x4b0(%rsp),%rdi
  70017d:	mov    0x68(%rsp),%rsi
  700182:	lea    0xc0(%rsp),%rdx
  70018a:	call   *0x342248(%rip)        # a423d8 <_DYNAMIC+0x3e8>
  700190:	cmpb   $0x0,0x4b0(%rsp)
  700198:	jne    702a42 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x45a2>
  70019e:	mov    0x80(%rsp),%r9
  7001a6:	lea    0x1(%r9),%rdx
  7001aa:	mov    0x38(%rsp),%r8
  7001af:	mov    0x2d0(%r8),%rsi
  7001b6:	cmp    %rsi,%rdx
  7001b9:	jae    7001e6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1d46>
  7001bb:	mov    0x2c8(%r8),%rax
  7001c2:	lea    (%rdx,%rdx,4),%rcx
  7001c6:	mov    0x18(%rax,%rcx,8),%eax
  7001ca:	mov    $0xffffffff,%ecx
  7001cf:	cmp    %rcx,%rax
  7001d2:	setne  %cl
  7001d5:	cmp    %rax,%r9
  7001d8:	sete   %al
  7001db:	and    %cl,%al
  7001dd:	mov    %eax,0x1f4(%rsp)
  7001e4:	jmp    7001f1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1d51>
  7001e6:	movl   $0x0,0x1f4(%rsp)
  7001f1:	mov    0x48(%rsp),%rax
  7001f6:	movsd  0x4f4(%rsp),%xmm0
  7001ff:	movaps %xmm0,0x8c0(%rsp)
  700207:	movups 0x4c4(%rsp),%xmm0
  70020f:	movaps %xmm0,0x8b0(%rsp)
  700217:	movss  0x4c8(%rsp),%xmm0
  700220:	movss  %xmm0,0x32c(%rsp)
  700229:	movups 0x4d4(%rsp),%xmm0
  700231:	movaps %xmm0,0x390(%rsp)
  700239:	movss  0x4dc(%rsp),%xmm0
  700242:	movaps %xmm0,0x890(%rsp)
  70024a:	movss  0x4d8(%rsp),%xmm0
  700253:	movss  %xmm0,0x328(%rsp)
  70025c:	movsd  0x4fc(%rsp),%xmm0
  700265:	movaps %xmm0,0x2b0(%rsp)
  70026d:	movsd  0x504(%rsp),%xmm0
  700276:	movaps %xmm0,0x8a0(%rsp)
  70027e:	mov    (%rax),%rax
  700281:	lea    -0x6be5dc(%rip),%rcx        # 41cac <GCC_except_table0+0x1f08>
  700288:	movslq (%rcx,%rax,4),%rax
  70028c:	add    %rcx,%rax
  70028f:	mov    %rdx,0x810(%rsp)
  700297:	jmp    *%rax
  700299:	movups -0x6b3130(%rip),%xmm0        # 4d170 <GCC_except_table0+0xd3cc>
  7002a0:	movaps %xmm0,0x4f0(%rsp)
  7002a8:	movups -0x6b314f(%rip),%xmm0        # 4d160 <GCC_except_table0+0xd3bc>
  7002af:	movaps %xmm0,0x4e0(%rsp)
  7002b7:	movups -0x6b316e(%rip),%xmm0        # 4d150 <GCC_except_table0+0xd3ac>
  7002be:	movaps %xmm0,0x4d0(%rsp)
  7002c6:	movups -0x6b318d(%rip),%xmm0        # 4d140 <GCC_except_table0+0xd39c>
  7002cd:	movaps %xmm0,0x4c0(%rsp)
  7002d5:	movups -0x6b31ac(%rip),%xmm0        # 4d130 <GCC_except_table0+0xd38c>
  7002dc:	movaps %xmm0,0x4b0(%rsp)
  7002e4:	movabs $0x3000100000000,%rax
  7002ee:	mov    %rax,0x500(%rsp)
  7002f6:	jmp    7003cc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1f2c>
  7002fb:	mov    0x220(%r8),%rax
  700302:	cmp    %rax,%r9
  700305:	jae    7031ad <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d0d>
  70030b:	mov    0x210(%r8),%rax
  700312:	mov    0x218(%r8),%rcx
  700319:	movzbl (%rcx,%r9,1),%ecx
  70031e:	cmp    %rcx,%rax
  700321:	jbe    7031b6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d16>
  700327:	mov    0x208(%r8),%rax
  70032e:	imul   $0x58,%rcx,%rcx
  700332:	jmp    70037d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1edd>
  700334:	mov    0x208(%r8),%rsi
  70033b:	lea    0x4b0(%rsp),%rdi
  700343:	mov    %r9,%rdx
  700346:	call   *0x34209c(%rip)        # a423e8 <_DYNAMIC+0x3f8>
  70034c:	mov    0x38(%rsp),%r8
  700351:	mov    0x2d0(%r8),%rsi
  700358:	mov    0x80(%rsp),%r9
  700360:	jmp    7003cc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1f2c>
  700362:	mov    0x218(%r8),%rax
  700369:	cmp    %rax,%r9
  70036c:	jae    7031c7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d27>
  700372:	mov    0x210(%r8),%rax
  700379:	imul   $0x58,%r9,%rcx
  70037d:	mov    0x50(%rax,%rcx,1),%rdx
  700382:	mov    %rdx,0x500(%rsp)
  70038a:	movups 0x40(%rax,%rcx,1),%xmm0
  70038f:	movaps %xmm0,0x4f0(%rsp)
  700397:	movups (%rax,%rcx,1),%xmm0
  70039b:	movups 0x10(%rax,%rcx,1),%xmm1
  7003a0:	movups 0x20(%rax,%rcx,1),%xmm2
  7003a5:	movupd 0x30(%rax,%rcx,1),%xmm3
  7003ab:	movapd %xmm3,0x4e0(%rsp)
  7003b4:	movaps %xmm2,0x4d0(%rsp)
  7003bc:	movaps %xmm1,0x4c0(%rsp)
  7003c4:	movaps %xmm0,0x4b0(%rsp)
  7003cc:	cmp    %rsi,%r9
  7003cf:	jae    7030f7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c57>
  7003d5:	mov    0x2c8(%r8),%rdi
  7003dc:	lea    (%r9,%r9,4),%r15
  7003e0:	mov    0x18(%rdi,%r15,8),%edx
  7003e5:	mov    $0xffffffff,%eax
  7003ea:	cmp    %rax,%rdx
  7003ed:	je     70040c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1f6c>
  7003ef:	call   6db0a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}>
  7003f4:	mov    0x38(%rsp),%r8
  7003f9:	mov    0x2d0(%r8),%rsi
  700400:	mov    %eax,%edx
  700402:	mov    0x80(%rsp),%r9
  70040a:	jmp    70040e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1f6e>
  70040c:	xor    %edx,%edx
  70040e:	cmp    %rsi,%r9
  700411:	jae    703106 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c66>
  700417:	mov    0x2c8(%r8),%rax
  70041e:	mov    0x18(%rax,%r15,8),%ebx
  700423:	mov    $0xffffffff,%ecx
  700428:	cmp    %rcx,%rbx
  70042b:	je     700446 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1fa6>
  70042d:	cmp    %rbx,%rsi
  700430:	jbe    703124 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c84>
  700436:	lea    (%rbx,%rbx,4),%rcx
  70043a:	mov    (%rax,%rcx,8),%rcx
  70043e:	mov    %rcx,0x800(%rsp)
  700446:	mov    %edx,0x190(%rsp)
  70044d:	mov    0x138(%rsp),%rcx
  700455:	mov    (%rcx),%rcx
  700458:	xorps  %xmm0,%xmm0
  70045b:	movss  %xmm0,0x128(%rsp)
  700464:	test   %rcx,%rcx
  700467:	je     70049f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1fff>
  700469:	mov    0x100(%rcx),%rdi
  700470:	test   %rdi,%rdi
  700473:	je     70049f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1fff>
  700475:	lea    (%rax,%r15,8),%rax
  700479:	mov    (%rax),%rsi
  70047c:	call   *0x34225e(%rip)        # a426e0 <_DYNAMIC+0x6f0>
  700482:	movss  %xmm0,0x128(%rsp)
  70048b:	mov    0x38(%rsp),%r8
  700490:	mov    0x2d0(%r8),%rsi
  700497:	mov    0x80(%rsp),%r9
  70049f:	cmp    %rsi,%r9
  7004a2:	jae    703115 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c75>
  7004a8:	mov    0x2c8(%r8),%r12
  7004af:	mov    0x18(%r12,%r15,8),%ecx
  7004b4:	mov    $0xffffffff,%eax
  7004b9:	cmp    %rax,%rcx
  7004bc:	je     7005d8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2138>
  7004c2:	mov    0x208(%rsp),%rax
  7004ca:	cmp    %rcx,%rax
  7004cd:	jbe    70313b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c9b>
  7004d3:	imul   $0x38,%rcx,%rax
  7004d7:	mov    0x200(%rsp),%rcx
  7004df:	movups (%rcx,%rax,1),%xmm0
  7004e3:	movaps %xmm0,0x50(%rsp)
  7004e8:	movups 0x10(%rcx,%rax,1),%xmm0
  7004ed:	movaps %xmm0,0x110(%rsp)
  7004f5:	movups 0x20(%rcx,%rax,1),%xmm0
  7004fa:	movaps %xmm0,0x2a0(%rsp)
  700502:	movzbl 0x30(%rcx,%rax,1),%ebp
  700507:	mov    0x31(%rcx,%rax,1),%edx
  70050b:	mov    %edx,0xa0(%rsp)
  700512:	mov    0x34(%rcx,%rax,1),%eax
  700516:	mov    %eax,0xa3(%rsp)
  70051d:	cmp    $0xffffffff,%ebx
  700520:	je     702ec0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4a20>
  700526:	lea    0xc0(%rsp),%rdi
  70052e:	lea    0x3a0(%rsp),%rsi
  700536:	mov    0x800(%rsp),%rdx
  70053e:	call   *0x34222c(%rip)        # a42770 <_DYNAMIC+0x780>
  700544:	cmpb   $0x0,0xc0(%rsp)
  70054c:	je     70060c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x216c>
  700552:	movq   0xc8(%rsp),%xmm0
  70055b:	movq   0xd0(%rsp),%xmm1
  700564:	movq   %xmm0,%rax
  700569:	movq   %xmm1,%rcx
  70056e:	movabs $0x7fffffffffffffff,%rdx
  700578:	and    %rdx,%rax
  70057b:	movabs $0x7fefffffffffffff,%rsi
  700585:	cmp    %rsi,%rax
  700588:	setg   %al
  70058b:	and    %rdx,%rcx
  70058e:	cmp    %rsi,%rcx
  700591:	setg   %cl
  700594:	or     %al,%cl
  700596:	or     %bpl,%cl
  700599:	and    $0x1,%cl
  70059c:	punpcklqdq %xmm1,%xmm1
  7005a0:	pxor   -0x6bf308(%rip),%xmm1        # 412a0 <GCC_except_table0+0x14fc>
  7005a8:	movapd 0x110(%rsp),%xmm3
  7005b1:	mulpd  %xmm3,%xmm1
  7005b5:	punpcklqdq %xmm0,%xmm0
  7005b9:	movapd 0x50(%rsp),%xmm2
  7005bf:	mulpd  %xmm2,%xmm0
  7005c3:	subpd  %xmm0,%xmm1
  7005c7:	movapd 0x2a0(%rsp),%xmm0
  7005d0:	addpd  %xmm1,%xmm0
  7005d4:	mov    %ecx,%ebp
  7005d6:	jmp    70063f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x219f>
  7005d8:	movsd  0x7f0(%rsp),%xmm0
  7005e1:	movsd  %xmm0,0x470(%rsp)
  7005ea:	lea    0x4a1(%rsp),%rax
  7005f2:	xorps  %xmm1,%xmm1
  7005f5:	movups %xmm1,-0x29(%rax)
  7005f9:	movsd  %xmm0,0x488(%rsp)
  700602:	movaps %xmm1,-0x11(%rax)
  700606:	movb   $0x0,-0x1(%rax)
  70060a:	jmp    700662 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x21c2>
  70060c:	mov    0xa0(%rsp),%eax
  700613:	mov    0xa3(%rsp),%ecx
  70061a:	lea    0x4a1(%rsp),%rdx
  700622:	mov    %ecx,0x3(%rdx)
  700625:	mov    %eax,(%rdx)
  700627:	movapd 0x50(%rsp),%xmm2
  70062d:	movapd 0x110(%rsp),%xmm3
  700636:	movapd 0x2a0(%rsp),%xmm0
  70063f:	movapd %xmm2,0x470(%rsp)
  700648:	movapd %xmm3,0x480(%rsp)
  700651:	movapd %xmm0,0x490(%rsp)
  70065a:	mov    %bpl,0x4a0(%rsp)
  700662:	movaps -0x6bf0b9(%rip),%xmm0        # 415b0 <GCC_except_table0+0x180c>
  700669:	movaps %xmm0,0xa0(%rsp)
  700671:	movaps 0x8c0(%rsp),%xmm0
  700679:	movlps %xmm0,0xb0(%rsp)
  700681:	lea    0xc0(%rsp),%rdi
  700689:	lea    0x470(%rsp),%rsi
  700691:	lea    0xa0(%rsp),%rdx
  700699:	call   *0x341d41(%rip)        # a423e0 <_DYNAMIC+0x3f0>
  70069f:	lea    0xb20(%rsp),%rdi
  7006a7:	lea    0xc0(%rsp),%rsi
  7006af:	lea    0x4ec(%rsp),%rdx
  7006b7:	call   *0x341d23(%rip)        # a423e0 <_DYNAMIC+0x3f0>
  7006bd:	mov    0x208(%rsp),%rbx
  7006c5:	cmp    0x1f8(%rsp),%rbx
  7006cd:	jne    7006dc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x223c>
  7006cf:	lea    0x1f8(%rsp),%rdi
  7006d7:	call   6f4900 <<alloc::raw_vec::RawVec<gpui::semantic::AnnotationDraft>>::grow_one>
  7006dc:	mov    0x200(%rsp),%rax
  7006e4:	imul   $0x38,%rbx,%rcx
  7006e8:	mov    0xb50(%rsp),%rdx
  7006f0:	mov    %rdx,0x30(%rax,%rcx,1)
  7006f5:	movups 0xb20(%rsp),%xmm0
  7006fd:	movups 0xb30(%rsp),%xmm1
  700705:	movups 0xb40(%rsp),%xmm2
  70070d:	movups %xmm2,0x20(%rax,%rcx,1)
  700712:	movups %xmm1,0x10(%rax,%rcx,1)
  700717:	movups %xmm0,(%rax,%rcx,1)
  70071b:	inc    %rbx
  70071e:	mov    %rbx,0x208(%rsp)
  700726:	movups 0xb20(%rsp),%xmm0
  70072e:	movaps %xmm0,0x110(%rsp)
  700736:	movups 0xb30(%rsp),%xmm0
  70073e:	movaps %xmm0,0x2a0(%rsp)
  700746:	movups 0xb40(%rsp),%xmm0
  70074e:	movaps %xmm0,0x50(%rsp)
  700753:	lea    0xb20(%rsp),%rdi
  70075b:	call   *0x342017(%rip)        # a42778 <_DYNAMIC+0x788>
  700761:	xor    %ebx,%ebx
  700763:	test   %al,%al
  700765:	je     700884 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x23e4>
  70076b:	cvtpd2ps 0x2a0(%rsp),%xmm0
  700774:	cvtpd2ps 0x110(%rsp),%xmm1
  70077d:	cvtpd2ps 0x50(%rsp),%xmm2
  700783:	unpcklpd %xmm0,%xmm1
  700787:	movd   %xmm1,%eax
  70078b:	and    $0x7fffffff,%eax
  700790:	movapd %xmm1,%xmm0
  700794:	shufps $0x55,%xmm1,%xmm0
  700798:	movd   %xmm0,%ecx
  70079c:	and    $0x7fffffff,%ecx
  7007a2:	cmp    $0x7f800000,%ecx
  7007a8:	setge  %cl
  7007ab:	movdqa %xmm1,%xmm0
  7007af:	punpckhqdq %xmm1,%xmm0
  7007b3:	movd   %xmm0,%edx
  7007b7:	and    $0x7fffffff,%edx
  7007bd:	cmp    $0x7f800000,%edx
  7007c3:	setge  %dl
  7007c6:	movaps %xmm1,%xmm0
  7007c9:	shufps $0xff,%xmm1,%xmm0
  7007cd:	movd   %xmm0,%esi
  7007d1:	and    $0x7fffffff,%esi
  7007d7:	cmp    $0x7f800000,%esi
  7007dd:	setge  %sil
  7007e1:	movd   %xmm2,%edi
  7007e5:	and    $0x7fffffff,%edi
  7007eb:	cmp    $0x7f800000,%edi
  7007f1:	setge  %dil
  7007f5:	movapd %xmm2,%xmm0
  7007f9:	shufps $0x55,%xmm2,%xmm0
  7007fd:	movd   %xmm0,%r8d
  700802:	and    $0x7fffffff,%r8d
  700809:	cmp    $0x7f800000,%r8d
  700810:	setl   %r8b
  700814:	cmp    $0x7f7fffff,%eax
  700819:	jg     700884 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x23e4>
  70081b:	test   %cl,%cl
  70081d:	jne    700884 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x23e4>
  70081f:	test   %dl,%dl
  700821:	jne    700884 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x23e4>
  700823:	test   %sil,%sil
  700826:	jne    700884 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x23e4>
  700828:	test   %dil,%dil
  70082b:	jne    700884 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x23e4>
  70082d:	test   %r8b,%r8b
  700830:	je     700884 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x23e4>
  700832:	movaps %xmm1,0x50(%rsp)
  700837:	movaps %xmm1,0xc0(%rsp)
  70083f:	movaps %xmm2,0x110(%rsp)
  700847:	movlpd %xmm2,0xd0(%rsp)
  700850:	lea    0xc0(%rsp),%rdi
  700858:	call   *0x341f22(%rip)        # a42780 <_DYNAMIC+0x790>
  70085e:	test   %al,%al
  700860:	je     700884 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x23e4>
  700862:	movaps 0x50(%rsp),%xmm0
  700867:	movups %xmm0,0x2f0(%rsp)
  70086f:	movaps 0x110(%rsp),%xmm0
  700877:	movlps %xmm0,0x300(%rsp)
  70087f:	mov    $0x1,%ebx
  700884:	lea    (%r12,%r15,8),%rsi
  700888:	mov    %ebx,0x2ec(%rsp)
  70088f:	xorps  %xmm0,%xmm0
  700892:	unpcklpd 0x2b0(%rsp),%xmm0
  70089b:	movups %xmm0,0x358(%rsp)
  7008a3:	cmpb   $0x0,0x37(%rsp)
  7008a8:	mov    %rsi,0x50(%rsp)
  7008ad:	je     700918 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2478>
  7008af:	mov    0x18(%rsi),%ecx
  7008b2:	mov    $0xffffffff,%eax
  7008b7:	cmp    %rax,%rcx
  7008ba:	je     700941 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x24a1>
  7008c0:	mov    0x230(%rsp),%rax
  7008c8:	cmp    %rcx,%rax
  7008cb:	jbe    703161 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4cc1>
  7008d1:	mov    0x228(%rsp),%rax
  7008d9:	mov    %rcx,%rdx
  7008dc:	shl    $0x4,%rdx
  7008e0:	movups (%rax,%rdx,1),%xmm1
  7008e4:	xorps  %xmm0,%xmm0
  7008e7:	unpcklpd 0x70(%rsp),%xmm0
  7008ed:	movups %xmm0,0xc0(%rsp)
  7008f5:	mov    0x248(%rsp),%rax
  7008fd:	cmp    %rcx,%rax
  700900:	jbe    703172 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4cd2>
  700906:	movaps %xmm1,0x2a0(%rsp)
  70090e:	add    0x240(%rsp),%rdx
  700916:	jmp    70096a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x24ca>
  700918:	xorps  %xmm0,%xmm0
  70091b:	unpcklpd 0x70(%rsp),%xmm0
  700921:	movups %xmm0,0x250(%rsp)
  700929:	movl   $0x0,0x110(%rsp)
  700934:	movaps 0x880(%rsp),%xmm0
  70093c:	jmp    7009e6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2546>
  700941:	xorps  %xmm0,%xmm0
  700944:	unpcklpd 0x70(%rsp),%xmm0
  70094a:	movups %xmm0,0xc0(%rsp)
  700952:	lea    0xc0(%rsp),%rdx
  70095a:	movaps 0x880(%rsp),%xmm0
  700962:	movaps %xmm0,0x2a0(%rsp)
  70096a:	movups (%rdx),%xmm0
  70096d:	movaps %xmm0,0x250(%rsp)
  700975:	mov    0x20(%rsi),%edi
  700978:	call   6f81d0 <<gpui::runtime::Node>::kind>
  70097d:	mov    $0x1,%cl
  70097f:	mov    %ecx,0x110(%rsp)
  700986:	cmp    $0x7,%al
  700988:	jne    700999 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x24f9>
  70098a:	mov    0x50(%rsp),%rsi
  70098f:	movaps 0x2a0(%rsp),%xmm0
  700997:	jmp    7009e6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2546>
  700999:	mov    0x50(%rsp),%rsi
  70099e:	mov    0x18(%rsi),%ecx
  7009a1:	mov    $0xffffffff,%eax
  7009a6:	cmp    %rax,%rcx
  7009a9:	movaps 0x2a0(%rsp),%xmm0
  7009b1:	je     7009db <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x253b>
  7009b3:	mov    0x1a8(%rsp),%rax
  7009bb:	cmp    %rcx,%rax
  7009be:	jbe    7031d0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d30>
  7009c4:	mov    0x1a0(%rsp),%rax
  7009cc:	movzbl (%rax,%rcx,1),%eax
  7009d0:	and    $0x1,%al
  7009d2:	mov    %eax,0x110(%rsp)
  7009d9:	jmp    7009e6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2546>
  7009db:	movl   $0x0,0x110(%rsp)
  7009e6:	movaps %xmm0,0x1b0(%rsp)
  7009ee:	mov    0x20(%rsi),%eax
  7009f1:	and    $0xf,%eax
  7009f4:	cmp    $0x7,%eax
  7009f7:	jb     700a05 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2565>
  7009f9:	lea    -0x8(%rax),%ecx
  7009fc:	cmp    $0x2,%ecx
  7009ff:	jae    701576 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x30d6>
  700a05:	mov    0x18(%rsi),%ecx
  700a08:	xor    %r12d,%r12d
  700a0b:	mov    $0xffffffff,%edx
  700a10:	cmp    %rdx,%rcx
  700a13:	je     700a33 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2593>
  700a15:	cmp    %rcx,0x1a8(%rsp)
  700a1d:	jbe    700a33 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2593>
  700a1f:	mov    0x1a0(%rsp),%rdx
  700a27:	movzbl (%rdx,%rcx,1),%r12d
  700a2c:	and    $0x2,%r12b
  700a30:	shr    $1,%r12b
  700a33:	cmpb   $0x0,0x37(%rsp)
  700a38:	je     700a87 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x25e7>
  700a3a:	mov    0x1a8(%rsp),%r14
  700a42:	cmp    0x198(%rsp),%r14
  700a4a:	jne    700a5a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x25ba>
  700a4c:	lea    0x198(%rsp),%rdi
  700a54:	call   *0x341d2e(%rip)        # a42788 <_DYNAMIC+0x798>
  700a5a:	lea    (%r12,%r12,1),%eax
  700a5e:	add    0x110(%rsp),%al
  700a65:	mov    0x1a0(%rsp),%rcx
  700a6d:	mov    %al,(%rcx,%r14,1)
  700a71:	inc    %r14
  700a74:	mov    %r14,0x1a8(%rsp)
  700a7c:	mov    0x50(%rsp),%rax
  700a81:	mov    0x20(%rax),%eax
  700a84:	and    $0xf,%eax
  700a87:	cmp    $0x9,%eax
  700a8a:	ja     702f99 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4af9>
  700a90:	mov    $0x34f,%ecx
  700a95:	bt     %eax,%ecx
  700a98:	jb     700b21 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2681>
  700a9e:	movaps 0x1b0(%rsp),%xmm0
  700aa6:	movaps %xmm0,0xa0(%rsp)
  700aae:	movups 0x358(%rsp),%xmm0
  700ab6:	movaps %xmm0,0xc0(%rsp)
  700abe:	lea    0x840(%rsp),%rdi
  700ac6:	lea    0xa0(%rsp),%rsi
  700ace:	lea    0x250(%rsp),%rdx
  700ad6:	lea    0x2ec(%rsp),%rcx
  700ade:	lea    0xc0(%rsp),%r8
  700ae6:	mov    0x310(%rsp),%r9
  700aee:	call   *0x341c9c(%rip)        # a42790 <_DYNAMIC+0x7a0>
  700af4:	cmpl   $0xfffffffe,0x840(%rsp)
  700afc:	jne    702b2d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x468d>
  700b02:	lea    0x848(%rsp),%rax
  700b0a:	movups (%rax),%xmm0
  700b0d:	movaps %xmm0,0x1b0(%rsp)
  700b15:	movups 0x10(%rax),%xmm0
  700b19:	movaps %xmm0,0x250(%rsp)
  700b21:	cmpb   $0x0,0x37(%rsp)
  700b26:	je     700bc6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2726>
  700b2c:	movaps 0x1b0(%rsp),%xmm0
  700b34:	movaps %xmm0,0xc0(%rsp)
  700b3c:	mov    0x230(%rsp),%r14
  700b44:	cmp    0x220(%rsp),%r14
  700b4c:	jne    700b5b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x26bb>
  700b4e:	lea    0x220(%rsp),%rdi
  700b56:	call   6f4970 <<alloc::raw_vec::RawVec<gpui_reactivity_core::geometry::Rect>>::grow_one>
  700b5b:	mov    0x228(%rsp),%rax
  700b63:	mov    %r14,%rcx
  700b66:	shl    $0x4,%rcx
  700b6a:	movaps 0xc0(%rsp),%xmm0
  700b72:	movups %xmm0,(%rax,%rcx,1)
  700b76:	inc    %r14
  700b79:	mov    %r14,0x230(%rsp)
  700b81:	mov    0x248(%rsp),%r14
  700b89:	cmp    0x238(%rsp),%r14
  700b91:	jne    700ba0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2700>
  700b93:	lea    0x238(%rsp),%rdi
  700b9b:	call   6f4970 <<alloc::raw_vec::RawVec<gpui_reactivity_core::geometry::Rect>>::grow_one>
  700ba0:	mov    0x240(%rsp),%rax
  700ba8:	mov    %r14,%rcx
  700bab:	shl    $0x4,%rcx
  700baf:	movaps 0x250(%rsp),%xmm0
  700bb7:	movups %xmm0,(%rax,%rcx,1)
  700bbb:	inc    %r14
  700bbe:	mov    %r14,0x248(%rsp)
  700bc6:	test   %ebx,%ebx
  700bc8:	je     700bfe <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x275e>
  700bca:	lea    0xc0(%rsp),%rdi
  700bd2:	lea    0x358(%rsp),%rsi
  700bda:	lea    0x2f0(%rsp),%rdx
  700be2:	call   6db1c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#24}>
  700be7:	cmpl   $0x1,0xc0(%rsp)
  700bef:	jne    700bfe <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x275e>
  700bf1:	lea    0xc4(%rsp),%rax
  700bf9:	movups (%rax),%xmm0
  700bfc:	jmp    700c01 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2761>
  700bfe:	xorps  %xmm0,%xmm0
  700c01:	movaps %xmm0,0x3d0(%rsp)
  700c09:	mov    0x110(%rsp),%eax
  700c10:	or     %r12b,%al
  700c13:	cmp    $0x1,%al
  700c15:	je     700c28 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2788>
  700c17:	mov    0x50(%rsp),%rax
  700c1c:	mov    0x20(%rax),%edi
  700c1f:	call   6f81d0 <<gpui::runtime::Node>::kind>
  700c24:	cmp    $0x6,%al
  700c26:	jne    700c48 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x27a8>
  700c28:	lea    0x2c0(%rsp),%rdi
  700c30:	lea    0x3d0(%rsp),%rsi
  700c38:	lea    0x250(%rsp),%rdx
  700c40:	call   *0x341b52(%rip)        # a42798 <_DYNAMIC+0x7a8>
  700c46:	jmp    700cb2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2812>
  700c48:	movsd  0x3d0(%rsp),%xmm0
  700c51:	movsd  0x3d8(%rsp),%xmm1
  700c5a:	movaps %xmm0,%xmm2
  700c5d:	addps  %xmm0,%xmm1
  700c60:	xorps  %xmm4,%xmm4
  700c63:	maxps  %xmm4,%xmm0
  700c66:	movaps %xmm0,%xmm3
  700c69:	cmpunordps %xmm0,%xmm3
  700c6d:	andps  %xmm3,%xmm2
  700c70:	andnps %xmm0,%xmm3
  700c73:	orps   %xmm2,%xmm3
  700c76:	movaps %xmm1,%xmm0
  700c79:	minps  0x70(%rsp),%xmm0
  700c7e:	movaps %xmm0,%xmm2
  700c81:	cmpunordps %xmm0,%xmm2
  700c85:	andps  %xmm2,%xmm1
  700c88:	andnps %xmm0,%xmm2
  700c8b:	orps   %xmm1,%xmm2
  700c8e:	subps  %xmm3,%xmm2
  700c91:	movaps %xmm2,%xmm0
  700c94:	maxps  %xmm4,%xmm0
  700c97:	movaps %xmm0,%xmm1
  700c9a:	cmpunordps %xmm0,%xmm1
  700c9e:	andps  %xmm1,%xmm2
  700ca1:	andnps %xmm0,%xmm1
  700ca4:	orps   %xmm2,%xmm1
  700ca7:	movlhps %xmm1,%xmm3
  700caa:	movups %xmm3,0x2c0(%rsp)
  700cb2:	test   %r12b,%r12b
  700cb5:	mov    0x38(%rsp),%rcx
  700cba:	je     700ce9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2849>
  700cbc:	movss  0x2c8(%rsp),%xmm0
  700cc5:	xor    %ebp,%ebp
  700cc7:	xorps  %xmm1,%xmm1
  700cca:	ucomiss %xmm1,%xmm0
  700ccd:	jne    700cd5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2835>
  700ccf:	jnp    700f75 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2ad5>
  700cd5:	movss  0x2cc(%rsp),%xmm0
  700cde:	ucomiss %xmm1,%xmm0
  700ce1:	jne    700ce9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2849>
  700ce3:	jnp    700f75 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2ad5>
  700ce9:	mov    0x4e8(%rsp),%eax
  700cf0:	mov    $0x3fffffff,%ecx
  700cf5:	and    %ecx,%eax
  700cf7:	cmp    $0x3f800001,%eax
  700cfc:	mov    $0x80000000,%ecx
  700d01:	cmove  %ecx,%eax
  700d04:	movd   %eax,%xmm0
  700d08:	xorps  %xmm1,%xmm1
  700d0b:	ucomiss %xmm1,%xmm0
  700d0e:	jbe    700df7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2957>
  700d14:	movl   $0x1,0xc8(%rsp)
  700d1f:	movq   $0x23,0xc0(%rsp)
  700d2b:	test   %bl,%bl
  700d2d:	je     702a6f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x45cf>
  700d33:	lea    0xc0(%rsp),%rbx
  700d3b:	mov    %rbx,%rdi
  700d3e:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  700d43:	lea    0x2f0(%rsp),%rax
  700d4b:	movups (%rax),%xmm0
  700d4e:	movaps %xmm0,0xae0(%rsp)
  700d56:	mov    0x10(%rax),%rax
  700d5a:	mov    %rax,0xaf0(%rsp)
  700d62:	mov    %rbx,%rdi
  700d65:	mov    0x48(%rsp),%rsi
  700d6a:	mov    0x80(%rsp),%rdx
  700d72:	xor    %ecx,%ecx
  700d74:	call   *0x341a26(%rip)        # a427a0 <_DYNAMIC+0x7b0>
  700d7a:	mov    0xd0(%rsp),%r9
  700d82:	test   %r9,%r9
  700d85:	je     700ef9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2a59>
  700d8b:	movups 0xc0(%rsp),%xmm0
  700d93:	movaps %xmm0,0x330(%rsp)
  700d9b:	movaps 0x1b0(%rsp),%xmm0
  700da3:	movaps %xmm0,0x150(%rsp)
  700dab:	movups 0x358(%rsp),%xmm0
  700db3:	movaps %xmm0,0xa0(%rsp)
  700dbb:	lea    0x8f0(%rsp),%rdi
  700dc3:	lea    0xa0(%rsp),%rsi
  700dcb:	movss  0x128(%rsp),%xmm0
  700dd4:	lea    0xae0(%rsp),%rdx
  700ddc:	lea    0x150(%rsp),%rcx
  700de4:	lea    0x330(%rsp),%r8
  700dec:	call   *0x3419b6(%rip)        # a427a8 <_DYNAMIC+0x7b8>
  700df2:	jmp    700ee6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2a46>
  700df7:	mov    0x50(%rsp),%rax
  700dfc:	cmpq   $0x0,0x8(%rax)
  700e01:	jne    700e20 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2980>
  700e03:	mov    0x50(%rsp),%rax
  700e08:	mov    0x20(%rax),%edi
  700e0b:	call   6f81d0 <<gpui::runtime::Node>::kind>
  700e10:	mov    $0x1,%bpl
  700e13:	cmp    $0x4,%al
  700e15:	mov    0x38(%rsp),%rcx
  700e1a:	jne    700f75 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2ad5>
  700e20:	movl   $0x1,0xc8(%rsp)
  700e2b:	movq   $0x23,0xc0(%rsp)
  700e37:	test   %bl,%bl
  700e39:	je     702a6f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x45cf>
  700e3f:	lea    0xc0(%rsp),%rbx
  700e47:	mov    %rbx,%rdi
  700e4a:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  700e4f:	lea    0x2f0(%rsp),%rcx
  700e57:	movups (%rcx),%xmm0
  700e5a:	movaps %xmm0,0x150(%rsp)
  700e62:	mov    0x10(%rcx),%rax
  700e66:	mov    %rax,0x160(%rsp)
  700e6e:	movups (%rcx),%xmm0
  700e71:	movaps %xmm0,0xb90(%rsp)
  700e79:	mov    0x10(%rcx),%rax
  700e7d:	mov    %rax,0xba0(%rsp)
  700e85:	movaps 0x1b0(%rsp),%xmm0
  700e8d:	movaps %xmm0,0x330(%rsp)
  700e95:	movups 0x358(%rsp),%xmm0
  700e9d:	movaps %xmm0,0xa0(%rsp)
  700ea5:	movups -0x6bfa6c(%rip),%xmm0        # 41440 <GCC_except_table0+0x169c>
  700eac:	movaps %xmm0,0xc0(%rsp)
  700eb4:	lea    0x8f0(%rsp),%rdi
  700ebc:	lea    0xa0(%rsp),%rsi
  700ec4:	movss  0x128(%rsp),%xmm0
  700ecd:	lea    0xb90(%rsp),%rdx
  700ed5:	lea    0x330(%rsp),%rcx
  700edd:	mov    %rbx,%r8
  700ee0:	call   *0x3418ca(%rip)        # a427b0 <_DYNAMIC+0x7c0>
  700ee6:	cmp    $0xffffffff,%eax
  700ee9:	jne    702aa8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4608>
  700eef:	mov    $0x1,%bpl
  700ef2:	mov    0x38(%rsp),%rcx
  700ef7:	jmp    700f75 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2ad5>
  700ef9:	movaps 0x1b0(%rsp),%xmm0
  700f01:	movaps %xmm0,0x150(%rsp)
  700f09:	lea    0x4ec(%rsp),%rax
  700f11:	movups -0x10(%rax),%xmm0
  700f15:	movaps %xmm0,0xa0(%rsp)
  700f1d:	movups 0x358(%rsp),%xmm0
  700f25:	movaps %xmm0,0xc0(%rsp)
  700f2d:	lea    0x8f0(%rsp),%rdi
  700f35:	lea    0xc0(%rsp),%rsi
  700f3d:	movss  0x128(%rsp),%xmm0
  700f46:	lea    0xae0(%rsp),%rdx
  700f4e:	lea    0x150(%rsp),%rcx
  700f56:	lea    0xa0(%rsp),%r8
  700f5e:	call   *0x34184c(%rip)        # a427b0 <_DYNAMIC+0x7c0>
  700f64:	mov    $0x1,%bpl
  700f67:	cmp    $0xffffffff,%eax
  700f6a:	mov    0x38(%rsp),%rcx
  700f6f:	jne    702aa8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4608>
  700f75:	mov    0x50(%rsp),%rax
  700f7a:	mov    0x20(%rax),%edi
  700f7d:	mov    %edi,%eax
  700f7f:	and    $0xf,%eax
  700f82:	cmp    $0x9,%eax
  700f85:	ja     702f99 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4af9>
  700f8b:	cmp    $0x6,%eax
  700f8e:	je     701587 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x30e7>
  700f94:	shr    $0x4,%edi
  700f97:	dec    %edi
  700f99:	mov    0x2e0(%rcx),%rsi
  700fa0:	mov    0x2e8(%rcx),%rdx
  700fa7:	call   6f80c0 <<gpui::runtime::TextSlot>::get_mut>
  700fac:	test   %rax,%rax
  700faf:	je     701399 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2ef9>
  700fb5:	lea    0x4ec(%rsp),%rcx
  700fbd:	movups -0x20(%rcx),%xmm0
  700fc1:	movaps %xmm0,0x8e0(%rsp)
  700fc9:	mov    0x38(%rsp),%rcx
  700fce:	mov    0x6c8(%rcx),%rbx
  700fd5:	mov    $0x1e,%esi
  700fda:	test   %rbx,%rbx
  700fdd:	je     702ea8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4a08>
  700fe3:	cmpq   $0x0,0x30(%rbx)
  700fe8:	je     702ea8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4a08>
  700fee:	movzbl 0x46c(%rsp),%ecx
  700ff6:	mov    $0x2,%r13b
  700ff9:	cmp    $0x2,%cl
  700ffc:	je     701073 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2bd3>
  700ffe:	mov    0x50(%rsp),%rdx
  701003:	mov    (%rdx),%rdx
  701006:	cmp    %rdx,0x458(%rsp)
  70100e:	jne    701073 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2bd3>
  701010:	mov    0x468(%rsp),%edx
  701017:	mov    %edx,0x1f0(%rsp)
  70101e:	movzbl 0x464(%rsp),%edx
  701026:	mov    %dl,0x99(%rsp)
  70102d:	mov    0x460(%rsp),%edx
  701034:	mov    %edx,0x18c(%rsp)
  70103b:	lea    0x465(%rsp),%rdi
  701043:	movzwl (%rdi),%edx
  701046:	mov    %dx,0x134(%rsp)
  70104e:	movzbl 0x2(%rdi),%edx
  701052:	mov    %dl,0x136(%rsp)
  701059:	movzwl 0x8(%rdi),%edx
  70105d:	mov    %dx,0x130(%rsp)
  701065:	movzbl 0xa(%rdi),%edx
  701069:	mov    %dl,0x132(%rsp)
  701070:	mov    %ecx,%r13d
  701073:	cmpq   $0x0,0x1c8(%rsp)
  70107c:	je     702ee4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4a44>
  701082:	movss  0x4c8(%rsp),%xmm0
  70108b:	movaps 0x2b0(%rsp),%xmm1
  701093:	subss  0x390(%rsp),%xmm1
  70109c:	subss  0x328(%rsp),%xmm1
  7010a5:	subss  0x8b0(%rsp),%xmm1
  7010ae:	subss  0x32c(%rsp),%xmm1
  7010b7:	subss  0x8a0(%rsp),%xmm1
  7010c0:	lea    0xc0(%rsp),%rdi
  7010c8:	mov    %rax,%rsi
  7010cb:	lea    0x1c8(%rsp),%rdx
  7010d3:	mov    $0x1,%ecx
  7010d8:	mov    $0x1,%r8d
  7010de:	call   *0x341374(%rip)        # a42458 <_DYNAMIC+0x468>
  7010e4:	mov    0xc0(%rsp),%rax
  7010ec:	mov    0xc8(%rsp),%r15
  7010f4:	cmp    $0xfffffffffffffffe,%rax
  7010f8:	jne    702abf <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x461f>
  7010fe:	movaps 0x390(%rsp),%xmm0
  701106:	movss  %xmm0,0x148(%rsp)
  70110f:	movaps 0x890(%rsp),%xmm0
  701117:	movss  %xmm0,0x14c(%rsp)
  701120:	mov    0x20(%r15),%rax
  701124:	test   %rax,%rax
  701127:	je     702f79 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4ad9>
  70112d:	lock incq (%rax)
  701131:	mov    0x38(%rsp),%r14
  701136:	jle    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  70113c:	movsd  0x148(%rsp),%xmm0
  701145:	movsd  %xmm0,0x318(%rsp)
  70114e:	mov    %rax,0x320(%rsp)
  701156:	test   %bpl,%bpl
  701159:	je     7015d8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3138>
  70115f:	testb  $0x1,0x2ec(%rsp)
  701167:	movl   $0x1,0xc8(%rsp)
  701172:	movq   $0x23,0xc0(%rsp)
  70117e:	je     702be5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4745>
  701184:	lea    0xc0(%rsp),%rdi
  70118c:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  701191:	lea    0x2f0(%rsp),%rcx
  701199:	movups (%rcx),%xmm0
  70119c:	movaps %xmm0,0xb00(%rsp)
  7011a4:	mov    0x10(%rcx),%rax
  7011a8:	mov    %rax,0xb10(%rsp)
  7011b0:	movups (%rcx),%xmm0
  7011b3:	movaps %xmm0,0x330(%rsp)
  7011bb:	mov    0x10(%rcx),%rax
  7011bf:	mov    %rax,0x340(%rsp)
  7011c7:	cmp    $0x2,%r13b
  7011cb:	je     7012d5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2e35>
  7011d1:	mov    0x18c(%rsp),%eax
  7011d8:	mov    %eax,0xa0(%rsp)
  7011df:	movzbl 0x99(%rsp),%eax
  7011e7:	mov    %al,0xa4(%rsp)
  7011ee:	movzbl 0x136(%rsp),%eax
  7011f6:	lea    0xa5(%rsp),%rcx
  7011fe:	mov    %al,0x2(%rcx)
  701201:	movzwl 0x134(%rsp),%eax
  701209:	mov    %ax,(%rcx)
  70120c:	mov    0x1f0(%rsp),%eax
  701213:	mov    %eax,0xa8(%rsp)
  70121a:	mov    %r13b,0xac(%rsp)
  701222:	movzbl 0x132(%rsp),%eax
  70122a:	mov    %al,0xa(%rcx)
  70122d:	movzwl 0x130(%rsp),%eax
  701235:	mov    %ax,0x8(%rcx)
  701239:	movl   $0xffffffff,0x150(%rsp)
  701244:	lea    0x150(%rsp),%rax
  70124c:	mov    %rax,0xc0(%rsp)
  701254:	lea    0x8f0(%rsp),%rax
  70125c:	mov    %rax,0xc8(%rsp)
  701264:	lea    0x148(%rsp),%rax
  70126c:	mov    %rax,0xd0(%rsp)
  701274:	lea    0x14c(%rsp),%rax
  70127c:	mov    %rax,0xd8(%rsp)
  701284:	lea    0x330(%rsp),%rax
  70128c:	mov    %rax,0xe0(%rsp)
  701294:	lea    0x1b0(%rsp),%rax
  70129c:	mov    %rax,0xe8(%rsp)
  7012a4:	mov    0x20(%r15),%rdi
  7012a8:	lea    0xa0(%rsp),%rsi
  7012b0:	lea    0xc0(%rsp),%rdx
  7012b8:	call   6b8010 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>>
  7012bd:	test   %al,%al
  7012bf:	je     702c89 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x47e9>
  7012c5:	mov    0x150(%rsp),%eax
  7012cc:	cmp    $0xffffffff,%eax
  7012cf:	jne    702c97 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x47f7>
  7012d5:	lea    0xa0(%rsp),%rdi
  7012dd:	mov    0x48(%rsp),%rsi
  7012e2:	mov    0x80(%rsp),%rdx
  7012ea:	mov    $0x1,%ecx
  7012ef:	call   *0x3414ab(%rip)        # a427a0 <_DYNAMIC+0x7b0>
  7012f5:	add    $0x30,%rbx
  7012f9:	mov    0xb0(%rsp),%rax
  701301:	test   %rax,%rax
  701304:	je     7013aa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2f0a>
  70130a:	movups 0xa0(%rsp),%xmm0
  701312:	movaps %xmm0,0x3e0(%rsp)
  70131a:	movaps 0x1b0(%rsp),%xmm0
  701322:	movaps %xmm0,0x150(%rsp)
  70132a:	movss  0x148(%rsp),%xmm0
  701333:	movss  0x14c(%rsp),%xmm1
  70133c:	lea    0x2f0(%rsp),%rdx
  701344:	mov    0x10(%rdx),%rcx
  701348:	mov    %rcx,0xd0(%rsp)
  701350:	movups (%rdx),%xmm2
  701353:	movaps %xmm2,0xc0(%rsp)
  70135b:	mov    %rax,(%rsp)
  70135f:	lea    0x8f0(%rsp),%rdi
  701367:	mov    %rbx,%rsi
  70136a:	mov    %r15,%rdx
  70136d:	lea    0xc0(%rsp),%rcx
  701375:	lea    0x150(%rsp),%r8
  70137d:	lea    0x3e0(%rsp),%r9
  701385:	movss  0x9c(%rsp),%xmm2
  70138e:	call   *0x341424(%rip)        # a427b8 <_DYNAMIC+0x7c8>
  701394:	jmp    701430 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2f90>
  701399:	movq   $0x0,0x218(%rsp)
  7013a5:	jmp    7015f8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3158>
  7013aa:	movaps 0x1b0(%rsp),%xmm0
  7013b2:	movaps %xmm0,0x150(%rsp)
  7013ba:	movss  0x148(%rsp),%xmm0
  7013c3:	movss  0x14c(%rsp),%xmm1
  7013cc:	lea    0x2f0(%rsp),%rcx
  7013d4:	mov    0x10(%rcx),%rax
  7013d8:	mov    %rax,0xd0(%rsp)
  7013e0:	movups (%rcx),%xmm2
  7013e3:	movaps %xmm2,0xc0(%rsp)
  7013eb:	movaps 0x8e0(%rsp),%xmm2
  7013f3:	movaps %xmm2,0xa0(%rsp)
  7013fb:	lea    0x8f0(%rsp),%rdi
  701403:	mov    %rbx,%rsi
  701406:	mov    %r15,%rdx
  701409:	lea    0xc0(%rsp),%rcx
  701411:	lea    0x150(%rsp),%r8
  701419:	lea    0xa0(%rsp),%r9
  701421:	movss  0x9c(%rsp),%xmm2
  70142a:	call   *0x341390(%rip)        # a427c0 <_DYNAMIC+0x7d0>
  701430:	cmp    $0xffffffff,%eax
  701433:	jne    702bce <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x472e>
  701439:	cmp    $0x2,%r13b
  70143d:	je     7015d8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3138>
  701443:	mov    0x18c(%rsp),%eax
  70144a:	cmp    0x1f0(%rsp),%eax
  701451:	jne    7015d8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3138>
  701457:	mov    0x618(%r14),%rax
  70145e:	test   %rax,%rax
  701461:	je     7015d8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3138>
  701467:	cmp    0x5e0(%r14),%rax
  70146e:	jne    7015d8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3138>
  701474:	mov    0x50(%rsp),%rax
  701479:	mov    (%rax),%rax
  70147c:	cmp    %rax,0x620(%r14)
  701483:	jne    7015d8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3138>
  701489:	movzbl %r13b,%ecx
  70148d:	lea    0xa0(%rsp),%rdi
  701495:	mov    %r15,%rsi
  701498:	mov    0x18c(%rsp),%edx
  70149f:	call   *0x3411bb(%rip)        # a42660 <_DYNAMIC+0x670>
  7014a5:	movq   $0x18,0xc0(%rsp)
  7014b1:	cmpl   $0x1,0xa0(%rsp)
  7014b9:	jne    702c89 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x47e9>
  7014bf:	lea    0xc0(%rsp),%rbx
  7014c7:	mov    %rbx,%rdi
  7014ca:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  7014cf:	movsd  0xa4(%rsp),%xmm0
  7014d8:	movaps 0x390(%rsp),%xmm1
  7014e0:	unpcklps 0x890(%rsp),%xmm1
  7014e8:	addps  %xmm0,%xmm1
  7014eb:	movhps 0xac(%rsp),%xmm1
  7014f3:	movups %xmm1,0x3e0(%rsp)
  7014fb:	mov    %rbx,%rdi
  7014fe:	mov    0x48(%rsp),%rsi
  701503:	mov    0x80(%rsp),%rdx
  70150b:	mov    $0x1,%ecx
  701510:	call   *0x34128a(%rip)        # a427a0 <_DYNAMIC+0x7b0>
  701516:	mov    0xd0(%rsp),%r9
  70151e:	test   %r9,%r9
  701521:	je     701591 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x30f1>
  701523:	movups 0xc0(%rsp),%xmm0
  70152b:	movaps %xmm0,0x150(%rsp)
  701533:	movaps 0x1b0(%rsp),%xmm0
  70153b:	movaps %xmm0,0xa0(%rsp)
  701543:	xorps  %xmm0,%xmm0
  701546:	lea    0x8f0(%rsp),%rdi
  70154e:	lea    0x3e0(%rsp),%rsi
  701556:	lea    0xb00(%rsp),%rdx
  70155e:	lea    0xa0(%rsp),%rcx
  701566:	lea    0x150(%rsp),%r8
  70156e:	call   *0x341234(%rip)        # a427a8 <_DYNAMIC+0x7b8>
  701574:	jmp    7015cf <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x312f>
  701576:	mov    $0x1,%r12b
  701579:	cmp    $0x7,%eax
  70157c:	je     700a33 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2593>
  701582:	jmp    702f99 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4af9>
  701587:	mov    $0xffffffff,%edi
  70158c:	jmp    700f99 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2af9>
  701591:	movaps 0x1b0(%rsp),%xmm0
  701599:	movaps %xmm0,0xc0(%rsp)
  7015a1:	lea    0x8f0(%rsp),%rdi
  7015a9:	lea    0x3e0(%rsp),%rsi
  7015b1:	lea    0xb00(%rsp),%rdx
  7015b9:	lea    0xc0(%rsp),%rcx
  7015c1:	lea    0x8e0(%rsp),%r8
  7015c9:	call   *0x340d09(%rip)        # a422d8 <_DYNAMIC+0x2e8>
  7015cf:	cmp    $0xffffffff,%eax
  7015d2:	jne    702bce <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x472e>
  7015d8:	mov    0x318(%rsp),%rax
  7015e0:	mov    %rax,0x210(%rsp)
  7015e8:	mov    0x320(%rsp),%rax
  7015f0:	mov    %rax,0x218(%rsp)
  7015f8:	test   %bpl,%bpl
  7015fb:	je     701758 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x32b8>
  701601:	mov    0x50(%rsp),%rax
  701606:	mov    0x20(%rax),%edi
  701609:	mov    $0x1,%r14b
  70160c:	call   *0x340e3e(%rip)        # a42450 <_DYNAMIC+0x460>
  701612:	mov    %edx,%ebp
  701614:	cmp    $0x2,%dl
  701617:	je     701758 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x32b8>
  70161d:	mov    0x280(%rsp),%rcx
  701625:	mov    (%rcx),%rcx
  701628:	test   %rcx,%rcx
  70162b:	je     702fb7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b17>
  701631:	mov    0x10(%rcx),%rsi
  701635:	mov    %eax,%ebx
  701637:	cmp    %rbx,%rsi
  70163a:	jbe    703192 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4cf2>
  701640:	mov    0x8(%rcx),%rax
  701644:	movaps 0x8b0(%rsp),%xmm3
  70164c:	movaps %xmm3,%xmm0
  70164f:	shufps $0xe8,%xmm3,%xmm0
  701653:	movaps 0x8c0(%rsp),%xmm5
  70165b:	addps  %xmm0,%xmm5
  70165e:	movaps 0x390(%rsp),%xmm4
  701666:	movaps %xmm4,%xmm1
  701669:	shufps $0xe8,%xmm4,%xmm1
  70166d:	movaps 0x2b0(%rsp),%xmm2
  701675:	subps  %xmm1,%xmm2
  701678:	addps  %xmm5,%xmm1
  70167b:	shufps $0xed,%xmm4,%xmm4
  70167f:	subps  %xmm4,%xmm2
  701682:	subps  %xmm0,%xmm2
  701685:	shufps $0xed,%xmm3,%xmm3
  701689:	subps  %xmm3,%xmm2
  70168c:	subps  0x8a0(%rsp),%xmm2
  701694:	movlhps %xmm2,%xmm1
  701697:	movups %xmm1,0x330(%rsp)
  70169f:	testb  $0x1,0x2ec(%rsp)
  7016a7:	movl   $0x1,0xc8(%rsp)
  7016b2:	movq   $0x23,0xc0(%rsp)
  7016be:	je     702c1e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x477e>
  7016c4:	lea    (%rax,%rbx,8),%rbx
  7016c8:	lea    0xc0(%rsp),%r15
  7016d0:	mov    %r15,%rdi
  7016d3:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  7016d8:	lea    0x2f0(%rsp),%rcx
  7016e0:	movups (%rcx),%xmm0
  7016e3:	movaps %xmm0,0x150(%rsp)
  7016eb:	mov    0x10(%rcx),%rax
  7016ef:	mov    %rax,0x160(%rsp)
  7016f7:	movups (%rcx),%xmm0
  7016fa:	movaps %xmm0,0xbb0(%rsp)
  701702:	mov    0x10(%rcx),%rax
  701706:	mov    %rax,0xbc0(%rsp)
  70170e:	movaps 0x1b0(%rsp),%xmm0
  701716:	movaps %xmm0,0xc0(%rsp)
  70171e:	movzbl %bpl,%r9d
  701722:	lea    0x8f0(%rsp),%rdi
  70172a:	mov    %rbx,%rsi
  70172d:	lea    0x330(%rsp),%rdx
  701735:	lea    0xbb0(%rsp),%rcx
  70173d:	mov    %r15,%r8
  701740:	movss  0x128(%rsp),%xmm0
  701749:	call   *0x341079(%rip)        # a427c8 <_DYNAMIC+0x7d8>
  70174f:	cmp    $0xffffffff,%eax
  701752:	jne    702c54 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x47b4>
  701758:	mov    0x50(%rsp),%rax
  70175d:	mov    0x18(%rax),%ebx
  701760:	cmpb   $0x0,0x37(%rsp)
  701765:	je     70178f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x32ef>
  701767:	cmp    $0xffffffff,%ebx
  70176a:	je     70178a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x32ea>
  70176c:	mov    0x180(%rsp),%rsi
  701774:	cmp    %rbx,%rsi
  701777:	jbe    703183 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4ce3>
  70177d:	mov    0x178(%rsp),%rax
  701785:	mov    (%rax,%rbx,4),%ebx
  701788:	jmp    70178f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x32ef>
  70178a:	mov    $0xffffffff,%ebx
  70178f:	cmpb   $0x0,0x110(%rsp)
  701797:	je     7017c4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3324>
  701799:	movss  0x2c8(%rsp),%xmm0
  7017a2:	xorps  %xmm1,%xmm1
  7017a5:	ucomiss %xmm1,%xmm0
  7017a8:	jne    7017b0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3310>
  7017aa:	jnp    7018f9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3459>
  7017b0:	movss  0x2cc(%rsp),%xmm0
  7017b9:	ucomiss %xmm1,%xmm0
  7017bc:	jne    7017c4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3324>
  7017be:	jnp    7018f9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3459>
  7017c4:	mov    0x50(%rsp),%rax
  7017c9:	mov    0x20(%rax),%edi
  7017cc:	mov    $0x1,%r14b
  7017cf:	call   6f81d0 <<gpui::runtime::Node>::kind>
  7017d4:	cmp    $0x7,%al
  7017d6:	jne    7017f0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3350>
  7017d8:	mov    0x50(%rsp),%rax
  7017dd:	mov    (%rax),%rsi
  7017e0:	mov    $0x1,%r14b
  7017e3:	lea    0x378(%rsp),%rdi
  7017eb:	call   6fc490 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  7017f0:	cmpb   $0x0,0x37(%rsp)
  7017f5:	je     701848 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x33a8>
  7017f7:	mov    0x1e8(%rsp),%rsi
  7017ff:	mov    $0x1,%edi
  701804:	mov    $0x1,%r14b
  701807:	call   *0x340a8b(%rip)        # a42298 <_DYNAMIC+0x2a8>
  70180d:	mov    %eax,%ebp
  70180f:	mov    0x180(%rsp),%r15
  701817:	cmp    0x170(%rsp),%r15
  70181f:	jne    701831 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3391>
  701821:	mov    $0x1,%r14b
  701824:	lea    0x170(%rsp),%rdi
  70182c:	call   6f4820 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  701831:	mov    0x178(%rsp),%rax
  701839:	mov    %ebp,(%rax,%r15,4)
  70183d:	inc    %r15
  701840:	mov    %r15,0x180(%rsp)
  701848:	movss  0x2c8(%rsp),%xmm0
  701851:	xor    %edx,%edx
  701853:	xorps  %xmm1,%xmm1
  701856:	ucomiss %xmm1,%xmm0
  701859:	jne    701861 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x33c1>
  70185b:	jnp    7019bf <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x351f>
  701861:	movss  0x2cc(%rsp),%xmm0
  70186a:	ucomiss %xmm1,%xmm0
  70186d:	mov    $0x0,%r8d
  701873:	mov    0x50(%rsp),%rsi
  701878:	jne    701880 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x33e0>
  70187a:	jnp    7019c2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3522>
  701880:	mov    0x20(%rsi),%edi
  701883:	mov    %edi,%eax
  701885:	and    $0xf,%eax
  701888:	cmp    $0x9,%eax
  70188b:	ja     703046 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4ba6>
  701891:	cmp    $0x6,%eax
  701894:	je     7018a2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3402>
  701896:	mov    $0x1,%r8b
  701899:	cmp    $0xf,%edi
  70189c:	ja     7019c2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3522>
  7018a2:	mov    0x4e8(%rsp),%eax
  7018a9:	mov    $0x3fffffff,%ecx
  7018ae:	and    %ecx,%eax
  7018b0:	cmp    $0x3f800001,%eax
  7018b5:	mov    $0x80000000,%ecx
  7018ba:	cmove  %ecx,%eax
  7018bd:	movd   %eax,%xmm0
  7018c1:	mov    $0x1,%r8b
  7018c4:	ucomiss %xmm1,%xmm0
  7018c7:	ja     7019c2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3522>
  7018cd:	cmpq   $0x0,0x8(%rsi)
  7018d2:	jne    7019c2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3522>
  7018d8:	mov    $0x1,%r14b
  7018db:	call   6f81d0 <<gpui::runtime::Node>::kind>
  7018e0:	lea    -0x4(%rax),%ecx
  7018e3:	cmp    $0x2,%al
  7018e5:	setae  %al
  7018e8:	test   $0xfb,%cl
  7018eb:	sete   %r8b
  7018ef:	and    %al,%r8b
  7018f2:	xor    %edx,%edx
  7018f4:	jmp    7019c2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3522>
  7018f9:	cmpb   $0x0,0x1f4(%rsp)
  701901:	je     70192b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x348b>
  701903:	movss  0x258(%rsp),%xmm0
  70190c:	ucomiss %xmm1,%xmm0
  70190f:	jne    701913 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3473>
  701911:	jnp    70192b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x348b>
  701913:	movss  0x25c(%rsp),%xmm0
  70191c:	ucomiss %xmm1,%xmm0
  70191f:	jne    7017c4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3324>
  701925:	jp     7017c4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3324>
  70192b:	test   %r12b,%r12b
  70192e:	je     701958 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x34b8>
  701930:	movss  0x258(%rsp),%xmm0
  701939:	ucomiss %xmm1,%xmm0
  70193c:	jne    701940 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x34a0>
  70193e:	jnp    701958 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x34b8>
  701940:	movss  0x25c(%rsp),%xmm0
  701949:	ucomiss %xmm1,%xmm0
  70194c:	jne    7017c4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3324>
  701952:	jp     7017c4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3324>
  701958:	mov    0x180(%rsp),%r15
  701960:	cmp    0x170(%rsp),%r15
  701968:	jne    70197a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x34da>
  70196a:	mov    $0x1,%r14b
  70196d:	lea    0x170(%rsp),%rdi
  701975:	call   6f4820 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  70197a:	mov    0x178(%rsp),%rax
  701982:	mov    %ebx,(%rax,%r15,4)
  701986:	inc    %r15
  701989:	mov    %r15,0x180(%rsp)
  701991:	mov    0x218(%rsp),%rax
  701999:	test   %rax,%rax
  70199c:	je     7000a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1c00>
  7019a2:	lock decq (%rax)
  7019a6:	jne    7000a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1c00>
  7019ac:	lea    0x218(%rsp),%rdi
  7019b4:	call   *0x34097e(%rip)        # a42338 <_DYNAMIC+0x348>
  7019ba:	jmp    7000a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1c00>
  7019bf:	xor    %r8d,%r8d
  7019c2:	mov    0x1e8(%rsp),%rax
  7019ca:	test   %rax,%rax
  7019cd:	je     7019e4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3544>
  7019cf:	mov    0x1e0(%rsp),%rcx
  7019d7:	shl    $0x6,%rax
  7019db:	mov    -0x8(%rcx,%rax,1),%ecx
  7019df:	mov    $0x1,%edx
  7019e4:	mov    %r8d,%ebp
  7019e7:	mov    %r8d,%eax
  7019ea:	xor    $0x1,%al
  7019ec:	movzbl %al,%esi
  7019ef:	mov    $0x1,%r14b
  7019f2:	mov    %ebx,%edi
  7019f4:	call   *0x340dd6(%rip)        # a427d0 <_DYNAMIC+0x7e0>
  7019fa:	mov    %eax,0x110(%rsp)
  701a01:	mov    0x218(%rsp),%rax
  701a09:	test   %rax,%rax
  701a0c:	sete   %r12b
  701a10:	je     701a52 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x35b2>
  701a12:	mov    0x1e8(%rsp),%ecx
  701a19:	mov    %ecx,0xd0(%rsp)
  701a20:	movsd  0x210(%rsp),%xmm0
  701a29:	movsd  %xmm0,0xc8(%rsp)
  701a32:	mov    %rax,0xc0(%rsp)
  701a3a:	xor    %r14d,%r14d
  701a3d:	lea    0x288(%rsp),%rdi
  701a45:	lea    0xc0(%rsp),%rsi
  701a4d:	call   6f7b00 <<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>::push_mut>
  701a52:	cmp    $0xffffffff,%ebx
  701a55:	mov    %r12b,0x80(%rsp)
  701a5d:	je     701a92 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x35f2>
  701a5f:	mov    %ebx,%edi
  701a61:	mov    0x1e8(%rsp),%rsi
  701a69:	cmp    %rdi,%rsi
  701a6c:	jbe    70314f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4caf>
  701a72:	mov    0x1e0(%rsp),%rax
  701a7a:	shl    $0x6,%rdi
  701a7e:	mov    0x30(%rax,%rdi,1),%rax
  701a83:	mov    %rax,0xc4(%rsp)
  701a8b:	mov    $0x1,%eax
  701a90:	jmp    701a94 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x35f4>
  701a92:	xor    %eax,%eax
  701a94:	mov    %eax,0xc0(%rsp)
  701a9b:	mov    %r12d,%r14d
  701a9e:	lea    0x2ec(%rsp),%rdi
  701aa6:	lea    0xc0(%rsp),%rsi
  701aae:	lea    0x2d0(%rsp),%rdx
  701ab6:	call   *0x340d1c(%rip)        # a427d8 <_DYNAMIC+0x7e8>
  701abc:	mov    %rax,%rbx
  701abf:	mov    0x50(%rsp),%rax
  701ac4:	mov    (%rax),%r13
  701ac7:	mov    0x20(%rax),%edi
  701aca:	mov    %r12d,%r14d
  701acd:	call   6f81d0 <<gpui::runtime::Node>::kind>
  701ad2:	mov    %eax,%r15d
  701ad5:	mov    0x50(%rsp),%rax
  701ada:	mov    0x20(%rax),%edi
  701add:	mov    %edi,%eax
  701adf:	and    $0xf,%eax
  701ae2:	cmp    $0x9,%eax
  701ae5:	ja     702fe3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b43>
  701aeb:	cmp    $0x6,%eax
  701aee:	mov    0x38(%rsp),%rax
  701af3:	je     701cd0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3830>
  701af9:	shr    $0x4,%edi
  701afc:	dec    %edi
  701afe:	mov    0x2e0(%rax),%rsi
  701b05:	mov    0x2e8(%rax),%rdx
  701b0c:	mov    %r12d,%r14d
  701b0f:	call   6f8070 <<gpui::runtime::TextSlot>::get>
  701b14:	test   %rax,%rax
  701b17:	je     701b4f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x36af>
  701b19:	mov    0x40(%rax),%r12
  701b1d:	testb  $0x1,(%r12)
  701b22:	jne    701b52 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x36b2>
  701b24:	mov    0x8(%r12),%rax
  701b29:	test   $0x1,%al
  701b2b:	jne    701b52 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x36b2>
  701b2d:	mov    $0x2,%eax
  701b32:	lock xadd %rax,0x8(%r12)
  701b39:	and    0x7e8(%rsp),%rax
  701b41:	neg    %rax
  701b44:	jno    701b52 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x36b2>
  701b46:	lock orq $0x1,0x8(%r12)
  701b4d:	jmp    701b52 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x36b2>
  701b4f:	xor    %r12d,%r12d
  701b52:	movdqa 0x2b0(%rsp),%xmm0
  701b5b:	movd   %xmm0,%esi
  701b5f:	shufps $0x55,%xmm0,%xmm0
  701b63:	movd   %xmm0,%eax
  701b67:	shl    $0x20,%rax
  701b6b:	or     %rax,%rsi
  701b6e:	lea    0xa0(%rsp),%rdi
  701b76:	lea    0x2ec(%rsp),%rdx
  701b7e:	call   *0x340c5c(%rip)        # a427e0 <_DYNAMIC+0x7f0>
  701b84:	mov    0x50(%rsp),%r14
  701b89:	mov    0x20(%r14),%edi
  701b8d:	call   6f81d0 <<gpui::runtime::Node>::kind>
  701b92:	xor    %esi,%esi
  701b94:	cmpq   $0x0,0x8(%r14)
  701b99:	setne  %sil
  701b9d:	movzbl %al,%edi
  701ba0:	call   6f7e20 <<gpui::runtime::semantics::Actions>::for_node>
  701ba5:	mov    0x18(%r14),%ecx
  701ba9:	mov    $0xffffffff,%edx
  701bae:	cmp    %rdx,%rcx
  701bb1:	je     701bd7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3737>
  701bb3:	cmp    %rcx,0x1a8(%rsp)
  701bbb:	jbe    701bd7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3737>
  701bbd:	mov    0x1a0(%rsp),%rdx
  701bc5:	cmpb   $0x0,(%rdx,%rcx,1)
  701bc9:	setne  %cl
  701bcc:	mov    0x190(%rsp),%edx
  701bd3:	or     %cl,%dl
  701bd5:	jmp    701bde <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x373e>
  701bd7:	mov    0x190(%rsp),%edx
  701bde:	movzbl %al,%ecx
  701be1:	or     $0x20,%al
  701be3:	movzbl %al,%eax
  701be6:	test   %dl,%dl
  701be8:	cmove  %ecx,%eax
  701beb:	mov    %r13,0xe0(%rsp)
  701bf3:	mov    0x110(%rsp),%ecx
  701bfa:	mov    %ecx,0xf8(%rsp)
  701c01:	mov    %r15b,0xfd(%rsp)
  701c09:	mov    %r12,0xe8(%rsp)
  701c11:	movups 0xa0(%rsp),%xmm0
  701c19:	movaps %xmm0,0xc0(%rsp)
  701c21:	mov    %rbx,0xf0(%rsp)
  701c29:	movups 0x2c0(%rsp),%xmm0
  701c31:	lea    0xc4(%rsp),%rcx
  701c39:	movups %xmm0,0xc(%rcx)
  701c3d:	mov    %bpl,0xfe(%rsp)
  701c45:	mov    %al,0xfc(%rsp)
  701c4c:	movzbl 0x80(%rsp),%ebp
  701c54:	mov    %ebp,%r14d
  701c57:	lea    0x1d8(%rsp),%rdi
  701c5f:	lea    0xc0(%rsp),%rsi
  701c67:	call   6f7a80 <<alloc::vec::Vec<gpui::runtime::Presented>>::push_mut>
  701c6c:	cmpl   $0xffffffff,0x780(%rsp)
  701c74:	je     7000a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1c00>
  701c7a:	mov    0x138(%rsp),%rax
  701c82:	mov    (%rax),%rbx
  701c85:	test   %rbx,%rbx
  701c88:	je     7000a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1c00>
  701c8e:	mov    0x50(%rsp),%rax
  701c93:	mov    (%rax),%r15
  701c96:	mov    0x38(%rsp),%rax
  701c9b:	mov    0x660(%rax),%rdi
  701ca2:	mov    0x668(%rax),%rsi
  701ca9:	mov    %r15,%rdx
  701cac:	call   6be4a0 <<alloc::collections::btree::map::BTreeMap<u64, gpui::runtime::list::ListRow>>::get::<u64>>
  701cb1:	mov    %ebp,%r14d
  701cb4:	lea    0x780(%rsp),%rdi
  701cbc:	mov    %rbx,%rsi
  701cbf:	mov    %r15,%rdx
  701cc2:	mov    %rax,%rcx
  701cc5:	call   *0x34099d(%rip)        # a42668 <_DYNAMIC+0x678>
  701ccb:	jmp    7000a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1c00>
  701cd0:	mov    $0xffffffff,%edi
  701cd5:	jmp    701afe <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x365e>
  701cda:	cmpl   $0xffffffff,0x780(%rsp)
  701ce2:	je     701cf2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3852>
  701ce4:	lea    0x780(%rsp),%rdi
  701cec:	call   *0x34097e(%rip)        # a42670 <_DYNAMIC+0x680>
  701cf2:	lea    0x1e8(%r14),%rbx
  701cf9:	mov    0x640(%r14),%rax
  701d00:	test   %rax,%rax
  701d03:	je     701de7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3947>
  701d09:	mov    0x100(%rax),%rdx
  701d10:	lea    0x2d0(%rsp),%rax
  701d18:	mov    %rax,0x4b0(%rsp)
  701d20:	lea    0x37(%rsp),%rax
  701d25:	mov    %rax,0x4b8(%rsp)
  701d2d:	mov    %rbx,0x4c0(%rsp)
  701d35:	lea    0x170(%rsp),%rax
  701d3d:	mov    %rax,0x4c8(%rsp)
  701d45:	lea    0x1d8(%rsp),%rax
  701d4d:	mov    %rax,0x4d0(%rsp)
  701d55:	test   %rdx,%rdx
  701d58:	je     701de7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3947>
  701d5e:	lea    0xc0(%rsp),%rdi
  701d66:	lea    0x4b0(%rsp),%rsi
  701d6e:	call   6db200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}>
  701d73:	mov    0xd0(%rsp),%rax
  701d7b:	mov    %rax,0x480(%rsp)
  701d83:	movups 0xc0(%rsp),%xmm0
  701d8b:	movaps %xmm0,0x470(%rsp)
  701d93:	jmp    701df3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3953>
  701d95:	movaps 0x8f0(%rsp),%xmm0
  701d9d:	movaps 0x900(%rsp),%xmm1
  701da5:	movaps 0x910(%rsp),%xmm2
  701dad:	mov    0x40(%rsp),%rcx
  701db2:	movups %xmm2,0x28(%rcx)
  701db6:	movups %xmm1,0x18(%rcx)
  701dba:	movups %xmm0,0x8(%rcx)
  701dbe:	mov    %rax,(%rcx)
  701dc1:	mov    $0x1,%r12b
  701dc4:	mov    $0x1,%al
  701dc6:	mov    %eax,0x50(%rsp)
  701dca:	mov    $0x1,%r13b
  701dcd:	mov    $0x1,%bpl
  701dd0:	mov    $0x1,%r15b
  701dd3:	cmpq   $0xffffffffffffffff,0x278(%rsp)
  701ddc:	jne    702d0a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x486a>
  701de2:	jmp    702d1a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x487a>
  701de7:	movq   $0xffffffffffffffff,0x470(%rsp)
  701df3:	mov    %rbx,0x2b0(%rsp)
  701dfb:	mov    0x2e0(%rsp),%rax
  701e03:	mov    %rax,0x4c0(%rsp)
  701e0b:	movups 0x2d0(%rsp),%xmm0
  701e13:	movaps %xmm0,0x4b0(%rsp)
  701e1b:	lea    0xa0(%rsp),%rdi
  701e23:	lea    0x470(%rsp),%rsi
  701e2b:	lea    0x4b0(%rsp),%rdx
  701e33:	call   6b6600 <<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#37}>>
  701e38:	cmpb   $0x0,0x74d(%r14)
  701e40:	je     701e9d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x39fd>
  701e42:	lea    0x4b0(%rsp),%rbx
  701e4a:	lea    0x8f0(%rsp),%rsi
  701e52:	mov    $0x1f0,%edx
  701e57:	mov    %rbx,%rdi
  701e5a:	call   *0x340418(%rip)        # a42278 <memcpy@GLIBC_2.14>
  701e60:	mov    $0x1,%al
  701e62:	mov    %eax,0x68(%rsp)
  701e66:	mov    $0x1,%r12b
  701e69:	mov    $0x1,%al
  701e6b:	mov    %eax,0x70(%rsp)
  701e6f:	mov    $0x1,%al
  701e71:	mov    %eax,0x50(%rsp)
  701e75:	mov    $0x1,%r15b
  701e78:	mov    $0x1,%bpl
  701e7b:	movb   $0x1,0x80(%rsp)
  701e83:	mov    %rbx,%rdi
  701e86:	call   *0x34095c(%rip)        # a427e8 <_DYNAMIC+0x7f8>
  701e8c:	movq   $0x0,0x110(%rsp)
  701e98:	jmp    701f30 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3a90>
  701e9d:	lea    0x4b0(%rsp),%rbx
  701ea5:	lea    0x8f0(%rsp),%rsi
  701ead:	mov    $0x1f0,%edx
  701eb2:	mov    %rbx,%rdi
  701eb5:	call   *0x3403bd(%rip)        # a42278 <memcpy@GLIBC_2.14>
  701ebb:	mov    $0x1,%al
  701ebd:	mov    %eax,0x68(%rsp)
  701ec1:	mov    $0x1,%r12b
  701ec4:	mov    $0x1,%al
  701ec6:	mov    %eax,0x70(%rsp)
  701eca:	mov    $0x1,%al
  701ecc:	mov    %eax,0x50(%rsp)
  701ed0:	mov    $0x1,%r15b
  701ed3:	mov    $0x1,%bpl
  701ed6:	movb   $0x1,0x80(%rsp)
  701ede:	mov    %rbx,%rdi
  701ee1:	call   *0x340909(%rip)        # a427f0 <_DYNAMIC+0x800>
  701ee7:	cmpq   $0xffffffffffffffff,0x5b8(%r14)
  701eef:	je     701efa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3a5a>
  701ef1:	mov    0x5d0(%r14),%rsi
  701ef8:	jmp    701efc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3a5c>
  701efa:	xor    %esi,%esi
  701efc:	mov    $0x1,%cl
  701efe:	mov    %ecx,0x68(%rsp)
  701f02:	mov    $0x1,%r12b
  701f05:	mov    $0x1,%cl
  701f07:	mov    %ecx,0x70(%rsp)
  701f0b:	mov    $0x1,%cl
  701f0d:	mov    %ecx,0x50(%rsp)
  701f11:	mov    $0x1,%r15b
  701f14:	mov    $0x1,%bpl
  701f17:	movb   $0x1,0x80(%rsp)
  701f1f:	mov    %rax,%rdi
  701f22:	call   *0x340718(%rip)        # a42640 <_DYNAMIC+0x650>
  701f28:	mov    %rax,0x110(%rsp)
  701f30:	mov    0x648(%r14),%rax
  701f37:	mov    0x658(%r14),%r12
  701f3e:	test   %rax,%rax
  701f41:	setne  %cl
  701f44:	test   %r12,%r12
  701f47:	setne  %dl
  701f4a:	test   %dl,%cl
  701f4c:	je     70213e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3c9e>
  701f52:	mov    0x38(%rsp),%rcx
  701f57:	mov    0x650(%rcx),%r13
  701f5e:	xor    %r14d,%r14d
  701f61:	lea    0x4b0(%rsp),%rbx
  701f69:	lea    0x3a0(%rsp),%r15
  701f71:	jmp    701f81 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3ae1>
  701f73:	mov    $0x0,%eax
  701f78:	dec    %r12
  701f7b:	je     70213e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3c9e>
  701f81:	test   %r14,%r14
  701f84:	jne    702008 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3b68>
  701f8a:	test   %r13,%r13
  701f8d:	je     701fb7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3b17>
  701f8f:	mov    %r13,%rcx
  701f92:	mov    %rax,%r14
  701f95:	and    $0x7,%rcx
  701f99:	je     701fbc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3b1c>
  701f9b:	xor    %edx,%edx
  701f9d:	nopl   (%rax)
  701fa0:	mov    0x590(%r14),%r14
  701fa7:	inc    %rdx
  701faa:	cmp    %rdx,%rcx
  701fad:	jne    701fa0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3b00>
  701faf:	mov    %r13,%rax
  701fb2:	sub    %rdx,%rax
  701fb5:	jmp    701fbf <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3b1f>
  701fb7:	mov    %rax,%r14
  701fba:	jmp    702003 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3b63>
  701fbc:	mov    %r13,%rax
  701fbf:	cmp    $0x8,%r13
  701fc3:	jb     702003 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3b63>
  701fc5:	mov    0x590(%r14),%rcx
  701fcc:	mov    0x590(%rcx),%rcx
  701fd3:	mov    0x590(%rcx),%rcx
  701fda:	mov    0x590(%rcx),%rcx
  701fe1:	mov    0x590(%rcx),%rcx
  701fe8:	mov    0x590(%rcx),%rcx
  701fef:	mov    0x590(%rcx),%rcx
  701ff6:	mov    0x590(%rcx),%r14
  701ffd:	add    $0xfffffffffffffff8,%rax
  702001:	jne    701fc5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3b25>
  702003:	xor    %r13d,%r13d
  702006:	xor    %eax,%eax
  702008:	movzwl 0x58a(%r14),%ecx
  702010:	cmp    %rcx,%r13
  702013:	jae    702020 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3b80>
  702015:	mov    %r13,%rdx
  702018:	mov    %r14,%rcx
  70201b:	jmp    702047 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3ba7>
  70201d:	nopl   (%rax)
  702020:	mov    0x580(%r14),%rcx
  702027:	test   %rcx,%rcx
  70202a:	je     70300d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b6d>
  702030:	inc    %rax
  702033:	movzwl 0x588(%r14),%edx
  70203b:	mov    %rcx,%r14
  70203e:	cmp    0x58a(%rcx),%dx
  702045:	jae    702020 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3b80>
  702047:	test   %rax,%rax
  70204a:	je     70208a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3bea>
  70204c:	lea    (%rcx,%rdx,8),%rsi
  702050:	add    $0x598,%rsi
  702057:	mov    %rax,%rdi
  70205a:	and    $0x7,%rdi
  70205e:	je     702093 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3bf3>
  702060:	xor    %r8d,%r8d
  702063:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  702070:	mov    (%rsi),%r14
  702073:	lea    0x590(%r14),%rsi
  70207a:	inc    %r8
  70207d:	cmp    %r8,%rdi
  702080:	jne    702070 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3bd0>
  702082:	mov    %rax,%rdi
  702085:	sub    %r8,%rdi
  702088:	jmp    702096 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3bf6>
  70208a:	lea    0x1(%rdx),%r13
  70208e:	mov    %rcx,%r14
  702091:	jmp    7020e4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3c44>
  702093:	mov    %rax,%rdi
  702096:	cmp    $0x8,%rax
  70209a:	jb     7020e1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3c41>
  70209c:	nopl   0x0(%rax)
  7020a0:	mov    (%rsi),%rax
  7020a3:	mov    0x590(%rax),%rax
  7020aa:	mov    0x590(%rax),%rax
  7020b1:	mov    0x590(%rax),%rax
  7020b8:	mov    0x590(%rax),%rax
  7020bf:	mov    0x590(%rax),%rax
  7020c6:	mov    0x590(%rax),%rax
  7020cd:	mov    0x590(%rax),%r14
  7020d4:	lea    0x590(%r14),%rsi
  7020db:	add    $0xfffffffffffffff8,%rdi
  7020df:	jne    7020a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3c00>
  7020e1:	xor    %r13d,%r13d
  7020e4:	mov    %rdx,%rax
  7020e7:	shl    $0x4,%rax
  7020eb:	cmpl   $0x1,(%rcx,%rax,1)
  7020ef:	jne    701f73 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3ad3>
  7020f5:	imul   $0x70,%rdx,%rdx
  7020f9:	lea    (%rcx,%rdx,1),%rbp
  7020fd:	add    $0xb0,%rbp
  702104:	cmpl   $0x2,0x0(%rbp)
  702108:	jne    701f73 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3ad3>
  70210e:	mov    0x8(%rcx,%rax,1),%rdx
  702113:	mov    %rbx,%rdi
  702116:	mov    %r15,%rsi
  702119:	call   *0x340651(%rip)        # a42770 <_DYNAMIC+0x780>
  70211f:	cmpl   $0x1,0x4b0(%rsp)
  702127:	jne    701f73 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3ad3>
  70212d:	movups 0x4b8(%rsp),%xmm0
  702135:	movups %xmm0,0x8(%rbp)
  702139:	jmp    701f73 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3ad3>
  70213e:	mov    0x38(%rsp),%r14
  702143:	mov    0x660(%r14),%r8
  70214a:	mov    0x670(%r14),%rax
  702151:	test   %r8,%r8
  702154:	setne  %cl
  702157:	test   %rax,%rax
  70215a:	setne  %dl
  70215d:	test   %dl,%cl
  70215f:	mov    0x310(%rsp),%rbx
  702167:	mov    0x280(%rsp),%r13
  70216f:	je     70239d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3efd>
  702175:	mov    0x668(%r14),%rsi
  70217c:	xor    %ecx,%ecx
  70217e:	jmp    7021a8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3d08>
  702180:	mov    $0x1,%r8b
  702183:	mov    0x38(%rsp),%r14
  702188:	mov    %r15,%rbx
  70218b:	dec    %rax
  70218e:	shl    $0x5,%rdi
  702192:	add    %rdi,%rdx
  702195:	mov    %r8b,0x1c(%rdx)
  702199:	mov    $0x0,%r8d
  70219f:	test   %rax,%rax
  7021a2:	je     70239d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3efd>
  7021a8:	test   %rcx,%rcx
  7021ab:	jne    702238 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3d98>
  7021b1:	test   %rsi,%rsi
  7021b4:	je     7021e7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3d47>
  7021b6:	mov    %rsi,%rdx
  7021b9:	mov    %r8,%rcx
  7021bc:	and    $0x7,%rdx
  7021c0:	je     7021ec <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3d4c>
  7021c2:	xor    %edi,%edi
  7021c4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  7021d0:	mov    0x1c8(%rcx),%rcx
  7021d7:	inc    %rdi
  7021da:	cmp    %rdi,%rdx
  7021dd:	jne    7021d0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3d30>
  7021df:	mov    %rsi,%rdx
  7021e2:	sub    %rdi,%rdx
  7021e5:	jmp    7021ef <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3d4f>
  7021e7:	mov    %r8,%rcx
  7021ea:	jmp    702233 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3d93>
  7021ec:	mov    %rsi,%rdx
  7021ef:	cmp    $0x8,%rsi
  7021f3:	jb     702233 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3d93>
  7021f5:	mov    0x1c8(%rcx),%rcx
  7021fc:	mov    0x1c8(%rcx),%rcx
  702203:	mov    0x1c8(%rcx),%rcx
  70220a:	mov    0x1c8(%rcx),%rcx
  702211:	mov    0x1c8(%rcx),%rcx
  702218:	mov    0x1c8(%rcx),%rcx
  70221f:	mov    0x1c8(%rcx),%rcx
  702226:	mov    0x1c8(%rcx),%rcx
  70222d:	add    $0xfffffffffffffff8,%rdx
  702231:	jne    7021f5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3d55>
  702233:	xor    %esi,%esi
  702235:	xor    %r8d,%r8d
  702238:	movzwl 0x1c2(%rcx),%edx
  70223f:	cmp    %rdx,%rsi
  702242:	jae    702250 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3db0>
  702244:	mov    %rsi,%rdi
  702247:	mov    %rcx,%rdx
  70224a:	jmp    702276 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3dd6>
  70224c:	nopl   0x0(%rax)
  702250:	mov    0x160(%rcx),%rdx
  702257:	test   %rdx,%rdx
  70225a:	je     70301f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b7f>
  702260:	inc    %r8
  702263:	movzwl 0x1c0(%rcx),%edi
  70226a:	mov    %rdx,%rcx
  70226d:	cmp    0x1c2(%rdx),%di
  702274:	jae    702250 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3db0>
  702276:	test   %r8,%r8
  702279:	je     7022ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3e1a>
  70227b:	lea    (%rdx,%rdi,8),%rsi
  70227f:	add    $0x1d0,%rsi
  702286:	mov    %r8,%r9
  702289:	and    $0x7,%r9
  70228d:	je     7022c3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3e23>
  70228f:	xor    %r10d,%r10d
  702292:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7022a0:	mov    (%rsi),%rcx
  7022a3:	lea    0x1c8(%rcx),%rsi
  7022aa:	inc    %r10
  7022ad:	cmp    %r10,%r9
  7022b0:	jne    7022a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3e00>
  7022b2:	mov    %r8,%r9
  7022b5:	sub    %r10,%r9
  7022b8:	jmp    7022c6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3e26>
  7022ba:	lea    0x1(%rdi),%rsi
  7022be:	mov    %rdx,%rcx
  7022c1:	jmp    702313 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3e73>
  7022c3:	mov    %r8,%r9
  7022c6:	cmp    $0x8,%r8
  7022ca:	jb     702311 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3e71>
  7022cc:	nopl   0x0(%rax)
  7022d0:	mov    (%rsi),%rcx
  7022d3:	mov    0x1c8(%rcx),%rcx
  7022da:	mov    0x1c8(%rcx),%rcx
  7022e1:	mov    0x1c8(%rcx),%rcx
  7022e8:	mov    0x1c8(%rcx),%rcx
  7022ef:	mov    0x1c8(%rcx),%rcx
  7022f6:	mov    0x1c8(%rcx),%rcx
  7022fd:	mov    0x1c8(%rcx),%rcx
  702304:	lea    0x1c8(%rcx),%rsi
  70230b:	add    $0xfffffffffffffff8,%r9
  70230f:	jne    7022d0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3e30>
  702311:	xor    %esi,%esi
  702313:	mov    0x378(%rsp),%r8
  70231b:	test   %r8,%r8
  70231e:	je     702395 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3ef5>
  702320:	mov    %rbx,%r15
  702323:	mov    0x168(%rdx,%rdi,8),%r9
  70232b:	mov    0x380(%rsp),%r10
  702333:	movzwl 0x62(%r8),%ebx
  702338:	mov    %ebx,%r14d
  70233b:	shl    $0x3,%r14d
  70233f:	mov    $0xffffffffffffffff,%r11
  702346:	cs nopw 0x0(%rax,%rax,1)
  702350:	test   %r14,%r14
  702353:	je     70237d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3edd>
  702355:	cmp    0x10(%r8,%r11,8),%r9
  70235a:	seta   %bpl
  70235e:	sbb    $0x0,%bpl
  702362:	inc    %r11
  702365:	add    $0xfffffffffffffff8,%r14
  702369:	cmp    $0x1,%bpl
  70236d:	je     702350 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3eb0>
  70236f:	movzbl %bpl,%ebx
  702373:	test   %ebx,%ebx
  702375:	je     702180 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3ce0>
  70237b:	jmp    702380 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3ee0>
  70237d:	mov    %rbx,%r11
  702380:	mov    0x38(%rsp),%r14
  702385:	mov    %r15,%rbx
  702388:	sub    $0x1,%r10
  70238c:	jb     702395 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3ef5>
  70238e:	mov    0x68(%r8,%r11,8),%r8
  702393:	jmp    702333 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3e93>
  702395:	xor    %r8d,%r8d
  702398:	jmp    70218b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3ceb>
  70239d:	cmpl   $0x2,0xc10(%rsp)
  7023a5:	mov    $0x1,%bpl
  7023a8:	je     7023e5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3f45>
  7023aa:	lea    0x4b0(%rsp),%rdi
  7023b2:	lea    0xc10(%rsp),%rsi
  7023ba:	mov    $0x1e8,%edx
  7023bf:	call   *0x33feb3(%rip)        # a42278 <memcpy@GLIBC_2.14>
  7023c5:	mov    %r14,%rdi
  7023c8:	call   6c6030 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  7023cd:	lea    0x4b0(%rsp),%rsi
  7023d5:	mov    $0x1e8,%edx
  7023da:	mov    %r14,%rdi
  7023dd:	call   *0x33fe95(%rip)        # a42278 <memcpy@GLIBC_2.14>
  7023e3:	xor    %ebp,%ebp
  7023e5:	mov    $0x1,%al
  7023e7:	mov    %eax,0x68(%rsp)
  7023eb:	cmpl   $0xffffffff,0x780(%rsp)
  7023f3:	mov    $0x1,%al
  7023f5:	mov    %eax,0x50(%rsp)
  7023f9:	je     7025b3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4113>
  7023ff:	movups 0x7d0(%rsp),%xmm0
  702407:	movaps %xmm0,0x440(%rsp)
  70240f:	movups 0x7c0(%rsp),%xmm0
  702417:	movaps %xmm0,0x430(%rsp)
  70241f:	movups 0x780(%rsp),%xmm0
  702427:	movups 0x790(%rsp),%xmm1
  70242f:	movups 0x7a0(%rsp),%xmm2
  702437:	movupd 0x7b0(%rsp),%xmm3
  702440:	movapd %xmm3,0x420(%rsp)
  702449:	movaps %xmm2,0x410(%rsp)
  702451:	movaps %xmm1,0x400(%rsp)
  702459:	movaps %xmm0,0x3f0(%rsp)
  702461:	mov    0x138(%rsp),%rax
  702469:	cmpq   $0x0,(%rax)
  70246d:	je     702584 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x40e4>
  702473:	mov    0x2b0(%rsp),%rax
  70247b:	mov    %rax,0x4b0(%rsp)
  702483:	lea    0x170(%rsp),%rax
  70248b:	mov    %rax,0x4b8(%rsp)
  702493:	lea    0x1d8(%rsp),%rax
  70249b:	mov    %rax,0x4c0(%rsp)
  7024a3:	lea    0xc0(%rsp),%rdi
  7024ab:	lea    0x3a0(%rsp),%rsi
  7024b3:	lea    0x4b0(%rsp),%rdx
  7024bb:	call   6b84d0 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>>
  7024c0:	lea    0x3f0(%rsp),%rdi
  7024c8:	call   6c72e0 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportColumn>>
  7024cd:	mov    0xd0(%rsp),%rax
  7024d5:	mov    %rax,0x400(%rsp)
  7024dd:	movups 0xc0(%rsp),%xmm0
  7024e5:	movaps %xmm0,0x3f0(%rsp)
  7024ed:	mov    0x138(%rsp),%rax
  7024f5:	mov    (%rax),%rdi
  7024f8:	cmpl   $0xffffffff,0x60(%rdi)
  7024fc:	je     702512 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4072>
  7024fe:	add    $0x60,%rdi
  702502:	call   6c76d0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  702507:	mov    0x138(%rsp),%rax
  70250f:	mov    (%rax),%rdi
  702512:	movaps 0x440(%rsp),%xmm0
  70251a:	movups %xmm0,0xb0(%rdi)
  702521:	movaps 0x430(%rsp),%xmm0
  702529:	movups %xmm0,0xa0(%rdi)
  702530:	movaps 0x3f0(%rsp),%xmm0
  702538:	mov    0x400(%rsp),%rax
  702540:	mov    0x408(%rsp),%rcx
  702548:	movaps 0x410(%rsp),%xmm1
  702550:	movaps 0x420(%rsp),%xmm2
  702558:	movups %xmm2,0x90(%rdi)
  70255f:	movups %xmm1,0x80(%rdi)
  702566:	mov    %rax,0x70(%rdi)
  70256a:	mov    %rcx,0x78(%rdi)
  70256e:	movups %xmm0,0x60(%rdi)
  702572:	movl   $0x0,0x68(%rsp)
  70257a:	movl   $0x0,0x50(%rsp)
  702582:	jmp    7025b3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4113>
  702584:	mov    $0x1,%al
  702586:	mov    %eax,0x68(%rsp)
  70258a:	movl   $0x0,0x50(%rsp)
  702592:	lea    0x3f0(%rsp),%rdi
  70259a:	mov    $0x1,%r12b
  70259d:	mov    $0x1,%al
  70259f:	mov    %eax,0x70(%rsp)
  7025a3:	mov    $0x1,%r15b
  7025a6:	movb   $0x1,0x80(%rsp)
  7025ae:	call   6c76d0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  7025b3:	mov    0xa0(%rsp),%r15
  7025bb:	cmp    $0xffffffffffffffff,%r15
  7025bf:	sete   0x80(%rsp)
  7025c7:	je     702640 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x41a0>
  7025c9:	mov    %rbx,%r12
  7025cc:	mov    0xa8(%rsp),%rax
  7025d4:	mov    %rax,0x70(%rsp)
  7025d9:	mov    0xb0(%rsp),%r14
  7025e1:	mov    0x138(%rsp),%r13
  7025e9:	mov    %r13,%rdi
  7025ec:	call   6b6810 <<core::option::Option<alloc::boxed::Box<gpui::runtime::metadata::Metadata>>>::get_or_insert_with::<<alloc::boxed::Box<gpui::runtime::metadata::Metadata> as core::default::Default>::default>>
  7025f1:	mov    $0x100,%ebx
  7025f6:	add    0x0(%r13),%rbx
  7025fa:	mov    %rbx,%rdi
  7025fd:	call   6b6670 <<core::option::Option<alloc::boxed::Box<gpui::runtime::geometry::Geometry>>>::get_or_insert_with::<<alloc::boxed::Box<gpui::runtime::geometry::Geometry> as core::default::Default>::default>>
  702602:	mov    (%rbx),%rdi
  702605:	mov    %r15,0x4b0(%rsp)
  70260d:	mov    0x70(%rsp),%rax
  702612:	mov    %rax,0x4b8(%rsp)
  70261a:	mov    %r14,0x4c0(%rsp)
  702622:	lea    0x4b0(%rsp),%rsi
  70262a:	call   *0x3401c8(%rip)        # a427f8 <_DYNAMIC+0x808>
  702630:	mov    0x38(%rsp),%r14
  702635:	mov    %r12,%rbx
  702638:	mov    0x280(%rsp),%r13
  702640:	cmpq   $0xffffffffffffffff,0x278(%rsp)
  702649:	je     702678 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x41d8>
  70264b:	mov    0x0(%r13),%rdi
  70264f:	test   %rdi,%rdi
  702652:	je     702fd1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b31>
  702658:	lea    0x828(%rsp),%rdx
  702660:	mov    0x308(%rsp),%rsi
  702668:	call   *0x340192(%rip)        # a42800 <_DYNAMIC+0x810>
  70266e:	movl   $0x0,0x70(%rsp)
  702676:	jmp    70267e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x41de>
  702678:	mov    $0x1,%al
  70267a:	mov    %eax,0x70(%rsp)
  70267e:	mov    0x138(%rsp),%rax
  702686:	mov    (%rax),%rax
  702689:	test   %rax,%rax
  70268c:	je     7026de <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x423e>
  70268e:	mov    0xe0(%rax),%rax
  702695:	test   %rax,%rax
  702698:	je     7026de <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x423e>
  70269a:	mov    0x818(%rsp),%rcx
  7026a2:	mov    %rcx,0x40(%rax)
  7026a6:	mov    0x368(%rsp),%rcx
  7026ae:	mov    %rcx,0x48(%rax)
  7026b2:	mov    0x370(%rsp),%ecx
  7026b9:	mov    %ecx,0x50(%rax)
  7026bc:	movzbl 0x9b(%rsp),%ecx
  7026c4:	mov    %cl,0x54(%rax)
  7026c7:	movzwl 0x12c(%rsp),%ecx
  7026cf:	mov    %cx,0x55(%rax)
  7026d3:	movzbl 0x12e(%rsp),%ecx
  7026db:	mov    %cl,0x57(%rax)
  7026de:	mov    0x6c8(%r14),%rdi
  7026e5:	test   %rdi,%rdi
  7026e8:	je     70271e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x427e>
  7026ea:	cmpq   $0xffffffffffffffff,0x18(%rdi)
  7026ef:	je     702701 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4261>
  7026f1:	add    $0x18,%rdi
  7026f5:	call   6c1520 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  7026fa:	mov    0x6c8(%r14),%rdi
  702701:	mov    0x298(%rsp),%rax
  702709:	mov    %rax,0x28(%rdi)
  70270d:	movups 0x288(%rsp),%xmm0
  702715:	movups %xmm0,0x18(%rdi)
  702719:	xor    %r12d,%r12d
  70271c:	jmp    702721 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4281>
  70271e:	mov    $0x1,%r12b
  702721:	mov    0x1e8(%rsp),%rax
  702729:	mov    %rax,0x4c0(%rsp)
  702731:	movups 0x1d8(%rsp),%xmm0
  702739:	movaps %xmm0,0x4b0(%rsp)
  702741:	lea    0x5b8(%r14),%r15
  702748:	cmpq   $0xffffffffffffffff,0x5b8(%r14)
  702750:	je     70275a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x42ba>
  702752:	mov    %r15,%rdi
  702755:	call   6c1190 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  70275a:	mov    0x4c0(%rsp),%rax
  702762:	mov    %rax,0x10(%r15)
  702766:	movaps 0x4b0(%rsp),%xmm0
  70276e:	movups %xmm0,(%r15)
  702772:	mov    0x110(%rsp),%rax
  70277a:	mov    %rax,0x5d0(%r14)
  702781:	mov    %bx,0x5d8(%r14)
  702789:	mov    0x194(%rsp),%eax
  702790:	mov    %ax,0x5da(%r14)
  702798:	movss  0x9c(%rsp),%xmm0
  7027a1:	movss  %xmm0,0x5dc(%r14)
  7027aa:	xor    %r15d,%r15d
  7027ad:	mov    %r14,%rdi
  7027b0:	call   6f04f0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::prune_focus>
  7027b5:	mov    0x350(%rsp),%rax
  7027bd:	mov    %rax,0x6b0(%r14)
  7027c4:	mov    0x308(%rsp),%rax
  7027cc:	mov    %rax,0x6b8(%r14)
  7027d3:	mov    0x690(%r14),%rax
  7027da:	mov    0x6c8(%r14),%rdi
  7027e1:	mov    %rax,0x6c0(%r14)
  7027e8:	mov    0x820(%rsp),%rax
  7027f0:	mov    %rax,0x5e8(%r14)
  7027f7:	cmpq   $0x0,0x2e8(%r14)
  7027ff:	setne  %al
  702802:	test   %rdi,%rdi
  702805:	sete   %cl
  702808:	or     %al,%cl
  70280a:	cmp    $0x1,%cl
  70280d:	je     702827 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4387>
  70280f:	add    $0x30,%rdi
  702813:	call   6bf5d0 <core::ptr::drop_glue::<core::option::Option<gpui_canvas::text::TextSystem>>>
  702818:	mov    0x6c8(%r14),%rax
  70281f:	movq   $0x0,0x30(%rax)
  702827:	movb   $0x0,0x74b(%r14)
  70282f:	movw   $0x0,0x748(%r14)
  702839:	lea    0x678(%r14),%rdi
  702840:	xor    %r15d,%r15d
  702843:	call   6f8200 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::clear>
  702848:	cmpb   $0x0,0x74d(%r14)
  702850:	je     702887 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x43e7>
  702852:	xor    %r15d,%r15d
  702855:	lea    0x4b0(%rsp),%rdi
  70285d:	mov    %r14,%rsi
  702860:	mov    0x350(%rsp),%rdx
  702868:	mov    0x308(%rsp),%rcx
  702870:	call   6fdef0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge>
  702875:	mov    0x4b0(%rsp),%rax
  70287d:	cmp    $0xfffffffffffffffe,%rax
  702881:	jne    7029bf <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x451f>
  702887:	mov    0x40(%rsp),%rax
  70288c:	movq   $0xfffffffffffffffe,(%rax)
  702893:	cmpb   $0x0,0x68(%rsp)
  702898:	je     7028a7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4407>
  70289a:	lea    0x3a0(%rsp),%rdi
  7028a2:	call   6c7290 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportBuild>>
  7028a7:	xor    %r13d,%r13d
  7028aa:	lea    0x378(%rsp),%rdi
  7028b2:	call   6c41f0 <core::ptr::drop_glue::<alloc::collections::btree::set::BTreeSet<gpui::list::ListId>>>
  7028b7:	mov    0x170(%rsp),%rsi
  7028bf:	test   %rsi,%rsi
  7028c2:	je     7028db <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x443b>
  7028c4:	mov    0x178(%rsp),%rdi
  7028cc:	shl    $0x2,%rsi
  7028d0:	mov    $0x4,%edx
  7028d5:	call   *0x33f97d(%rip)        # a42258 <_DYNAMIC+0x268>
  7028db:	mov    0x198(%rsp),%rsi
  7028e3:	test   %rsi,%rsi
  7028e6:	je     7028fb <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x445b>
  7028e8:	mov    0x1a0(%rsp),%rdi
  7028f0:	mov    $0x1,%edx
  7028f5:	call   *0x33f95d(%rip)        # a42258 <_DYNAMIC+0x268>
  7028fb:	mov    0x238(%rsp),%rsi
  702903:	test   %rsi,%rsi
  702906:	je     70291f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x447f>
  702908:	mov    0x240(%rsp),%rdi
  702910:	shl    $0x4,%rsi
  702914:	mov    $0x4,%edx
  702919:	call   *0x33f939(%rip)        # a42258 <_DYNAMIC+0x268>
  70291f:	mov    0x220(%rsp),%rsi
  702927:	test   %rsi,%rsi
  70292a:	je     702943 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x44a3>
  70292c:	mov    0x228(%rsp),%rdi
  702934:	shl    $0x4,%rsi
  702938:	mov    $0x4,%edx
  70293d:	call   *0x33f915(%rip)        # a42258 <_DYNAMIC+0x268>
  702943:	mov    0x1f8(%rsp),%rax
  70294b:	test   %rax,%rax
  70294e:	je     702967 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x44c7>
  702950:	mov    0x200(%rsp),%rdi
  702958:	imul   $0x38,%rax,%rsi
  70295c:	mov    $0x8,%edx
  702961:	call   *0x33f8f1(%rip)        # a42258 <_DYNAMIC+0x268>
  702967:	cmpq   $0x0,0x1c8(%rsp)
  702970:	je     70297f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x44df>
  702972:	mov    0x1d0(%rsp),%rdi
  70297a:	call   6c5a90 <core::ptr::drop_glue::<gpui_canvas::text::TextShaper>>
  70297f:	test   %r12b,%r12b
  702982:	je     702991 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x44f1>
  702984:	lea    0x288(%rsp),%rdi
  70298c:	call   6c1520 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  702991:	mov    0x140(%rsp),%rax
  702999:	test   %rax,%rax
  70299c:	je     6ffd16 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1876>
  7029a2:	lock decq (%rax)
  7029a6:	jne    6ffd16 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1876>
  7029ac:	lea    0x140(%rsp),%rdi
  7029b4:	call   *0x33f96e(%rip)        # a42328 <_DYNAMIC+0x338>
  7029ba:	jmp    6ffd16 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1876>
  7029bf:	mov    0x4d8(%rsp),%rcx
  7029c7:	movzbl 0x4e0(%rsp),%edx
  7029cf:	mov    0x4e1(%rsp),%esi
  7029d6:	mov    %esi,0xc0(%rsp)
  7029dd:	mov    0x4e4(%rsp),%esi
  7029e4:	mov    %esi,0xc3(%rsp)
  7029eb:	movups 0x4b8(%rsp),%xmm0
  7029f3:	movups 0x4c8(%rsp),%xmm1
  7029fb:	mov    0xc0(%rsp),%esi
  702a02:	mov    0xc3(%rsp),%edi
  702a09:	mov    0x40(%rsp),%r8
  702a0e:	mov    %edi,0x34(%r8)
  702a12:	mov    %esi,0x31(%r8)
  702a16:	mov    %rax,(%r8)
  702a19:	movups %xmm0,0x8(%r8)
  702a1e:	movups %xmm1,0x18(%r8)
  702a23:	mov    %rcx,0x28(%r8)
  702a27:	mov    %dl,0x30(%r8)
  702a2b:	xor    %r13d,%r13d
  702a2e:	cmpb   $0x0,0x68(%rsp)
  702a33:	mov    0x70(%rsp),%ebx
  702a37:	jne    702cea <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x484a>
  702a3d:	jmp    702cf7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4857>
  702a42:	movzbl 0x4b1(%rsp),%eax
  702a4a:	mov    0x40(%rsp),%rcx
  702a4f:	movq   $0x22,(%rcx)
  702a56:	mov    %al,0x8(%rcx)
  702a59:	jmp    702ccc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x482c>
  702a5e:	mov    0x40(%rsp),%rax
  702a63:	movq   $0x1f,(%rax)
  702a6a:	jmp    6ffd16 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1876>
  702a6f:	lea    0xc4(%rsp),%rcx
  702a77:	mov    0x14(%rcx),%rax
  702a7b:	movups 0x4(%rcx),%xmm0
  702a7f:	movaps %xmm0,0x150(%rsp)
  702a87:	mov    %rax,0x160(%rsp)
  702a8f:	mov    0x40(%rsp),%rcx
  702a94:	mov    %rax,0x18(%rcx)
  702a98:	movups %xmm0,0x8(%rcx)
  702a9c:	movq   $0x23,(%rcx)
  702aa3:	jmp    702ccc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x482c>
  702aa8:	mov    0x40(%rsp),%rcx
  702aad:	movq   $0x23,(%rcx)
  702ab4:	mov    %eax,0x8(%rcx)
  702ab7:	mov    %edx,0xc(%rcx)
  702aba:	jmp    702ccc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x482c>
  702abf:	mov    0xf0(%rsp),%rcx
  702ac7:	mov    0x40(%rsp),%rdx
  702acc:	mov    %rcx,0x30(%rdx)
  702ad0:	movups 0xd0(%rsp),%xmm0
  702ad8:	movups 0xe0(%rsp),%xmm1
  702ae0:	movups %xmm1,0x20(%rdx)
  702ae4:	movups %xmm0,0x10(%rdx)
  702ae8:	mov    %rax,(%rdx)
  702aeb:	mov    %r15,0x8(%rdx)
  702aef:	jmp    702ccc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x482c>
  702af4:	mov    0x4e0(%rsp),%rax
  702afc:	mov    0x40(%rsp),%rcx
  702b01:	mov    %rax,0x30(%rcx)
  702b05:	movups 0x4b0(%rsp),%xmm0
  702b0d:	movups 0x4c0(%rsp),%xmm1
  702b15:	movups 0x4d0(%rsp),%xmm2
  702b1d:	movups %xmm2,0x20(%rcx)
  702b21:	movups %xmm1,0x10(%rcx)
  702b25:	movups %xmm0,(%rcx)
  702b28:	jmp    702ccc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x482c>
  702b2d:	mov    0x50(%rsp),%rax
  702b32:	mov    0x20(%rax),%esi
  702b35:	lea    0xc0(%rsp),%rdi
  702b3d:	lea    0x840(%rsp),%rdx
  702b45:	call   6db130 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#23}>
  702b4a:	mov    0xf0(%rsp),%rax
  702b52:	mov    %rax,0x870(%rsp)
  702b5a:	movups 0xc0(%rsp),%xmm0
  702b62:	movups 0xd0(%rsp),%xmm1
  702b6a:	movups 0xe0(%rsp),%xmm2
  702b72:	movaps %xmm2,0x860(%rsp)
  702b7a:	movaps %xmm1,0x850(%rsp)
  702b82:	movaps %xmm0,0x840(%rsp)
  702b8a:	mov    0x840(%rsp),%rax
  702b92:	mov    0x868(%rsp),%rcx
  702b9a:	mov    0x40(%rsp),%rdx
  702b9f:	mov    %rcx,0x28(%rdx)
  702ba3:	mov    0x870(%rsp),%rcx
  702bab:	mov    %rcx,0x30(%rdx)
  702baf:	lea    0x848(%rsp),%rcx
  702bb7:	movups (%rcx),%xmm0
  702bba:	movups 0x10(%rcx),%xmm1
  702bbe:	movups %xmm0,0x8(%rdx)
  702bc2:	movups %xmm1,0x18(%rdx)
  702bc6:	mov    %rax,(%rdx)
  702bc9:	jmp    702ccc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x482c>
  702bce:	mov    0x40(%rsp),%rcx
  702bd3:	movq   $0x23,(%rcx)
  702bda:	mov    %eax,0x8(%rcx)
  702bdd:	mov    %edx,0xc(%rcx)
  702be0:	jmp    702cb0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4810>
  702be5:	lea    0xc4(%rsp),%rcx
  702bed:	mov    0x14(%rcx),%rax
  702bf1:	movups 0x4(%rcx),%xmm0
  702bf5:	movaps %xmm0,0x150(%rsp)
  702bfd:	mov    %rax,0x160(%rsp)
  702c05:	mov    0x40(%rsp),%rcx
  702c0a:	mov    %rax,0x18(%rcx)
  702c0e:	movups %xmm0,0x8(%rcx)
  702c12:	movq   $0x23,(%rcx)
  702c19:	jmp    702cb0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4810>
  702c1e:	lea    0xc4(%rsp),%rcx
  702c26:	mov    0x14(%rcx),%rax
  702c2a:	movups 0x4(%rcx),%xmm0
  702c2e:	movaps %xmm0,0x150(%rsp)
  702c36:	mov    %rax,0x160(%rsp)
  702c3e:	mov    0x40(%rsp),%rcx
  702c43:	mov    %rax,0x18(%rcx)
  702c47:	movups %xmm0,0x8(%rcx)
  702c4b:	movq   $0x23,(%rcx)
  702c52:	jmp    702c66 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x47c6>
  702c54:	mov    0x40(%rsp),%rcx
  702c59:	movq   $0x23,(%rcx)
  702c60:	mov    %eax,0x8(%rcx)
  702c63:	mov    %edx,0xc(%rcx)
  702c66:	mov    0x218(%rsp),%rax
  702c6e:	test   %rax,%rax
  702c71:	je     702ccc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x482c>
  702c73:	lock decq (%rax)
  702c77:	jne    702ccc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x482c>
  702c79:	lea    0x218(%rsp),%rdi
  702c81:	call   *0x33f6b1(%rip)        # a42338 <_DYNAMIC+0x348>
  702c87:	jmp    702ccc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x482c>
  702c89:	mov    0x40(%rsp),%rax
  702c8e:	movq   $0x18,(%rax)
  702c95:	jmp    702cb0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4810>
  702c97:	mov    0x154(%rsp),%ecx
  702c9e:	mov    0x40(%rsp),%rdx
  702ca3:	movq   $0x23,(%rdx)
  702caa:	mov    %eax,0x8(%rdx)
  702cad:	mov    %ecx,0xc(%rdx)
  702cb0:	mov    0x320(%rsp),%rax
  702cb8:	lock decq (%rax)
  702cbc:	jne    702ccc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x482c>
  702cbe:	lea    0x320(%rsp),%rdi
  702cc6:	call   *0x33f66c(%rip)        # a42338 <_DYNAMIC+0x348>
  702ccc:	lea    0x8f0(%rsp),%rdi
  702cd4:	call   6c6030 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  702cd9:	mov    $0x1,%r12b
  702cdc:	mov    $0x1,%bl
  702cde:	mov    $0x1,%al
  702ce0:	mov    %eax,0x50(%rsp)
  702ce4:	mov    $0x1,%r13b
  702ce7:	mov    $0x1,%bpl
  702cea:	lea    0x3a0(%rsp),%rdi
  702cf2:	call   6c7290 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportBuild>>
  702cf7:	cmpq   $0xffffffffffffffff,0x278(%rsp)
  702d00:	setne  %al
  702d03:	mov    %r13d,%r15d
  702d06:	test   %bl,%al
  702d08:	je     702d1a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x487a>
  702d0a:	lea    0x828(%rsp),%rdi
  702d12:	call   6c1310 <core::ptr::drop_glue::<alloc::vec::Vec<gpui_canvas::image::Image>>>
  702d17:	mov    %r15d,%r13d
  702d1a:	cmpl   $0xffffffff,0x780(%rsp)
  702d22:	je     702d38 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4898>
  702d24:	cmpb   $0x0,0x50(%rsp)
  702d29:	je     702d38 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4898>
  702d2b:	lea    0x780(%rsp),%rdi
  702d33:	call   6c76d0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  702d38:	lea    0x378(%rsp),%rdi
  702d40:	call   6c41f0 <core::ptr::drop_glue::<alloc::collections::btree::set::BTreeSet<gpui::list::ListId>>>
  702d45:	mov    0x170(%rsp),%rsi
  702d4d:	test   %rsi,%rsi
  702d50:	je     702d69 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x48c9>
  702d52:	mov    0x178(%rsp),%rdi
  702d5a:	shl    $0x2,%rsi
  702d5e:	mov    $0x4,%edx
  702d63:	call   *0x33f4ef(%rip)        # a42258 <_DYNAMIC+0x268>
  702d69:	mov    0x198(%rsp),%rsi
  702d71:	test   %rsi,%rsi
  702d74:	je     702d89 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x48e9>
  702d76:	mov    0x1a0(%rsp),%rdi
  702d7e:	mov    $0x1,%edx
  702d83:	call   *0x33f4cf(%rip)        # a42258 <_DYNAMIC+0x268>
  702d89:	mov    0x238(%rsp),%rsi
  702d91:	test   %rsi,%rsi
  702d94:	je     702dad <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x490d>
  702d96:	mov    0x240(%rsp),%rdi
  702d9e:	shl    $0x4,%rsi
  702da2:	mov    $0x4,%edx
  702da7:	call   *0x33f4ab(%rip)        # a42258 <_DYNAMIC+0x268>
  702dad:	mov    0x220(%rsp),%rsi
  702db5:	test   %rsi,%rsi
  702db8:	je     702dd1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4931>
  702dba:	mov    0x228(%rsp),%rdi
  702dc2:	shl    $0x4,%rsi
  702dc6:	mov    $0x4,%edx
  702dcb:	call   *0x33f487(%rip)        # a42258 <_DYNAMIC+0x268>
  702dd1:	mov    0x1f8(%rsp),%rax
  702dd9:	test   %rax,%rax
  702ddc:	je     702df5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4955>
  702dde:	mov    0x200(%rsp),%rdi
  702de6:	imul   $0x38,%rax,%rsi
  702dea:	mov    $0x8,%edx
  702def:	call   *0x33f463(%rip)        # a42258 <_DYNAMIC+0x268>
  702df5:	test   %r13b,%r13b
  702df8:	je     702e2b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x498b>
  702dfa:	mov    0x2d0(%rsp),%rsi
  702e02:	test   %rsi,%rsi
  702e05:	je     702e1e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x497e>
  702e07:	mov    0x2d8(%rsp),%rdi
  702e0f:	shl    $0x4,%rsi
  702e13:	mov    $0x4,%edx
  702e18:	call   *0x33f43a(%rip)        # a42258 <_DYNAMIC+0x268>
  702e1e:	lea    0x1d8(%rsp),%rdi
  702e26:	call   6c1190 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  702e2b:	mov    0x748(%rsp),%rax
  702e33:	cmp    $0xfffffffffffffffe,%rax
  702e37:	jne    6ff8da <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x143a>
  702e3d:	jmp    6ffcaf <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x180f>
  702e42:	lea    -0x6b2be7(%rip),%rdi        # 50262 <GCC_except_table0+0x104be>
  702e49:	lea    0x3207a0(%rip),%rdx        # a235f0 <__frame_dummy_init_array_entry+0x1b00>
  702e50:	mov    $0x83,%esi
  702e55:	call   *0x33f435(%rip)        # a42290 <_DYNAMIC+0x2a0>
  702e5b:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  702e60:	lea    -0x6b2e7b(%rip),%rdi        # 4ffec <GCC_except_table0+0x10248>
  702e67:	lea    0x320262(%rip),%rdx        # a230d0 <__frame_dummy_init_array_entry+0x15e0>
  702e6e:	mov    $0x1c,%esi
  702e73:	call   *0x33f57f(%rip)        # a423f8 <_DYNAMIC+0x408>
  702e79:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  702e7e:	mov    $0x1,%bpl
  702e81:	mov    $0x8,%edi
  702e86:	mov    $0x78,%esi
  702e8b:	call   *0x33f3df(%rip)        # a42270 <_DYNAMIC+0x280>
  702e91:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  702e96:	lea    0x31f45b(%rip),%rdi        # a222f8 <__frame_dummy_init_array_entry+0x808>
  702e9d:	call   *0x33f455(%rip)        # a422f8 <_DYNAMIC+0x308>
  702ea3:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  702ea8:	lea    -0x6b2c0c(%rip),%rax        # 502a3 <GCC_except_table0+0x104ff>
  702eaf:	mov    %rax,0x270(%rsp)
  702eb7:	lea    0x32090a(%rip),%rax        # a237c8 <__frame_dummy_init_array_entry+0x1cd8>
  702ebe:	jmp    702efa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4a5a>
  702ec0:	lea    0x31f581(%rip),%rdi        # a22448 <__frame_dummy_init_array_entry+0x958>
  702ec7:	call   *0x33f42b(%rip)        # a422f8 <_DYNAMIC+0x308>
  702ecd:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  702ed2:	lea    0x31f41f(%rip),%rdi        # a222f8 <__frame_dummy_init_array_entry+0x808>
  702ed9:	call   *0x33f419(%rip)        # a422f8 <_DYNAMIC+0x308>
  702edf:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  702ee4:	lea    -0x6b2c48(%rip),%rax        # 502a3 <GCC_except_table0+0x104ff>
  702eeb:	mov    %rax,0x270(%rsp)
  702ef3:	lea    0x3208e6(%rip),%rax        # a237e0 <__frame_dummy_init_array_entry+0x1cf0>
  702efa:	mov    %rax,0x268(%rsp)
  702f02:	jmp    702f7e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4ade>
  702f04:	mov    0x4c0(%rsp),%rsi
  702f0c:	mov    $0x1,%bpl
  702f0f:	call   *0x33f3d3(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  702f15:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  702f1a:	mov    0x4c0(%rsp),%rsi
  702f22:	call   *0x33f3c0(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  702f28:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  702f2d:	mov    0x4c0(%rsp),%rsi
  702f35:	call   *0x33f3ad(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  702f3b:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  702f40:	mov    0x4c0(%rsp),%rsi
  702f48:	call   *0x33f39a(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  702f4e:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  702f53:	mov    0x4c0(%rsp),%rsi
  702f5b:	call   *0x33f387(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  702f61:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  702f66:	mov    0x4c0(%rsp),%rsi
  702f6e:	call   *0x33f374(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  702f74:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  702f79:	mov    $0x1f,%esi
  702f7e:	mov    0x270(%rsp),%rdi
  702f86:	mov    0x268(%rsp),%rdx
  702f8e:	call   *0x33f464(%rip)        # a423f8 <_DYNAMIC+0x408>
  702f94:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  702f99:	lea    -0x6b2d3e(%rip),%rdi        # 50262 <GCC_except_table0+0x104be>
  702fa0:	lea    0x320649(%rip),%rdx        # a235f0 <__frame_dummy_init_array_entry+0x1b00>
  702fa7:	mov    $0x83,%esi
  702fac:	call   *0x33f2de(%rip)        # a42290 <_DYNAMIC+0x2a0>
  702fb2:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  702fb7:	movb   $0x1,0x80(%rsp)
  702fbf:	lea    0x32084a(%rip),%rdi        # a23810 <__frame_dummy_init_array_entry+0x1d20>
  702fc6:	call   *0x33f32c(%rip)        # a422f8 <_DYNAMIC+0x308>
  702fcc:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  702fd1:	lea    0x320778(%rip),%rdi        # a23750 <__frame_dummy_init_array_entry+0x1c60>
  702fd8:	call   *0x33f31a(%rip)        # a422f8 <_DYNAMIC+0x308>
  702fde:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  702fe3:	lea    -0x6b2d88(%rip),%rdi        # 50262 <GCC_except_table0+0x104be>
  702fea:	lea    0x3205ff(%rip),%rdx        # a235f0 <__frame_dummy_init_array_entry+0x1b00>
  702ff1:	mov    $0x83,%esi
  702ff6:	call   *0x33f294(%rip)        # a42290 <_DYNAMIC+0x2a0>
  702ffc:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  703001:	lea    0x31f338(%rip),%rax        # a22340 <__frame_dummy_init_array_entry+0x850>
  703008:	jmp    7030c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c20>
  70300d:	lea    0x31f2fc(%rip),%rdi        # a22310 <__frame_dummy_init_array_entry+0x820>
  703014:	call   *0x33f2de(%rip)        # a422f8 <_DYNAMIC+0x308>
  70301a:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  70301f:	lea    0x31f2ea(%rip),%rdi        # a22310 <__frame_dummy_init_array_entry+0x820>
  703026:	call   *0x33f2cc(%rip)        # a422f8 <_DYNAMIC+0x308>
  70302c:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  703031:	lea    0x320690(%rip),%rax        # a236c8 <__frame_dummy_init_array_entry+0x1bd8>
  703038:	jmp    7030c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c20>
  70303d:	lea    0x32069c(%rip),%rax        # a236e0 <__frame_dummy_init_array_entry+0x1bf0>
  703044:	jmp    7030c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c20>
  703046:	movb   $0x1,0x80(%rsp)
  70304e:	lea    -0x6b2df3(%rip),%rdi        # 50262 <GCC_except_table0+0x104be>
  703055:	lea    0x320594(%rip),%rdx        # a235f0 <__frame_dummy_init_array_entry+0x1b00>
  70305c:	mov    $0x83,%esi
  703061:	call   *0x33f229(%rip)        # a42290 <_DYNAMIC+0x2a0>
  703067:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  70306c:	lea    0x31fe8d(%rip),%rax        # a22f00 <__frame_dummy_init_array_entry+0x1410>
  703073:	jmp    7030c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c20>
  703075:	lea    0x31fe6c(%rip),%rax        # a22ee8 <__frame_dummy_init_array_entry+0x13f8>
  70307c:	jmp    7030c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c20>
  70307e:	mov    %rbx,%rbp
  703081:	lea    0x31fe78(%rip),%rax        # a22f00 <__frame_dummy_init_array_entry+0x1410>
  703088:	jmp    7030c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c20>
  70308a:	mov    %rax,%rbp
  70308d:	jmp    7030b9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c19>
  70308f:	mov    %rbx,%rbp
  703092:	lea    0x31fe4f(%rip),%rax        # a22ee8 <__frame_dummy_init_array_entry+0x13f8>
  703099:	jmp    7030c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c20>
  70309b:	mov    %rax,%r13
  70309e:	lea    0x31fe43(%rip),%rax        # a22ee8 <__frame_dummy_init_array_entry+0x13f8>
  7030a5:	jmp    7030c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c20>
  7030a7:	mov    %rax,%r13
  7030aa:	lea    0x31fe4f(%rip),%rax        # a22f00 <__frame_dummy_init_array_entry+0x1410>
  7030b1:	jmp    7030c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c20>
  7030b3:	mov    %rcx,%rbp
  7030b6:	mov    %rax,%r13
  7030b9:	lea    0x31fe58(%rip),%rax        # a22f18 <__frame_dummy_init_array_entry+0x1428>
  7030c0:	mov    %rax,0x48(%rsp)
  7030c5:	mov    %rbp,%rdi
  7030c8:	mov    %r13,%rsi
  7030cb:	mov    0x48(%rsp),%rdx
  7030d0:	call   *0x33f1b2(%rip)        # a42288 <_DYNAMIC+0x298>
  7030d6:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  7030db:	mov    $0x1,%r12b
  7030de:	lea    0x32062b(%rip),%rdx        # a23710 <__frame_dummy_init_array_entry+0x1c20>
  7030e5:	mov    $0x1,%bpl
  7030e8:	xor    %edi,%edi
  7030ea:	xor    %esi,%esi
  7030ec:	call   *0x33f196(%rip)        # a42288 <_DYNAMIC+0x298>
  7030f2:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  7030f7:	mov    %rsi,%rax
  7030fa:	lea    0x32067f(%rip),%rcx        # a23780 <__frame_dummy_init_array_entry+0x1c90>
  703101:	jmp    7031df <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3f>
  703106:	mov    %rsi,%rax
  703109:	lea    0x320688(%rip),%rcx        # a23798 <__frame_dummy_init_array_entry+0x1ca8>
  703110:	jmp    7031df <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3f>
  703115:	mov    %rsi,%rax
  703118:	lea    0x320691(%rip),%rcx        # a237b0 <__frame_dummy_init_array_entry+0x1cc0>
  70311f:	jmp    7031df <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3f>
  703124:	mov    %rbx,0x80(%rsp)
  70312c:	mov    %rsi,%rax
  70312f:	lea    0x31f2e2(%rip),%rcx        # a22418 <__frame_dummy_init_array_entry+0x928>
  703136:	jmp    7031df <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3f>
  70313b:	mov    %rcx,0x80(%rsp)
  703143:	lea    0x31f2e6(%rip),%rcx        # a22430 <__frame_dummy_init_array_entry+0x940>
  70314a:	jmp    7031df <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3f>
  70314f:	lea    0x31f36a(%rip),%rdx        # a224c0 <__frame_dummy_init_array_entry+0x9d0>
  703156:	call   *0x33f12c(%rip)        # a42288 <_DYNAMIC+0x298>
  70315c:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  703161:	mov    %rcx,0x80(%rsp)
  703169:	lea    0x31f2f0(%rip),%rcx        # a22460 <__frame_dummy_init_array_entry+0x970>
  703170:	jmp    7031df <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3f>
  703172:	mov    %rcx,0x80(%rsp)
  70317a:	lea    0x31f2f7(%rip),%rcx        # a22478 <__frame_dummy_init_array_entry+0x988>
  703181:	jmp    7031df <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3f>
  703183:	lea    0x31f31e(%rip),%rax        # a224a8 <__frame_dummy_init_array_entry+0x9b8>
  70318a:	mov    %rax,0x348(%rsp)
  703192:	movb   $0x1,0x80(%rsp)
  70319a:	mov    %rbx,%rdi
  70319d:	mov    0x348(%rsp),%rdx
  7031a5:	call   *0x33f0dd(%rip)        # a42288 <_DYNAMIC+0x298>
  7031ab:	jmp    703200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d60>
  7031ad:	lea    0x31fd4c(%rip),%rcx        # a22f00 <__frame_dummy_init_array_entry+0x1410>
  7031b4:	jmp    7031df <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3f>
  7031b6:	mov    %rcx,0x80(%rsp)
  7031be:	lea    0x31fd53(%rip),%rcx        # a22f18 <__frame_dummy_init_array_entry+0x1428>
  7031c5:	jmp    7031df <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3f>
  7031c7:	lea    0x31fd1a(%rip),%rcx        # a22ee8 <__frame_dummy_init_array_entry+0x13f8>
  7031ce:	jmp    7031df <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3f>
  7031d0:	mov    %rcx,0x80(%rsp)
  7031d8:	lea    0x31f2b1(%rip),%rcx        # a22490 <__frame_dummy_init_array_entry+0x9a0>
  7031df:	mov    %rcx,0x108(%rsp)
  7031e7:	mov    0x80(%rsp),%rdi
  7031ef:	mov    %rax,%rsi
  7031f2:	mov    0x108(%rsp),%rdx
  7031fa:	call   *0x33f088(%rip)        # a42288 <_DYNAMIC+0x298>
  703200:	ud2
  703202:	mov    %rax,%rbx
  703205:	mov    0x138(%rsp),%rax
  70320d:	mov    (%rax),%rax
  703210:	movaps 0x440(%rsp),%xmm0
  703218:	movups %xmm0,0xb0(%rax)
  70321f:	movaps 0x430(%rsp),%xmm0
  703227:	movups %xmm0,0xa0(%rax)
  70322e:	movaps 0x3f0(%rsp),%xmm0
  703236:	movaps 0x400(%rsp),%xmm1
  70323e:	movaps 0x410(%rsp),%xmm2
  703246:	movapd 0x420(%rsp),%xmm3
  70324f:	movupd %xmm3,0x90(%rax)
  703257:	movups %xmm2,0x80(%rax)
  70325e:	movups %xmm1,0x70(%rax)
  703262:	movups %xmm0,0x60(%rax)
  703266:	jmp    7032e7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4e47>
  703268:	mov    %rax,%rbx
  70326b:	mov    0x6c8(%r14),%rax
  703272:	mov    0x298(%rsp),%rcx
  70327a:	mov    %rcx,0x28(%rax)
  70327e:	movups 0x288(%rsp),%xmm0
  703286:	movups %xmm0,0x18(%rax)
  70328a:	mov    $0x1,%r15b
  70328d:	xor    %r12d,%r12d
  703290:	jmp    7035af <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x510f>
  703295:	mov    %rax,%rbx
  703298:	lea    0x408(%rsp),%rdi
  7032a0:	call   6c16f0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::metadata::TextSlot>>>
  7032a5:	lea    0x420(%rsp),%rdi
  7032ad:	call   6c16f0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::metadata::TextSlot>>>
  7032b2:	lea    0x3f0(%rsp),%rdi
  7032ba:	call   6c72e0 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportColumn>>
  7032bf:	mov    0x438(%rsp),%rax
  7032c7:	test   %rax,%rax
  7032ca:	je     7032e7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4e47>
  7032cc:	mov    0x440(%rsp),%rdi
  7032d4:	shl    $0x3,%rax
  7032d8:	lea    (%rax,%rax,2),%rsi
  7032dc:	mov    $0x8,%edx
  7032e1:	call   *0x33ef71(%rip)        # a42258 <_DYNAMIC+0x268>
  7032e7:	mov    $0x1,%r12b
  7032ea:	movl   $0x0,0x68(%rsp)
  7032f2:	mov    $0x1,%al
  7032f4:	mov    %eax,0x70(%rsp)
  7032f8:	movl   $0x0,0x50(%rsp)
  703300:	mov    $0x1,%r15b
  703303:	jmp    70345e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4fbe>
  703308:	mov    %rax,%rbx
  70330b:	mov    0x6c8(%r14),%rax
  703312:	movq   $0x0,0x30(%rax)
  70331a:	xor    %r15d,%r15d
  70331d:	jmp    7035af <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x510f>
  703322:	mov    %rax,%rbx
  703325:	lea    0x4b0(%rsp),%rsi
  70332d:	mov    $0x1e8,%edx
  703332:	mov    %r14,%rdi
  703335:	call   *0x33ef3d(%rip)        # a42278 <memcpy@GLIBC_2.14>
  70333b:	mov    $0x1,%al
  70333d:	mov    %eax,0x68(%rsp)
  703341:	xor    %ebp,%ebp
  703343:	mov    $0x1,%r12b
  703346:	mov    $0x1,%al
  703348:	mov    %eax,0x70(%rsp)
  70334c:	mov    $0x1,%al
  70334e:	mov    %eax,0x50(%rsp)
  703352:	mov    $0x1,%r15b
  703355:	jmp    70345e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4fbe>
  70335a:	mov    %rax,%rbx
  70335d:	jmp    7035a1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5101>
  703362:	mov    %rbx,%rcx
  703365:	mov    %rax,%rbx
  703368:	mov    0x4c0(%rsp),%rax
  703370:	mov    %rax,0x10(%r15)
  703374:	movaps 0x4b0(%rsp),%xmm0
  70337c:	movups %xmm0,(%r15)
  703380:	mov    0x110(%rsp),%rax
  703388:	mov    %rax,0x5d0(%r14)
  70338f:	mov    %cx,0x5d8(%r14)
  703397:	mov    0x194(%rsp),%eax
  70339e:	mov    %ax,0x5da(%r14)
  7033a6:	movss  0x9c(%rsp),%xmm0
  7033af:	movss  %xmm0,0x5dc(%r14)
  7033b8:	xor    %r15d,%r15d
  7033bb:	jmp    7035af <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x510f>
  7033c0:	mov    %rax,%rbx
  7033c3:	mov    $0x1,%r12b
  7033c6:	jmp    7033ea <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4f4a>
  7033c8:	mov    %rax,%rbx
  7033cb:	mov    $0x1,%r12b
  7033ce:	test   %r15,%r15
  7033d1:	je     7033ea <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4f4a>
  7033d3:	shl    $0x4,%r15
  7033d7:	mov    $0x4,%edx
  7033dc:	mov    0x70(%rsp),%rdi
  7033e1:	mov    %r15,%rsi
  7033e4:	call   *0x33ee6e(%rip)        # a42258 <_DYNAMIC+0x268>
  7033ea:	mov    $0x1,%al
  7033ec:	mov    %eax,0x70(%rsp)
  7033f0:	mov    $0x1,%r15b
  7033f3:	xor    %r13d,%r13d
  7033f6:	cmpb   $0x0,0x68(%rsp)
  7033fb:	je     7035fa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x515a>
  703401:	jmp    7036f2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5252>
  703406:	mov    %rax,%rbx
  703409:	mov    $0x1,%r12b
  70340c:	mov    $0x1,%al
  70340e:	mov    %eax,0x70(%rsp)
  703412:	mov    $0x1,%al
  703414:	mov    %eax,0x50(%rsp)
  703418:	mov    $0x1,%r13b
  70341b:	mov    $0x1,%r15b
  70341e:	mov    $0x1,%bpl
  703421:	cmpq   $0xffffffffffffffff,0x278(%rsp)
  70342a:	jne    70370a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x526a>
  703430:	jmp    70371e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x527e>
  703435:	mov    %rax,%rbx
  703438:	mov    %r15d,%r13d
  70343b:	jmp    70371e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x527e>
  703440:	mov    %rax,%rbx
  703443:	mov    $0x1,%al
  703445:	mov    %eax,0x68(%rsp)
  703449:	mov    $0x1,%r12b
  70344c:	mov    $0x1,%al
  70344e:	mov    %eax,0x70(%rsp)
  703452:	mov    $0x1,%al
  703454:	mov    %eax,0x50(%rsp)
  703458:	mov    $0x1,%r15b
  70345b:	mov    $0x1,%bpl
  70345e:	movb   $0x1,0x80(%rsp)
  703466:	jmp    7035af <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x510f>
  70346b:	mov    %rax,%rbx
  70346e:	mov    %r13d,%r15d
  703471:	jmp    703749 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x52a9>
  703476:	mov    %rax,%rbx
  703479:	jmp    7035af <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x510f>
  70347e:	mov    %rax,%rbx
  703481:	mov    %r13d,%r15d
  703484:	jmp    70373c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x529c>
  703489:	mov    %rax,%rbx
  70348c:	add    $0x38,%r15
  703490:	mov    %r15,%rdi
  703493:	call   6c5ce0 <core::ptr::drop_glue::<gpui_canvas::text::RasterCache>>
  703498:	jmp    7034eb <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x504b>
  70349a:	call   *0x33ede0(%rip)        # a42280 <_DYNAMIC+0x290>
  7034a0:	mov    %rax,%rbx
  7034a3:	mov    0x320(%rsp),%rax
  7034ab:	lock decq (%rax)
  7034af:	jne    7036cd <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x522d>
  7034b5:	lea    0x320(%rsp),%rdi
  7034bd:	call   *0x33ee75(%rip)        # a42338 <_DYNAMIC+0x348>
  7034c3:	jmp    7036cd <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x522d>
  7034c8:	mov    %rax,%rbx
  7034cb:	mov    $0x1,%bpl
  7034ce:	mov    $0x1,%r15b
  7034d1:	mov    $0x1,%r13b
  7034d4:	mov    $0x1,%al
  7034d6:	mov    %eax,0x50(%rsp)
  7034da:	mov    $0x1,%al
  7034dc:	mov    %eax,0x70(%rsp)
  7034e0:	mov    $0x1,%r12b
  7034e3:	jmp    7036f2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5252>
  7034e8:	mov    %rax,%rbx
  7034eb:	mov    0x38(%rsp),%rax
  7034f0:	mov    0x6c8(%rax),%rax
  7034f7:	mov    %r12,0x30(%rax)
  7034fb:	mov    %r14d,0x38(%rax)
  7034ff:	mov    %ebp,0x3c(%rax)
  703502:	movaps 0x8f0(%rsp),%xmm0
  70350a:	movaps 0x900(%rsp),%xmm1
  703512:	movaps 0x910(%rsp),%xmm2
  70351a:	movups %xmm0,0x40(%rax)
  70351e:	movups %xmm1,0x50(%rax)
  703522:	movups %xmm2,0x60(%rax)
  703526:	mov    0x920(%rsp),%rcx
  70352e:	mov    %rcx,0x70(%rax)
  703532:	mov    $0x1,%bpl
  703535:	jmp    7038a1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5401>
  70353a:	mov    %rax,%rbx
  70353d:	mov    %r12,%rdi
  703540:	call   6bf420 <core::ptr::drop_glue::<core::option::Option<gpui::shared_text::SharedText>>>
  703545:	jmp    703620 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5180>
  70354a:	mov    %rax,%rbx
  70354d:	jmp    703880 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x53e0>
  703552:	mov    %rax,%rbx
  703555:	lea    0x4b0(%rsp),%rsi
  70355d:	mov    $0x298,%edx
  703562:	mov    %r15,%rdi
  703565:	call   *0x33ed0d(%rip)        # a42278 <memcpy@GLIBC_2.14>
  70356b:	jmp    703850 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x53b0>
  703570:	mov    %rax,%rbx
  703573:	jmp    70386e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x53ce>
  703578:	mov    %rax,%rbx
  70357b:	mov    %r14b,0x80(%rsp)
  703583:	jmp    703620 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5180>
  703588:	jmp    7036ca <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x522a>
  70358d:	ud2
  70358f:	ud2
  703591:	mov    %rax,%rbx
  703594:	lea    0x828(%rsp),%rdi
  70359c:	call   6c1310 <core::ptr::drop_glue::<alloc::vec::Vec<gpui_canvas::image::Image>>>
  7035a1:	mov    $0x1,%r12b
  7035a4:	movl   $0x0,0x70(%rsp)
  7035ac:	mov    $0x1,%r15b
  7035af:	mov    0xa0(%rsp),%rsi
  7035b7:	test   %rsi,%rsi
  7035ba:	setg   %al
  7035bd:	test   %al,0x80(%rsp)
  7035c4:	je     7035ec <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x514c>
  7035c6:	mov    0xa8(%rsp),%rdi
  7035ce:	shl    $0x4,%rsi
  7035d2:	mov    $0x4,%edx
  7035d7:	call   *0x33ec7b(%rip)        # a42258 <_DYNAMIC+0x268>
  7035dd:	xor    %r13d,%r13d
  7035e0:	cmpb   $0x0,0x68(%rsp)
  7035e5:	je     7035fa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x515a>
  7035e7:	jmp    7036f2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5252>
  7035ec:	xor    %r13d,%r13d
  7035ef:	cmpb   $0x0,0x68(%rsp)
  7035f4:	jne    7036f2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5252>
  7035fa:	cmpq   $0xffffffffffffffff,0x278(%rsp)
  703603:	jne    70370a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x526a>
  703609:	jmp    70371e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x527e>
  70360e:	jmp    70384d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x53ad>
  703613:	jmp    70384d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x53ad>
  703618:	jmp    70384d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x53ad>
  70361d:	mov    %rax,%rbx
  703620:	mov    0x218(%rsp),%rax
  703628:	test   %rax,%rax
  70362b:	setne  %cl
  70362e:	test   %cl,0x80(%rsp)
  703635:	je     7036cd <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x522d>
  70363b:	lock decq (%rax)
  70363f:	jne    7036cd <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x522d>
  703645:	lea    0x218(%rsp),%rdi
  70364d:	call   *0x33ece5(%rip)        # a42338 <_DYNAMIC+0x348>
  703653:	jmp    7036cd <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x522d>
  703655:	mov    %rax,%rbx
  703658:	mov    $0x1,%r12b
  70365b:	mov    $0x1,%r13b
  70365e:	mov    $0x1,%r15b
  703661:	mov    $0x1,%bpl
  703664:	jmp    70376d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x52cd>
  703669:	mov    %rax,%rbx
  70366c:	mov    $0x1,%r12b
  70366f:	mov    $0x1,%r13b
  703672:	mov    $0x1,%r15b
  703675:	mov    $0x1,%bpl
  703678:	jmp    70378d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x52ed>
  70367d:	mov    %rax,%rbx
  703680:	mov    $0x1,%r12b
  703683:	mov    $0x1,%r13b
  703686:	mov    $0x1,%r15b
  703689:	mov    $0x1,%bpl
  70368c:	jmp    7037b1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5311>
  703691:	mov    %rax,%rbx
  703694:	mov    $0x1,%r12b
  703697:	mov    $0x1,%r13b
  70369a:	mov    $0x1,%r15b
  70369d:	mov    $0x1,%bpl
  7036a0:	jmp    7037d5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5335>
  7036a5:	mov    %rax,%rbx
  7036a8:	mov    $0x1,%bpl
  7036ab:	mov    $0x1,%r15b
  7036ae:	mov    $0x1,%r12b
  7036b1:	jmp    7037fe <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x535e>
  7036b6:	mov    %rax,%rbx
  7036b9:	jmp    703834 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5394>
  7036be:	ud2
  7036c0:	ud2
  7036c2:	mov    %rax,%rbx
  7036c5:	jmp    7038a1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5401>
  7036ca:	mov    %rax,%rbx
  7036cd:	mov    $0x1,%bpl
  7036d0:	lea    0x8f0(%rsp),%rdi
  7036d8:	call   6c6030 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  7036dd:	mov    $0x1,%r15b
  7036e0:	mov    $0x1,%r13b
  7036e3:	mov    $0x1,%al
  7036e5:	mov    %eax,0x50(%rsp)
  7036e9:	mov    $0x1,%al
  7036eb:	mov    %eax,0x70(%rsp)
  7036ef:	mov    $0x1,%r12b
  7036f2:	lea    0x3a0(%rsp),%rdi
  7036fa:	call   6c7290 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportBuild>>
  7036ff:	cmpq   $0xffffffffffffffff,0x278(%rsp)
  703708:	je     70371e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x527e>
  70370a:	cmpb   $0x0,0x70(%rsp)
  70370f:	je     70371e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x527e>
  703711:	lea    0x828(%rsp),%rdi
  703719:	call   6c1310 <core::ptr::drop_glue::<alloc::vec::Vec<gpui_canvas::image::Image>>>
  70371e:	cmpl   $0xffffffff,0x780(%rsp)
  703726:	je     70373c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x529c>
  703728:	cmpb   $0x0,0x50(%rsp)
  70372d:	je     70373c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x529c>
  70372f:	lea    0x780(%rsp),%rdi
  703737:	call   6c76d0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  70373c:	lea    0x378(%rsp),%rdi
  703744:	call   6c41f0 <core::ptr::drop_glue::<alloc::collections::btree::set::BTreeSet<gpui::list::ListId>>>
  703749:	mov    0x170(%rsp),%rsi
  703751:	test   %rsi,%rsi
  703754:	je     70376d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x52cd>
  703756:	mov    0x178(%rsp),%rdi
  70375e:	shl    $0x2,%rsi
  703762:	mov    $0x4,%edx
  703767:	call   *0x33eaeb(%rip)        # a42258 <_DYNAMIC+0x268>
  70376d:	mov    0x198(%rsp),%rsi
  703775:	test   %rsi,%rsi
  703778:	je     70378d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x52ed>
  70377a:	mov    0x1a0(%rsp),%rdi
  703782:	mov    $0x1,%edx
  703787:	call   *0x33eacb(%rip)        # a42258 <_DYNAMIC+0x268>
  70378d:	mov    0x238(%rsp),%rsi
  703795:	test   %rsi,%rsi
  703798:	je     7037b1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5311>
  70379a:	mov    0x240(%rsp),%rdi
  7037a2:	shl    $0x4,%rsi
  7037a6:	mov    $0x4,%edx
  7037ab:	call   *0x33eaa7(%rip)        # a42258 <_DYNAMIC+0x268>
  7037b1:	mov    0x220(%rsp),%rsi
  7037b9:	test   %rsi,%rsi
  7037bc:	je     7037d5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5335>
  7037be:	mov    0x228(%rsp),%rdi
  7037c6:	shl    $0x4,%rsi
  7037ca:	mov    $0x4,%edx
  7037cf:	call   *0x33ea83(%rip)        # a42258 <_DYNAMIC+0x268>
  7037d5:	mov    0x1f8(%rsp),%rax
  7037dd:	test   %rax,%rax
  7037e0:	je     7037f9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5359>
  7037e2:	mov    0x200(%rsp),%rdi
  7037ea:	imul   $0x38,%rax,%rsi
  7037ee:	mov    $0x8,%edx
  7037f3:	call   *0x33ea5f(%rip)        # a42258 <_DYNAMIC+0x268>
  7037f9:	test   %r13b,%r13b
  7037fc:	je     703822 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5382>
  7037fe:	mov    0x2d0(%rsp),%rsi
  703806:	test   %rsi,%rsi
  703809:	je     703822 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5382>
  70380b:	mov    0x2d8(%rsp),%rdi
  703813:	shl    $0x4,%rsi
  703817:	mov    $0x4,%edx
  70381c:	call   *0x33ea36(%rip)        # a42258 <_DYNAMIC+0x268>
  703822:	test   %r15b,%r15b
  703825:	je     703834 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5394>
  703827:	lea    0x1d8(%rsp),%rdi
  70382f:	call   6c1190 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  703834:	cmpl   $0xfffffffe,0x748(%rsp)
  70383c:	je     703856 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x53b6>
  70383e:	lea    0x748(%rsp),%rdi
  703846:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  70384b:	jmp    703856 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x53b6>
  70384d:	mov    %rax,%rbx
  703850:	mov    $0x1,%r12b
  703853:	mov    $0x1,%bpl
  703856:	cmpq   $0x0,0x1c8(%rsp)
  70385f:	je     70386e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x53ce>
  703861:	mov    0x1d0(%rsp),%rdi
  703869:	call   6c5a90 <core::ptr::drop_glue::<gpui_canvas::text::TextShaper>>
  70386e:	test   %r12b,%r12b
  703871:	je     703880 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x53e0>
  703873:	lea    0x288(%rsp),%rdi
  70387b:	call   6c1520 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  703880:	mov    0x140(%rsp),%rax
  703888:	test   %rax,%rax
  70388b:	je     7038a1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5401>
  70388d:	lock decq (%rax)
  703891:	jne    7038a1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5401>
  703893:	lea    0x140(%rsp),%rdi
  70389b:	call   *0x33ea87(%rip)        # a42328 <_DYNAMIC+0x338>
  7038a1:	cmpl   $0x2,0xc10(%rsp)
  7038a9:	je     7038bd <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x541d>
  7038ab:	test   %bpl,%bpl
  7038ae:	je     7038bd <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x541d>
  7038b0:	lea    0xc10(%rsp),%rdi
  7038b8:	call   6c6030 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  7038bd:	mov    %rbx,%rdi
  7038c0:	call   a20740 <_Unwind_Resume@plt>
  7038c5:	call   *0x33e9b5(%rip)        # a42280 <_DYNAMIC+0x290>

<gpui::runtime::Runtime<text_column_public_control::Input>>::hit code=874 fixed_stack=120

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

000000000070cd60 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit>:
  70cd60:	push   %rbp
  70cd61:	push   %r15
  70cd63:	push   %r14
  70cd65:	push   %r13
  70cd67:	push   %r12
  70cd69:	push   %rbx
  70cd6a:	sub    $0x48,%rsp
  70cd6e:	movss  %xmm1,0xc(%rsp)
  70cd74:	movss  %xmm0,0x8(%rsp)
  70cd7a:	mov    %rdi,%r15
  70cd7d:	mov    0x5a8(%rdi),%r14
  70cd84:	mov    0x5b0(%rdi),%rax
  70cd8b:	mov    %rax,(%rsp)
  70cd8f:	mov    0x640(%rdi),%rbx
  70cd96:	test   %rbx,%rbx
  70cd99:	je     70cdb4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x54>
  70cd9b:	mov    0x100(%rbx),%rsi
  70cda2:	test   %rsi,%rsi
  70cda5:	je     70cdc9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x69>
  70cda7:	lea    0x30(%rsp),%rdi
  70cdac:	call   *0x335486(%rip)        # a42238 <_DYNAMIC+0x248>
  70cdb2:	jmp    70cdda <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x7a>
  70cdb4:	movq   $0x4,0x30(%rsp)
  70cdbd:	xorps  %xmm0,%xmm0
  70cdc0:	movups %xmm0,0x38(%rsp)
  70cdc5:	xor    %ebx,%ebx
  70cdc7:	jmp    70cde1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x81>
  70cdc9:	movq   $0x4,0x30(%rsp)
  70cdd2:	xorps  %xmm0,%xmm0
  70cdd5:	movups %xmm0,0x38(%rsp)
  70cdda:	cmpq   $0x0,(%rbx)
  70cdde:	setne  %bl
  70cde1:	mov    0x6a0(%r15),%rax
  70cde8:	mov    %eax,%ecx
  70cdea:	xorps  %xmm0,%xmm0
  70cded:	cvtsi2ss %rcx,%xmm0
  70cdf2:	shr    $0x20,%rax
  70cdf6:	xorps  %xmm1,%xmm1
  70cdf9:	cvtsi2ss %rax,%xmm1
  70cdfe:	movq   $0x0,0x10(%rsp)
  70ce07:	movss  %xmm0,0x18(%rsp)
  70ce0d:	movss  %xmm1,0x1c(%rsp)
  70ce13:	lea    0x10(%rsp),%rdi
  70ce18:	movss  0x8(%rsp),%xmm0
  70ce1e:	movss  0xc(%rsp),%xmm1
  70ce24:	call   *0x33570e(%rip)        # a42538 <_DYNAMIC+0x548>
  70ce2a:	xor    %r12d,%r12d
  70ce2d:	cmpq   $0x0,(%rsp)
  70ce32:	je     70ceed <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x18d>
  70ce38:	test   %al,%al
  70ce3a:	je     70ceed <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x18d>
  70ce40:	mov    (%rsp),%rax
  70ce44:	shl    $0x6,%rax
  70ce48:	add    %r14,%rax
  70ce4b:	movzbl %bl,%ebp
  70ce4e:	xor    %r12d,%r12d
  70ce51:	jmp    70cead <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x14d>
  70ce53:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  70ce60:	mov    %rbx,%r13
  70ce63:	sub    %r14,%r13
  70ce66:	shr    $0x6,%r13
  70ce6a:	mov    0x40(%rsp),%rax
  70ce6f:	mov    %rax,0x20(%rsp)
  70ce74:	movups 0x30(%rsp),%xmm0
  70ce79:	movaps %xmm0,0x10(%rsp)
  70ce7e:	mov    %r14,%rdi
  70ce81:	mov    (%rsp),%rsi
  70ce85:	lea    0x10(%rsp),%rdx
  70ce8a:	mov    %ebp,%ecx
  70ce8c:	mov    %r13,%r8
  70ce8f:	movss  0x8(%rsp),%xmm0
  70ce95:	movss  0xc(%rsp),%xmm1
  70ce9b:	call   *0x3356af(%rip)        # a42550 <_DYNAMIC+0x560>
  70cea1:	test   %al,%al
  70cea3:	jne    70ceff <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x19f>
  70cea5:	mov    %rbx,%rax
  70cea8:	cmp    %rbx,%r14
  70ceab:	je     70ceed <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x18d>
  70cead:	lea    -0x40(%rax),%rbx
  70ceb1:	cmpb   $0x0,-0x2(%rax)
  70ceb5:	jne    70ce60 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x100>
  70ceb7:	mov    -0x8(%rax),%eax
  70ceba:	cmp    $0x3ffff,%rax
  70cec0:	jbe    70cea5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x145>
  70cec2:	shr    $0x11,%eax
  70cec5:	mov    %rbx,%rcx
  70cec8:	sub    %r14,%rcx
  70cecb:	shr    $0x6,%rcx
  70cecf:	mov    $0x2,%edx
  70ced4:	sub    %rax,%rdx
  70ced7:	add    $0xfffffffffffffffe,%rax
  70cedb:	shl    $0x6,%rdx
  70cedf:	cmp    %rcx,%rax
  70cee2:	lea    -0x40(%rbx,%rdx,1),%rbx
  70cee7:	cmovae %r14,%rbx
  70ceeb:	jmp    70cea5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x145>
  70ceed:	mov    %r12,%rax
  70cef0:	add    $0x48,%rsp
  70cef4:	pop    %rbx
  70cef5:	pop    %r12
  70cef7:	pop    %r13
  70cef9:	pop    %r14
  70cefb:	pop    %r15
  70cefd:	pop    %rbp
  70cefe:	ret
  70ceff:	mov    0x1e8(%r15),%rax
  70cf06:	mov    0x1f0(%r15),%rcx
  70cf0d:	mov    0x1f8(%r15),%r8
  70cf14:	mov    0x2d0(%r15),%rsi
  70cf1b:	mov    0x2c8(%r15),%r9
  70cf22:	jmp    70cf48 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x1e8>
  70cf24:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  70cf30:	mov    0x38(%r10),%r13d
  70cf34:	and    $0x1ffff,%r13d
  70cf3b:	cmp    $0x1ffff,%r13
  70cf42:	je     70d0a1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x341>
  70cf48:	cmp    (%rsp),%r13
  70cf4c:	jae    70d0a9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x349>
  70cf52:	shl    $0x6,%r13
  70cf56:	lea    (%r14,%r13,1),%r10
  70cf5a:	mov    0x20(%r14,%r13,1),%rdx
  70cf5f:	test   %rax,%rax
  70cf62:	je     70cf80 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x220>
  70cf64:	cmp    $0x1,%eax
  70cf67:	jne    70cfa0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x240>
  70cf69:	test   %r8,%r8
  70cf6c:	je     70cf30 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x1d0>
  70cf6e:	cmp    $0x1,%r8
  70cf72:	jne    70cfc0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x260>
  70cf74:	xor    %edi,%edi
  70cf76:	jmp    70cff4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x294>
  70cf78:	nopl   0x0(%rax,%rax,1)
  70cf80:	mov    %rdx,%rdi
  70cf83:	sub    %rcx,%rdi
  70cf86:	setae  %r11b
  70cf8a:	cmp    %r8,%rdi
  70cf8d:	setb   %bl
  70cf90:	test   %bl,%r11b
  70cf93:	je     70cf30 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x1d0>
  70cf95:	jmp    70d076 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x316>
  70cf9a:	nopw   0x0(%rax,%rax,1)
  70cfa0:	test   %r8,%r8
  70cfa3:	je     70cf30 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x1d0>
  70cfa5:	cmp    $0x1,%r8
  70cfa9:	jne    70d035 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x2d5>
  70cfaf:	mov    %rcx,%rdi
  70cfb2:	cmp    %rdx,(%rcx)
  70cfb5:	jne    70cf30 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x1d0>
  70cfbb:	jmp    70d073 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x313>
  70cfc0:	mov    %r8,%r11
  70cfc3:	xor    %edi,%edi
  70cfc5:	data16 cs nopw 0x0(%rax,%rax,1)
  70cfd0:	mov    %rdi,%rbx
  70cfd3:	mov    %r11,%r15
  70cfd6:	shr    $1,%r15
  70cfd9:	add    %r15,%rdi
  70cfdc:	mov    %rdi,%r12
  70cfdf:	shl    $0x4,%r12
  70cfe3:	cmp    %rdx,(%rcx,%r12,1)
  70cfe7:	cmova  %rbx,%rdi
  70cfeb:	sub    %r15,%r11
  70cfee:	cmp    $0x1,%r11
  70cff2:	ja     70cfd0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x270>
  70cff4:	mov    %rdi,%rbx
  70cff7:	shl    $0x4,%rbx
  70cffb:	xor    %r11d,%r11d
  70cffe:	cmp    %rdx,(%rcx,%rbx,1)
  70d002:	setbe  %r11b
  70d006:	add    %rdi,%r11
  70d009:	je     70cf30 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x1d0>
  70d00f:	shl    $0x4,%r11
  70d013:	mov    %rdx,%rdi
  70d016:	sub    -0x10(%rcx,%r11,1),%rdi
  70d01b:	mov    -0x4(%rcx,%r11,1),%ebx
  70d020:	cmp    %rbx,%rdi
  70d023:	jae    70cf30 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x1d0>
  70d029:	add    %rcx,%r11
  70d02c:	mov    -0x8(%r11),%r11d
  70d030:	add    %r11,%rdi
  70d033:	jmp    70d076 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x316>
  70d035:	mov    %r8,%rdi
  70d038:	xor    %r11d,%r11d
  70d03b:	nopl   0x0(%rax,%rax,1)
  70d040:	mov    %r11,%rbx
  70d043:	mov    %rdi,%r15
  70d046:	shr    $1,%r15
  70d049:	add    %r15,%r11
  70d04c:	lea    (%r11,%r11,2),%r12
  70d050:	cmp    %rdx,(%rcx,%r12,4)
  70d054:	cmova  %rbx,%r11
  70d058:	sub    %r15,%rdi
  70d05b:	cmp    $0x1,%rdi
  70d05f:	ja     70d040 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x2e0>
  70d061:	lea    (%r11,%r11,2),%rdi
  70d065:	cmp    %rdx,(%rcx,%rdi,4)
  70d069:	jne    70cf30 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x1d0>
  70d06f:	lea    (%rcx,%rdi,4),%rdi
  70d073:	mov    0x8(%rdi),%edi
  70d076:	cmp    %rsi,%rdi
  70d079:	jae    70d0bd <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x35d>
  70d07b:	lea    (%rdi,%rdi,4),%rdi
  70d07f:	mov    $0x1,%r12d
  70d085:	cmpq   $0x0,0x8(%r9,%rdi,8)
  70d08b:	jne    70ceed <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x18d>
  70d091:	cmpb   $0x4,0x3d(%r10)
  70d096:	jne    70cf30 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x1d0>
  70d09c:	jmp    70ceed <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x18d>
  70d0a1:	xor    %r12d,%r12d
  70d0a4:	jmp    70ceed <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x18d>
  70d0a9:	lea    0x3165d0(%rip),%rdx        # a23680 <__frame_dummy_init_array_entry+0x1b90>
  70d0b0:	mov    %r13,%rdi
  70d0b3:	mov    (%rsp),%rsi
  70d0b7:	call   *0x3351cb(%rip)        # a42288 <_DYNAMIC+0x298>
  70d0bd:	lea    0x3165d4(%rip),%rdx        # a23698 <__frame_dummy_init_array_entry+0x1ba8>
  70d0c4:	call   *0x3351be(%rip)        # a42288 <_DYNAMIC+0x298>

<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge code=1446 fixed_stack=184

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

000000000070d5d0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge>:
  70d5d0:	push   %r15
  70d5d2:	push   %r14
  70d5d4:	push   %r12
  70d5d6:	push   %rbx
  70d5d7:	sub    $0x98,%rsp
  70d5de:	mov    %rdi,%r14
  70d5e1:	cmp    %rdx,0x6f0(%rsi)
  70d5e8:	jne    70d91a <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x34a>
  70d5ee:	mov    %rsi,%rbx
  70d5f1:	cmp    %rcx,0x6f8(%rsi)
  70d5f8:	jne    70d91a <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x34a>
  70d5fe:	lea    0x630(%rbx),%rdi
  70d605:	mov    %rcx,%rsi
  70d608:	call   *0x3350ea(%rip)        # a426f8 <_DYNAMIC+0x708>
  70d60e:	mov    0x618(%rbx),%rax
  70d615:	mov    %rax,0x30(%rsp)
  70d61a:	movdqu 0x5f8(%rbx),%xmm0
  70d622:	movdqu 0x608(%rbx),%xmm1
  70d62a:	movdqa %xmm0,0x10(%rsp)
  70d630:	movq   $0xffffffffffffffff,0x5f8(%rbx)
  70d63b:	movzbl 0x78c(%rbx),%eax
  70d642:	xor    $0x1,%rax
  70d646:	cmpq   $0xffffffffffffffff,0x10(%rsp)
  70d64c:	movdqa %xmm1,0x20(%rsp)
  70d652:	mov    $0x1,%r12d
  70d658:	cmove  %rax,%r12
  70d65c:	je     70d702 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x132>
  70d662:	movdqa 0x30(%rsp),%xmm0
  70d668:	movss  0x34(%rsp),%xmm2
  70d66e:	movd   %xmm0,%eax
  70d672:	pand   -0x6cc13a(%rip),%xmm0        # 41540 <GCC_except_table0+0x179c>
  70d67a:	pxor   %xmm1,%xmm1
  70d67e:	punpcklwd %xmm1,%xmm0
  70d682:	movq   %xmm0,0x6e0(%rbx)
  70d68a:	test   %ax,%ax
  70d68d:	js     70d926 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x356>
  70d693:	movss  %xmm2,0xc(%rsp)
  70d699:	lea    0x5e0(%rbx),%r15
  70d6a0:	mov    %r15,%rdi
  70d6a3:	call   6c1190 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  70d6a8:	mov    0x20(%rsp),%rax
  70d6ad:	mov    %rax,0x10(%r15)
  70d6b1:	movaps 0x10(%rsp),%xmm0
  70d6b6:	movups %xmm0,(%r15)
  70d6ba:	mov    0x708(%rbx),%rdi
  70d6c1:	test   %rdi,%rdi
  70d6c4:	je     70d6cc <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0xfc>
  70d6c6:	call   *0x335034(%rip)        # a42700 <_DYNAMIC+0x710>
  70d6cc:	mov    0x680(%rbx),%rax
  70d6d3:	test   %rax,%rax
  70d6d6:	je     70d6f4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x124>
  70d6d8:	mov    0xe0(%rax),%rax
  70d6df:	test   %rax,%rax
  70d6e2:	je     70d6f4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x124>
  70d6e4:	mov    0x50(%rax),%rcx
  70d6e8:	mov    %rcx,0x38(%rax)
  70d6ec:	movups 0x40(%rax),%xmm0
  70d6f0:	movups %xmm0,0x28(%rax)
  70d6f4:	movd   0xc(%rsp),%xmm0
  70d6fa:	movd   %xmm0,0x784(%rbx)
  70d702:	mov    0x680(%rbx),%rax
  70d709:	test   %rax,%rax
  70d70c:	je     70d948 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70d712:	mov    0x60(%rax),%r15
  70d716:	movq   $0xffffffffffffffff,0x60(%rax)
  70d71e:	cmp    $0xffffffffffffffff,%r15
  70d722:	je     70d7c6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x1f6>
  70d728:	mov    0xb8(%rax),%rcx
  70d72f:	mov    %rcx,0x90(%rsp)
  70d737:	movups 0xa8(%rax),%xmm0
  70d73e:	movaps %xmm0,0x80(%rsp)
  70d746:	movups 0x68(%rax),%xmm0
  70d74a:	movups 0x78(%rax),%xmm1
  70d74e:	movups 0x88(%rax),%xmm2
  70d755:	movups 0x98(%rax),%xmm3
  70d75c:	movaps %xmm3,0x70(%rsp)
  70d761:	movaps %xmm2,0x60(%rsp)
  70d766:	movaps %xmm1,0x50(%rsp)
  70d76b:	movaps %xmm0,0x40(%rsp)
  70d770:	mov    0x680(%rbx),%rdi
  70d777:	call   6c76d0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  70d77c:	mov    0x680(%rbx),%rax
  70d783:	mov    %r15,(%rax)
  70d786:	movaps 0x40(%rsp),%xmm0
  70d78b:	movdqa 0x50(%rsp),%xmm1
  70d791:	movaps 0x60(%rsp),%xmm2
  70d796:	movaps 0x70(%rsp),%xmm3
  70d79b:	movups %xmm0,0x8(%rax)
  70d79f:	movdqu %xmm1,0x18(%rax)
  70d7a4:	movups %xmm2,0x28(%rax)
  70d7a8:	movups %xmm3,0x38(%rax)
  70d7ac:	movdqa 0x80(%rsp),%xmm0
  70d7b5:	movdqu %xmm0,0x48(%rax)
  70d7ba:	mov    0x90(%rsp),%rcx
  70d7c2:	mov    %rcx,0x58(%rax)
  70d7c6:	mov    0x680(%rbx),%r15
  70d7cd:	test   %r15,%r15
  70d7d0:	je     70d948 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70d7d6:	mov    0x100(%r15),%rdi
  70d7dd:	test   %rdi,%rdi
  70d7e0:	je     70d830 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x260>
  70d7e2:	call   *0x334f20(%rip)        # a42708 <_DYNAMIC+0x718>
  70d7e8:	mov    0x100(%r15),%rax
  70d7ef:	cmpq   $0x0,0x10(%rax)
  70d7f4:	jne    70d830 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x260>
  70d7f6:	cmpq   $0x0,0x58(%rax)
  70d7fb:	jne    70d830 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x260>
  70d7fd:	cmpq   $0x0,0x28(%rax)
  70d802:	jne    70d830 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x260>
  70d804:	cmpq   $0xffffffffffffffff,0x30(%rax)
  70d809:	jne    70d830 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x260>
  70d80b:	mov    0x680(%rbx),%rax
  70d812:	mov    0x100(%rax),%rdi
  70d819:	call   6bf280 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::geometry::Geometry>>>>
  70d81e:	mov    0x680(%rbx),%rax
  70d825:	movq   $0x0,0x100(%rax)
  70d830:	mov    0x680(%rbx),%r15
  70d837:	test   %r15,%r15
  70d83a:	je     70d948 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70d840:	mov    0xe0(%r15),%rdi
  70d847:	test   %rdi,%rdi
  70d84a:	je     70d890 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x2c0>
  70d84c:	cmpb   $0x2,0x24(%rdi)
  70d850:	jne    70d890 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x2c0>
  70d852:	cmpb   $0x2,0x3c(%rdi)
  70d856:	jne    70d890 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x2c0>
  70d858:	cmpb   $0x2,0x54(%rdi)
  70d85c:	jne    70d890 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x2c0>
  70d85e:	mov    $0x58,%esi
  70d863:	mov    $0x8,%edx
  70d868:	call   *0x3349ea(%rip)        # a42258 <_DYNAMIC+0x268>
  70d86e:	mov    0x680(%rbx),%rax
  70d875:	movq   $0x0,0xe0(%rax)
  70d880:	mov    0x680(%rbx),%r15
  70d887:	test   %r15,%r15
  70d88a:	je     70d948 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70d890:	cmpq   $0x0,0xd8(%r15)
  70d898:	jne    70d948 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70d89e:	cmpq   $0x0,0xe0(%r15)
  70d8a6:	jne    70d948 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70d8ac:	cmpq   $0x0,0x100(%r15)
  70d8b4:	jne    70d948 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70d8ba:	cmpq   $0x0,0xd0(%r15)
  70d8c2:	jne    70d948 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70d8c8:	cmpq   $0x0,0xf8(%r15)
  70d8d0:	jne    70d948 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70d8d2:	mov    0x60(%r15),%rax
  70d8d6:	cmp    $0xffffffff,%eax
  70d8d9:	jne    70d948 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70d8db:	cmpq   $0x0,0x28(%r15)
  70d8e0:	jne    70d948 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70d8e2:	mov    (%r15),%rax
  70d8e5:	or     0x40(%r15),%rax
  70d8e9:	jne    70d948 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70d8eb:	cmpq   $0x0,0x58(%r15)
  70d8f0:	jne    70d948 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70d8f2:	mov    %r15,%rdi
  70d8f5:	call   6c7770 <core::ptr::drop_glue::<gpui::runtime::metadata::Metadata>>
  70d8fa:	mov    $0x108,%esi
  70d8ff:	mov    $0x8,%edx
  70d904:	mov    %r15,%rdi
  70d907:	call   *0x33494b(%rip)        # a42258 <_DYNAMIC+0x268>
  70d90d:	movq   $0x0,0x680(%rbx)
  70d918:	jmp    70d948 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70d91a:	movq   $0x15,(%r14)
  70d921:	jmp    70da8d <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x4bd>
  70d926:	movss  %xmm2,0x784(%rbx)
  70d92e:	lea    0x10(%rsp),%rdi
  70d933:	call   6c1190 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  70d938:	mov    0x680(%rbx),%rax
  70d93f:	test   %rax,%rax
  70d942:	jne    70d712 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x142>
  70d948:	mov    0x708(%rbx),%rdi
  70d94f:	test   %rdi,%rdi
  70d952:	je     70d979 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x3a9>
  70d954:	cmpq   $0x0,0x30(%rdi)
  70d959:	jne    70d979 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x3a9>
  70d95b:	cmpq   $0x0,0x10(%rdi)
  70d960:	jne    70d979 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x3a9>
  70d962:	cmpq   $0xffffffffffffffff,0x18(%rdi)
  70d967:	jne    70d979 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x3a9>
  70d969:	call   6bf110 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::text_geometry::TextResources>>>>
  70d96e:	movq   $0x0,0x708(%rbx)
  70d979:	mov    0x658(%rbx),%rdx
  70d980:	test   %rdx,%rdx
  70d983:	je     70da25 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x455>
  70d989:	mov    0x660(%rbx),%rcx
  70d990:	lea    0x40(%rsp),%rdi
  70d995:	mov    %rbx,%rsi
  70d998:	call   712fb0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::resolve_index>
  70d99d:	mov    0x40(%rsp),%rax
  70d9a2:	mov    0x48(%rsp),%rsi
  70d9a7:	cmp    $0xfffffffffffffffe,%rax
  70d9ab:	jne    70d9d8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x408>
  70d9ad:	mov    0x310(%rbx),%rax
  70d9b4:	cmp    %rax,%rsi
  70d9b7:	jae    70da9c <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x4cc>
  70d9bd:	lea    (%rsi,%rsi,4),%rdi
  70d9c1:	shl    $0x3,%rdi
  70d9c5:	add    0x308(%rbx),%rdi
  70d9cc:	call   *0x334b6e(%rip)        # a42540 <_DYNAMIC+0x550>
  70d9d2:	test   %al,%al
  70d9d4:	je     70da1a <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x44a>
  70d9d6:	jmp    70da25 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x455>
  70d9d8:	sub    $0xd,%rax
  70d9dc:	mov    $0x14,%ecx
  70d9e1:	cmovge %rax,%rcx
  70d9e5:	cmp    $0x14,%rcx
  70d9e9:	je     70d9fd <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x42d>
  70d9eb:	cmp    $0x19,%rcx
  70d9ef:	jne    70da1a <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x44a>
  70d9f1:	test   %rsi,%rsi
  70d9f4:	je     70da1a <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x44a>
  70d9f6:	lea    0x50(%rsp),%rax
  70d9fb:	jmp    70da0c <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x43c>
  70d9fd:	mov    0x58(%rsp),%rsi
  70da02:	test   %rsi,%rsi
  70da05:	je     70da1a <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x44a>
  70da07:	lea    0x60(%rsp),%rax
  70da0c:	mov    (%rax),%rdi
  70da0f:	mov    $0x1,%edx
  70da14:	call   *0x33483e(%rip)        # a42258 <_DYNAMIC+0x268>
  70da1a:	movq   $0x0,0x658(%rbx)
  70da25:	mov    0x700(%rbx),%rax
  70da2c:	mov    %rax,0x6d8(%rbx)
  70da33:	movb   $0x1,0x78c(%rbx)
  70da3a:	add    %r12,0x758(%rbx)
  70da41:	cmpq   $0x0,0x6f0(%rbx)
  70da49:	setne  %cl
  70da4c:	cmpq   $0xffffffffffffffff,0x5f8(%rbx)
  70da54:	mov    0x6d0(%rbx),%rdx
  70da5b:	setne  %sil
  70da5f:	and    %cl,%sil
  70da62:	movzbl %sil,%ecx
  70da66:	mov    0x778(%rbx),%rsi
  70da6d:	mov    %rcx,0x8(%r14)
  70da71:	mov    %rax,0x10(%r14)
  70da75:	mov    %rdx,0x18(%r14)
  70da79:	mov    %rax,0x20(%r14)
  70da7d:	mov    %rsi,0x28(%r14)
  70da81:	movb   $0x1,0x30(%r14)
  70da86:	movq   $0xfffffffffffffffe,(%r14)
  70da8d:	add    $0x98,%rsp
  70da94:	pop    %rbx
  70da95:	pop    %r12
  70da97:	pop    %r14
  70da99:	pop    %r15
  70da9b:	ret
  70da9c:	lea    0x31477d(%rip),%rdx        # a22220 <__frame_dummy_init_array_entry+0x730>
  70daa3:	mov    %rsi,%rdi
  70daa6:	mov    %rax,%rsi
  70daa9:	call   *0x3347d9(%rip)        # a42288 <_DYNAMIC+0x298>
  70daaf:	mov    %rax,%r14
  70dab2:	mov    $0x108,%esi
  70dab7:	mov    $0x8,%edx
  70dabc:	mov    %r15,%rdi
  70dabf:	call   *0x334793(%rip)        # a42258 <_DYNAMIC+0x268>
  70dac5:	movq   $0x0,0x680(%rbx)
  70dad0:	mov    %r14,%rdi
  70dad3:	call   a20740 <_Unwind_Resume@plt>
  70dad8:	mov    %rax,%r14
  70dadb:	mov    0x680(%rbx),%rax
  70dae2:	movq   $0x0,0x100(%rax)
  70daed:	mov    %r14,%rdi
  70daf0:	call   a20740 <_Unwind_Resume@plt>
  70daf5:	movq   $0x0,0x708(%rbx)
  70db00:	mov    %rax,%rdi
  70db03:	call   a20740 <_Unwind_Resume@plt>
  70db08:	mov    %rax,%r14
  70db0b:	mov    0x680(%rbx),%rax
  70db12:	mov    %r15,(%rax)
  70db15:	movaps 0x40(%rsp),%xmm0
  70db1a:	movaps 0x50(%rsp),%xmm1
  70db1f:	movaps 0x60(%rsp),%xmm2
  70db24:	movaps 0x70(%rsp),%xmm3
  70db29:	movups %xmm0,0x8(%rax)
  70db2d:	movups %xmm1,0x18(%rax)
  70db31:	movups %xmm2,0x28(%rax)
  70db35:	movups %xmm3,0x38(%rax)
  70db39:	movaps 0x80(%rsp),%xmm0
  70db41:	movups %xmm0,0x48(%rax)
  70db45:	mov    0x90(%rsp),%rcx
  70db4d:	mov    %rcx,0x58(%rax)
  70db51:	mov    %r14,%rdi
  70db54:	call   a20740 <_Unwind_Resume@plt>
  70db59:	mov    %rax,%r14
  70db5c:	mov    0x20(%rsp),%rax
  70db61:	mov    %rax,0x10(%r15)
  70db65:	movaps 0x10(%rsp),%xmm0
  70db6a:	movups %xmm0,(%r15)
  70db6e:	mov    %r14,%rdi
  70db71:	call   a20740 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner code=21547 fixed_stack=3624

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

000000000070db80 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner>:
  70db80:	push   %rbp
  70db81:	push   %r15
  70db83:	push   %r14
  70db85:	push   %r13
  70db87:	push   %r12
  70db89:	push   %rbx
  70db8a:	sub    $0xdf8,%rsp
  70db91:	mov    %rdi,0x40(%rsp)
  70db96:	mov    0x628(%rsi),%rax
  70db9d:	mov    %rax,0x308(%rsp)
  70dba5:	inc    %rax
  70dba8:	je     71213e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x45be>
  70dbae:	mov    %rsi,%r14
  70dbb1:	mov    %rax,0x820(%rsp)
  70dbb9:	mov    0x620(%rsi),%rax
  70dbc0:	mov    %rax,0x350(%rsp)
  70dbc8:	mov    0x6e8(%rsi),%rsi
  70dbcf:	movq   %rsi,%xmm0
  70dbd4:	movdqa %xmm0,0x80(%rsp)
  70dbdd:	pshufd $0x55,%xmm0,%xmm0
  70dbe2:	movd   %xmm0,%edx
  70dbe6:	movss  0x780(%r14),%xmm0
  70dbef:	movss  %xmm0,0x9c(%rsp)
  70dbf8:	mov    0x1a8(%r14),%eax
  70dbff:	mov    0x1b0(%r14),%rcx
  70dc06:	shl    $0x20,%rcx
  70dc0a:	or     %rax,%rcx
  70dc0d:	cmp    %rsi,%rcx
  70dc10:	mov    %r14,0x38(%rsp)
  70dc15:	mov    %rsi,0x310(%rsp)
  70dc1d:	mov    %edx,0x194(%rsp)
  70dc24:	jne    70dc4d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xcd>
  70dc26:	movq   $0x2,0xc10(%rsp)
  70dc32:	mov    $0x2,%ebx
  70dc37:	cmpl   $0xffff,0x310(%rsp)
  70dc42:	jbe    70dcec <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x16c>
  70dc48:	jmp    70dcf9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x179>
  70dc4d:	movups 0x138(%r14),%xmm0
  70dc55:	movaps %xmm0,0x8f0(%rsp)
  70dc5d:	lea    0x4b0(%rsp),%rdi
  70dc65:	lea    0x8f0(%rsp),%rcx
  70dc6d:	call   *0x33488d(%rip)        # a42500 <_DYNAMIC+0x510>
  70dc73:	mov    0x4b0(%rsp),%rbx
  70dc7b:	mov    0x4b8(%rsp),%r14d
  70dc83:	mov    0x4bc(%rsp),%ebp
  70dc8a:	cmp    $0x2,%rbx
  70dc8e:	jne    70dca8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x128>
  70dc90:	mov    0x40(%rsp),%rax
  70dc95:	movq   $0x23,(%rax)
  70dc9c:	mov    %r14d,0x8(%rax)
  70dca0:	mov    %ebp,0xc(%rax)
  70dca3:	jmp    70f3f6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1876>
  70dca8:	lea    0x4c0(%rsp),%rsi
  70dcb0:	lea    0xc20(%rsp),%rdi
  70dcb8:	mov    $0x1d8,%edx
  70dcbd:	call   *0x3345b5(%rip)        # a42278 <memcpy@GLIBC_2.14>
  70dcc3:	mov    %rbx,0xc10(%rsp)
  70dccb:	mov    %r14d,0xc18(%rsp)
  70dcd3:	mov    %ebp,0xc1c(%rsp)
  70dcda:	mov    0x38(%rsp),%r14
  70dcdf:	cmpl   $0xffff,0x310(%rsp)
  70dcea:	ja     70dcf9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x179>
  70dcec:	cmpl   $0xffff,0x194(%rsp)
  70dcf7:	jbe    70dd1a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x19a>
  70dcf9:	mov    0x40(%rsp),%rax
  70dcfe:	movq   $0x23,(%rax)
  70dd05:	movl   $0x0,0x8(%rax)
  70dd0c:	cmp    $0x2,%ebx
  70dd0f:	jne    70f3e9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1869>
  70dd15:	jmp    70f3f6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1876>
  70dd1a:	cmpq   $0x0,0x328(%r14)
  70dd22:	je     70dd37 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1b7>
  70dd24:	mov    0x708(%r14),%rax
  70dd2b:	test   %rax,%rax
  70dd2e:	je     70dd4c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1cc>
  70dd30:	cmpq   $0x0,0x30(%rax)
  70dd35:	je     70dd99 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x219>
  70dd37:	mov    0x708(%r14),%rax
  70dd3e:	test   %rax,%rax
  70dd41:	jne    70de97 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x317>
  70dd47:	jmp    70def4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x374>
  70dd4c:	call   *0x33450e(%rip)        # a42260 <_DYNAMIC+0x270>
  70dd52:	mov    $0x78,%edi
  70dd57:	mov    $0x8,%esi
  70dd5c:	call   *0x334506(%rip)        # a42268 <_DYNAMIC+0x278>
  70dd62:	test   %rax,%rax
  70dd65:	je     71255e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x49de>
  70dd6b:	movq   $0x0,(%rax)
  70dd72:	movq   $0x8,0x8(%rax)
  70dd7a:	movq   $0x0,0x10(%rax)
  70dd82:	movq   $0xffffffffffffffff,0x18(%rax)
  70dd8a:	movq   $0x0,0x30(%rax)
  70dd92:	mov    %rax,0x708(%r14)
  70dd99:	mov    $0x1,%bpl
  70dd9c:	lea    0x4b0(%rsp),%rdi
  70dda4:	call   *0x334966(%rip)        # a42710 <_DYNAMIC+0x720>
  70ddaa:	mov    0x4b0(%rsp),%r12
  70ddb2:	mov    0x4b8(%rsp),%r14d
  70ddba:	mov    0x4bc(%rsp),%ebp
  70ddc1:	test   %r12,%r12
  70ddc4:	je     70f302 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1782>
  70ddca:	mov    0x4f0(%rsp),%rax
  70ddd2:	mov    %rax,0x920(%rsp)
  70ddda:	movups 0x4c0(%rsp),%xmm0
  70dde2:	movups 0x4d0(%rsp),%xmm1
  70ddea:	movups 0x4e0(%rsp),%xmm2
  70ddf2:	movaps %xmm2,0x910(%rsp)
  70ddfa:	movaps %xmm1,0x900(%rsp)
  70de02:	movaps %xmm0,0x8f0(%rsp)
  70de0a:	mov    0x38(%rsp),%rax
  70de0f:	mov    0x708(%rax),%r15
  70de16:	mov    0x30(%r15),%rax
  70de1a:	test   %rax,%rax
  70de1d:	je     70de47 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2c7>
  70de1f:	lock decq (%rax)
  70de23:	jne    70de2f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2af>
  70de25:	lea    0x30(%r15),%rdi
  70de29:	call   *0x3344f9(%rip)        # a42328 <_DYNAMIC+0x338>
  70de2f:	add    $0x38,%r15
  70de33:	mov    %r15,%rdi
  70de36:	call   6c5ce0 <core::ptr::drop_glue::<gpui_canvas::text::RasterCache>>
  70de3b:	mov    0x38(%rsp),%rax
  70de40:	mov    0x708(%rax),%r15
  70de47:	mov    %r12,0x30(%r15)
  70de4b:	mov    %r14d,0x38(%r15)
  70de4f:	mov    %ebp,0x3c(%r15)
  70de53:	movaps 0x8f0(%rsp),%xmm0
  70de5b:	movaps 0x900(%rsp),%xmm1
  70de63:	movaps 0x910(%rsp),%xmm2
  70de6b:	movups %xmm0,0x40(%r15)
  70de70:	movups %xmm1,0x50(%r15)
  70de75:	movups %xmm2,0x60(%r15)
  70de7a:	mov    0x920(%rsp),%rax
  70de82:	mov    %rax,0x70(%r15)
  70de86:	mov    0x38(%rsp),%r14
  70de8b:	mov    0x708(%r14),%rax
  70de92:	test   %rax,%rax
  70de95:	je     70def4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x374>
  70de97:	mov    0x30(%rax),%rax
  70de9b:	test   %rax,%rax
  70de9e:	je     70def4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x374>
  70dea0:	lock incq (%rax)
  70dea4:	jle    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  70deaa:	mov    %rax,0x140(%rsp)
  70deb2:	movq   $0x0,0x288(%rsp)
  70debe:	movq   $0x8,0x290(%rsp)
  70deca:	movq   $0x0,0x298(%rsp)
  70ded6:	lea    0x140(%rsp),%rax
  70dede:	mov    %rax,0x1c8(%rsp)
  70dee6:	movq   $0x0,0x1d0(%rsp)
  70def2:	jmp    70df30 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3b0>
  70def4:	movq   $0x0,0x140(%rsp)
  70df00:	movq   $0x0,0x288(%rsp)
  70df0c:	movq   $0x8,0x290(%rsp)
  70df18:	movq   $0x0,0x298(%rsp)
  70df24:	movq   $0x0,0x1c8(%rsp)
  70df30:	lea    0x458(%rsp),%rdi
  70df38:	mov    %r14,%rsi
  70df3b:	call   6ed410 <<gpui::runtime::Runtime<text_column_public_control::Model>>::active_selection>
  70df40:	lea    0x4b0(%rsp),%rdi
  70df48:	mov    %r14,%rsi
  70df4b:	call   6ed410 <<gpui::runtime::Runtime<text_column_public_control::Model>>::active_selection>
  70df50:	movzbl 0x4c4(%rsp),%ebx
  70df58:	cmp    $0x2,%bl
  70df5b:	je     70dfb3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x433>
  70df5d:	mov    0x4b0(%rsp),%rax
  70df65:	mov    %rax,0x818(%rsp)
  70df6d:	test   %rax,%rax
  70df70:	je     712540 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x49c0>
  70df76:	mov    0x4c0(%rsp),%eax
  70df7d:	mov    %eax,0x370(%rsp)
  70df84:	mov    0x4b8(%rsp),%rax
  70df8c:	mov    %rax,0x368(%rsp)
  70df94:	movzwl 0x4c5(%rsp),%eax
  70df9c:	mov    %ax,0x12c(%rsp)
  70dfa4:	movzbl 0x4c7(%rsp),%eax
  70dfac:	mov    %al,0x12e(%rsp)
  70dfb3:	lea    0x330(%r14),%rax
  70dfba:	mov    %rax,0x68(%rsp)
  70dfbf:	cmpb   $0x0,0x788(%r14)
  70dfc7:	mov    %bl,0x9b(%rsp)
  70dfce:	jne    70e322 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x7a2>
  70dfd4:	cmpb   $0x0,0x789(%r14)
  70dfdc:	jne    70e322 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x7a2>
  70dfe2:	cmpb   $0x0,0x5c0(%r14)
  70dfea:	jne    70e322 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x7a2>
  70dff0:	mov    0x688(%r14),%rax
  70dff7:	mov    0x698(%r14),%r15
  70dffe:	test   %rax,%rax
  70e001:	setne  %cl
  70e004:	test   %r15,%r15
  70e007:	setne  %dl
  70e00a:	and    %cl,%dl
  70e00c:	cmp    $0x1,%dl
  70e00f:	jne    70e866 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xce6>
  70e015:	mov    0x38(%rsp),%rcx
  70e01a:	mov    0x690(%rcx),%r14
  70e021:	lea    0x1e8(%rcx),%rdx
  70e028:	mov    %rdx,0x50(%rsp)
  70e02d:	add    $0x6b8,%rcx
  70e034:	mov    %rcx,0x70(%rsp)
  70e039:	xor    %ebx,%ebx
  70e03b:	lea    0x3156b6(%rip),%rcx        # a236f8 <__frame_dummy_init_array_entry+0x1c08>
  70e042:	mov    %rcx,0x48(%rsp)
  70e047:	jmp    70e06b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4eb>
  70e049:	nopl   0x0(%rax)
  70e050:	mov    0x70(%rsp),%rdi
  70e055:	mov    %r12,%rsi
  70e058:	call   6fc490 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  70e05d:	mov    $0x0,%eax
  70e062:	dec    %r15
  70e065:	je     70e866 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xce6>
  70e06b:	test   %rbx,%rbx
  70e06e:	je     70e090 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x510>
  70e070:	movzwl 0x58a(%rbx),%ecx
  70e077:	cmp    %rcx,%r14
  70e07a:	jae    70e140 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5c0>
  70e080:	mov    %rbx,%rcx
  70e083:	mov    %r14,%rdx
  70e086:	jmp    70e166 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5e6>
  70e08b:	nopl   0x0(%rax,%rax,1)
  70e090:	test   %r14,%r14
  70e093:	je     70e0cd <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x54d>
  70e095:	mov    %r14,%rcx
  70e098:	mov    %rax,%rbx
  70e09b:	and    $0x7,%rcx
  70e09f:	je     70e0d2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x552>
  70e0a1:	xor    %edx,%edx
  70e0a3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  70e0b0:	mov    0x590(%rbx),%rbx
  70e0b7:	inc    %rdx
  70e0ba:	cmp    %rdx,%rcx
  70e0bd:	jne    70e0b0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x530>
  70e0bf:	mov    %r14,%rax
  70e0c2:	sub    %rdx,%rax
  70e0c5:	cmp    $0x8,%r14
  70e0c9:	jae    70e0e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x560>
  70e0cb:	jmp    70e11e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x59e>
  70e0cd:	mov    %rax,%rbx
  70e0d0:	jmp    70e11e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x59e>
  70e0d2:	mov    %r14,%rax
  70e0d5:	cmp    $0x8,%r14
  70e0d9:	jb     70e11e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x59e>
  70e0db:	nopl   0x0(%rax,%rax,1)
  70e0e0:	mov    0x590(%rbx),%rcx
  70e0e7:	mov    0x590(%rcx),%rcx
  70e0ee:	mov    0x590(%rcx),%rcx
  70e0f5:	mov    0x590(%rcx),%rcx
  70e0fc:	mov    0x590(%rcx),%rcx
  70e103:	mov    0x590(%rcx),%rcx
  70e10a:	mov    0x590(%rcx),%rcx
  70e111:	mov    0x590(%rcx),%rbx
  70e118:	add    $0xfffffffffffffff8,%rax
  70e11c:	jne    70e0e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x560>
  70e11e:	xor    %eax,%eax
  70e120:	xor    %r14d,%r14d
  70e123:	movzwl 0x58a(%rbx),%ecx
  70e12a:	cmp    %rcx,%r14
  70e12d:	jb     70e080 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x500>
  70e133:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  70e140:	mov    0x580(%rbx),%rcx
  70e147:	test   %rcx,%rcx
  70e14a:	je     712576 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x49f6>
  70e150:	inc    %rax
  70e153:	movzwl 0x588(%rbx),%edx
  70e15a:	mov    %rcx,%rbx
  70e15d:	cmp    0x58a(%rcx),%dx
  70e164:	jae    70e140 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5c0>
  70e166:	test   %rax,%rax
  70e169:	je     70e200 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x680>
  70e16f:	lea    (%rcx,%rdx,8),%rsi
  70e173:	add    $0x598,%rsi
  70e17a:	mov    %rax,%rdi
  70e17d:	and    $0x7,%rdi
  70e181:	je     70e310 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x790>
  70e187:	xor    %r8d,%r8d
  70e18a:	nopw   0x0(%rax,%rax,1)
  70e190:	mov    (%rsi),%rbx
  70e193:	lea    0x590(%rbx),%rsi
  70e19a:	inc    %r8
  70e19d:	cmp    %r8,%rdi
  70e1a0:	jne    70e190 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x610>
  70e1a2:	mov    %rax,%rdi
  70e1a5:	sub    %r8,%rdi
  70e1a8:	cmp    $0x8,%rax
  70e1ac:	jb     70e1f1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x671>
  70e1ae:	xchg   %ax,%ax
  70e1b0:	mov    (%rsi),%rax
  70e1b3:	mov    0x590(%rax),%rax
  70e1ba:	mov    0x590(%rax),%rax
  70e1c1:	mov    0x590(%rax),%rax
  70e1c8:	mov    0x590(%rax),%rax
  70e1cf:	mov    0x590(%rax),%rax
  70e1d6:	mov    0x590(%rax),%rax
  70e1dd:	mov    0x590(%rax),%rbx
  70e1e4:	lea    0x590(%rbx),%rsi
  70e1eb:	add    $0xfffffffffffffff8,%rdi
  70e1ef:	jne    70e1b0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x630>
  70e1f1:	xor    %r14d,%r14d
  70e1f4:	jmp    70e207 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x687>
  70e1f6:	cs nopw 0x0(%rax,%rax,1)
  70e200:	lea    0x1(%rdx),%r14
  70e204:	mov    %rcx,%rbx
  70e207:	imul   $0x70,%rdx,%rax
  70e20b:	shl    $0x4,%rdx
  70e20f:	lea    (%rcx,%rax,1),%rdi
  70e213:	add    $0xb0,%rdi
  70e21a:	mov    (%rcx,%rdx,1),%rsi
  70e21e:	mov    0x8(%rcx,%rdx,1),%rdx
  70e223:	call   *0x3341a7(%rip)        # a423d0 <_DYNAMIC+0x3e0>
  70e229:	mov    %rax,%r12
  70e22c:	mov    0x50(%rsp),%rdi
  70e231:	mov    %rax,%rsi
  70e234:	call   6f7cf0 <<gpui::runtime::identity_index::IdentityIndex>::required>
  70e239:	mov    %rax,%rbp
  70e23c:	mov    0x38(%rsp),%rax
  70e241:	mov    0x310(%rax),%r13
  70e248:	cmp    %r13,%rbp
  70e24b:	jae    7127a5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c25>
  70e251:	mov    0x308(%rax),%rcx
  70e258:	lea    0x0(,%rbp,4),%rax
  70e260:	add    %rbp,%rax
  70e263:	mov    0x18(%rcx,%rax,8),%ebp
  70e267:	mov    $0xffffffff,%eax
  70e26c:	cmp    %rax,%rbp
  70e26f:	je     70e05d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4dd>
  70e275:	cmp    %rbp,%r13
  70e278:	jbe    7126e1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b61>
  70e27e:	mov    0x70(%rsp),%rax
  70e283:	mov    (%rax),%rax
  70e286:	test   %rax,%rax
  70e289:	je     70e05d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4dd>
  70e28f:	lea    0x0(,%rbp,4),%rdx
  70e297:	add    %rbp,%rdx
  70e29a:	mov    (%rcx,%rdx,8),%rcx
  70e29e:	mov    0x38(%rsp),%rdx
  70e2a3:	mov    0x6c0(%rdx),%rdx
  70e2aa:	movzwl 0x62(%rax),%edi
  70e2ae:	mov    %edi,%r8d
  70e2b1:	shl    $0x3,%r8d
  70e2b5:	mov    $0xffffffffffffffff,%rsi
  70e2bc:	nopl   0x0(%rax)
  70e2c0:	test   %r8,%r8
  70e2c3:	je     70e2f0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x770>
  70e2c5:	cmp    0x10(%rax,%rsi,8),%rcx
  70e2ca:	seta   %r9b
  70e2ce:	sbb    $0x0,%r9b
  70e2d2:	inc    %rsi
  70e2d5:	add    $0xfffffffffffffff8,%r8
  70e2d9:	cmp    $0x1,%r9b
  70e2dd:	je     70e2c0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x740>
  70e2df:	movzbl %r9b,%edi
  70e2e3:	test   %edi,%edi
  70e2e5:	je     70e050 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d0>
  70e2eb:	jmp    70e2f3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x773>
  70e2ed:	nopl   (%rax)
  70e2f0:	mov    %rdi,%rsi
  70e2f3:	sub    $0x1,%rdx
  70e2f7:	jb     70e05d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4dd>
  70e2fd:	mov    0x68(%rax,%rsi,8),%rax
  70e302:	jmp    70e2aa <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x72a>
  70e304:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  70e310:	mov    %rax,%rdi
  70e313:	cmp    $0x8,%rax
  70e317:	jae    70e1b0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x630>
  70e31d:	jmp    70e1f1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x671>
  70e322:	lea    0x4b0(%rsp),%rdi
  70e32a:	call   *0x3341e0(%rip)        # a42510 <_DYNAMIC+0x520>
  70e330:	lea    0x330(%r14),%r15
  70e337:	mov    %r15,%rdi
  70e33a:	call   6c5550 <core::ptr::drop_glue::<gpui_reactivity_core::layout::LayoutTree>>
  70e33f:	lea    0x4b0(%rsp),%rsi
  70e347:	mov    $0x298,%edx
  70e34c:	mov    %r15,%rdi
  70e34f:	call   *0x333f23(%rip)        # a42278 <memcpy@GLIBC_2.14>
  70e355:	movq   $0x0,0x5d8(%r14)
  70e360:	mov    0x310(%r14),%rax
  70e367:	test   %rax,%rax
  70e36a:	je     70ee4b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x12cb>
  70e370:	lea    0x5c8(%r14),%rcx
  70e377:	mov    %rcx,0x70(%rsp)
  70e37c:	mov    0x308(%r14),%r12
  70e383:	lea    (%rax,%rax,4),%rax
  70e387:	lea    (%r12,%rax,8),%rax
  70e38b:	mov    %rax,0x50(%rsp)
  70e390:	xor    %r13d,%r13d
  70e393:	lea    0x313f8e(%rip),%rax        # a22328 <__frame_dummy_init_array_entry+0x838>
  70e39a:	mov    %rax,0x48(%rsp)
  70e39f:	xor    %ebx,%ebx
  70e3a1:	jmp    70e3e6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x866>
  70e3a3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  70e3b0:	add    $0x28,%r12
  70e3b4:	inc    %rbx
  70e3b7:	mov    0x5d0(%r14),%rax
  70e3be:	mov    %r13,%rcx
  70e3c1:	shl    $0x4,%rcx
  70e3c5:	movaps 0x8d0(%rsp),%xmm0
  70e3cd:	movups %xmm0,(%rax,%rcx,1)
  70e3d1:	inc    %r13
  70e3d4:	mov    %r13,0x5d8(%r14)
  70e3db:	cmp    0x50(%rsp),%r12
  70e3e0:	je     70ee4b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x12cb>
  70e3e6:	mov    0x18(%r12),%ebp
  70e3eb:	mov    $0xffffffff,%eax
  70e3f0:	cmp    %rax,%rbp
  70e3f3:	je     70e430 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x8b0>
  70e3f5:	cmp    %rbp,%r13
  70e3f8:	jbe    7127a5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c25>
  70e3fe:	mov    0x5d0(%r14),%rax
  70e405:	mov    %rbp,%rcx
  70e408:	shl    $0x4,%rcx
  70e40c:	movups (%rax,%rcx,1),%xmm0
  70e410:	lea    0xbd8(%rsp),%rax
  70e418:	movups %xmm0,(%rax)
  70e41b:	mov    $0x1,%eax
  70e420:	jmp    70e432 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x8b2>
  70e422:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  70e430:	xor    %eax,%eax
  70e432:	mov    %rax,0xbd0(%rsp)
  70e43a:	mov    0x20(%r12),%eax
  70e43f:	and    $0xf,%eax
  70e442:	cmp    $0xa,%eax
  70e445:	jae    712522 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x49a2>
  70e44b:	lea    -0x6bd800(%rip),%rcx        # 50c52 <GCC_except_table0+0x10eae>
  70e452:	movzbl (%rax,%rcx,1),%r15d
  70e457:	mov    0x38(%rsp),%r14
  70e45c:	mov    0x200(%r14),%rax
  70e463:	lea    -0x6cc78e(%rip),%rcx        # 41cdc <GCC_except_table0+0x1f38>
  70e46a:	movslq (%rcx,%rax,4),%rax
  70e46e:	add    %rcx,%rax
  70e471:	jmp    *%rax
  70e473:	movups -0x6c130a(%rip),%xmm0        # 4d170 <GCC_except_table0+0xd3cc>
  70e47a:	movaps %xmm0,0x930(%rsp)
  70e482:	movups -0x6c1329(%rip),%xmm0        # 4d160 <GCC_except_table0+0xd3bc>
  70e489:	movaps %xmm0,0x920(%rsp)
  70e491:	movups -0x6c1348(%rip),%xmm0        # 4d150 <GCC_except_table0+0xd3ac>
  70e498:	movaps %xmm0,0x910(%rsp)
  70e4a0:	movups -0x6c1367(%rip),%xmm0        # 4d140 <GCC_except_table0+0xd39c>
  70e4a7:	movaps %xmm0,0x900(%rsp)
  70e4af:	movups -0x6c1386(%rip),%xmm0        # 4d130 <GCC_except_table0+0xd38c>
  70e4b6:	movaps %xmm0,0x8f0(%rsp)
  70e4be:	movabs $0x3000100000000,%rax
  70e4c8:	mov    %rax,0x940(%rsp)
  70e4d0:	cmp    $0xffffffff,%ebp
  70e4d3:	jne    70e568 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x9e8>
  70e4d9:	jmp    70e619 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xa99>
  70e4de:	mov    0x220(%r14),%r13
  70e4e5:	cmp    %r13,%rbx
  70e4e8:	jae    71275e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4bde>
  70e4ee:	mov    0x210(%r14),%r13
  70e4f5:	mov    0x218(%r14),%rax
  70e4fc:	movzbl (%rax,%rbx,1),%eax
  70e500:	cmp    %rax,%r13
  70e503:	jbe    71276a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4bea>
  70e509:	mov    0x208(%r14),%rcx
  70e510:	imul   $0x58,%rax,%rax
  70e514:	mov    0x50(%rcx,%rax,1),%rdx
  70e519:	mov    %rdx,0x940(%rsp)
  70e521:	movups 0x40(%rcx,%rax,1),%xmm0
  70e526:	movaps %xmm0,0x930(%rsp)
  70e52e:	movups (%rcx,%rax,1),%xmm0
  70e532:	movups 0x10(%rcx,%rax,1),%xmm1
  70e537:	movups 0x20(%rcx,%rax,1),%xmm2
  70e53c:	movupd 0x30(%rcx,%rax,1),%xmm3
  70e542:	jmp    70e5ef <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xa6f>
  70e547:	mov    0x208(%r14),%rsi
  70e54e:	lea    0x8f0(%rsp),%rdi
  70e556:	mov    %rbx,%rdx
  70e559:	call   *0x333e89(%rip)        # a423e8 <_DYNAMIC+0x3f8>
  70e55f:	cmp    $0xffffffff,%ebp
  70e562:	je     70e619 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xa99>
  70e568:	mov    0x200(%r14),%rax
  70e56f:	lea    -0x6cc88a(%rip),%rdx        # 41cec <GCC_except_table0+0x1f48>
  70e576:	movslq (%rdx,%rax,4),%rcx
  70e57a:	add    %rdx,%rcx
  70e57d:	lea    -0x6c1454(%rip),%rax        # 4d130 <GCC_except_table0+0xd38c>
  70e584:	jmp    *%rcx
  70e586:	mov    0x218(%r14),%r13
  70e58d:	cmp    %rbp,%r13
  70e590:	jbe    712755 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4bd5>
  70e596:	imul   $0x58,%rbp,%rax
  70e59a:	add    0x210(%r14),%rax
  70e5a1:	jmp    70e666 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xae6>
  70e5a6:	mov    0x218(%r14),%r13
  70e5ad:	cmp    %r13,%rbx
  70e5b0:	jae    71276f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4bef>
  70e5b6:	mov    0x210(%r14),%rax
  70e5bd:	imul   $0x58,%rbx,%rcx
  70e5c1:	mov    0x50(%rax,%rcx,1),%rdx
  70e5c6:	mov    %rdx,0x940(%rsp)
  70e5ce:	movups 0x40(%rax,%rcx,1),%xmm0
  70e5d3:	movaps %xmm0,0x930(%rsp)
  70e5db:	movups (%rax,%rcx,1),%xmm0
  70e5df:	movups 0x10(%rax,%rcx,1),%xmm1
  70e5e4:	movups 0x20(%rax,%rcx,1),%xmm2
  70e5e9:	movupd 0x30(%rax,%rcx,1),%xmm3
  70e5ef:	movapd %xmm3,0x920(%rsp)
  70e5f8:	movaps %xmm2,0x910(%rsp)
  70e600:	movaps %xmm1,0x900(%rsp)
  70e608:	movaps %xmm0,0x8f0(%rsp)
  70e610:	cmp    $0xffffffff,%ebp
  70e613:	jne    70e568 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x9e8>
  70e619:	mov    $0x2,%al
  70e61b:	mov    0x6a0(%r14),%r8
  70e622:	test   %r8,%r8
  70e625:	jne    70e6e1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xb61>
  70e62b:	jmp    70e770 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xbf0>
  70e630:	mov    0x220(%r14),%r13
  70e637:	cmp    %rbp,%r13
  70e63a:	jbe    71274c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4bcc>
  70e640:	mov    0x210(%r14),%r13
  70e647:	mov    0x218(%r14),%rax
  70e64e:	movzbl (%rax,%rbp,1),%ebp
  70e652:	cmp    %rbp,%r13
  70e655:	jbe    712799 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c19>
  70e65b:	imul   $0x58,%rbp,%rax
  70e65f:	add    0x208(%r14),%rax
  70e666:	mov    0x50(%rax),%rcx
  70e66a:	mov    %rcx,0x500(%rsp)
  70e672:	movups 0x40(%rax),%xmm0
  70e676:	movaps %xmm0,0x4f0(%rsp)
  70e67e:	movups (%rax),%xmm0
  70e681:	movups 0x10(%rax),%xmm1
  70e685:	movups 0x20(%rax),%xmm2
  70e689:	movupd 0x30(%rax),%xmm3
  70e68e:	movapd %xmm3,0x4e0(%rsp)
  70e697:	movaps %xmm2,0x4d0(%rsp)
  70e69f:	movaps %xmm1,0x4c0(%rsp)
  70e6a7:	movaps %xmm0,0x4b0(%rsp)
  70e6af:	jmp    70e6c9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xb49>
  70e6b1:	mov    0x208(%r14),%rsi
  70e6b8:	lea    0x4b0(%rsp),%rdi
  70e6c0:	mov    %rbp,%rdx
  70e6c3:	call   *0x333d1f(%rip)        # a423e8 <_DYNAMIC+0x3f8>
  70e6c9:	movzbl 0x504(%rsp),%eax
  70e6d1:	mov    0x6a0(%r14),%r8
  70e6d8:	test   %r8,%r8
  70e6db:	je     70e770 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xbf0>
  70e6e1:	mov    (%r12),%rcx
  70e6e5:	mov    0x6a8(%r14),%rdx
  70e6ec:	movzwl 0x1c2(%r8),%edi
  70e6f4:	mov    %edi,%r10d
  70e6f7:	shl    $0x5,%r10d
  70e6fb:	mov    $0xffffffffffffffff,%rsi
  70e702:	xor    %r9d,%r9d
  70e705:	data16 cs nopw 0x0(%rax,%rax,1)
  70e710:	mov    %r10,%r11
  70e713:	add    %r9,%r11
  70e716:	je     70e740 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xbc0>
  70e718:	cmp    0x170(%r8,%rsi,8),%rcx
  70e720:	seta   %r11b
  70e724:	sbb    $0x0,%r11b
  70e728:	add    $0xffffffffffffffe0,%r9
  70e72c:	inc    %rsi
  70e72f:	cmp    $0x1,%r11b
  70e733:	je     70e710 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xb90>
  70e735:	movzbl %r11b,%edi
  70e739:	test   %edi,%edi
  70e73b:	jne    70e743 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xbc3>
  70e73d:	jmp    70e760 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xbe0>
  70e73f:	nop
  70e740:	mov    %rdi,%rsi
  70e743:	sub    $0x1,%rdx
  70e747:	jb     70e770 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xbf0>
  70e749:	mov    0x1c8(%r8,%rsi,8),%r8
  70e751:	jmp    70e6ec <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xb6c>
  70e753:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  70e760:	sub    %r9,%r8
  70e763:	add    $0xffffffffffffffe0,%r8
  70e767:	jmp    70e773 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xbf3>
  70e769:	nopl   0x0(%rax)
  70e770:	xor    %r8d,%r8d
  70e773:	movzbl %r15b,%esi
  70e777:	movzbl %al,%ecx
  70e77a:	lea    0x4b0(%rsp),%rdi
  70e782:	lea    0x8f0(%rsp),%rdx
  70e78a:	call   *0x333f88(%rip)        # a42718 <_DYNAMIC+0x728>
  70e790:	lea    0x780(%rsp),%rdi
  70e798:	mov    0x68(%rsp),%rsi
  70e79d:	lea    0xbd0(%rsp),%rdx
  70e7a5:	xor    %ecx,%ecx
  70e7a7:	lea    0x4b0(%rsp),%r8
  70e7af:	call   *0x333f6b(%rip)        # a42720 <_DYNAMIC+0x730>
  70e7b5:	cmpb   $0x0,0x780(%rsp)
  70e7bd:	jne    70f372 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x17f2>
  70e7c3:	lea    0x788(%rsp),%rax
  70e7cb:	movups (%rax),%xmm0
  70e7ce:	lea    0xc6(%rsp),%rax
  70e7d6:	movups %xmm0,(%rax)
  70e7d9:	movups (%rax),%xmm0
  70e7dc:	movaps %xmm0,0x8d0(%rsp)
  70e7e4:	mov    0x20(%r12),%ecx
  70e7e9:	mov    %ecx,%eax
  70e7eb:	and    $0xf,%eax
  70e7ee:	cmp    $0x9,%eax
  70e7f1:	ja     712522 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x49a2>
  70e7f7:	cmp    $0x6,%eax
  70e7fa:	mov    0x38(%rsp),%r14
  70e7ff:	je     70e811 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xc91>
  70e801:	cmp    $0x10,%ecx
  70e804:	setae  %cl
  70e807:	cmp    $0x6,%eax
  70e80a:	sete   %al
  70e80d:	or     %cl,%al
  70e80f:	je     70e843 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xcc3>
  70e811:	movaps 0x8d0(%rsp),%xmm0
  70e819:	movaps %xmm0,0x4b0(%rsp)
  70e821:	mov    0x68(%rsp),%rdi
  70e826:	lea    0x4b0(%rsp),%rsi
  70e82e:	mov    0x333ef3(%rip),%rdx        # a42728 <_DYNAMIC+0x738>
  70e835:	call   *0x333ef5(%rip)        # a42730 <_DYNAMIC+0x740>
  70e83b:	test   $0x1,%al
  70e83d:	jne    70f361 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x17e1>
  70e843:	mov    0x5d8(%r14),%r13
  70e84a:	cmp    0x5c8(%r14),%r13
  70e851:	jne    70e3b0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x830>
  70e857:	mov    0x70(%rsp),%rdi
  70e85c:	call   6f4430 <<alloc::raw_vec::RawVec<[core::option::Option<gpui::source::FieldId>; 2]>>::grow_one>
  70e861:	jmp    70e3b0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x830>
  70e866:	mov    0x38(%rsp),%r14
  70e86b:	mov    0x6b8(%r14),%rax
  70e872:	mov    0x6c8(%r14),%rdi
  70e879:	test   %rax,%rax
  70e87c:	setne  %cl
  70e87f:	test   %rdi,%rdi
  70e882:	setne  %dl
  70e885:	and    %cl,%dl
  70e887:	cmp    $0x1,%dl
  70e88a:	jne    70ee4b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x12cb>
  70e890:	mov    0x6c0(%r14),%rbx
  70e897:	lea    0x1e8(%r14),%rcx
  70e89e:	mov    %rcx,0x2b0(%rsp)
  70e8a6:	xor    %r12d,%r12d
  70e8a9:	lea    0x314e00(%rip),%rcx        # a236b0 <__frame_dummy_init_array_entry+0x1bc0>
  70e8b0:	mov    %rcx,0x48(%rsp)
  70e8b5:	data16 cs nopw 0x0(%rax,%rax,1)
  70e8c0:	test   %r12,%r12
  70e8c3:	je     70e8dc <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xd5c>
  70e8c5:	movzwl 0x62(%r12),%ecx
  70e8cb:	cmp    %rcx,%rbx
  70e8ce:	jae    70e960 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xde0>
  70e8d4:	mov    %r12,%r15
  70e8d7:	jmp    70e980 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xe00>
  70e8dc:	test   %rbx,%rbx
  70e8df:	je     70e90b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xd8b>
  70e8e1:	mov    %rbx,%rcx
  70e8e4:	mov    %rax,%r12
  70e8e7:	and    $0x7,%rcx
  70e8eb:	je     70e910 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xd90>
  70e8ed:	xor    %edx,%edx
  70e8ef:	nop
  70e8f0:	mov    0x68(%r12),%r12
  70e8f5:	inc    %rdx
  70e8f8:	cmp    %rdx,%rcx
  70e8fb:	jne    70e8f0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xd70>
  70e8fd:	mov    %rbx,%rax
  70e900:	sub    %rdx,%rax
  70e903:	cmp    $0x8,%rbx
  70e907:	jae    70e920 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xda0>
  70e909:	jmp    70e947 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xdc7>
  70e90b:	mov    %rax,%r12
  70e90e:	jmp    70e947 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xdc7>
  70e910:	mov    %rbx,%rax
  70e913:	cmp    $0x8,%rbx
  70e917:	jb     70e947 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xdc7>
  70e919:	nopl   0x0(%rax)
  70e920:	mov    0x68(%r12),%rcx
  70e925:	mov    0x68(%rcx),%rcx
  70e929:	mov    0x68(%rcx),%rcx
  70e92d:	mov    0x68(%rcx),%rcx
  70e931:	mov    0x68(%rcx),%rcx
  70e935:	mov    0x68(%rcx),%rcx
  70e939:	mov    0x68(%rcx),%rcx
  70e93d:	mov    0x68(%rcx),%r12
  70e941:	add    $0xfffffffffffffff8,%rax
  70e945:	jne    70e920 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xda0>
  70e947:	xor    %eax,%eax
  70e949:	xor    %ebx,%ebx
  70e94b:	movzwl 0x62(%r12),%ecx
  70e951:	cmp    %rcx,%rbx
  70e954:	jb     70e8d4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xd54>
  70e95a:	nopw   0x0(%rax,%rax,1)
  70e960:	mov    (%r12),%r15
  70e964:	test   %r15,%r15
  70e967:	je     7125b2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4a32>
  70e96d:	inc    %rax
  70e970:	movzwl 0x60(%r12),%ebx
  70e976:	mov    %r15,%r12
  70e979:	cmp    0x62(%r15),%bx
  70e97e:	jae    70e960 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xde0>
  70e980:	test   %rax,%rax
  70e983:	mov    %rdi,0x70(%rsp)
  70e988:	je     70ea08 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xe88>
  70e98a:	lea    (%r15,%rbx,8),%rcx
  70e98e:	add    $0x70,%rcx
  70e992:	mov    %rax,%rdx
  70e995:	and    $0x7,%rdx
  70e999:	je     70ec66 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x10e6>
  70e99f:	xor    %esi,%esi
  70e9a1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  70e9b0:	mov    (%rcx),%r12
  70e9b3:	lea    0x68(%r12),%rcx
  70e9b8:	inc    %rsi
  70e9bb:	cmp    %rsi,%rdx
  70e9be:	jne    70e9b0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xe30>
  70e9c0:	mov    %rax,%rdx
  70e9c3:	sub    %rsi,%rdx
  70e9c6:	cmp    $0x8,%rax
  70e9ca:	jb     70e9fa <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xe7a>
  70e9cc:	nopl   0x0(%rax)
  70e9d0:	mov    (%rcx),%rax
  70e9d3:	mov    0x68(%rax),%rax
  70e9d7:	mov    0x68(%rax),%rax
  70e9db:	mov    0x68(%rax),%rax
  70e9df:	mov    0x68(%rax),%rax
  70e9e3:	mov    0x68(%rax),%rax
  70e9e7:	mov    0x68(%rax),%rax
  70e9eb:	mov    0x68(%rax),%r12
  70e9ef:	lea    0x68(%r12),%rcx
  70e9f4:	add    $0xfffffffffffffff8,%rdx
  70e9f8:	jne    70e9d0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xe50>
  70e9fa:	movq   $0x0,0x110(%rsp)
  70ea06:	jmp    70ea17 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xe97>
  70ea08:	lea    0x1(%rbx),%rax
  70ea0c:	mov    %rax,0x110(%rsp)
  70ea14:	mov    %r15,%r12
  70ea17:	mov    0x8(%r15,%rbx,8),%rsi
  70ea1c:	mov    0x2b0(%rsp),%rdi
  70ea24:	call   6f7cf0 <<gpui::runtime::identity_index::IdentityIndex>::required>
  70ea29:	mov    %rax,%rbp
  70ea2c:	mov    0x38(%rsp),%rdx
  70ea31:	mov    0x5d8(%rdx),%r13
  70ea38:	cmp    %r13,%rax
  70ea3b:	jae    7127a5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c25>
  70ea41:	mov    0x5d0(%rdx),%rax
  70ea48:	mov    %rbp,%rcx
  70ea4b:	shl    $0x4,%rcx
  70ea4f:	movups (%rax,%rcx,1),%xmm0
  70ea53:	movaps %xmm0,0xc0(%rsp)
  70ea5b:	mov    0x310(%rdx),%r13
  70ea62:	cmp    %r13,%rbp
  70ea65:	jae    712711 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b91>
  70ea6b:	mov    0x308(%rdx),%rax
  70ea72:	lea    0x0(,%rbp,4),%r14
  70ea7a:	add    %rbp,%r14
  70ea7d:	mov    0x20(%rax,%r14,8),%eax
  70ea82:	and    $0xf,%eax
  70ea85:	cmp    $0xa,%eax
  70ea88:	jae    712522 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x49a2>
  70ea8e:	lea    -0x6bde43(%rip),%rcx        # 50c52 <GCC_except_table0+0x10eae>
  70ea95:	movzbl (%rax,%rcx,1),%eax
  70ea99:	mov    %al,0x50(%rsp)
  70ea9d:	mov    0x38(%rsp),%rdx
  70eaa2:	mov    0x200(%rdx),%rax
  70eaa9:	lea    -0x6ccdf4(%rip),%rcx        # 41cbc <GCC_except_table0+0x1f18>
  70eab0:	movslq (%rcx,%rax,4),%rax
  70eab4:	add    %rcx,%rax
  70eab7:	jmp    *%rax
  70eab9:	movups -0x6c1950(%rip),%xmm0        # 4d170 <GCC_except_table0+0xd3cc>
  70eac0:	movaps %xmm0,0x930(%rsp)
  70eac8:	movups -0x6c196f(%rip),%xmm0        # 4d160 <GCC_except_table0+0xd3bc>
  70eacf:	movaps %xmm0,0x920(%rsp)
  70ead7:	movups -0x6c198e(%rip),%xmm0        # 4d150 <GCC_except_table0+0xd3ac>
  70eade:	movaps %xmm0,0x910(%rsp)
  70eae6:	movups -0x6c19ad(%rip),%xmm0        # 4d140 <GCC_except_table0+0xd39c>
  70eaed:	movaps %xmm0,0x900(%rsp)
  70eaf5:	movups -0x6c19cc(%rip),%xmm0        # 4d130 <GCC_except_table0+0xd38c>
  70eafc:	movaps %xmm0,0x8f0(%rsp)
  70eb04:	movabs $0x3000100000000,%rax
  70eb0e:	mov    %rax,0x940(%rsp)
  70eb16:	jmp    70ebe3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1063>
  70eb1b:	mov    0x220(%rdx),%rax
  70eb22:	cmp    %rax,%rbp
  70eb25:	jae    712787 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c07>
  70eb2b:	mov    0x210(%rdx),%rax
  70eb32:	mov    0x218(%rdx),%rcx
  70eb39:	movzbl (%rcx,%rbp,1),%ecx
  70eb3d:	cmp    %rcx,%rax
  70eb40:	jbe    712793 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c13>
  70eb46:	mov    0x208(%rdx),%rax
  70eb4d:	imul   $0x58,%rcx,%rcx
  70eb51:	jmp    70eb94 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1014>
  70eb53:	mov    0x208(%rdx),%rsi
  70eb5a:	lea    0x8f0(%rsp),%rdi
  70eb62:	mov    %rbp,%rdx
  70eb65:	call   *0x33387d(%rip)        # a423e8 <_DYNAMIC+0x3f8>
  70eb6b:	mov    0x38(%rsp),%rax
  70eb70:	mov    0x310(%rax),%r13
  70eb77:	jmp    70ebe3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1063>
  70eb79:	mov    0x218(%rdx),%rax
  70eb80:	cmp    %rax,%rbp
  70eb83:	jae    71277b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4bfb>
  70eb89:	mov    0x210(%rdx),%rax
  70eb90:	imul   $0x58,%rbp,%rcx
  70eb94:	mov    0x50(%rax,%rcx,1),%rdx
  70eb99:	mov    %rdx,0x940(%rsp)
  70eba1:	movups 0x40(%rax,%rcx,1),%xmm0
  70eba6:	movaps %xmm0,0x930(%rsp)
  70ebae:	movups (%rax,%rcx,1),%xmm0
  70ebb2:	movups 0x10(%rax,%rcx,1),%xmm1
  70ebb7:	movups 0x20(%rax,%rcx,1),%xmm2
  70ebbc:	movupd 0x30(%rax,%rcx,1),%xmm3
  70ebc2:	movapd %xmm3,0x920(%rsp)
  70ebcb:	movaps %xmm2,0x910(%rsp)
  70ebd3:	movaps %xmm1,0x900(%rsp)
  70ebdb:	movaps %xmm0,0x8f0(%rsp)
  70ebe3:	cmp    %r13,%rbp
  70ebe6:	jae    71271d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b9d>
  70ebec:	mov    0x38(%rsp),%rdx
  70ebf1:	mov    0x308(%rdx),%rax
  70ebf8:	mov    0x18(%rax,%r14,8),%ebp
  70ebfd:	mov    $0xffffffff,%eax
  70ec02:	cmp    %rax,%rbp
  70ec05:	je     70ec42 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x10c2>
  70ec07:	mov    0x200(%rdx),%rax
  70ec0e:	lea    -0x6ccf49(%rip),%rsi        # 41ccc <GCC_except_table0+0x1f28>
  70ec15:	movslq (%rsi,%rax,4),%rcx
  70ec19:	add    %rsi,%rcx
  70ec1c:	lea    -0x6c1af3(%rip),%rax        # 4d130 <GCC_except_table0+0xd38c>
  70ec23:	jmp    *%rcx
  70ec25:	mov    0x218(%rdx),%r13
  70ec2c:	cmp    %rbp,%r13
  70ec2f:	jbe    712755 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4bd5>
  70ec35:	imul   $0x58,%rbp,%rax
  70ec39:	add    0x210(%rdx),%rax
  70ec40:	jmp    70ecae <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x112e>
  70ec42:	mov    $0x2,%al
  70ec44:	mov    0x38(%rsp),%rdx
  70ec49:	mov    0x6a0(%rdx),%r8
  70ec50:	test   %r8,%r8
  70ec53:	jne    70ed2e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x11ae>
  70ec59:	xor    %r8d,%r8d
  70ec5c:	movzbl 0x50(%rsp),%ebx
  70ec61:	jmp    70edb7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1237>
  70ec66:	mov    %rax,%rdx
  70ec69:	cmp    $0x8,%rax
  70ec6d:	jae    70e9d0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xe50>
  70ec73:	jmp    70e9fa <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xe7a>
  70ec78:	mov    0x220(%rdx),%r13
  70ec7f:	cmp    %rbp,%r13
  70ec82:	jbe    71274c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4bcc>
  70ec88:	mov    0x210(%rdx),%r13
  70ec8f:	mov    0x218(%rdx),%rax
  70ec96:	movzbl (%rax,%rbp,1),%ebp
  70ec9a:	cmp    %rbp,%r13
  70ec9d:	jbe    712799 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c19>
  70eca3:	imul   $0x58,%rbp,%rax
  70eca7:	add    0x208(%rdx),%rax
  70ecae:	mov    0x50(%rax),%rcx
  70ecb2:	mov    %rcx,0x500(%rsp)
  70ecba:	movups 0x40(%rax),%xmm0
  70ecbe:	movaps %xmm0,0x4f0(%rsp)
  70ecc6:	movups (%rax),%xmm0
  70ecc9:	movups 0x10(%rax),%xmm1
  70eccd:	movups 0x20(%rax),%xmm2
  70ecd1:	movupd 0x30(%rax),%xmm3
  70ecd6:	movapd %xmm3,0x4e0(%rsp)
  70ecdf:	movaps %xmm2,0x4d0(%rsp)
  70ece7:	movaps %xmm1,0x4c0(%rsp)
  70ecef:	movaps %xmm0,0x4b0(%rsp)
  70ecf7:	jmp    70ed11 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1191>
  70ecf9:	mov    0x208(%rdx),%rsi
  70ed00:	lea    0x4b0(%rsp),%rdi
  70ed08:	mov    %rbp,%rdx
  70ed0b:	call   *0x3336d7(%rip)        # a423e8 <_DYNAMIC+0x3f8>
  70ed11:	movzbl 0x504(%rsp),%eax
  70ed19:	mov    0x38(%rsp),%rdx
  70ed1e:	mov    0x6a0(%rdx),%r8
  70ed25:	test   %r8,%r8
  70ed28:	je     70ec59 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x10d9>
  70ed2e:	mov    0x8(%r15,%rbx,8),%rcx
  70ed33:	mov    0x6a8(%rdx),%rdx
  70ed3a:	movzbl 0x50(%rsp),%ebx
  70ed3f:	movzwl 0x1c2(%r8),%edi
  70ed47:	mov    %edi,%r10d
  70ed4a:	shl    $0x5,%r10d
  70ed4e:	mov    $0xffffffffffffffff,%rsi
  70ed55:	xor    %r9d,%r9d
  70ed58:	nopl   0x0(%rax,%rax,1)
  70ed60:	mov    %r10,%r11
  70ed63:	add    %r9,%r11
  70ed66:	je     70ed90 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1210>
  70ed68:	cmp    0x170(%r8,%rsi,8),%rcx
  70ed70:	seta   %r11b
  70ed74:	sbb    $0x0,%r11b
  70ed78:	add    $0xffffffffffffffe0,%r9
  70ed7c:	inc    %rsi
  70ed7f:	cmp    $0x1,%r11b
  70ed83:	je     70ed60 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x11e0>
  70ed85:	movzbl %r11b,%edi
  70ed89:	test   %edi,%edi
  70ed8b:	jne    70ed93 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1213>
  70ed8d:	jmp    70edb0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1230>
  70ed8f:	nop
  70ed90:	mov    %rdi,%rsi
  70ed93:	sub    $0x1,%rdx
  70ed97:	jb     70ee43 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x12c3>
  70ed9d:	mov    0x1c8(%r8,%rsi,8),%r8
  70eda5:	jmp    70ed3f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x11bf>
  70eda7:	nopw   0x0(%rax,%rax,1)
  70edb0:	sub    %r9,%r8
  70edb3:	add    $0xffffffffffffffe0,%r8
  70edb7:	movzbl %bl,%esi
  70edba:	movzbl %al,%ecx
  70edbd:	lea    0x4b0(%rsp),%rdi
  70edc5:	lea    0x8f0(%rsp),%rdx
  70edcd:	call   *0x333945(%rip)        # a42718 <_DYNAMIC+0x728>
  70edd3:	movaps 0xc0(%rsp),%xmm0
  70eddb:	movaps %xmm0,0x780(%rsp)
  70ede3:	mov    0x68(%rsp),%rdi
  70ede8:	lea    0x780(%rsp),%rsi
  70edf0:	lea    0x4b0(%rsp),%rdx
  70edf8:	call   *0x33393a(%rip)        # a42738 <_DYNAMIC+0x748>
  70edfe:	test   $0x1,%al
  70ee00:	jne    70f361 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x17e1>
  70ee06:	mov    0x68(%rsp),%rdi
  70ee0b:	lea    0xc0(%rsp),%rsi
  70ee13:	call   *0x333887(%rip)        # a426a0 <_DYNAMIC+0x6b0>
  70ee19:	cmp    $0xff,%al
  70ee1b:	jne    70f37a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x17fa>
  70ee21:	mov    $0x0,%eax
  70ee26:	mov    0x70(%rsp),%rdi
  70ee2b:	dec    %rdi
  70ee2e:	mov    0x38(%rsp),%r14
  70ee33:	mov    0x110(%rsp),%rbx
  70ee3b:	jne    70e8c0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xd40>
  70ee41:	jmp    70ee4b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x12cb>
  70ee43:	xor    %r8d,%r8d
  70ee46:	jmp    70edb7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1237>
  70ee4b:	lea    0x318(%r14),%rax
  70ee52:	mov    %r14,%rsi
  70ee55:	mov    0x588(%r14),%r14
  70ee5c:	mov    0x5a8(%rsi),%rbx
  70ee63:	lea    0x5c8(%rsi),%rcx
  70ee6a:	movq   $0xfffffffffffffffe,0x748(%rsp)
  70ee76:	lea    0x300(%rsi),%rdx
  70ee7d:	lea    0x200(%rsi),%r13
  70ee84:	lea    0x630(%rsi),%r15
  70ee8b:	mov    %rcx,0xb58(%rsp)
  70ee93:	mov    %rdx,0xb60(%rsp)
  70ee9b:	mov    %r15,0xb68(%rsp)
  70eea3:	lea    0x1c8(%rsp),%rcx
  70eeab:	mov    %rcx,0xb70(%rsp)
  70eeb3:	mov    %rax,0xb78(%rsp)
  70eebb:	mov    %r13,0xb80(%rsp)
  70eec3:	lea    0x748(%rsp),%rax
  70eecb:	mov    %rax,0xb88(%rsp)
  70eed3:	cmpq   $0x0,0x5d8(%rsi)
  70eedb:	je     7127bb <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c3b>
  70eee1:	mov    0x5d0(%rsi),%rax
  70eee8:	movupd (%rax),%xmm0
  70eeec:	movapd %xmm0,0x8f0(%rsp)
  70eef5:	xorpd  %xmm0,%xmm0
  70eef9:	movapd 0x80(%rsp),%xmm1
  70ef02:	unpcklps %xmm0,%xmm1
  70ef05:	movapd -0x6cdfad(%rip),%xmm0        # 40f60 <GCC_except_table0+0x11bc>
  70ef0d:	orpd   %xmm0,%xmm1
  70ef11:	subpd  %xmm0,%xmm1
  70ef15:	cvtpd2ps %xmm1,%xmm1
  70ef19:	movapd %xmm1,%xmm0
  70ef1d:	shufps $0x55,%xmm1,%xmm0
  70ef21:	movaps %xmm1,0x70(%rsp)
  70ef26:	movss  0x9c(%rsp),%xmm2
  70ef2f:	divss  %xmm2,%xmm1
  70ef33:	divss  %xmm2,%xmm0
  70ef37:	movl   $0x0,0x4b0(%rsp)
  70ef42:	movss  %xmm1,0x4b4(%rsp)
  70ef4b:	movl   $0x0,0x4b8(%rsp)
  70ef56:	movss  %xmm0,0x4bc(%rsp)
  70ef5f:	mov    $0x1,%r12b
  70ef62:	lea    0x314b6f(%rip),%r8        # a23ad8 <__frame_dummy_init_array_entry+0x1fe8>
  70ef69:	lea    0x8f0(%rsp),%rsi
  70ef71:	lea    0x4b0(%rsp),%rdx
  70ef79:	lea    0xb58(%rsp),%rcx
  70ef81:	mov    $0x1,%bpl
  70ef84:	mov    0x68(%rsp),%rdi
  70ef89:	call   *0x3337b1(%rip)        # a42740 <_DYNAMIC+0x750>
  70ef8f:	test   $0x1,%al
  70ef91:	je     70eff9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1479>
  70ef93:	mov    0x40(%rsp),%rax
  70ef98:	movq   $0x22,(%rax)
  70ef9f:	mov    %dl,0x8(%rax)
  70efa2:	mov    0x748(%rsp),%rax
  70efaa:	mov    $0x1,%r12b
  70efad:	mov    $0x1,%bpl
  70efb0:	cmp    $0xfffffffffffffffe,%rax
  70efb4:	je     70f38f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x180f>
  70efba:	sub    $0xd,%rax
  70efbe:	mov    $0x14,%ecx
  70efc3:	cmovge %rax,%rcx
  70efc7:	cmp    $0x14,%rcx
  70efcb:	je     70f441 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x18c1>
  70efd1:	cmp    $0x19,%rcx
  70efd5:	jne    70f38f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x180f>
  70efdb:	mov    0x750(%rsp),%rsi
  70efe3:	test   %rsi,%rsi
  70efe6:	je     70f38f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x180f>
  70efec:	lea    0x758(%rsp),%rax
  70eff4:	jmp    70f45a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x18da>
  70eff9:	mov    0x38(%rsp),%rsi
  70effe:	mov    0x588(%rsi),%rax
  70f005:	sub    %r14,%rax
  70f008:	mov    0x5a8(%rsi),%rcx
  70f00f:	add    %rax,0x748(%rsi)
  70f016:	sub    %rbx,%rcx
  70f019:	add    %rcx,0x750(%rsi)
  70f020:	cmpl   $0xfffffffe,0x748(%rsp)
  70f028:	jne    70f32b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x17ab>
  70f02e:	lea    0x4b0(%rsp),%rdi
  70f036:	mov    $0x1,%bpl
  70f039:	mov    $0x1,%edx
  70f03e:	call   6f3200 <<gpui::runtime::Runtime<text_column_public_control::Model>>::refresh_inspector>
  70f043:	cmpl   $0xfffffffe,0x4b0(%rsp)
  70f04b:	jne    70f408 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1888>
  70f051:	mov    0x38(%rsp),%r14
  70f056:	mov    0x310(%r14),%rsi
  70f05d:	lea    0x4b0(%rsp),%rdi
  70f065:	mov    $0x8,%ecx
  70f06a:	mov    $0x40,%r8d
  70f070:	xor    %edx,%edx
  70f072:	call   6f4b00 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  70f077:	mov    0x4b8(%rsp),%rdi
  70f07f:	cmpl   $0x1,0x4b0(%rsp)
  70f087:	je     7125e4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4a64>
  70f08d:	mov    0x4c0(%rsp),%rax
  70f095:	mov    %rdi,0x1d8(%rsp)
  70f09d:	mov    %rax,0x1e0(%rsp)
  70f0a5:	movq   $0x0,0x1e8(%rsp)
  70f0b1:	movq   $0x0,0x2d0(%rsp)
  70f0bd:	movq   $0x4,0x2d8(%rsp)
  70f0c9:	movq   $0x0,0x2e0(%rsp)
  70f0d5:	mov    0x310(%r14),%rsi
  70f0dc:	lea    0x4b0(%rsp),%rdi
  70f0e4:	mov    $0x8,%ecx
  70f0e9:	mov    $0x38,%r8d
  70f0ef:	xor    %edx,%edx
  70f0f1:	call   6f4b00 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  70f0f6:	mov    0x4b8(%rsp),%rdi
  70f0fe:	cmpb   $0x0,0x4b0(%rsp)
  70f106:	jne    7125fa <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4a7a>
  70f10c:	mov    0x4c0(%rsp),%rax
  70f114:	mov    %rdi,0x1f8(%rsp)
  70f11c:	mov    %rax,0x200(%rsp)
  70f124:	movq   $0x0,0x208(%rsp)
  70f130:	mov    0x698(%r14),%rbx
  70f137:	test   %rbx,%rbx
  70f13a:	setne  0x37(%rsp)
  70f13f:	je     70f148 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x15c8>
  70f141:	mov    0x310(%r14),%rbx
  70f148:	lea    0x4b0(%rsp),%rdi
  70f150:	mov    $0x4,%ecx
  70f155:	mov    $0x10,%r8d
  70f15b:	mov    %rbx,%rsi
  70f15e:	xor    %edx,%edx
  70f160:	call   6f4b00 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  70f165:	mov    0x4b8(%rsp),%rdi
  70f16d:	cmpb   $0x0,0x4b0(%rsp)
  70f175:	jne    71260d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4a8d>
  70f17b:	mov    0x4c0(%rsp),%rax
  70f183:	mov    %rdi,0x220(%rsp)
  70f18b:	mov    %rax,0x228(%rsp)
  70f193:	movq   $0x0,0x230(%rsp)
  70f19f:	lea    0x4b0(%rsp),%rdi
  70f1a7:	mov    $0x4,%ecx
  70f1ac:	mov    $0x10,%r8d
  70f1b2:	mov    %rbx,%rsi
  70f1b5:	xor    %edx,%edx
  70f1b7:	call   6f4b00 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  70f1bc:	mov    0x4b8(%rsp),%rdi
  70f1c4:	cmpb   $0x0,0x4b0(%rsp)
  70f1cc:	jne    712620 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4aa0>
  70f1d2:	mov    0x4c0(%rsp),%rax
  70f1da:	mov    %rdi,0x238(%rsp)
  70f1e2:	mov    %rax,0x240(%rsp)
  70f1ea:	movq   $0x0,0x248(%rsp)
  70f1f6:	lea    0x4b0(%rsp),%rdi
  70f1fe:	mov    $0x1,%ecx
  70f203:	mov    $0x1,%r8d
  70f209:	mov    %rbx,%rsi
  70f20c:	xor    %edx,%edx
  70f20e:	call   6f4b00 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  70f213:	mov    0x4b8(%rsp),%rdi
  70f21b:	cmpb   $0x0,0x4b0(%rsp)
  70f223:	jne    712633 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4ab3>
  70f229:	mov    0x4c0(%rsp),%rax
  70f231:	mov    %rdi,0x198(%rsp)
  70f239:	mov    %rax,0x1a0(%rsp)
  70f241:	movq   $0x0,0x1a8(%rsp)
  70f24d:	lea    0x4b0(%rsp),%rdi
  70f255:	mov    $0x4,%ecx
  70f25a:	mov    $0x4,%r8d
  70f260:	mov    %rbx,%rsi
  70f263:	xor    %edx,%edx
  70f265:	call   6f4b00 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  70f26a:	mov    0x4b8(%rsp),%rdi
  70f272:	cmpb   $0x0,0x4b0(%rsp)
  70f27a:	jne    712646 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4ac6>
  70f280:	mov    %r13,0x48(%rsp)
  70f285:	mov    %r15,0x280(%rsp)
  70f28d:	mov    0x4c0(%rsp),%rax
  70f295:	mov    %rdi,0x170(%rsp)
  70f29d:	mov    %rax,0x178(%rsp)
  70f2a5:	movq   $0x0,0x180(%rsp)
  70f2b1:	movq   $0x0,0x378(%rsp)
  70f2bd:	movq   $0x0,0x388(%rsp)
  70f2c9:	mov    0x680(%r14),%rcx
  70f2d0:	test   %rcx,%rcx
  70f2d3:	je     70f46d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x18ed>
  70f2d9:	mov    0x310(%r14),%rsi
  70f2e0:	mov    0x6b0(%r14),%rdx
  70f2e7:	mov    $0x1,%r12b
  70f2ea:	lea    0x780(%rsp),%rdi
  70f2f2:	mov    $0x1,%r13b
  70f2f5:	mov    $0x1,%bpl
  70f2f8:	call   6da240 <<gpui::runtime::Runtime<text_column_public_control::Input>>::metadata_sheet::{closure#0}>
  70f2fd:	jmp    70f479 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x18f9>
  70f302:	mov    0x40(%rsp),%rax
  70f307:	movq   $0x23,(%rax)
  70f30e:	mov    %r14d,0x8(%rax)
  70f312:	mov    %ebp,0xc(%rax)
  70f315:	mov    0xc10(%rsp),%rbx
  70f31d:	cmp    $0x2,%ebx
  70f320:	jne    70f3e9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1869>
  70f326:	jmp    70f3f6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1876>
  70f32b:	mov    0x778(%rsp),%rax
  70f333:	mov    0x40(%rsp),%rcx
  70f338:	mov    %rax,0x30(%rcx)
  70f33c:	movups 0x748(%rsp),%xmm0
  70f344:	movups 0x758(%rsp),%xmm1
  70f34c:	movups 0x768(%rsp),%xmm2
  70f354:	movups %xmm2,0x20(%rcx)
  70f358:	movups %xmm1,0x10(%rcx)
  70f35c:	movups %xmm0,(%rcx)
  70f35f:	jmp    70f389 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1809>
  70f361:	mov    0x40(%rsp),%rax
  70f366:	movq   $0x22,(%rax)
  70f36d:	mov    %dl,0x8(%rax)
  70f370:	jmp    70f389 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1809>
  70f372:	movzbl 0x781(%rsp),%eax
  70f37a:	mov    0x40(%rsp),%rcx
  70f37f:	movq   $0x22,(%rcx)
  70f386:	mov    %al,0x8(%rcx)
  70f389:	mov    $0x1,%r12b
  70f38c:	mov    $0x1,%bpl
  70f38f:	cmpq   $0x0,0x1c8(%rsp)
  70f398:	je     70f3a7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1827>
  70f39a:	mov    0x1d0(%rsp),%rdi
  70f3a2:	call   6c5a90 <core::ptr::drop_glue::<gpui_canvas::text::TextShaper>>
  70f3a7:	test   %r12b,%r12b
  70f3aa:	je     70f3b9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1839>
  70f3ac:	lea    0x288(%rsp),%rdi
  70f3b4:	call   6c1520 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  70f3b9:	mov    0x140(%rsp),%rax
  70f3c1:	test   %rax,%rax
  70f3c4:	je     70f3da <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x185a>
  70f3c6:	lock decq (%rax)
  70f3ca:	jne    70f3da <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x185a>
  70f3cc:	lea    0x140(%rsp),%rdi
  70f3d4:	call   *0x332f4e(%rip)        # a42328 <_DYNAMIC+0x338>
  70f3da:	cmpl   $0x2,0xc10(%rsp)
  70f3e2:	je     70f3f6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1876>
  70f3e4:	test   %bpl,%bpl
  70f3e7:	je     70f3f6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1876>
  70f3e9:	lea    0xc10(%rsp),%rdi
  70f3f1:	call   6c6030 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  70f3f6:	add    $0xdf8,%rsp
  70f3fd:	pop    %rbx
  70f3fe:	pop    %r12
  70f400:	pop    %r13
  70f402:	pop    %r14
  70f404:	pop    %r15
  70f406:	pop    %rbp
  70f407:	ret
  70f408:	mov    0x4e0(%rsp),%rax
  70f410:	mov    0x40(%rsp),%rcx
  70f415:	mov    %rax,0x30(%rcx)
  70f419:	movups 0x4b0(%rsp),%xmm0
  70f421:	movups 0x4c0(%rsp),%xmm1
  70f429:	movups 0x4d0(%rsp),%xmm2
  70f431:	movups %xmm2,0x20(%rcx)
  70f435:	movups %xmm1,0x10(%rcx)
  70f439:	movups %xmm0,(%rcx)
  70f43c:	jmp    70efa2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1422>
  70f441:	mov    0x760(%rsp),%rsi
  70f449:	test   %rsi,%rsi
  70f44c:	je     70f38f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x180f>
  70f452:	lea    0x768(%rsp),%rax
  70f45a:	mov    (%rax),%rdi
  70f45d:	mov    $0x1,%edx
  70f462:	call   *0x332df0(%rip)        # a42258 <_DYNAMIC+0x268>
  70f468:	jmp    70f38f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x180f>
  70f46d:	movq   $0xffffffffffffffff,0x780(%rsp)
  70f479:	mov    0x280(%rsp),%rax
  70f481:	mov    (%rax),%rsi
  70f484:	test   %rsi,%rsi
  70f487:	je     70f551 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x19d1>
  70f48d:	mov    $0x1,%r12b
  70f490:	lea    0x4b0(%rsp),%rdi
  70f498:	mov    $0x1,%al
  70f49a:	mov    %eax,0x50(%rsp)
  70f49e:	mov    $0x1,%r15b
  70f4a1:	mov    $0x1,%bpl
  70f4a4:	call   *0x33329e(%rip)        # a42748 <_DYNAMIC+0x758>
  70f4aa:	mov    0x48(%rsp),%rbx
  70f4af:	mov    0x4b0(%rsp),%rax
  70f4b7:	mov    0x4b8(%rsp),%rsi
  70f4bf:	movups 0x4c0(%rsp),%xmm0
  70f4c7:	movaps %xmm0,0xc0(%rsp)
  70f4cf:	movups 0x4d0(%rsp),%xmm1
  70f4d7:	movaps %xmm1,0x8f0(%rsp)
  70f4df:	mov    0x4e0(%rsp),%rcx
  70f4e7:	mov    %rcx,0x900(%rsp)
  70f4ef:	movaps %xmm0,0x470(%rsp)
  70f4f7:	cmp    $0xfffffffffffffffe,%rax
  70f4fb:	je     70f55d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x19dd>
  70f4fd:	mov    0x900(%rsp),%rcx
  70f505:	mov    0x40(%rsp),%rdx
  70f50a:	mov    %rcx,0x30(%rdx)
  70f50e:	movaps 0x8f0(%rsp),%xmm0
  70f516:	movups %xmm0,0x20(%rdx)
  70f51a:	movaps 0x470(%rsp),%xmm0
  70f522:	movaps %xmm0,0x3a0(%rsp)
  70f52a:	movups %xmm0,0x10(%rdx)
  70f52e:	mov    %rax,(%rdx)
  70f531:	mov    %rsi,0x8(%rdx)
  70f535:	mov    $0x1,%r12b
  70f538:	cmpl   $0xffffffff,0x780(%rsp)
  70f540:	mov    $0x1,%r13b
  70f543:	mov    $0x1,%bpl
  70f546:	jne    71240b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x488b>
  70f54c:	jmp    712418 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4898>
  70f551:	mov    $0xffffffffffffffff,%rsi
  70f558:	mov    0x48(%rsp),%rbx
  70f55d:	movaps 0x470(%rsp),%xmm0
  70f565:	movups %xmm0,0x830(%rsp)
  70f56d:	mov    %rsi,0x278(%rsp)
  70f575:	mov    %rsi,0x828(%rsp)
  70f57d:	cmpb   $0x0,0x37(%rsp)
  70f582:	je     70f61c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1a9c>
  70f588:	lea    0x4b0(%rsp),%rdi
  70f590:	lea    0x1f8(%rsp),%rdx
  70f598:	lea    0x170(%rsp),%rcx
  70f5a0:	mov    %r14,%rsi
  70f5a3:	call   6ca570 <gpui::runtime::scroll::geometry::<text_column_public_control::Model>>
  70f5a8:	mov    0x4b0(%rsp),%rax
  70f5b0:	movups 0x4b8(%rsp),%xmm0
  70f5b8:	movaps %xmm0,0x8f0(%rsp)
  70f5c0:	movups 0x4c8(%rsp),%xmm0
  70f5c8:	movaps %xmm0,0x900(%rsp)
  70f5d0:	movups 0x4d8(%rsp),%xmm0
  70f5d8:	movaps %xmm0,0x910(%rsp)
  70f5e0:	cmp    $0xfffffffffffffffe,%rax
  70f5e4:	jne    711475 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x38f5>
  70f5ea:	movaps 0x8f0(%rsp),%xmm0
  70f5f2:	movaps 0x900(%rsp),%xmm1
  70f5fa:	movaps 0x910(%rsp),%xmm2
  70f602:	movaps %xmm2,0x3c0(%rsp)
  70f60a:	movaps %xmm1,0x3b0(%rsp)
  70f612:	movaps %xmm0,0x3a0(%rsp)
  70f61a:	jmp    70f657 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1ad7>
  70f61c:	movq   $0x0,0x3a0(%rsp)
  70f628:	movq   $0x8,0x3a8(%rsp)
  70f634:	xorps  %xmm0,%xmm0
  70f637:	movups %xmm0,0x3b0(%rsp)
  70f63f:	movq   $0x8,0x3c0(%rsp)
  70f64b:	movq   $0x0,0x3c8(%rsp)
  70f657:	lea    0xbe8(%rsp),%rdi
  70f65f:	mov    %r14,%rsi
  70f662:	call   6f3050 <<gpui::runtime::Runtime<text_column_public_control::Model>>::inspector_display>
  70f667:	mov    %rbx,%rdi
  70f66a:	call   *0x3330e0(%rip)        # a42750 <_DYNAMIC+0x760>
  70f670:	movzbl 0xbe8(%rsp),%eax
  70f678:	mov    %al,0x9a(%rsp)
  70f67f:	cmpl   $0x2,0xc10(%rsp)
  70f687:	mov    0xbf0(%rsp),%rax
  70f68f:	mov    %rax,0x808(%rsp)
  70f697:	lea    0xc10(%rsp),%rsi
  70f69f:	cmove  %r14,%rsi
  70f6a3:	lea    0x8f0(%rsp),%rdi
  70f6ab:	call   *0x3330a7(%rip)        # a42758 <_DYNAMIC+0x768>
  70f6b1:	movups -0x6cf638(%rip),%xmm0        # 40080 <GCC_except_table0+0x2dc>
  70f6b8:	movaps %xmm0,0x4b0(%rsp)
  70f6c0:	lea    0x8f0(%rsp),%rdi
  70f6c8:	lea    0x4b0(%rsp),%rsi
  70f6d0:	call   *0x33308a(%rip)        # a42760 <_DYNAMIC+0x770>
  70f6d6:	incq   0x760(%r14)
  70f6dd:	lea    0x680(%r14),%rax
  70f6e4:	mov    %rax,0x138(%rsp)
  70f6ec:	mov    0x310(%r14),%rax
  70f6f3:	mov    %rax,0x7f8(%rsp)
  70f6fb:	test   %rax,%rax
  70f6fe:	je     7113ba <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x383a>
  70f704:	movss  0x9c(%rsp),%xmm0
  70f70d:	cvtss2sd %xmm0,%xmm0
  70f711:	movsd  %xmm0,0x7f0(%rsp)
  70f71a:	xorps  %xmm0,%xmm0
  70f71d:	unpcklpd 0x70(%rsp),%xmm0
  70f723:	movaps %xmm0,0x880(%rsp)
  70f72b:	xor    %eax,%eax
  70f72d:	movabs $0x8000000000000000,%rcx
  70f737:	inc    %rcx
  70f73a:	mov    %rcx,0x7e8(%rsp)
  70f742:	lea    0x31401f(%rip),%rcx        # a23768 <__frame_dummy_init_array_entry+0x1c78>
  70f749:	mov    %rcx,0x108(%rsp)
  70f751:	lea    0x312c48(%rip),%rcx        # a223a0 <__frame_dummy_init_array_entry+0x8b0>
  70f758:	mov    %rcx,0x348(%rsp)
  70f760:	lea    0x314091(%rip),%rcx        # a237f8 <__frame_dummy_init_array_entry+0x1d08>
  70f767:	mov    %rcx,0x268(%rsp)
  70f76f:	lea    -0x6bf4b5(%rip),%rcx        # 502c1 <GCC_except_table0+0x1051d>
  70f776:	mov    %rcx,0x270(%rsp)
  70f77e:	jmp    70f79b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1c1b>
  70f780:	mov    0x810(%rsp),%rax
  70f788:	cmp    0x7f8(%rsp),%rax
  70f790:	mov    0x38(%rsp),%r14
  70f795:	je     7113ba <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x383a>
  70f79b:	mov    %rax,%rcx
  70f79e:	cmp    0x808(%rsp),%rax
  70f7a6:	sete   %al
  70f7a9:	test   %al,0x9a(%rsp)
  70f7b0:	mov    %rcx,0x80(%rsp)
  70f7b8:	je     70f82e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1cae>
  70f7ba:	mov    0x1e0(%rsp),%rdx
  70f7c2:	mov    0x1e8(%rsp),%rcx
  70f7ca:	mov    0x2d8(%rsp),%r8
  70f7d2:	mov    0x2e0(%rsp),%r9
  70f7da:	movups 0x320(%r14),%xmm0
  70f7e2:	movups 0x5d0(%r14),%xmm1
  70f7ea:	movups %xmm1,0x18(%rsp)
  70f7ef:	mov    0x68(%rsp),%rax
  70f7f4:	mov    %rax,0x10(%rsp)
  70f7f9:	movups %xmm0,(%rsp)
  70f7fd:	lea    0x4b0(%rsp),%rdi
  70f805:	lea    0xbf0(%rsp),%rsi
  70f80d:	call   *0x332f55(%rip)        # a42768 <_DYNAMIC+0x778>
  70f813:	cmpl   $0xfffffffe,0x4b0(%rsp)
  70f81b:	jne    7121d4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4654>
  70f821:	mov    0x38(%rsp),%r14
  70f826:	mov    0x80(%rsp),%rcx
  70f82e:	mov    0x5d8(%r14),%rax
  70f835:	cmp    %rax,%rcx
  70f838:	jae    7128c7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d47>
  70f83e:	mov    0x5d0(%r14),%rax
  70f845:	shl    $0x4,%rcx
  70f849:	movups (%rax,%rcx,1),%xmm0
  70f84d:	movaps %xmm0,0xc0(%rsp)
  70f855:	lea    0x4b0(%rsp),%rdi
  70f85d:	mov    0x68(%rsp),%rsi
  70f862:	lea    0xc0(%rsp),%rdx
  70f86a:	call   *0x332b68(%rip)        # a423d8 <_DYNAMIC+0x3e8>
  70f870:	cmpb   $0x0,0x4b0(%rsp)
  70f878:	jne    712122 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x45a2>
  70f87e:	mov    0x80(%rsp),%r9
  70f886:	lea    0x1(%r9),%rdx
  70f88a:	mov    0x38(%rsp),%r8
  70f88f:	mov    0x310(%r8),%rsi
  70f896:	cmp    %rsi,%rdx
  70f899:	jae    70f8c6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1d46>
  70f89b:	mov    0x308(%r8),%rax
  70f8a2:	lea    (%rdx,%rdx,4),%rcx
  70f8a6:	mov    0x18(%rax,%rcx,8),%eax
  70f8aa:	mov    $0xffffffff,%ecx
  70f8af:	cmp    %rcx,%rax
  70f8b2:	setne  %cl
  70f8b5:	cmp    %rax,%r9
  70f8b8:	sete   %al
  70f8bb:	and    %cl,%al
  70f8bd:	mov    %eax,0x1f4(%rsp)
  70f8c4:	jmp    70f8d1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1d51>
  70f8c6:	movl   $0x0,0x1f4(%rsp)
  70f8d1:	mov    0x48(%rsp),%rax
  70f8d6:	movsd  0x4f4(%rsp),%xmm0
  70f8df:	movaps %xmm0,0x8c0(%rsp)
  70f8e7:	movups 0x4c4(%rsp),%xmm0
  70f8ef:	movaps %xmm0,0x8b0(%rsp)
  70f8f7:	movss  0x4c8(%rsp),%xmm0
  70f900:	movss  %xmm0,0x32c(%rsp)
  70f909:	movups 0x4d4(%rsp),%xmm0
  70f911:	movaps %xmm0,0x390(%rsp)
  70f919:	movss  0x4dc(%rsp),%xmm0
  70f922:	movaps %xmm0,0x890(%rsp)
  70f92a:	movss  0x4d8(%rsp),%xmm0
  70f933:	movss  %xmm0,0x328(%rsp)
  70f93c:	movsd  0x4fc(%rsp),%xmm0
  70f945:	movaps %xmm0,0x2b0(%rsp)
  70f94d:	movsd  0x504(%rsp),%xmm0
  70f956:	movaps %xmm0,0x8a0(%rsp)
  70f95e:	mov    (%rax),%rax
  70f961:	lea    -0x6cdc6c(%rip),%rcx        # 41cfc <GCC_except_table0+0x1f58>
  70f968:	movslq (%rcx,%rax,4),%rax
  70f96c:	add    %rcx,%rax
  70f96f:	mov    %rdx,0x810(%rsp)
  70f977:	jmp    *%rax
  70f979:	movups -0x6c2810(%rip),%xmm0        # 4d170 <GCC_except_table0+0xd3cc>
  70f980:	movaps %xmm0,0x4f0(%rsp)
  70f988:	movups -0x6c282f(%rip),%xmm0        # 4d160 <GCC_except_table0+0xd3bc>
  70f98f:	movaps %xmm0,0x4e0(%rsp)
  70f997:	movups -0x6c284e(%rip),%xmm0        # 4d150 <GCC_except_table0+0xd3ac>
  70f99e:	movaps %xmm0,0x4d0(%rsp)
  70f9a6:	movups -0x6c286d(%rip),%xmm0        # 4d140 <GCC_except_table0+0xd39c>
  70f9ad:	movaps %xmm0,0x4c0(%rsp)
  70f9b5:	movups -0x6c288c(%rip),%xmm0        # 4d130 <GCC_except_table0+0xd38c>
  70f9bc:	movaps %xmm0,0x4b0(%rsp)
  70f9c4:	movabs $0x3000100000000,%rax
  70f9ce:	mov    %rax,0x500(%rsp)
  70f9d6:	jmp    70faac <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1f2c>
  70f9db:	mov    0x220(%r8),%rax
  70f9e2:	cmp    %rax,%r9
  70f9e5:	jae    71288d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d0d>
  70f9eb:	mov    0x210(%r8),%rax
  70f9f2:	mov    0x218(%r8),%rcx
  70f9f9:	movzbl (%rcx,%r9,1),%ecx
  70f9fe:	cmp    %rcx,%rax
  70fa01:	jbe    712896 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d16>
  70fa07:	mov    0x208(%r8),%rax
  70fa0e:	imul   $0x58,%rcx,%rcx
  70fa12:	jmp    70fa5d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1edd>
  70fa14:	mov    0x208(%r8),%rsi
  70fa1b:	lea    0x4b0(%rsp),%rdi
  70fa23:	mov    %r9,%rdx
  70fa26:	call   *0x3329bc(%rip)        # a423e8 <_DYNAMIC+0x3f8>
  70fa2c:	mov    0x38(%rsp),%r8
  70fa31:	mov    0x310(%r8),%rsi
  70fa38:	mov    0x80(%rsp),%r9
  70fa40:	jmp    70faac <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1f2c>
  70fa42:	mov    0x218(%r8),%rax
  70fa49:	cmp    %rax,%r9
  70fa4c:	jae    7128a7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d27>
  70fa52:	mov    0x210(%r8),%rax
  70fa59:	imul   $0x58,%r9,%rcx
  70fa5d:	mov    0x50(%rax,%rcx,1),%rdx
  70fa62:	mov    %rdx,0x500(%rsp)
  70fa6a:	movups 0x40(%rax,%rcx,1),%xmm0
  70fa6f:	movaps %xmm0,0x4f0(%rsp)
  70fa77:	movups (%rax,%rcx,1),%xmm0
  70fa7b:	movups 0x10(%rax,%rcx,1),%xmm1
  70fa80:	movups 0x20(%rax,%rcx,1),%xmm2
  70fa85:	movupd 0x30(%rax,%rcx,1),%xmm3
  70fa8b:	movapd %xmm3,0x4e0(%rsp)
  70fa94:	movaps %xmm2,0x4d0(%rsp)
  70fa9c:	movaps %xmm1,0x4c0(%rsp)
  70faa4:	movaps %xmm0,0x4b0(%rsp)
  70faac:	cmp    %rsi,%r9
  70faaf:	jae    7127d7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c57>
  70fab5:	mov    0x308(%r8),%rdi
  70fabc:	lea    (%r9,%r9,4),%r15
  70fac0:	mov    0x18(%rdi,%r15,8),%edx
  70fac5:	mov    $0xffffffff,%eax
  70faca:	cmp    %rax,%rdx
  70facd:	je     70faec <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1f6c>
  70facf:	call   6db0a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}>
  70fad4:	mov    0x38(%rsp),%r8
  70fad9:	mov    0x310(%r8),%rsi
  70fae0:	mov    %eax,%edx
  70fae2:	mov    0x80(%rsp),%r9
  70faea:	jmp    70faee <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1f6e>
  70faec:	xor    %edx,%edx
  70faee:	cmp    %rsi,%r9
  70faf1:	jae    7127e6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c66>
  70faf7:	mov    0x308(%r8),%rax
  70fafe:	mov    0x18(%rax,%r15,8),%ebx
  70fb03:	mov    $0xffffffff,%ecx
  70fb08:	cmp    %rcx,%rbx
  70fb0b:	je     70fb26 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1fa6>
  70fb0d:	cmp    %rbx,%rsi
  70fb10:	jbe    712804 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c84>
  70fb16:	lea    (%rbx,%rbx,4),%rcx
  70fb1a:	mov    (%rax,%rcx,8),%rcx
  70fb1e:	mov    %rcx,0x800(%rsp)
  70fb26:	mov    %edx,0x190(%rsp)
  70fb2d:	mov    0x138(%rsp),%rcx
  70fb35:	mov    (%rcx),%rcx
  70fb38:	xorps  %xmm0,%xmm0
  70fb3b:	movss  %xmm0,0x128(%rsp)
  70fb44:	test   %rcx,%rcx
  70fb47:	je     70fb7f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1fff>
  70fb49:	mov    0x100(%rcx),%rdi
  70fb50:	test   %rdi,%rdi
  70fb53:	je     70fb7f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1fff>
  70fb55:	lea    (%rax,%r15,8),%rax
  70fb59:	mov    (%rax),%rsi
  70fb5c:	call   *0x332b7e(%rip)        # a426e0 <_DYNAMIC+0x6f0>
  70fb62:	movss  %xmm0,0x128(%rsp)
  70fb6b:	mov    0x38(%rsp),%r8
  70fb70:	mov    0x310(%r8),%rsi
  70fb77:	mov    0x80(%rsp),%r9
  70fb7f:	cmp    %rsi,%r9
  70fb82:	jae    7127f5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c75>
  70fb88:	mov    0x308(%r8),%r12
  70fb8f:	mov    0x18(%r12,%r15,8),%ecx
  70fb94:	mov    $0xffffffff,%eax
  70fb99:	cmp    %rax,%rcx
  70fb9c:	je     70fcb8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2138>
  70fba2:	mov    0x208(%rsp),%rax
  70fbaa:	cmp    %rcx,%rax
  70fbad:	jbe    71281b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c9b>
  70fbb3:	imul   $0x38,%rcx,%rax
  70fbb7:	mov    0x200(%rsp),%rcx
  70fbbf:	movups (%rcx,%rax,1),%xmm0
  70fbc3:	movaps %xmm0,0x50(%rsp)
  70fbc8:	movups 0x10(%rcx,%rax,1),%xmm0
  70fbcd:	movaps %xmm0,0x110(%rsp)
  70fbd5:	movups 0x20(%rcx,%rax,1),%xmm0
  70fbda:	movaps %xmm0,0x2a0(%rsp)
  70fbe2:	movzbl 0x30(%rcx,%rax,1),%ebp
  70fbe7:	mov    0x31(%rcx,%rax,1),%edx
  70fbeb:	mov    %edx,0xa0(%rsp)
  70fbf2:	mov    0x34(%rcx,%rax,1),%eax
  70fbf6:	mov    %eax,0xa3(%rsp)
  70fbfd:	cmp    $0xffffffff,%ebx
  70fc00:	je     7125a0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4a20>
  70fc06:	lea    0xc0(%rsp),%rdi
  70fc0e:	lea    0x3a0(%rsp),%rsi
  70fc16:	mov    0x800(%rsp),%rdx
  70fc1e:	call   *0x332b4c(%rip)        # a42770 <_DYNAMIC+0x780>
  70fc24:	cmpb   $0x0,0xc0(%rsp)
  70fc2c:	je     70fcec <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x216c>
  70fc32:	movq   0xc8(%rsp),%xmm0
  70fc3b:	movq   0xd0(%rsp),%xmm1
  70fc44:	movq   %xmm0,%rax
  70fc49:	movq   %xmm1,%rcx
  70fc4e:	movabs $0x7fffffffffffffff,%rdx
  70fc58:	and    %rdx,%rax
  70fc5b:	movabs $0x7fefffffffffffff,%rsi
  70fc65:	cmp    %rsi,%rax
  70fc68:	setg   %al
  70fc6b:	and    %rdx,%rcx
  70fc6e:	cmp    %rsi,%rcx
  70fc71:	setg   %cl
  70fc74:	or     %al,%cl
  70fc76:	or     %bpl,%cl
  70fc79:	and    $0x1,%cl
  70fc7c:	punpcklqdq %xmm1,%xmm1
  70fc80:	pxor   -0x6ce9e8(%rip),%xmm1        # 412a0 <GCC_except_table0+0x14fc>
  70fc88:	movapd 0x110(%rsp),%xmm3
  70fc91:	mulpd  %xmm3,%xmm1
  70fc95:	punpcklqdq %xmm0,%xmm0
  70fc99:	movapd 0x50(%rsp),%xmm2
  70fc9f:	mulpd  %xmm2,%xmm0
  70fca3:	subpd  %xmm0,%xmm1
  70fca7:	movapd 0x2a0(%rsp),%xmm0
  70fcb0:	addpd  %xmm1,%xmm0
  70fcb4:	mov    %ecx,%ebp
  70fcb6:	jmp    70fd1f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x219f>
  70fcb8:	movsd  0x7f0(%rsp),%xmm0
  70fcc1:	movsd  %xmm0,0x470(%rsp)
  70fcca:	lea    0x4a1(%rsp),%rax
  70fcd2:	xorps  %xmm1,%xmm1
  70fcd5:	movups %xmm1,-0x29(%rax)
  70fcd9:	movsd  %xmm0,0x488(%rsp)
  70fce2:	movaps %xmm1,-0x11(%rax)
  70fce6:	movb   $0x0,-0x1(%rax)
  70fcea:	jmp    70fd42 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x21c2>
  70fcec:	mov    0xa0(%rsp),%eax
  70fcf3:	mov    0xa3(%rsp),%ecx
  70fcfa:	lea    0x4a1(%rsp),%rdx
  70fd02:	mov    %ecx,0x3(%rdx)
  70fd05:	mov    %eax,(%rdx)
  70fd07:	movapd 0x50(%rsp),%xmm2
  70fd0d:	movapd 0x110(%rsp),%xmm3
  70fd16:	movapd 0x2a0(%rsp),%xmm0
  70fd1f:	movapd %xmm2,0x470(%rsp)
  70fd28:	movapd %xmm3,0x480(%rsp)
  70fd31:	movapd %xmm0,0x490(%rsp)
  70fd3a:	mov    %bpl,0x4a0(%rsp)
  70fd42:	movaps -0x6ce799(%rip),%xmm0        # 415b0 <GCC_except_table0+0x180c>
  70fd49:	movaps %xmm0,0xa0(%rsp)
  70fd51:	movaps 0x8c0(%rsp),%xmm0
  70fd59:	movlps %xmm0,0xb0(%rsp)
  70fd61:	lea    0xc0(%rsp),%rdi
  70fd69:	lea    0x470(%rsp),%rsi
  70fd71:	lea    0xa0(%rsp),%rdx
  70fd79:	call   *0x332661(%rip)        # a423e0 <_DYNAMIC+0x3f0>
  70fd7f:	lea    0xb20(%rsp),%rdi
  70fd87:	lea    0xc0(%rsp),%rsi
  70fd8f:	lea    0x4ec(%rsp),%rdx
  70fd97:	call   *0x332643(%rip)        # a423e0 <_DYNAMIC+0x3f0>
  70fd9d:	mov    0x208(%rsp),%rbx
  70fda5:	cmp    0x1f8(%rsp),%rbx
  70fdad:	jne    70fdbc <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x223c>
  70fdaf:	lea    0x1f8(%rsp),%rdi
  70fdb7:	call   6f4900 <<alloc::raw_vec::RawVec<gpui::semantic::AnnotationDraft>>::grow_one>
  70fdbc:	mov    0x200(%rsp),%rax
  70fdc4:	imul   $0x38,%rbx,%rcx
  70fdc8:	mov    0xb50(%rsp),%rdx
  70fdd0:	mov    %rdx,0x30(%rax,%rcx,1)
  70fdd5:	movups 0xb20(%rsp),%xmm0
  70fddd:	movups 0xb30(%rsp),%xmm1
  70fde5:	movups 0xb40(%rsp),%xmm2
  70fded:	movups %xmm2,0x20(%rax,%rcx,1)
  70fdf2:	movups %xmm1,0x10(%rax,%rcx,1)
  70fdf7:	movups %xmm0,(%rax,%rcx,1)
  70fdfb:	inc    %rbx
  70fdfe:	mov    %rbx,0x208(%rsp)
  70fe06:	movups 0xb20(%rsp),%xmm0
  70fe0e:	movaps %xmm0,0x110(%rsp)
  70fe16:	movups 0xb30(%rsp),%xmm0
  70fe1e:	movaps %xmm0,0x2a0(%rsp)
  70fe26:	movups 0xb40(%rsp),%xmm0
  70fe2e:	movaps %xmm0,0x50(%rsp)
  70fe33:	lea    0xb20(%rsp),%rdi
  70fe3b:	call   *0x332937(%rip)        # a42778 <_DYNAMIC+0x788>
  70fe41:	xor    %ebx,%ebx
  70fe43:	test   %al,%al
  70fe45:	je     70ff64 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x23e4>
  70fe4b:	cvtpd2ps 0x2a0(%rsp),%xmm0
  70fe54:	cvtpd2ps 0x110(%rsp),%xmm1
  70fe5d:	cvtpd2ps 0x50(%rsp),%xmm2
  70fe63:	unpcklpd %xmm0,%xmm1
  70fe67:	movd   %xmm1,%eax
  70fe6b:	and    $0x7fffffff,%eax
  70fe70:	movapd %xmm1,%xmm0
  70fe74:	shufps $0x55,%xmm1,%xmm0
  70fe78:	movd   %xmm0,%ecx
  70fe7c:	and    $0x7fffffff,%ecx
  70fe82:	cmp    $0x7f800000,%ecx
  70fe88:	setge  %cl
  70fe8b:	movdqa %xmm1,%xmm0
  70fe8f:	punpckhqdq %xmm1,%xmm0
  70fe93:	movd   %xmm0,%edx
  70fe97:	and    $0x7fffffff,%edx
  70fe9d:	cmp    $0x7f800000,%edx
  70fea3:	setge  %dl
  70fea6:	movaps %xmm1,%xmm0
  70fea9:	shufps $0xff,%xmm1,%xmm0
  70fead:	movd   %xmm0,%esi
  70feb1:	and    $0x7fffffff,%esi
  70feb7:	cmp    $0x7f800000,%esi
  70febd:	setge  %sil
  70fec1:	movd   %xmm2,%edi
  70fec5:	and    $0x7fffffff,%edi
  70fecb:	cmp    $0x7f800000,%edi
  70fed1:	setge  %dil
  70fed5:	movapd %xmm2,%xmm0
  70fed9:	shufps $0x55,%xmm2,%xmm0
  70fedd:	movd   %xmm0,%r8d
  70fee2:	and    $0x7fffffff,%r8d
  70fee9:	cmp    $0x7f800000,%r8d
  70fef0:	setl   %r8b
  70fef4:	cmp    $0x7f7fffff,%eax
  70fef9:	jg     70ff64 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x23e4>
  70fefb:	test   %cl,%cl
  70fefd:	jne    70ff64 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x23e4>
  70feff:	test   %dl,%dl
  70ff01:	jne    70ff64 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x23e4>
  70ff03:	test   %sil,%sil
  70ff06:	jne    70ff64 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x23e4>
  70ff08:	test   %dil,%dil
  70ff0b:	jne    70ff64 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x23e4>
  70ff0d:	test   %r8b,%r8b
  70ff10:	je     70ff64 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x23e4>
  70ff12:	movaps %xmm1,0x50(%rsp)
  70ff17:	movaps %xmm1,0xc0(%rsp)
  70ff1f:	movaps %xmm2,0x110(%rsp)
  70ff27:	movlpd %xmm2,0xd0(%rsp)
  70ff30:	lea    0xc0(%rsp),%rdi
  70ff38:	call   *0x332842(%rip)        # a42780 <_DYNAMIC+0x790>
  70ff3e:	test   %al,%al
  70ff40:	je     70ff64 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x23e4>
  70ff42:	movaps 0x50(%rsp),%xmm0
  70ff47:	movups %xmm0,0x2f0(%rsp)
  70ff4f:	movaps 0x110(%rsp),%xmm0
  70ff57:	movlps %xmm0,0x300(%rsp)
  70ff5f:	mov    $0x1,%ebx
  70ff64:	lea    (%r12,%r15,8),%rsi
  70ff68:	mov    %ebx,0x2ec(%rsp)
  70ff6f:	xorps  %xmm0,%xmm0
  70ff72:	unpcklpd 0x2b0(%rsp),%xmm0
  70ff7b:	movups %xmm0,0x358(%rsp)
  70ff83:	cmpb   $0x0,0x37(%rsp)
  70ff88:	mov    %rsi,0x50(%rsp)
  70ff8d:	je     70fff8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2478>
  70ff8f:	mov    0x18(%rsi),%ecx
  70ff92:	mov    $0xffffffff,%eax
  70ff97:	cmp    %rax,%rcx
  70ff9a:	je     710021 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x24a1>
  70ffa0:	mov    0x230(%rsp),%rax
  70ffa8:	cmp    %rcx,%rax
  70ffab:	jbe    712841 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4cc1>
  70ffb1:	mov    0x228(%rsp),%rax
  70ffb9:	mov    %rcx,%rdx
  70ffbc:	shl    $0x4,%rdx
  70ffc0:	movups (%rax,%rdx,1),%xmm1
  70ffc4:	xorps  %xmm0,%xmm0
  70ffc7:	unpcklpd 0x70(%rsp),%xmm0
  70ffcd:	movups %xmm0,0xc0(%rsp)
  70ffd5:	mov    0x248(%rsp),%rax
  70ffdd:	cmp    %rcx,%rax
  70ffe0:	jbe    712852 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4cd2>
  70ffe6:	movaps %xmm1,0x2a0(%rsp)
  70ffee:	add    0x240(%rsp),%rdx
  70fff6:	jmp    71004a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x24ca>
  70fff8:	xorps  %xmm0,%xmm0
  70fffb:	unpcklpd 0x70(%rsp),%xmm0
  710001:	movups %xmm0,0x250(%rsp)
  710009:	movl   $0x0,0x110(%rsp)
  710014:	movaps 0x880(%rsp),%xmm0
  71001c:	jmp    7100c6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2546>
  710021:	xorps  %xmm0,%xmm0
  710024:	unpcklpd 0x70(%rsp),%xmm0
  71002a:	movups %xmm0,0xc0(%rsp)
  710032:	lea    0xc0(%rsp),%rdx
  71003a:	movaps 0x880(%rsp),%xmm0
  710042:	movaps %xmm0,0x2a0(%rsp)
  71004a:	movups (%rdx),%xmm0
  71004d:	movaps %xmm0,0x250(%rsp)
  710055:	mov    0x20(%rsi),%edi
  710058:	call   6f81d0 <<gpui::runtime::Node>::kind>
  71005d:	mov    $0x1,%cl
  71005f:	mov    %ecx,0x110(%rsp)
  710066:	cmp    $0x7,%al
  710068:	jne    710079 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x24f9>
  71006a:	mov    0x50(%rsp),%rsi
  71006f:	movaps 0x2a0(%rsp),%xmm0
  710077:	jmp    7100c6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2546>
  710079:	mov    0x50(%rsp),%rsi
  71007e:	mov    0x18(%rsi),%ecx
  710081:	mov    $0xffffffff,%eax
  710086:	cmp    %rax,%rcx
  710089:	movaps 0x2a0(%rsp),%xmm0
  710091:	je     7100bb <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x253b>
  710093:	mov    0x1a8(%rsp),%rax
  71009b:	cmp    %rcx,%rax
  71009e:	jbe    7128b0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d30>
  7100a4:	mov    0x1a0(%rsp),%rax
  7100ac:	movzbl (%rax,%rcx,1),%eax
  7100b0:	and    $0x1,%al
  7100b2:	mov    %eax,0x110(%rsp)
  7100b9:	jmp    7100c6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2546>
  7100bb:	movl   $0x0,0x110(%rsp)
  7100c6:	movaps %xmm0,0x1b0(%rsp)
  7100ce:	mov    0x20(%rsi),%eax
  7100d1:	and    $0xf,%eax
  7100d4:	cmp    $0x7,%eax
  7100d7:	jb     7100e5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2565>
  7100d9:	lea    -0x8(%rax),%ecx
  7100dc:	cmp    $0x2,%ecx
  7100df:	jae    710c56 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x30d6>
  7100e5:	mov    0x18(%rsi),%ecx
  7100e8:	xor    %r12d,%r12d
  7100eb:	mov    $0xffffffff,%edx
  7100f0:	cmp    %rdx,%rcx
  7100f3:	je     710113 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2593>
  7100f5:	cmp    %rcx,0x1a8(%rsp)
  7100fd:	jbe    710113 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2593>
  7100ff:	mov    0x1a0(%rsp),%rdx
  710107:	movzbl (%rdx,%rcx,1),%r12d
  71010c:	and    $0x2,%r12b
  710110:	shr    $1,%r12b
  710113:	cmpb   $0x0,0x37(%rsp)
  710118:	je     710167 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x25e7>
  71011a:	mov    0x1a8(%rsp),%r14
  710122:	cmp    0x198(%rsp),%r14
  71012a:	jne    71013a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x25ba>
  71012c:	lea    0x198(%rsp),%rdi
  710134:	call   *0x33264e(%rip)        # a42788 <_DYNAMIC+0x798>
  71013a:	lea    (%r12,%r12,1),%eax
  71013e:	add    0x110(%rsp),%al
  710145:	mov    0x1a0(%rsp),%rcx
  71014d:	mov    %al,(%rcx,%r14,1)
  710151:	inc    %r14
  710154:	mov    %r14,0x1a8(%rsp)
  71015c:	mov    0x50(%rsp),%rax
  710161:	mov    0x20(%rax),%eax
  710164:	and    $0xf,%eax
  710167:	cmp    $0x9,%eax
  71016a:	ja     712679 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4af9>
  710170:	mov    $0x34f,%ecx
  710175:	bt     %eax,%ecx
  710178:	jb     710201 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2681>
  71017e:	movaps 0x1b0(%rsp),%xmm0
  710186:	movaps %xmm0,0xa0(%rsp)
  71018e:	movups 0x358(%rsp),%xmm0
  710196:	movaps %xmm0,0xc0(%rsp)
  71019e:	lea    0x840(%rsp),%rdi
  7101a6:	lea    0xa0(%rsp),%rsi
  7101ae:	lea    0x250(%rsp),%rdx
  7101b6:	lea    0x2ec(%rsp),%rcx
  7101be:	lea    0xc0(%rsp),%r8
  7101c6:	mov    0x310(%rsp),%r9
  7101ce:	call   *0x3325bc(%rip)        # a42790 <_DYNAMIC+0x7a0>
  7101d4:	cmpl   $0xfffffffe,0x840(%rsp)
  7101dc:	jne    71220d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x468d>
  7101e2:	lea    0x848(%rsp),%rax
  7101ea:	movups (%rax),%xmm0
  7101ed:	movaps %xmm0,0x1b0(%rsp)
  7101f5:	movups 0x10(%rax),%xmm0
  7101f9:	movaps %xmm0,0x250(%rsp)
  710201:	cmpb   $0x0,0x37(%rsp)
  710206:	je     7102a6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2726>
  71020c:	movaps 0x1b0(%rsp),%xmm0
  710214:	movaps %xmm0,0xc0(%rsp)
  71021c:	mov    0x230(%rsp),%r14
  710224:	cmp    0x220(%rsp),%r14
  71022c:	jne    71023b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x26bb>
  71022e:	lea    0x220(%rsp),%rdi
  710236:	call   6f4970 <<alloc::raw_vec::RawVec<gpui_reactivity_core::geometry::Rect>>::grow_one>
  71023b:	mov    0x228(%rsp),%rax
  710243:	mov    %r14,%rcx
  710246:	shl    $0x4,%rcx
  71024a:	movaps 0xc0(%rsp),%xmm0
  710252:	movups %xmm0,(%rax,%rcx,1)
  710256:	inc    %r14
  710259:	mov    %r14,0x230(%rsp)
  710261:	mov    0x248(%rsp),%r14
  710269:	cmp    0x238(%rsp),%r14
  710271:	jne    710280 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2700>
  710273:	lea    0x238(%rsp),%rdi
  71027b:	call   6f4970 <<alloc::raw_vec::RawVec<gpui_reactivity_core::geometry::Rect>>::grow_one>
  710280:	mov    0x240(%rsp),%rax
  710288:	mov    %r14,%rcx
  71028b:	shl    $0x4,%rcx
  71028f:	movaps 0x250(%rsp),%xmm0
  710297:	movups %xmm0,(%rax,%rcx,1)
  71029b:	inc    %r14
  71029e:	mov    %r14,0x248(%rsp)
  7102a6:	test   %ebx,%ebx
  7102a8:	je     7102de <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x275e>
  7102aa:	lea    0xc0(%rsp),%rdi
  7102b2:	lea    0x358(%rsp),%rsi
  7102ba:	lea    0x2f0(%rsp),%rdx
  7102c2:	call   6db1c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#24}>
  7102c7:	cmpl   $0x1,0xc0(%rsp)
  7102cf:	jne    7102de <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x275e>
  7102d1:	lea    0xc4(%rsp),%rax
  7102d9:	movups (%rax),%xmm0
  7102dc:	jmp    7102e1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2761>
  7102de:	xorps  %xmm0,%xmm0
  7102e1:	movaps %xmm0,0x3d0(%rsp)
  7102e9:	mov    0x110(%rsp),%eax
  7102f0:	or     %r12b,%al
  7102f3:	cmp    $0x1,%al
  7102f5:	je     710308 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2788>
  7102f7:	mov    0x50(%rsp),%rax
  7102fc:	mov    0x20(%rax),%edi
  7102ff:	call   6f81d0 <<gpui::runtime::Node>::kind>
  710304:	cmp    $0x6,%al
  710306:	jne    710328 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x27a8>
  710308:	lea    0x2c0(%rsp),%rdi
  710310:	lea    0x3d0(%rsp),%rsi
  710318:	lea    0x250(%rsp),%rdx
  710320:	call   *0x332472(%rip)        # a42798 <_DYNAMIC+0x7a8>
  710326:	jmp    710392 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2812>
  710328:	movsd  0x3d0(%rsp),%xmm0
  710331:	movsd  0x3d8(%rsp),%xmm1
  71033a:	movaps %xmm0,%xmm2
  71033d:	addps  %xmm0,%xmm1
  710340:	xorps  %xmm4,%xmm4
  710343:	maxps  %xmm4,%xmm0
  710346:	movaps %xmm0,%xmm3
  710349:	cmpunordps %xmm0,%xmm3
  71034d:	andps  %xmm3,%xmm2
  710350:	andnps %xmm0,%xmm3
  710353:	orps   %xmm2,%xmm3
  710356:	movaps %xmm1,%xmm0
  710359:	minps  0x70(%rsp),%xmm0
  71035e:	movaps %xmm0,%xmm2
  710361:	cmpunordps %xmm0,%xmm2
  710365:	andps  %xmm2,%xmm1
  710368:	andnps %xmm0,%xmm2
  71036b:	orps   %xmm1,%xmm2
  71036e:	subps  %xmm3,%xmm2
  710371:	movaps %xmm2,%xmm0
  710374:	maxps  %xmm4,%xmm0
  710377:	movaps %xmm0,%xmm1
  71037a:	cmpunordps %xmm0,%xmm1
  71037e:	andps  %xmm1,%xmm2
  710381:	andnps %xmm0,%xmm1
  710384:	orps   %xmm2,%xmm1
  710387:	movlhps %xmm1,%xmm3
  71038a:	movups %xmm3,0x2c0(%rsp)
  710392:	test   %r12b,%r12b
  710395:	mov    0x38(%rsp),%rcx
  71039a:	je     7103c9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2849>
  71039c:	movss  0x2c8(%rsp),%xmm0
  7103a5:	xor    %ebp,%ebp
  7103a7:	xorps  %xmm1,%xmm1
  7103aa:	ucomiss %xmm1,%xmm0
  7103ad:	jne    7103b5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2835>
  7103af:	jnp    710655 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2ad5>
  7103b5:	movss  0x2cc(%rsp),%xmm0
  7103be:	ucomiss %xmm1,%xmm0
  7103c1:	jne    7103c9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2849>
  7103c3:	jnp    710655 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2ad5>
  7103c9:	mov    0x4e8(%rsp),%eax
  7103d0:	mov    $0x3fffffff,%ecx
  7103d5:	and    %ecx,%eax
  7103d7:	cmp    $0x3f800001,%eax
  7103dc:	mov    $0x80000000,%ecx
  7103e1:	cmove  %ecx,%eax
  7103e4:	movd   %eax,%xmm0
  7103e8:	xorps  %xmm1,%xmm1
  7103eb:	ucomiss %xmm1,%xmm0
  7103ee:	jbe    7104d7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2957>
  7103f4:	movl   $0x1,0xc8(%rsp)
  7103ff:	movq   $0x23,0xc0(%rsp)
  71040b:	test   %bl,%bl
  71040d:	je     71214f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x45cf>
  710413:	lea    0xc0(%rsp),%rbx
  71041b:	mov    %rbx,%rdi
  71041e:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  710423:	lea    0x2f0(%rsp),%rax
  71042b:	movups (%rax),%xmm0
  71042e:	movaps %xmm0,0xae0(%rsp)
  710436:	mov    0x10(%rax),%rax
  71043a:	mov    %rax,0xaf0(%rsp)
  710442:	mov    %rbx,%rdi
  710445:	mov    0x48(%rsp),%rsi
  71044a:	mov    0x80(%rsp),%rdx
  710452:	xor    %ecx,%ecx
  710454:	call   *0x332346(%rip)        # a427a0 <_DYNAMIC+0x7b0>
  71045a:	mov    0xd0(%rsp),%r9
  710462:	test   %r9,%r9
  710465:	je     7105d9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2a59>
  71046b:	movups 0xc0(%rsp),%xmm0
  710473:	movaps %xmm0,0x330(%rsp)
  71047b:	movaps 0x1b0(%rsp),%xmm0
  710483:	movaps %xmm0,0x150(%rsp)
  71048b:	movups 0x358(%rsp),%xmm0
  710493:	movaps %xmm0,0xa0(%rsp)
  71049b:	lea    0x8f0(%rsp),%rdi
  7104a3:	lea    0xa0(%rsp),%rsi
  7104ab:	movss  0x128(%rsp),%xmm0
  7104b4:	lea    0xae0(%rsp),%rdx
  7104bc:	lea    0x150(%rsp),%rcx
  7104c4:	lea    0x330(%rsp),%r8
  7104cc:	call   *0x3322d6(%rip)        # a427a8 <_DYNAMIC+0x7b8>
  7104d2:	jmp    7105c6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2a46>
  7104d7:	mov    0x50(%rsp),%rax
  7104dc:	cmpq   $0x0,0x8(%rax)
  7104e1:	jne    710500 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2980>
  7104e3:	mov    0x50(%rsp),%rax
  7104e8:	mov    0x20(%rax),%edi
  7104eb:	call   6f81d0 <<gpui::runtime::Node>::kind>
  7104f0:	mov    $0x1,%bpl
  7104f3:	cmp    $0x4,%al
  7104f5:	mov    0x38(%rsp),%rcx
  7104fa:	jne    710655 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2ad5>
  710500:	movl   $0x1,0xc8(%rsp)
  71050b:	movq   $0x23,0xc0(%rsp)
  710517:	test   %bl,%bl
  710519:	je     71214f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x45cf>
  71051f:	lea    0xc0(%rsp),%rbx
  710527:	mov    %rbx,%rdi
  71052a:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  71052f:	lea    0x2f0(%rsp),%rcx
  710537:	movups (%rcx),%xmm0
  71053a:	movaps %xmm0,0x150(%rsp)
  710542:	mov    0x10(%rcx),%rax
  710546:	mov    %rax,0x160(%rsp)
  71054e:	movups (%rcx),%xmm0
  710551:	movaps %xmm0,0xb90(%rsp)
  710559:	mov    0x10(%rcx),%rax
  71055d:	mov    %rax,0xba0(%rsp)
  710565:	movaps 0x1b0(%rsp),%xmm0
  71056d:	movaps %xmm0,0x330(%rsp)
  710575:	movups 0x358(%rsp),%xmm0
  71057d:	movaps %xmm0,0xa0(%rsp)
  710585:	movups -0x6cf14c(%rip),%xmm0        # 41440 <GCC_except_table0+0x169c>
  71058c:	movaps %xmm0,0xc0(%rsp)
  710594:	lea    0x8f0(%rsp),%rdi
  71059c:	lea    0xa0(%rsp),%rsi
  7105a4:	movss  0x128(%rsp),%xmm0
  7105ad:	lea    0xb90(%rsp),%rdx
  7105b5:	lea    0x330(%rsp),%rcx
  7105bd:	mov    %rbx,%r8
  7105c0:	call   *0x3321ea(%rip)        # a427b0 <_DYNAMIC+0x7c0>
  7105c6:	cmp    $0xffffffff,%eax
  7105c9:	jne    712188 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4608>
  7105cf:	mov    $0x1,%bpl
  7105d2:	mov    0x38(%rsp),%rcx
  7105d7:	jmp    710655 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2ad5>
  7105d9:	movaps 0x1b0(%rsp),%xmm0
  7105e1:	movaps %xmm0,0x150(%rsp)
  7105e9:	lea    0x4ec(%rsp),%rax
  7105f1:	movups -0x10(%rax),%xmm0
  7105f5:	movaps %xmm0,0xa0(%rsp)
  7105fd:	movups 0x358(%rsp),%xmm0
  710605:	movaps %xmm0,0xc0(%rsp)
  71060d:	lea    0x8f0(%rsp),%rdi
  710615:	lea    0xc0(%rsp),%rsi
  71061d:	movss  0x128(%rsp),%xmm0
  710626:	lea    0xae0(%rsp),%rdx
  71062e:	lea    0x150(%rsp),%rcx
  710636:	lea    0xa0(%rsp),%r8
  71063e:	call   *0x33216c(%rip)        # a427b0 <_DYNAMIC+0x7c0>
  710644:	mov    $0x1,%bpl
  710647:	cmp    $0xffffffff,%eax
  71064a:	mov    0x38(%rsp),%rcx
  71064f:	jne    712188 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4608>
  710655:	mov    0x50(%rsp),%rax
  71065a:	mov    0x20(%rax),%edi
  71065d:	mov    %edi,%eax
  71065f:	and    $0xf,%eax
  710662:	cmp    $0x9,%eax
  710665:	ja     712679 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4af9>
  71066b:	cmp    $0x6,%eax
  71066e:	je     710c67 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x30e7>
  710674:	shr    $0x4,%edi
  710677:	dec    %edi
  710679:	mov    0x320(%rcx),%rsi
  710680:	mov    0x328(%rcx),%rdx
  710687:	call   6f80c0 <<gpui::runtime::TextSlot>::get_mut>
  71068c:	test   %rax,%rax
  71068f:	je     710a79 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2ef9>
  710695:	lea    0x4ec(%rsp),%rcx
  71069d:	movups -0x20(%rcx),%xmm0
  7106a1:	movaps %xmm0,0x8e0(%rsp)
  7106a9:	mov    0x38(%rsp),%rcx
  7106ae:	mov    0x708(%rcx),%rbx
  7106b5:	mov    $0x1e,%esi
  7106ba:	test   %rbx,%rbx
  7106bd:	je     712588 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4a08>
  7106c3:	cmpq   $0x0,0x30(%rbx)
  7106c8:	je     712588 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4a08>
  7106ce:	movzbl 0x46c(%rsp),%ecx
  7106d6:	mov    $0x2,%r13b
  7106d9:	cmp    $0x2,%cl
  7106dc:	je     710753 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2bd3>
  7106de:	mov    0x50(%rsp),%rdx
  7106e3:	mov    (%rdx),%rdx
  7106e6:	cmp    %rdx,0x458(%rsp)
  7106ee:	jne    710753 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2bd3>
  7106f0:	mov    0x468(%rsp),%edx
  7106f7:	mov    %edx,0x1f0(%rsp)
  7106fe:	movzbl 0x464(%rsp),%edx
  710706:	mov    %dl,0x99(%rsp)
  71070d:	mov    0x460(%rsp),%edx
  710714:	mov    %edx,0x18c(%rsp)
  71071b:	lea    0x465(%rsp),%rdi
  710723:	movzwl (%rdi),%edx
  710726:	mov    %dx,0x134(%rsp)
  71072e:	movzbl 0x2(%rdi),%edx
  710732:	mov    %dl,0x136(%rsp)
  710739:	movzwl 0x8(%rdi),%edx
  71073d:	mov    %dx,0x130(%rsp)
  710745:	movzbl 0xa(%rdi),%edx
  710749:	mov    %dl,0x132(%rsp)
  710750:	mov    %ecx,%r13d
  710753:	cmpq   $0x0,0x1c8(%rsp)
  71075c:	je     7125c4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4a44>
  710762:	movss  0x4c8(%rsp),%xmm0
  71076b:	movaps 0x2b0(%rsp),%xmm1
  710773:	subss  0x390(%rsp),%xmm1
  71077c:	subss  0x328(%rsp),%xmm1
  710785:	subss  0x8b0(%rsp),%xmm1
  71078e:	subss  0x32c(%rsp),%xmm1
  710797:	subss  0x8a0(%rsp),%xmm1
  7107a0:	lea    0xc0(%rsp),%rdi
  7107a8:	mov    %rax,%rsi
  7107ab:	lea    0x1c8(%rsp),%rdx
  7107b3:	mov    $0x1,%ecx
  7107b8:	mov    $0x1,%r8d
  7107be:	call   *0x331c94(%rip)        # a42458 <_DYNAMIC+0x468>
  7107c4:	mov    0xc0(%rsp),%rax
  7107cc:	mov    0xc8(%rsp),%r15
  7107d4:	cmp    $0xfffffffffffffffe,%rax
  7107d8:	jne    71219f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x461f>
  7107de:	movaps 0x390(%rsp),%xmm0
  7107e6:	movss  %xmm0,0x148(%rsp)
  7107ef:	movaps 0x890(%rsp),%xmm0
  7107f7:	movss  %xmm0,0x14c(%rsp)
  710800:	mov    0x20(%r15),%rax
  710804:	test   %rax,%rax
  710807:	je     712659 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4ad9>
  71080d:	lock incq (%rax)
  710811:	mov    0x38(%rsp),%r14
  710816:	jle    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  71081c:	movsd  0x148(%rsp),%xmm0
  710825:	movsd  %xmm0,0x318(%rsp)
  71082e:	mov    %rax,0x320(%rsp)
  710836:	test   %bpl,%bpl
  710839:	je     710cb8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3138>
  71083f:	testb  $0x1,0x2ec(%rsp)
  710847:	movl   $0x1,0xc8(%rsp)
  710852:	movq   $0x23,0xc0(%rsp)
  71085e:	je     7122c5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4745>
  710864:	lea    0xc0(%rsp),%rdi
  71086c:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  710871:	lea    0x2f0(%rsp),%rcx
  710879:	movups (%rcx),%xmm0
  71087c:	movaps %xmm0,0xb00(%rsp)
  710884:	mov    0x10(%rcx),%rax
  710888:	mov    %rax,0xb10(%rsp)
  710890:	movups (%rcx),%xmm0
  710893:	movaps %xmm0,0x330(%rsp)
  71089b:	mov    0x10(%rcx),%rax
  71089f:	mov    %rax,0x340(%rsp)
  7108a7:	cmp    $0x2,%r13b
  7108ab:	je     7109b5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2e35>
  7108b1:	mov    0x18c(%rsp),%eax
  7108b8:	mov    %eax,0xa0(%rsp)
  7108bf:	movzbl 0x99(%rsp),%eax
  7108c7:	mov    %al,0xa4(%rsp)
  7108ce:	movzbl 0x136(%rsp),%eax
  7108d6:	lea    0xa5(%rsp),%rcx
  7108de:	mov    %al,0x2(%rcx)
  7108e1:	movzwl 0x134(%rsp),%eax
  7108e9:	mov    %ax,(%rcx)
  7108ec:	mov    0x1f0(%rsp),%eax
  7108f3:	mov    %eax,0xa8(%rsp)
  7108fa:	mov    %r13b,0xac(%rsp)
  710902:	movzbl 0x132(%rsp),%eax
  71090a:	mov    %al,0xa(%rcx)
  71090d:	movzwl 0x130(%rsp),%eax
  710915:	mov    %ax,0x8(%rcx)
  710919:	movl   $0xffffffff,0x150(%rsp)
  710924:	lea    0x150(%rsp),%rax
  71092c:	mov    %rax,0xc0(%rsp)
  710934:	lea    0x8f0(%rsp),%rax
  71093c:	mov    %rax,0xc8(%rsp)
  710944:	lea    0x148(%rsp),%rax
  71094c:	mov    %rax,0xd0(%rsp)
  710954:	lea    0x14c(%rsp),%rax
  71095c:	mov    %rax,0xd8(%rsp)
  710964:	lea    0x330(%rsp),%rax
  71096c:	mov    %rax,0xe0(%rsp)
  710974:	lea    0x1b0(%rsp),%rax
  71097c:	mov    %rax,0xe8(%rsp)
  710984:	mov    0x20(%r15),%rdi
  710988:	lea    0xa0(%rsp),%rsi
  710990:	lea    0xc0(%rsp),%rdx
  710998:	call   6b8010 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>>
  71099d:	test   %al,%al
  71099f:	je     712369 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x47e9>
  7109a5:	mov    0x150(%rsp),%eax
  7109ac:	cmp    $0xffffffff,%eax
  7109af:	jne    712377 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x47f7>
  7109b5:	lea    0xa0(%rsp),%rdi
  7109bd:	mov    0x48(%rsp),%rsi
  7109c2:	mov    0x80(%rsp),%rdx
  7109ca:	mov    $0x1,%ecx
  7109cf:	call   *0x331dcb(%rip)        # a427a0 <_DYNAMIC+0x7b0>
  7109d5:	add    $0x30,%rbx
  7109d9:	mov    0xb0(%rsp),%rax
  7109e1:	test   %rax,%rax
  7109e4:	je     710a8a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2f0a>
  7109ea:	movups 0xa0(%rsp),%xmm0
  7109f2:	movaps %xmm0,0x3e0(%rsp)
  7109fa:	movaps 0x1b0(%rsp),%xmm0
  710a02:	movaps %xmm0,0x150(%rsp)
  710a0a:	movss  0x148(%rsp),%xmm0
  710a13:	movss  0x14c(%rsp),%xmm1
  710a1c:	lea    0x2f0(%rsp),%rdx
  710a24:	mov    0x10(%rdx),%rcx
  710a28:	mov    %rcx,0xd0(%rsp)
  710a30:	movups (%rdx),%xmm2
  710a33:	movaps %xmm2,0xc0(%rsp)
  710a3b:	mov    %rax,(%rsp)
  710a3f:	lea    0x8f0(%rsp),%rdi
  710a47:	mov    %rbx,%rsi
  710a4a:	mov    %r15,%rdx
  710a4d:	lea    0xc0(%rsp),%rcx
  710a55:	lea    0x150(%rsp),%r8
  710a5d:	lea    0x3e0(%rsp),%r9
  710a65:	movss  0x9c(%rsp),%xmm2
  710a6e:	call   *0x331d44(%rip)        # a427b8 <_DYNAMIC+0x7c8>
  710a74:	jmp    710b10 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2f90>
  710a79:	movq   $0x0,0x218(%rsp)
  710a85:	jmp    710cd8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3158>
  710a8a:	movaps 0x1b0(%rsp),%xmm0
  710a92:	movaps %xmm0,0x150(%rsp)
  710a9a:	movss  0x148(%rsp),%xmm0
  710aa3:	movss  0x14c(%rsp),%xmm1
  710aac:	lea    0x2f0(%rsp),%rcx
  710ab4:	mov    0x10(%rcx),%rax
  710ab8:	mov    %rax,0xd0(%rsp)
  710ac0:	movups (%rcx),%xmm2
  710ac3:	movaps %xmm2,0xc0(%rsp)
  710acb:	movaps 0x8e0(%rsp),%xmm2
  710ad3:	movaps %xmm2,0xa0(%rsp)
  710adb:	lea    0x8f0(%rsp),%rdi
  710ae3:	mov    %rbx,%rsi
  710ae6:	mov    %r15,%rdx
  710ae9:	lea    0xc0(%rsp),%rcx
  710af1:	lea    0x150(%rsp),%r8
  710af9:	lea    0xa0(%rsp),%r9
  710b01:	movss  0x9c(%rsp),%xmm2
  710b0a:	call   *0x331cb0(%rip)        # a427c0 <_DYNAMIC+0x7d0>
  710b10:	cmp    $0xffffffff,%eax
  710b13:	jne    7122ae <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x472e>
  710b19:	cmp    $0x2,%r13b
  710b1d:	je     710cb8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3138>
  710b23:	mov    0x18c(%rsp),%eax
  710b2a:	cmp    0x1f0(%rsp),%eax
  710b31:	jne    710cb8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3138>
  710b37:	mov    0x658(%r14),%rax
  710b3e:	test   %rax,%rax
  710b41:	je     710cb8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3138>
  710b47:	cmp    0x620(%r14),%rax
  710b4e:	jne    710cb8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3138>
  710b54:	mov    0x50(%rsp),%rax
  710b59:	mov    (%rax),%rax
  710b5c:	cmp    %rax,0x660(%r14)
  710b63:	jne    710cb8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3138>
  710b69:	movzbl %r13b,%ecx
  710b6d:	lea    0xa0(%rsp),%rdi
  710b75:	mov    %r15,%rsi
  710b78:	mov    0x18c(%rsp),%edx
  710b7f:	call   *0x331adb(%rip)        # a42660 <_DYNAMIC+0x670>
  710b85:	movq   $0x18,0xc0(%rsp)
  710b91:	cmpl   $0x1,0xa0(%rsp)
  710b99:	jne    712369 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x47e9>
  710b9f:	lea    0xc0(%rsp),%rbx
  710ba7:	mov    %rbx,%rdi
  710baa:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  710baf:	movsd  0xa4(%rsp),%xmm0
  710bb8:	movaps 0x390(%rsp),%xmm1
  710bc0:	unpcklps 0x890(%rsp),%xmm1
  710bc8:	addps  %xmm0,%xmm1
  710bcb:	movhps 0xac(%rsp),%xmm1
  710bd3:	movups %xmm1,0x3e0(%rsp)
  710bdb:	mov    %rbx,%rdi
  710bde:	mov    0x48(%rsp),%rsi
  710be3:	mov    0x80(%rsp),%rdx
  710beb:	mov    $0x1,%ecx
  710bf0:	call   *0x331baa(%rip)        # a427a0 <_DYNAMIC+0x7b0>
  710bf6:	mov    0xd0(%rsp),%r9
  710bfe:	test   %r9,%r9
  710c01:	je     710c71 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x30f1>
  710c03:	movups 0xc0(%rsp),%xmm0
  710c0b:	movaps %xmm0,0x150(%rsp)
  710c13:	movaps 0x1b0(%rsp),%xmm0
  710c1b:	movaps %xmm0,0xa0(%rsp)
  710c23:	xorps  %xmm0,%xmm0
  710c26:	lea    0x8f0(%rsp),%rdi
  710c2e:	lea    0x3e0(%rsp),%rsi
  710c36:	lea    0xb00(%rsp),%rdx
  710c3e:	lea    0xa0(%rsp),%rcx
  710c46:	lea    0x150(%rsp),%r8
  710c4e:	call   *0x331b54(%rip)        # a427a8 <_DYNAMIC+0x7b8>
  710c54:	jmp    710caf <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x312f>
  710c56:	mov    $0x1,%r12b
  710c59:	cmp    $0x7,%eax
  710c5c:	je     710113 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2593>
  710c62:	jmp    712679 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4af9>
  710c67:	mov    $0xffffffff,%edi
  710c6c:	jmp    710679 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2af9>
  710c71:	movaps 0x1b0(%rsp),%xmm0
  710c79:	movaps %xmm0,0xc0(%rsp)
  710c81:	lea    0x8f0(%rsp),%rdi
  710c89:	lea    0x3e0(%rsp),%rsi
  710c91:	lea    0xb00(%rsp),%rdx
  710c99:	lea    0xc0(%rsp),%rcx
  710ca1:	lea    0x8e0(%rsp),%r8
  710ca9:	call   *0x331629(%rip)        # a422d8 <_DYNAMIC+0x2e8>
  710caf:	cmp    $0xffffffff,%eax
  710cb2:	jne    7122ae <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x472e>
  710cb8:	mov    0x318(%rsp),%rax
  710cc0:	mov    %rax,0x210(%rsp)
  710cc8:	mov    0x320(%rsp),%rax
  710cd0:	mov    %rax,0x218(%rsp)
  710cd8:	test   %bpl,%bpl
  710cdb:	je     710e38 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x32b8>
  710ce1:	mov    0x50(%rsp),%rax
  710ce6:	mov    0x20(%rax),%edi
  710ce9:	mov    $0x1,%r14b
  710cec:	call   *0x33175e(%rip)        # a42450 <_DYNAMIC+0x460>
  710cf2:	mov    %edx,%ebp
  710cf4:	cmp    $0x2,%dl
  710cf7:	je     710e38 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x32b8>
  710cfd:	mov    0x280(%rsp),%rcx
  710d05:	mov    (%rcx),%rcx
  710d08:	test   %rcx,%rcx
  710d0b:	je     712697 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b17>
  710d11:	mov    0x10(%rcx),%rsi
  710d15:	mov    %eax,%ebx
  710d17:	cmp    %rbx,%rsi
  710d1a:	jbe    712872 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4cf2>
  710d20:	mov    0x8(%rcx),%rax
  710d24:	movaps 0x8b0(%rsp),%xmm3
  710d2c:	movaps %xmm3,%xmm0
  710d2f:	shufps $0xe8,%xmm3,%xmm0
  710d33:	movaps 0x8c0(%rsp),%xmm5
  710d3b:	addps  %xmm0,%xmm5
  710d3e:	movaps 0x390(%rsp),%xmm4
  710d46:	movaps %xmm4,%xmm1
  710d49:	shufps $0xe8,%xmm4,%xmm1
  710d4d:	movaps 0x2b0(%rsp),%xmm2
  710d55:	subps  %xmm1,%xmm2
  710d58:	addps  %xmm5,%xmm1
  710d5b:	shufps $0xed,%xmm4,%xmm4
  710d5f:	subps  %xmm4,%xmm2
  710d62:	subps  %xmm0,%xmm2
  710d65:	shufps $0xed,%xmm3,%xmm3
  710d69:	subps  %xmm3,%xmm2
  710d6c:	subps  0x8a0(%rsp),%xmm2
  710d74:	movlhps %xmm2,%xmm1
  710d77:	movups %xmm1,0x330(%rsp)
  710d7f:	testb  $0x1,0x2ec(%rsp)
  710d87:	movl   $0x1,0xc8(%rsp)
  710d92:	movq   $0x23,0xc0(%rsp)
  710d9e:	je     7122fe <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x477e>
  710da4:	lea    (%rax,%rbx,8),%rbx
  710da8:	lea    0xc0(%rsp),%r15
  710db0:	mov    %r15,%rdi
  710db3:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  710db8:	lea    0x2f0(%rsp),%rcx
  710dc0:	movups (%rcx),%xmm0
  710dc3:	movaps %xmm0,0x150(%rsp)
  710dcb:	mov    0x10(%rcx),%rax
  710dcf:	mov    %rax,0x160(%rsp)
  710dd7:	movups (%rcx),%xmm0
  710dda:	movaps %xmm0,0xbb0(%rsp)
  710de2:	mov    0x10(%rcx),%rax
  710de6:	mov    %rax,0xbc0(%rsp)
  710dee:	movaps 0x1b0(%rsp),%xmm0
  710df6:	movaps %xmm0,0xc0(%rsp)
  710dfe:	movzbl %bpl,%r9d
  710e02:	lea    0x8f0(%rsp),%rdi
  710e0a:	mov    %rbx,%rsi
  710e0d:	lea    0x330(%rsp),%rdx
  710e15:	lea    0xbb0(%rsp),%rcx
  710e1d:	mov    %r15,%r8
  710e20:	movss  0x128(%rsp),%xmm0
  710e29:	call   *0x331999(%rip)        # a427c8 <_DYNAMIC+0x7d8>
  710e2f:	cmp    $0xffffffff,%eax
  710e32:	jne    712334 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x47b4>
  710e38:	mov    0x50(%rsp),%rax
  710e3d:	mov    0x18(%rax),%ebx
  710e40:	cmpb   $0x0,0x37(%rsp)
  710e45:	je     710e6f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x32ef>
  710e47:	cmp    $0xffffffff,%ebx
  710e4a:	je     710e6a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x32ea>
  710e4c:	mov    0x180(%rsp),%rsi
  710e54:	cmp    %rbx,%rsi
  710e57:	jbe    712863 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4ce3>
  710e5d:	mov    0x178(%rsp),%rax
  710e65:	mov    (%rax,%rbx,4),%ebx
  710e68:	jmp    710e6f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x32ef>
  710e6a:	mov    $0xffffffff,%ebx
  710e6f:	cmpb   $0x0,0x110(%rsp)
  710e77:	je     710ea4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3324>
  710e79:	movss  0x2c8(%rsp),%xmm0
  710e82:	xorps  %xmm1,%xmm1
  710e85:	ucomiss %xmm1,%xmm0
  710e88:	jne    710e90 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3310>
  710e8a:	jnp    710fd9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3459>
  710e90:	movss  0x2cc(%rsp),%xmm0
  710e99:	ucomiss %xmm1,%xmm0
  710e9c:	jne    710ea4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3324>
  710e9e:	jnp    710fd9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3459>
  710ea4:	mov    0x50(%rsp),%rax
  710ea9:	mov    0x20(%rax),%edi
  710eac:	mov    $0x1,%r14b
  710eaf:	call   6f81d0 <<gpui::runtime::Node>::kind>
  710eb4:	cmp    $0x7,%al
  710eb6:	jne    710ed0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3350>
  710eb8:	mov    0x50(%rsp),%rax
  710ebd:	mov    (%rax),%rsi
  710ec0:	mov    $0x1,%r14b
  710ec3:	lea    0x378(%rsp),%rdi
  710ecb:	call   6fc490 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  710ed0:	cmpb   $0x0,0x37(%rsp)
  710ed5:	je     710f28 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x33a8>
  710ed7:	mov    0x1e8(%rsp),%rsi
  710edf:	mov    $0x1,%edi
  710ee4:	mov    $0x1,%r14b
  710ee7:	call   *0x3313ab(%rip)        # a42298 <_DYNAMIC+0x2a8>
  710eed:	mov    %eax,%ebp
  710eef:	mov    0x180(%rsp),%r15
  710ef7:	cmp    0x170(%rsp),%r15
  710eff:	jne    710f11 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3391>
  710f01:	mov    $0x1,%r14b
  710f04:	lea    0x170(%rsp),%rdi
  710f0c:	call   6f4820 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  710f11:	mov    0x178(%rsp),%rax
  710f19:	mov    %ebp,(%rax,%r15,4)
  710f1d:	inc    %r15
  710f20:	mov    %r15,0x180(%rsp)
  710f28:	movss  0x2c8(%rsp),%xmm0
  710f31:	xor    %edx,%edx
  710f33:	xorps  %xmm1,%xmm1
  710f36:	ucomiss %xmm1,%xmm0
  710f39:	jne    710f41 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x33c1>
  710f3b:	jnp    71109f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x351f>
  710f41:	movss  0x2cc(%rsp),%xmm0
  710f4a:	ucomiss %xmm1,%xmm0
  710f4d:	mov    $0x0,%r8d
  710f53:	mov    0x50(%rsp),%rsi
  710f58:	jne    710f60 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x33e0>
  710f5a:	jnp    7110a2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3522>
  710f60:	mov    0x20(%rsi),%edi
  710f63:	mov    %edi,%eax
  710f65:	and    $0xf,%eax
  710f68:	cmp    $0x9,%eax
  710f6b:	ja     712726 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4ba6>
  710f71:	cmp    $0x6,%eax
  710f74:	je     710f82 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3402>
  710f76:	mov    $0x1,%r8b
  710f79:	cmp    $0xf,%edi
  710f7c:	ja     7110a2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3522>
  710f82:	mov    0x4e8(%rsp),%eax
  710f89:	mov    $0x3fffffff,%ecx
  710f8e:	and    %ecx,%eax
  710f90:	cmp    $0x3f800001,%eax
  710f95:	mov    $0x80000000,%ecx
  710f9a:	cmove  %ecx,%eax
  710f9d:	movd   %eax,%xmm0
  710fa1:	mov    $0x1,%r8b
  710fa4:	ucomiss %xmm1,%xmm0
  710fa7:	ja     7110a2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3522>
  710fad:	cmpq   $0x0,0x8(%rsi)
  710fb2:	jne    7110a2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3522>
  710fb8:	mov    $0x1,%r14b
  710fbb:	call   6f81d0 <<gpui::runtime::Node>::kind>
  710fc0:	lea    -0x4(%rax),%ecx
  710fc3:	cmp    $0x2,%al
  710fc5:	setae  %al
  710fc8:	test   $0xfb,%cl
  710fcb:	sete   %r8b
  710fcf:	and    %al,%r8b
  710fd2:	xor    %edx,%edx
  710fd4:	jmp    7110a2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3522>
  710fd9:	cmpb   $0x0,0x1f4(%rsp)
  710fe1:	je     71100b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x348b>
  710fe3:	movss  0x258(%rsp),%xmm0
  710fec:	ucomiss %xmm1,%xmm0
  710fef:	jne    710ff3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3473>
  710ff1:	jnp    71100b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x348b>
  710ff3:	movss  0x25c(%rsp),%xmm0
  710ffc:	ucomiss %xmm1,%xmm0
  710fff:	jne    710ea4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3324>
  711005:	jp     710ea4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3324>
  71100b:	test   %r12b,%r12b
  71100e:	je     711038 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x34b8>
  711010:	movss  0x258(%rsp),%xmm0
  711019:	ucomiss %xmm1,%xmm0
  71101c:	jne    711020 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x34a0>
  71101e:	jnp    711038 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x34b8>
  711020:	movss  0x25c(%rsp),%xmm0
  711029:	ucomiss %xmm1,%xmm0
  71102c:	jne    710ea4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3324>
  711032:	jp     710ea4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3324>
  711038:	mov    0x180(%rsp),%r15
  711040:	cmp    0x170(%rsp),%r15
  711048:	jne    71105a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x34da>
  71104a:	mov    $0x1,%r14b
  71104d:	lea    0x170(%rsp),%rdi
  711055:	call   6f4820 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  71105a:	mov    0x178(%rsp),%rax
  711062:	mov    %ebx,(%rax,%r15,4)
  711066:	inc    %r15
  711069:	mov    %r15,0x180(%rsp)
  711071:	mov    0x218(%rsp),%rax
  711079:	test   %rax,%rax
  71107c:	je     70f780 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1c00>
  711082:	lock decq (%rax)
  711086:	jne    70f780 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1c00>
  71108c:	lea    0x218(%rsp),%rdi
  711094:	call   *0x33129e(%rip)        # a42338 <_DYNAMIC+0x348>
  71109a:	jmp    70f780 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1c00>
  71109f:	xor    %r8d,%r8d
  7110a2:	mov    0x1e8(%rsp),%rax
  7110aa:	test   %rax,%rax
  7110ad:	je     7110c4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3544>
  7110af:	mov    0x1e0(%rsp),%rcx
  7110b7:	shl    $0x6,%rax
  7110bb:	mov    -0x8(%rcx,%rax,1),%ecx
  7110bf:	mov    $0x1,%edx
  7110c4:	mov    %r8d,%ebp
  7110c7:	mov    %r8d,%eax
  7110ca:	xor    $0x1,%al
  7110cc:	movzbl %al,%esi
  7110cf:	mov    $0x1,%r14b
  7110d2:	mov    %ebx,%edi
  7110d4:	call   *0x3316f6(%rip)        # a427d0 <_DYNAMIC+0x7e0>
  7110da:	mov    %eax,0x110(%rsp)
  7110e1:	mov    0x218(%rsp),%rax
  7110e9:	test   %rax,%rax
  7110ec:	sete   %r12b
  7110f0:	je     711132 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x35b2>
  7110f2:	mov    0x1e8(%rsp),%ecx
  7110f9:	mov    %ecx,0xd0(%rsp)
  711100:	movsd  0x210(%rsp),%xmm0
  711109:	movsd  %xmm0,0xc8(%rsp)
  711112:	mov    %rax,0xc0(%rsp)
  71111a:	xor    %r14d,%r14d
  71111d:	lea    0x288(%rsp),%rdi
  711125:	lea    0xc0(%rsp),%rsi
  71112d:	call   6f7b00 <<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>::push_mut>
  711132:	cmp    $0xffffffff,%ebx
  711135:	mov    %r12b,0x80(%rsp)
  71113d:	je     711172 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x35f2>
  71113f:	mov    %ebx,%edi
  711141:	mov    0x1e8(%rsp),%rsi
  711149:	cmp    %rdi,%rsi
  71114c:	jbe    71282f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4caf>
  711152:	mov    0x1e0(%rsp),%rax
  71115a:	shl    $0x6,%rdi
  71115e:	mov    0x30(%rax,%rdi,1),%rax
  711163:	mov    %rax,0xc4(%rsp)
  71116b:	mov    $0x1,%eax
  711170:	jmp    711174 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x35f4>
  711172:	xor    %eax,%eax
  711174:	mov    %eax,0xc0(%rsp)
  71117b:	mov    %r12d,%r14d
  71117e:	lea    0x2ec(%rsp),%rdi
  711186:	lea    0xc0(%rsp),%rsi
  71118e:	lea    0x2d0(%rsp),%rdx
  711196:	call   *0x33163c(%rip)        # a427d8 <_DYNAMIC+0x7e8>
  71119c:	mov    %rax,%rbx
  71119f:	mov    0x50(%rsp),%rax
  7111a4:	mov    (%rax),%r13
  7111a7:	mov    0x20(%rax),%edi
  7111aa:	mov    %r12d,%r14d
  7111ad:	call   6f81d0 <<gpui::runtime::Node>::kind>
  7111b2:	mov    %eax,%r15d
  7111b5:	mov    0x50(%rsp),%rax
  7111ba:	mov    0x20(%rax),%edi
  7111bd:	mov    %edi,%eax
  7111bf:	and    $0xf,%eax
  7111c2:	cmp    $0x9,%eax
  7111c5:	ja     7126c3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b43>
  7111cb:	cmp    $0x6,%eax
  7111ce:	mov    0x38(%rsp),%rax
  7111d3:	je     7113b0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3830>
  7111d9:	shr    $0x4,%edi
  7111dc:	dec    %edi
  7111de:	mov    0x320(%rax),%rsi
  7111e5:	mov    0x328(%rax),%rdx
  7111ec:	mov    %r12d,%r14d
  7111ef:	call   6f8070 <<gpui::runtime::TextSlot>::get>
  7111f4:	test   %rax,%rax
  7111f7:	je     71122f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x36af>
  7111f9:	mov    0x40(%rax),%r12
  7111fd:	testb  $0x1,(%r12)
  711202:	jne    711232 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x36b2>
  711204:	mov    0x8(%r12),%rax
  711209:	test   $0x1,%al
  71120b:	jne    711232 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x36b2>
  71120d:	mov    $0x2,%eax
  711212:	lock xadd %rax,0x8(%r12)
  711219:	and    0x7e8(%rsp),%rax
  711221:	neg    %rax
  711224:	jno    711232 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x36b2>
  711226:	lock orq $0x1,0x8(%r12)
  71122d:	jmp    711232 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x36b2>
  71122f:	xor    %r12d,%r12d
  711232:	movdqa 0x2b0(%rsp),%xmm0
  71123b:	movd   %xmm0,%esi
  71123f:	shufps $0x55,%xmm0,%xmm0
  711243:	movd   %xmm0,%eax
  711247:	shl    $0x20,%rax
  71124b:	or     %rax,%rsi
  71124e:	lea    0xa0(%rsp),%rdi
  711256:	lea    0x2ec(%rsp),%rdx
  71125e:	call   *0x33157c(%rip)        # a427e0 <_DYNAMIC+0x7f0>
  711264:	mov    0x50(%rsp),%r14
  711269:	mov    0x20(%r14),%edi
  71126d:	call   6f81d0 <<gpui::runtime::Node>::kind>
  711272:	xor    %esi,%esi
  711274:	cmpq   $0x0,0x8(%r14)
  711279:	setne  %sil
  71127d:	movzbl %al,%edi
  711280:	call   6f7e20 <<gpui::runtime::semantics::Actions>::for_node>
  711285:	mov    0x18(%r14),%ecx
  711289:	mov    $0xffffffff,%edx
  71128e:	cmp    %rdx,%rcx
  711291:	je     7112b7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3737>
  711293:	cmp    %rcx,0x1a8(%rsp)
  71129b:	jbe    7112b7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3737>
  71129d:	mov    0x1a0(%rsp),%rdx
  7112a5:	cmpb   $0x0,(%rdx,%rcx,1)
  7112a9:	setne  %cl
  7112ac:	mov    0x190(%rsp),%edx
  7112b3:	or     %cl,%dl
  7112b5:	jmp    7112be <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x373e>
  7112b7:	mov    0x190(%rsp),%edx
  7112be:	movzbl %al,%ecx
  7112c1:	or     $0x20,%al
  7112c3:	movzbl %al,%eax
  7112c6:	test   %dl,%dl
  7112c8:	cmove  %ecx,%eax
  7112cb:	mov    %r13,0xe0(%rsp)
  7112d3:	mov    0x110(%rsp),%ecx
  7112da:	mov    %ecx,0xf8(%rsp)
  7112e1:	mov    %r15b,0xfd(%rsp)
  7112e9:	mov    %r12,0xe8(%rsp)
  7112f1:	movups 0xa0(%rsp),%xmm0
  7112f9:	movaps %xmm0,0xc0(%rsp)
  711301:	mov    %rbx,0xf0(%rsp)
  711309:	movups 0x2c0(%rsp),%xmm0
  711311:	lea    0xc4(%rsp),%rcx
  711319:	movups %xmm0,0xc(%rcx)
  71131d:	mov    %bpl,0xfe(%rsp)
  711325:	mov    %al,0xfc(%rsp)
  71132c:	movzbl 0x80(%rsp),%ebp
  711334:	mov    %ebp,%r14d
  711337:	lea    0x1d8(%rsp),%rdi
  71133f:	lea    0xc0(%rsp),%rsi
  711347:	call   6f7a80 <<alloc::vec::Vec<gpui::runtime::Presented>>::push_mut>
  71134c:	cmpl   $0xffffffff,0x780(%rsp)
  711354:	je     70f780 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1c00>
  71135a:	mov    0x138(%rsp),%rax
  711362:	mov    (%rax),%rbx
  711365:	test   %rbx,%rbx
  711368:	je     70f780 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1c00>
  71136e:	mov    0x50(%rsp),%rax
  711373:	mov    (%rax),%r15
  711376:	mov    0x38(%rsp),%rax
  71137b:	mov    0x6a0(%rax),%rdi
  711382:	mov    0x6a8(%rax),%rsi
  711389:	mov    %r15,%rdx
  71138c:	call   6be4a0 <<alloc::collections::btree::map::BTreeMap<u64, gpui::runtime::list::ListRow>>::get::<u64>>
  711391:	mov    %ebp,%r14d
  711394:	lea    0x780(%rsp),%rdi
  71139c:	mov    %rbx,%rsi
  71139f:	mov    %r15,%rdx
  7113a2:	mov    %rax,%rcx
  7113a5:	call   *0x3312bd(%rip)        # a42668 <_DYNAMIC+0x678>
  7113ab:	jmp    70f780 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1c00>
  7113b0:	mov    $0xffffffff,%edi
  7113b5:	jmp    7111de <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x365e>
  7113ba:	cmpl   $0xffffffff,0x780(%rsp)
  7113c2:	je     7113d2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3852>
  7113c4:	lea    0x780(%rsp),%rdi
  7113cc:	call   *0x33129e(%rip)        # a42670 <_DYNAMIC+0x680>
  7113d2:	lea    0x1e8(%r14),%rbx
  7113d9:	mov    0x680(%r14),%rax
  7113e0:	test   %rax,%rax
  7113e3:	je     7114c7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3947>
  7113e9:	mov    0x100(%rax),%rdx
  7113f0:	lea    0x2d0(%rsp),%rax
  7113f8:	mov    %rax,0x4b0(%rsp)
  711400:	lea    0x37(%rsp),%rax
  711405:	mov    %rax,0x4b8(%rsp)
  71140d:	mov    %rbx,0x4c0(%rsp)
  711415:	lea    0x170(%rsp),%rax
  71141d:	mov    %rax,0x4c8(%rsp)
  711425:	lea    0x1d8(%rsp),%rax
  71142d:	mov    %rax,0x4d0(%rsp)
  711435:	test   %rdx,%rdx
  711438:	je     7114c7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3947>
  71143e:	lea    0xc0(%rsp),%rdi
  711446:	lea    0x4b0(%rsp),%rsi
  71144e:	call   6db200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}>
  711453:	mov    0xd0(%rsp),%rax
  71145b:	mov    %rax,0x480(%rsp)
  711463:	movups 0xc0(%rsp),%xmm0
  71146b:	movaps %xmm0,0x470(%rsp)
  711473:	jmp    7114d3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3953>
  711475:	movaps 0x8f0(%rsp),%xmm0
  71147d:	movaps 0x900(%rsp),%xmm1
  711485:	movaps 0x910(%rsp),%xmm2
  71148d:	mov    0x40(%rsp),%rcx
  711492:	movups %xmm2,0x28(%rcx)
  711496:	movups %xmm1,0x18(%rcx)
  71149a:	movups %xmm0,0x8(%rcx)
  71149e:	mov    %rax,(%rcx)
  7114a1:	mov    $0x1,%r12b
  7114a4:	mov    $0x1,%al
  7114a6:	mov    %eax,0x50(%rsp)
  7114aa:	mov    $0x1,%r13b
  7114ad:	mov    $0x1,%bpl
  7114b0:	mov    $0x1,%r15b
  7114b3:	cmpq   $0xffffffffffffffff,0x278(%rsp)
  7114bc:	jne    7123ea <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x486a>
  7114c2:	jmp    7123fa <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x487a>
  7114c7:	movq   $0xffffffffffffffff,0x470(%rsp)
  7114d3:	mov    %rbx,0x2b0(%rsp)
  7114db:	mov    0x2e0(%rsp),%rax
  7114e3:	mov    %rax,0x4c0(%rsp)
  7114eb:	movups 0x2d0(%rsp),%xmm0
  7114f3:	movaps %xmm0,0x4b0(%rsp)
  7114fb:	lea    0xa0(%rsp),%rdi
  711503:	lea    0x470(%rsp),%rsi
  71150b:	lea    0x4b0(%rsp),%rdx
  711513:	call   6b6600 <<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#37}>>
  711518:	cmpb   $0x0,0x78d(%r14)
  711520:	je     71157d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x39fd>
  711522:	lea    0x4b0(%rsp),%rbx
  71152a:	lea    0x8f0(%rsp),%rsi
  711532:	mov    $0x1f0,%edx
  711537:	mov    %rbx,%rdi
  71153a:	call   *0x330d38(%rip)        # a42278 <memcpy@GLIBC_2.14>
  711540:	mov    $0x1,%al
  711542:	mov    %eax,0x68(%rsp)
  711546:	mov    $0x1,%r12b
  711549:	mov    $0x1,%al
  71154b:	mov    %eax,0x70(%rsp)
  71154f:	mov    $0x1,%al
  711551:	mov    %eax,0x50(%rsp)
  711555:	mov    $0x1,%r15b
  711558:	mov    $0x1,%bpl
  71155b:	movb   $0x1,0x80(%rsp)
  711563:	mov    %rbx,%rdi
  711566:	call   *0x33127c(%rip)        # a427e8 <_DYNAMIC+0x7f8>
  71156c:	movq   $0x0,0x110(%rsp)
  711578:	jmp    711610 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3a90>
  71157d:	lea    0x4b0(%rsp),%rbx
  711585:	lea    0x8f0(%rsp),%rsi
  71158d:	mov    $0x1f0,%edx
  711592:	mov    %rbx,%rdi
  711595:	call   *0x330cdd(%rip)        # a42278 <memcpy@GLIBC_2.14>
  71159b:	mov    $0x1,%al
  71159d:	mov    %eax,0x68(%rsp)
  7115a1:	mov    $0x1,%r12b
  7115a4:	mov    $0x1,%al
  7115a6:	mov    %eax,0x70(%rsp)
  7115aa:	mov    $0x1,%al
  7115ac:	mov    %eax,0x50(%rsp)
  7115b0:	mov    $0x1,%r15b
  7115b3:	mov    $0x1,%bpl
  7115b6:	movb   $0x1,0x80(%rsp)
  7115be:	mov    %rbx,%rdi
  7115c1:	call   *0x331229(%rip)        # a427f0 <_DYNAMIC+0x800>
  7115c7:	cmpq   $0xffffffffffffffff,0x5f8(%r14)
  7115cf:	je     7115da <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3a5a>
  7115d1:	mov    0x610(%r14),%rsi
  7115d8:	jmp    7115dc <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3a5c>
  7115da:	xor    %esi,%esi
  7115dc:	mov    $0x1,%cl
  7115de:	mov    %ecx,0x68(%rsp)
  7115e2:	mov    $0x1,%r12b
  7115e5:	mov    $0x1,%cl
  7115e7:	mov    %ecx,0x70(%rsp)
  7115eb:	mov    $0x1,%cl
  7115ed:	mov    %ecx,0x50(%rsp)
  7115f1:	mov    $0x1,%r15b
  7115f4:	mov    $0x1,%bpl
  7115f7:	movb   $0x1,0x80(%rsp)
  7115ff:	mov    %rax,%rdi
  711602:	call   *0x331038(%rip)        # a42640 <_DYNAMIC+0x650>
  711608:	mov    %rax,0x110(%rsp)
  711610:	mov    0x688(%r14),%rax
  711617:	mov    0x698(%r14),%r12
  71161e:	test   %rax,%rax
  711621:	setne  %cl
  711624:	test   %r12,%r12
  711627:	setne  %dl
  71162a:	test   %dl,%cl
  71162c:	je     71181e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3c9e>
  711632:	mov    0x38(%rsp),%rcx
  711637:	mov    0x690(%rcx),%r13
  71163e:	xor    %r14d,%r14d
  711641:	lea    0x4b0(%rsp),%rbx
  711649:	lea    0x3a0(%rsp),%r15
  711651:	jmp    711661 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3ae1>
  711653:	mov    $0x0,%eax
  711658:	dec    %r12
  71165b:	je     71181e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3c9e>
  711661:	test   %r14,%r14
  711664:	jne    7116e8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3b68>
  71166a:	test   %r13,%r13
  71166d:	je     711697 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3b17>
  71166f:	mov    %r13,%rcx
  711672:	mov    %rax,%r14
  711675:	and    $0x7,%rcx
  711679:	je     71169c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3b1c>
  71167b:	xor    %edx,%edx
  71167d:	nopl   (%rax)
  711680:	mov    0x590(%r14),%r14
  711687:	inc    %rdx
  71168a:	cmp    %rdx,%rcx
  71168d:	jne    711680 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3b00>
  71168f:	mov    %r13,%rax
  711692:	sub    %rdx,%rax
  711695:	jmp    71169f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3b1f>
  711697:	mov    %rax,%r14
  71169a:	jmp    7116e3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3b63>
  71169c:	mov    %r13,%rax
  71169f:	cmp    $0x8,%r13
  7116a3:	jb     7116e3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3b63>
  7116a5:	mov    0x590(%r14),%rcx
  7116ac:	mov    0x590(%rcx),%rcx
  7116b3:	mov    0x590(%rcx),%rcx
  7116ba:	mov    0x590(%rcx),%rcx
  7116c1:	mov    0x590(%rcx),%rcx
  7116c8:	mov    0x590(%rcx),%rcx
  7116cf:	mov    0x590(%rcx),%rcx
  7116d6:	mov    0x590(%rcx),%r14
  7116dd:	add    $0xfffffffffffffff8,%rax
  7116e1:	jne    7116a5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3b25>
  7116e3:	xor    %r13d,%r13d
  7116e6:	xor    %eax,%eax
  7116e8:	movzwl 0x58a(%r14),%ecx
  7116f0:	cmp    %rcx,%r13
  7116f3:	jae    711700 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3b80>
  7116f5:	mov    %r13,%rdx
  7116f8:	mov    %r14,%rcx
  7116fb:	jmp    711727 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3ba7>
  7116fd:	nopl   (%rax)
  711700:	mov    0x580(%r14),%rcx
  711707:	test   %rcx,%rcx
  71170a:	je     7126ed <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b6d>
  711710:	inc    %rax
  711713:	movzwl 0x588(%r14),%edx
  71171b:	mov    %rcx,%r14
  71171e:	cmp    0x58a(%rcx),%dx
  711725:	jae    711700 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3b80>
  711727:	test   %rax,%rax
  71172a:	je     71176a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3bea>
  71172c:	lea    (%rcx,%rdx,8),%rsi
  711730:	add    $0x598,%rsi
  711737:	mov    %rax,%rdi
  71173a:	and    $0x7,%rdi
  71173e:	je     711773 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3bf3>
  711740:	xor    %r8d,%r8d
  711743:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  711750:	mov    (%rsi),%r14
  711753:	lea    0x590(%r14),%rsi
  71175a:	inc    %r8
  71175d:	cmp    %r8,%rdi
  711760:	jne    711750 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3bd0>
  711762:	mov    %rax,%rdi
  711765:	sub    %r8,%rdi
  711768:	jmp    711776 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3bf6>
  71176a:	lea    0x1(%rdx),%r13
  71176e:	mov    %rcx,%r14
  711771:	jmp    7117c4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3c44>
  711773:	mov    %rax,%rdi
  711776:	cmp    $0x8,%rax
  71177a:	jb     7117c1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3c41>
  71177c:	nopl   0x0(%rax)
  711780:	mov    (%rsi),%rax
  711783:	mov    0x590(%rax),%rax
  71178a:	mov    0x590(%rax),%rax
  711791:	mov    0x590(%rax),%rax
  711798:	mov    0x590(%rax),%rax
  71179f:	mov    0x590(%rax),%rax
  7117a6:	mov    0x590(%rax),%rax
  7117ad:	mov    0x590(%rax),%r14
  7117b4:	lea    0x590(%r14),%rsi
  7117bb:	add    $0xfffffffffffffff8,%rdi
  7117bf:	jne    711780 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3c00>
  7117c1:	xor    %r13d,%r13d
  7117c4:	mov    %rdx,%rax
  7117c7:	shl    $0x4,%rax
  7117cb:	cmpl   $0x1,(%rcx,%rax,1)
  7117cf:	jne    711653 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3ad3>
  7117d5:	imul   $0x70,%rdx,%rdx
  7117d9:	lea    (%rcx,%rdx,1),%rbp
  7117dd:	add    $0xb0,%rbp
  7117e4:	cmpl   $0x2,0x0(%rbp)
  7117e8:	jne    711653 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3ad3>
  7117ee:	mov    0x8(%rcx,%rax,1),%rdx
  7117f3:	mov    %rbx,%rdi
  7117f6:	mov    %r15,%rsi
  7117f9:	call   *0x330f71(%rip)        # a42770 <_DYNAMIC+0x780>
  7117ff:	cmpl   $0x1,0x4b0(%rsp)
  711807:	jne    711653 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3ad3>
  71180d:	movups 0x4b8(%rsp),%xmm0
  711815:	movups %xmm0,0x8(%rbp)
  711819:	jmp    711653 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3ad3>
  71181e:	mov    0x38(%rsp),%r14
  711823:	mov    0x6a0(%r14),%r8
  71182a:	mov    0x6b0(%r14),%rax
  711831:	test   %r8,%r8
  711834:	setne  %cl
  711837:	test   %rax,%rax
  71183a:	setne  %dl
  71183d:	test   %dl,%cl
  71183f:	mov    0x310(%rsp),%rbx
  711847:	mov    0x280(%rsp),%r13
  71184f:	je     711a7d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3efd>
  711855:	mov    0x6a8(%r14),%rsi
  71185c:	xor    %ecx,%ecx
  71185e:	jmp    711888 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3d08>
  711860:	mov    $0x1,%r8b
  711863:	mov    0x38(%rsp),%r14
  711868:	mov    %r15,%rbx
  71186b:	dec    %rax
  71186e:	shl    $0x5,%rdi
  711872:	add    %rdi,%rdx
  711875:	mov    %r8b,0x1c(%rdx)
  711879:	mov    $0x0,%r8d
  71187f:	test   %rax,%rax
  711882:	je     711a7d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3efd>
  711888:	test   %rcx,%rcx
  71188b:	jne    711918 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3d98>
  711891:	test   %rsi,%rsi
  711894:	je     7118c7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3d47>
  711896:	mov    %rsi,%rdx
  711899:	mov    %r8,%rcx
  71189c:	and    $0x7,%rdx
  7118a0:	je     7118cc <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3d4c>
  7118a2:	xor    %edi,%edi
  7118a4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  7118b0:	mov    0x1c8(%rcx),%rcx
  7118b7:	inc    %rdi
  7118ba:	cmp    %rdi,%rdx
  7118bd:	jne    7118b0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3d30>
  7118bf:	mov    %rsi,%rdx
  7118c2:	sub    %rdi,%rdx
  7118c5:	jmp    7118cf <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3d4f>
  7118c7:	mov    %r8,%rcx
  7118ca:	jmp    711913 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3d93>
  7118cc:	mov    %rsi,%rdx
  7118cf:	cmp    $0x8,%rsi
  7118d3:	jb     711913 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3d93>
  7118d5:	mov    0x1c8(%rcx),%rcx
  7118dc:	mov    0x1c8(%rcx),%rcx
  7118e3:	mov    0x1c8(%rcx),%rcx
  7118ea:	mov    0x1c8(%rcx),%rcx
  7118f1:	mov    0x1c8(%rcx),%rcx
  7118f8:	mov    0x1c8(%rcx),%rcx
  7118ff:	mov    0x1c8(%rcx),%rcx
  711906:	mov    0x1c8(%rcx),%rcx
  71190d:	add    $0xfffffffffffffff8,%rdx
  711911:	jne    7118d5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3d55>
  711913:	xor    %esi,%esi
  711915:	xor    %r8d,%r8d
  711918:	movzwl 0x1c2(%rcx),%edx
  71191f:	cmp    %rdx,%rsi
  711922:	jae    711930 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3db0>
  711924:	mov    %rsi,%rdi
  711927:	mov    %rcx,%rdx
  71192a:	jmp    711956 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3dd6>
  71192c:	nopl   0x0(%rax)
  711930:	mov    0x160(%rcx),%rdx
  711937:	test   %rdx,%rdx
  71193a:	je     7126ff <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b7f>
  711940:	inc    %r8
  711943:	movzwl 0x1c0(%rcx),%edi
  71194a:	mov    %rdx,%rcx
  71194d:	cmp    0x1c2(%rdx),%di
  711954:	jae    711930 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3db0>
  711956:	test   %r8,%r8
  711959:	je     71199a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3e1a>
  71195b:	lea    (%rdx,%rdi,8),%rsi
  71195f:	add    $0x1d0,%rsi
  711966:	mov    %r8,%r9
  711969:	and    $0x7,%r9
  71196d:	je     7119a3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3e23>
  71196f:	xor    %r10d,%r10d
  711972:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  711980:	mov    (%rsi),%rcx
  711983:	lea    0x1c8(%rcx),%rsi
  71198a:	inc    %r10
  71198d:	cmp    %r10,%r9
  711990:	jne    711980 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3e00>
  711992:	mov    %r8,%r9
  711995:	sub    %r10,%r9
  711998:	jmp    7119a6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3e26>
  71199a:	lea    0x1(%rdi),%rsi
  71199e:	mov    %rdx,%rcx
  7119a1:	jmp    7119f3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3e73>
  7119a3:	mov    %r8,%r9
  7119a6:	cmp    $0x8,%r8
  7119aa:	jb     7119f1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3e71>
  7119ac:	nopl   0x0(%rax)
  7119b0:	mov    (%rsi),%rcx
  7119b3:	mov    0x1c8(%rcx),%rcx
  7119ba:	mov    0x1c8(%rcx),%rcx
  7119c1:	mov    0x1c8(%rcx),%rcx
  7119c8:	mov    0x1c8(%rcx),%rcx
  7119cf:	mov    0x1c8(%rcx),%rcx
  7119d6:	mov    0x1c8(%rcx),%rcx
  7119dd:	mov    0x1c8(%rcx),%rcx
  7119e4:	lea    0x1c8(%rcx),%rsi
  7119eb:	add    $0xfffffffffffffff8,%r9
  7119ef:	jne    7119b0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3e30>
  7119f1:	xor    %esi,%esi
  7119f3:	mov    0x378(%rsp),%r8
  7119fb:	test   %r8,%r8
  7119fe:	je     711a75 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3ef5>
  711a00:	mov    %rbx,%r15
  711a03:	mov    0x168(%rdx,%rdi,8),%r9
  711a0b:	mov    0x380(%rsp),%r10
  711a13:	movzwl 0x62(%r8),%ebx
  711a18:	mov    %ebx,%r14d
  711a1b:	shl    $0x3,%r14d
  711a1f:	mov    $0xffffffffffffffff,%r11
  711a26:	cs nopw 0x0(%rax,%rax,1)
  711a30:	test   %r14,%r14
  711a33:	je     711a5d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3edd>
  711a35:	cmp    0x10(%r8,%r11,8),%r9
  711a3a:	seta   %bpl
  711a3e:	sbb    $0x0,%bpl
  711a42:	inc    %r11
  711a45:	add    $0xfffffffffffffff8,%r14
  711a49:	cmp    $0x1,%bpl
  711a4d:	je     711a30 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3eb0>
  711a4f:	movzbl %bpl,%ebx
  711a53:	test   %ebx,%ebx
  711a55:	je     711860 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3ce0>
  711a5b:	jmp    711a60 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3ee0>
  711a5d:	mov    %rbx,%r11
  711a60:	mov    0x38(%rsp),%r14
  711a65:	mov    %r15,%rbx
  711a68:	sub    $0x1,%r10
  711a6c:	jb     711a75 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3ef5>
  711a6e:	mov    0x68(%r8,%r11,8),%r8
  711a73:	jmp    711a13 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3e93>
  711a75:	xor    %r8d,%r8d
  711a78:	jmp    71186b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3ceb>
  711a7d:	cmpl   $0x2,0xc10(%rsp)
  711a85:	mov    $0x1,%bpl
  711a88:	je     711ac5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3f45>
  711a8a:	lea    0x4b0(%rsp),%rdi
  711a92:	lea    0xc10(%rsp),%rsi
  711a9a:	mov    $0x1e8,%edx
  711a9f:	call   *0x3307d3(%rip)        # a42278 <memcpy@GLIBC_2.14>
  711aa5:	mov    %r14,%rdi
  711aa8:	call   6c6030 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  711aad:	lea    0x4b0(%rsp),%rsi
  711ab5:	mov    $0x1e8,%edx
  711aba:	mov    %r14,%rdi
  711abd:	call   *0x3307b5(%rip)        # a42278 <memcpy@GLIBC_2.14>
  711ac3:	xor    %ebp,%ebp
  711ac5:	mov    $0x1,%al
  711ac7:	mov    %eax,0x68(%rsp)
  711acb:	cmpl   $0xffffffff,0x780(%rsp)
  711ad3:	mov    $0x1,%al
  711ad5:	mov    %eax,0x50(%rsp)
  711ad9:	je     711c93 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4113>
  711adf:	movups 0x7d0(%rsp),%xmm0
  711ae7:	movaps %xmm0,0x440(%rsp)
  711aef:	movups 0x7c0(%rsp),%xmm0
  711af7:	movaps %xmm0,0x430(%rsp)
  711aff:	movups 0x780(%rsp),%xmm0
  711b07:	movups 0x790(%rsp),%xmm1
  711b0f:	movups 0x7a0(%rsp),%xmm2
  711b17:	movupd 0x7b0(%rsp),%xmm3
  711b20:	movapd %xmm3,0x420(%rsp)
  711b29:	movaps %xmm2,0x410(%rsp)
  711b31:	movaps %xmm1,0x400(%rsp)
  711b39:	movaps %xmm0,0x3f0(%rsp)
  711b41:	mov    0x138(%rsp),%rax
  711b49:	cmpq   $0x0,(%rax)
  711b4d:	je     711c64 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x40e4>
  711b53:	mov    0x2b0(%rsp),%rax
  711b5b:	mov    %rax,0x4b0(%rsp)
  711b63:	lea    0x170(%rsp),%rax
  711b6b:	mov    %rax,0x4b8(%rsp)
  711b73:	lea    0x1d8(%rsp),%rax
  711b7b:	mov    %rax,0x4c0(%rsp)
  711b83:	lea    0xc0(%rsp),%rdi
  711b8b:	lea    0x3a0(%rsp),%rsi
  711b93:	lea    0x4b0(%rsp),%rdx
  711b9b:	call   6b84d0 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>>
  711ba0:	lea    0x3f0(%rsp),%rdi
  711ba8:	call   6c72e0 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportColumn>>
  711bad:	mov    0xd0(%rsp),%rax
  711bb5:	mov    %rax,0x400(%rsp)
  711bbd:	movups 0xc0(%rsp),%xmm0
  711bc5:	movaps %xmm0,0x3f0(%rsp)
  711bcd:	mov    0x138(%rsp),%rax
  711bd5:	mov    (%rax),%rdi
  711bd8:	cmpl   $0xffffffff,0x60(%rdi)
  711bdc:	je     711bf2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4072>
  711bde:	add    $0x60,%rdi
  711be2:	call   6c76d0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  711be7:	mov    0x138(%rsp),%rax
  711bef:	mov    (%rax),%rdi
  711bf2:	movaps 0x440(%rsp),%xmm0
  711bfa:	movups %xmm0,0xb0(%rdi)
  711c01:	movaps 0x430(%rsp),%xmm0
  711c09:	movups %xmm0,0xa0(%rdi)
  711c10:	movaps 0x3f0(%rsp),%xmm0
  711c18:	mov    0x400(%rsp),%rax
  711c20:	mov    0x408(%rsp),%rcx
  711c28:	movaps 0x410(%rsp),%xmm1
  711c30:	movaps 0x420(%rsp),%xmm2
  711c38:	movups %xmm2,0x90(%rdi)
  711c3f:	movups %xmm1,0x80(%rdi)
  711c46:	mov    %rax,0x70(%rdi)
  711c4a:	mov    %rcx,0x78(%rdi)
  711c4e:	movups %xmm0,0x60(%rdi)
  711c52:	movl   $0x0,0x68(%rsp)
  711c5a:	movl   $0x0,0x50(%rsp)
  711c62:	jmp    711c93 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4113>
  711c64:	mov    $0x1,%al
  711c66:	mov    %eax,0x68(%rsp)
  711c6a:	movl   $0x0,0x50(%rsp)
  711c72:	lea    0x3f0(%rsp),%rdi
  711c7a:	mov    $0x1,%r12b
  711c7d:	mov    $0x1,%al
  711c7f:	mov    %eax,0x70(%rsp)
  711c83:	mov    $0x1,%r15b
  711c86:	movb   $0x1,0x80(%rsp)
  711c8e:	call   6c76d0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  711c93:	mov    0xa0(%rsp),%r15
  711c9b:	cmp    $0xffffffffffffffff,%r15
  711c9f:	sete   0x80(%rsp)
  711ca7:	je     711d20 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x41a0>
  711ca9:	mov    %rbx,%r12
  711cac:	mov    0xa8(%rsp),%rax
  711cb4:	mov    %rax,0x70(%rsp)
  711cb9:	mov    0xb0(%rsp),%r14
  711cc1:	mov    0x138(%rsp),%r13
  711cc9:	mov    %r13,%rdi
  711ccc:	call   6b6810 <<core::option::Option<alloc::boxed::Box<gpui::runtime::metadata::Metadata>>>::get_or_insert_with::<<alloc::boxed::Box<gpui::runtime::metadata::Metadata> as core::default::Default>::default>>
  711cd1:	mov    $0x100,%ebx
  711cd6:	add    0x0(%r13),%rbx
  711cda:	mov    %rbx,%rdi
  711cdd:	call   6b6670 <<core::option::Option<alloc::boxed::Box<gpui::runtime::geometry::Geometry>>>::get_or_insert_with::<<alloc::boxed::Box<gpui::runtime::geometry::Geometry> as core::default::Default>::default>>
  711ce2:	mov    (%rbx),%rdi
  711ce5:	mov    %r15,0x4b0(%rsp)
  711ced:	mov    0x70(%rsp),%rax
  711cf2:	mov    %rax,0x4b8(%rsp)
  711cfa:	mov    %r14,0x4c0(%rsp)
  711d02:	lea    0x4b0(%rsp),%rsi
  711d0a:	call   *0x330ae8(%rip)        # a427f8 <_DYNAMIC+0x808>
  711d10:	mov    0x38(%rsp),%r14
  711d15:	mov    %r12,%rbx
  711d18:	mov    0x280(%rsp),%r13
  711d20:	cmpq   $0xffffffffffffffff,0x278(%rsp)
  711d29:	je     711d58 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x41d8>
  711d2b:	mov    0x0(%r13),%rdi
  711d2f:	test   %rdi,%rdi
  711d32:	je     7126b1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b31>
  711d38:	lea    0x828(%rsp),%rdx
  711d40:	mov    0x308(%rsp),%rsi
  711d48:	call   *0x330ab2(%rip)        # a42800 <_DYNAMIC+0x810>
  711d4e:	movl   $0x0,0x70(%rsp)
  711d56:	jmp    711d5e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x41de>
  711d58:	mov    $0x1,%al
  711d5a:	mov    %eax,0x70(%rsp)
  711d5e:	mov    0x138(%rsp),%rax
  711d66:	mov    (%rax),%rax
  711d69:	test   %rax,%rax
  711d6c:	je     711dbe <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x423e>
  711d6e:	mov    0xe0(%rax),%rax
  711d75:	test   %rax,%rax
  711d78:	je     711dbe <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x423e>
  711d7a:	mov    0x818(%rsp),%rcx
  711d82:	mov    %rcx,0x40(%rax)
  711d86:	mov    0x368(%rsp),%rcx
  711d8e:	mov    %rcx,0x48(%rax)
  711d92:	mov    0x370(%rsp),%ecx
  711d99:	mov    %ecx,0x50(%rax)
  711d9c:	movzbl 0x9b(%rsp),%ecx
  711da4:	mov    %cl,0x54(%rax)
  711da7:	movzwl 0x12c(%rsp),%ecx
  711daf:	mov    %cx,0x55(%rax)
  711db3:	movzbl 0x12e(%rsp),%ecx
  711dbb:	mov    %cl,0x57(%rax)
  711dbe:	mov    0x708(%r14),%rdi
  711dc5:	test   %rdi,%rdi
  711dc8:	je     711dfe <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x427e>
  711dca:	cmpq   $0xffffffffffffffff,0x18(%rdi)
  711dcf:	je     711de1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4261>
  711dd1:	add    $0x18,%rdi
  711dd5:	call   6c1520 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  711dda:	mov    0x708(%r14),%rdi
  711de1:	mov    0x298(%rsp),%rax
  711de9:	mov    %rax,0x28(%rdi)
  711ded:	movups 0x288(%rsp),%xmm0
  711df5:	movups %xmm0,0x18(%rdi)
  711df9:	xor    %r12d,%r12d
  711dfc:	jmp    711e01 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4281>
  711dfe:	mov    $0x1,%r12b
  711e01:	mov    0x1e8(%rsp),%rax
  711e09:	mov    %rax,0x4c0(%rsp)
  711e11:	movups 0x1d8(%rsp),%xmm0
  711e19:	movaps %xmm0,0x4b0(%rsp)
  711e21:	lea    0x5f8(%r14),%r15
  711e28:	cmpq   $0xffffffffffffffff,0x5f8(%r14)
  711e30:	je     711e3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x42ba>
  711e32:	mov    %r15,%rdi
  711e35:	call   6c1190 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  711e3a:	mov    0x4c0(%rsp),%rax
  711e42:	mov    %rax,0x10(%r15)
  711e46:	movaps 0x4b0(%rsp),%xmm0
  711e4e:	movups %xmm0,(%r15)
  711e52:	mov    0x110(%rsp),%rax
  711e5a:	mov    %rax,0x610(%r14)
  711e61:	mov    %bx,0x618(%r14)
  711e69:	mov    0x194(%rsp),%eax
  711e70:	mov    %ax,0x61a(%r14)
  711e78:	movss  0x9c(%rsp),%xmm0
  711e81:	movss  %xmm0,0x61c(%r14)
  711e8a:	xor    %r15d,%r15d
  711e8d:	mov    %r14,%rdi
  711e90:	call   6f0ba0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::prune_focus>
  711e95:	mov    0x350(%rsp),%rax
  711e9d:	mov    %rax,0x6f0(%r14)
  711ea4:	mov    0x308(%rsp),%rax
  711eac:	mov    %rax,0x6f8(%r14)
  711eb3:	mov    0x6d0(%r14),%rax
  711eba:	mov    0x708(%r14),%rdi
  711ec1:	mov    %rax,0x700(%r14)
  711ec8:	mov    0x820(%rsp),%rax
  711ed0:	mov    %rax,0x628(%r14)
  711ed7:	cmpq   $0x0,0x328(%r14)
  711edf:	setne  %al
  711ee2:	test   %rdi,%rdi
  711ee5:	sete   %cl
  711ee8:	or     %al,%cl
  711eea:	cmp    $0x1,%cl
  711eed:	je     711f07 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4387>
  711eef:	add    $0x30,%rdi
  711ef3:	call   6bf5d0 <core::ptr::drop_glue::<core::option::Option<gpui_canvas::text::TextSystem>>>
  711ef8:	mov    0x708(%r14),%rax
  711eff:	movq   $0x0,0x30(%rax)
  711f07:	movb   $0x0,0x78b(%r14)
  711f0f:	movw   $0x0,0x788(%r14)
  711f19:	lea    0x6b8(%r14),%rdi
  711f20:	xor    %r15d,%r15d
  711f23:	call   6f8200 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::clear>
  711f28:	cmpb   $0x0,0x78d(%r14)
  711f30:	je     711f67 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x43e7>
  711f32:	xor    %r15d,%r15d
  711f35:	lea    0x4b0(%rsp),%rdi
  711f3d:	mov    %r14,%rsi
  711f40:	mov    0x350(%rsp),%rdx
  711f48:	mov    0x308(%rsp),%rcx
  711f50:	call   70d5d0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge>
  711f55:	mov    0x4b0(%rsp),%rax
  711f5d:	cmp    $0xfffffffffffffffe,%rax
  711f61:	jne    71209f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x451f>
  711f67:	mov    0x40(%rsp),%rax
  711f6c:	movq   $0xfffffffffffffffe,(%rax)
  711f73:	cmpb   $0x0,0x68(%rsp)
  711f78:	je     711f87 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4407>
  711f7a:	lea    0x3a0(%rsp),%rdi
  711f82:	call   6c7290 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportBuild>>
  711f87:	xor    %r13d,%r13d
  711f8a:	lea    0x378(%rsp),%rdi
  711f92:	call   6c41f0 <core::ptr::drop_glue::<alloc::collections::btree::set::BTreeSet<gpui::list::ListId>>>
  711f97:	mov    0x170(%rsp),%rsi
  711f9f:	test   %rsi,%rsi
  711fa2:	je     711fbb <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x443b>
  711fa4:	mov    0x178(%rsp),%rdi
  711fac:	shl    $0x2,%rsi
  711fb0:	mov    $0x4,%edx
  711fb5:	call   *0x33029d(%rip)        # a42258 <_DYNAMIC+0x268>
  711fbb:	mov    0x198(%rsp),%rsi
  711fc3:	test   %rsi,%rsi
  711fc6:	je     711fdb <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x445b>
  711fc8:	mov    0x1a0(%rsp),%rdi
  711fd0:	mov    $0x1,%edx
  711fd5:	call   *0x33027d(%rip)        # a42258 <_DYNAMIC+0x268>
  711fdb:	mov    0x238(%rsp),%rsi
  711fe3:	test   %rsi,%rsi
  711fe6:	je     711fff <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x447f>
  711fe8:	mov    0x240(%rsp),%rdi
  711ff0:	shl    $0x4,%rsi
  711ff4:	mov    $0x4,%edx
  711ff9:	call   *0x330259(%rip)        # a42258 <_DYNAMIC+0x268>
  711fff:	mov    0x220(%rsp),%rsi
  712007:	test   %rsi,%rsi
  71200a:	je     712023 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x44a3>
  71200c:	mov    0x228(%rsp),%rdi
  712014:	shl    $0x4,%rsi
  712018:	mov    $0x4,%edx
  71201d:	call   *0x330235(%rip)        # a42258 <_DYNAMIC+0x268>
  712023:	mov    0x1f8(%rsp),%rax
  71202b:	test   %rax,%rax
  71202e:	je     712047 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x44c7>
  712030:	mov    0x200(%rsp),%rdi
  712038:	imul   $0x38,%rax,%rsi
  71203c:	mov    $0x8,%edx
  712041:	call   *0x330211(%rip)        # a42258 <_DYNAMIC+0x268>
  712047:	cmpq   $0x0,0x1c8(%rsp)
  712050:	je     71205f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x44df>
  712052:	mov    0x1d0(%rsp),%rdi
  71205a:	call   6c5a90 <core::ptr::drop_glue::<gpui_canvas::text::TextShaper>>
  71205f:	test   %r12b,%r12b
  712062:	je     712071 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x44f1>
  712064:	lea    0x288(%rsp),%rdi
  71206c:	call   6c1520 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  712071:	mov    0x140(%rsp),%rax
  712079:	test   %rax,%rax
  71207c:	je     70f3f6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1876>
  712082:	lock decq (%rax)
  712086:	jne    70f3f6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1876>
  71208c:	lea    0x140(%rsp),%rdi
  712094:	call   *0x33028e(%rip)        # a42328 <_DYNAMIC+0x338>
  71209a:	jmp    70f3f6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1876>
  71209f:	mov    0x4d8(%rsp),%rcx
  7120a7:	movzbl 0x4e0(%rsp),%edx
  7120af:	mov    0x4e1(%rsp),%esi
  7120b6:	mov    %esi,0xc0(%rsp)
  7120bd:	mov    0x4e4(%rsp),%esi
  7120c4:	mov    %esi,0xc3(%rsp)
  7120cb:	movups 0x4b8(%rsp),%xmm0
  7120d3:	movups 0x4c8(%rsp),%xmm1
  7120db:	mov    0xc0(%rsp),%esi
  7120e2:	mov    0xc3(%rsp),%edi
  7120e9:	mov    0x40(%rsp),%r8
  7120ee:	mov    %edi,0x34(%r8)
  7120f2:	mov    %esi,0x31(%r8)
  7120f6:	mov    %rax,(%r8)
  7120f9:	movups %xmm0,0x8(%r8)
  7120fe:	movups %xmm1,0x18(%r8)
  712103:	mov    %rcx,0x28(%r8)
  712107:	mov    %dl,0x30(%r8)
  71210b:	xor    %r13d,%r13d
  71210e:	cmpb   $0x0,0x68(%rsp)
  712113:	mov    0x70(%rsp),%ebx
  712117:	jne    7123ca <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x484a>
  71211d:	jmp    7123d7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4857>
  712122:	movzbl 0x4b1(%rsp),%eax
  71212a:	mov    0x40(%rsp),%rcx
  71212f:	movq   $0x22,(%rcx)
  712136:	mov    %al,0x8(%rcx)
  712139:	jmp    7123ac <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x482c>
  71213e:	mov    0x40(%rsp),%rax
  712143:	movq   $0x1f,(%rax)
  71214a:	jmp    70f3f6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1876>
  71214f:	lea    0xc4(%rsp),%rcx
  712157:	mov    0x14(%rcx),%rax
  71215b:	movups 0x4(%rcx),%xmm0
  71215f:	movaps %xmm0,0x150(%rsp)
  712167:	mov    %rax,0x160(%rsp)
  71216f:	mov    0x40(%rsp),%rcx
  712174:	mov    %rax,0x18(%rcx)
  712178:	movups %xmm0,0x8(%rcx)
  71217c:	movq   $0x23,(%rcx)
  712183:	jmp    7123ac <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x482c>
  712188:	mov    0x40(%rsp),%rcx
  71218d:	movq   $0x23,(%rcx)
  712194:	mov    %eax,0x8(%rcx)
  712197:	mov    %edx,0xc(%rcx)
  71219a:	jmp    7123ac <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x482c>
  71219f:	mov    0xf0(%rsp),%rcx
  7121a7:	mov    0x40(%rsp),%rdx
  7121ac:	mov    %rcx,0x30(%rdx)
  7121b0:	movups 0xd0(%rsp),%xmm0
  7121b8:	movups 0xe0(%rsp),%xmm1
  7121c0:	movups %xmm1,0x20(%rdx)
  7121c4:	movups %xmm0,0x10(%rdx)
  7121c8:	mov    %rax,(%rdx)
  7121cb:	mov    %r15,0x8(%rdx)
  7121cf:	jmp    7123ac <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x482c>
  7121d4:	mov    0x4e0(%rsp),%rax
  7121dc:	mov    0x40(%rsp),%rcx
  7121e1:	mov    %rax,0x30(%rcx)
  7121e5:	movups 0x4b0(%rsp),%xmm0
  7121ed:	movups 0x4c0(%rsp),%xmm1
  7121f5:	movups 0x4d0(%rsp),%xmm2
  7121fd:	movups %xmm2,0x20(%rcx)
  712201:	movups %xmm1,0x10(%rcx)
  712205:	movups %xmm0,(%rcx)
  712208:	jmp    7123ac <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x482c>
  71220d:	mov    0x50(%rsp),%rax
  712212:	mov    0x20(%rax),%esi
  712215:	lea    0xc0(%rsp),%rdi
  71221d:	lea    0x840(%rsp),%rdx
  712225:	call   6db130 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#23}>
  71222a:	mov    0xf0(%rsp),%rax
  712232:	mov    %rax,0x870(%rsp)
  71223a:	movups 0xc0(%rsp),%xmm0
  712242:	movups 0xd0(%rsp),%xmm1
  71224a:	movups 0xe0(%rsp),%xmm2
  712252:	movaps %xmm2,0x860(%rsp)
  71225a:	movaps %xmm1,0x850(%rsp)
  712262:	movaps %xmm0,0x840(%rsp)
  71226a:	mov    0x840(%rsp),%rax
  712272:	mov    0x868(%rsp),%rcx
  71227a:	mov    0x40(%rsp),%rdx
  71227f:	mov    %rcx,0x28(%rdx)
  712283:	mov    0x870(%rsp),%rcx
  71228b:	mov    %rcx,0x30(%rdx)
  71228f:	lea    0x848(%rsp),%rcx
  712297:	movups (%rcx),%xmm0
  71229a:	movups 0x10(%rcx),%xmm1
  71229e:	movups %xmm0,0x8(%rdx)
  7122a2:	movups %xmm1,0x18(%rdx)
  7122a6:	mov    %rax,(%rdx)
  7122a9:	jmp    7123ac <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x482c>
  7122ae:	mov    0x40(%rsp),%rcx
  7122b3:	movq   $0x23,(%rcx)
  7122ba:	mov    %eax,0x8(%rcx)
  7122bd:	mov    %edx,0xc(%rcx)
  7122c0:	jmp    712390 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4810>
  7122c5:	lea    0xc4(%rsp),%rcx
  7122cd:	mov    0x14(%rcx),%rax
  7122d1:	movups 0x4(%rcx),%xmm0
  7122d5:	movaps %xmm0,0x150(%rsp)
  7122dd:	mov    %rax,0x160(%rsp)
  7122e5:	mov    0x40(%rsp),%rcx
  7122ea:	mov    %rax,0x18(%rcx)
  7122ee:	movups %xmm0,0x8(%rcx)
  7122f2:	movq   $0x23,(%rcx)
  7122f9:	jmp    712390 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4810>
  7122fe:	lea    0xc4(%rsp),%rcx
  712306:	mov    0x14(%rcx),%rax
  71230a:	movups 0x4(%rcx),%xmm0
  71230e:	movaps %xmm0,0x150(%rsp)
  712316:	mov    %rax,0x160(%rsp)
  71231e:	mov    0x40(%rsp),%rcx
  712323:	mov    %rax,0x18(%rcx)
  712327:	movups %xmm0,0x8(%rcx)
  71232b:	movq   $0x23,(%rcx)
  712332:	jmp    712346 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x47c6>
  712334:	mov    0x40(%rsp),%rcx
  712339:	movq   $0x23,(%rcx)
  712340:	mov    %eax,0x8(%rcx)
  712343:	mov    %edx,0xc(%rcx)
  712346:	mov    0x218(%rsp),%rax
  71234e:	test   %rax,%rax
  712351:	je     7123ac <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x482c>
  712353:	lock decq (%rax)
  712357:	jne    7123ac <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x482c>
  712359:	lea    0x218(%rsp),%rdi
  712361:	call   *0x32ffd1(%rip)        # a42338 <_DYNAMIC+0x348>
  712367:	jmp    7123ac <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x482c>
  712369:	mov    0x40(%rsp),%rax
  71236e:	movq   $0x18,(%rax)
  712375:	jmp    712390 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4810>
  712377:	mov    0x154(%rsp),%ecx
  71237e:	mov    0x40(%rsp),%rdx
  712383:	movq   $0x23,(%rdx)
  71238a:	mov    %eax,0x8(%rdx)
  71238d:	mov    %ecx,0xc(%rdx)
  712390:	mov    0x320(%rsp),%rax
  712398:	lock decq (%rax)
  71239c:	jne    7123ac <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x482c>
  71239e:	lea    0x320(%rsp),%rdi
  7123a6:	call   *0x32ff8c(%rip)        # a42338 <_DYNAMIC+0x348>
  7123ac:	lea    0x8f0(%rsp),%rdi
  7123b4:	call   6c6030 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  7123b9:	mov    $0x1,%r12b
  7123bc:	mov    $0x1,%bl
  7123be:	mov    $0x1,%al
  7123c0:	mov    %eax,0x50(%rsp)
  7123c4:	mov    $0x1,%r13b
  7123c7:	mov    $0x1,%bpl
  7123ca:	lea    0x3a0(%rsp),%rdi
  7123d2:	call   6c7290 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportBuild>>
  7123d7:	cmpq   $0xffffffffffffffff,0x278(%rsp)
  7123e0:	setne  %al
  7123e3:	mov    %r13d,%r15d
  7123e6:	test   %bl,%al
  7123e8:	je     7123fa <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x487a>
  7123ea:	lea    0x828(%rsp),%rdi
  7123f2:	call   6c1310 <core::ptr::drop_glue::<alloc::vec::Vec<gpui_canvas::image::Image>>>
  7123f7:	mov    %r15d,%r13d
  7123fa:	cmpl   $0xffffffff,0x780(%rsp)
  712402:	je     712418 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4898>
  712404:	cmpb   $0x0,0x50(%rsp)
  712409:	je     712418 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4898>
  71240b:	lea    0x780(%rsp),%rdi
  712413:	call   6c76d0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  712418:	lea    0x378(%rsp),%rdi
  712420:	call   6c41f0 <core::ptr::drop_glue::<alloc::collections::btree::set::BTreeSet<gpui::list::ListId>>>
  712425:	mov    0x170(%rsp),%rsi
  71242d:	test   %rsi,%rsi
  712430:	je     712449 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x48c9>
  712432:	mov    0x178(%rsp),%rdi
  71243a:	shl    $0x2,%rsi
  71243e:	mov    $0x4,%edx
  712443:	call   *0x32fe0f(%rip)        # a42258 <_DYNAMIC+0x268>
  712449:	mov    0x198(%rsp),%rsi
  712451:	test   %rsi,%rsi
  712454:	je     712469 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x48e9>
  712456:	mov    0x1a0(%rsp),%rdi
  71245e:	mov    $0x1,%edx
  712463:	call   *0x32fdef(%rip)        # a42258 <_DYNAMIC+0x268>
  712469:	mov    0x238(%rsp),%rsi
  712471:	test   %rsi,%rsi
  712474:	je     71248d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x490d>
  712476:	mov    0x240(%rsp),%rdi
  71247e:	shl    $0x4,%rsi
  712482:	mov    $0x4,%edx
  712487:	call   *0x32fdcb(%rip)        # a42258 <_DYNAMIC+0x268>
  71248d:	mov    0x220(%rsp),%rsi
  712495:	test   %rsi,%rsi
  712498:	je     7124b1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4931>
  71249a:	mov    0x228(%rsp),%rdi
  7124a2:	shl    $0x4,%rsi
  7124a6:	mov    $0x4,%edx
  7124ab:	call   *0x32fda7(%rip)        # a42258 <_DYNAMIC+0x268>
  7124b1:	mov    0x1f8(%rsp),%rax
  7124b9:	test   %rax,%rax
  7124bc:	je     7124d5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4955>
  7124be:	mov    0x200(%rsp),%rdi
  7124c6:	imul   $0x38,%rax,%rsi
  7124ca:	mov    $0x8,%edx
  7124cf:	call   *0x32fd83(%rip)        # a42258 <_DYNAMIC+0x268>
  7124d5:	test   %r13b,%r13b
  7124d8:	je     71250b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x498b>
  7124da:	mov    0x2d0(%rsp),%rsi
  7124e2:	test   %rsi,%rsi
  7124e5:	je     7124fe <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x497e>
  7124e7:	mov    0x2d8(%rsp),%rdi
  7124ef:	shl    $0x4,%rsi
  7124f3:	mov    $0x4,%edx
  7124f8:	call   *0x32fd5a(%rip)        # a42258 <_DYNAMIC+0x268>
  7124fe:	lea    0x1d8(%rsp),%rdi
  712506:	call   6c1190 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  71250b:	mov    0x748(%rsp),%rax
  712513:	cmp    $0xfffffffffffffffe,%rax
  712517:	jne    70efba <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x143a>
  71251d:	jmp    70f38f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x180f>
  712522:	lea    -0x6c22c7(%rip),%rdi        # 50262 <GCC_except_table0+0x104be>
  712529:	lea    0x3110c0(%rip),%rdx        # a235f0 <__frame_dummy_init_array_entry+0x1b00>
  712530:	mov    $0x83,%esi
  712535:	call   *0x32fd55(%rip)        # a42290 <_DYNAMIC+0x2a0>
  71253b:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  712540:	lea    -0x6c255b(%rip),%rdi        # 4ffec <GCC_except_table0+0x10248>
  712547:	lea    0x310b82(%rip),%rdx        # a230d0 <__frame_dummy_init_array_entry+0x15e0>
  71254e:	mov    $0x1c,%esi
  712553:	call   *0x32fe9f(%rip)        # a423f8 <_DYNAMIC+0x408>
  712559:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  71255e:	mov    $0x1,%bpl
  712561:	mov    $0x8,%edi
  712566:	mov    $0x78,%esi
  71256b:	call   *0x32fcff(%rip)        # a42270 <_DYNAMIC+0x280>
  712571:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  712576:	lea    0x30fd7b(%rip),%rdi        # a222f8 <__frame_dummy_init_array_entry+0x808>
  71257d:	call   *0x32fd75(%rip)        # a422f8 <_DYNAMIC+0x308>
  712583:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  712588:	lea    -0x6c22ec(%rip),%rax        # 502a3 <GCC_except_table0+0x104ff>
  71258f:	mov    %rax,0x270(%rsp)
  712597:	lea    0x31122a(%rip),%rax        # a237c8 <__frame_dummy_init_array_entry+0x1cd8>
  71259e:	jmp    7125da <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4a5a>
  7125a0:	lea    0x30fea1(%rip),%rdi        # a22448 <__frame_dummy_init_array_entry+0x958>
  7125a7:	call   *0x32fd4b(%rip)        # a422f8 <_DYNAMIC+0x308>
  7125ad:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  7125b2:	lea    0x30fd3f(%rip),%rdi        # a222f8 <__frame_dummy_init_array_entry+0x808>
  7125b9:	call   *0x32fd39(%rip)        # a422f8 <_DYNAMIC+0x308>
  7125bf:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  7125c4:	lea    -0x6c2328(%rip),%rax        # 502a3 <GCC_except_table0+0x104ff>
  7125cb:	mov    %rax,0x270(%rsp)
  7125d3:	lea    0x311206(%rip),%rax        # a237e0 <__frame_dummy_init_array_entry+0x1cf0>
  7125da:	mov    %rax,0x268(%rsp)
  7125e2:	jmp    71265e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4ade>
  7125e4:	mov    0x4c0(%rsp),%rsi
  7125ec:	mov    $0x1,%bpl
  7125ef:	call   *0x32fcf3(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  7125f5:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  7125fa:	mov    0x4c0(%rsp),%rsi
  712602:	call   *0x32fce0(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  712608:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  71260d:	mov    0x4c0(%rsp),%rsi
  712615:	call   *0x32fccd(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  71261b:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  712620:	mov    0x4c0(%rsp),%rsi
  712628:	call   *0x32fcba(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  71262e:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  712633:	mov    0x4c0(%rsp),%rsi
  71263b:	call   *0x32fca7(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  712641:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  712646:	mov    0x4c0(%rsp),%rsi
  71264e:	call   *0x32fc94(%rip)        # a422e8 <_DYNAMIC+0x2f8>
  712654:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  712659:	mov    $0x1f,%esi
  71265e:	mov    0x270(%rsp),%rdi
  712666:	mov    0x268(%rsp),%rdx
  71266e:	call   *0x32fd84(%rip)        # a423f8 <_DYNAMIC+0x408>
  712674:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  712679:	lea    -0x6c241e(%rip),%rdi        # 50262 <GCC_except_table0+0x104be>
  712680:	lea    0x310f69(%rip),%rdx        # a235f0 <__frame_dummy_init_array_entry+0x1b00>
  712687:	mov    $0x83,%esi
  71268c:	call   *0x32fbfe(%rip)        # a42290 <_DYNAMIC+0x2a0>
  712692:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  712697:	movb   $0x1,0x80(%rsp)
  71269f:	lea    0x31116a(%rip),%rdi        # a23810 <__frame_dummy_init_array_entry+0x1d20>
  7126a6:	call   *0x32fc4c(%rip)        # a422f8 <_DYNAMIC+0x308>
  7126ac:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  7126b1:	lea    0x311098(%rip),%rdi        # a23750 <__frame_dummy_init_array_entry+0x1c60>
  7126b8:	call   *0x32fc3a(%rip)        # a422f8 <_DYNAMIC+0x308>
  7126be:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  7126c3:	lea    -0x6c2468(%rip),%rdi        # 50262 <GCC_except_table0+0x104be>
  7126ca:	lea    0x310f1f(%rip),%rdx        # a235f0 <__frame_dummy_init_array_entry+0x1b00>
  7126d1:	mov    $0x83,%esi
  7126d6:	call   *0x32fbb4(%rip)        # a42290 <_DYNAMIC+0x2a0>
  7126dc:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  7126e1:	lea    0x30fc58(%rip),%rax        # a22340 <__frame_dummy_init_array_entry+0x850>
  7126e8:	jmp    7127a0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c20>
  7126ed:	lea    0x30fc1c(%rip),%rdi        # a22310 <__frame_dummy_init_array_entry+0x820>
  7126f4:	call   *0x32fbfe(%rip)        # a422f8 <_DYNAMIC+0x308>
  7126fa:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  7126ff:	lea    0x30fc0a(%rip),%rdi        # a22310 <__frame_dummy_init_array_entry+0x820>
  712706:	call   *0x32fbec(%rip)        # a422f8 <_DYNAMIC+0x308>
  71270c:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  712711:	lea    0x310fb0(%rip),%rax        # a236c8 <__frame_dummy_init_array_entry+0x1bd8>
  712718:	jmp    7127a0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c20>
  71271d:	lea    0x310fbc(%rip),%rax        # a236e0 <__frame_dummy_init_array_entry+0x1bf0>
  712724:	jmp    7127a0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c20>
  712726:	movb   $0x1,0x80(%rsp)
  71272e:	lea    -0x6c24d3(%rip),%rdi        # 50262 <GCC_except_table0+0x104be>
  712735:	lea    0x310eb4(%rip),%rdx        # a235f0 <__frame_dummy_init_array_entry+0x1b00>
  71273c:	mov    $0x83,%esi
  712741:	call   *0x32fb49(%rip)        # a42290 <_DYNAMIC+0x2a0>
  712747:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  71274c:	lea    0x3107ad(%rip),%rax        # a22f00 <__frame_dummy_init_array_entry+0x1410>
  712753:	jmp    7127a0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c20>
  712755:	lea    0x31078c(%rip),%rax        # a22ee8 <__frame_dummy_init_array_entry+0x13f8>
  71275c:	jmp    7127a0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c20>
  71275e:	mov    %rbx,%rbp
  712761:	lea    0x310798(%rip),%rax        # a22f00 <__frame_dummy_init_array_entry+0x1410>
  712768:	jmp    7127a0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c20>
  71276a:	mov    %rax,%rbp
  71276d:	jmp    712799 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c19>
  71276f:	mov    %rbx,%rbp
  712772:	lea    0x31076f(%rip),%rax        # a22ee8 <__frame_dummy_init_array_entry+0x13f8>
  712779:	jmp    7127a0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c20>
  71277b:	mov    %rax,%r13
  71277e:	lea    0x310763(%rip),%rax        # a22ee8 <__frame_dummy_init_array_entry+0x13f8>
  712785:	jmp    7127a0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c20>
  712787:	mov    %rax,%r13
  71278a:	lea    0x31076f(%rip),%rax        # a22f00 <__frame_dummy_init_array_entry+0x1410>
  712791:	jmp    7127a0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c20>
  712793:	mov    %rcx,%rbp
  712796:	mov    %rax,%r13
  712799:	lea    0x310778(%rip),%rax        # a22f18 <__frame_dummy_init_array_entry+0x1428>
  7127a0:	mov    %rax,0x48(%rsp)
  7127a5:	mov    %rbp,%rdi
  7127a8:	mov    %r13,%rsi
  7127ab:	mov    0x48(%rsp),%rdx
  7127b0:	call   *0x32fad2(%rip)        # a42288 <_DYNAMIC+0x298>
  7127b6:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  7127bb:	mov    $0x1,%r12b
  7127be:	lea    0x310f4b(%rip),%rdx        # a23710 <__frame_dummy_init_array_entry+0x1c20>
  7127c5:	mov    $0x1,%bpl
  7127c8:	xor    %edi,%edi
  7127ca:	xor    %esi,%esi
  7127cc:	call   *0x32fab6(%rip)        # a42288 <_DYNAMIC+0x298>
  7127d2:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  7127d7:	mov    %rsi,%rax
  7127da:	lea    0x310f9f(%rip),%rcx        # a23780 <__frame_dummy_init_array_entry+0x1c90>
  7127e1:	jmp    7128bf <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3f>
  7127e6:	mov    %rsi,%rax
  7127e9:	lea    0x310fa8(%rip),%rcx        # a23798 <__frame_dummy_init_array_entry+0x1ca8>
  7127f0:	jmp    7128bf <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3f>
  7127f5:	mov    %rsi,%rax
  7127f8:	lea    0x310fb1(%rip),%rcx        # a237b0 <__frame_dummy_init_array_entry+0x1cc0>
  7127ff:	jmp    7128bf <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3f>
  712804:	mov    %rbx,0x80(%rsp)
  71280c:	mov    %rsi,%rax
  71280f:	lea    0x30fc02(%rip),%rcx        # a22418 <__frame_dummy_init_array_entry+0x928>
  712816:	jmp    7128bf <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3f>
  71281b:	mov    %rcx,0x80(%rsp)
  712823:	lea    0x30fc06(%rip),%rcx        # a22430 <__frame_dummy_init_array_entry+0x940>
  71282a:	jmp    7128bf <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3f>
  71282f:	lea    0x30fc8a(%rip),%rdx        # a224c0 <__frame_dummy_init_array_entry+0x9d0>
  712836:	call   *0x32fa4c(%rip)        # a42288 <_DYNAMIC+0x298>
  71283c:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  712841:	mov    %rcx,0x80(%rsp)
  712849:	lea    0x30fc10(%rip),%rcx        # a22460 <__frame_dummy_init_array_entry+0x970>
  712850:	jmp    7128bf <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3f>
  712852:	mov    %rcx,0x80(%rsp)
  71285a:	lea    0x30fc17(%rip),%rcx        # a22478 <__frame_dummy_init_array_entry+0x988>
  712861:	jmp    7128bf <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3f>
  712863:	lea    0x30fc3e(%rip),%rax        # a224a8 <__frame_dummy_init_array_entry+0x9b8>
  71286a:	mov    %rax,0x348(%rsp)
  712872:	movb   $0x1,0x80(%rsp)
  71287a:	mov    %rbx,%rdi
  71287d:	mov    0x348(%rsp),%rdx
  712885:	call   *0x32f9fd(%rip)        # a42288 <_DYNAMIC+0x298>
  71288b:	jmp    7128e0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d60>
  71288d:	lea    0x31066c(%rip),%rcx        # a22f00 <__frame_dummy_init_array_entry+0x1410>
  712894:	jmp    7128bf <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3f>
  712896:	mov    %rcx,0x80(%rsp)
  71289e:	lea    0x310673(%rip),%rcx        # a22f18 <__frame_dummy_init_array_entry+0x1428>
  7128a5:	jmp    7128bf <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3f>
  7128a7:	lea    0x31063a(%rip),%rcx        # a22ee8 <__frame_dummy_init_array_entry+0x13f8>
  7128ae:	jmp    7128bf <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3f>
  7128b0:	mov    %rcx,0x80(%rsp)
  7128b8:	lea    0x30fbd1(%rip),%rcx        # a22490 <__frame_dummy_init_array_entry+0x9a0>
  7128bf:	mov    %rcx,0x108(%rsp)
  7128c7:	mov    0x80(%rsp),%rdi
  7128cf:	mov    %rax,%rsi
  7128d2:	mov    0x108(%rsp),%rdx
  7128da:	call   *0x32f9a8(%rip)        # a42288 <_DYNAMIC+0x298>
  7128e0:	ud2
  7128e2:	mov    %rax,%rbx
  7128e5:	mov    0x138(%rsp),%rax
  7128ed:	mov    (%rax),%rax
  7128f0:	movaps 0x440(%rsp),%xmm0
  7128f8:	movups %xmm0,0xb0(%rax)
  7128ff:	movaps 0x430(%rsp),%xmm0
  712907:	movups %xmm0,0xa0(%rax)
  71290e:	movaps 0x3f0(%rsp),%xmm0
  712916:	movaps 0x400(%rsp),%xmm1
  71291e:	movaps 0x410(%rsp),%xmm2
  712926:	movapd 0x420(%rsp),%xmm3
  71292f:	movupd %xmm3,0x90(%rax)
  712937:	movups %xmm2,0x80(%rax)
  71293e:	movups %xmm1,0x70(%rax)
  712942:	movups %xmm0,0x60(%rax)
  712946:	jmp    7129c7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4e47>
  712948:	mov    %rax,%rbx
  71294b:	mov    0x708(%r14),%rax
  712952:	mov    0x298(%rsp),%rcx
  71295a:	mov    %rcx,0x28(%rax)
  71295e:	movups 0x288(%rsp),%xmm0
  712966:	movups %xmm0,0x18(%rax)
  71296a:	mov    $0x1,%r15b
  71296d:	xor    %r12d,%r12d
  712970:	jmp    712c8f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x510f>
  712975:	mov    %rax,%rbx
  712978:	lea    0x408(%rsp),%rdi
  712980:	call   6c16f0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::metadata::TextSlot>>>
  712985:	lea    0x420(%rsp),%rdi
  71298d:	call   6c16f0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::metadata::TextSlot>>>
  712992:	lea    0x3f0(%rsp),%rdi
  71299a:	call   6c72e0 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportColumn>>
  71299f:	mov    0x438(%rsp),%rax
  7129a7:	test   %rax,%rax
  7129aa:	je     7129c7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4e47>
  7129ac:	mov    0x440(%rsp),%rdi
  7129b4:	shl    $0x3,%rax
  7129b8:	lea    (%rax,%rax,2),%rsi
  7129bc:	mov    $0x8,%edx
  7129c1:	call   *0x32f891(%rip)        # a42258 <_DYNAMIC+0x268>
  7129c7:	mov    $0x1,%r12b
  7129ca:	movl   $0x0,0x68(%rsp)
  7129d2:	mov    $0x1,%al
  7129d4:	mov    %eax,0x70(%rsp)
  7129d8:	movl   $0x0,0x50(%rsp)
  7129e0:	mov    $0x1,%r15b
  7129e3:	jmp    712b3e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4fbe>
  7129e8:	mov    %rax,%rbx
  7129eb:	mov    0x708(%r14),%rax
  7129f2:	movq   $0x0,0x30(%rax)
  7129fa:	xor    %r15d,%r15d
  7129fd:	jmp    712c8f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x510f>
  712a02:	mov    %rax,%rbx
  712a05:	lea    0x4b0(%rsp),%rsi
  712a0d:	mov    $0x1e8,%edx
  712a12:	mov    %r14,%rdi
  712a15:	call   *0x32f85d(%rip)        # a42278 <memcpy@GLIBC_2.14>
  712a1b:	mov    $0x1,%al
  712a1d:	mov    %eax,0x68(%rsp)
  712a21:	xor    %ebp,%ebp
  712a23:	mov    $0x1,%r12b
  712a26:	mov    $0x1,%al
  712a28:	mov    %eax,0x70(%rsp)
  712a2c:	mov    $0x1,%al
  712a2e:	mov    %eax,0x50(%rsp)
  712a32:	mov    $0x1,%r15b
  712a35:	jmp    712b3e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4fbe>
  712a3a:	mov    %rax,%rbx
  712a3d:	jmp    712c81 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5101>
  712a42:	mov    %rbx,%rcx
  712a45:	mov    %rax,%rbx
  712a48:	mov    0x4c0(%rsp),%rax
  712a50:	mov    %rax,0x10(%r15)
  712a54:	movaps 0x4b0(%rsp),%xmm0
  712a5c:	movups %xmm0,(%r15)
  712a60:	mov    0x110(%rsp),%rax
  712a68:	mov    %rax,0x610(%r14)
  712a6f:	mov    %cx,0x618(%r14)
  712a77:	mov    0x194(%rsp),%eax
  712a7e:	mov    %ax,0x61a(%r14)
  712a86:	movss  0x9c(%rsp),%xmm0
  712a8f:	movss  %xmm0,0x61c(%r14)
  712a98:	xor    %r15d,%r15d
  712a9b:	jmp    712c8f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x510f>
  712aa0:	mov    %rax,%rbx
  712aa3:	mov    $0x1,%r12b
  712aa6:	jmp    712aca <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4f4a>
  712aa8:	mov    %rax,%rbx
  712aab:	mov    $0x1,%r12b
  712aae:	test   %r15,%r15
  712ab1:	je     712aca <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4f4a>
  712ab3:	shl    $0x4,%r15
  712ab7:	mov    $0x4,%edx
  712abc:	mov    0x70(%rsp),%rdi
  712ac1:	mov    %r15,%rsi
  712ac4:	call   *0x32f78e(%rip)        # a42258 <_DYNAMIC+0x268>
  712aca:	mov    $0x1,%al
  712acc:	mov    %eax,0x70(%rsp)
  712ad0:	mov    $0x1,%r15b
  712ad3:	xor    %r13d,%r13d
  712ad6:	cmpb   $0x0,0x68(%rsp)
  712adb:	je     712cda <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x515a>
  712ae1:	jmp    712dd2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5252>
  712ae6:	mov    %rax,%rbx
  712ae9:	mov    $0x1,%r12b
  712aec:	mov    $0x1,%al
  712aee:	mov    %eax,0x70(%rsp)
  712af2:	mov    $0x1,%al
  712af4:	mov    %eax,0x50(%rsp)
  712af8:	mov    $0x1,%r13b
  712afb:	mov    $0x1,%r15b
  712afe:	mov    $0x1,%bpl
  712b01:	cmpq   $0xffffffffffffffff,0x278(%rsp)
  712b0a:	jne    712dea <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x526a>
  712b10:	jmp    712dfe <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x527e>
  712b15:	mov    %rax,%rbx
  712b18:	mov    %r15d,%r13d
  712b1b:	jmp    712dfe <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x527e>
  712b20:	mov    %rax,%rbx
  712b23:	mov    $0x1,%al
  712b25:	mov    %eax,0x68(%rsp)
  712b29:	mov    $0x1,%r12b
  712b2c:	mov    $0x1,%al
  712b2e:	mov    %eax,0x70(%rsp)
  712b32:	mov    $0x1,%al
  712b34:	mov    %eax,0x50(%rsp)
  712b38:	mov    $0x1,%r15b
  712b3b:	mov    $0x1,%bpl
  712b3e:	movb   $0x1,0x80(%rsp)
  712b46:	jmp    712c8f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x510f>
  712b4b:	mov    %rax,%rbx
  712b4e:	mov    %r13d,%r15d
  712b51:	jmp    712e29 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x52a9>
  712b56:	mov    %rax,%rbx
  712b59:	jmp    712c8f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x510f>
  712b5e:	mov    %rax,%rbx
  712b61:	mov    %r13d,%r15d
  712b64:	jmp    712e1c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x529c>
  712b69:	mov    %rax,%rbx
  712b6c:	add    $0x38,%r15
  712b70:	mov    %r15,%rdi
  712b73:	call   6c5ce0 <core::ptr::drop_glue::<gpui_canvas::text::RasterCache>>
  712b78:	jmp    712bcb <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x504b>
  712b7a:	call   *0x32f700(%rip)        # a42280 <_DYNAMIC+0x290>
  712b80:	mov    %rax,%rbx
  712b83:	mov    0x320(%rsp),%rax
  712b8b:	lock decq (%rax)
  712b8f:	jne    712dad <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x522d>
  712b95:	lea    0x320(%rsp),%rdi
  712b9d:	call   *0x32f795(%rip)        # a42338 <_DYNAMIC+0x348>
  712ba3:	jmp    712dad <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x522d>
  712ba8:	mov    %rax,%rbx
  712bab:	mov    $0x1,%bpl
  712bae:	mov    $0x1,%r15b
  712bb1:	mov    $0x1,%r13b
  712bb4:	mov    $0x1,%al
  712bb6:	mov    %eax,0x50(%rsp)
  712bba:	mov    $0x1,%al
  712bbc:	mov    %eax,0x70(%rsp)
  712bc0:	mov    $0x1,%r12b
  712bc3:	jmp    712dd2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5252>
  712bc8:	mov    %rax,%rbx
  712bcb:	mov    0x38(%rsp),%rax
  712bd0:	mov    0x708(%rax),%rax
  712bd7:	mov    %r12,0x30(%rax)
  712bdb:	mov    %r14d,0x38(%rax)
  712bdf:	mov    %ebp,0x3c(%rax)
  712be2:	movaps 0x8f0(%rsp),%xmm0
  712bea:	movaps 0x900(%rsp),%xmm1
  712bf2:	movaps 0x910(%rsp),%xmm2
  712bfa:	movups %xmm0,0x40(%rax)
  712bfe:	movups %xmm1,0x50(%rax)
  712c02:	movups %xmm2,0x60(%rax)
  712c06:	mov    0x920(%rsp),%rcx
  712c0e:	mov    %rcx,0x70(%rax)
  712c12:	mov    $0x1,%bpl
  712c15:	jmp    712f81 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5401>
  712c1a:	mov    %rax,%rbx
  712c1d:	mov    %r12,%rdi
  712c20:	call   6bf420 <core::ptr::drop_glue::<core::option::Option<gpui::shared_text::SharedText>>>
  712c25:	jmp    712d00 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5180>
  712c2a:	mov    %rax,%rbx
  712c2d:	jmp    712f60 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x53e0>
  712c32:	mov    %rax,%rbx
  712c35:	lea    0x4b0(%rsp),%rsi
  712c3d:	mov    $0x298,%edx
  712c42:	mov    %r15,%rdi
  712c45:	call   *0x32f62d(%rip)        # a42278 <memcpy@GLIBC_2.14>
  712c4b:	jmp    712f30 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x53b0>
  712c50:	mov    %rax,%rbx
  712c53:	jmp    712f4e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x53ce>
  712c58:	mov    %rax,%rbx
  712c5b:	mov    %r14b,0x80(%rsp)
  712c63:	jmp    712d00 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5180>
  712c68:	jmp    712daa <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x522a>
  712c6d:	ud2
  712c6f:	ud2
  712c71:	mov    %rax,%rbx
  712c74:	lea    0x828(%rsp),%rdi
  712c7c:	call   6c1310 <core::ptr::drop_glue::<alloc::vec::Vec<gpui_canvas::image::Image>>>
  712c81:	mov    $0x1,%r12b
  712c84:	movl   $0x0,0x70(%rsp)
  712c8c:	mov    $0x1,%r15b
  712c8f:	mov    0xa0(%rsp),%rsi
  712c97:	test   %rsi,%rsi
  712c9a:	setg   %al
  712c9d:	test   %al,0x80(%rsp)
  712ca4:	je     712ccc <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x514c>
  712ca6:	mov    0xa8(%rsp),%rdi
  712cae:	shl    $0x4,%rsi
  712cb2:	mov    $0x4,%edx
  712cb7:	call   *0x32f59b(%rip)        # a42258 <_DYNAMIC+0x268>
  712cbd:	xor    %r13d,%r13d
  712cc0:	cmpb   $0x0,0x68(%rsp)
  712cc5:	je     712cda <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x515a>
  712cc7:	jmp    712dd2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5252>
  712ccc:	xor    %r13d,%r13d
  712ccf:	cmpb   $0x0,0x68(%rsp)
  712cd4:	jne    712dd2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5252>
  712cda:	cmpq   $0xffffffffffffffff,0x278(%rsp)
  712ce3:	jne    712dea <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x526a>
  712ce9:	jmp    712dfe <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x527e>
  712cee:	jmp    712f2d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x53ad>
  712cf3:	jmp    712f2d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x53ad>
  712cf8:	jmp    712f2d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x53ad>
  712cfd:	mov    %rax,%rbx
  712d00:	mov    0x218(%rsp),%rax
  712d08:	test   %rax,%rax
  712d0b:	setne  %cl
  712d0e:	test   %cl,0x80(%rsp)
  712d15:	je     712dad <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x522d>
  712d1b:	lock decq (%rax)
  712d1f:	jne    712dad <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x522d>
  712d25:	lea    0x218(%rsp),%rdi
  712d2d:	call   *0x32f605(%rip)        # a42338 <_DYNAMIC+0x348>
  712d33:	jmp    712dad <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x522d>
  712d35:	mov    %rax,%rbx
  712d38:	mov    $0x1,%r12b
  712d3b:	mov    $0x1,%r13b
  712d3e:	mov    $0x1,%r15b
  712d41:	mov    $0x1,%bpl
  712d44:	jmp    712e4d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x52cd>
  712d49:	mov    %rax,%rbx
  712d4c:	mov    $0x1,%r12b
  712d4f:	mov    $0x1,%r13b
  712d52:	mov    $0x1,%r15b
  712d55:	mov    $0x1,%bpl
  712d58:	jmp    712e6d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x52ed>
  712d5d:	mov    %rax,%rbx
  712d60:	mov    $0x1,%r12b
  712d63:	mov    $0x1,%r13b
  712d66:	mov    $0x1,%r15b
  712d69:	mov    $0x1,%bpl
  712d6c:	jmp    712e91 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5311>
  712d71:	mov    %rax,%rbx
  712d74:	mov    $0x1,%r12b
  712d77:	mov    $0x1,%r13b
  712d7a:	mov    $0x1,%r15b
  712d7d:	mov    $0x1,%bpl
  712d80:	jmp    712eb5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5335>
  712d85:	mov    %rax,%rbx
  712d88:	mov    $0x1,%bpl
  712d8b:	mov    $0x1,%r15b
  712d8e:	mov    $0x1,%r12b
  712d91:	jmp    712ede <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x535e>
  712d96:	mov    %rax,%rbx
  712d99:	jmp    712f14 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5394>
  712d9e:	ud2
  712da0:	ud2
  712da2:	mov    %rax,%rbx
  712da5:	jmp    712f81 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5401>
  712daa:	mov    %rax,%rbx
  712dad:	mov    $0x1,%bpl
  712db0:	lea    0x8f0(%rsp),%rdi
  712db8:	call   6c6030 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  712dbd:	mov    $0x1,%r15b
  712dc0:	mov    $0x1,%r13b
  712dc3:	mov    $0x1,%al
  712dc5:	mov    %eax,0x50(%rsp)
  712dc9:	mov    $0x1,%al
  712dcb:	mov    %eax,0x70(%rsp)
  712dcf:	mov    $0x1,%r12b
  712dd2:	lea    0x3a0(%rsp),%rdi
  712dda:	call   6c7290 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportBuild>>
  712ddf:	cmpq   $0xffffffffffffffff,0x278(%rsp)
  712de8:	je     712dfe <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x527e>
  712dea:	cmpb   $0x0,0x70(%rsp)
  712def:	je     712dfe <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x527e>
  712df1:	lea    0x828(%rsp),%rdi
  712df9:	call   6c1310 <core::ptr::drop_glue::<alloc::vec::Vec<gpui_canvas::image::Image>>>
  712dfe:	cmpl   $0xffffffff,0x780(%rsp)
  712e06:	je     712e1c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x529c>
  712e08:	cmpb   $0x0,0x50(%rsp)
  712e0d:	je     712e1c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x529c>
  712e0f:	lea    0x780(%rsp),%rdi
  712e17:	call   6c76d0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  712e1c:	lea    0x378(%rsp),%rdi
  712e24:	call   6c41f0 <core::ptr::drop_glue::<alloc::collections::btree::set::BTreeSet<gpui::list::ListId>>>
  712e29:	mov    0x170(%rsp),%rsi
  712e31:	test   %rsi,%rsi
  712e34:	je     712e4d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x52cd>
  712e36:	mov    0x178(%rsp),%rdi
  712e3e:	shl    $0x2,%rsi
  712e42:	mov    $0x4,%edx
  712e47:	call   *0x32f40b(%rip)        # a42258 <_DYNAMIC+0x268>
  712e4d:	mov    0x198(%rsp),%rsi
  712e55:	test   %rsi,%rsi
  712e58:	je     712e6d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x52ed>
  712e5a:	mov    0x1a0(%rsp),%rdi
  712e62:	mov    $0x1,%edx
  712e67:	call   *0x32f3eb(%rip)        # a42258 <_DYNAMIC+0x268>
  712e6d:	mov    0x238(%rsp),%rsi
  712e75:	test   %rsi,%rsi
  712e78:	je     712e91 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5311>
  712e7a:	mov    0x240(%rsp),%rdi
  712e82:	shl    $0x4,%rsi
  712e86:	mov    $0x4,%edx
  712e8b:	call   *0x32f3c7(%rip)        # a42258 <_DYNAMIC+0x268>
  712e91:	mov    0x220(%rsp),%rsi
  712e99:	test   %rsi,%rsi
  712e9c:	je     712eb5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5335>
  712e9e:	mov    0x228(%rsp),%rdi
  712ea6:	shl    $0x4,%rsi
  712eaa:	mov    $0x4,%edx
  712eaf:	call   *0x32f3a3(%rip)        # a42258 <_DYNAMIC+0x268>
  712eb5:	mov    0x1f8(%rsp),%rax
  712ebd:	test   %rax,%rax
  712ec0:	je     712ed9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5359>
  712ec2:	mov    0x200(%rsp),%rdi
  712eca:	imul   $0x38,%rax,%rsi
  712ece:	mov    $0x8,%edx
  712ed3:	call   *0x32f37f(%rip)        # a42258 <_DYNAMIC+0x268>
  712ed9:	test   %r13b,%r13b
  712edc:	je     712f02 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5382>
  712ede:	mov    0x2d0(%rsp),%rsi
  712ee6:	test   %rsi,%rsi
  712ee9:	je     712f02 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5382>
  712eeb:	mov    0x2d8(%rsp),%rdi
  712ef3:	shl    $0x4,%rsi
  712ef7:	mov    $0x4,%edx
  712efc:	call   *0x32f356(%rip)        # a42258 <_DYNAMIC+0x268>
  712f02:	test   %r15b,%r15b
  712f05:	je     712f14 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5394>
  712f07:	lea    0x1d8(%rsp),%rdi
  712f0f:	call   6c1190 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  712f14:	cmpl   $0xfffffffe,0x748(%rsp)
  712f1c:	je     712f36 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x53b6>
  712f1e:	lea    0x748(%rsp),%rdi
  712f26:	call   6c5340 <core::ptr::drop_glue::<gpui::runtime::Error>>
  712f2b:	jmp    712f36 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x53b6>
  712f2d:	mov    %rax,%rbx
  712f30:	mov    $0x1,%r12b
  712f33:	mov    $0x1,%bpl
  712f36:	cmpq   $0x0,0x1c8(%rsp)
  712f3f:	je     712f4e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x53ce>
  712f41:	mov    0x1d0(%rsp),%rdi
  712f49:	call   6c5a90 <core::ptr::drop_glue::<gpui_canvas::text::TextShaper>>
  712f4e:	test   %r12b,%r12b
  712f51:	je     712f60 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x53e0>
  712f53:	lea    0x288(%rsp),%rdi
  712f5b:	call   6c1520 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  712f60:	mov    0x140(%rsp),%rax
  712f68:	test   %rax,%rax
  712f6b:	je     712f81 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5401>
  712f6d:	lock decq (%rax)
  712f71:	jne    712f81 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5401>
  712f73:	lea    0x140(%rsp),%rdi
  712f7b:	call   *0x32f3a7(%rip)        # a42328 <_DYNAMIC+0x338>
  712f81:	cmpl   $0x2,0xc10(%rsp)
  712f89:	je     712f9d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x541d>
  712f8b:	test   %bpl,%bpl
  712f8e:	je     712f9d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x541d>
  712f90:	lea    0xc10(%rsp),%rdi
  712f98:	call   6c6030 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  712f9d:	mov    %rbx,%rdi
  712fa0:	call   a20740 <_Unwind_Resume@plt>
  712fa5:	call   *0x32f2d5(%rip)        # a42280 <_DYNAMIC+0x290>

<gpui::runtime::text_geometry::TextResources>::acknowledge code=336 fixed_stack=104

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

000000000072e620 <<gpui::runtime::text_geometry::TextResources>::acknowledge>:
  72e620:	push   %rbp
  72e621:	push   %r15
  72e623:	push   %r14
  72e625:	push   %r13
  72e627:	push   %r12
  72e629:	push   %rbx
  72e62a:	sub    $0x38,%rsp
  72e62e:	mov    0x18(%rdi),%rax
  72e632:	movq   $0xffffffffffffffff,0x18(%rdi)
  72e63a:	cmp    $0xffffffffffffffff,%rax
  72e63e:	je     72e6e6 <<gpui::runtime::text_geometry::TextResources>::acknowledge+0xc6>
  72e644:	mov    %rdi,%rbx
  72e647:	mov    %rax,0x10(%rsp)
  72e64c:	movups 0x20(%rdi),%xmm0
  72e650:	movaps %xmm0,0x20(%rsp)
  72e655:	lea    0x8(%rdi),%rax
  72e659:	mov    %rax,0x8(%rsp)
  72e65e:	mov    0x8(%rdi),%r14
  72e662:	mov    0x10(%rdi),%rax
  72e666:	test   %rax,%rax
  72e669:	je     72e6b3 <<gpui::runtime::text_geometry::TextResources>::acknowledge+0x93>
  72e66b:	mov    $0x1,%r15d
  72e671:	sub    %rax,%r15
  72e674:	mov    $0xffffffffffffffe8,%r13
  72e67b:	xor    %r12d,%r12d
  72e67e:	mov    0x313cb3(%rip),%rbp        # a42338 <_DYNAMIC+0x348>
  72e685:	jmp    72e6a1 <<gpui::runtime::text_geometry::TextResources>::acknowledge+0x81>
  72e687:	nopw   0x0(%rax,%rax,1)
  72e690:	add    $0xffffffffffffffe8,%r13
  72e694:	inc    %r15
  72e697:	add    $0x18,%r12
  72e69b:	cmp    $0x1,%r15
  72e69f:	je     72e6b3 <<gpui::runtime::text_geometry::TextResources>::acknowledge+0x93>
  72e6a1:	mov    (%r14,%r12,1),%rax
  72e6a5:	lock decq (%rax)
  72e6a9:	jne    72e690 <<gpui::runtime::text_geometry::TextResources>::acknowledge+0x70>
  72e6ab:	lea    (%r14,%r12,1),%rdi
  72e6af:	call   *%rbp
  72e6b1:	jmp    72e690 <<gpui::runtime::text_geometry::TextResources>::acknowledge+0x70>
  72e6b3:	mov    (%rbx),%rax
  72e6b6:	test   %rax,%rax
  72e6b9:	je     72e6d1 <<gpui::runtime::text_geometry::TextResources>::acknowledge+0xb1>
  72e6bb:	shl    $0x3,%rax
  72e6bf:	lea    (%rax,%rax,2),%rsi
  72e6c3:	mov    $0x8,%edx
  72e6c8:	mov    %r14,%rdi
  72e6cb:	call   *0x313b87(%rip)        # a42258 <_DYNAMIC+0x268>
  72e6d1:	mov    0x10(%rsp),%rax
  72e6d6:	mov    %rax,(%rbx)
  72e6d9:	movaps 0x20(%rsp),%xmm0
  72e6de:	mov    0x8(%rsp),%rax
  72e6e3:	movups %xmm0,(%rax)
  72e6e6:	add    $0x38,%rsp
  72e6ea:	pop    %rbx
  72e6eb:	pop    %r12
  72e6ed:	pop    %r13
  72e6ef:	pop    %r14
  72e6f1:	pop    %r15
  72e6f3:	pop    %rbp
  72e6f4:	ret
  72e6f5:	mov    %rax,0x18(%rsp)
  72e6fa:	test   %r15,%r15
  72e6fd:	jne    72e73c <<gpui::runtime::text_geometry::TextResources>::acknowledge+0x11c>
  72e6ff:	mov    (%rbx),%rax
  72e702:	test   %rax,%rax
  72e705:	je     72e71d <<gpui::runtime::text_geometry::TextResources>::acknowledge+0xfd>
  72e707:	shl    $0x3,%rax
  72e70b:	lea    (%rax,%rax,2),%rsi
  72e70f:	mov    $0x8,%edx
  72e714:	mov    %r14,%rdi
  72e717:	call   *0x313b3b(%rip)        # a42258 <_DYNAMIC+0x268>
  72e71d:	mov    0x10(%rsp),%rax
  72e722:	mov    %rax,(%rbx)
  72e725:	movaps 0x20(%rsp),%xmm0
  72e72a:	mov    0x8(%rsp),%rax
  72e72f:	movups %xmm0,(%rax)
  72e732:	mov    0x18(%rsp),%rdi
  72e737:	call   a20740 <_Unwind_Resume@plt>
  72e73c:	mov    %r14,%r12
  72e73f:	sub    %r13,%r12
  72e742:	neg    %r15
  72e745:	jmp    72e759 <<gpui::runtime::text_geometry::TextResources>::acknowledge+0x139>
  72e747:	nopw   0x0(%rax,%rax,1)
  72e750:	add    $0x18,%r12
  72e754:	dec    %r15
  72e757:	je     72e6ff <<gpui::runtime::text_geometry::TextResources>::acknowledge+0xdf>
  72e759:	mov    (%r12),%rax
  72e75d:	lock decq (%rax)
  72e761:	jne    72e750 <<gpui::runtime::text_geometry::TextResources>::acknowledge+0x130>
  72e763:	mov    %r12,%rdi
  72e766:	call   *%rbp
  72e768:	jmp    72e750 <<gpui::runtime::text_geometry::TextResources>::acknowledge+0x130>
  72e76a:	call   *0x313b10(%rip)        # a42280 <_DYNAMIC+0x290>

<gpui::runtime::geometry::Geometry>::acknowledge code=76 fixed_stack=24

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000007354a0 <<gpui::runtime::geometry::Geometry>::acknowledge>:
  7354a0:	push   %r15
  7354a2:	push   %r14
  7354a4:	push   %rbx
  7354a5:	mov    0x30(%rdi),%r14
  7354a9:	movq   $0xffffffffffffffff,0x30(%rdi)
  7354b1:	cmp    $0xffffffffffffffff,%r14
  7354b5:	je     7354e6 <<gpui::runtime::geometry::Geometry>::acknowledge+0x46>
  7354b7:	mov    %rdi,%rbx
  7354ba:	lea    0x38(%rdi),%r15
  7354be:	mov    0x18(%rdi),%rsi
  7354c2:	test   %rsi,%rsi
  7354c5:	je     7354da <<gpui::runtime::geometry::Geometry>::acknowledge+0x3a>
  7354c7:	mov    0x20(%rbx),%rdi
  7354cb:	shl    $0x4,%rsi
  7354cf:	mov    $0x4,%edx
  7354d4:	call   *0x30cd7e(%rip)        # a42258 <_DYNAMIC+0x268>
  7354da:	mov    %r14,0x18(%rbx)
  7354de:	movups (%r15),%xmm0
  7354e2:	movups %xmm0,0x20(%rbx)
  7354e6:	pop    %rbx
  7354e7:	pop    %r14
  7354e9:	pop    %r15
  7354eb:	ret

gpui::runtime::image::acknowledge code=157 fixed_stack=40

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

0000000000739cd0 <gpui::runtime::image::acknowledge>:
  739cd0:	push   %r15
  739cd2:	push   %r14
  739cd4:	push   %rbx
  739cd5:	sub    $0x10,%rsp
  739cd9:	mov    (%rdi),%r14
  739cdc:	test   %r14,%r14
  739cdf:	je     739d3f <gpui::runtime::image::acknowledge+0x6f>
  739ce1:	mov    %rdi,%rbx
  739ce4:	mov    0x38(%r14),%r15
  739ce8:	cmp    $0xffffffffffffffff,%r15
  739cec:	je     739d1b <gpui::runtime::image::acknowledge+0x4b>
  739cee:	cmp    %rsi,0x30(%r14)
  739cf2:	jne    739d1b <gpui::runtime::image::acknowledge+0x4b>
  739cf4:	movups 0x40(%r14),%xmm0
  739cf9:	movaps %xmm0,(%rsp)
  739cfd:	movq   $0xffffffffffffffff,0x38(%r14)
  739d05:	lea    0x18(%r14),%rdi
  739d09:	call   72a730 <core::ptr::drop_glue::<alloc::vec::Vec<gpui_canvas::image::Image>>>
  739d0e:	mov    %r15,0x18(%r14)
  739d12:	movaps (%rsp),%xmm0
  739d16:	movups %xmm0,0x20(%r14)
  739d1b:	cmpq   $0x0,0x10(%r14)
  739d20:	jne    739d3f <gpui::runtime::image::acknowledge+0x6f>
  739d22:	cmpq   $0x0,0x28(%r14)
  739d27:	jne    739d3f <gpui::runtime::image::acknowledge+0x6f>
  739d29:	cmpq   $0xffffffffffffffff,0x38(%r14)
  739d2e:	jne    739d3f <gpui::runtime::image::acknowledge+0x6f>
  739d30:	mov    %r14,%rdi
  739d33:	call   72a3d0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::image::Images>>>>
  739d38:	movq   $0x0,(%rbx)
  739d3f:	add    $0x10,%rsp
  739d43:	pop    %rbx
  739d44:	pop    %r14
  739d46:	pop    %r15
  739d48:	ret
  739d49:	movq   $0x0,(%rbx)
  739d50:	mov    %rax,%rdi
  739d53:	call   a20740 <_Unwind_Resume@plt>
  739d58:	mov    %r15,0x18(%r14)
  739d5c:	movaps (%rsp),%xmm0
  739d60:	movups %xmm0,0x20(%r14)
  739d65:	mov    %rax,%rdi
  739d68:	call   a20740 <_Unwind_Resume@plt>

gpui::runtime::query::contains_point code=922 fixed_stack=168

/tmp/gpui-text-column-cpu-evidence/codegen-baseline-frozen:     file format elf64-x86-64


Disassembly of section .text:

000000000073ba90 <gpui::runtime::query::contains_point>:
  73ba90:	push   %rbp
  73ba91:	push   %r15
  73ba93:	push   %r14
  73ba95:	push   %r13
  73ba97:	push   %r12
  73ba99:	push   %rbx
  73ba9a:	sub    $0x78,%rsp
  73ba9e:	mov    %r8,%r12
  73baa1:	mov    %rsi,%rbx
  73baa4:	cmp    %rsi,%r8
  73baa7:	jae    73bdf1 <gpui::runtime::query::contains_point+0x361>
  73baad:	mov    %ecx,%ebp
  73baaf:	mov    %rdx,%r13
  73bab2:	mov    %rdi,%r14
  73bab5:	shl    $0x6,%r12
  73bab9:	add    %r12,%rdi
  73babc:	add    $0x10,%rdi
  73bac0:	movss  %xmm0,0xc(%rsp)
  73bac6:	movss  %xmm1,0x10(%rsp)
  73bacc:	call   *0x306a66(%rip)        # a42538 <_DYNAMIC+0x548>
  73bad2:	test   %al,%al
  73bad4:	je     73bb14 <gpui::runtime::query::contains_point+0x84>
  73bad6:	mov    0x8(%r13),%rdx
  73bada:	mov    0x10(%r13),%r15
  73bade:	cmp    %r15,%rdx
  73bae1:	jb     73bdcf <gpui::runtime::query::contains_point+0x33f>
  73bae7:	mov    %ebp,0x14(%rsp)
  73baeb:	add    %r14,%r12
  73baee:	mov    0x0(%r13),%rbp
  73baf2:	mov    0x30(%r12),%rcx
  73baf7:	movsd  (%r12),%xmm1
  73bafd:	mov    %rcx,%rdi
  73bb00:	shr    $0x20,%rdi
  73bb04:	cmp    $0x7fc00001,%ecx
  73bb0a:	je     73bb29 <gpui::runtime::query::contains_point+0x99>
  73bb0c:	cmp    $0x7fc00002,%ecx
  73bb12:	jne    73bb46 <gpui::runtime::query::contains_point+0xb6>
  73bb14:	xor    %r13d,%r13d
  73bb17:	mov    %r13d,%eax
  73bb1a:	add    $0x78,%rsp
  73bb1e:	pop    %rbx
  73bb1f:	pop    %r12
  73bb21:	pop    %r13
  73bb23:	pop    %r14
  73bb25:	pop    %r15
  73bb27:	pop    %rbp
  73bb28:	ret
  73bb29:	cmp    %r15,%rdi
  73bb2c:	jae    73be04 <gpui::runtime::query::contains_point+0x374>
  73bb32:	shl    $0x4,%rdi
  73bb36:	mov    0x0(%rbp,%rdi,1),%ecx
  73bb3a:	movq   0x4(%rbp,%rdi,1),%xmm2
  73bb40:	mov    0xc(%rbp,%rdi,1),%edi
  73bb44:	jmp    73bb4a <gpui::runtime::query::contains_point+0xba>
  73bb46:	pxor   %xmm2,%xmm2
  73bb4a:	mov    %ecx,0x18(%rsp)
  73bb4e:	movq   %xmm2,0x1c(%rsp)
  73bb54:	mov    %edi,0x24(%rsp)
  73bb58:	movlps %xmm1,0x28(%rsp)
  73bb5d:	sub    %r15,%rdx
  73bb60:	je     73bbd6 <gpui::runtime::query::contains_point+0x146>
  73bb62:	mov    0x20(%r12),%r8
  73bb67:	mov    %r15,%rsi
  73bb6a:	shl    $0x4,%rsi
  73bb6e:	add    %rbp,%rsi
  73bb71:	xor    %eax,%eax
  73bb73:	cmp    $0x1,%rdx
  73bb77:	je     73bba5 <gpui::runtime::query::contains_point+0x115>
  73bb79:	mov    %rdx,%r9
  73bb7c:	nopl   0x0(%rax)
  73bb80:	mov    %rax,%r10
  73bb83:	mov    %r9,%r11
  73bb86:	shr    $1,%r11
  73bb89:	add    %r11,%rax
  73bb8c:	mov    %rax,%r13
  73bb8f:	shl    $0x4,%r13
  73bb93:	cmp    %r8,0x8(%rsi,%r13,1)
  73bb98:	cmova  %r10,%rax
  73bb9c:	sub    %r11,%r9
  73bb9f:	cmp    $0x1,%r9
  73bba3:	ja     73bb80 <gpui::runtime::query::contains_point+0xf0>
  73bba5:	mov    %rax,%r9
  73bba8:	shl    $0x4,%r9
  73bbac:	cmp    %r8,0x8(%rsi,%r9,1)
  73bbb1:	jne    73bbd6 <gpui::runtime::query::contains_point+0x146>
  73bbb3:	cmp    %rdx,%rax
  73bbb6:	jae    73be14 <gpui::runtime::query::contains_point+0x384>
  73bbbc:	add    %r9,%rsi
  73bbbf:	movss  0x4(%rsi),%xmm0
  73bbc4:	xorps  %xmm3,%xmm3
  73bbc7:	ucomiss %xmm3,%xmm0
  73bbca:	jne    73bd70 <gpui::runtime::query::contains_point+0x2e0>
  73bbd0:	jp     73bd70 <gpui::runtime::query::contains_point+0x2e0>
  73bbd6:	movd   %edi,%xmm0
  73bbda:	movd   %ecx,%xmm3
  73bbde:	punpckldq %xmm2,%xmm3
  73bbe2:	cvtps2pd %xmm3,%xmm3
  73bbe5:	shufps $0xd4,%xmm2,%xmm0
  73bbe9:	shufps $0x52,%xmm2,%xmm0
  73bbed:	cvtps2pd %xmm0,%xmm0
  73bbf0:	cvtps2pd %xmm1,%xmm1
  73bbf3:	movaps %xmm3,0x30(%rsp)
  73bbf8:	movaps %xmm0,0x40(%rsp)
  73bbfd:	movaps %xmm1,0x50(%rsp)
  73bc02:	movb   $0x0,0x60(%rsp)
  73bc07:	movq   $0x0,0x68(%rsp)
  73bc10:	movsd  0x8(%r12),%xmm0
  73bc17:	movsd  %xmm0,0x70(%rsp)
  73bc1d:	lea    0x30(%rsp),%rdi
  73bc22:	lea    0x68(%rsp),%rsi
  73bc27:	movss  0xc(%rsp),%xmm0
  73bc2d:	movss  0x10(%rsp),%xmm1
  73bc33:	call   *0x306e9f(%rip)        # a42ad8 <_DYNAMIC+0xae8>
  73bc39:	mov    %eax,%r13d
  73bc3c:	test   %al,0x14(%rsp)
  73bc40:	je     73bb17 <gpui::runtime::query::contains_point+0x87>
  73bc46:	mov    $0x1ffff,%ecx
  73bc4b:	mov    0x38(%r12),%eax
  73bc50:	and    %ecx,%eax
  73bc52:	mov    $0x1,%r13b
  73bc55:	jmp    73bce9 <gpui::runtime::query::contains_point+0x259>
  73bc5a:	nopw   0x0(%rax,%rax,1)
  73bc60:	cmp    $0x7fc00002,%eax
  73bc65:	je     73bb14 <gpui::runtime::query::contains_point+0x84>
  73bc6b:	xorps  %xmm2,%xmm2
  73bc6e:	movd   %eax,%xmm3
  73bc72:	cvtss2sd %xmm3,%xmm3
  73bc76:	cvtss2sd %xmm1,%xmm1
  73bc7a:	movsd  %xmm3,0x30(%rsp)
  73bc80:	movups %xmm2,0x38(%rsp)
  73bc85:	movd   %edi,%xmm2
  73bc89:	movlhps %xmm2,%xmm0
  73bc8c:	shufps $0xe2,%xmm2,%xmm0
  73bc90:	cvtps2pd %xmm0,%xmm0
  73bc93:	movups %xmm0,0x48(%rsp)
  73bc98:	movsd  %xmm1,0x58(%rsp)
  73bc9e:	movb   $0x0,0x60(%rsp)
  73bca3:	movq   $0x0,0x18(%rsp)
  73bcac:	movsd  0x8(%r12),%xmm0
  73bcb3:	movsd  %xmm0,0x20(%rsp)
  73bcb9:	lea    0x30(%rsp),%rdi
  73bcbe:	lea    0x18(%rsp),%rsi
  73bcc3:	movss  0xc(%rsp),%xmm0
  73bcc9:	movss  0x10(%rsp),%xmm1
  73bccf:	call   *0x306e03(%rip)        # a42ad8 <_DYNAMIC+0xae8>
  73bcd5:	test   %al,%al
  73bcd7:	je     73bb14 <gpui::runtime::query::contains_point+0x84>
  73bcdd:	mov    0x38(%r12),%eax
  73bce2:	mov    $0x1ffff,%ecx
  73bce7:	and    %ecx,%eax
  73bce9:	cmp    $0x1ffff,%eax
  73bcee:	je     73bb17 <gpui::runtime::query::contains_point+0x87>
  73bcf4:	mov    %eax,%edi
  73bcf6:	cmp    %rdi,%rbx
  73bcf9:	jbe    73bde1 <gpui::runtime::query::contains_point+0x351>
  73bcff:	shl    $0x6,%rdi
  73bd03:	lea    (%r14,%rdi,1),%r12
  73bd07:	movzbl 0x3d(%r14,%rdi,1),%eax
  73bd0d:	sub    $0x2,%al
  73bd0f:	movzbl %al,%eax
  73bd12:	mov    $0x8,%ecx
  73bd17:	cmovb  %ecx,%eax
  73bd1a:	cmp    $0x7,%al
  73bd1c:	ja     73bcdd <gpui::runtime::query::contains_point+0x24d>
  73bd1e:	movzbl %al,%eax
  73bd21:	mov    $0xb0,%ecx
  73bd26:	bt     %eax,%ecx
  73bd29:	jae    73bcdd <gpui::runtime::query::contains_point+0x24d>
  73bd2b:	mov    0x30(%r12),%rax
  73bd30:	movss  (%r12),%xmm0
  73bd36:	movss  0x4(%r12),%xmm1
  73bd3d:	mov    %rax,%rdi
  73bd40:	shr    $0x20,%rdi
  73bd44:	cmp    $0x7fc00001,%eax
  73bd49:	jne    73bc60 <gpui::runtime::query::contains_point+0x1d0>
  73bd4f:	cmp    %r15,%rdi
  73bd52:	jae    73be04 <gpui::runtime::query::contains_point+0x374>
  73bd58:	shl    $0x4,%rdi
  73bd5c:	mov    0x0(%rbp,%rdi,1),%eax
  73bd60:	cvtps2pd 0x4(%rbp,%rdi,1),%xmm2
  73bd65:	mov    0xc(%rbp,%rdi,1),%ecx
  73bd69:	mov    %ecx,%edi
  73bd6b:	jmp    73bc6e <gpui::runtime::query::contains_point+0x1de>
  73bd70:	movq   $0x0,0x30(%rsp)
  73bd79:	movsd  0x8(%r12),%xmm1
  73bd80:	movsd  %xmm1,0x38(%rsp)
  73bd86:	lea    0x30(%rsp),%rdi
  73bd8b:	lea    0x18(%rsp),%rsi
  73bd90:	movss  0xc(%rsp),%xmm1
  73bd96:	movss  0x10(%rsp),%xmm2
  73bd9c:	call   *0x306d3e(%rip)        # a42ae0 <_DYNAMIC+0xaf0>
  73bda2:	movabs $0x1ffffffff,%rcx
  73bdac:	and    %rcx,%rax
  73bdaf:	cmp    %rcx,%rax
  73bdb2:	sete   %r13b
  73bdb6:	cmpb   $0x0,0x14(%rsp)
  73bdbb:	je     73bb17 <gpui::runtime::query::contains_point+0x87>
  73bdc1:	cmp    %rcx,%rax
  73bdc4:	je     73bc46 <gpui::runtime::query::contains_point+0x1b6>
  73bdca:	jmp    73bb17 <gpui::runtime::query::contains_point+0x87>
  73bdcf:	lea    0x2e8c62(%rip),%rcx        # a24a38 <__frame_dummy_init_array_entry+0x2f48>
  73bdd6:	xor    %edi,%edi
  73bdd8:	mov    %r15,%rsi
  73bddb:	call   *0x306637(%rip)        # a42418 <_DYNAMIC+0x428>
  73bde1:	lea    0x2e9180(%rip),%rdx        # a24f68 <gpui::property::WRAP_DECL+0x50>
  73bde8:	mov    %rbx,%rsi
  73bdeb:	call   *0x306497(%rip)        # a42288 <_DYNAMIC+0x298>
  73bdf1:	lea    0x2e9158(%rip),%rdx        # a24f50 <gpui::property::WRAP_DECL+0x38>
  73bdf8:	mov    %r12,%rdi
  73bdfb:	mov    %rbx,%rsi
  73bdfe:	call   *0x306484(%rip)        # a42288 <_DYNAMIC+0x298>
  73be04:	lea    0x2e8b0d(%rip),%rdx        # a24918 <__frame_dummy_init_array_entry+0x2e28>
  73be0b:	mov    %r15,%rsi
  73be0e:	call   *0x306474(%rip)        # a42288 <_DYNAMIC+0x298>
  73be14:	lea    0x2e87d5(%rip),%rcx        # a245f0 <__frame_dummy_init_array_entry+0x2b00>
  73be1b:	mov    %rax,%rdi
  73be1e:	mov    %rdx,%rsi
  73be21:	mov    %rcx,%rdx
  73be24:	call   *0x30645e(%rip)        # a42288 <_DYNAMIC+0x298>
