
text_column_public_control::ack::<text_column_public_control::Input> code=273 fixed_stack=136

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006b5ea0 <text_column_public_control::ack::<text_column_public_control::Input>>:
  6b5ea0:	push   %r14
  6b5ea2:	push   %rbx
  6b5ea3:	sub    $0x78,%rsp
  6b5ea7:	test   %rsi,%rsi
  6b5eaa:	je     6b5eff <text_column_public_control::ack::<text_column_public_control::Input>+0x5f>
  6b5eac:	cmpb   $0x0,0x74e(%rsi)
  6b5eb3:	jne    6b5f06 <text_column_public_control::ack::<text_column_public_control::Input>+0x66>
  6b5eb5:	mov    0x6b0(%rsi),%rdx
  6b5ebc:	test   %rdx,%rdx
  6b5ebf:	je     6b5f0d <text_column_public_control::ack::<text_column_public_control::Input>+0x6d>
  6b5ec1:	mov    %rdi,%rbx
  6b5ec4:	mov    0x6b8(%rsi),%rcx
  6b5ecb:	lea    0x8(%rsp),%rdi
  6b5ed0:	call   6fe1d0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge>
  6b5ed5:	cmpq   $0xfffffffffffffffe,0x8(%rsp)
  6b5edb:	jne    6b5f4a <text_column_public_control::ack::<text_column_public_control::Input>+0xaa>
  6b5edd:	movups 0x10(%rsp),%xmm0
  6b5ee2:	movups 0x20(%rsp),%xmm1
  6b5ee7:	movups 0x30(%rsp),%xmm2
  6b5eec:	movups %xmm2,0x20(%rbx)
  6b5ef0:	movups %xmm1,0x10(%rbx)
  6b5ef4:	movups %xmm0,(%rbx)
  6b5ef7:	add    $0x78,%rsp
  6b5efb:	pop    %rbx
  6b5efc:	pop    %r14
  6b5efe:	ret
  6b5eff:	mov    $0xd,%eax
  6b5f04:	jmp    6b5f12 <text_column_public_control::ack::<text_column_public_control::Input>+0x72>
  6b5f06:	mov    $0xe,%eax
  6b5f0b:	jmp    6b5f12 <text_column_public_control::ack::<text_column_public_control::Input>+0x72>
  6b5f0d:	mov    $0x14,%eax
  6b5f12:	mov    %rax,0x40(%rsp)
  6b5f17:	movq   $0x0,0x48(%rsp)
  6b5f20:	lea    -0x668750(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6b5f27:	lea    0x36d2fa(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6b5f2e:	lea    0x36c0c3(%rip),%r8        # a21ff8 <__frame_dummy_init_array_entry+0x8>
  6b5f35:	lea    0x40(%rsp),%rbx
  6b5f3a:	mov    $0x2b,%esi
  6b5f3f:	mov    %rbx,%rdx
  6b5f42:	call   *0x38c890(%rip)        # a427d8 <_DYNAMIC+0x240>
  6b5f48:	jmp    6b5f9a <text_column_public_control::ack::<text_column_public_control::Input>+0xfa>
  6b5f4a:	mov    0x38(%rsp),%rax
  6b5f4f:	mov    %rax,0x70(%rsp)
  6b5f54:	movups 0x8(%rsp),%xmm0
  6b5f59:	movups 0x18(%rsp),%xmm1
  6b5f5e:	movups 0x28(%rsp),%xmm2
  6b5f63:	movaps %xmm2,0x60(%rsp)
  6b5f68:	movaps %xmm1,0x50(%rsp)
  6b5f6d:	movaps %xmm0,0x40(%rsp)
  6b5f72:	lea    -0x6687a2(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6b5f79:	lea    0x36d2a8(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6b5f80:	lea    0x36c089(%rip),%r8        # a22010 <__frame_dummy_init_array_entry+0x20>
  6b5f87:	lea    0x40(%rsp),%rbx
  6b5f8c:	mov    $0x2b,%esi
  6b5f91:	mov    %rbx,%rdx
  6b5f94:	call   *0x38c83e(%rip)        # a427d8 <_DYNAMIC+0x240>
  6b5f9a:	ud2
  6b5f9c:	jmp    6b5f9e <text_column_public_control::ack::<text_column_public_control::Input>+0xfe>
  6b5f9e:	mov    %rax,%r14
  6b5fa1:	mov    %rbx,%rdi
  6b5fa4:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6b5fa9:	mov    %r14,%rdi
  6b5fac:	call   a20c40 <_Unwind_Resume@plt>

text_column_public_control::ack::<text_column_public_control::Model> code=273 fixed_stack=136

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006b5fc0 <text_column_public_control::ack::<text_column_public_control::Model>>:
  6b5fc0:	push   %r14
  6b5fc2:	push   %rbx
  6b5fc3:	sub    $0x78,%rsp
  6b5fc7:	test   %rsi,%rsi
  6b5fca:	je     6b601f <text_column_public_control::ack::<text_column_public_control::Model>+0x5f>
  6b5fcc:	cmpb   $0x0,0x78e(%rsi)
  6b5fd3:	jne    6b6026 <text_column_public_control::ack::<text_column_public_control::Model>+0x66>
  6b5fd5:	mov    0x6f0(%rsi),%rdx
  6b5fdc:	test   %rdx,%rdx
  6b5fdf:	je     6b602d <text_column_public_control::ack::<text_column_public_control::Model>+0x6d>
  6b5fe1:	mov    %rdi,%rbx
  6b5fe4:	mov    0x6f8(%rsi),%rcx
  6b5feb:	lea    0x8(%rsp),%rdi
  6b5ff0:	call   70d850 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge>
  6b5ff5:	cmpq   $0xfffffffffffffffe,0x8(%rsp)
  6b5ffb:	jne    6b606a <text_column_public_control::ack::<text_column_public_control::Model>+0xaa>
  6b5ffd:	movups 0x10(%rsp),%xmm0
  6b6002:	movups 0x20(%rsp),%xmm1
  6b6007:	movups 0x30(%rsp),%xmm2
  6b600c:	movups %xmm2,0x20(%rbx)
  6b6010:	movups %xmm1,0x10(%rbx)
  6b6014:	movups %xmm0,(%rbx)
  6b6017:	add    $0x78,%rsp
  6b601b:	pop    %rbx
  6b601c:	pop    %r14
  6b601e:	ret
  6b601f:	mov    $0xd,%eax
  6b6024:	jmp    6b6032 <text_column_public_control::ack::<text_column_public_control::Model>+0x72>
  6b6026:	mov    $0xe,%eax
  6b602b:	jmp    6b6032 <text_column_public_control::ack::<text_column_public_control::Model>+0x72>
  6b602d:	mov    $0x14,%eax
  6b6032:	mov    %rax,0x40(%rsp)
  6b6037:	movq   $0x0,0x48(%rsp)
  6b6040:	lea    -0x668870(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6b6047:	lea    0x36d1da(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6b604e:	lea    0x36bfa3(%rip),%r8        # a21ff8 <__frame_dummy_init_array_entry+0x8>
  6b6055:	lea    0x40(%rsp),%rbx
  6b605a:	mov    $0x2b,%esi
  6b605f:	mov    %rbx,%rdx
  6b6062:	call   *0x38c770(%rip)        # a427d8 <_DYNAMIC+0x240>
  6b6068:	jmp    6b60ba <text_column_public_control::ack::<text_column_public_control::Model>+0xfa>
  6b606a:	mov    0x38(%rsp),%rax
  6b606f:	mov    %rax,0x70(%rsp)
  6b6074:	movups 0x8(%rsp),%xmm0
  6b6079:	movups 0x18(%rsp),%xmm1
  6b607e:	movups 0x28(%rsp),%xmm2
  6b6083:	movaps %xmm2,0x60(%rsp)
  6b6088:	movaps %xmm1,0x50(%rsp)
  6b608d:	movaps %xmm0,0x40(%rsp)
  6b6092:	lea    -0x6688c2(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6b6099:	lea    0x36d188(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6b60a0:	lea    0x36bf69(%rip),%r8        # a22010 <__frame_dummy_init_array_entry+0x20>
  6b60a7:	lea    0x40(%rsp),%rbx
  6b60ac:	mov    $0x2b,%esi
  6b60b1:	mov    %rbx,%rdx
  6b60b4:	call   *0x38c71e(%rip)        # a427d8 <_DYNAMIC+0x240>
  6b60ba:	ud2
  6b60bc:	jmp    6b60be <text_column_public_control::ack::<text_column_public_control::Model>+0xfe>
  6b60be:	mov    %rax,%r14
  6b60c1:	mov    %rbx,%rdi
  6b60c4:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6b60c9:	mov    %r14,%rdi
  6b60cc:	call   a20c40 <_Unwind_Resume@plt>

text_column_public_control::observe::<text_column_public_control::Model> code=1653 fixed_stack=376

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006b60e0 <text_column_public_control::observe::<text_column_public_control::Model>>:
  6b60e0:	push   %rbp
  6b60e1:	push   %r15
  6b60e3:	push   %r14
  6b60e5:	push   %r13
  6b60e7:	push   %r12
  6b60e9:	push   %rbx
  6b60ea:	sub    $0x148,%rsp
  6b60f1:	test   %rsi,%rsi
  6b60f4:	je     6b66ec <text_column_public_control::observe::<text_column_public_control::Model>+0x60c>
  6b60fa:	mov    %rsi,%rbx
  6b60fd:	cmpb   $0x0,0x78e(%rsi)
  6b6104:	jne    6b66f3 <text_column_public_control::observe::<text_column_public_control::Model>+0x613>
  6b610a:	cmpb   $0x1,0x78c(%rbx)
  6b6111:	jne    6b66fa <text_column_public_control::observe::<text_column_public_control::Model>+0x61a>
  6b6117:	mov    0x708(%rbx),%rdx
  6b611e:	mov    0x6e0(%rbx),%r12
  6b6125:	mov    0x5e8(%rbx),%rbp
  6b612c:	mov    0x5f0(%rbx),%rax
  6b6133:	mov    %rax,0x8(%rsp)
  6b6138:	movups 0x658(%rbx),%xmm1
  6b613f:	mov    0x680(%rbx),%r13
  6b6146:	test   %r13,%r13
  6b6149:	mov    %rdi,0x80(%rsp)
  6b6151:	je     6b6193 <text_column_public_control::observe::<text_column_public_control::Model>+0xb3>
  6b6153:	mov    0xe0(%r13),%rax
  6b615a:	test   %rax,%rax
  6b615d:	je     6b61af <text_column_public_control::observe::<text_column_public_control::Model>+0xcf>
  6b615f:	mov    0x38(%rax),%ecx
  6b6162:	mov    %ecx,0x20(%rsp)
  6b6166:	movups 0x28(%rax),%xmm0
  6b616a:	movaps %xmm0,0x10(%rsp)
  6b616f:	movzbl 0x3c(%rax),%r15d
  6b6174:	movzbl 0x3f(%rax),%ecx
  6b6178:	mov    %cl,0x62(%rsp)
  6b617c:	movzwl 0x3d(%rax),%eax
  6b6180:	mov    %ax,0x60(%rsp)
  6b6185:	mov    0x100(%r13),%rsi
  6b618c:	test   %rsi,%rsi
  6b618f:	jne    6b61be <text_column_public_control::observe::<text_column_public_control::Model>+0xde>
  6b6191:	jmp    6b6196 <text_column_public_control::observe::<text_column_public_control::Model>+0xb6>
  6b6193:	mov    $0x2,%r15b
  6b6196:	movq   $0x4,0x100(%rsp)
  6b61a2:	xorps  %xmm0,%xmm0
  6b61a5:	movups %xmm0,0x108(%rsp)
  6b61ad:	jmp    6b61dc <text_column_public_control::observe::<text_column_public_control::Model>+0xfc>
  6b61af:	mov    $0x2,%r15b
  6b61b2:	mov    0x100(%r13),%rsi
  6b61b9:	test   %rsi,%rsi
  6b61bc:	je     6b6196 <text_column_public_control::observe::<text_column_public_control::Model>+0xb6>
  6b61be:	lea    0x100(%rsp),%rdi
  6b61c6:	mov    %rdx,%r14
  6b61c9:	movaps %xmm1,0x50(%rsp)
  6b61ce:	call   *0x38c60c(%rip)        # a427e0 <_DYNAMIC+0x248>
  6b61d4:	movaps 0x50(%rsp),%xmm1
  6b61d9:	mov    %r14,%rdx
  6b61dc:	movabs $0xcbf29ce484222325,%r14
  6b61e6:	add    $0x620,%rbx
  6b61ed:	mov    %rbx,0xe0(%rsp)
  6b61f5:	mov    %rdx,0xb0(%rsp)
  6b61fd:	mov    %r12,0xb8(%rsp)
  6b6205:	mov    %rbp,0xa0(%rsp)
  6b620d:	mov    0x8(%rsp),%rcx
  6b6212:	mov    %rcx,0xa8(%rsp)
  6b621a:	movaps %xmm1,0x90(%rsp)
  6b6222:	mov    %r13,0xc0(%rsp)
  6b622a:	mov    0x100(%rsp),%rax
  6b6232:	mov    %rax,0xc8(%rsp)
  6b623a:	mov    0x108(%rsp),%rax
  6b6242:	mov    %rax,0xd0(%rsp)
  6b624a:	mov    0x110(%rsp),%rax
  6b6252:	mov    %rax,0xd8(%rsp)
  6b625a:	movaps 0x10(%rsp),%xmm0
  6b625f:	movups %xmm0,0xe8(%rsp)
  6b6267:	mov    0x20(%rsp),%eax
  6b626b:	mov    %eax,0xf8(%rsp)
  6b6272:	mov    %r15b,0xfc(%rsp)
  6b627a:	movzwl 0x60(%rsp),%eax
  6b627f:	mov    %ax,0xfd(%rsp)
  6b6287:	movzbl 0x62(%rsp),%eax
  6b628c:	mov    %al,0xff(%rsp)
  6b6293:	test   %rcx,%rcx
  6b6296:	je     6b66b6 <text_column_public_control::observe::<text_column_public_control::Model>+0x5d6>
  6b629c:	movabs $0x100000001b3,%r13
  6b62a6:	xor    %edx,%edx
  6b62a8:	lea    0x10(%rsp),%rdi
  6b62ad:	lea    0x100(%rsp),%r12
  6b62b5:	movq   $0x0,(%rsp)
  6b62bd:	mov    %rbp,0x88(%rsp)
  6b62c5:	jmp    6b62f7 <text_column_public_control::observe::<text_column_public_control::Model>+0x217>
  6b62c7:	nopw   0x0(%rax,%rax,1)
  6b62d0:	mov    %rbx,%r14
  6b62d3:	incq   (%rsp)
  6b62d7:	mov    0x88(%rsp),%rbp
  6b62df:	mov    0x50(%rsp),%rdx
  6b62e4:	inc    %rdx
  6b62e7:	cmp    0x8(%rsp),%rdx
  6b62ec:	lea    0x10(%rsp),%rdi
  6b62f1:	je     6b66be <text_column_public_control::observe::<text_column_public_control::Model>+0x5de>
  6b62f7:	mov    %rdx,%r15
  6b62fa:	shl    $0x6,%r15
  6b62fe:	movzbl 0x3d(%rbp,%r15,1),%eax
  6b6304:	sub    $0x2,%al
  6b6306:	movzbl %al,%eax
  6b6309:	mov    $0x8,%ecx
  6b630e:	cmovb  %ecx,%eax
  6b6311:	movzbl %al,%eax
  6b6314:	xor    %r14,%rax
  6b6317:	imul   %r13,%rax
  6b631b:	mov    0x10(%rbp,%r15,1),%ecx
  6b6320:	xor    %rax,%rcx
  6b6323:	mov    0x14(%rbp,%r15,1),%eax
  6b6328:	mov    0x18(%rbp,%r15,1),%r8d
  6b632d:	mov    0x1c(%rbp,%r15,1),%esi
  6b6332:	imul   %r13,%rcx
  6b6336:	xor    %rax,%rcx
  6b6339:	imul   %r13,%rcx
  6b633d:	xor    %r8,%rcx
  6b6340:	imul   %r13,%rcx
  6b6344:	xor    %rsi,%rcx
  6b6347:	movabs $0x8a97b0004e7feab,%rax
  6b6351:	imul   %rax,%rcx
  6b6355:	mov    0x8(%rbp,%r15,1),%ebx
  6b635a:	mov    0xc(%rbp,%r15,1),%eax
  6b635f:	xor    %rcx,%rbx
  6b6362:	imul   %r13,%rbx
  6b6366:	xor    %rax,%rbx
  6b6369:	imul   %r13,%rbx
  6b636d:	lea    0x90(%rsp),%rsi
  6b6375:	mov    %rdx,0x50(%rsp)
  6b637a:	call   *0x38c468(%rip)        # a427e8 <_DYNAMIC+0x250>
  6b6380:	cmpl   $0x1,0x10(%rsp)
  6b6385:	jne    6b63ce <text_column_public_control::observe::<text_column_public_control::Model>+0x2ee>
  6b6387:	mov    0x14(%rsp),%eax
  6b638b:	mov    0x18(%rsp),%ecx
  6b638f:	mov    0x1c(%rsp),%edx
  6b6393:	mov    0x20(%rsp),%esi
  6b6397:	mov    0x24(%rsp),%edi
  6b639b:	mov    0x28(%rsp),%r8d
  6b63a0:	xor    $0x1,%rbx
  6b63a4:	imul   %r13,%rbx
  6b63a8:	xor    %rax,%rbx
  6b63ab:	imul   %r13,%rbx
  6b63af:	xor    %rcx,%rbx
  6b63b2:	imul   %r13,%rbx
  6b63b6:	xor    %rdx,%rbx
  6b63b9:	imul   %r13,%rbx
  6b63bd:	xor    %rsi,%rbx
  6b63c0:	imul   %r13,%rbx
  6b63c4:	xor    %rdi,%rbx
  6b63c7:	imul   %r13,%rbx
  6b63cb:	xor    %r8,%rbx
  6b63ce:	add    %rbp,%r15
  6b63d1:	mov    0x28(%r15),%rcx
  6b63d5:	test   %rcx,%rcx
  6b63d8:	je     6b6510 <text_column_public_control::observe::<text_column_public_control::Model>+0x430>
  6b63de:	imul   %r13,%rbx
  6b63e2:	mov    (%rcx),%rdx
  6b63e5:	mov    %rdx,%rdi
  6b63e8:	shr    $1,%rdi
  6b63eb:	movzbl 0x3d(%r15),%r8d
  6b63f0:	xor    $0x1,%rbx
  6b63f4:	imul   %r13,%rbx
  6b63f8:	test   %rdi,%rdi
  6b63fb:	je     6b6520 <text_column_public_control::observe::<text_column_public_control::Model>+0x440>
  6b6401:	lea    0x10(%rcx),%rax
  6b6405:	mov    %rdi,%rsi
  6b6408:	and    $0x7,%rsi
  6b640c:	lea    0x138(%rsp),%r15
  6b6414:	je     6b6619 <text_column_public_control::observe::<text_column_public_control::Model>+0x539>
  6b641a:	mov    %rsi,%r10
  6b641d:	mov    %rax,%r9
  6b6420:	movzbl (%r9),%r14d
  6b6424:	inc    %r9
  6b6427:	xor    %rbx,%r14
  6b642a:	imul   %r13,%r14
  6b642e:	mov    %r14,%rbx
  6b6431:	dec    %r10
  6b6434:	jne    6b6420 <text_column_public_control::observe::<text_column_public_control::Model>+0x340>
  6b6436:	add    %rdi,%rcx
  6b6439:	add    $0x10,%rcx
  6b643d:	cmp    $0x10,%rdx
  6b6441:	jb     6b64b8 <text_column_public_control::observe::<text_column_public_control::Model>+0x3d8>
  6b6443:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6b6450:	movzbl (%r9),%r10d
  6b6454:	xor    %r14,%r10
  6b6457:	imul   %r13,%r10
  6b645b:	movzbl 0x1(%r9),%r11d
  6b6460:	xor    %r10,%r11
  6b6463:	imul   %r13,%r11
  6b6467:	movzbl 0x2(%r9),%r10d
  6b646c:	xor    %r11,%r10
  6b646f:	imul   %r13,%r10
  6b6473:	movzbl 0x3(%r9),%r11d
  6b6478:	xor    %r10,%r11
  6b647b:	imul   %r13,%r11
  6b647f:	movzbl 0x4(%r9),%r10d
  6b6484:	xor    %r11,%r10
  6b6487:	imul   %r13,%r10
  6b648b:	movzbl 0x5(%r9),%r11d
  6b6490:	xor    %r10,%r11
  6b6493:	imul   %r13,%r11
  6b6497:	movzbl 0x6(%r9),%r10d
  6b649c:	xor    %r11,%r10
  6b649f:	imul   %r13,%r10
  6b64a3:	movzbl 0x7(%r9),%r14d
  6b64a8:	add    $0x8,%r9
  6b64ac:	xor    %r10,%r14
  6b64af:	imul   %r13,%r14
  6b64b3:	cmp    %rcx,%r9
  6b64b6:	jne    6b6450 <text_column_public_control::observe::<text_column_public_control::Model>+0x370>
  6b64b8:	cmp    $0x4,%r8b
  6b64bc:	jne    6b6537 <text_column_public_control::observe::<text_column_public_control::Model>+0x457>
  6b64be:	xor    $0x1,%r14
  6b64c2:	mov    %r14,%r8
  6b64c5:	imul   %r13,%r8
  6b64c9:	test   $0x7,%dil
  6b64cd:	je     6b6635 <text_column_public_control::observe::<text_column_public_control::Model>+0x555>
  6b64d3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6b64e0:	movzbl (%rax),%r14d
  6b64e4:	inc    %rax
  6b64e7:	xor    %r8,%r14
  6b64ea:	imul   %r13,%r14
  6b64ee:	mov    %r14,%r8
  6b64f1:	dec    %rsi
  6b64f4:	jne    6b64e0 <text_column_public_control::observe::<text_column_public_control::Model>+0x400>
  6b64f6:	cmp    $0x10,%rdx
  6b64fa:	mov    0x50(%rsp),%rdx
  6b64ff:	jae    6b6650 <text_column_public_control::observe::<text_column_public_control::Model>+0x570>
  6b6505:	jmp    6b6540 <text_column_public_control::observe::<text_column_public_control::Model>+0x460>
  6b6507:	nopw   0x0(%rax,%rax,1)
  6b6510:	movabs $0x366000002e329,%rax
  6b651a:	imul   %rax,%rbx
  6b651e:	jmp    6b652c <text_column_public_control::observe::<text_column_public_control::Model>+0x44c>
  6b6520:	xor    %eax,%eax
  6b6522:	cmp    $0x4,%r8b
  6b6526:	sete   %al
  6b6529:	xor    %rax,%rbx
  6b652c:	mov    %rbx,%r14
  6b652f:	lea    0x138(%rsp),%r15
  6b6537:	imul   %r13,%r14
  6b653b:	mov    0x50(%rsp),%rdx
  6b6540:	lea    0x60(%rsp),%rdi
  6b6545:	lea    0x90(%rsp),%rsi
  6b654d:	call   *0x38c29d(%rip)        # a427f0 <_DYNAMIC+0x258>
  6b6553:	cmpq   $0x0,0x60(%rsp)
  6b6559:	je     6b62df <text_column_public_control::observe::<text_column_public_control::Model>+0x1ff>
  6b655f:	mov    0x70(%rsp),%rsi
  6b6564:	mov    0x78(%rsp),%eax
  6b6568:	mov    0x7c(%rsp),%ecx
  6b656c:	xor    %rax,%r14
  6b656f:	imul   %r13,%r14
  6b6573:	xor    %rcx,%r14
  6b6576:	imul   %r13,%r14
  6b657a:	mov    0x48(%rsi),%ebx
  6b657d:	xor    %r14,%rbx
  6b6580:	imul   %r13,%rbx
  6b6584:	mov    %r12,%rdi
  6b6587:	call   *0x38c26b(%rip)        # a427f8 <_DYNAMIC+0x260>
  6b658d:	lea    0x10(%rsp),%rdi
  6b6592:	mov    %r12,%rsi
  6b6595:	mov    %r15,%rdx
  6b6598:	call   6da0a0 <<core::iter::adapters::zip::Zip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>, core::iter::adapters::skip::Skip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>>> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::find_map::check<(&[gpui_canvas::text::layout::Stop], &[gpui_canvas::text::layout::Stop]), gpui_canvas::text::layout::interaction::TextGrapheme, &mut <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#1}>::{closure#0}, core::ops::control_flow::ControlFlow<gpui_canvas::text::layout::interaction::TextGrapheme>>>
  6b659d:	cmpb   $0x2,0x14(%rsp)
  6b65a2:	je     6b62d0 <text_column_public_control::observe::<text_column_public_control::Model>+0x1f0>
  6b65a8:	lea    0x10(%rsp),%rbp
  6b65ad:	nopl   (%rax)
  6b65b0:	mov    0x10(%rsp),%r14d
  6b65b5:	mov    0x18(%rsp),%eax
  6b65b9:	xor    %rbx,%r14
  6b65bc:	mov    0x20(%rsp),%ecx
  6b65c0:	mov    0x24(%rsp),%edx
  6b65c4:	mov    0x28(%rsp),%esi
  6b65c8:	mov    0x2c(%rsp),%edi
  6b65cc:	imul   %r13,%r14
  6b65d0:	xor    %rax,%r14
  6b65d3:	imul   %r13,%r14
  6b65d7:	xor    %rcx,%r14
  6b65da:	imul   %r13,%r14
  6b65de:	xor    %rdx,%r14
  6b65e1:	imul   %r13,%r14
  6b65e5:	xor    %rsi,%r14
  6b65e8:	imul   %r13,%r14
  6b65ec:	xor    %rdi,%r14
  6b65ef:	imul   %r13,%r14
  6b65f3:	xor    0x30(%rsp),%r14
  6b65f8:	imul   %r13,%r14
  6b65fc:	mov    %rbp,%rdi
  6b65ff:	mov    %r12,%rsi
  6b6602:	mov    %r15,%rdx
  6b6605:	call   6da0a0 <<core::iter::adapters::zip::Zip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>, core::iter::adapters::skip::Skip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>>> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::find_map::check<(&[gpui_canvas::text::layout::Stop], &[gpui_canvas::text::layout::Stop]), gpui_canvas::text::layout::interaction::TextGrapheme, &mut <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#1}>::{closure#0}, core::ops::control_flow::ControlFlow<gpui_canvas::text::layout::interaction::TextGrapheme>>>
  6b660a:	cmpb   $0x2,0x14(%rsp)
  6b660f:	mov    %r14,%rbx
  6b6612:	jne    6b65b0 <text_column_public_control::observe::<text_column_public_control::Model>+0x4d0>
  6b6614:	jmp    6b62d3 <text_column_public_control::observe::<text_column_public_control::Model>+0x1f3>
  6b6619:	mov    %rbx,%r14
  6b661c:	mov    %rax,%r9
  6b661f:	add    %rdi,%rcx
  6b6622:	add    $0x10,%rcx
  6b6626:	cmp    $0x10,%rdx
  6b662a:	jae    6b6450 <text_column_public_control::observe::<text_column_public_control::Model>+0x370>
  6b6630:	jmp    6b64b8 <text_column_public_control::observe::<text_column_public_control::Model>+0x3d8>
  6b6635:	mov    %r8,%r14
  6b6638:	cmp    $0x10,%rdx
  6b663c:	mov    0x50(%rsp),%rdx
  6b6641:	jb     6b6540 <text_column_public_control::observe::<text_column_public_control::Model>+0x460>
  6b6647:	nopw   0x0(%rax,%rax,1)
  6b6650:	movzbl (%rax),%edi
  6b6653:	xor    %r14,%rdi
  6b6656:	imul   %r13,%rdi
  6b665a:	movzbl 0x1(%rax),%esi
  6b665e:	xor    %rdi,%rsi
  6b6661:	imul   %r13,%rsi
  6b6665:	movzbl 0x2(%rax),%edi
  6b6669:	xor    %rsi,%rdi
  6b666c:	imul   %r13,%rdi
  6b6670:	movzbl 0x3(%rax),%esi
  6b6674:	xor    %rdi,%rsi
  6b6677:	imul   %r13,%rsi
  6b667b:	movzbl 0x4(%rax),%edi
  6b667f:	xor    %rsi,%rdi
  6b6682:	imul   %r13,%rdi
  6b6686:	movzbl 0x5(%rax),%esi
  6b668a:	xor    %rdi,%rsi
  6b668d:	imul   %r13,%rsi
  6b6691:	movzbl 0x6(%rax),%edi
  6b6695:	xor    %rsi,%rdi
  6b6698:	imul   %r13,%rdi
  6b669c:	movzbl 0x7(%rax),%r14d
  6b66a1:	add    $0x8,%rax
  6b66a5:	xor    %rdi,%r14
  6b66a8:	imul   %r13,%r14
  6b66ac:	cmp    %rcx,%rax
  6b66af:	jne    6b6650 <text_column_public_control::observe::<text_column_public_control::Model>+0x570>
  6b66b1:	jmp    6b6540 <text_column_public_control::observe::<text_column_public_control::Model>+0x460>
  6b66b6:	movq   $0x0,(%rsp)
  6b66be:	mov    0x80(%rsp),%rax
  6b66c6:	mov    0x8(%rsp),%rcx
  6b66cb:	mov    %rcx,(%rax)
  6b66ce:	mov    (%rsp),%rcx
  6b66d2:	mov    %rcx,0x8(%rax)
  6b66d6:	mov    %r14,0x10(%rax)
  6b66da:	add    $0x148,%rsp
  6b66e1:	pop    %rbx
  6b66e2:	pop    %r12
  6b66e4:	pop    %r13
  6b66e6:	pop    %r14
  6b66e8:	pop    %r15
  6b66ea:	pop    %rbp
  6b66eb:	ret
  6b66ec:	mov    $0xd,%eax
  6b66f1:	jmp    6b66ff <text_column_public_control::observe::<text_column_public_control::Model>+0x61f>
  6b66f3:	mov    $0xe,%eax
  6b66f8:	jmp    6b66ff <text_column_public_control::observe::<text_column_public_control::Model>+0x61f>
  6b66fa:	mov    $0x12,%eax
  6b66ff:	mov    %rax,0x90(%rsp)
  6b6707:	movq   $0x0,0x98(%rsp)
  6b6713:	lea    -0x668f43(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6b671a:	lea    0x36cb07(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6b6721:	lea    0x36b900(%rip),%r8        # a22028 <__frame_dummy_init_array_entry+0x38>
  6b6728:	lea    0x90(%rsp),%rdx
  6b6730:	mov    $0x2b,%esi
  6b6735:	call   *0x38c09d(%rip)        # a427d8 <_DYNAMIC+0x240>
  6b673b:	ud2
  6b673d:	mov    %rax,%rbx
  6b6740:	lea    0x90(%rsp),%rdi
  6b6748:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6b674d:	mov    %rbx,%rdi
  6b6750:	call   a20c40 <_Unwind_Resume@plt>

<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#37}> code=105 fixed_stack=0

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006b6810 <<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#37}>>:
  6b6810:	cmpq   $0xffffffffffffffff,(%rsi)
  6b6814:	je     6b683f <<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#37}>+0x2f>
  6b6816:	mov    0x10(%rsi),%rax
  6b681a:	mov    %rax,0x10(%rdi)
  6b681e:	movups (%rsi),%xmm0
  6b6821:	movups %xmm0,(%rdi)
  6b6824:	mov    (%rdx),%rsi
  6b6827:	test   %rsi,%rsi
  6b682a:	je     6b685a <<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#37}>+0x4a>
  6b682c:	mov    0x8(%rdx),%rdi
  6b6830:	shl    $0x4,%rsi
  6b6834:	mov    $0x4,%edx
  6b6839:	jmp    *0x38bfc1(%rip)        # a42800 <_DYNAMIC+0x268>
  6b683f:	mov    (%rdx),%rsi
  6b6842:	mov    0x8(%rdx),%rax
  6b6846:	mov    0x10(%rdx),%rcx
  6b684a:	test   %rcx,%rcx
  6b684d:	je     6b685b <<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#37}>+0x4b>
  6b684f:	mov    %rsi,(%rdi)
  6b6852:	mov    %rax,0x8(%rdi)
  6b6856:	mov    %rcx,0x10(%rdi)
  6b685a:	ret
  6b685b:	movq   $0xffffffffffffffff,(%rdi)
  6b6862:	test   %rsi,%rsi
  6b6865:	je     6b685a <<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#37}>+0x4a>
  6b6867:	shl    $0x4,%rsi
  6b686b:	mov    $0x4,%edx
  6b6870:	mov    %rax,%rdi
  6b6873:	jmp    *0x38bf87(%rip)        # a42800 <_DYNAMIC+0x268>

<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}> code=1105 fixed_stack=344

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006b8220 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>>:
  6b8220:	test   %rdi,%rdi
  6b8223:	je     6b8592 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x372>
  6b8229:	push   %rbp
  6b822a:	push   %r15
  6b822c:	push   %r14
  6b822e:	push   %r13
  6b8230:	push   %r12
  6b8232:	push   %rbx
  6b8233:	sub    $0x128,%rsp
  6b823a:	mov    %rsi,%r12
  6b823d:	mov    %rdi,%r15
  6b8240:	lea    0x10(%rdi),%r14
  6b8244:	mov    (%rdx),%rbp
  6b8247:	mov    0x8(%rdx),%rbx
  6b824b:	mov    0x10(%rdx),%rax
  6b824f:	mov    %rax,0x48(%rsp)
  6b8254:	mov    0x18(%rdx),%rax
  6b8258:	mov    %rax,0x40(%rsp)
  6b825d:	mov    0x20(%rdx),%rax
  6b8261:	mov    %rax,0x50(%rsp)
  6b8266:	mov    0x28(%rdx),%rax
  6b826a:	mov    %rax,0x58(%rsp)
  6b826f:	mov    %r14,%rdi
  6b8272:	call   *0x38a5e8(%rip)        # a42860 <_DYNAMIC+0x2c8>
  6b8278:	test   %al,%al
  6b827a:	je     6b8595 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x375>
  6b8280:	mov    (%r12),%esi
  6b8284:	mov    0x8(%r12),%ecx
  6b8289:	mov    $0x1,%al
  6b828b:	cmp    %esi,%ecx
  6b828d:	je     6b865f <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x43f>
  6b8293:	mov    %rbx,0x38(%rsp)
  6b8298:	mov    %esi,%edx
  6b829a:	cmova  %ecx,%edx
  6b829d:	cmovb  %ecx,%esi
  6b82a0:	mov    %r14,%rdi
  6b82a3:	call   *0x38a5bf(%rip)        # a42868 <_DYNAMIC+0x2d0>
  6b82a9:	mov    %rdx,%rcx
  6b82ac:	movss  0x5c(%r15),%xmm0
  6b82b2:	mulss  -0x67838a(%rip),%xmm0        # 3ff30 <GCC_except_table0+0xe8>
  6b82ba:	lea    0xe0(%rsp),%r15
  6b82c2:	mov    %r15,%rdi
  6b82c5:	mov    %r14,%rsi
  6b82c8:	mov    %rax,%rdx
  6b82cb:	call   *0x38a59f(%rip)        # a42870 <_DYNAMIC+0x2d8>
  6b82d1:	lea    0x118(%rsp),%r14
  6b82d9:	lea    0x70(%rsp),%rdi
  6b82de:	mov    %r15,%rsi
  6b82e1:	mov    %r14,%rdx
  6b82e4:	call   6da0a0 <<core::iter::adapters::zip::Zip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>, core::iter::adapters::skip::Skip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>>> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::find_map::check<(&[gpui_canvas::text::layout::Stop], &[gpui_canvas::text::layout::Stop]), gpui_canvas::text::layout::interaction::TextGrapheme, &mut <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#1}>::{closure#0}, core::ops::control_flow::ControlFlow<gpui_canvas::text::layout::interaction::TextGrapheme>>>
  6b82e9:	cmpb   $0x2,0x74(%rsp)
  6b82ee:	je     6b865d <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x43d>
  6b82f4:	xor    %eax,%eax
  6b82f6:	lea    0x70(%rsp),%r15
  6b82fb:	lea    0xe0(%rsp),%r12
  6b8303:	test   $0x1,%al
  6b8305:	je     6b8310 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0xf0>
  6b8307:	movaps %xmm0,0x60(%rsp)
  6b830c:	jmp    6b8373 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x153>
  6b830e:	xchg   %ax,%ax
  6b8310:	movss  0x88(%rsp),%xmm1
  6b8319:	xorps  %xmm0,%xmm0
  6b831c:	ucomiss %xmm0,%xmm1
  6b831f:	jne    6b8443 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x223>
  6b8325:	jp     6b8443 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x223>
  6b832b:	mov    %r15,%rdi
  6b832e:	mov    %r12,%rsi
  6b8331:	mov    %r14,%rdx
  6b8334:	call   6da0a0 <<core::iter::adapters::zip::Zip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>, core::iter::adapters::skip::Skip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>>> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::find_map::check<(&[gpui_canvas::text::layout::Stop], &[gpui_canvas::text::layout::Stop]), gpui_canvas::text::layout::interaction::TextGrapheme, &mut <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#1}>::{closure#0}, core::ops::control_flow::ControlFlow<gpui_canvas::text::layout::interaction::TextGrapheme>>>
  6b8339:	cmpb   $0x2,0x74(%rsp)
  6b833e:	jne    6b8310 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0xf0>
  6b8340:	jmp    6b865d <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x43d>
  6b8345:	data16 cs nopw 0x0(%rax,%rax,1)
  6b8350:	movaps %xmm5,0x10(%rsp)
  6b8355:	mov    %r15,%rdi
  6b8358:	mov    %r12,%rsi
  6b835b:	mov    %r14,%rdx
  6b835e:	call   6da0a0 <<core::iter::adapters::zip::Zip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>, core::iter::adapters::skip::Skip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>>> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::find_map::check<(&[gpui_canvas::text::layout::Stop], &[gpui_canvas::text::layout::Stop]), gpui_canvas::text::layout::interaction::TextGrapheme, &mut <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#1}>::{closure#0}, core::ops::control_flow::ControlFlow<gpui_canvas::text::layout::interaction::TextGrapheme>>>
  6b8363:	cmpb   $0x2,0x74(%rsp)
  6b8368:	movaps 0x10(%rsp),%xmm5
  6b836d:	je     6b859c <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x37c>
  6b8373:	movss  0x88(%rsp),%xmm2
  6b837c:	xorps  %xmm0,%xmm0
  6b837f:	ucomiss %xmm0,%xmm2
  6b8382:	jne    6b8386 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x166>
  6b8384:	jnp    6b8350 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x130>
  6b8386:	movsd  0x80(%rsp),%xmm3
  6b838f:	movss  0x8c(%rsp),%xmm4
  6b8398:	mov    0x90(%rsp),%r13
  6b83a0:	cmp    %r13,%rbx
  6b83a3:	jne    6b8476 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x256>
  6b83a9:	movaps %xmm3,%xmm0
  6b83ac:	shufps $0x55,%xmm3,%xmm0
  6b83b0:	movaps 0xb0(%rsp),%xmm1
  6b83b8:	ucomiss %xmm0,%xmm1
  6b83bb:	jne    6b8476 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x256>
  6b83c1:	jp     6b8476 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x256>
  6b83c7:	movss  0x4(%rsp),%xmm0
  6b83cd:	ucomiss %xmm4,%xmm0
  6b83d0:	jne    6b8476 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x256>
  6b83d6:	jp     6b8476 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x256>
  6b83dc:	movaps %xmm3,%xmm0
  6b83df:	addss  %xmm2,%xmm0
  6b83e3:	ucomiss %xmm5,%xmm0
  6b83e6:	jb     6b8473 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x253>
  6b83ec:	movaps 0x60(%rsp),%xmm1
  6b83f1:	addss  %xmm5,%xmm1
  6b83f5:	ucomiss %xmm3,%xmm1
  6b83f8:	jb     6b8473 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x253>
  6b83fa:	movaps %xmm1,%xmm2
  6b83fd:	maxss  %xmm0,%xmm2
  6b8401:	movaps %xmm2,%xmm4
  6b8404:	cmpunordss %xmm2,%xmm4
  6b8409:	movaps %xmm4,%xmm0
  6b840c:	andnps %xmm2,%xmm0
  6b840f:	andps  %xmm1,%xmm4
  6b8412:	orps   %xmm0,%xmm4
  6b8415:	movaps %xmm5,%xmm0
  6b8418:	minss  %xmm3,%xmm0
  6b841c:	movaps %xmm0,%xmm1
  6b841f:	cmpunordss %xmm0,%xmm1
  6b8424:	movaps %xmm1,%xmm2
  6b8427:	andnps %xmm0,%xmm2
  6b842a:	andps  %xmm5,%xmm1
  6b842d:	orps   %xmm2,%xmm1
  6b8430:	subss  %xmm1,%xmm4
  6b8434:	movaps %xmm4,0x60(%rsp)
  6b8439:	movaps %xmm1,0x10(%rsp)
  6b843e:	jmp    6b8355 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x135>
  6b8443:	movss  %xmm1,0xc(%rsp)
  6b8449:	movsd  0x80(%rsp),%xmm0
  6b8452:	movaps %xmm0,0x10(%rsp)
  6b8457:	movss  0x8c(%rsp),%xmm0
  6b8460:	movss  %xmm0,0x8(%rsp)
  6b8466:	mov    0x90(%rsp),%r13
  6b846e:	jmp    6b8546 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x326>
  6b8473:	mov    %rbx,%r13
  6b8476:	movss  %xmm4,0x8(%rsp)
  6b847c:	movss  %xmm2,0xc(%rsp)
  6b8482:	movaps %xmm3,0x10(%rsp)
  6b8487:	cmpl   $0xffffffff,0x0(%rbp)
  6b848b:	jne    6b8546 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x326>
  6b8491:	unpcklps 0xb0(%rsp),%xmm5
  6b8499:	mov    0x40(%rsp),%rax
  6b849e:	movss  (%rax),%xmm0
  6b84a2:	mov    0x48(%rsp),%rax
  6b84a7:	movss  (%rax),%xmm1
  6b84ab:	unpcklps %xmm0,%xmm1
  6b84ae:	addps  %xmm5,%xmm1
  6b84b1:	movlps %xmm1,0xc0(%rsp)
  6b84b9:	movaps 0x60(%rsp),%xmm0
  6b84be:	movss  %xmm0,0xc8(%rsp)
  6b84c7:	movss  0x4(%rsp),%xmm0
  6b84cd:	movss  %xmm0,0xcc(%rsp)
  6b84d6:	mov    0x50(%rsp),%rcx
  6b84db:	mov    0x10(%rcx),%rax
  6b84df:	mov    %rax,0x80(%rsp)
  6b84e7:	movups (%rcx),%xmm0
  6b84ea:	movaps %xmm0,0x70(%rsp)
  6b84ef:	mov    0x58(%rsp),%rax
  6b84f4:	movups (%rax),%xmm0
  6b84f7:	movaps %xmm0,0x20(%rsp)
  6b84fc:	lea    0xd0(%rsp),%rbx
  6b8504:	mov    %rbx,%rdi
  6b8507:	mov    $0x46,%esi
  6b850c:	mov    $0x82,%edx
  6b8511:	mov    $0xf0,%ecx
  6b8516:	mov    $0x60,%r8d
  6b851c:	call   *0x38a356(%rip)        # a42878 <_DYNAMIC+0x2e0>
  6b8522:	mov    0x38(%rsp),%rdi
  6b8527:	lea    0xc0(%rsp),%rsi
  6b852f:	mov    %r15,%rdx
  6b8532:	lea    0x20(%rsp),%rcx
  6b8537:	mov    %rbx,%r8
  6b853a:	call   *0x38a340(%rip)        # a42880 <_DYNAMIC+0x2e8>
  6b8540:	mov    %eax,0x0(%rbp)
  6b8543:	mov    %edx,0x4(%rbp)
  6b8546:	mov    %r15,%rdi
  6b8549:	mov    %r12,%rsi
  6b854c:	mov    %r14,%rdx
  6b854f:	call   6da0a0 <<core::iter::adapters::zip::Zip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>, core::iter::adapters::skip::Skip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>>> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::find_map::check<(&[gpui_canvas::text::layout::Stop], &[gpui_canvas::text::layout::Stop]), gpui_canvas::text::layout::interaction::TextGrapheme, &mut <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#1}>::{closure#0}, core::ops::control_flow::ControlFlow<gpui_canvas::text::layout::interaction::TextGrapheme>>>
  6b8554:	cmpb   $0x2,0x74(%rsp)
  6b8559:	movaps 0x10(%rsp),%xmm2
  6b855e:	movaps %xmm2,%xmm0
  6b8561:	shufps $0x55,%xmm2,%xmm0
  6b8565:	movaps %xmm0,0xb0(%rsp)
  6b856d:	mov    $0x1,%al
  6b856f:	mov    %r13,%rbx
  6b8572:	movss  0x8(%rsp),%xmm4
  6b8578:	movss  %xmm4,0x4(%rsp)
  6b857e:	movss  0xc(%rsp),%xmm3
  6b8584:	movaps %xmm3,%xmm0
  6b8587:	movaps %xmm2,%xmm5
  6b858a:	jne    6b8303 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0xe3>
  6b8590:	jmp    6b85b2 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x392>
  6b8592:	xor    %eax,%eax
  6b8594:	ret
  6b8595:	xor    %eax,%eax
  6b8597:	jmp    6b865f <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x43f>
  6b859c:	unpcklps 0xb0(%rsp),%xmm5
  6b85a4:	movss  0x4(%rsp),%xmm4
  6b85aa:	movaps 0x60(%rsp),%xmm3
  6b85af:	movaps %xmm5,%xmm2
  6b85b2:	cmpl   $0xffffffff,0x0(%rbp)
  6b85b6:	jne    6b865d <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>+0x43d>
  6b85bc:	mov    0x40(%rsp),%rax
  6b85c1:	movss  (%rax),%xmm0
  6b85c5:	mov    0x48(%rsp),%rax
  6b85ca:	movss  (%rax),%xmm1
  6b85ce:	unpcklps %xmm0,%xmm1
  6b85d1:	addps  %xmm1,%xmm2
  6b85d4:	movlps %xmm2,0x20(%rsp)
  6b85d9:	movss  %xmm3,0x28(%rsp)
  6b85df:	movss  %xmm4,0x2c(%rsp)
  6b85e5:	mov    0x50(%rsp),%rcx
  6b85ea:	mov    0x10(%rcx),%rax
  6b85ee:	mov    %rax,0xf0(%rsp)
  6b85f6:	movups (%rcx),%xmm0
  6b85f9:	movaps %xmm0,0xe0(%rsp)
  6b8601:	mov    0x58(%rsp),%rax
  6b8606:	movups (%rax),%xmm0
  6b8609:	movaps %xmm0,0xd0(%rsp)
  6b8611:	lea    0x70(%rsp),%r14
  6b8616:	mov    %r14,%rdi
  6b8619:	mov    $0x46,%esi
  6b861e:	mov    $0x82,%edx
  6b8623:	mov    $0xf0,%ecx
  6b8628:	mov    $0x60,%r8d
  6b862e:	call   *0x38a244(%rip)        # a42878 <_DYNAMIC+0x2e0>
  6b8634:	lea    0x20(%rsp),%rsi
  6b8639:	lea    0xe0(%rsp),%rdx
  6b8641:	lea    0xd0(%rsp),%rcx
  6b8649:	mov    0x38(%rsp),%rdi
  6b864e:	mov    %r14,%r8
  6b8651:	call   *0x38a229(%rip)        # a42880 <_DYNAMIC+0x2e8>
  6b8657:	mov    %eax,0x0(%rbp)
  6b865a:	mov    %edx,0x4(%rbp)
  6b865d:	mov    $0x1,%al
  6b865f:	add    $0x128,%rsp
  6b8666:	pop    %rbx
  6b8667:	pop    %r12
  6b8669:	pop    %r13
  6b866b:	pop    %r14
  6b866d:	pop    %r15
  6b866f:	pop    %rbp
  6b8670:	ret

<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}> code=1391 fixed_stack=120

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006b86e0 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>>:
  6b86e0:	push   %rbp
  6b86e1:	push   %r15
  6b86e3:	push   %r14
  6b86e5:	push   %r13
  6b86e7:	push   %r12
  6b86e9:	push   %rbx
  6b86ea:	sub    $0x48,%rsp
  6b86ee:	mov    %rdx,0x10(%rsp)
  6b86f3:	mov    %rdi,0x18(%rsp)
  6b86f8:	mov    0x10(%rsi),%rbx
  6b86fc:	test   %rbx,%rbx
  6b86ff:	mov    %rsi,0x8(%rsp)
  6b8704:	je     6b8749 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x69>
  6b8706:	mov    0x8(%rsi),%rbp
  6b870a:	lea    -0x1(%rbx),%r15
  6b870e:	mov    $0x28,%r13d
  6b8714:	xor    %r14d,%r14d
  6b8717:	nopw   0x0(%rax,%rax,1)
  6b8720:	mov    -0x28(%rbp,%r13,1),%rsi
  6b8725:	mov    0x10(%rsp),%rdi
  6b872a:	call   6db1c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>
  6b872f:	test   $0x1,%al
  6b8731:	je     6b874e <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x6e>
  6b8733:	mov    %edx,-0x4(%rbp,%r13,1)
  6b8738:	inc    %r14
  6b873b:	add    $0x28,%r13
  6b873f:	cmp    %r14,%rbx
  6b8742:	jne    6b8720 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x40>
  6b8744:	mov    %rbx,%r14
  6b8747:	jmp    6b87b1 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0xd1>
  6b8749:	xor    %r14d,%r14d
  6b874c:	jmp    6b87b1 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0xd1>
  6b874e:	lea    0x1(%r14),%rax
  6b8752:	cmp    %rbx,%rax
  6b8755:	jae    6b87b1 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0xd1>
  6b8757:	sub    %r14,%r15
  6b875a:	jmp    6b8769 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x89>
  6b875c:	nopl   0x0(%rax)
  6b8760:	add    $0x28,%r13
  6b8764:	dec    %r15
  6b8767:	je     6b87b1 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0xd1>
  6b8769:	mov    %rbp,%r12
  6b876c:	add    %r13,%r12
  6b876f:	mov    0x0(%rbp,%r13,1),%rsi
  6b8774:	mov    0x10(%rsp),%rdi
  6b8779:	call   6db1c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>
  6b877e:	cmp    $0x1,%rax
  6b8782:	jne    6b8760 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x80>
  6b8784:	mov    %edx,0x24(%rbp,%r13,1)
  6b8789:	lea    (%r14,%r14,4),%rax
  6b878d:	mov    0x20(%r12),%rcx
  6b8792:	mov    %rcx,0x20(%rbp,%rax,8)
  6b8797:	movups (%r12),%xmm0
  6b879c:	movups 0x10(%r12),%xmm1
  6b87a2:	movups %xmm1,0x10(%rbp,%rax,8)
  6b87a7:	movups %xmm0,0x0(%rbp,%rax,8)
  6b87ac:	inc    %r14
  6b87af:	jmp    6b8760 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x80>
  6b87b1:	mov    0x8(%rsp),%rax
  6b87b6:	mov    0x28(%rax),%rbp
  6b87ba:	test   %rbp,%rbp
  6b87bd:	mov    %r14,0x20(%rsp)
  6b87c2:	je     6b8809 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x129>
  6b87c4:	mov    0x20(%rax),%r13
  6b87c8:	lea    -0x1(%rbp),%r15
  6b87cc:	mov    $0x40,%ebx
  6b87d1:	xor    %r12d,%r12d
  6b87d4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6b87e0:	mov    -0x10(%r13,%rbx,1),%rsi
  6b87e5:	mov    0x10(%rsp),%rdi
  6b87ea:	call   6db1c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>
  6b87ef:	test   $0x1,%al
  6b87f1:	je     6b880e <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x12e>
  6b87f3:	mov    %edx,-0x8(%r13,%rbx,1)
  6b87f8:	inc    %r12
  6b87fb:	add    $0x40,%rbx
  6b87ff:	cmp    %r12,%rbp
  6b8802:	jne    6b87e0 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x100>
  6b8804:	mov    %rbp,%r12
  6b8807:	jmp    6b8881 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x1a1>
  6b8809:	xor    %r12d,%r12d
  6b880c:	jmp    6b8881 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x1a1>
  6b880e:	lea    0x1(%r12),%rax
  6b8813:	cmp    %rbp,%rax
  6b8816:	jae    6b8881 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x1a1>
  6b8818:	sub    %r12,%r15
  6b881b:	jmp    6b882c <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x14c>
  6b881d:	nopl   (%rax)
  6b8820:	mov    %r14,%rbp
  6b8823:	add    $0x40,%rbx
  6b8827:	dec    %r15
  6b882a:	je     6b8881 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x1a1>
  6b882c:	mov    %rbp,%r14
  6b882f:	lea    (%rbx,%r13,1),%rbp
  6b8833:	mov    0x30(%r13,%rbx,1),%rsi
  6b8838:	mov    0x10(%rsp),%rdi
  6b883d:	call   6db1c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>
  6b8842:	cmp    $0x1,%rax
  6b8846:	jne    6b8820 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x140>
  6b8848:	mov    %edx,0x38(%r13,%rbx,1)
  6b884d:	mov    %r12,%rax
  6b8850:	shl    $0x6,%rax
  6b8854:	movups 0x0(%rbp),%xmm0
  6b8858:	movups 0x10(%rbp),%xmm1
  6b885c:	movups 0x20(%rbp),%xmm2
  6b8860:	movups 0x30(%rbp),%xmm3
  6b8864:	movups %xmm3,0x30(%r13,%rax,1)
  6b886a:	movups %xmm2,0x20(%r13,%rax,1)
  6b8870:	movups %xmm1,0x10(%r13,%rax,1)
  6b8876:	movups %xmm0,0x0(%r13,%rax,1)
  6b887c:	inc    %r12
  6b887f:	jmp    6b8820 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x140>
  6b8881:	mov    0x20(%rsp),%r14
  6b8886:	test   %r14,%r14
  6b8889:	je     6b88f0 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x210>
  6b888b:	test   %r12,%r12
  6b888e:	je     6b894a <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x26a>
  6b8894:	mov    0x8(%rsp),%rcx
  6b8899:	mov    (%rcx),%rax
  6b889c:	mov    0x8(%rcx),%rbx
  6b88a0:	cmp    %r14,%rax
  6b88a3:	jbe    6b89a3 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x2c3>
  6b88a9:	shl    $0x3,%rax
  6b88ad:	lea    (%rax,%rax,4),%r13
  6b88b1:	lea    0x0(,%r14,8),%rax
  6b88b9:	lea    (%rax,%rax,4),%rbp
  6b88bd:	mov    $0x8,%edx
  6b88c2:	mov    %rbx,%rdi
  6b88c5:	mov    %r13,%rsi
  6b88c8:	mov    %rbp,%rcx
  6b88cb:	call   *0x389fb7(%rip)        # a42888 <_DYNAMIC+0x2f0>
  6b88d1:	mov    %rax,%r15
  6b88d4:	test   %rax,%rax
  6b88d7:	jne    6b89a6 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x2c6>
  6b88dd:	mov    $0x8,%edi
  6b88e2:	mov    %rbp,%rsi
  6b88e5:	call   *0x389fa5(%rip)        # a42890 <_DYNAMIC+0x2f8>
  6b88eb:	jmp    6b8b0e <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x42e>
  6b88f0:	test   %r12,%r12
  6b88f3:	je     6b8a4b <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x36b>
  6b88f9:	mov    0x8(%rsp),%r14
  6b88fe:	mov    0x18(%r14),%r15
  6b8902:	mov    0x20(%r14),%rbx
  6b8906:	cmp    %r12,%r15
  6b8909:	jbe    6b8a64 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x384>
  6b890f:	shl    $0x6,%r15
  6b8913:	mov    %r12,%r13
  6b8916:	shl    $0x6,%r13
  6b891a:	mov    $0x8,%edx
  6b891f:	mov    %rbx,%rdi
  6b8922:	mov    %r15,%rsi
  6b8925:	mov    %r13,%rcx
  6b8928:	call   *0x389f5a(%rip)        # a42888 <_DYNAMIC+0x2f0>
  6b892e:	test   %rax,%rax
  6b8931:	jne    6b8a67 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x387>
  6b8937:	mov    $0x8,%edi
  6b893c:	mov    %r13,%rsi
  6b893f:	call   *0x389f4b(%rip)        # a42890 <_DYNAMIC+0x2f8>
  6b8945:	jmp    6b8b0e <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x42e>
  6b894a:	mov    0x8(%rsp),%rcx
  6b894f:	mov    (%rcx),%rax
  6b8952:	mov    0x8(%rcx),%r15
  6b8956:	cmp    %r14,%rax
  6b8959:	jbe    6b8aca <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x3ea>
  6b895f:	shl    $0x3,%rax
  6b8963:	lea    (%rax,%rax,4),%r12
  6b8967:	lea    0x0(,%r14,8),%rax
  6b896f:	lea    (%rax,%rax,4),%r13
  6b8973:	mov    $0x8,%edx
  6b8978:	mov    %r15,%rdi
  6b897b:	mov    %r12,%rsi
  6b897e:	mov    %r13,%rcx
  6b8981:	call   *0x389f01(%rip)        # a42888 <_DYNAMIC+0x2f0>
  6b8987:	test   %rax,%rax
  6b898a:	jne    6b8acd <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x3ed>
  6b8990:	mov    $0x8,%edi
  6b8995:	mov    %r13,%rsi
  6b8998:	call   *0x389ef2(%rip)        # a42890 <_DYNAMIC+0x2f8>
  6b899e:	jmp    6b8b0e <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x42e>
  6b89a3:	mov    %rbx,%r15
  6b89a6:	mov    0x8(%rsp),%rax
  6b89ab:	mov    0x18(%rax),%rbp
  6b89af:	mov    0x20(%rax),%rbx
  6b89b3:	cmp    %r12,%rbp
  6b89b6:	jbe    6b89ef <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x30f>
  6b89b8:	shl    $0x6,%rbp
  6b89bc:	mov    %r12,%r13
  6b89bf:	shl    $0x6,%r13
  6b89c3:	mov    $0x8,%edx
  6b89c8:	mov    %rbx,%rdi
  6b89cb:	mov    %rbp,%rsi
  6b89ce:	mov    %r13,%rcx
  6b89d1:	call   *0x389eb1(%rip)        # a42888 <_DYNAMIC+0x2f0>
  6b89d7:	test   %rax,%rax
  6b89da:	jne    6b89f2 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x312>
  6b89dc:	mov    $0x8,%edi
  6b89e1:	mov    %r13,%rsi
  6b89e4:	call   *0x389ea6(%rip)        # a42890 <_DYNAMIC+0x2f8>
  6b89ea:	jmp    6b8b0e <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x42e>
  6b89ef:	mov    %rbx,%rax
  6b89f2:	mov    %r15,0x28(%rsp)
  6b89f7:	mov    %r14,0x30(%rsp)
  6b89fc:	mov    %rax,0x38(%rsp)
  6b8a01:	mov    %r12,0x40(%rsp)
  6b8a06:	call   *0x389dfc(%rip)        # a42808 <_DYNAMIC+0x270>
  6b8a0c:	mov    $0x20,%edi
  6b8a11:	mov    $0x8,%esi
  6b8a16:	call   *0x389df4(%rip)        # a42810 <_DYNAMIC+0x278>
  6b8a1c:	test   %rax,%rax
  6b8a1f:	je     6b8afe <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x41e>
  6b8a25:	movups 0x28(%rsp),%xmm0
  6b8a2a:	movups 0x38(%rsp),%xmm1
  6b8a2f:	movups %xmm1,0x10(%rax)
  6b8a33:	movups %xmm0,(%rax)
  6b8a36:	mov    0x18(%rsp),%rcx
  6b8a3b:	mov    %rax,0x8(%rcx)
  6b8a3f:	movq   $0x3,(%rcx)
  6b8a46:	jmp    6b8aef <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x40f>
  6b8a4b:	xor    %eax,%eax
  6b8a4d:	mov    0x8(%rsp),%r14
  6b8a52:	mov    0x18(%rsp),%rcx
  6b8a57:	mov    %rax,(%rcx)
  6b8a5a:	mov    (%r14),%rax
  6b8a5d:	test   %rax,%rax
  6b8a60:	jne    6b8a84 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x3a4>
  6b8a62:	jmp    6b8a9b <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x3bb>
  6b8a64:	mov    %rbx,%rax
  6b8a67:	mov    0x18(%rsp),%rcx
  6b8a6c:	mov    %rax,0x8(%rcx)
  6b8a70:	mov    %r12,0x10(%rcx)
  6b8a74:	mov    $0x2,%eax
  6b8a79:	mov    %rax,(%rcx)
  6b8a7c:	mov    (%r14),%rax
  6b8a7f:	test   %rax,%rax
  6b8a82:	je     6b8a9b <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x3bb>
  6b8a84:	mov    0x8(%r14),%rdi
  6b8a88:	shl    $0x3,%rax
  6b8a8c:	lea    (%rax,%rax,4),%rsi
  6b8a90:	mov    $0x8,%edx
  6b8a95:	call   *0x389d65(%rip)        # a42800 <_DYNAMIC+0x268>
  6b8a9b:	test   %r12,%r12
  6b8a9e:	jne    6b8aef <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x40f>
  6b8aa0:	mov    0x18(%r14),%rsi
  6b8aa4:	test   %rsi,%rsi
  6b8aa7:	je     6b8aef <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x40f>
  6b8aa9:	mov    0x20(%r14),%rdi
  6b8aad:	shl    $0x6,%rsi
  6b8ab1:	mov    $0x8,%edx
  6b8ab6:	add    $0x48,%rsp
  6b8aba:	pop    %rbx
  6b8abb:	pop    %r12
  6b8abd:	pop    %r13
  6b8abf:	pop    %r14
  6b8ac1:	pop    %r15
  6b8ac3:	pop    %rbp
  6b8ac4:	jmp    *0x389d36(%rip)        # a42800 <_DYNAMIC+0x268>
  6b8aca:	mov    %r15,%rax
  6b8acd:	mov    0x18(%rsp),%rcx
  6b8ad2:	mov    %rax,0x8(%rcx)
  6b8ad6:	mov    %r14,0x10(%rcx)
  6b8ada:	movq   $0x1,(%rcx)
  6b8ae1:	mov    0x8(%rsp),%r14
  6b8ae6:	mov    0x18(%r14),%rsi
  6b8aea:	test   %rsi,%rsi
  6b8aed:	jne    6b8aa9 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x3c9>
  6b8aef:	add    $0x48,%rsp
  6b8af3:	pop    %rbx
  6b8af4:	pop    %r12
  6b8af6:	pop    %r13
  6b8af8:	pop    %r14
  6b8afa:	pop    %r15
  6b8afc:	pop    %rbp
  6b8afd:	ret
  6b8afe:	mov    $0x8,%edi
  6b8b03:	mov    $0x20,%esi
  6b8b08:	call   *0x389d0a(%rip)        # a42818 <_DYNAMIC+0x280>
  6b8b0e:	ud2
  6b8b10:	mov    %rax,%r14
  6b8b13:	mov    $0x8,%edx
  6b8b18:	mov    %r15,%rdi
  6b8b1b:	mov    %r12,%rsi
  6b8b1e:	jmp    6b8b7e <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x49e>
  6b8b20:	mov    %rax,0x10(%rsp)
  6b8b25:	mov    $0x8,%edx
  6b8b2a:	mov    %rbx,%rdi
  6b8b2d:	mov    %r15,%rsi
  6b8b30:	call   *0x389cca(%rip)        # a42800 <_DYNAMIC+0x268>
  6b8b36:	xor    %ebx,%ebx
  6b8b38:	jmp    6b8bda <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x4fa>
  6b8b3d:	mov    %rax,%r13
  6b8b40:	mov    0x389cb9(%rip),%r12        # a42800 <_DYNAMIC+0x268>
  6b8b47:	mov    $0x8,%edx
  6b8b4c:	mov    %rbx,%rdi
  6b8b4f:	mov    %rbp,%rsi
  6b8b52:	call   *%r12
  6b8b55:	shl    $0x3,%r14
  6b8b59:	lea    (%r14,%r14,4),%rsi
  6b8b5d:	mov    $0x8,%edx
  6b8b62:	mov    %r15,%rdi
  6b8b65:	call   *%r12
  6b8b68:	mov    %r13,%rdi
  6b8b6b:	call   a20c40 <_Unwind_Resume@plt>
  6b8b70:	mov    %rax,%r14
  6b8b73:	mov    $0x8,%edx
  6b8b78:	mov    %rbx,%rdi
  6b8b7b:	mov    %r13,%rsi
  6b8b7e:	call   *0x389c7c(%rip)        # a42800 <_DYNAMIC+0x268>
  6b8b84:	jmp    6b8c0c <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x52c>
  6b8b89:	mov    %rax,0x10(%rsp)
  6b8b8e:	shl    $0x6,%r12
  6b8b92:	add    %r12,%r13
  6b8b95:	shl    $0x6,%r14
  6b8b99:	sub    %rbx,%r14
  6b8b9c:	mov    %r13,%rdi
  6b8b9f:	mov    %rbp,%rsi
  6b8ba2:	mov    %r14,%rdx
  6b8ba5:	jmp    6b8bc9 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x4e9>
  6b8ba7:	mov    %rax,0x10(%rsp)
  6b8bac:	lea    (%r14,%r14,4),%rax
  6b8bb0:	lea    0x0(,%rax,8),%rdi
  6b8bb8:	add    %rbp,%rdi
  6b8bbb:	shl    $0x3,%rbx
  6b8bbf:	lea    (%rbx,%rbx,4),%rdx
  6b8bc3:	sub    %r13,%rdx
  6b8bc6:	mov    %r12,%rsi
  6b8bc9:	call   *0x389c81(%rip)        # a42850 <memmove@GLIBC_2.2.5>
  6b8bcf:	jmp    6b8bd8 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x4f8>
  6b8bd1:	jmp    6b8bd3 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x4f3>
  6b8bd3:	mov    %rax,0x10(%rsp)
  6b8bd8:	mov    $0x1,%bl
  6b8bda:	mov    0x8(%rsp),%rax
  6b8bdf:	mov    (%rax),%rax
  6b8be2:	test   %rax,%rax
  6b8be5:	je     6b8c03 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x523>
  6b8be7:	mov    0x8(%rsp),%rcx
  6b8bec:	mov    0x8(%rcx),%rdi
  6b8bf0:	shl    $0x3,%rax
  6b8bf4:	lea    (%rax,%rax,4),%rsi
  6b8bf8:	mov    $0x8,%edx
  6b8bfd:	call   *0x389bfd(%rip)        # a42800 <_DYNAMIC+0x268>
  6b8c03:	test   %bl,%bl
  6b8c05:	mov    0x10(%rsp),%r14
  6b8c0a:	je     6b8c47 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x567>
  6b8c0c:	mov    0x8(%rsp),%rax
  6b8c11:	mov    0x18(%rax),%rsi
  6b8c15:	test   %rsi,%rsi
  6b8c18:	je     6b8c47 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>+0x567>
  6b8c1a:	mov    0x8(%rsp),%rax
  6b8c1f:	mov    0x20(%rax),%rdi
  6b8c23:	shl    $0x6,%rsi
  6b8c27:	mov    $0x8,%edx
  6b8c2c:	call   *0x389bce(%rip)        # a42800 <_DYNAMIC+0x268>
  6b8c32:	mov    %r14,%rdi
  6b8c35:	call   a20c40 <_Unwind_Resume@plt>
  6b8c3a:	mov    %rax,%r14
  6b8c3d:	lea    0x28(%rsp),%rdi
  6b8c42:	call   6c75a0 <core::ptr::drop_glue::<gpui::runtime::scroll::Columns>>
  6b8c47:	mov    %r14,%rdi
  6b8c4a:	call   a20c40 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9} code=1503 fixed_stack=248

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006dabe0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}>:
  6dabe0:	push   %rbp
  6dabe1:	push   %r15
  6dabe3:	push   %r14
  6dabe5:	push   %r13
  6dabe7:	push   %r12
  6dabe9:	push   %rbx
  6dabea:	sub    $0xc8,%rsp
  6dabf1:	mov    %rcx,%r14
  6dabf4:	mov    %rsi,%r15
  6dabf7:	mov    (%rcx),%ecx
  6dabf9:	mov    0x10(%r14),%ebx
  6dabfd:	test   %ebx,%ebx
  6dabff:	je     6dac23 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x43>
  6dac01:	cmp    $0x1,%ebx
  6dac04:	jne    6dadfa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x21a>
  6dac0a:	movss  -0x69ab76(%rip),%xmm0        # 4009c <GCC_except_table0+0x254>
  6dac12:	mov    %ebx,%ebp
  6dac14:	movss  0x4(%r14),%xmm1
  6dac1a:	movaps %xmm1,%xmm2
  6dac1d:	test   %ecx,%ecx
  6dac1f:	je     6dac3b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x5b>
  6dac21:	jmp    6dac3e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x5e>
  6dac23:	movss  0x14(%r14),%xmm0
  6dac29:	mov    $0x1,%ebp
  6dac2e:	movss  0x4(%r14),%xmm1
  6dac34:	movaps %xmm1,%xmm2
  6dac37:	test   %ecx,%ecx
  6dac39:	jne    6dac3e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x5e>
  6dac3b:	movaps %xmm0,%xmm2
  6dac3e:	mov    $0x1,%eax
  6dac43:	cmovne %eax,%ebp
  6dac46:	mov    (%r15),%rax
  6dac49:	mov    0x10(%rax),%rsi
  6dac4d:	test   %rsi,%rsi
  6dac50:	je     6db121 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x541>
  6dac56:	mov    %ecx,0x1c(%rsp)
  6dac5a:	mov    %rdi,0x10(%rsp)
  6dac5f:	mov    0x8(%rax),%rax
  6dac63:	mov    (%rdx),%rcx
  6dac66:	cmp    $0x1,%rsi
  6dac6a:	jne    6dad31 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x151>
  6dac70:	xor    %r12d,%r12d
  6dac73:	mov    %r12,%rdi
  6dac76:	shl    $0x4,%rdi
  6dac7a:	mov    (%rax,%rdi,1),%r8
  6dac7e:	cmp    %rcx,%r8
  6dac81:	seta   %sil
  6dac85:	sbb    $0x0,%sil
  6dac89:	cmp    %rcx,%r8
  6dac8c:	jne    6dacb3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0xd3>
  6dac8e:	add    %rdi,%rax
  6dac91:	mov    0x8(%rax),%ecx
  6dac94:	mov    0x8(%rdx),%edi
  6dac97:	cmp    %edi,%ecx
  6dac99:	seta   %sil
  6dac9d:	sbb    $0x0,%sil
  6daca1:	cmp    %edi,%ecx
  6daca3:	jne    6dacb3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0xd3>
  6daca5:	mov    0xc(%rax),%eax
  6daca8:	cmp    0xc(%rdx),%eax
  6dacab:	seta   %sil
  6dacaf:	sbb    $0x0,%sil
  6dacb3:	test   %sil,%sil
  6dacb6:	jne    6db126 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x546>
  6dacbc:	movss  %xmm2,0x8(%rsp)
  6dacc2:	movss  %xmm1,0xc(%rsp)
  6dacc8:	mov    0x8(%r15),%rax
  6daccc:	mov    0x10(%rax),%rsi
  6dacd0:	cmp    %rsi,%r12
  6dacd3:	jae    6db15c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x57c>
  6dacd9:	mov    0x8(%rax),%rax
  6dacdd:	lea    (%r12,%r12,4),%rcx
  6dace1:	mov    0x20(%rax,%rcx,8),%r13d
  6dace6:	mov    %r13d,%edi
  6dace9:	call   *0x367d09(%rip)        # a429f8 <_DYNAMIC+0x460>
  6dacef:	cmp    $0x2,%dl
  6dacf2:	jne    6dad89 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x1a9>
  6dacf8:	mov    0x18(%r15),%rdx
  6dacfc:	cmpq   $0x0,(%rdx)
  6dad00:	je     6db0d5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x4f5>
  6dad06:	mov    %r13d,%eax
  6dad09:	and    $0xf,%eax
  6dad0c:	cmp    $0x9,%eax
  6dad0f:	ja     6db108 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x528>
  6dad15:	cmp    $0x6,%eax
  6dad18:	je     6dad24 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x144>
  6dad1a:	shr    $0x4,%r13d
  6dad1e:	jne    6dae29 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x249>
  6dad24:	lea    0x347ba5(%rip),%rdi        # a228d0 <__frame_dummy_init_array_entry+0x8e0>
  6dad2b:	call   *0x367b6f(%rip)        # a428a0 <_DYNAMIC+0x308>
  6dad31:	mov    0x8(%rdx),%edi
  6dad34:	mov    0xc(%rdx),%r8d
  6dad38:	xor    %r9d,%r9d
  6dad3b:	jmp    6dad57 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x177>
  6dad3d:	nopl   (%rax)
  6dad40:	test   %r13b,%r13b
  6dad43:	cmovne %r9,%r12
  6dad47:	sub    %r10,%rsi
  6dad4a:	mov    %r12,%r9
  6dad4d:	cmp    $0x1,%rsi
  6dad51:	jbe    6dac73 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x93>
  6dad57:	mov    %rsi,%r10
  6dad5a:	shr    $1,%r10
  6dad5d:	lea    (%r10,%r9,1),%r12
  6dad61:	mov    %r12,%r11
  6dad64:	shl    $0x4,%r11
  6dad68:	cmp    %rcx,(%rax,%r11,1)
  6dad6c:	seta   %r13b
  6dad70:	jne    6dad40 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x160>
  6dad72:	add    %rax,%r11
  6dad75:	cmp    %edi,0x8(%r11)
  6dad79:	seta   %r13b
  6dad7d:	jne    6dad40 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x160>
  6dad7f:	cmp    %r8d,0xc(%r11)
  6dad83:	seta   %r13b
  6dad87:	jmp    6dad40 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x160>
  6dad89:	mov    0x10(%r15),%rcx
  6dad8d:	mov    (%rcx),%rcx
  6dad90:	test   %rcx,%rcx
  6dad93:	je     6db0ee <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x50e>
  6dad99:	mov    %eax,%edi
  6dad9b:	mov    0x10(%rcx),%rsi
  6dad9f:	cmp    %rdi,%rsi
  6dada2:	jbe    6db16c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x58c>
  6dada8:	mov    0x8(%rcx),%rax
  6dadac:	mov    (%rax,%rdi,8),%rax
  6dadb0:	mov    0x30(%rax),%ecx
  6dadb3:	mov    0x34(%rax),%eax
  6dadb6:	xorps  %xmm0,%xmm0
  6dadb9:	cvtsi2ss %rcx,%xmm0
  6dadbe:	xorps  %xmm1,%xmm1
  6dadc1:	cvtsi2ss %rax,%xmm1
  6dadc6:	movaps %xmm0,%xmm2
  6dadc9:	divss  %xmm1,%xmm2
  6dadcd:	movzbl 0x8(%r14),%ecx
  6dadd2:	movss  0xc(%r14),%xmm3
  6dadd8:	cmpb   $0x0,0x1c(%rsp)
  6daddd:	mov    0x10(%rsp),%rax
  6dade2:	je     6dae12 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x232>
  6dade4:	test   %cl,%cl
  6dade6:	je     6daebc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x2dc>
  6dadec:	movss  0xc(%rsp),%xmm0
  6dadf2:	movaps %xmm3,%xmm1
  6dadf5:	jmp    6daec9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x2e9>
  6dadfa:	xor    %ebp,%ebp
  6dadfc:	movss  0x4(%r14),%xmm1
  6dae02:	movaps %xmm1,%xmm2
  6dae05:	test   %ecx,%ecx
  6dae07:	je     6dac3b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x5b>
  6dae0d:	jmp    6dac3e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x5e>
  6dae12:	test   %cl,%cl
  6dae14:	je     6daec9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x2e9>
  6dae1a:	mulss  %xmm3,%xmm2
  6dae1e:	movaps %xmm2,%xmm0
  6dae21:	movaps %xmm3,%xmm1
  6dae24:	jmp    6daec9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x2e9>
  6dae29:	mov    0x20(%r15),%rax
  6dae2d:	mov    0x10(%rax),%rsi
  6dae31:	dec    %r13d
  6dae34:	cmp    %r13,%rsi
  6dae37:	jbe    6db179 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x599>
  6dae3d:	mov    0x8(%rax),%rsi
  6dae41:	lea    0x0(%r13,%r13,4),%r13
  6dae46:	shl    $0x4,%r13
  6dae4a:	cmpq   $0xfffffffffffffffe,(%rsi,%r13,1)
  6dae4f:	je     6db0fb <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x51b>
  6dae55:	mov    0x28(%r15),%rcx
  6dae59:	mov    (%rcx),%rax
  6dae5c:	lea    -0x699333(%rip),%rdi        # 41b30 <GCC_except_table0+0x1ce8>
  6dae63:	movslq (%rdi,%rax,4),%rax
  6dae67:	add    %rdi,%rax
  6dae6a:	jmp    *%rax
  6dae6c:	movups -0x68dc0f(%rip),%xmm0        # 4d264 <GCC_except_table0+0xd41c>
  6dae73:	movaps %xmm0,0x60(%rsp)
  6dae78:	movups -0x68dc2b(%rip),%xmm0        # 4d254 <GCC_except_table0+0xd40c>
  6dae7f:	movaps %xmm0,0x50(%rsp)
  6dae84:	movups -0x68dc47(%rip),%xmm0        # 4d244 <GCC_except_table0+0xd3fc>
  6dae8b:	movaps %xmm0,0x40(%rsp)
  6dae90:	movups -0x68dc63(%rip),%xmm0        # 4d234 <GCC_except_table0+0xd3ec>
  6dae97:	movaps %xmm0,0x30(%rsp)
  6dae9c:	movups -0x68dc7f(%rip),%xmm0        # 4d224 <GCC_except_table0+0xd3dc>
  6daea3:	movaps %xmm0,0x20(%rsp)
  6daea8:	movabs $0x3000100000000,%rax
  6daeb2:	mov    %rax,0x70(%rsp)
  6daeb7:	jmp    6daf92 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x3b2>
  6daebc:	movss  0xc(%rsp),%xmm0
  6daec2:	movaps %xmm0,%xmm1
  6daec5:	divss  %xmm2,%xmm1
  6daec9:	movss  %xmm0,0x10(%rax)
  6daece:	movss  %xmm1,0x14(%rax)
  6daed3:	xorps  %xmm0,%xmm0
  6daed6:	movups %xmm0,(%rax)
  6daed9:	jmp    6db0c3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x4e3>
  6daede:	mov    0x20(%rcx),%rax
  6daee2:	cmp    %rax,%r12
  6daee5:	jae    6db189 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x5a9>
  6daeeb:	mov    0x10(%rcx),%rax
  6daeef:	mov    0x18(%rcx),%rdi
  6daef3:	movzbl (%rdi,%r12,1),%edi
  6daef8:	cmp    %rdi,%rax
  6daefb:	jbe    6db1af <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x5cf>
  6daf01:	mov    0x8(%rcx),%rax
  6daf05:	imul   $0x58,%rdi,%rcx
  6daf09:	jmp    6daf57 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x377>
  6daf0b:	mov    0x8(%rcx),%rax
  6daf0f:	lea    0x20(%rsp),%rdi
  6daf14:	mov    %rsi,0x88(%rsp)
  6daf1c:	mov    %rax,%rsi
  6daf1f:	mov    %rdx,0x80(%rsp)
  6daf27:	mov    %r12,%rdx
  6daf2a:	call   *0x367a60(%rip)        # a42990 <_DYNAMIC+0x3f8>
  6daf30:	mov    0x88(%rsp),%rsi
  6daf38:	mov    0x80(%rsp),%rdx
  6daf40:	jmp    6daf92 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x3b2>
  6daf42:	mov    0x18(%rcx),%rax
  6daf46:	cmp    %rax,%r12
  6daf49:	jae    6db19c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x5bc>
  6daf4f:	mov    0x10(%rcx),%rax
  6daf53:	imul   $0x58,%r12,%rcx
  6daf57:	mov    0x50(%rax,%rcx,1),%rdi
  6daf5c:	mov    %rdi,0x70(%rsp)
  6daf61:	movups 0x40(%rax,%rcx,1),%xmm0
  6daf66:	movaps %xmm0,0x60(%rsp)
  6daf6b:	movups (%rax,%rcx,1),%xmm0
  6daf6f:	movups 0x10(%rax,%rcx,1),%xmm1
  6daf74:	movups 0x20(%rax,%rcx,1),%xmm2
  6daf79:	movups 0x30(%rax,%rcx,1),%xmm3
  6daf7e:	movaps %xmm3,0x50(%rsp)
  6daf83:	movaps %xmm2,0x40(%rsp)
  6daf88:	movaps %xmm1,0x30(%rsp)
  6daf8d:	movaps %xmm0,0x20(%rsp)
  6daf92:	mov    0x10(%rsp),%r12
  6daf97:	movss  0x8(%rsp),%xmm1
  6daf9d:	add    %r13,%rsi
  6dafa0:	movss  0x38(%rsp),%xmm0
  6dafa6:	test   %ebx,%ebx
  6dafa8:	sete   %al
  6dafab:	mov    0x1c(%rsp),%ebx
  6dafaf:	or     %bl,%al
  6dafb1:	movzbl %al,%r8d
  6dafb5:	lea    0x90(%rsp),%rdi
  6dafbd:	mov    %ebp,%ecx
  6dafbf:	call   *0x367a3b(%rip)        # a42a00 <_DYNAMIC+0x468>
  6dafc5:	cmpl   $0xfffffffe,0x90(%rsp)
  6dafcd:	jne    6db032 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x452>
  6dafcf:	mov    0x98(%rsp),%rax
  6dafd7:	movss  0x30(%rax),%xmm0
  6dafdc:	test   %bl,%bl
  6dafde:	movss  0xc(%rsp),%xmm2
  6dafe4:	jne    6dafeb <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x40b>
  6dafe6:	movss  0x28(%rax),%xmm2
  6dafeb:	add    $0x2c,%rax
  6dafef:	lea    0xc(%r14),%rcx
  6daff3:	cmpb   $0x0,0x8(%r14)
  6daff8:	cmove  %rax,%rcx
  6daffc:	movss  (%rcx),%xmm1
  6db000:	movss  %xmm2,0x10(%r12)
  6db007:	movss  %xmm1,0x14(%r12)
  6db00e:	movl   $0x1,(%r12)
  6db016:	movss  %xmm0,0x4(%r12)
  6db01d:	movl   $0x1,0x8(%r12)
  6db026:	movss  %xmm0,0xc(%r12)
  6db02d:	jmp    6db0c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x4e0>
  6db032:	mov    0x30(%r15),%rbx
  6db036:	mov    (%rbx),%rax
  6db039:	cmp    $0xfffffffffffffffe,%rax
  6db03d:	je     6db080 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x4a0>
  6db03f:	sub    $0xd,%rax
  6db043:	mov    $0x14,%ecx
  6db048:	cmovge %rax,%rcx
  6db04c:	cmp    $0x14,%rcx
  6db050:	je     6db063 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x483>
  6db052:	cmp    $0x19,%rcx
  6db056:	jne    6db080 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x4a0>
  6db058:	mov    0x8(%rbx),%rsi
  6db05c:	mov    $0x10,%eax
  6db061:	jmp    6db06c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x48c>
  6db063:	mov    0x18(%rbx),%rsi
  6db067:	mov    $0x20,%eax
  6db06c:	test   %rsi,%rsi
  6db06f:	je     6db080 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x4a0>
  6db071:	mov    (%rbx,%rax,1),%rdi
  6db075:	mov    $0x1,%edx
  6db07a:	call   *0x367780(%rip)        # a42800 <_DYNAMIC+0x268>
  6db080:	mov    0xc0(%rsp),%rax
  6db088:	mov    %rax,0x30(%rbx)
  6db08c:	movups 0x90(%rsp),%xmm0
  6db094:	movups 0xa0(%rsp),%xmm1
  6db09c:	movups 0xb0(%rsp),%xmm2
  6db0a4:	movups %xmm2,0x20(%rbx)
  6db0a8:	movups %xmm1,0x10(%rbx)
  6db0ac:	movups %xmm0,(%rbx)
  6db0af:	xorps  %xmm0,%xmm0
  6db0b2:	movups %xmm0,(%r12)
  6db0b7:	movq   $0x0,0x10(%r12)
  6db0c0:	mov    %r12,%rax
  6db0c3:	add    $0xc8,%rsp
  6db0ca:	pop    %rbx
  6db0cb:	pop    %r12
  6db0cd:	pop    %r13
  6db0cf:	pop    %r14
  6db0d1:	pop    %r15
  6db0d3:	pop    %rbp
  6db0d4:	ret
  6db0d5:	lea    -0x68dbbe(%rip),%rdi        # 4d51e <GCC_except_table0+0xd6d6>
  6db0dc:	lea    0x3477d5(%rip),%rdx        # a228b8 <__frame_dummy_init_array_entry+0x8c8>
  6db0e3:	mov    $0x28,%esi
  6db0e8:	call   *0x3678b2(%rip)        # a429a0 <_DYNAMIC+0x408>
  6db0ee:	lea    0x347793(%rip),%rdi        # a22888 <__frame_dummy_init_array_entry+0x898>
  6db0f5:	call   *0x3677a5(%rip)        # a428a0 <_DYNAMIC+0x308>
  6db0fb:	lea    0x3476de(%rip),%rdi        # a227e0 <__frame_dummy_init_array_entry+0x7f0>
  6db102:	call   *0x367798(%rip)        # a428a0 <_DYNAMIC+0x308>
  6db108:	lea    -0x68ad91(%rip),%rdi        # 5037e <GCC_except_table0+0x10536>
  6db10f:	lea    0x3489f2(%rip),%rdx        # a23b08 <__frame_dummy_init_array_entry+0x1b18>
  6db116:	mov    $0x83,%esi
  6db11b:	call   *0x367717(%rip)        # a42838 <_DYNAMIC+0x2a0>
  6db121:	xor    %r12d,%r12d
  6db124:	jmp    6db132 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}+0x552>
  6db126:	xor    %eax,%eax
  6db128:	cmp    $0xff,%sil
  6db12c:	sete   %al
  6db12f:	add    %rax,%r12
  6db132:	mov    %r12,0x20(%rsp)
  6db137:	lea    -0x68dc54(%rip),%rdi        # 4d4ea <GCC_except_table0+0xd6a2>
  6db13e:	lea    0x3481a3(%rip),%rcx        # a232e8 <__frame_dummy_init_array_entry+0x12f8>
  6db145:	lea    0x34770c(%rip),%r8        # a22858 <__frame_dummy_init_array_entry+0x868>
  6db14c:	lea    0x20(%rsp),%rdx
  6db151:	mov    $0x34,%esi
  6db156:	call   *0x36767c(%rip)        # a427d8 <_DYNAMIC+0x240>
  6db15c:	lea    0x34770d(%rip),%rdx        # a22870 <__frame_dummy_init_array_entry+0x880>
  6db163:	mov    %r12,%rdi
  6db166:	call   *0x3676c4(%rip)        # a42830 <_DYNAMIC+0x298>
  6db16c:	lea    0x34772d(%rip),%rdx        # a228a0 <__frame_dummy_init_array_entry+0x8b0>
  6db173:	call   *0x3676b7(%rip)        # a42830 <_DYNAMIC+0x298>
  6db179:	lea    0x347648(%rip),%rdx        # a227c8 <__frame_dummy_init_array_entry+0x7d8>
  6db180:	mov    %r13,%rdi
  6db183:	call   *0x3676a7(%rip)        # a42830 <_DYNAMIC+0x298>
  6db189:	lea    0x348270(%rip),%rdx        # a23400 <__frame_dummy_init_array_entry+0x1410>
  6db190:	mov    %r12,%rdi
  6db193:	mov    %rax,%rsi
  6db196:	call   *0x367694(%rip)        # a42830 <_DYNAMIC+0x298>
  6db19c:	lea    0x348245(%rip),%rdx        # a233e8 <__frame_dummy_init_array_entry+0x13f8>
  6db1a3:	mov    %r12,%rdi
  6db1a6:	mov    %rax,%rsi
  6db1a9:	call   *0x367681(%rip)        # a42830 <_DYNAMIC+0x298>
  6db1af:	lea    0x348262(%rip),%rdx        # a23418 <__frame_dummy_init_array_entry+0x1428>
  6db1b6:	mov    %rax,%rsi
  6db1b9:	call   *0x367671(%rip)        # a42830 <_DYNAMIC+0x298>

<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39} code=415 fixed_stack=8

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006db1c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>:
  6db1c0:	push   %rax
  6db1c1:	mov    (%rdi),%rdx
  6db1c4:	mov    (%rdx),%rax
  6db1c7:	test   %rax,%rax
  6db1ca:	je     6db216 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x56>
  6db1cc:	cmp    $0x1,%eax
  6db1cf:	jne    6db232 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x72>
  6db1d1:	mov    0x8(%rdx),%rcx
  6db1d5:	mov    0x10(%rdx),%rdx
  6db1d9:	cmp    $0x1,%rdx
  6db1dd:	je     6db288 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0xc8>
  6db1e3:	test   %rdx,%rdx
  6db1e6:	je     6db330 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x170>
  6db1ec:	xor    %eax,%eax
  6db1ee:	xchg   %ax,%ax
  6db1f0:	mov    %rax,%r8
  6db1f3:	mov    %rdx,%r9
  6db1f6:	shr    $1,%r9
  6db1f9:	add    %r9,%rax
  6db1fc:	mov    %rax,%r10
  6db1ff:	shl    $0x4,%r10
  6db203:	cmp    %rsi,(%rcx,%r10,1)
  6db207:	cmova  %r8,%rax
  6db20b:	sub    %r9,%rdx
  6db20e:	cmp    $0x1,%rdx
  6db212:	ja     6db1f0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x30>
  6db214:	jmp    6db28a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0xca>
  6db216:	mov    %rsi,%rax
  6db219:	sub    0x8(%rdx),%rax
  6db21d:	jb     6db330 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x170>
  6db223:	cmp    0x10(%rdx),%rax
  6db227:	jb     6db2c2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x102>
  6db22d:	jmp    6db330 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x170>
  6db232:	mov    0x8(%rdx),%rax
  6db236:	mov    0x10(%rdx),%rcx
  6db23a:	cmp    $0x1,%rcx
  6db23e:	je     6db308 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x148>
  6db244:	test   %rcx,%rcx
  6db247:	je     6db330 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x170>
  6db24d:	xor    %edx,%edx
  6db24f:	nop
  6db250:	mov    %rdx,%r8
  6db253:	mov    %rcx,%r9
  6db256:	shr    $1,%r9
  6db259:	add    %r9,%rdx
  6db25c:	lea    (%rdx,%rdx,2),%r10
  6db260:	cmp    %rsi,(%rax,%r10,4)
  6db264:	cmova  %r8,%rdx
  6db268:	sub    %r9,%rcx
  6db26b:	cmp    $0x1,%rcx
  6db26f:	ja     6db250 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x90>
  6db271:	lea    (%rdx,%rdx,2),%rcx
  6db275:	cmp    %rsi,(%rax,%rcx,4)
  6db279:	jne    6db330 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x170>
  6db27f:	lea    (%rax,%rcx,4),%rax
  6db283:	jmp    6db30d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x14d>
  6db288:	xor    %eax,%eax
  6db28a:	mov    %rax,%r8
  6db28d:	shl    $0x4,%r8
  6db291:	xor    %edx,%edx
  6db293:	cmp    %rsi,(%rcx,%r8,1)
  6db297:	setbe  %dl
  6db29a:	add    %rax,%rdx
  6db29d:	je     6db330 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x170>
  6db2a3:	shl    $0x4,%rdx
  6db2a7:	mov    %rsi,%rax
  6db2aa:	sub    -0x10(%rcx,%rdx,1),%rax
  6db2af:	mov    -0x4(%rcx,%rdx,1),%r8d
  6db2b4:	cmp    %r8,%rax
  6db2b7:	jae    6db330 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x170>
  6db2b9:	add    %rdx,%rcx
  6db2bc:	mov    -0x8(%rcx),%ecx
  6db2bf:	add    %rcx,%rax
  6db2c2:	mov    0x8(%rdi),%rdx
  6db2c6:	mov    0x10(%rdx),%rcx
  6db2ca:	cmp    %rcx,%rax
  6db2cd:	jae    6db31d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x15d>
  6db2cf:	mov    0x8(%rdx),%rcx
  6db2d3:	mov    (%rcx,%rax,4),%edx
  6db2d6:	mov    $0xffffffff,%eax
  6db2db:	cmp    %rax,%rdx
  6db2de:	je     6db304 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x144>
  6db2e0:	mov    0x10(%rdi),%rcx
  6db2e4:	mov    0x10(%rcx),%rax
  6db2e8:	cmp    %rdx,%rax
  6db2eb:	jbe    6db349 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x189>
  6db2ed:	mov    0x8(%rcx),%rcx
  6db2f1:	mov    %rdx,%rdi
  6db2f4:	shl    $0x6,%rdi
  6db2f8:	xor    %eax,%eax
  6db2fa:	cmp    %rsi,0x20(%rcx,%rdi,1)
  6db2ff:	sete   %al
  6db302:	pop    %rcx
  6db303:	ret
  6db304:	xor    %eax,%eax
  6db306:	pop    %rcx
  6db307:	ret
  6db308:	cmp    %rsi,(%rax)
  6db30b:	jne    6db330 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x170>
  6db30d:	mov    0x8(%rax),%eax
  6db310:	mov    0x8(%rdi),%rdx
  6db314:	mov    0x10(%rdx),%rcx
  6db318:	cmp    %rcx,%rax
  6db31b:	jb     6db2cf <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}+0x10f>
  6db31d:	lea    0x3475c4(%rip),%rdx        # a228e8 <__frame_dummy_init_array_entry+0x8f8>
  6db324:	mov    %rax,%rdi
  6db327:	mov    %rcx,%rsi
  6db32a:	call   *0x367500(%rip)        # a42830 <_DYNAMIC+0x298>
  6db330:	lea    -0x68dea5(%rip),%rdi        # 4d492 <GCC_except_table0+0xd64a>
  6db337:	lea    0x347172(%rip),%rdx        # a224b0 <__frame_dummy_init_array_entry+0x4c0>
  6db33e:	mov    $0x15,%esi
  6db343:	call   *0x367657(%rip)        # a429a0 <_DYNAMIC+0x408>
  6db349:	lea    0x3472f8(%rip),%rcx        # a22648 <__frame_dummy_init_array_entry+0x658>
  6db350:	mov    %rdx,%rdi
  6db353:	mov    %rax,%rsi
  6db356:	mov    %rcx,%rdx
  6db359:	call   *0x3674d1(%rip)        # a42830 <_DYNAMIC+0x298>

<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13} code=130 fixed_stack=8

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006db360 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}>:
  6db360:	push   %rax
  6db361:	cmp    %rsi,%rdx
  6db364:	jae    6db3cf <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}+0x6f>
  6db366:	lea    (%rdx,%rdx,4),%rax
  6db36a:	mov    0x20(%rdi,%rax,8),%eax
  6db36e:	and    $0xf,%eax
  6db371:	cmp    $0x9,%eax
  6db374:	ja     6db3b6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}+0x56>
  6db376:	lea    -0x69983d(%rip),%rcx        # 41b40 <GCC_except_table0+0x1cf8>
  6db37d:	movslq (%rcx,%rax,4),%rax
  6db381:	add    %rcx,%rax
  6db384:	jmp    *%rax
  6db386:	mov    $0x8,%al
  6db388:	jmp    6db3a8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}+0x48>
  6db38a:	mov    $0x4,%al
  6db38c:	jmp    6db3a8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}+0x48>
  6db38e:	mov    $0x2,%al
  6db390:	jmp    6db3a8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}+0x48>
  6db392:	mov    $0x3,%al
  6db394:	jmp    6db3a8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}+0x48>
  6db396:	mov    $0x7,%al
  6db398:	jmp    6db3a8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}+0x48>
  6db39a:	xor    %eax,%eax
  6db39c:	jmp    6db3a8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}+0x48>
  6db39e:	mov    $0x1,%al
  6db3a0:	jmp    6db3a8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}+0x48>
  6db3a2:	mov    $0x5,%al
  6db3a4:	jmp    6db3a8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}+0x48>
  6db3a6:	mov    $0x6,%al
  6db3a8:	cmp    $0x4,%al
  6db3aa:	sete   %cl
  6db3ad:	cmp    $0x7,%al
  6db3af:	sete   %al
  6db3b2:	or     %cl,%al
  6db3b4:	pop    %rcx
  6db3b5:	ret
  6db3b6:	lea    -0x68b03f(%rip),%rdi        # 5037e <GCC_except_table0+0x10536>
  6db3bd:	lea    0x348744(%rip),%rdx        # a23b08 <__frame_dummy_init_array_entry+0x1b18>
  6db3c4:	mov    $0x83,%esi
  6db3c9:	call   *0x367469(%rip)        # a42838 <_DYNAMIC+0x2a0>
  6db3cf:	lea    0x34752a(%rip),%rax        # a22900 <__frame_dummy_init_array_entry+0x910>
  6db3d6:	mov    %rdx,%rdi
  6db3d9:	mov    %rax,%rdx
  6db3dc:	call   *0x36744e(%rip)        # a42830 <_DYNAMIC+0x298>

<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#23} code=143 fixed_stack=24

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006db3f0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#23}>:
  6db3f0:	push   %r14
  6db3f2:	push   %rbx
  6db3f3:	push   %rax
  6db3f4:	mov    %rdx,%rbx
  6db3f7:	and    $0xf,%esi
  6db3fa:	cmp    $0x7,%esi
  6db3fd:	jb     6db407 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#23}+0x17>
  6db3ff:	lea    -0x8(%rsi),%eax
  6db402:	cmp    $0x2,%eax
  6db405:	jae    6db42d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#23}+0x3d>
  6db407:	mov    0x30(%rbx),%rax
  6db40b:	mov    %rax,0x30(%rdi)
  6db40f:	movups (%rbx),%xmm0
  6db412:	movups 0x10(%rbx),%xmm1
  6db416:	movups 0x20(%rbx),%xmm2
  6db41a:	movups %xmm2,0x20(%rdi)
  6db41e:	movups %xmm1,0x10(%rdi)
  6db422:	movups %xmm0,(%rdi)
  6db425:	add    $0x8,%rsp
  6db429:	pop    %rbx
  6db42a:	pop    %r14
  6db42c:	ret
  6db42d:	cmp    $0x7,%esi
  6db430:	jne    6db451 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#23}+0x61>
  6db432:	cmpl   $0x27,(%rbx)
  6db435:	jne    6db407 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#23}+0x17>
  6db437:	cmpq   $0xb,0x8(%rbx)
  6db43c:	jne    6db407 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#23}+0x17>
  6db43e:	movb   $0x5,0x8(%rdi)
  6db442:	movq   $0x28,(%rdi)
  6db449:	add    $0x8,%rsp
  6db44d:	pop    %rbx
  6db44e:	pop    %r14
  6db450:	ret
  6db451:	lea    -0x68b0da(%rip),%rdi        # 5037e <GCC_except_table0+0x10536>
  6db458:	lea    0x3486a9(%rip),%rdx        # a23b08 <__frame_dummy_init_array_entry+0x1b18>
  6db45f:	mov    $0x83,%esi
  6db464:	call   *0x3673ce(%rip)        # a42838 <_DYNAMIC+0x2a0>
  6db46a:	ud2
  6db46c:	mov    %rax,%r14
  6db46f:	mov    %rbx,%rdi
  6db472:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6db477:	mov    %r14,%rdi
  6db47a:	call   a20c40 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#24} code=61 fixed_stack=72

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006db480 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#24}>:
  6db480:	sub    $0x48,%rsp
  6db484:	cvtps2pd (%rdx),%xmm0
  6db487:	cvtps2pd 0x8(%rdx),%xmm1
  6db48b:	movaps %xmm0,0x10(%rsp)
  6db490:	movaps %xmm1,0x20(%rsp)
  6db495:	cvtps2pd 0x10(%rdx),%xmm0
  6db499:	movaps %xmm0,0x30(%rsp)
  6db49e:	movb   $0x0,0x40(%rsp)
  6db4a3:	movups (%rsi),%xmm0
  6db4a6:	movaps %xmm0,(%rsp)
  6db4aa:	lea    0x10(%rsp),%rsi
  6db4af:	mov    %rsp,%rdx
  6db4b2:	call   *0x367550(%rip)        # a42a08 <_DYNAMIC+0x470>
  6db4b8:	add    $0x48,%rsp
  6db4bc:	ret

<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36} code=884 fixed_stack=136

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006db4c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}>:
  6db4c0:	push   %rbp
  6db4c1:	push   %r15
  6db4c3:	push   %r14
  6db4c5:	push   %r13
  6db4c7:	push   %r12
  6db4c9:	push   %rbx
  6db4ca:	sub    $0x58,%rsp
  6db4ce:	mov    (%rsi),%rax
  6db4d1:	mov    0x10(%rax),%rcx
  6db4d5:	mov    %rcx,0x10(%rsp)
  6db4da:	movups (%rax),%xmm0
  6db4dd:	movaps %xmm0,(%rsp)
  6db4e1:	movq   $0x0,(%rax)
  6db4e8:	movq   $0x4,0x8(%rax)
  6db4f0:	movq   $0x0,0x10(%rax)
  6db4f8:	mov    0x8(%rsi),%r13
  6db4fc:	mov    0x10(%rsi),%rbp
  6db500:	mov    0x18(%rsi),%rax
  6db504:	mov    %rax,0x30(%rsp)
  6db509:	mov    0x20(%rsi),%rax
  6db50d:	mov    %rax,0x28(%rsp)
  6db512:	mov    0x8(%rdx),%r12
  6db516:	mov    0x10(%rdx),%rbx
  6db51a:	mov    (%rsp),%r15
  6db51e:	mov    0x10(%rsp),%rsi
  6db523:	mov    %r15,%rax
  6db526:	sub    %rsi,%rax
  6db529:	cmp    %rax,%rbx
  6db52c:	mov    %rdi,0x38(%rsp)
  6db531:	ja     6db79e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x2de>
  6db537:	test   %rbx,%rbx
  6db53a:	je     6db77a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x2ba>
  6db540:	shl    $0x4,%rbx
  6db544:	add    %r12,%rbx
  6db547:	mov    %rsp,%rdi
  6db54a:	jmp    6db589 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc9>
  6db54c:	mov    0x8(%rsp),%rax
  6db551:	mov    %rsi,%rcx
  6db554:	shl    $0x4,%rcx
  6db558:	movl   $0x7fc00000,(%rax,%rcx,1)
  6db55f:	mov    %r15d,0x4(%rax,%rcx,1)
  6db564:	mov    %r14,0x8(%rax,%rcx,1)
  6db569:	inc    %rsi
  6db56c:	mov    %rsi,0x10(%rsp)
  6db571:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6db580:	cmp    %rbx,%r12
  6db583:	je     6db77a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x2ba>
  6db589:	mov    %r12,%rax
  6db58c:	add    $0x10,%r12
  6db590:	mov    0x8(%rax),%r15d
  6db594:	test   %r15d,%r15d
  6db597:	je     6db580 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db599:	mov    (%rax),%r14
  6db59c:	cmpb   $0x1,0x0(%r13)
  6db5a1:	jne    6db6f7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x237>
  6db5a7:	mov    0x0(%rbp),%rax
  6db5ab:	test   %rax,%rax
  6db5ae:	je     6db660 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x1a0>
  6db5b4:	cmp    $0x1,%eax
  6db5b7:	jne    6db680 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x1c0>
  6db5bd:	mov    0x10(%rbp),%rcx
  6db5c1:	test   %rcx,%rcx
  6db5c4:	je     6db580 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db5c6:	mov    0x8(%rbp),%rax
  6db5ca:	xor    %edx,%edx
  6db5cc:	cmp    $0x1,%rcx
  6db5d0:	je     6db604 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x144>
  6db5d2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6db5e0:	mov    %rdx,%r9
  6db5e3:	mov    %rcx,%r10
  6db5e6:	shr    $1,%r10
  6db5e9:	add    %r10,%rdx
  6db5ec:	mov    %rdx,%r8
  6db5ef:	shl    $0x4,%r8
  6db5f3:	cmp    %r14,(%rax,%r8,1)
  6db5f7:	cmova  %r9,%rdx
  6db5fb:	sub    %r10,%rcx
  6db5fe:	cmp    $0x1,%rcx
  6db602:	ja     6db5e0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x120>
  6db604:	mov    %rdx,%rcx
  6db607:	shl    $0x4,%rcx
  6db60b:	xor    %r8d,%r8d
  6db60e:	cmp    %r14,(%rax,%rcx,1)
  6db612:	setbe  %r8b
  6db616:	add    %rdx,%r8
  6db619:	je     6db580 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db61f:	shl    $0x4,%r8
  6db623:	mov    %r14,%rcx
  6db626:	sub    -0x10(%rax,%r8,1),%rcx
  6db62b:	mov    -0x4(%rax,%r8,1),%edx
  6db630:	cmp    %rdx,%rcx
  6db633:	jae    6db580 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db639:	add    %r8,%rax
  6db63c:	mov    -0x8(%rax),%eax
  6db63f:	add    %rax,%rcx
  6db642:	mov    0x30(%rsp),%rax
  6db647:	cmp    0x10(%rax),%rcx
  6db64b:	jae    6db580 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db651:	jmp    6db6b6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x1f6>
  6db653:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6db660:	mov    %r14,%rcx
  6db663:	sub    0x8(%rbp),%rcx
  6db667:	jb     6db580 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db66d:	cmp    0x10(%rbp),%rcx
  6db671:	jae    6db580 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db677:	jmp    6db6a7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x1e7>
  6db679:	nopl   0x0(%rax)
  6db680:	mov    0x10(%rbp),%rcx
  6db684:	test   %rcx,%rcx
  6db687:	je     6db580 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db68d:	mov    0x8(%rbp),%rax
  6db691:	cmp    $0x1,%rcx
  6db695:	jne    6db728 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x268>
  6db69b:	cmp    %r14,(%rax)
  6db69e:	jne    6db580 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db6a4:	mov    0x8(%rax),%ecx
  6db6a7:	mov    0x30(%rsp),%rax
  6db6ac:	cmp    0x10(%rax),%rcx
  6db6b0:	jae    6db580 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db6b6:	mov    0x30(%rsp),%rax
  6db6bb:	mov    0x8(%rax),%rax
  6db6bf:	mov    (%rax,%rcx,4),%eax
  6db6c2:	mov    $0xffffffff,%ecx
  6db6c7:	cmp    %rcx,%rax
  6db6ca:	je     6db580 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db6d0:	mov    0x28(%rsp),%rcx
  6db6d5:	cmp    %rax,0x10(%rcx)
  6db6d9:	jbe    6db580 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db6df:	mov    0x28(%rsp),%rcx
  6db6e4:	mov    0x8(%rcx),%rcx
  6db6e8:	shl    $0x6,%rax
  6db6ec:	cmp    %r14,0x20(%rcx,%rax,1)
  6db6f1:	jne    6db580 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db6f7:	cmp    (%rsp),%rsi
  6db6fb:	jne    6db54c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x8c>
  6db701:	mov    $0x1,%edx
  6db706:	mov    $0x4,%ecx
  6db70b:	mov    $0x10,%r8d
  6db711:	mov    %rsi,0x20(%rsp)
  6db716:	call   6d93e0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  6db71b:	mov    %rsp,%rdi
  6db71e:	mov    0x20(%rsp),%rsi
  6db723:	jmp    6db54c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x8c>
  6db728:	xor    %edx,%edx
  6db72a:	nopw   0x0(%rax,%rax,1)
  6db730:	mov    %rdx,%r9
  6db733:	mov    %rcx,%r10
  6db736:	shr    $1,%r10
  6db739:	add    %r10,%rdx
  6db73c:	lea    (%rdx,%rdx,2),%r8
  6db740:	cmp    %r14,(%rax,%r8,4)
  6db744:	cmova  %r9,%rdx
  6db748:	sub    %r10,%rcx
  6db74b:	cmp    $0x1,%rcx
  6db74f:	ja     6db730 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x270>
  6db751:	lea    (%rdx,%rdx,2),%rcx
  6db755:	cmp    %r14,(%rax,%rcx,4)
  6db759:	jne    6db580 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db75f:	lea    (%rax,%rcx,4),%rax
  6db763:	mov    0x8(%rax),%ecx
  6db766:	mov    0x30(%rsp),%rax
  6db76b:	cmp    0x10(%rax),%rcx
  6db76f:	jae    6db580 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0xc0>
  6db775:	jmp    6db6b6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x1f6>
  6db77a:	mov    0x10(%rsp),%rax
  6db77f:	mov    0x38(%rsp),%rcx
  6db784:	mov    %rax,0x10(%rcx)
  6db788:	movaps (%rsp),%xmm0
  6db78c:	movups %xmm0,(%rcx)
  6db78f:	add    $0x58,%rsp
  6db793:	pop    %rbx
  6db794:	pop    %r12
  6db796:	pop    %r13
  6db798:	pop    %r14
  6db79a:	pop    %r15
  6db79c:	pop    %rbp
  6db79d:	ret
  6db79e:	mov    %rsi,0x20(%rsp)
  6db7a3:	mov    %rsi,%rax
  6db7a6:	add    %rbx,%rax
  6db7a9:	jb     6db7ee <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x32e>
  6db7ab:	mov    0x8(%rsp),%rdx
  6db7b0:	lea    0x40(%rsp),%rdi
  6db7b5:	mov    $0x4,%r8d
  6db7bb:	mov    $0x10,%r9d
  6db7c1:	mov    %r15,%rsi
  6db7c4:	mov    %rax,%r14
  6db7c7:	mov    %rax,%rcx
  6db7ca:	call   6f4da0 <<alloc::raw_vec::RawVecInner>::finish_grow>
  6db7cf:	cmpl   $0x1,0x40(%rsp)
  6db7d4:	je     6db7f8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x338>
  6db7d6:	mov    0x48(%rsp),%rax
  6db7db:	mov    %rax,0x8(%rsp)
  6db7e0:	mov    %r14,(%rsp)
  6db7e4:	mov    0x20(%rsp),%rsi
  6db7e9:	jmp    6db540 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x80>
  6db7ee:	xor    %edi,%edi
  6db7f0:	call   *0x36709a(%rip)        # a42890 <_DYNAMIC+0x2f8>
  6db7f6:	ud2
  6db7f8:	mov    0x48(%rsp),%rdi
  6db7fd:	mov    0x50(%rsp),%rsi
  6db802:	jmp    6db7f0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x330>
  6db804:	mov    %rax,%rbx
  6db807:	mov    (%rsp),%r15
  6db80b:	jmp    6db810 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x350>
  6db80d:	mov    %rax,%rbx
  6db810:	test   %r15,%r15
  6db813:	je     6db82c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}+0x36c>
  6db815:	mov    0x8(%rsp),%rdi
  6db81a:	shl    $0x4,%r15
  6db81e:	mov    $0x4,%edx
  6db823:	mov    %r15,%rsi
  6db826:	call   *0x366fd4(%rip)        # a42800 <_DYNAMIC+0x268>
  6db82c:	mov    %rbx,%rdi
  6db82f:	call   a20c40 <_Unwind_Resume@plt>

<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9} as core::ops::function::FnOnce<(gpui_reactivity_core::tree::NodeId, cephal::tree::traits::MeasureInput)>>::call_once::{shim:vtable#0} code=57 fixed_stack=56

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006dbc30 <<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9} as core::ops::function::FnOnce<(gpui_reactivity_core::tree::NodeId, cephal::tree::traits::MeasureInput)>>::call_once::{shim:vtable#0}>:
  6dbc30:	push   %rbx
  6dbc31:	sub    $0x30,%rsp
  6dbc35:	mov    %rdi,%rbx
  6dbc38:	lea    0x10(%rsp),%rax
  6dbc3d:	movups (%rcx),%xmm0
  6dbc40:	movups 0x10(%rcx),%xmm1
  6dbc44:	movaps %xmm1,0x20(%rsp)
  6dbc49:	movaps %xmm0,0x10(%rsp)
  6dbc4e:	movups (%rdx),%xmm0
  6dbc51:	movaps %xmm0,(%rsp)
  6dbc55:	mov    %rsp,%rdx
  6dbc58:	mov    %rax,%rcx
  6dbc5b:	call   6dabe0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#9}>
  6dbc60:	mov    %rbx,%rax
  6dbc63:	add    $0x30,%rsp
  6dbc67:	pop    %rbx
  6dbc68:	ret

text_column_public_control::emit_state code=5501 fixed_stack=712

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006dbc70 <text_column_public_control::emit_state>:
  6dbc70:	push   %rbp
  6dbc71:	push   %r15
  6dbc73:	push   %r14
  6dbc75:	push   %r13
  6dbc77:	push   %r12
  6dbc79:	push   %rbx
  6dbc7a:	sub    $0x298,%rsp
  6dbc81:	mov    %edx,0xcc(%rsp)
  6dbc88:	mov    %esi,0xc8(%rsp)
  6dbc8f:	mov    %rdi,%rbp
  6dbc92:	mov    %rcx,0x270(%rsp)
  6dbc9a:	mov    %r8,0x278(%rsp)
  6dbca2:	lea    0xd0(%rsp),%rdi
  6dbcaa:	mov    %rbp,%rsi
  6dbcad:	call   6b60e0 <text_column_public_control::observe::<text_column_public_control::Model>>
  6dbcb2:	mov    0xd0(%rsp),%rax
  6dbcba:	mov    0xd8(%rsp),%rcx
  6dbcc2:	mov    %rax,0x1f8(%rsp)
  6dbcca:	mov    %rcx,0x200(%rsp)
  6dbcd2:	mov    0xe0(%rsp),%rax
  6dbcda:	mov    %rax,0x208(%rsp)
  6dbce2:	test   %rbp,%rbp
  6dbce5:	je     6dcff9 <text_column_public_control::emit_state+0x1389>
  6dbceb:	mov    0x5f0(%rbp),%r15
  6dbcf2:	mov    %r15,%rax
  6dbcf5:	shl    $0x7,%rax
  6dbcf9:	lea    (%rax,%r15,8),%rbx
  6dbcfd:	movabs $0xf0f0f0f0f0f0f0,%rax
  6dbd07:	cmp    %rax,%r15
  6dbd0a:	jbe    6dbd1b <text_column_public_control::emit_state+0xab>
  6dbd0c:	xor    %r14d,%r14d
  6dbd0f:	mov    %r14,%rdi
  6dbd12:	mov    %rbx,%rsi
  6dbd15:	call   *0x366b75(%rip)        # a42890 <_DYNAMIC+0x2f8>
  6dbd1b:	test   %rbx,%rbx
  6dbd1e:	je     6dbd44 <text_column_public_control::emit_state+0xd4>
  6dbd20:	call   *0x366ae2(%rip)        # a42808 <_DYNAMIC+0x270>
  6dbd26:	mov    $0x8,%r14d
  6dbd2c:	mov    $0x8,%esi
  6dbd31:	mov    %rbx,%rdi
  6dbd34:	call   *0x366ad6(%rip)        # a42810 <_DYNAMIC+0x278>
  6dbd3a:	test   %rax,%rax
  6dbd3d:	je     6dbd0f <text_column_public_control::emit_state+0x9f>
  6dbd3f:	mov    %rax,%r12
  6dbd42:	jmp    6dbd4d <text_column_public_control::emit_state+0xdd>
  6dbd44:	mov    $0x8,%r12d
  6dbd4a:	xor    %r15d,%r15d
  6dbd4d:	mov    %r15,0x88(%rsp)
  6dbd55:	mov    %r12,0x90(%rsp)
  6dbd5d:	movq   $0x0,0x98(%rsp)
  6dbd69:	mov    0x680(%rbp),%rax
  6dbd70:	test   %rax,%rax
  6dbd73:	je     6dbd8e <text_column_public_control::emit_state+0x11e>
  6dbd75:	mov    0x100(%rax),%rsi
  6dbd7c:	test   %rsi,%rsi
  6dbd7f:	je     6dbd8e <text_column_public_control::emit_state+0x11e>
  6dbd81:	lea    0x30(%rsp),%rdi
  6dbd86:	call   *0x366a54(%rip)        # a427e0 <_DYNAMIC+0x248>
  6dbd8c:	jmp    6dbd9f <text_column_public_control::emit_state+0x12f>
  6dbd8e:	movq   $0x4,0x30(%rsp)
  6dbd97:	xorps  %xmm0,%xmm0
  6dbd9a:	movups %xmm0,0x38(%rsp)
  6dbd9f:	mov    0x5f0(%rbp),%rax
  6dbda6:	mov    %rax,0xb0(%rsp)
  6dbdae:	test   %rax,%rax
  6dbdb1:	mov    %rbp,0x80(%rsp)
  6dbdb9:	je     6dc2c1 <text_column_public_control::emit_state+0x651>
  6dbdbf:	lea    0x620(%rbp),%rax
  6dbdc6:	mov    %rax,0x18(%rsp)
  6dbdcb:	xor    %r14d,%r14d
  6dbdce:	lea    0x347d7b(%rip),%rax        # a23b50 <__frame_dummy_init_array_entry+0x1b60>
  6dbdd5:	mov    %rax,0x10(%rsp)
  6dbdda:	jmp    6dbe26 <text_column_public_control::emit_state+0x1b6>
  6dbddc:	nopl   0x0(%rax)
  6dbde0:	mov    0x90(%rsp),%r12
  6dbde8:	lea    0x1(%r14),%rbx
  6dbdec:	mov    %r14,%rax
  6dbdef:	shl    $0x7,%rax
  6dbdf3:	lea    (%rax,%r14,8),%rdi
  6dbdf7:	add    %r12,%rdi
  6dbdfa:	mov    $0x88,%edx
  6dbdff:	lea    0xd0(%rsp),%rsi
  6dbe07:	call   *0x366a13(%rip)        # a42820 <memcpy@GLIBC_2.14>
  6dbe0d:	mov    %rbx,0x98(%rsp)
  6dbe15:	mov    %rbx,%r14
  6dbe18:	cmp    0xb0(%rsp),%rbx
  6dbe20:	je     6dc2c1 <text_column_public_control::emit_state+0x651>
  6dbe26:	mov    0x5f0(%rbp),%rsi
  6dbe2d:	cmp    %rsi,%r14
  6dbe30:	jae    6dcf96 <text_column_public_control::emit_state+0x1326>
  6dbe36:	mov    0x5e8(%rbp),%r15
  6dbe3d:	mov    %r14,%rbx
  6dbe40:	shl    $0x6,%rbx
  6dbe44:	mov    0x20(%r15,%rbx,1),%r8
  6dbe49:	cmpb   $0x0,0x78a(%rbp)
  6dbe50:	mov    %r8,0x8(%rsp)
  6dbe55:	je     6dbe64 <text_column_public_control::emit_state+0x1f4>
  6dbe57:	cmpb   $0x0,0x78e(%rbp)
  6dbe5e:	je     6dbf70 <text_column_public_control::emit_state+0x300>
  6dbe64:	xor    %r13d,%r13d
  6dbe67:	add    %rbx,%r15
  6dbe6a:	mov    0x38(%r15),%ebx
  6dbe6e:	and    $0x1ffff,%ebx
  6dbe74:	xor    %ebp,%ebp
  6dbe76:	cmp    $0x1ffff,%rbx
  6dbe7d:	setne  0xb8(%rsp)
  6dbe85:	movzbl 0x3d(%r15),%eax
  6dbe8a:	sub    $0x2,%al
  6dbe8c:	movzbl %al,%eax
  6dbe8f:	mov    $0x8,%ecx
  6dbe94:	cmovb  %ecx,%eax
  6dbe97:	mov    %al,0x1a0(%rsp)
  6dbe9e:	lea    0x1a0(%rsp),%rax
  6dbea6:	mov    %rax,0x218(%rsp)
  6dbeae:	lea    0x4be4b(%rip),%rax        # 727d00 <<gpui::element::Role as core::fmt::Debug>::fmt>
  6dbeb5:	mov    %rax,0x220(%rsp)
  6dbebd:	lea    0xd0(%rsp),%rdi
  6dbec5:	lea    -0x696bf8(%rip),%rsi        # 452d4 <GCC_except_table0+0x548c>
  6dbecc:	lea    0x218(%rsp),%rdx
  6dbed4:	call   *0x366b46(%rip)        # a42a20 <_DYNAMIC+0x488>
  6dbeda:	mov    %r14,0xc0(%rsp)
  6dbee2:	mov    %r12,0x70(%rsp)
  6dbee7:	mov    0xd0(%rsp),%rax
  6dbeef:	mov    %rax,0x20(%rsp)
  6dbef4:	mov    0xd8(%rsp),%rax
  6dbefc:	mov    %rax,0x78(%rsp)
  6dbf01:	mov    0xe0(%rsp),%rax
  6dbf09:	mov    %rax,0x68(%rsp)
  6dbf0e:	mov    0x28(%r15),%r14
  6dbf12:	test   %r14,%r14
  6dbf15:	je     6dbf60 <text_column_public_control::emit_state+0x2f0>
  6dbf17:	mov    (%r14),%r12
  6dbf1a:	shr    $1,%r12
  6dbf1d:	je     6dbfc0 <text_column_public_control::emit_state+0x350>
  6dbf23:	call   *0x3668df(%rip)        # a42808 <_DYNAMIC+0x270>
  6dbf29:	mov    $0x1,%esi
  6dbf2e:	mov    %r12,%rdi
  6dbf31:	call   *0x3668d9(%rip)        # a42810 <_DYNAMIC+0x278>
  6dbf37:	test   %rax,%rax
  6dbf3a:	je     6dcfbe <text_column_public_control::emit_state+0x134e>
  6dbf40:	add    $0x10,%r14
  6dbf44:	mov    %rax,0x50(%rsp)
  6dbf49:	mov    %rax,%rdi
  6dbf4c:	mov    %r14,%rsi
  6dbf4f:	mov    %r12,%rdx
  6dbf52:	call   *0x3668c8(%rip)        # a42820 <memcpy@GLIBC_2.14>
  6dbf58:	mov    %r12,0x60(%rsp)
  6dbf5d:	jmp    6dbfd6 <text_column_public_control::emit_state+0x366>
  6dbf5f:	nop
  6dbf60:	mov    $0xffffffffffffffff,%r12
  6dbf67:	jmp    6dbfd6 <text_column_public_control::emit_state+0x366>
  6dbf69:	nopl   0x0(%rax)
  6dbf70:	mov    0x1e8(%rbp),%rax
  6dbf77:	test   %rax,%rax
  6dbf7a:	je     6dc12e <text_column_public_control::emit_state+0x4be>
  6dbf80:	cmp    $0x1,%eax
  6dbf83:	jne    6dc150 <text_column_public_control::emit_state+0x4e0>
  6dbf89:	mov    0x1f8(%rbp),%r13
  6dbf90:	test   %r13,%r13
  6dbf93:	je     6dc180 <text_column_public_control::emit_state+0x510>
  6dbf99:	mov    0x1f0(%rbp),%rax
  6dbfa0:	xor    %ecx,%ecx
  6dbfa2:	cmp    $0x1,%r13
  6dbfa6:	jne    6dc185 <text_column_public_control::emit_state+0x515>
  6dbfac:	mov    0x8(%rsp),%r8
  6dbfb1:	jmp    6dc1b4 <text_column_public_control::emit_state+0x544>
  6dbfb6:	cs nopw 0x0(%rax,%rax,1)
  6dbfc0:	mov    $0x1,%eax
  6dbfc5:	mov    %rax,0x50(%rsp)
  6dbfca:	xor    %r12d,%r12d
  6dbfcd:	movq   $0x0,0x60(%rsp)
  6dbfd6:	movups 0x10(%r15),%xmm0
  6dbfdb:	movaps %xmm0,0x190(%rsp)
  6dbfe3:	lea    0x30(%rsp),%rdi
  6dbfe8:	call   *0x366a3a(%rip)        # a42a28 <_DYNAMIC+0x490>
  6dbfee:	mov    0xc0(%rsp),%r14
  6dbff6:	mov    %rdx,%rcx
  6dbff9:	lea    0xd0(%rsp),%rdi
  6dc001:	mov    %r15,%rsi
  6dc004:	mov    %rax,%rdx
  6dc007:	call   *0x366a23(%rip)        # a42a30 <_DYNAMIC+0x498>
  6dc00d:	mov    0xd0(%rsp),%eax
  6dc014:	test   %eax,%eax
  6dc016:	jne    6dc030 <text_column_public_control::emit_state+0x3c0>
  6dc018:	movaps 0x1c0(%rsp),%xmm0
  6dc020:	movaps 0x1b0(%rsp),%xmm1
  6dc028:	jmp    6dc041 <text_column_public_control::emit_state+0x3d1>
  6dc02a:	nopw   0x0(%rax,%rax,1)
  6dc030:	movups 0xd4(%rsp),%xmm0
  6dc038:	movsd  0xe4(%rsp),%xmm1
  6dc041:	movaps 0x190(%rsp),%xmm2
  6dc049:	movzbl 0xb8(%rsp),%ecx
  6dc051:	mov    %cl,%bpl
  6dc054:	mov    0x8(%rsp),%rcx
  6dc059:	mov    %rcx,0x110(%rsp)
  6dc061:	mov    %rbp,0xd0(%rsp)
  6dc069:	mov    %rbx,0xd8(%rsp)
  6dc071:	mov    0x20(%rsp),%rcx
  6dc076:	mov    %rcx,0xe0(%rsp)
  6dc07e:	mov    0x78(%rsp),%rcx
  6dc083:	mov    %rcx,0xe8(%rsp)
  6dc08b:	mov    0x68(%rsp),%rcx
  6dc090:	mov    %rcx,0xf0(%rsp)
  6dc098:	mov    %r12,0xf8(%rsp)
  6dc0a0:	mov    0x50(%rsp),%rcx
  6dc0a5:	mov    %rcx,0x100(%rsp)
  6dc0ad:	mov    0x60(%rsp),%rcx
  6dc0b2:	mov    %rcx,0x108(%rsp)
  6dc0ba:	movups %xmm2,0x118(%rsp)
  6dc0c2:	mov    %eax,0x138(%rsp)
  6dc0c9:	movaps %xmm0,0x1c0(%rsp)
  6dc0d1:	movups %xmm0,0x13c(%rsp)
  6dc0d9:	movaps %xmm1,0x1b0(%rsp)
  6dc0e1:	movlps %xmm1,0x14c(%rsp)
  6dc0e9:	mov    %r13,0x128(%rsp)
  6dc0f1:	mov    0xa8(%rsp),%rax
  6dc0f9:	mov    %rax,0x130(%rsp)
  6dc101:	cmp    0x88(%rsp),%r14
  6dc109:	mov    0x80(%rsp),%rbp
  6dc111:	mov    0x70(%rsp),%r12
  6dc116:	jne    6dbde8 <text_column_public_control::emit_state+0x178>
  6dc11c:	lea    0x88(%rsp),%rdi
  6dc124:	call   6f4a90 <<alloc::raw_vec::RawVec<gpui::runtime::SnapshotNode>>::grow_one>
  6dc129:	jmp    6dbde0 <text_column_public_control::emit_state+0x170>
  6dc12e:	mov    %r8,%rcx
  6dc131:	sub    0x1f0(%rbp),%rcx
  6dc138:	jb     6dbe64 <text_column_public_control::emit_state+0x1f4>
  6dc13e:	cmp    0x1f8(%rbp),%rcx
  6dc145:	jae    6dbe64 <text_column_public_control::emit_state+0x1f4>
  6dc14b:	jmp    6dc236 <text_column_public_control::emit_state+0x5c6>
  6dc150:	mov    0x1f8(%rbp),%r13
  6dc157:	test   %r13,%r13
  6dc15a:	je     6dc180 <text_column_public_control::emit_state+0x510>
  6dc15c:	mov    0x1f0(%rbp),%rax
  6dc163:	cmp    $0x1,%r13
  6dc167:	jne    6dc1f1 <text_column_public_control::emit_state+0x581>
  6dc16d:	mov    0x8(%rsp),%r8
  6dc172:	cmp    %r8,(%rax)
  6dc175:	jne    6dbe64 <text_column_public_control::emit_state+0x1f4>
  6dc17b:	jmp    6dc233 <text_column_public_control::emit_state+0x5c3>
  6dc180:	jmp    6dbe67 <text_column_public_control::emit_state+0x1f7>
  6dc185:	mov    0x8(%rsp),%r8
  6dc18a:	nopw   0x0(%rax,%rax,1)
  6dc190:	mov    %rcx,%rdx
  6dc193:	mov    %r13,%rsi
  6dc196:	shr    $1,%rsi
  6dc199:	add    %rsi,%rcx
  6dc19c:	mov    %rcx,%rdi
  6dc19f:	shl    $0x4,%rdi
  6dc1a3:	cmp    %r8,(%rax,%rdi,1)
  6dc1a7:	cmova  %rdx,%rcx
  6dc1ab:	sub    %rsi,%r13
  6dc1ae:	cmp    $0x1,%r13
  6dc1b2:	ja     6dc190 <text_column_public_control::emit_state+0x520>
  6dc1b4:	mov    %rcx,%rsi
  6dc1b7:	shl    $0x4,%rsi
  6dc1bb:	xor    %edx,%edx
  6dc1bd:	cmp    %r8,(%rax,%rsi,1)
  6dc1c1:	setbe  %dl
  6dc1c4:	add    %rcx,%rdx
  6dc1c7:	je     6dbe64 <text_column_public_control::emit_state+0x1f4>
  6dc1cd:	shl    $0x4,%rdx
  6dc1d1:	mov    %r8,%rcx
  6dc1d4:	sub    -0x10(%rax,%rdx,1),%rcx
  6dc1d9:	mov    -0x4(%rax,%rdx,1),%esi
  6dc1dd:	cmp    %rsi,%rcx
  6dc1e0:	jae    6dbe64 <text_column_public_control::emit_state+0x1f4>
  6dc1e6:	add    %rdx,%rax
  6dc1e9:	mov    -0x8(%rax),%eax
  6dc1ec:	add    %rax,%rcx
  6dc1ef:	jmp    6dc236 <text_column_public_control::emit_state+0x5c6>
  6dc1f1:	xor    %ecx,%ecx
  6dc1f3:	mov    0x8(%rsp),%r8
  6dc1f8:	nopl   0x0(%rax,%rax,1)
  6dc200:	mov    %rcx,%rdx
  6dc203:	mov    %r13,%rsi
  6dc206:	shr    $1,%rsi
  6dc209:	add    %rsi,%rcx
  6dc20c:	lea    (%rcx,%rcx,2),%rdi
  6dc210:	cmp    %r8,(%rax,%rdi,4)
  6dc214:	cmova  %rdx,%rcx
  6dc218:	sub    %rsi,%r13
  6dc21b:	cmp    $0x1,%r13
  6dc21f:	ja     6dc200 <text_column_public_control::emit_state+0x590>
  6dc221:	lea    (%rcx,%rcx,2),%rcx
  6dc225:	cmp    %r8,(%rax,%rcx,4)
  6dc229:	jne    6dbe64 <text_column_public_control::emit_state+0x1f4>
  6dc22f:	lea    (%rax,%rcx,4),%rax
  6dc233:	mov    0x8(%rax),%ecx
  6dc236:	mov    0x310(%rbp),%rsi
  6dc23d:	cmp    %rsi,%rcx
  6dc240:	jae    6dd03b <text_column_public_control::emit_state+0x13cb>
  6dc246:	mov    0x308(%rbp),%rax
  6dc24d:	lea    (%rcx,%rcx,4),%rcx
  6dc251:	cmpq   $0x0,0x8(%rax,%rcx,8)
  6dc257:	je     6dc277 <text_column_public_control::emit_state+0x607>
  6dc259:	mov    0x18(%rsp),%rdi
  6dc25e:	mov    %r8,%rsi
  6dc261:	call   *0x3667d1(%rip)        # a42a38 <_DYNAMIC+0x4a0>
  6dc267:	mov    %rdx,0xa8(%rsp)
  6dc26f:	mov    %rax,%r13
  6dc272:	jmp    6dbe67 <text_column_public_control::emit_state+0x1f7>
  6dc277:	lea    (%rax,%rcx,8),%rax
  6dc27b:	mov    0x20(%rax),%eax
  6dc27e:	and    $0xf,%eax
  6dc281:	lea    -0x3(%rax),%ecx
  6dc284:	cmp    $0x7,%ecx
  6dc287:	jb     6dbe64 <text_column_public_control::emit_state+0x1f4>
  6dc28d:	mov    $0x0,%r13d
  6dc293:	cmp    $0x2,%eax
  6dc296:	jb     6dbe67 <text_column_public_control::emit_state+0x1f7>
  6dc29c:	mov    0x8(%rsp),%r8
  6dc2a1:	je     6dc259 <text_column_public_control::emit_state+0x5e9>
  6dc2a3:	lea    -0x68bf2c(%rip),%rdi        # 5037e <GCC_except_table0+0x10536>
  6dc2aa:	lea    0x347857(%rip),%rdx        # a23b08 <__frame_dummy_init_array_entry+0x1b18>
  6dc2b1:	mov    $0x83,%esi
  6dc2b6:	call   *0x36657c(%rip)        # a42838 <_DYNAMIC+0x2a0>
  6dc2bc:	jmp    6dd0a2 <text_column_public_control::emit_state+0x1432>
  6dc2c1:	lea    0x90(%rsp),%rdx
  6dc2c9:	movups 0x6d0(%rbp),%xmm0
  6dc2d0:	movzbl 0x78c(%rbp),%ecx
  6dc2d7:	mov    0x6f0(%rbp),%rax
  6dc2de:	test   %rax,%rax
  6dc2e1:	je     6dc300 <text_column_public_control::emit_state+0x690>
  6dc2e3:	test   %cl,%cl
  6dc2e5:	je     6dc2f1 <text_column_public_control::emit_state+0x681>
  6dc2e7:	cmpq   $0xffffffffffffffff,0x5f8(%rbp)
  6dc2ef:	je     6dc300 <text_column_public_control::emit_state+0x690>
  6dc2f1:	mov    0x700(%rbp),%r10
  6dc2f8:	mov    $0x1,%r11d
  6dc2fe:	jmp    6dc303 <text_column_public_control::emit_state+0x693>
  6dc300:	xor    %r11d,%r11d
  6dc303:	movzbl 0x78e(%rbp),%esi
  6dc30a:	movups (%rdx),%xmm1
  6dc30d:	mov    0x88(%rsp),%rdx
  6dc315:	movups %xmm1,0x230(%rsp)
  6dc31d:	mov    %r11,0x218(%rsp)
  6dc325:	mov    %r10,0x220(%rsp)
  6dc32d:	mov    %rdx,0x228(%rsp)
  6dc335:	movups %xmm0,0x240(%rsp)
  6dc33d:	movups 0x6e0(%rbp),%xmm0
  6dc344:	movups %xmm0,0x250(%rsp)
  6dc34c:	movsd  0x780(%rbp),%xmm0
  6dc354:	shufps $0xe1,%xmm0,%xmm0
  6dc358:	movlps %xmm0,0x260(%rsp)
  6dc360:	mov    %cl,0x268(%rsp)
  6dc367:	mov    %sil,0x269(%rsp)
  6dc36f:	test   %rax,%rax
  6dc372:	je     6dd04f <text_column_public_control::emit_state+0x13df>
  6dc378:	test   %sil,%sil
  6dc37b:	jne    6dd04f <text_column_public_control::emit_state+0x13df>
  6dc381:	mov    0x1a8(%rbp),%ecx
  6dc387:	mov    0x1b0(%rbp),%rax
  6dc38e:	mov    0x1b8(%rbp),%r8d
  6dc395:	mov    0x1bc(%rbp),%edi
  6dc39b:	mov    0x1c0(%rbp),%esi
  6dc3a1:	mov    0x1c4(%rbp),%edx
  6dc3a7:	mov    0x118(%rbp),%r9
  6dc3ae:	test   %r9,%r9
  6dc3b1:	je     6dc3c8 <text_column_public_control::emit_state+0x758>
  6dc3b3:	mov    0x10(%r9),%r9
  6dc3b7:	mov    %r9,0xd0(%rsp)
  6dc3bf:	test   %r9,%r9
  6dc3c2:	jne    6dcf71 <text_column_public_control::emit_state+0x1301>
  6dc3c8:	mov    %r11,0x1d8(%rsp)
  6dc3d0:	mov    %r10,0x1d0(%rsp)
  6dc3d8:	movabs $0xcbf29ce484222325,%rbx
  6dc3e2:	movabs $0x100000001b3,%r14
  6dc3ec:	mov    %eax,%r9d
  6dc3ef:	mov    %rcx,%r15
  6dc3f2:	xor    %rbx,%r15
  6dc3f5:	imul   %r14,%r15
  6dc3f9:	xor    %r9,%r15
  6dc3fc:	imul   %r14,%r15
  6dc400:	xor    %r8,%r15
  6dc403:	imul   %r14,%r15
  6dc407:	xor    %rdi,%r15
  6dc40a:	imul   %r14,%r15
  6dc40e:	xor    %rsi,%r15
  6dc411:	imul   %r14,%r15
  6dc415:	xor    %rdx,%r15
  6dc418:	imul   %r14,%r15
  6dc41c:	mov    0x80(%rbp),%rdx
  6dc423:	test   %rdx,%rdx
  6dc426:	je     6dcac6 <text_column_public_control::emit_state+0xe56>
  6dc42c:	movzwl %cx,%ecx
  6dc42f:	movd   %ecx,%xmm0
  6dc433:	pinsrw $0x2,%eax,%xmm0
  6dc438:	cvtdq2ps %xmm0,%xmm0
  6dc43b:	mov    0x78(%rbp),%r13
  6dc43f:	lea    0x0(%r13,%rdx,4),%rax
  6dc444:	mov    %rax,0x1e8(%rsp)
  6dc44c:	lea    0xb8(%rbp),%rax
  6dc453:	mov    %rax,0x1f0(%rsp)
  6dc45b:	xorps  %xmm1,%xmm1
  6dc45e:	movlhps %xmm0,%xmm1
  6dc461:	movaps %xmm1,0x280(%rsp)
  6dc469:	lea    0x347340(%rip),%rax        # a237b0 <__frame_dummy_init_array_entry+0x17c0>
  6dc470:	mov    %rax,0x48(%rsp)
  6dc475:	jmp    6dc4c1 <text_column_public_control::emit_state+0x851>
  6dc477:	nopw   0x0(%rax,%rax,1)
  6dc480:	xorps  %xmm1,%xmm1
  6dc483:	ucomiss %xmm1,%xmm0
  6dc486:	jne    6dc48e <text_column_public_control::emit_state+0x81e>
  6dc488:	jnp    6dca22 <text_column_public_control::emit_state+0xdb2>
  6dc48e:	imul   %r14,%rdi
  6dc492:	xor    $0x1,%rdi
  6dc496:	imul   %r14,%rdi
  6dc49a:	movd   %xmm0,%eax
  6dc49e:	xor    %rdi,%rax
  6dc4a1:	imul   %r14,%rax
  6dc4a5:	mov    %rax,%rdi
  6dc4a8:	imul   %r14,%rdi
  6dc4ac:	mov    %rdi,%r15
  6dc4af:	add    $0x4,%r13
  6dc4b3:	cmp    0x1e8(%rsp),%r13
  6dc4bb:	je     6dcac6 <text_column_public_control::emit_state+0xe56>
  6dc4c1:	movslq 0x0(%r13),%rdi
  6dc4c5:	movdqa 0x280(%rsp),%xmm0
  6dc4ce:	movdqu %xmm0,0x88(%rsp)
  6dc4d7:	test   %rdi,%rdi
  6dc4da:	js     6dc540 <text_column_public_control::emit_state+0x8d0>
  6dc4dc:	mov    0xf8(%rbp),%rsi
  6dc4e3:	cmp    %rdi,%rsi
  6dc4e6:	jbe    6dcfb5 <text_column_public_control::emit_state+0x1345>
  6dc4ec:	mov    0xb0(%rbp),%rsi
  6dc4f3:	mov    0xf0(%rbp),%r12
  6dc4fa:	shl    $0x5,%rdi
  6dc4fe:	mov    0x18(%r12,%rdi,1),%eax
  6dc503:	cmp    %rax,%rsi
  6dc506:	jbe    6dcfa9 <text_column_public_control::emit_state+0x1339>
  6dc50c:	add    %rdi,%r12
  6dc50f:	mov    0xa8(%rbp),%rcx
  6dc516:	shl    $0x5,%rax
  6dc51a:	mov    0x10(%rcx,%rax,1),%rdx
  6dc51f:	mov    %rdx,0x40(%rsp)
  6dc524:	movups (%rcx,%rax,1),%xmm0
  6dc528:	movaps %xmm0,0x30(%rsp)
  6dc52d:	lea    0x1c(%r12),%rax
  6dc532:	jmp    6dc583 <text_column_public_control::emit_state+0x913>
  6dc534:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6dc540:	and    $0x7fffffff,%edi
  6dc546:	mov    0x98(%rbp),%rsi
  6dc54d:	cmp    %rdi,%rsi
  6dc550:	jbe    6dcfe9 <text_column_public_control::emit_state+0x1379>
  6dc556:	mov    0x90(%rbp),%rax
  6dc55d:	imul   $0x38,%rdi,%rcx
  6dc561:	mov    0x10(%rax,%rcx,1),%rdx
  6dc566:	mov    %rdx,0x40(%rsp)
  6dc56b:	movups (%rax,%rcx,1),%xmm0
  6dc56f:	movaps %xmm0,0x30(%rsp)
  6dc574:	lea    (%rax,%rcx,1),%r12
  6dc578:	add    $0x18,%r12
  6dc57c:	add    %rcx,%rax
  6dc57f:	add    $0x30,%rax
  6dc583:	movslq (%rax),%rbp
  6dc586:	xor    %r8d,%r8d
  6dc589:	cmp    $0x40000000,%rbp
  6dc590:	setge  %r8b
  6dc594:	lea    0xd0(%rsp),%rdi
  6dc59c:	mov    0x1f0(%rsp),%rsi
  6dc5a4:	lea    0x30(%rsp),%rdx
  6dc5a9:	lea    0x88(%rsp),%rcx
  6dc5b1:	call   *0x366489(%rip)        # a42a40 <_DYNAMIC+0x4a8>
  6dc5b7:	mov    0xd0(%rsp),%eax
  6dc5be:	mov    %rax,0x60(%rsp)
  6dc5c3:	mov    0xd4(%rsp),%eax
  6dc5ca:	mov    %rax,0x50(%rsp)
  6dc5cf:	mov    0xd8(%rsp),%eax
  6dc5d6:	mov    %rax,0x190(%rsp)
  6dc5de:	mov    0xdc(%rsp),%eax
  6dc5e5:	mov    %rax,0x68(%rsp)
  6dc5ea:	mov    0xe0(%rsp),%rax
  6dc5f2:	mov    %rax,0x70(%rsp)
  6dc5f7:	mov    0xe8(%rsp),%r9
  6dc5ff:	mov    0xf0(%rsp),%rsi
  6dc607:	mov    0xf8(%rsp),%rdi
  6dc60f:	mov    0x100(%rsp),%r10
  6dc617:	mov    0x108(%rsp),%r8
  6dc61f:	movd   0x110(%rsp),%xmm0
  6dc628:	mov    0x114(%rsp),%eax
  6dc62f:	mov    0x118(%rsp),%ecx
  6dc636:	mov    0x11c(%rsp),%edx
  6dc63d:	mov    0x10(%r12),%r11
  6dc642:	cmp    $0xffffffff,%ebp
  6dc645:	mov    %rdi,0xc0(%rsp)
  6dc64d:	mov    %rsi,0x78(%rsp)
  6dc652:	mov    %r9,0xb8(%rsp)
  6dc65a:	je     6dc6a0 <text_column_public_control::emit_state+0xa30>
  6dc65c:	test   %ebp,%ebp
  6dc65e:	js     6dc6b0 <text_column_public_control::emit_state+0xa40>
  6dc660:	cmp    $0x40000000,%ebp
  6dc666:	jae    6dc6c2 <text_column_public_control::emit_state+0xa52>
  6dc668:	mov    0x80(%rsp),%rdi
  6dc670:	mov    0x110(%rdi),%rsi
  6dc677:	cmp    %rbp,%rsi
  6dc67a:	jbe    6dcfd1 <text_column_public_control::emit_state+0x1361>
  6dc680:	mov    0x108(%rdi),%rsi
  6dc687:	mov    (%rsi,%rbp,8),%rdi
  6dc68b:	add    $0x10,%rdi
  6dc68f:	mov    $0x2,%r9d
  6dc695:	jmp    6dc709 <text_column_public_control::emit_state+0xa99>
  6dc697:	nopw   0x0(%rax,%rax,1)
  6dc6a0:	xor    %r9d,%r9d
  6dc6a3:	jmp    6dc709 <text_column_public_control::emit_state+0xa99>
  6dc6a5:	data16 cs nopw 0x0(%rax,%rax,1)
  6dc6b0:	and    $0x7fffffff,%ebp
  6dc6b6:	movd   %ebp,%xmm1
  6dc6ba:	mov    $0x1,%r9d
  6dc6c0:	jmp    6dc709 <text_column_public_control::emit_state+0xa99>
  6dc6c2:	mov    0x80(%rsp),%rsi
  6dc6ca:	mov    0x118(%rsi),%r9
  6dc6d1:	test   %r9,%r9
  6dc6d4:	je     6dcf5f <text_column_public_control::emit_state+0x12ef>
  6dc6da:	mov    %ebp,%edi
  6dc6dc:	and    $0x1fffffff,%edi
  6dc6e2:	mov    0x10(%r9),%rsi
  6dc6e6:	cmp    %rdi,%rsi
  6dc6e9:	jbe    6dcfdd <text_column_public_control::emit_state+0x136d>
  6dc6ef:	shl    $0x3,%edi
  6dc6f2:	add    0x8(%r9),%rdi
  6dc6f6:	and    $0x20000000,%ebp
  6dc6fc:	cmp    $0x1,%ebp
  6dc6ff:	mov    $0x0,%r9d
  6dc705:	adc    $0x3,%r9d
  6dc709:	mov    $0x3f800000,%ebp
  6dc70e:	mov    $0x3f800000,%esi
  6dc713:	mov    %rsi,0x8(%rsp)
  6dc718:	mov    %rsi,0x20(%rsp)
  6dc71d:	cmp    $0x2,%r9d
  6dc721:	ja     6dc734 <text_column_public_control::emit_state+0xac4>
  6dc723:	movd   %xmm0,%esi
  6dc727:	mov    %rdx,%rbp
  6dc72a:	mov    %rcx,0x8(%rsp)
  6dc72f:	mov    %rax,0x20(%rsp)
  6dc734:	mov    %rbp,0x1b0(%rsp)
  6dc73c:	mov    %r11,%rax
  6dc73f:	shr    $0x20,%rax
  6dc743:	movzwl %ax,%ebp
  6dc746:	movzwl %r11w,%edx
  6dc74a:	mov    %r9d,%eax
  6dc74d:	lea    -0x69abec(%rip),%rcx        # 41b68 <GCC_except_table0+0x1d20>
  6dc754:	movslq (%rcx,%rax,4),%rax
  6dc758:	add    %rcx,%rax
  6dc75b:	jmp    *%rax
  6dc75d:	mov    (%rdi),%rax
  6dc760:	mov    $0x1,%ecx
  6dc765:	cmpb   $0x0,0x10(%rax)
  6dc769:	jne    6dc772 <text_column_public_control::emit_state+0xb02>
  6dc76b:	movzwl 0x11(%rax),%ecx
  6dc76f:	shl    $0x8,%ecx
  6dc772:	mov    %rcx,0x58(%rsp)
  6dc777:	mov    0x30(%rax),%ecx
  6dc77a:	mov    %rcx,0x18(%rsp)
  6dc77f:	mov    0x34(%rax),%ecx
  6dc782:	mov    %rcx,0x10(%rsp)
  6dc787:	mov    0x18(%rax),%rax
  6dc78b:	mov    %rax,0xa0(%rsp)
  6dc793:	mov    $0x3,%cl
  6dc795:	xor    %edi,%edi
  6dc797:	xor    %r9d,%r9d
  6dc79a:	jmp    6dc7f9 <text_column_public_control::emit_state+0xb89>
  6dc79c:	mov    0x28(%rdi),%rcx
  6dc7a0:	mov    0x30(%rdi),%rax
  6dc7a4:	mov    %rax,0x1e0(%rsp)
  6dc7ac:	mov    0x8(%rdi),%rax
  6dc7b0:	mov    %rax,0x58(%rsp)
  6dc7b5:	mov    0x10(%rdi),%rax
  6dc7b9:	mov    %rax,0xa0(%rsp)
  6dc7c1:	mov    %rcx,0x18(%rsp)
  6dc7c6:	shr    $0x20,%rcx
  6dc7ca:	mov    %rcx,0x10(%rsp)
  6dc7cf:	mov    $0x2,%cl
  6dc7d1:	mov    $0x1,%r9b
  6dc7d4:	xor    %edi,%edi
  6dc7d6:	jmp    6dc7f9 <text_column_public_control::emit_state+0xb89>
  6dc7d8:	mov    $0x1,%edi
  6dc7dd:	xor    %r9d,%r9d
  6dc7e0:	xor    %ecx,%ecx
  6dc7e2:	jmp    6dc7ef <text_column_public_control::emit_state+0xb7f>
  6dc7e4:	mov    $0x1,%cl
  6dc7e6:	xor    %edi,%edi
  6dc7e8:	movdqa %xmm1,%xmm0
  6dc7ec:	xor    %r9d,%r9d
  6dc7ef:	mov    %rax,0x18(%rsp)
  6dc7f4:	mov    %rax,0x10(%rsp)
  6dc7f9:	mov    %r13,0x1c0(%rsp)
  6dc801:	sub    %rdx,%rbp
  6dc804:	mov    %rcx,0xb0(%rsp)
  6dc80c:	mov    %r9,0xa8(%rsp)
  6dc814:	mov    %r10,%r13
  6dc817:	mov    %r8,%rcx
  6dc81a:	js     6dc830 <text_column_public_control::emit_state+0xbc0>
  6dc81c:	xorps  %xmm1,%xmm1
  6dc81f:	cvtsi2ss %ebp,%xmm1
  6dc823:	jmp    6dc848 <text_column_public_control::emit_state+0xbd8>
  6dc825:	data16 cs nopw 0x0(%rax,%rax,1)
  6dc830:	mov    %rbp,%rax
  6dc833:	shr    $1,%rax
  6dc836:	and    $0x1,%ebp
  6dc839:	or     %rax,%rbp
  6dc83c:	xorps  %xmm1,%xmm1
  6dc83f:	cvtsi2ss %rbp,%xmm1
  6dc844:	addss  %xmm1,%xmm1
  6dc848:	mov    %r11d,%r8d
  6dc84b:	shr    $0x10,%r8d
  6dc84f:	mov    (%r12),%r10d
  6dc853:	mov    0x4(%r12),%eax
  6dc858:	mov    0x8(%r12),%ebp
  6dc85d:	mov    0xc(%r12),%r9d
  6dc862:	shr    $0x30,%r11
  6dc866:	cvtsi2ss %edx,%xmm4
  6dc86a:	cvtsi2ss %r8d,%xmm2
  6dc86f:	sub    %r8,%r11
  6dc872:	js     6dc880 <text_column_public_control::emit_state+0xc10>
  6dc874:	cvtsi2ss %r11d,%xmm3
  6dc879:	jmp    6dc896 <text_column_public_control::emit_state+0xc26>
  6dc87b:	nopl   0x0(%rax,%rax,1)
  6dc880:	mov    %r11,%rdx
  6dc883:	shr    $1,%rdx
  6dc886:	and    $0x1,%r11d
  6dc88a:	or     %rdx,%r11
  6dc88d:	cvtsi2ss %r11,%xmm3
  6dc892:	addss  %xmm3,%xmm3
  6dc896:	mov    0x70(%rsp),%r11
  6dc89b:	mov    0x68(%rsp),%r12
  6dc8a0:	xor    %r10,%r15
  6dc8a3:	imul   %r14,%r15
  6dc8a7:	xor    %rax,%r15
  6dc8aa:	imul   %r14,%r15
  6dc8ae:	xor    %rbp,%r15
  6dc8b1:	imul   %r14,%r15
  6dc8b5:	xor    %r9,%r15
  6dc8b8:	imul   %r14,%r15
  6dc8bc:	movd   %xmm4,%eax
  6dc8c0:	xor    %r15,%rax
  6dc8c3:	imul   %r14,%rax
  6dc8c7:	movd   %xmm2,%edx
  6dc8cb:	xor    %rax,%rdx
  6dc8ce:	imul   %r14,%rdx
  6dc8d2:	movd   %xmm1,%r8d
  6dc8d7:	xor    %rdx,%r8
  6dc8da:	imul   %r14,%r8
  6dc8de:	movd   %xmm3,%eax
  6dc8e2:	xor    %r8,%rax
  6dc8e5:	imul   %r14,%rax
  6dc8e9:	xor    0x60(%rsp),%rax
  6dc8ee:	imul   %r14,%rax
  6dc8f2:	xor    0x50(%rsp),%rax
  6dc8f7:	imul   %r14,%rax
  6dc8fb:	xor    0x190(%rsp),%rax
  6dc903:	imul   %r14,%rax
  6dc907:	xor    %r12,%rax
  6dc90a:	imul   %r14,%rax
  6dc90e:	xor    %r11,%rax
  6dc911:	imul   %r14,%rax
  6dc915:	xor    0xb8(%rsp),%rax
  6dc91d:	imul   %r14,%rax
  6dc921:	xor    0x78(%rsp),%rax
  6dc926:	imul   %r14,%rax
  6dc92a:	xor    0xc0(%rsp),%rax
  6dc932:	imul   %r14,%rax
  6dc936:	xor    %r13,%rax
  6dc939:	imul   %r14,%rax
  6dc93d:	xor    %rcx,%rax
  6dc940:	imul   %r14,%rax
  6dc944:	xor    %rax,%rsi
  6dc947:	imul   %r14,%rsi
  6dc94b:	xor    0x20(%rsp),%rsi
  6dc950:	imul   %r14,%rsi
  6dc954:	xor    0x8(%rsp),%rsi
  6dc959:	imul   %r14,%rsi
  6dc95d:	xor    0x1b0(%rsp),%rsi
  6dc965:	imul   %r14,%rsi
  6dc969:	xor    %rsi,%rdi
  6dc96c:	mov    0xb0(%rsp),%rax
  6dc974:	cmp    $0x1,%al
  6dc976:	mov    0x80(%rsp),%rbp
  6dc97e:	mov    0x1c0(%rsp),%r13
  6dc986:	je     6dc48e <text_column_public_control::emit_state+0x81e>
  6dc98c:	movzbl %al,%eax
  6dc98f:	cmp    $0x3,%eax
  6dc992:	je     6dc480 <text_column_public_control::emit_state+0x810>
  6dc998:	movabs $0x366000002e329,%rax
  6dc9a2:	imul   %rax,%rdi
  6dc9a6:	cmpb   $0x0,0xa8(%rsp)
  6dc9ae:	je     6dc4a8 <text_column_public_control::emit_state+0x838>
  6dc9b4:	mov    0x10(%rsp),%rcx
  6dc9b9:	shl    $0x20,%rcx
  6dc9bd:	mov    0x18(%rsp),%eax
  6dc9c1:	or     %rcx,%rax
  6dc9c4:	xor    %rdi,%rax
  6dc9c7:	imul   %r14,%rax
  6dc9cb:	xor    0x1e0(%rsp),%rax
  6dc9d3:	imul   %r14,%rax
  6dc9d7:	mov    0xa0(%rsp),%rdi
  6dc9df:	test   %rdi,%rdi
  6dc9e2:	je     6dca35 <text_column_public_control::emit_state+0xdc5>
  6dc9e4:	mov    %rdi,%rdx
  6dc9e7:	and    $0x7,%rdx
  6dc9eb:	je     6dca3d <text_column_public_control::emit_state+0xdcd>
  6dc9ed:	mov    0x58(%rsp),%rsi
  6dc9f2:	mov    %rsi,%rcx
  6dc9f5:	data16 cs nopw 0x0(%rax,%rax,1)
  6dca00:	movzbl (%rcx),%r15d
  6dca04:	inc    %rcx
  6dca07:	xor    %rax,%r15
  6dca0a:	imul   %r14,%r15
  6dca0e:	mov    %r15,%rax
  6dca11:	dec    %rdx
  6dca14:	jne    6dca00 <text_column_public_control::emit_state+0xd90>
  6dca16:	cmp    $0x8,%rdi
  6dca1a:	jb     6dc4af <text_column_public_control::emit_state+0x83f>
  6dca20:	jmp    6dca52 <text_column_public_control::emit_state+0xde2>
  6dca22:	movabs $0x366000002e329,%rax
  6dca2c:	imul   %rax,%rdi
  6dca30:	jmp    6dc4a8 <text_column_public_control::emit_state+0x838>
  6dca35:	mov    %rax,%r15
  6dca38:	jmp    6dc4af <text_column_public_control::emit_state+0x83f>
  6dca3d:	mov    %rax,%r15
  6dca40:	mov    0x58(%rsp),%rsi
  6dca45:	mov    %rsi,%rcx
  6dca48:	cmp    $0x8,%rdi
  6dca4c:	jb     6dc4af <text_column_public_control::emit_state+0x83f>
  6dca52:	add    %rdi,%rsi
  6dca55:	data16 cs nopw 0x0(%rax,%rax,1)
  6dca60:	movzbl (%rcx),%eax
  6dca63:	xor    %r15,%rax
  6dca66:	imul   %r14,%rax
  6dca6a:	movzbl 0x1(%rcx),%edx
  6dca6e:	xor    %rax,%rdx
  6dca71:	imul   %r14,%rdx
  6dca75:	movzbl 0x2(%rcx),%eax
  6dca79:	xor    %rdx,%rax
  6dca7c:	imul   %r14,%rax
  6dca80:	movzbl 0x3(%rcx),%edx
  6dca84:	xor    %rax,%rdx
  6dca87:	imul   %r14,%rdx
  6dca8b:	movzbl 0x4(%rcx),%eax
  6dca8f:	xor    %rdx,%rax
  6dca92:	imul   %r14,%rax
  6dca96:	movzbl 0x5(%rcx),%edx
  6dca9a:	xor    %rax,%rdx
  6dca9d:	imul   %r14,%rdx
  6dcaa1:	movzbl 0x6(%rcx),%eax
  6dcaa5:	xor    %rdx,%rax
  6dcaa8:	imul   %r14,%rax
  6dcaac:	movzbl 0x7(%rcx),%r15d
  6dcab1:	add    $0x8,%rcx
  6dcab5:	xor    %rax,%r15
  6dcab8:	imul   %r14,%r15
  6dcabc:	cmp    %rsi,%rcx
  6dcabf:	jne    6dca60 <text_column_public_control::emit_state+0xdf0>
  6dcac1:	jmp    6dc4af <text_column_public_control::emit_state+0x83f>
  6dcac6:	mov    %r15,0x210(%rsp)
  6dcace:	mov    %rbx,0x28(%rsp)
  6dcad3:	mov    0x238(%rsp),%rax
  6dcadb:	test   %rax,%rax
  6dcade:	je     6dcc0c <text_column_public_control::emit_state+0xf9c>
  6dcae4:	mov    0x230(%rsp),%rsi
  6dcaec:	mov    %rax,%rcx
  6dcaef:	shl    $0x7,%rcx
  6dcaf3:	lea    (%rcx,%rax,8),%rcx
  6dcaf7:	add    $0xffffffffffffff78,%rcx
  6dcafe:	movabs $0xf0f0f0f0f0f0f0f1,%rdx
  6dcb08:	mov    %rcx,%rax
  6dcb0b:	mul    %rdx
  6dcb0e:	shr    $0x7,%rdx
  6dcb12:	inc    %rdx
  6dcb15:	mov    %edx,%eax
  6dcb17:	and    $0x3,%eax
  6dcb1a:	cmp    $0x198,%rcx
  6dcb21:	jb     6dcbd4 <text_column_public_control::emit_state+0xf64>
  6dcb27:	and    $0xfffffffffffffffc,%rdx
  6dcb2b:	jmp    6dcb4d <text_column_public_control::emit_state+0xedd>
  6dcb2d:	nopl   (%rax)
  6dcb30:	add    $0x220,%rsi
  6dcb37:	xor    %rcx,%rbx
  6dcb3a:	imul   %r14,%rbx
  6dcb3e:	mov    %rbx,0x28(%rsp)
  6dcb43:	add    $0xfffffffffffffffc,%rdx
  6dcb47:	je     6dcbcf <text_column_public_control::emit_state+0xf5f>
  6dcb4d:	cmpb   $0x0,(%rsi)
  6dcb50:	mov    $0xffffffffffffffff,%rcx
  6dcb57:	mov    $0xffffffffffffffff,%rdi
  6dcb5e:	je     6dcb64 <text_column_public_control::emit_state+0xef4>
  6dcb60:	mov    0x8(%rsi),%rdi
  6dcb64:	xor    %rdi,%rbx
  6dcb67:	imul   %r14,%rbx
  6dcb6b:	mov    %rbx,0x28(%rsp)
  6dcb70:	cmpb   $0x0,0x88(%rsi)
  6dcb77:	mov    $0xffffffffffffffff,%rdi
  6dcb7e:	je     6dcb87 <text_column_public_control::emit_state+0xf17>
  6dcb80:	mov    0x90(%rsi),%rdi
  6dcb87:	xor    %rdi,%rbx
  6dcb8a:	imul   %r14,%rbx
  6dcb8e:	mov    %rbx,0x28(%rsp)
  6dcb93:	cmpb   $0x0,0x110(%rsi)
  6dcb9a:	mov    $0xffffffffffffffff,%rdi
  6dcba1:	je     6dcbaa <text_column_public_control::emit_state+0xf3a>
  6dcba3:	mov    0x118(%rsi),%rdi
  6dcbaa:	xor    %rdi,%rbx
  6dcbad:	imul   %r14,%rbx
  6dcbb1:	mov    %rbx,0x28(%rsp)
  6dcbb6:	cmpb   $0x0,0x198(%rsi)
  6dcbbd:	je     6dcb30 <text_column_public_control::emit_state+0xec0>
  6dcbc3:	mov    0x1a0(%rsi),%rcx
  6dcbca:	jmp    6dcb30 <text_column_public_control::emit_state+0xec0>
  6dcbcf:	test   %rax,%rax
  6dcbd2:	je     6dcc0c <text_column_public_control::emit_state+0xf9c>
  6dcbd4:	mov    %eax,%ecx
  6dcbd6:	shl    $0x7,%eax
  6dcbd9:	lea    (%rax,%rcx,8),%eax
  6dcbdc:	xor    %ecx,%ecx
  6dcbde:	jmp    6dcbf8 <text_column_public_control::emit_state+0xf88>
  6dcbe0:	xor    %rdx,%rbx
  6dcbe3:	imul   %r14,%rbx
  6dcbe7:	mov    %rbx,0x28(%rsp)
  6dcbec:	add    $0x88,%rcx
  6dcbf3:	cmp    %rcx,%rax
  6dcbf6:	je     6dcc0c <text_column_public_control::emit_state+0xf9c>
  6dcbf8:	cmpb   $0x0,(%rsi,%rcx,1)
  6dcbfc:	mov    $0xffffffffffffffff,%rdx
  6dcc03:	je     6dcbe0 <text_column_public_control::emit_state+0xf70>
  6dcc05:	mov    0x8(%rsi,%rcx,1),%rdx
  6dcc0a:	jmp    6dcbe0 <text_column_public_control::emit_state+0xf70>
  6dcc0c:	movzbl 0xc8(%rsp),%eax
  6dcc14:	shl    $0x3,%eax
  6dcc17:	lea    0x347cfa(%rip),%rcx        # a24918 <__frame_dummy_init_array_entry+0x2928>
  6dcc1e:	mov    (%rax,%rcx,1),%rcx
  6dcc22:	lea    -0x68bf21(%rip),%rdx        # 50d08 <GCC_except_table0+0x10ec0>
  6dcc29:	mov    (%rax,%rdx,1),%rax
  6dcc2d:	mov    %rcx,0x1a0(%rsp)
  6dcc35:	mov    %rax,0x1a8(%rsp)
  6dcc3d:	lea    -0x68f6ae(%rip),%rax        # 4d596 <GCC_except_table0+0xd74e>
  6dcc44:	lea    -0x68f6bb(%rip),%rcx        # 4d590 <GCC_except_table0+0xd748>
  6dcc4b:	mov    0xcc(%rsp),%edx
  6dcc52:	test   %dl,%dl
  6dcc54:	cmovne %rax,%rcx
  6dcc58:	movzbl %dl,%eax
  6dcc5b:	mov    $0x6,%edx
  6dcc60:	sub    %rax,%rdx
  6dcc63:	mov    %rcx,0x88(%rsp)
  6dcc6b:	mov    %rdx,0x90(%rsp)
  6dcc73:	call   *0x365b8f(%rip)        # a42808 <_DYNAMIC+0x270>
  6dcc79:	mov    $0x4,%edi
  6dcc7e:	mov    $0x1,%esi
  6dcc83:	call   *0x365b87(%rip)        # a42810 <_DYNAMIC+0x278>
  6dcc89:	test   %rax,%rax
  6dcc8c:	je     6dd092 <text_column_public_control::emit_state+0x1422>
  6dcc92:	mov    %rax,%rbx
  6dcc95:	movl   $0x6c6c756e,(%rax)
  6dcc9b:	cmpq   $0x0,0x1d8(%rsp)
  6dcca4:	je     6dccdd <text_column_public_control::emit_state+0x106d>
  6dcca6:	lea    0xd0(%rsp),%rsi
  6dccae:	mov    $0x14,%edx
  6dccb3:	mov    0x1d0(%rsp),%rdi
  6dccbb:	call   *0x365d87(%rip)        # a42a48 <_DYNAMIC+0x4b0>
  6dccc1:	mov    %rdx,%r14
  6dccc4:	test   %rdx,%rdx
  6dccc7:	jns    6dccf6 <text_column_public_control::emit_state+0x1086>
  6dccc9:	xor    %r13d,%r13d
  6dcccc:	mov    %r13,%rdi
  6dcccf:	mov    %r14,%rsi
  6dccd2:	call   *0x365bb8(%rip)        # a42890 <_DYNAMIC+0x2f8>
  6dccd8:	jmp    6dd0a2 <text_column_public_control::emit_state+0x1432>
  6dccdd:	movq   $0x4,0x30(%rsp)
  6dcce6:	mov    %rbx,0x38(%rsp)
  6dcceb:	movq   $0x4,0x40(%rsp)
  6dccf4:	jmp    6dcd59 <text_column_public_control::emit_state+0x10e9>
  6dccf6:	test   %r14,%r14
  6dccf9:	je     6dcd31 <text_column_public_control::emit_state+0x10c1>
  6dccfb:	mov    %rax,%r12
  6dccfe:	call   *0x365b04(%rip)        # a42808 <_DYNAMIC+0x270>
  6dcd04:	mov    $0x1,%r13d
  6dcd0a:	mov    $0x1,%esi
  6dcd0f:	mov    %r14,%rdi
  6dcd12:	call   *0x365af8(%rip)        # a42810 <_DYNAMIC+0x278>
  6dcd18:	test   %rax,%rax
  6dcd1b:	je     6dcccc <text_column_public_control::emit_state+0x105c>
  6dcd1d:	mov    %rax,%r15
  6dcd20:	mov    %rax,%rdi
  6dcd23:	mov    %r12,%rsi
  6dcd26:	mov    %r14,%rdx
  6dcd29:	call   *0x365af1(%rip)        # a42820 <memcpy@GLIBC_2.14>
  6dcd2f:	jmp    6dcd37 <text_column_public_control::emit_state+0x10c7>
  6dcd31:	mov    $0x1,%r15d
  6dcd37:	mov    %r14,0x30(%rsp)
  6dcd3c:	mov    %r15,0x38(%rsp)
  6dcd41:	mov    %r14,0x40(%rsp)
  6dcd46:	mov    $0x4,%esi
  6dcd4b:	mov    $0x1,%edx
  6dcd50:	mov    %rbx,%rdi
  6dcd53:	call   *0x365aa7(%rip)        # a42800 <_DYNAMIC+0x268>
  6dcd59:	lea    0x240(%rsp),%rdx
  6dcd61:	lea    0x248(%rsp),%rcx
  6dcd69:	lea    0x268(%rsp),%rax
  6dcd71:	lea    0x1a0(%rsp),%rsi
  6dcd79:	mov    %rsi,0xd0(%rsp)
  6dcd81:	lea    0x4a228(%rip),%rsi        # 726fb0 <<&str as core::fmt::Display>::fmt>
  6dcd88:	mov    %rsi,0xd8(%rsp)
  6dcd90:	lea    0x88(%rsp),%rdi
  6dcd98:	mov    %rdi,0xe0(%rsp)
  6dcda0:	mov    %rsi,0xe8(%rsp)
  6dcda8:	lea    0x270(%rsp),%rdi
  6dcdb0:	mov    %rdi,0xf0(%rsp)
  6dcdb8:	mov    %rsi,0xf8(%rsp)
  6dcdc0:	lea    0x1f8(%rsp),%rsi
  6dcdc8:	mov    %rsi,0x100(%rsp)
  6dcdd0:	mov    0x365c79(%rip),%rsi        # a42a50 <_DYNAMIC+0x4b8>
  6dcdd7:	mov    %rsi,0x108(%rsp)
  6dcddf:	lea    0x200(%rsp),%rdi
  6dcde7:	mov    %rdi,0x110(%rsp)
  6dcdef:	mov    %rsi,0x118(%rsp)
  6dcdf7:	lea    0x208(%rsp),%rsi
  6dcdff:	mov    %rsi,0x120(%rsp)
  6dce07:	mov    0x365c4a(%rip),%rsi        # a42a58 <_DYNAMIC+0x4c0>
  6dce0e:	mov    %rsi,0x128(%rsp)
  6dce16:	lea    0x28(%rsp),%rdi
  6dce1b:	mov    %rdi,0x130(%rsp)
  6dce23:	mov    %rsi,0x138(%rsp)
  6dce2b:	lea    0x210(%rsp),%rdi
  6dce33:	mov    %rdi,0x140(%rsp)
  6dce3b:	mov    %rsi,0x148(%rsp)
  6dce43:	mov    %rdx,0x150(%rsp)
  6dce4b:	mov    %rsi,0x158(%rsp)
  6dce53:	mov    %rcx,0x160(%rsp)
  6dce5b:	mov    %rsi,0x168(%rsp)
  6dce63:	lea    0x30(%rsp),%rcx
  6dce68:	mov    %rcx,0x170(%rsp)
  6dce70:	lea    0x4c709(%rip),%rcx        # 729580 <<alloc::string::String as core::fmt::Display>::fmt>
  6dce77:	mov    %rcx,0x178(%rsp)
  6dce7f:	mov    %rax,0x180(%rsp)
  6dce87:	mov    0x365bd2(%rip),%rax        # a42a60 <_DYNAMIC+0x4c8>
  6dce8e:	mov    %rax,0x188(%rsp)
  6dce96:	lea    -0x6992be(%rip),%rdi        # 43bdf <GCC_except_table0+0x3d97>
  6dce9d:	lea    0xd0(%rsp),%rsi
  6dcea5:	call   *0x365bbd(%rip)        # a42a68 <_DYNAMIC+0x4d0>
  6dceab:	mov    0x30(%rsp),%rsi
  6dceb0:	test   %rsi,%rsi
  6dceb3:	je     6dcec5 <text_column_public_control::emit_state+0x1255>
  6dceb5:	mov    0x38(%rsp),%rdi
  6dceba:	mov    $0x1,%edx
  6dcebf:	call   *0x36593b(%rip)        # a42800 <_DYNAMIC+0x268>
  6dcec5:	mov    0x230(%rsp),%rbx
  6dcecd:	mov    0x238(%rsp),%r14
  6dced5:	test   %r14,%r14
  6dced8:	je     6dcf27 <text_column_public_control::emit_state+0x12b7>
  6dceda:	lea    0x30(%rbx),%r15
  6dcede:	mov    0x36591b(%rip),%r12        # a42800 <_DYNAMIC+0x268>
  6dcee5:	jmp    6dcefc <text_column_public_control::emit_state+0x128c>
  6dcee7:	nopw   0x0(%rax,%rax,1)
  6dcef0:	add    $0x88,%r15
  6dcef7:	dec    %r14
  6dcefa:	je     6dcf27 <text_column_public_control::emit_state+0x12b7>
  6dcefc:	mov    -0x20(%r15),%rsi
  6dcf00:	test   %rsi,%rsi
  6dcf03:	je     6dcf11 <text_column_public_control::emit_state+0x12a1>
  6dcf05:	mov    -0x18(%r15),%rdi
  6dcf09:	mov    $0x1,%edx
  6dcf0e:	call   *%r12
  6dcf11:	mov    -0x8(%r15),%rsi
  6dcf15:	test   %rsi,%rsi
  6dcf18:	jle    6dcef0 <text_column_public_control::emit_state+0x1280>
  6dcf1a:	mov    (%r15),%rdi
  6dcf1d:	mov    $0x1,%edx
  6dcf22:	call   *%r12
  6dcf25:	jmp    6dcef0 <text_column_public_control::emit_state+0x1280>
  6dcf27:	mov    0x228(%rsp),%rax
  6dcf2f:	test   %rax,%rax
  6dcf32:	je     6dcf4d <text_column_public_control::emit_state+0x12dd>
  6dcf34:	mov    %rax,%rcx
  6dcf37:	shl    $0x7,%rcx
  6dcf3b:	lea    (%rcx,%rax,8),%rsi
  6dcf3f:	mov    $0x8,%edx
  6dcf44:	mov    %rbx,%rdi
  6dcf47:	call   *0x3658b3(%rip)        # a42800 <_DYNAMIC+0x268>
  6dcf4d:	add    $0x298,%rsp
  6dcf54:	pop    %rbx
  6dcf55:	pop    %r12
  6dcf57:	pop    %r13
  6dcf59:	pop    %r14
  6dcf5b:	pop    %r15
  6dcf5d:	pop    %rbp
  6dcf5e:	ret
  6dcf5f:	lea    0x3467ea(%rip),%rdi        # a23750 <__frame_dummy_init_array_entry+0x1760>
  6dcf66:	call   *0x365934(%rip)        # a428a0 <_DYNAMIC+0x308>
  6dcf6c:	jmp    6dd0a2 <text_column_public_control::emit_state+0x1432>
  6dcf71:	lea    -0x69b6e8(%rip),%rdx        # 41890 <GCC_except_table0+0x1a48>
  6dcf78:	lea    0x3456e1(%rip),%r9        # a22660 <__frame_dummy_init_array_entry+0x670>
  6dcf7f:	lea    0xd0(%rsp),%rsi
  6dcf87:	xor    %edi,%edi
  6dcf89:	xor    %ecx,%ecx
  6dcf8b:	call   *0x365adf(%rip)        # a42a70 <_DYNAMIC+0x4d8>
  6dcf91:	jmp    6dd0a2 <text_column_public_control::emit_state+0x1432>
  6dcf96:	mov    %r14,%rdi
  6dcf99:	mov    0x10(%rsp),%rdx
  6dcf9e:	call   *0x36588c(%rip)        # a42830 <_DYNAMIC+0x298>
  6dcfa4:	jmp    6dd0a2 <text_column_public_control::emit_state+0x1432>
  6dcfa9:	mov    %rax,%rdi
  6dcfac:	lea    0x3467e5(%rip),%rax        # a23798 <__frame_dummy_init_array_entry+0x17a8>
  6dcfb3:	jmp    6dcfe4 <text_column_public_control::emit_state+0x1374>
  6dcfb5:	lea    0x3467c4(%rip),%rax        # a23780 <__frame_dummy_init_array_entry+0x1790>
  6dcfbc:	jmp    6dcfe4 <text_column_public_control::emit_state+0x1374>
  6dcfbe:	mov    $0x1,%edi
  6dcfc3:	mov    %r12,%rsi
  6dcfc6:	call   *0x3658c4(%rip)        # a42890 <_DYNAMIC+0x2f8>
  6dcfcc:	jmp    6dd0a2 <text_column_public_control::emit_state+0x1432>
  6dcfd1:	mov    %rbp,%rdi
  6dcfd4:	lea    0x34675d(%rip),%rax        # a23738 <__frame_dummy_init_array_entry+0x1748>
  6dcfdb:	jmp    6dcfe4 <text_column_public_control::emit_state+0x1374>
  6dcfdd:	lea    0x346784(%rip),%rax        # a23768 <__frame_dummy_init_array_entry+0x1778>
  6dcfe4:	mov    %rax,0x48(%rsp)
  6dcfe9:	mov    0x48(%rsp),%rdx
  6dcfee:	call   *0x36583c(%rip)        # a42830 <_DYNAMIC+0x298>
  6dcff4:	jmp    6dd0a2 <text_column_public_control::emit_state+0x1432>
  6dcff9:	movq   $0xd,0xd0(%rsp)
  6dd005:	movq   $0x0,0xd8(%rsp)
  6dd011:	lea    -0x68f841(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6dd018:	lea    0x346209(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6dd01f:	lea    0x345aea(%rip),%r8        # a22b10 <__frame_dummy_init_array_entry+0xb20>
  6dd026:	lea    0xd0(%rsp),%rdx
  6dd02e:	mov    $0x2b,%esi
  6dd033:	call   *0x36579f(%rip)        # a427d8 <_DYNAMIC+0x240>
  6dd039:	jmp    6dd0a2 <text_column_public_control::emit_state+0x1432>
  6dd03b:	mov    %rcx,%rdi
  6dd03e:	lea    0x346b23(%rip),%rax        # a23b68 <__frame_dummy_init_array_entry+0x1b78>
  6dd045:	mov    %rax,0x10(%rsp)
  6dd04a:	jmp    6dcf99 <text_column_public_control::emit_state+0x1329>
  6dd04f:	test   %sil,%sil
  6dd052:	mov    $0xe,%eax
  6dd057:	mov    $0x14,%ecx
  6dd05c:	cmovne %rax,%rcx
  6dd060:	mov    %rcx,0xd0(%rsp)
  6dd068:	lea    -0x68f898(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6dd06f:	lea    0x3461b2(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6dd076:	lea    0x345aab(%rip),%r8        # a22b28 <__frame_dummy_init_array_entry+0xb38>
  6dd07d:	lea    0xd0(%rsp),%rdx
  6dd085:	mov    $0x2b,%esi
  6dd08a:	call   *0x365748(%rip)        # a427d8 <_DYNAMIC+0x240>
  6dd090:	jmp    6dd0a2 <text_column_public_control::emit_state+0x1432>
  6dd092:	mov    $0x1,%edi
  6dd097:	mov    $0x4,%esi
  6dd09c:	call   *0x3657ee(%rip)        # a42890 <_DYNAMIC+0x2f8>
  6dd0a2:	ud2
  6dd0a4:	mov    %rax,%r15
  6dd0a7:	mov    0x30(%rsp),%rsi
  6dd0ac:	test   %rsi,%rsi
  6dd0af:	je     6dd1d8 <text_column_public_control::emit_state+0x1568>
  6dd0b5:	mov    0x38(%rsp),%rdi
  6dd0ba:	mov    $0x1,%edx
  6dd0bf:	call   *0x36573b(%rip)        # a42800 <_DYNAMIC+0x268>
  6dd0c5:	lea    0x218(%rsp),%rdi
  6dd0cd:	call   6c55a0 <core::ptr::drop_glue::<gpui::runtime::Snapshot>>
  6dd0d2:	mov    %r15,%rdi
  6dd0d5:	call   a20c40 <_Unwind_Resume@plt>
  6dd0da:	mov    %rax,%r15
  6dd0dd:	lea    0xd0(%rsp),%rdi
  6dd0e5:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6dd0ea:	lea    0x218(%rsp),%rdi
  6dd0f2:	call   6c55a0 <core::ptr::drop_glue::<gpui::runtime::Snapshot>>
  6dd0f7:	mov    %r15,%rdi
  6dd0fa:	call   a20c40 <_Unwind_Resume@plt>
  6dd0ff:	mov    %rax,%r15
  6dd102:	lea    0xd0(%rsp),%rdi
  6dd10a:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6dd10f:	mov    %r15,%rdi
  6dd112:	call   a20c40 <_Unwind_Resume@plt>
  6dd117:	mov    %rax,%r15
  6dd11a:	jmp    6dd160 <text_column_public_control::emit_state+0x14f0>
  6dd11c:	mov    %rax,%r15
  6dd11f:	lea    0xd0(%rsp),%rdi
  6dd127:	call   6c5510 <core::ptr::drop_glue::<gpui::runtime::SnapshotNode>>
  6dd12c:	lea    0x88(%rsp),%rdi
  6dd134:	call   6c1290 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::SnapshotNode>>>
  6dd139:	mov    %r15,%rdi
  6dd13c:	call   a20c40 <_Unwind_Resume@plt>
  6dd141:	jmp    6dd1aa <text_column_public_control::emit_state+0x153a>
  6dd143:	jmp    6dd192 <text_column_public_control::emit_state+0x1522>
  6dd145:	mov    %rax,%r15
  6dd148:	test   %r12,%r12
  6dd14b:	jle    6dd160 <text_column_public_control::emit_state+0x14f0>
  6dd14d:	mov    $0x1,%edx
  6dd152:	mov    0x50(%rsp),%rdi
  6dd157:	mov    %r12,%rsi
  6dd15a:	call   *0x3656a0(%rip)        # a42800 <_DYNAMIC+0x268>
  6dd160:	cmpq   $0x0,0x20(%rsp)
  6dd166:	je     6dd195 <text_column_public_control::emit_state+0x1525>
  6dd168:	mov    $0x1,%edx
  6dd16d:	mov    0x78(%rsp),%rdi
  6dd172:	mov    0x20(%rsp),%rsi
  6dd177:	call   *0x365683(%rip)        # a42800 <_DYNAMIC+0x268>
  6dd17d:	lea    0x88(%rsp),%rdi
  6dd185:	call   6c1290 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::SnapshotNode>>>
  6dd18a:	mov    %r15,%rdi
  6dd18d:	call   a20c40 <_Unwind_Resume@plt>
  6dd192:	mov    %rax,%r15
  6dd195:	lea    0x88(%rsp),%rdi
  6dd19d:	call   6c1290 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::SnapshotNode>>>
  6dd1a2:	mov    %r15,%rdi
  6dd1a5:	call   a20c40 <_Unwind_Resume@plt>
  6dd1aa:	mov    %rax,%r15
  6dd1ad:	lea    0x218(%rsp),%rdi
  6dd1b5:	call   6c55a0 <core::ptr::drop_glue::<gpui::runtime::Snapshot>>
  6dd1ba:	mov    %r15,%rdi
  6dd1bd:	call   a20c40 <_Unwind_Resume@plt>
  6dd1c2:	mov    %rax,%r15
  6dd1c5:	mov    $0x4,%esi
  6dd1ca:	mov    $0x1,%edx
  6dd1cf:	mov    %rbx,%rdi
  6dd1d2:	call   *0x365628(%rip)        # a42800 <_DYNAMIC+0x268>
  6dd1d8:	lea    0x218(%rsp),%rdi
  6dd1e0:	call   6c55a0 <core::ptr::drop_glue::<gpui::runtime::Snapshot>>
  6dd1e5:	mov    %r15,%rdi
  6dd1e8:	call   a20c40 <_Unwind_Resume@plt>

text_column_public_control::public_hit code=264 fixed_stack=72

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006dd1f0 <text_column_public_control::public_hit>:
  6dd1f0:	push   %rbx
  6dd1f1:	sub    $0x40,%rsp
  6dd1f5:	test   %rdi,%rdi
  6dd1f8:	je     6dd2a2 <text_column_public_control::public_hit+0xb2>
  6dd1fe:	mov    %rdi,%rbx
  6dd201:	cmpb   $0x0,0x74e(%rdi)
  6dd208:	jne    6dd2a9 <text_column_public_control::public_hit+0xb9>
  6dd20e:	mov    $0x12,%eax
  6dd213:	cmpb   $0x1,0x74a(%rbx)
  6dd21a:	jne    6dd2ae <text_column_public_control::public_hit+0xbe>
  6dd220:	cmpb   $0x0,0x74b(%rbx)
  6dd227:	jne    6dd2ae <text_column_public_control::public_hit+0xbe>
  6dd22d:	cmpb   $0x0,0x74c(%rbx)
  6dd234:	je     6dd2ae <text_column_public_control::public_hit+0xbe>
  6dd236:	cmpq   $0xffffffffffffffff,0x5b8(%rbx)
  6dd23e:	jne    6dd2ae <text_column_public_control::public_hit+0xbe>
  6dd240:	mov    0x690(%rbx),%rcx
  6dd247:	cmp    0x698(%rbx),%rcx
  6dd24e:	jne    6dd2ae <text_column_public_control::public_hit+0xbe>
  6dd250:	mov    0x6a8(%rbx),%rcx
  6dd257:	cmp    0x6a0(%rbx),%rcx
  6dd25e:	jne    6dd2ae <text_column_public_control::public_hit+0xbe>
  6dd260:	movss  0x740(%rbx),%xmm2
  6dd268:	ucomiss 0x744(%rbx),%xmm2
  6dd26f:	jne    6dd2ae <text_column_public_control::public_hit+0xbe>
  6dd271:	jp     6dd2ae <text_column_public_control::public_hit+0xbe>
  6dd273:	mov    %rbx,%rdi
  6dd276:	call   70cfe0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit>
  6dd27b:	cmp    $0x1,%rax
  6dd27f:	jne    6dd29a <text_column_public_control::public_hit+0xaa>
  6dd281:	add    $0x5e0,%rbx
  6dd288:	mov    %rbx,%rdi
  6dd28b:	mov    %rdx,%rsi
  6dd28e:	call   *0x3657a4(%rip)        # a42a38 <_DYNAMIC+0x4a0>
  6dd294:	add    $0x40,%rsp
  6dd298:	pop    %rbx
  6dd299:	ret
  6dd29a:	xor    %eax,%eax
  6dd29c:	add    $0x40,%rsp
  6dd2a0:	pop    %rbx
  6dd2a1:	ret
  6dd2a2:	mov    $0xd,%eax
  6dd2a7:	jmp    6dd2ae <text_column_public_control::public_hit+0xbe>
  6dd2a9:	mov    $0xe,%eax
  6dd2ae:	mov    %rax,0x8(%rsp)
  6dd2b3:	movq   $0x0,0x10(%rsp)
  6dd2bc:	lea    -0x68faec(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6dd2c3:	lea    0x345f5e(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6dd2ca:	lea    0x34586f(%rip),%r8        # a22b40 <__frame_dummy_init_array_entry+0xb50>
  6dd2d1:	lea    0x8(%rsp),%rdx
  6dd2d6:	mov    $0x2b,%esi
  6dd2db:	call   *0x3654f7(%rip)        # a427d8 <_DYNAMIC+0x240>
  6dd2e1:	ud2
  6dd2e3:	mov    %rax,%rbx
  6dd2e6:	lea    0x8(%rsp),%rdi
  6dd2eb:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6dd2f0:	mov    %rbx,%rdi
  6dd2f3:	call   a20c40 <_Unwind_Resume@plt>

text_column_public_control::public_query code=1653 fixed_stack=376

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006dd300 <text_column_public_control::public_query>:
  6dd300:	push   %rbp
  6dd301:	push   %r15
  6dd303:	push   %r14
  6dd305:	push   %r13
  6dd307:	push   %r12
  6dd309:	push   %rbx
  6dd30a:	sub    $0x148,%rsp
  6dd311:	test   %rsi,%rsi
  6dd314:	je     6dd90c <text_column_public_control::public_query+0x60c>
  6dd31a:	mov    %rsi,%rbx
  6dd31d:	cmpb   $0x0,0x74e(%rsi)
  6dd324:	jne    6dd913 <text_column_public_control::public_query+0x613>
  6dd32a:	cmpb   $0x1,0x74c(%rbx)
  6dd331:	jne    6dd91a <text_column_public_control::public_query+0x61a>
  6dd337:	mov    0x6c8(%rbx),%rdx
  6dd33e:	mov    0x6a0(%rbx),%r12
  6dd345:	mov    0x5a8(%rbx),%rbp
  6dd34c:	mov    0x5b0(%rbx),%rax
  6dd353:	mov    %rax,0x8(%rsp)
  6dd358:	movups 0x618(%rbx),%xmm1
  6dd35f:	mov    0x640(%rbx),%r13
  6dd366:	test   %r13,%r13
  6dd369:	mov    %rdi,0x80(%rsp)
  6dd371:	je     6dd3b3 <text_column_public_control::public_query+0xb3>
  6dd373:	mov    0xe0(%r13),%rax
  6dd37a:	test   %rax,%rax
  6dd37d:	je     6dd3cf <text_column_public_control::public_query+0xcf>
  6dd37f:	mov    0x38(%rax),%ecx
  6dd382:	mov    %ecx,0x20(%rsp)
  6dd386:	movups 0x28(%rax),%xmm0
  6dd38a:	movaps %xmm0,0x10(%rsp)
  6dd38f:	movzbl 0x3c(%rax),%r15d
  6dd394:	movzbl 0x3f(%rax),%ecx
  6dd398:	mov    %cl,0x62(%rsp)
  6dd39c:	movzwl 0x3d(%rax),%eax
  6dd3a0:	mov    %ax,0x60(%rsp)
  6dd3a5:	mov    0x100(%r13),%rsi
  6dd3ac:	test   %rsi,%rsi
  6dd3af:	jne    6dd3de <text_column_public_control::public_query+0xde>
  6dd3b1:	jmp    6dd3b6 <text_column_public_control::public_query+0xb6>
  6dd3b3:	mov    $0x2,%r15b
  6dd3b6:	movq   $0x4,0x100(%rsp)
  6dd3c2:	xorps  %xmm0,%xmm0
  6dd3c5:	movups %xmm0,0x108(%rsp)
  6dd3cd:	jmp    6dd3fc <text_column_public_control::public_query+0xfc>
  6dd3cf:	mov    $0x2,%r15b
  6dd3d2:	mov    0x100(%r13),%rsi
  6dd3d9:	test   %rsi,%rsi
  6dd3dc:	je     6dd3b6 <text_column_public_control::public_query+0xb6>
  6dd3de:	lea    0x100(%rsp),%rdi
  6dd3e6:	mov    %rdx,%r14
  6dd3e9:	movaps %xmm1,0x50(%rsp)
  6dd3ee:	call   *0x3653ec(%rip)        # a427e0 <_DYNAMIC+0x248>
  6dd3f4:	movaps 0x50(%rsp),%xmm1
  6dd3f9:	mov    %r14,%rdx
  6dd3fc:	movabs $0xcbf29ce484222325,%r14
  6dd406:	add    $0x5e0,%rbx
  6dd40d:	mov    %rbx,0xe0(%rsp)
  6dd415:	mov    %rdx,0xb0(%rsp)
  6dd41d:	mov    %r12,0xb8(%rsp)
  6dd425:	mov    %rbp,0xa0(%rsp)
  6dd42d:	mov    0x8(%rsp),%rcx
  6dd432:	mov    %rcx,0xa8(%rsp)
  6dd43a:	movaps %xmm1,0x90(%rsp)
  6dd442:	mov    %r13,0xc0(%rsp)
  6dd44a:	mov    0x100(%rsp),%rax
  6dd452:	mov    %rax,0xc8(%rsp)
  6dd45a:	mov    0x108(%rsp),%rax
  6dd462:	mov    %rax,0xd0(%rsp)
  6dd46a:	mov    0x110(%rsp),%rax
  6dd472:	mov    %rax,0xd8(%rsp)
  6dd47a:	movaps 0x10(%rsp),%xmm0
  6dd47f:	movups %xmm0,0xe8(%rsp)
  6dd487:	mov    0x20(%rsp),%eax
  6dd48b:	mov    %eax,0xf8(%rsp)
  6dd492:	mov    %r15b,0xfc(%rsp)
  6dd49a:	movzwl 0x60(%rsp),%eax
  6dd49f:	mov    %ax,0xfd(%rsp)
  6dd4a7:	movzbl 0x62(%rsp),%eax
  6dd4ac:	mov    %al,0xff(%rsp)
  6dd4b3:	test   %rcx,%rcx
  6dd4b6:	je     6dd8d6 <text_column_public_control::public_query+0x5d6>
  6dd4bc:	movabs $0x100000001b3,%r13
  6dd4c6:	xor    %edx,%edx
  6dd4c8:	lea    0x10(%rsp),%rdi
  6dd4cd:	lea    0x100(%rsp),%r12
  6dd4d5:	movq   $0x0,(%rsp)
  6dd4dd:	mov    %rbp,0x88(%rsp)
  6dd4e5:	jmp    6dd517 <text_column_public_control::public_query+0x217>
  6dd4e7:	nopw   0x0(%rax,%rax,1)
  6dd4f0:	mov    %rbx,%r14
  6dd4f3:	incq   (%rsp)
  6dd4f7:	mov    0x88(%rsp),%rbp
  6dd4ff:	mov    0x50(%rsp),%rdx
  6dd504:	inc    %rdx
  6dd507:	cmp    0x8(%rsp),%rdx
  6dd50c:	lea    0x10(%rsp),%rdi
  6dd511:	je     6dd8de <text_column_public_control::public_query+0x5de>
  6dd517:	mov    %rdx,%r15
  6dd51a:	shl    $0x6,%r15
  6dd51e:	movzbl 0x3d(%rbp,%r15,1),%eax
  6dd524:	sub    $0x2,%al
  6dd526:	movzbl %al,%eax
  6dd529:	mov    $0x8,%ecx
  6dd52e:	cmovb  %ecx,%eax
  6dd531:	movzbl %al,%eax
  6dd534:	xor    %r14,%rax
  6dd537:	imul   %r13,%rax
  6dd53b:	mov    0x10(%rbp,%r15,1),%ecx
  6dd540:	xor    %rax,%rcx
  6dd543:	mov    0x14(%rbp,%r15,1),%eax
  6dd548:	mov    0x18(%rbp,%r15,1),%r8d
  6dd54d:	mov    0x1c(%rbp,%r15,1),%esi
  6dd552:	imul   %r13,%rcx
  6dd556:	xor    %rax,%rcx
  6dd559:	imul   %r13,%rcx
  6dd55d:	xor    %r8,%rcx
  6dd560:	imul   %r13,%rcx
  6dd564:	xor    %rsi,%rcx
  6dd567:	movabs $0x8a97b0004e7feab,%rax
  6dd571:	imul   %rax,%rcx
  6dd575:	mov    0x8(%rbp,%r15,1),%ebx
  6dd57a:	mov    0xc(%rbp,%r15,1),%eax
  6dd57f:	xor    %rcx,%rbx
  6dd582:	imul   %r13,%rbx
  6dd586:	xor    %rax,%rbx
  6dd589:	imul   %r13,%rbx
  6dd58d:	lea    0x90(%rsp),%rsi
  6dd595:	mov    %rdx,0x50(%rsp)
  6dd59a:	call   *0x365248(%rip)        # a427e8 <_DYNAMIC+0x250>
  6dd5a0:	cmpl   $0x1,0x10(%rsp)
  6dd5a5:	jne    6dd5ee <text_column_public_control::public_query+0x2ee>
  6dd5a7:	mov    0x14(%rsp),%eax
  6dd5ab:	mov    0x18(%rsp),%ecx
  6dd5af:	mov    0x1c(%rsp),%edx
  6dd5b3:	mov    0x20(%rsp),%esi
  6dd5b7:	mov    0x24(%rsp),%edi
  6dd5bb:	mov    0x28(%rsp),%r8d
  6dd5c0:	xor    $0x1,%rbx
  6dd5c4:	imul   %r13,%rbx
  6dd5c8:	xor    %rax,%rbx
  6dd5cb:	imul   %r13,%rbx
  6dd5cf:	xor    %rcx,%rbx
  6dd5d2:	imul   %r13,%rbx
  6dd5d6:	xor    %rdx,%rbx
  6dd5d9:	imul   %r13,%rbx
  6dd5dd:	xor    %rsi,%rbx
  6dd5e0:	imul   %r13,%rbx
  6dd5e4:	xor    %rdi,%rbx
  6dd5e7:	imul   %r13,%rbx
  6dd5eb:	xor    %r8,%rbx
  6dd5ee:	add    %rbp,%r15
  6dd5f1:	mov    0x28(%r15),%rcx
  6dd5f5:	test   %rcx,%rcx
  6dd5f8:	je     6dd730 <text_column_public_control::public_query+0x430>
  6dd5fe:	imul   %r13,%rbx
  6dd602:	mov    (%rcx),%rdx
  6dd605:	mov    %rdx,%rdi
  6dd608:	shr    $1,%rdi
  6dd60b:	movzbl 0x3d(%r15),%r8d
  6dd610:	xor    $0x1,%rbx
  6dd614:	imul   %r13,%rbx
  6dd618:	test   %rdi,%rdi
  6dd61b:	je     6dd740 <text_column_public_control::public_query+0x440>
  6dd621:	lea    0x10(%rcx),%rax
  6dd625:	mov    %rdi,%rsi
  6dd628:	and    $0x7,%rsi
  6dd62c:	lea    0x138(%rsp),%r15
  6dd634:	je     6dd839 <text_column_public_control::public_query+0x539>
  6dd63a:	mov    %rsi,%r10
  6dd63d:	mov    %rax,%r9
  6dd640:	movzbl (%r9),%r14d
  6dd644:	inc    %r9
  6dd647:	xor    %rbx,%r14
  6dd64a:	imul   %r13,%r14
  6dd64e:	mov    %r14,%rbx
  6dd651:	dec    %r10
  6dd654:	jne    6dd640 <text_column_public_control::public_query+0x340>
  6dd656:	add    %rdi,%rcx
  6dd659:	add    $0x10,%rcx
  6dd65d:	cmp    $0x10,%rdx
  6dd661:	jb     6dd6d8 <text_column_public_control::public_query+0x3d8>
  6dd663:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6dd670:	movzbl (%r9),%r10d
  6dd674:	xor    %r14,%r10
  6dd677:	imul   %r13,%r10
  6dd67b:	movzbl 0x1(%r9),%r11d
  6dd680:	xor    %r10,%r11
  6dd683:	imul   %r13,%r11
  6dd687:	movzbl 0x2(%r9),%r10d
  6dd68c:	xor    %r11,%r10
  6dd68f:	imul   %r13,%r10
  6dd693:	movzbl 0x3(%r9),%r11d
  6dd698:	xor    %r10,%r11
  6dd69b:	imul   %r13,%r11
  6dd69f:	movzbl 0x4(%r9),%r10d
  6dd6a4:	xor    %r11,%r10
  6dd6a7:	imul   %r13,%r10
  6dd6ab:	movzbl 0x5(%r9),%r11d
  6dd6b0:	xor    %r10,%r11
  6dd6b3:	imul   %r13,%r11
  6dd6b7:	movzbl 0x6(%r9),%r10d
  6dd6bc:	xor    %r11,%r10
  6dd6bf:	imul   %r13,%r10
  6dd6c3:	movzbl 0x7(%r9),%r14d
  6dd6c8:	add    $0x8,%r9
  6dd6cc:	xor    %r10,%r14
  6dd6cf:	imul   %r13,%r14
  6dd6d3:	cmp    %rcx,%r9
  6dd6d6:	jne    6dd670 <text_column_public_control::public_query+0x370>
  6dd6d8:	cmp    $0x4,%r8b
  6dd6dc:	jne    6dd757 <text_column_public_control::public_query+0x457>
  6dd6de:	xor    $0x1,%r14
  6dd6e2:	mov    %r14,%r8
  6dd6e5:	imul   %r13,%r8
  6dd6e9:	test   $0x7,%dil
  6dd6ed:	je     6dd855 <text_column_public_control::public_query+0x555>
  6dd6f3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6dd700:	movzbl (%rax),%r14d
  6dd704:	inc    %rax
  6dd707:	xor    %r8,%r14
  6dd70a:	imul   %r13,%r14
  6dd70e:	mov    %r14,%r8
  6dd711:	dec    %rsi
  6dd714:	jne    6dd700 <text_column_public_control::public_query+0x400>
  6dd716:	cmp    $0x10,%rdx
  6dd71a:	mov    0x50(%rsp),%rdx
  6dd71f:	jae    6dd870 <text_column_public_control::public_query+0x570>
  6dd725:	jmp    6dd760 <text_column_public_control::public_query+0x460>
  6dd727:	nopw   0x0(%rax,%rax,1)
  6dd730:	movabs $0x366000002e329,%rax
  6dd73a:	imul   %rax,%rbx
  6dd73e:	jmp    6dd74c <text_column_public_control::public_query+0x44c>
  6dd740:	xor    %eax,%eax
  6dd742:	cmp    $0x4,%r8b
  6dd746:	sete   %al
  6dd749:	xor    %rax,%rbx
  6dd74c:	mov    %rbx,%r14
  6dd74f:	lea    0x138(%rsp),%r15
  6dd757:	imul   %r13,%r14
  6dd75b:	mov    0x50(%rsp),%rdx
  6dd760:	lea    0x60(%rsp),%rdi
  6dd765:	lea    0x90(%rsp),%rsi
  6dd76d:	call   *0x36507d(%rip)        # a427f0 <_DYNAMIC+0x258>
  6dd773:	cmpq   $0x0,0x60(%rsp)
  6dd779:	je     6dd4ff <text_column_public_control::public_query+0x1ff>
  6dd77f:	mov    0x70(%rsp),%rsi
  6dd784:	mov    0x78(%rsp),%eax
  6dd788:	mov    0x7c(%rsp),%ecx
  6dd78c:	xor    %rax,%r14
  6dd78f:	imul   %r13,%r14
  6dd793:	xor    %rcx,%r14
  6dd796:	imul   %r13,%r14
  6dd79a:	mov    0x48(%rsi),%ebx
  6dd79d:	xor    %r14,%rbx
  6dd7a0:	imul   %r13,%rbx
  6dd7a4:	mov    %r12,%rdi
  6dd7a7:	call   *0x36504b(%rip)        # a427f8 <_DYNAMIC+0x260>
  6dd7ad:	lea    0x10(%rsp),%rdi
  6dd7b2:	mov    %r12,%rsi
  6dd7b5:	mov    %r15,%rdx
  6dd7b8:	call   6da0a0 <<core::iter::adapters::zip::Zip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>, core::iter::adapters::skip::Skip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>>> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::find_map::check<(&[gpui_canvas::text::layout::Stop], &[gpui_canvas::text::layout::Stop]), gpui_canvas::text::layout::interaction::TextGrapheme, &mut <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#1}>::{closure#0}, core::ops::control_flow::ControlFlow<gpui_canvas::text::layout::interaction::TextGrapheme>>>
  6dd7bd:	cmpb   $0x2,0x14(%rsp)
  6dd7c2:	je     6dd4f0 <text_column_public_control::public_query+0x1f0>
  6dd7c8:	lea    0x10(%rsp),%rbp
  6dd7cd:	nopl   (%rax)
  6dd7d0:	mov    0x10(%rsp),%r14d
  6dd7d5:	mov    0x18(%rsp),%eax
  6dd7d9:	xor    %rbx,%r14
  6dd7dc:	mov    0x20(%rsp),%ecx
  6dd7e0:	mov    0x24(%rsp),%edx
  6dd7e4:	mov    0x28(%rsp),%esi
  6dd7e8:	mov    0x2c(%rsp),%edi
  6dd7ec:	imul   %r13,%r14
  6dd7f0:	xor    %rax,%r14
  6dd7f3:	imul   %r13,%r14
  6dd7f7:	xor    %rcx,%r14
  6dd7fa:	imul   %r13,%r14
  6dd7fe:	xor    %rdx,%r14
  6dd801:	imul   %r13,%r14
  6dd805:	xor    %rsi,%r14
  6dd808:	imul   %r13,%r14
  6dd80c:	xor    %rdi,%r14
  6dd80f:	imul   %r13,%r14
  6dd813:	xor    0x30(%rsp),%r14
  6dd818:	imul   %r13,%r14
  6dd81c:	mov    %rbp,%rdi
  6dd81f:	mov    %r12,%rsi
  6dd822:	mov    %r15,%rdx
  6dd825:	call   6da0a0 <<core::iter::adapters::zip::Zip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>, core::iter::adapters::skip::Skip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>>> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::find_map::check<(&[gpui_canvas::text::layout::Stop], &[gpui_canvas::text::layout::Stop]), gpui_canvas::text::layout::interaction::TextGrapheme, &mut <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#1}>::{closure#0}, core::ops::control_flow::ControlFlow<gpui_canvas::text::layout::interaction::TextGrapheme>>>
  6dd82a:	cmpb   $0x2,0x14(%rsp)
  6dd82f:	mov    %r14,%rbx
  6dd832:	jne    6dd7d0 <text_column_public_control::public_query+0x4d0>
  6dd834:	jmp    6dd4f3 <text_column_public_control::public_query+0x1f3>
  6dd839:	mov    %rbx,%r14
  6dd83c:	mov    %rax,%r9
  6dd83f:	add    %rdi,%rcx
  6dd842:	add    $0x10,%rcx
  6dd846:	cmp    $0x10,%rdx
  6dd84a:	jae    6dd670 <text_column_public_control::public_query+0x370>
  6dd850:	jmp    6dd6d8 <text_column_public_control::public_query+0x3d8>
  6dd855:	mov    %r8,%r14
  6dd858:	cmp    $0x10,%rdx
  6dd85c:	mov    0x50(%rsp),%rdx
  6dd861:	jb     6dd760 <text_column_public_control::public_query+0x460>
  6dd867:	nopw   0x0(%rax,%rax,1)
  6dd870:	movzbl (%rax),%edi
  6dd873:	xor    %r14,%rdi
  6dd876:	imul   %r13,%rdi
  6dd87a:	movzbl 0x1(%rax),%esi
  6dd87e:	xor    %rdi,%rsi
  6dd881:	imul   %r13,%rsi
  6dd885:	movzbl 0x2(%rax),%edi
  6dd889:	xor    %rsi,%rdi
  6dd88c:	imul   %r13,%rdi
  6dd890:	movzbl 0x3(%rax),%esi
  6dd894:	xor    %rdi,%rsi
  6dd897:	imul   %r13,%rsi
  6dd89b:	movzbl 0x4(%rax),%edi
  6dd89f:	xor    %rsi,%rdi
  6dd8a2:	imul   %r13,%rdi
  6dd8a6:	movzbl 0x5(%rax),%esi
  6dd8aa:	xor    %rdi,%rsi
  6dd8ad:	imul   %r13,%rsi
  6dd8b1:	movzbl 0x6(%rax),%edi
  6dd8b5:	xor    %rsi,%rdi
  6dd8b8:	imul   %r13,%rdi
  6dd8bc:	movzbl 0x7(%rax),%r14d
  6dd8c1:	add    $0x8,%rax
  6dd8c5:	xor    %rdi,%r14
  6dd8c8:	imul   %r13,%r14
  6dd8cc:	cmp    %rcx,%rax
  6dd8cf:	jne    6dd870 <text_column_public_control::public_query+0x570>
  6dd8d1:	jmp    6dd760 <text_column_public_control::public_query+0x460>
  6dd8d6:	movq   $0x0,(%rsp)
  6dd8de:	mov    0x80(%rsp),%rax
  6dd8e6:	mov    0x8(%rsp),%rcx
  6dd8eb:	mov    %rcx,(%rax)
  6dd8ee:	mov    (%rsp),%rcx
  6dd8f2:	mov    %rcx,0x8(%rax)
  6dd8f6:	mov    %r14,0x10(%rax)
  6dd8fa:	add    $0x148,%rsp
  6dd901:	pop    %rbx
  6dd902:	pop    %r12
  6dd904:	pop    %r13
  6dd906:	pop    %r14
  6dd908:	pop    %r15
  6dd90a:	pop    %rbp
  6dd90b:	ret
  6dd90c:	mov    $0xd,%eax
  6dd911:	jmp    6dd91f <text_column_public_control::public_query+0x61f>
  6dd913:	mov    $0xe,%eax
  6dd918:	jmp    6dd91f <text_column_public_control::public_query+0x61f>
  6dd91a:	mov    $0x12,%eax
  6dd91f:	mov    %rax,0x90(%rsp)
  6dd927:	movq   $0x0,0x98(%rsp)
  6dd933:	lea    -0x690163(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6dd93a:	lea    0x3458e7(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6dd941:	lea    0x3446e0(%rip),%r8        # a22028 <__frame_dummy_init_array_entry+0x38>
  6dd948:	lea    0x90(%rsp),%rdx
  6dd950:	mov    $0x2b,%esi
  6dd955:	call   *0x364e7d(%rip)        # a427d8 <_DYNAMIC+0x240>
  6dd95b:	ud2
  6dd95d:	mov    %rax,%rbx
  6dd960:	lea    0x90(%rsp),%rdi
  6dd968:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6dd96d:	mov    %rbx,%rdi
  6dd970:	call   a20c40 <_Unwind_Resume@plt>

text_column_public_control::public_prepare code=316 fixed_stack=152

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006dd980 <text_column_public_control::public_prepare>:
  6dd980:	push   %rbx
  6dd981:	sub    $0x90,%rsp
  6dd988:	mov    (%rsi),%rax
  6dd98b:	test   %rax,%rax
  6dd98e:	je     6dda8c <text_column_public_control::public_prepare+0x10c>
  6dd994:	add    $0x8,%rsi
  6dd998:	mov    %rax,0x40(%rsp)
  6dd99d:	mov    %rsi,0x48(%rsp)
  6dd9a2:	movq   $0x0,0x50(%rsp)
  6dd9ab:	cmpb   $0x0,0x74e(%rax)
  6dd9b2:	jne    6ddaa0 <text_column_public_control::public_prepare+0x120>
  6dd9b8:	mov    0x690(%rax),%rcx
  6dd9bf:	cmp    $0xffffffffffffffff,%rcx
  6dd9c3:	je     6dda30 <text_column_public_control::public_prepare+0xb0>
  6dd9c5:	mov    %rdi,%rbx
  6dd9c8:	inc    %rcx
  6dd9cb:	movss  %xmm0,0x2b8(%rax)
  6dd9d3:	mov    %rcx,0x690(%rax)
  6dd9da:	incq   0x6e0(%rax)
  6dd9e1:	movq   $0x0,0x738(%rax)
  6dd9ec:	lea    0x8(%rsp),%rdi
  6dd9f1:	lea    0x40(%rsp),%rsi
  6dd9f6:	lea    0x50(%rsp),%rcx
  6dd9fb:	xor    %edx,%edx
  6dd9fd:	xor    %r8d,%r8d
  6dda00:	call   6e6450 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::after_source_changed>
  6dda05:	cmpq   $0xfffffffffffffffe,0x8(%rsp)
  6dda0b:	jne    6dda3a <text_column_public_control::public_prepare+0xba>
  6dda0d:	movups 0x10(%rsp),%xmm0
  6dda12:	movups 0x20(%rsp),%xmm1
  6dda17:	movups 0x30(%rsp),%xmm2
  6dda1c:	movups %xmm2,0x20(%rbx)
  6dda20:	movups %xmm1,0x10(%rbx)
  6dda24:	movups %xmm0,(%rbx)
  6dda27:	add    $0x90,%rsp
  6dda2e:	pop    %rbx
  6dda2f:	ret
  6dda30:	mov    $0x1f,%eax
  6dda35:	mov    %rax,0x8(%rsp)
  6dda3a:	mov    0x38(%rsp),%rax
  6dda3f:	mov    %rax,0x80(%rsp)
  6dda47:	movups 0x8(%rsp),%xmm0
  6dda4c:	movups 0x18(%rsp),%xmm1
  6dda51:	movups 0x28(%rsp),%xmm2
  6dda56:	movaps %xmm2,0x70(%rsp)
  6dda5b:	movaps %xmm1,0x60(%rsp)
  6dda60:	movaps %xmm0,0x50(%rsp)
  6dda65:	lea    -0x690295(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6dda6c:	lea    0x3457b5(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6dda73:	lea    0x34528e(%rip),%r8        # a22d08 <__frame_dummy_init_array_entry+0xd18>
  6dda7a:	lea    0x50(%rsp),%rdx
  6dda7f:	mov    $0x2b,%esi
  6dda84:	call   *0x364d4e(%rip)        # a427d8 <_DYNAMIC+0x240>
  6dda8a:	ud2
  6dda8c:	movq   $0xd,0x8(%rsp)
  6dda95:	movq   $0x0,0x10(%rsp)
  6dda9e:	jmp    6dda3a <text_column_public_control::public_prepare+0xba>
  6ddaa0:	mov    $0xe,%eax
  6ddaa5:	jmp    6dda35 <text_column_public_control::public_prepare+0xb5>
  6ddaa7:	mov    %rax,%rbx
  6ddaaa:	lea    0x50(%rsp),%rdi
  6ddaaf:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6ddab4:	mov    %rbx,%rdi
  6ddab7:	call   a20c40 <_Unwind_Resume@plt>

text_column_public_control::edit code=7730 fixed_stack=392

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006ddac0 <text_column_public_control::edit>:
  6ddac0:	push   %rbp
  6ddac1:	push   %r15
  6ddac3:	push   %r14
  6ddac5:	push   %r13
  6ddac7:	push   %r12
  6ddac9:	push   %rbx
  6ddaca:	sub    $0x158,%rsp
  6ddad1:	mov    %rsi,%r14
  6ddad4:	mov    %rdi,%rbx
  6ddad7:	movzbl %dl,%eax
  6ddada:	lea    -0x69bf65(%rip),%rsi        # 41b7c <GCC_except_table0+0x1d34>
  6ddae1:	movslq (%rsi,%rax,4),%rax
  6ddae5:	add    %rsi,%rax
  6ddae8:	jmp    *%rax
  6ddaea:	xor    %eax,%eax
  6ddaec:	test   $0x1,%r8b
  6ddaf0:	sete   %al
  6ddaf3:	lea    -0x69c0ca(%rip),%rdx        # 41a30 <GCC_except_table0+0x1be8>
  6ddafa:	movss  (%rdx,%rax,4),%xmm0
  6ddaff:	jmp    6dddfd <text_column_public_control::edit+0x33d>
  6ddb04:	and    $0x1,%r8d
  6ddb08:	lea    0x12(%r8),%rax
  6ddb0c:	test   %r8,%r8
  6ddb0f:	lea    -0x6904f1(%rip),%rdx        # 4d625 <GCC_except_table0+0xd7dd>
  6ddb16:	lea    -0x690582(%rip),%rsi        # 4d59b <GCC_except_table0+0xd753>
  6ddb1d:	cmove  %rdx,%rsi
  6ddb21:	mov    %rsi,0x60(%rsp)
  6ddb26:	mov    %rax,0x68(%rsp)
  6ddb2b:	lea    0x60(%rsp),%rax
  6ddb30:	mov    0x68(%rsp),%r12
  6ddb35:	test   %r12,%r12
  6ddb38:	jns    6de308 <text_column_public_control::edit+0x848>
  6ddb3e:	xor    %ebp,%ebp
  6ddb40:	mov    %rbp,%rdi
  6ddb43:	mov    %r12,%rsi
  6ddb46:	call   *0x364d44(%rip)        # a42890 <_DYNAMIC+0x2f8>
  6ddb4c:	mov    %r8d,%eax
  6ddb4f:	and    $0x1,%eax
  6ddb52:	shl    $0xe,%eax
  6ddb55:	add    $0x4000,%rax
  6ddb5b:	movsd  -0x69c393(%rip),%xmm0        # 417d0 <GCC_except_table0+0x1988>
  6ddb63:	not    %r8b
  6ddb66:	cmp    $0x7,%dl
  6ddb69:	sete   %dl
  6ddb6c:	and    %r8b,%dl
  6ddb6f:	mov    %rax,0x100(%rsp)
  6ddb77:	movsd  %xmm0,0x108(%rsp)
  6ddb80:	mov    %dl,0x110(%rsp)
  6ddb87:	lea    0x100(%rsp),%rax
  6ddb8f:	test   %cl,%cl
  6ddb91:	je     6de55f <text_column_public_control::edit+0xa9f>
  6ddb97:	mov    0x100(%rsp),%rax
  6ddb9f:	mov    %rax,0x18(%rsp)
  6ddba4:	mov    0x108(%rsp),%rax
  6ddbac:	mov    %rax,0x10(%rsp)
  6ddbb1:	movzbl 0x110(%rsp),%eax
  6ddbb9:	mov    %al,0x8(%rsp)
  6ddbbd:	lea    0x111(%rsp),%rax
  6ddbc5:	mov    0x114(%rsp),%ecx
  6ddbcc:	mov    %ecx,0x153(%rsp)
  6ddbd3:	mov    0x111(%rsp),%ecx
  6ddbda:	mov    %ecx,0x150(%rsp)
  6ddbe1:	mov    (%r14),%r15
  6ddbe4:	test   %r15,%r15
  6ddbe7:	je     6dee72 <text_column_public_control::edit+0x13b2>
  6ddbed:	mov    (%rax),%ecx
  6ddbef:	mov    0x3(%rax),%eax
  6ddbf2:	mov    %eax,0xcb(%rsp)
  6ddbf9:	mov    %ecx,0xc8(%rsp)
  6ddc00:	mov    0x6d0(%r15),%rax
  6ddc07:	cmpb   $0x0,0x78e(%r15)
  6ddc0f:	mov    %rax,0x120(%rsp)
  6ddc17:	jne    6deeaf <text_column_public_control::edit+0x13ef>
  6ddc1d:	add    $0x8,%r14
  6ddc21:	mov    %r14,0x58(%rsp)
  6ddc26:	movabs $0x400000001,%r12
  6ddc30:	mov    0x248(%r15),%r13
  6ddc37:	mov    0x250(%r15),%rbp
  6ddc3e:	shl    $0x4,%rbp
  6ddc42:	xor    %r14d,%r14d
  6ddc45:	data16 cs nopw 0x0(%rax,%rax,1)
  6ddc50:	cmp    %r14,%rbp
  6ddc53:	je     6dec7e <text_column_public_control::edit+0x11be>
  6ddc59:	mov    0x0(%r13,%r14,1),%rdi
  6ddc5e:	mov    0x8(%r13,%r14,1),%rax
  6ddc63:	call   *0x18(%rax)
  6ddc66:	add    $0x10,%r14
  6ddc6a:	cmp    %r12,%rax
  6ddc6d:	jne    6ddc50 <text_column_public_control::edit+0x190>
  6ddc6f:	mov    -0x10(%r13,%r14,1),%rdi
  6ddc74:	mov    -0x8(%r13,%r14,1),%rax
  6ddc79:	lea    0x290(%r15),%rsi
  6ddc80:	call   *0x28(%rax)
  6ddc83:	mov    %rax,%rdi
  6ddc86:	mov    %rdx,%rax
  6ddc89:	lea    0x345c70(%rip),%rdx        # a23900 <__frame_dummy_init_array_entry+0x1910>
  6ddc90:	lea    0x2b0(%r15),%rsi
  6ddc97:	call   *0x20(%rax)
  6ddc9a:	mov    %r12,0x68(%rsp)
  6ddc9f:	mov    0x68(%rsp),%rcx
  6ddca4:	mov    %rcx,0xd0(%rsp)
  6ddcac:	mov    0x70(%rsp),%rcx
  6ddcb1:	mov    %rcx,0xd8(%rsp)
  6ddcb9:	test   %al,%al
  6ddcbb:	mov    0x58(%rsp),%rdx
  6ddcc0:	mov    0x10(%rsp),%rsi
  6ddcc5:	mov    0x18(%rsp),%rdi
  6ddcca:	je     6deec8 <text_column_public_control::edit+0x1408>
  6ddcd0:	movq   $0x0,0xd0(%rsp)
  6ddcdc:	cmpb   $0x0,0x78e(%r15)
  6ddce4:	jne    6deed2 <text_column_public_control::edit+0x1412>
  6ddcea:	mov    0x6d0(%r15),%rax
  6ddcf1:	inc    %rax
  6ddcf4:	je     6de94b <text_column_public_control::edit+0xe8b>
  6ddcfa:	mov    0x2c8(%r15),%ecx
  6ddd01:	cmp    $0xffffffff,%ecx
  6ddd04:	je     6de974 <text_column_public_control::edit+0xeb4>
  6ddd0a:	inc    %ecx
  6ddd0c:	mov    %ecx,0x2c8(%r15)
  6ddd13:	movzbl 0x8(%rsp),%ecx
  6ddd18:	cmp    $0x2,%cl
  6ddd1b:	je     6de989 <text_column_public_control::edit+0xec9>
  6ddd21:	mov    %rdi,0x2b0(%r15)
  6ddd28:	mov    %rsi,0x2b8(%r15)
  6ddd2f:	mov    %cl,0x2c0(%r15)
  6ddd36:	mov    0x150(%rsp),%ecx
  6ddd3d:	mov    0x153(%rsp),%esi
  6ddd44:	mov    %ecx,0x2c1(%r15)
  6ddd4b:	mov    %esi,0x2c4(%r15)
  6ddd52:	mov    %rax,0x6d0(%r15)
  6ddd59:	incq   0x720(%r15)
  6ddd60:	movq   $0x0,0x778(%r15)
  6ddd6b:	lea    0x20(%rsp),%rdi
  6ddd70:	lea    0xd0(%rsp),%r8
  6ddd78:	mov    %r15,%rsi
  6ddd7b:	mov    %r12,%rcx
  6ddd7e:	call   6e9560 <<gpui::runtime::RuntimeMut<text_column_public_control::Model, ()>>::after_source_with_editing>
  6ddd83:	mov    0x20(%rsp),%r13
  6ddd88:	mov    0x28(%rsp),%rax
  6ddd8d:	cmp    $0xfffffffffffffffe,%r13
  6ddd91:	jne    6deedd <text_column_public_control::edit+0x141d>
  6ddd97:	mov    0x40(%rsp),%rcx
  6ddd9c:	movzbl 0x48(%rsp),%edx
  6ddda1:	mov    0x49(%rsp),%esi
  6ddda5:	mov    %esi,0xf8(%rsp)
  6dddac:	mov    0x4c(%rsp),%esi
  6dddb0:	mov    %esi,0xfb(%rsp)
  6dddb7:	mov    0x50(%rsp),%rsi
  6dddbc:	movups 0x30(%rsp),%xmm0
  6dddc1:	mov    %rax,(%rbx)
  6dddc4:	movups %xmm0,0x8(%rbx)
  6dddc8:	mov    %rcx,0x18(%rbx)
  6dddcc:	mov    %dl,0x20(%rbx)
  6dddcf:	mov    0xf8(%rsp),%eax
  6dddd6:	mov    0xfb(%rsp),%ecx
  6ddddd:	mov    %eax,0x21(%rbx)
  6ddde0:	mov    %ecx,0x24(%rbx)
  6ddde3:	mov    %rsi,0x28(%rbx)
  6ddde7:	jmp    6de728 <text_column_public_control::edit+0xc68>
  6dddec:	and    $0x3,%r8d
  6dddf0:	lea    -0x69cc67(%rip),%rax        # 41190 <GCC_except_table0+0x1348>
  6dddf7:	movss  (%rax,%r8,4),%xmm0
  6dddfd:	movaps -0x69c7b4(%rip),%xmm1        # 41650 <GCC_except_table0+0x1808>
  6dde04:	movaps %xmm1,0x100(%rsp)
  6dde0c:	movss  %xmm0,0x110(%rsp)
  6dde15:	movl   $0x0,0x114(%rsp)
  6dde20:	lea    0x100(%rsp),%rax
  6dde28:	test   %cl,%cl
  6dde2a:	je     6de063 <text_column_public_control::edit+0x5a3>
  6dde30:	mov    0x100(%rsp),%rax
  6dde38:	mov    %rax,0x8(%rsp)
  6dde3d:	mov    0x108(%rsp),%rax
  6dde45:	mov    %rax,0x10(%rsp)
  6dde4a:	movzbl 0x110(%rsp),%r12d
  6dde53:	mov    0x114(%rsp),%eax
  6dde5a:	mov    %eax,0xcb(%rsp)
  6dde61:	mov    0x111(%rsp),%eax
  6dde68:	mov    %eax,0xc8(%rsp)
  6dde6f:	mov    (%r14),%r15
  6dde72:	test   %r15,%r15
  6dde75:	je     6ded68 <text_column_public_control::edit+0x12a8>
  6dde7b:	mov    %r12b,0x18(%rsp)
  6dde80:	cmpb   $0x0,0x78e(%r15)
  6dde88:	jne    6dedac <text_column_public_control::edit+0x12ec>
  6dde8e:	add    $0x8,%r14
  6dde92:	mov    %r14,0x58(%rsp)
  6dde97:	mov    0x6d0(%r15),%rax
  6dde9e:	mov    %rax,0x120(%rsp)
  6ddea6:	movabs $0x100000001,%r12
  6ddeb0:	mov    0x248(%r15),%r13
  6ddeb7:	mov    0x250(%r15),%rbp
  6ddebe:	shl    $0x4,%rbp
  6ddec2:	xor    %r14d,%r14d
  6ddec5:	data16 cs nopw 0x0(%rax,%rax,1)
  6dded0:	cmp    %r14,%rbp
  6dded3:	je     6dec35 <text_column_public_control::edit+0x1175>
  6dded9:	mov    0x0(%r13,%r14,1),%rdi
  6ddede:	mov    0x8(%r13,%r14,1),%rax
  6ddee3:	call   *0x18(%rax)
  6ddee6:	add    $0x10,%r14
  6ddeea:	cmp    %r12,%rax
  6ddeed:	jne    6dded0 <text_column_public_control::edit+0x410>
  6ddeef:	mov    -0x10(%r13,%r14,1),%rdi
  6ddef4:	mov    -0x8(%r13,%r14,1),%rax
  6ddef9:	lea    0x290(%r15),%rsi
  6ddf00:	call   *0x28(%rax)
  6ddf03:	mov    %rax,%rdi
  6ddf06:	mov    %rdx,%rax
  6ddf09:	lea    0x345a40(%rip),%rdx        # a23950 <__frame_dummy_init_array_entry+0x1960>
  6ddf10:	lea    0x2e0(%r15),%rsi
  6ddf17:	call   *0x20(%rax)
  6ddf1a:	mov    %r12,0x68(%rsp)
  6ddf1f:	mov    0x68(%rsp),%rcx
  6ddf24:	mov    %rcx,0xd0(%rsp)
  6ddf2c:	mov    0x70(%rsp),%rcx
  6ddf31:	mov    %rcx,0xd8(%rsp)
  6ddf39:	test   %al,%al
  6ddf3b:	mov    0x58(%rsp),%rdx
  6ddf40:	je     6dedcb <text_column_public_control::edit+0x130b>
  6ddf46:	movq   $0x0,0xd0(%rsp)
  6ddf52:	cmpb   $0x0,0x78e(%r15)
  6ddf5a:	jne    6dedd5 <text_column_public_control::edit+0x1315>
  6ddf60:	mov    0x6d0(%r15),%rax
  6ddf67:	inc    %rax
  6ddf6a:	je     6de7a5 <text_column_public_control::edit+0xce5>
  6ddf70:	mov    0x2f8(%r15),%ecx
  6ddf77:	cmp    $0xffffffff,%ecx
  6ddf7a:	je     6de8c2 <text_column_public_control::edit+0xe02>
  6ddf80:	inc    %ecx
  6ddf82:	mov    %ecx,0x2f8(%r15)
  6ddf89:	mov    0x8(%rsp),%rcx
  6ddf8e:	mov    %rcx,0x2e0(%r15)
  6ddf95:	mov    0x10(%rsp),%rcx
  6ddf9a:	mov    %rcx,0x2e8(%r15)
  6ddfa1:	movzbl 0x18(%rsp),%ecx
  6ddfa6:	mov    %cl,0x2f0(%r15)
  6ddfad:	mov    0xc8(%rsp),%ecx
  6ddfb4:	mov    0xcb(%rsp),%esi
  6ddfbb:	mov    %ecx,0x2f1(%r15)
  6ddfc2:	mov    %esi,0x2f4(%r15)
  6ddfc9:	mov    %rax,0x6d0(%r15)
  6ddfd0:	incq   0x720(%r15)
  6ddfd7:	movq   $0x0,0x778(%r15)
  6ddfe2:	lea    0x20(%rsp),%rdi
  6ddfe7:	lea    0xd0(%rsp),%r8
  6ddfef:	mov    %r15,%rsi
  6ddff2:	mov    %r12,%rcx
  6ddff5:	call   6e9560 <<gpui::runtime::RuntimeMut<text_column_public_control::Model, ()>>::after_source_with_editing>
  6ddffa:	mov    0x20(%rsp),%r13
  6ddfff:	mov    0x28(%rsp),%r14
  6de004:	cmp    $0xfffffffffffffffe,%r13
  6de008:	jne    6dede0 <text_column_public_control::edit+0x1320>
  6de00e:	mov    0x40(%rsp),%rax
  6de013:	movzbl 0x48(%rsp),%ecx
  6de018:	mov    0x49(%rsp),%edx
  6de01c:	mov    %edx,0x130(%rsp)
  6de023:	mov    0x4c(%rsp),%edx
  6de027:	mov    %edx,0x133(%rsp)
  6de02e:	mov    0x50(%rsp),%rdx
  6de033:	movups 0x30(%rsp),%xmm0
  6de038:	mov    %r14,(%rbx)
  6de03b:	movups %xmm0,0x8(%rbx)
  6de03f:	mov    %rax,0x18(%rbx)
  6de043:	mov    %cl,0x20(%rbx)
  6de046:	mov    0x130(%rsp),%eax
  6de04d:	mov    0x133(%rsp),%ecx
  6de054:	mov    %eax,0x21(%rbx)
  6de057:	mov    %ecx,0x24(%rbx)
  6de05a:	mov    %rdx,0x28(%rbx)
  6de05e:	jmp    6de728 <text_column_public_control::edit+0xc68>
  6de063:	mov    (%r14),%r15
  6de066:	test   %r15,%r15
  6de069:	je     6ded95 <text_column_public_control::edit+0x12d5>
  6de06f:	movq   $0x0,0xd0(%rsp)
  6de07b:	cmpb   $0x1,0x78e(%r15)
  6de083:	je     6dedbd <text_column_public_control::edit+0x12fd>
  6de089:	mov    0x6d0(%r15),%rax
  6de090:	inc    %rax
  6de093:	je     6de73a <text_column_public_control::edit+0xc7a>
  6de099:	mov    0x2f8(%r15),%ecx
  6de0a0:	cmp    $0xffffffff,%ecx
  6de0a3:	je     6de8a4 <text_column_public_control::edit+0xde4>
  6de0a9:	add    $0x8,%r14
  6de0ad:	inc    %ecx
  6de0af:	mov    %ecx,0x2f8(%r15)
  6de0b6:	movaps 0x100(%rsp),%xmm0
  6de0be:	movups %xmm0,0x2e0(%r15)
  6de0c6:	mov    0x110(%rsp),%rcx
  6de0ce:	mov    %rcx,0x2f0(%r15)
  6de0d5:	mov    %rax,0x6d0(%r15)
  6de0dc:	incq   0x720(%r15)
  6de0e3:	movq   $0x0,0x778(%r15)
  6de0ee:	lea    0x20(%rsp),%rdi
  6de0f3:	lea    0xd0(%rsp),%r8
  6de0fb:	mov    %r15,%rsi
  6de0fe:	mov    %r14,%rdx
  6de101:	xor    %ecx,%ecx
  6de103:	call   6e9560 <<gpui::runtime::RuntimeMut<text_column_public_control::Model, ()>>::after_source_with_editing>
  6de108:	cmpq   $0xfffffffffffffffe,0x20(%rsp)
  6de10e:	je     6de70e <text_column_public_control::edit+0xc4e>
  6de114:	jmp    6de743 <text_column_public_control::edit+0xc83>
  6de119:	test   %cl,%cl
  6de11b:	je     6de615 <text_column_public_control::edit+0xb55>
  6de121:	xor    %eax,%eax
  6de123:	test   $0x1,%r8b
  6de127:	sete   %al
  6de12a:	lea    -0x69d401(%rip),%rcx        # 40d30 <GCC_except_table0+0xee8>
  6de131:	movsd  (%rcx,%rax,8),%xmm0
  6de136:	movsd  %xmm0,0x60(%rsp)
  6de13c:	lea    0x60(%rsp),%rax
  6de141:	movsd  0x60(%rsp),%xmm0
  6de147:	movsd  %xmm0,0x8(%rsp)
  6de14d:	mov    (%r14),%r15
  6de150:	test   %r15,%r15
  6de153:	je     6def03 <text_column_public_control::edit+0x1443>
  6de159:	cmpb   $0x0,0x78e(%r15)
  6de161:	jne    6def1a <text_column_public_control::edit+0x145a>
  6de167:	mov    %rax,0x18(%rsp)
  6de16c:	mov    $0x2,%eax
  6de171:	mov    %rax,0x10(%rsp)
  6de176:	add    $0x8,%r14
  6de17a:	mov    %r14,0x58(%rsp)
  6de17f:	mov    0x6d0(%r15),%rax
  6de186:	mov    %rax,0x120(%rsp)
  6de18e:	movabs $0x300000001,%r12
  6de198:	mov    0x248(%r15),%r13
  6de19f:	mov    0x250(%r15),%rbp
  6de1a6:	shl    $0x4,%rbp
  6de1aa:	xor    %r14d,%r14d
  6de1ad:	nopl   (%rax)
  6de1b0:	cmp    %r14,%rbp
  6de1b3:	je     6decc7 <text_column_public_control::edit+0x1207>
  6de1b9:	mov    0x0(%r13,%r14,1),%rdi
  6de1be:	mov    0x8(%r13,%r14,1),%rax
  6de1c3:	call   *0x18(%rax)
  6de1c6:	add    $0x10,%r14
  6de1ca:	cmp    %r12,%rax
  6de1cd:	jne    6de1b0 <text_column_public_control::edit+0x6f0>
  6de1cf:	mov    -0x10(%r13,%r14,1),%rdi
  6de1d4:	mov    -0x8(%r13,%r14,1),%rax
  6de1d9:	lea    0x290(%r15),%rsi
  6de1e0:	call   *0x28(%rax)
  6de1e3:	mov    %rax,%rdi
  6de1e6:	mov    %rdx,%rax
  6de1e9:	lea    0x345788(%rip),%rdx        # a23978 <__frame_dummy_init_array_entry+0x1988>
  6de1f0:	lea    0x2d0(%r15),%rsi
  6de1f7:	call   *0x20(%rax)
  6de1fa:	mov    %r12,0x68(%rsp)
  6de1ff:	mov    0x68(%rsp),%rcx
  6de204:	mov    %rcx,0xd0(%rsp)
  6de20c:	mov    0x70(%rsp),%rcx
  6de211:	mov    %rcx,0xd8(%rsp)
  6de219:	test   %al,%al
  6de21b:	mov    0x58(%rsp),%rdx
  6de220:	je     6def2f <text_column_public_control::edit+0x146f>
  6de226:	movq   $0x0,0xd0(%rsp)
  6de232:	cmpb   $0x0,0x78e(%r15)
  6de23a:	jne    6def39 <text_column_public_control::edit+0x1479>
  6de240:	mov    0x6d0(%r15),%rax
  6de247:	inc    %rax
  6de24a:	je     6de9ac <text_column_public_control::edit+0xeec>
  6de250:	mov    0x2d8(%r15),%ecx
  6de257:	cmp    $0xffffffff,%ecx
  6de25a:	je     6deb17 <text_column_public_control::edit+0x1057>
  6de260:	inc    %ecx
  6de262:	mov    %ecx,0x2d8(%r15)
  6de269:	movsd  0x8(%rsp),%xmm0
  6de26f:	movsd  %xmm0,0x2d0(%r15)
  6de278:	mov    %rax,0x6d0(%r15)
  6de27f:	incq   0x720(%r15)
  6de286:	movq   $0x0,0x778(%r15)
  6de291:	lea    0x20(%rsp),%rdi
  6de296:	lea    0xd0(%rsp),%r8
  6de29e:	mov    %r15,%rsi
  6de2a1:	mov    %r12,%rcx
  6de2a4:	call   6e9560 <<gpui::runtime::RuntimeMut<text_column_public_control::Model, ()>>::after_source_with_editing>
  6de2a9:	mov    0x20(%rsp),%r13
  6de2ae:	mov    0x28(%rsp),%r14
  6de2b3:	cmp    $0xfffffffffffffffe,%r13
  6de2b7:	jne    6defc5 <text_column_public_control::edit+0x1505>
  6de2bd:	mov    0x40(%rsp),%rax
  6de2c2:	movzbl 0x48(%rsp),%ecx
  6de2c7:	mov    0x49(%rsp),%edx
  6de2cb:	mov    %edx,0x138(%rsp)
  6de2d2:	mov    0x4c(%rsp),%edx
  6de2d6:	mov    %edx,0x13b(%rsp)
  6de2dd:	mov    0x50(%rsp),%rdx
  6de2e2:	movups 0x30(%rsp),%xmm0
  6de2e7:	mov    %r14,(%rbx)
  6de2ea:	movups %xmm0,0x8(%rbx)
  6de2ee:	mov    %rax,0x18(%rbx)
  6de2f2:	mov    %cl,0x20(%rbx)
  6de2f5:	mov    0x138(%rsp),%eax
  6de2fc:	mov    0x13b(%rsp),%ecx
  6de303:	jmp    6de054 <text_column_public_control::edit+0x594>
  6de308:	je     6de631 <text_column_public_control::edit+0xb71>
  6de30e:	mov    %r14,0x58(%rsp)
  6de313:	mov    %ecx,%r14d
  6de316:	mov    0x60(%rsp),%r13
  6de31b:	call   *0x3644e7(%rip)        # a42808 <_DYNAMIC+0x270>
  6de321:	mov    $0x1,%ebp
  6de326:	mov    $0x1,%esi
  6de32b:	mov    %r12,%rdi
  6de32e:	call   *0x3644dc(%rip)        # a42810 <_DYNAMIC+0x278>
  6de334:	test   %rax,%rax
  6de337:	je     6ddb40 <text_column_public_control::edit+0x80>
  6de33d:	mov    %rax,%r15
  6de340:	mov    %rax,%rdi
  6de343:	mov    %r13,%rsi
  6de346:	mov    %r12,%rdx
  6de349:	call   *0x3644d1(%rip)        # a42820 <memcpy@GLIBC_2.14>
  6de34f:	mov    %r14d,%ecx
  6de352:	mov    0x58(%rsp),%r14
  6de357:	test   %cl,%cl
  6de359:	mov    %r12,0x8(%rsp)
  6de35e:	je     6de644 <text_column_public_control::edit+0xb84>
  6de364:	mov    (%r14),%r13
  6de367:	test   %r13,%r13
  6de36a:	mov    %r15,0x10(%rsp)
  6de36f:	je     6def44 <text_column_public_control::edit+0x1484>
  6de375:	cmpb   $0x0,0x78e(%r13)
  6de37d:	jne    6def78 <text_column_public_control::edit+0x14b8>
  6de383:	mov    $0x2,%eax
  6de388:	mov    %rax,0x18(%rsp)
  6de38d:	add    $0x8,%r14
  6de391:	mov    %r14,0x58(%rsp)
  6de396:	mov    0x6d0(%r13),%rax
  6de39d:	mov    %rax,0x120(%rsp)
  6de3a5:	movabs $0x200000001,%r12
  6de3af:	mov    0x248(%r13),%rbp
  6de3b6:	mov    0x250(%r13),%r15
  6de3bd:	shl    $0x4,%r15
  6de3c1:	xor    %r14d,%r14d
  6de3c4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6de3d0:	cmp    %r14,%r15
  6de3d3:	je     6ded10 <text_column_public_control::edit+0x1250>
  6de3d9:	mov    0x0(%rbp,%r14,1),%rdi
  6de3de:	mov    0x8(%rbp,%r14,1),%rax
  6de3e3:	call   *0x18(%rax)
  6de3e6:	add    $0x10,%r14
  6de3ea:	cmp    %r12,%rax
  6de3ed:	jne    6de3d0 <text_column_public_control::edit+0x910>
  6de3ef:	mov    -0x10(%rbp,%r14,1),%rdi
  6de3f4:	mov    -0x8(%rbp,%r14,1),%rax
  6de3f9:	lea    0x290(%r13),%r14
  6de400:	mov    %r14,%rsi
  6de403:	call   *0x28(%rax)
  6de406:	mov    %rax,%rdi
  6de409:	mov    %rdx,%rax
  6de40c:	lea    0x345515(%rip),%rdx        # a23928 <__frame_dummy_init_array_entry+0x1938>
  6de413:	mov    %r14,%rsi
  6de416:	call   *0x20(%rax)
  6de419:	mov    %r12,0x68(%rsp)
  6de41e:	mov    0x68(%rsp),%rcx
  6de423:	mov    %rcx,0xd0(%rsp)
  6de42b:	mov    0x70(%rsp),%rcx
  6de430:	mov    %rcx,0xd8(%rsp)
  6de438:	test   %al,%al
  6de43a:	mov    0x58(%rsp),%r14
  6de43f:	mov    0x10(%rsp),%r15
  6de444:	je     6defbb <text_column_public_control::edit+0x14fb>
  6de44a:	movq   $0x0,0xd0(%rsp)
  6de456:	cmpb   $0x0,0x78e(%r13)
  6de45e:	jne    6def82 <text_column_public_control::edit+0x14c2>
  6de464:	mov    0x6d0(%r13),%r12
  6de46b:	inc    %r12
  6de46e:	je     6deb35 <text_column_public_control::edit+0x1075>
  6de474:	mov    0x2a8(%r13),%eax
  6de47b:	cmp    $0xffffffff,%eax
  6de47e:	je     6dec17 <text_column_public_control::edit+0x1157>
  6de484:	inc    %eax
  6de486:	mov    %eax,0x2a8(%r13)
  6de48d:	mov    0x290(%r13),%rsi
  6de494:	test   %rsi,%rsi
  6de497:	je     6de4ab <text_column_public_control::edit+0x9eb>
  6de499:	mov    0x298(%r13),%rdi
  6de4a0:	mov    $0x1,%edx
  6de4a5:	call   *0x364355(%rip)        # a42800 <_DYNAMIC+0x268>
  6de4ab:	mov    0x8(%rsp),%rax
  6de4b0:	mov    %rax,0x290(%r13)
  6de4b7:	mov    %r15,0x298(%r13)
  6de4be:	mov    %rax,0x2a0(%r13)
  6de4c5:	mov    %r12,0x6d0(%r13)
  6de4cc:	incq   0x720(%r13)
  6de4d3:	movq   $0x0,0x778(%r13)
  6de4de:	mov    $0xffffffffffffffff,%r15
  6de4e5:	lea    0x20(%rsp),%rdi
  6de4ea:	movabs $0x200000001,%rcx
  6de4f4:	lea    0xd0(%rsp),%r8
  6de4fc:	mov    %r13,%rsi
  6de4ff:	mov    %r14,%rdx
  6de502:	call   6e9560 <<gpui::runtime::RuntimeMut<text_column_public_control::Model, ()>>::after_source_with_editing>
  6de507:	mov    0x20(%rsp),%r14
  6de50c:	mov    0x28(%rsp),%rbp
  6de511:	cmp    $0xfffffffffffffffe,%r14
  6de515:	jne    6df030 <text_column_public_control::edit+0x1570>
  6de51b:	mov    0x40(%rsp),%rax
  6de520:	movzbl 0x48(%rsp),%ecx
  6de525:	mov    0x49(%rsp),%edx
  6de529:	movzwl 0x4d(%rsp),%esi
  6de52e:	movzbl 0x4f(%rsp),%edi
  6de533:	mov    0x50(%rsp),%r8
  6de538:	movups 0x30(%rsp),%xmm0
  6de53d:	mov    %rbp,(%rbx)
  6de540:	movups %xmm0,0x8(%rbx)
  6de544:	mov    %rax,0x18(%rbx)
  6de548:	mov    %cl,0x20(%rbx)
  6de54b:	mov    %dil,0x27(%rbx)
  6de54f:	mov    %si,0x25(%rbx)
  6de553:	mov    %edx,0x21(%rbx)
  6de556:	mov    %r8,0x28(%rbx)
  6de55a:	jmp    6de728 <text_column_public_control::edit+0xc68>
  6de55f:	mov    (%r14),%r15
  6de562:	test   %r15,%r15
  6de565:	je     6dee98 <text_column_public_control::edit+0x13d8>
  6de56b:	movq   $0x0,0xd0(%rsp)
  6de577:	cmpb   $0x1,0x78e(%r15)
  6de57f:	je     6deeba <text_column_public_control::edit+0x13fa>
  6de585:	mov    0x6d0(%r15),%rax
  6de58c:	inc    %rax
  6de58f:	je     6de8e0 <text_column_public_control::edit+0xe20>
  6de595:	mov    0x2c8(%r15),%ecx
  6de59c:	cmp    $0xffffffff,%ecx
  6de59f:	je     6de956 <text_column_public_control::edit+0xe96>
  6de5a5:	add    $0x8,%r14
  6de5a9:	inc    %ecx
  6de5ab:	mov    %ecx,0x2c8(%r15)
  6de5b2:	movups 0x100(%rsp),%xmm0
  6de5ba:	movups %xmm0,0x2b0(%r15)
  6de5c2:	mov    0x110(%rsp),%rcx
  6de5ca:	mov    %rcx,0x2c0(%r15)
  6de5d1:	mov    %rax,0x6d0(%r15)
  6de5d8:	incq   0x720(%r15)
  6de5df:	movq   $0x0,0x778(%r15)
  6de5ea:	lea    0x20(%rsp),%rdi
  6de5ef:	lea    0xd0(%rsp),%r8
  6de5f7:	mov    %r15,%rsi
  6de5fa:	mov    %r14,%rdx
  6de5fd:	xor    %ecx,%ecx
  6de5ff:	call   6e9560 <<gpui::runtime::RuntimeMut<text_column_public_control::Model, ()>>::after_source_with_editing>
  6de604:	cmpq   $0xfffffffffffffffe,0x20(%rsp)
  6de60a:	je     6de70e <text_column_public_control::edit+0xc4e>
  6de610:	jmp    6de8e9 <text_column_public_control::edit+0xe29>
  6de615:	mov    $0x8000,%eax
  6de61a:	test   $0x1,%r8b
  6de61e:	jne    6ddb5b <text_column_public_control::edit+0x9b>
  6de624:	movsd  -0x69cd0c(%rip),%xmm0        # 41920 <GCC_except_table0+0x1ad8>
  6de62c:	jmp    6ddb63 <text_column_public_control::edit+0xa3>
  6de631:	mov    $0x1,%r15d
  6de637:	test   %cl,%cl
  6de639:	mov    %r12,0x8(%rsp)
  6de63e:	jne    6de364 <text_column_public_control::edit+0x8a4>
  6de644:	mov    (%r14),%r13
  6de647:	test   %r13,%r13
  6de64a:	je     6def5b <text_column_public_control::edit+0x149b>
  6de650:	movq   $0x0,0xd0(%rsp)
  6de65c:	cmpb   $0x0,0x78e(%r13)
  6de664:	jne    6def8d <text_column_public_control::edit+0x14cd>
  6de66a:	mov    0x6d0(%r13),%r12
  6de671:	inc    %r12
  6de674:	je     6dea9f <text_column_public_control::edit+0xfdf>
  6de67a:	mov    0x2a8(%r13),%eax
  6de681:	cmp    $0xffffffff,%eax
  6de684:	je     6debf9 <text_column_public_control::edit+0x1139>
  6de68a:	add    $0x8,%r14
  6de68e:	inc    %eax
  6de690:	mov    %eax,0x2a8(%r13)
  6de697:	mov    0x290(%r13),%rsi
  6de69e:	test   %rsi,%rsi
  6de6a1:	je     6de6b5 <text_column_public_control::edit+0xbf5>
  6de6a3:	mov    0x298(%r13),%rdi
  6de6aa:	mov    $0x1,%edx
  6de6af:	call   *0x36414b(%rip)        # a42800 <_DYNAMIC+0x268>
  6de6b5:	mov    0x8(%rsp),%rax
  6de6ba:	mov    %rax,0x290(%r13)
  6de6c1:	mov    %r15,0x298(%r13)
  6de6c8:	mov    %rax,0x2a0(%r13)
  6de6cf:	mov    %r12,0x6d0(%r13)
  6de6d6:	incq   0x720(%r13)
  6de6dd:	movq   $0x0,0x778(%r13)
  6de6e8:	lea    0x20(%rsp),%rdi
  6de6ed:	lea    0xd0(%rsp),%r8
  6de6f5:	mov    %r13,%rsi
  6de6f8:	mov    %r14,%rdx
  6de6fb:	xor    %ecx,%ecx
  6de6fd:	call   6e9560 <<gpui::runtime::RuntimeMut<text_column_public_control::Model, ()>>::after_source_with_editing>
  6de702:	cmpq   $0xfffffffffffffffe,0x20(%rsp)
  6de708:	jne    6deab5 <text_column_public_control::edit+0xff5>
  6de70e:	movups 0x28(%rsp),%xmm0
  6de713:	movups 0x38(%rsp),%xmm1
  6de718:	movups 0x48(%rsp),%xmm2
  6de71d:	movups %xmm2,0x20(%rbx)
  6de721:	movups %xmm1,0x10(%rbx)
  6de725:	movups %xmm0,(%rbx)
  6de728:	add    $0x158,%rsp
  6de72f:	pop    %rbx
  6de730:	pop    %r12
  6de732:	pop    %r13
  6de734:	pop    %r14
  6de736:	pop    %r15
  6de738:	pop    %rbp
  6de739:	ret
  6de73a:	movq   $0x1f,0x20(%rsp)
  6de743:	mov    0x50(%rsp),%rax
  6de748:	mov    %rax,0x90(%rsp)
  6de750:	mov    0x20(%rsp),%rax
  6de755:	mov    0x28(%rsp),%rcx
  6de75a:	movups 0x30(%rsp),%xmm0
  6de75f:	movups 0x40(%rsp),%xmm1
  6de764:	movaps %xmm1,0x80(%rsp)
  6de76c:	movaps %xmm0,0x70(%rsp)
  6de771:	mov    %rax,0x60(%rsp)
  6de776:	mov    %rcx,0x68(%rsp)
  6de77b:	lea    -0x690fab(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6de782:	lea    0x344a9f(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6de789:	lea    0x344590(%rip),%r8        # a22d20 <__frame_dummy_init_array_entry+0xd30>
  6de790:	lea    0x60(%rsp),%rdx
  6de795:	mov    $0x2b,%esi
  6de79a:	call   *0x364038(%rip)        # a427d8 <_DYNAMIC+0x240>
  6de7a0:	jmp    6df7f2 <text_column_public_control::edit+0x1d32>
  6de7a5:	mov    $0x1f,%r13d
  6de7ab:	movzbl 0x18(%rsp),%r12d
  6de7b1:	mov    0x30(%rsp),%r8
  6de7b6:	mov    0x38(%rsp),%r9
  6de7bb:	mov    0xc8(%rsp),%ecx
  6de7c2:	mov    0xcb(%rsp),%edx
  6de7c9:	mov    %edx,0x12b(%rsp)
  6de7d0:	mov    %ecx,0x128(%rsp)
  6de7d7:	mov    $0x2,%esi
  6de7dc:	mov    %rsi,0x60(%rsp)
  6de7e1:	mov    %r13,0x68(%rsp)
  6de7e6:	mov    %rax,0x70(%rsp)
  6de7eb:	mov    %r8,0x78(%rsp)
  6de7f0:	mov    %r9,0x80(%rsp)
  6de7f8:	mov    %dil,0x88(%rsp)
  6de800:	mov    0x130(%rsp),%eax
  6de807:	mov    0x133(%rsp),%esi
  6de80e:	mov    %eax,0x89(%rsp)
  6de815:	mov    %esi,0x8c(%rsp)
  6de81c:	mov    %r11,0x90(%rsp)
  6de824:	mov    %r10,0x98(%rsp)
  6de82c:	mov    0x8(%rsp),%rax
  6de831:	mov    %rax,0xa0(%rsp)
  6de839:	mov    0x10(%rsp),%rax
  6de83e:	mov    %rax,0xa8(%rsp)
  6de846:	mov    %r12b,0xb0(%rsp)
  6de84e:	mov    0x128(%rsp),%eax
  6de855:	mov    0x12b(%rsp),%esi
  6de85c:	mov    %eax,0xb1(%rsp)
  6de863:	mov    %esi,0xb4(%rsp)
  6de86a:	mov    %rcx,0xb8(%rsp)
  6de872:	mov    %rdx,0xc0(%rsp)
  6de87a:	lea    -0x6910aa(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6de881:	lea    0x344a00(%rip),%rcx        # a23288 <__frame_dummy_init_array_entry+0x1298>
  6de888:	lea    0x3444d1(%rip),%r8        # a22d60 <__frame_dummy_init_array_entry+0xd70>
  6de88f:	lea    0x60(%rsp),%rdx
  6de894:	mov    $0x2b,%esi
  6de899:	call   *0x363f39(%rip)        # a427d8 <_DYNAMIC+0x240>
  6de89f:	jmp    6df7f2 <text_column_public_control::edit+0x1d32>
  6de8a4:	lea    -0x68e0dd(%rip),%rdi        # 507ce <GCC_except_table0+0x10986>
  6de8ab:	lea    0x345b7e(%rip),%rdx        # a24430 <__frame_dummy_init_array_entry+0x2440>
  6de8b2:	mov    $0x19,%esi
  6de8b7:	call   *0x3640e3(%rip)        # a429a0 <_DYNAMIC+0x408>
  6de8bd:	jmp    6df7f2 <text_column_public_control::edit+0x1d32>
  6de8c2:	lea    -0x68e0fb(%rip),%rdi        # 507ce <GCC_except_table0+0x10986>
  6de8c9:	lea    0x345b60(%rip),%rdx        # a24430 <__frame_dummy_init_array_entry+0x2440>
  6de8d0:	mov    $0x19,%esi
  6de8d5:	call   *0x3640c5(%rip)        # a429a0 <_DYNAMIC+0x408>
  6de8db:	jmp    6df7f2 <text_column_public_control::edit+0x1d32>
  6de8e0:	movq   $0x1f,0x20(%rsp)
  6de8e9:	mov    0x50(%rsp),%rax
  6de8ee:	mov    %rax,0x90(%rsp)
  6de8f6:	mov    0x20(%rsp),%rax
  6de8fb:	mov    0x28(%rsp),%rcx
  6de900:	movups 0x30(%rsp),%xmm0
  6de905:	movups 0x40(%rsp),%xmm1
  6de90a:	movaps %xmm1,0x80(%rsp)
  6de912:	movaps %xmm0,0x70(%rsp)
  6de917:	mov    %rax,0x60(%rsp)
  6de91c:	mov    %rcx,0x68(%rsp)
  6de921:	lea    -0x691151(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6de928:	lea    0x3448f9(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6de92f:	lea    0x3444da(%rip),%r8        # a22e10 <__frame_dummy_init_array_entry+0xe20>
  6de936:	lea    0x60(%rsp),%rdx
  6de93b:	mov    $0x2b,%esi
  6de940:	call   *0x363e92(%rip)        # a427d8 <_DYNAMIC+0x240>
  6de946:	jmp    6df7f2 <text_column_public_control::edit+0x1d32>
  6de94b:	mov    $0x1f,%r13d
  6de951:	jmp    6df602 <text_column_public_control::edit+0x1b42>
  6de956:	lea    -0x68e18f(%rip),%rdi        # 507ce <GCC_except_table0+0x10986>
  6de95d:	lea    0x345acc(%rip),%rdx        # a24430 <__frame_dummy_init_array_entry+0x2440>
  6de964:	mov    $0x19,%esi
  6de969:	call   *0x364031(%rip)        # a429a0 <_DYNAMIC+0x408>
  6de96f:	jmp    6df7f2 <text_column_public_control::edit+0x1d32>
  6de974:	lea    0x345ab5(%rip),%rdx        # a24430 <__frame_dummy_init_array_entry+0x2440>
  6de97b:	mov    $0x19,%esi
  6de980:	lea    -0x68e1b9(%rip),%rdi        # 507ce <GCC_except_table0+0x10986>
  6de987:	jmp    6de9a1 <text_column_public_control::edit+0xee1>
  6de989:	lea    0x343c88(%rip),%rdx        # a22618 <__frame_dummy_init_array_entry+0x628>
  6de990:	mov    $0x1b,%esi
  6de995:	lea    -0x6914cd(%rip),%rdi        # 4d4cf <GCC_except_table0+0xd687>
  6de99c:	movb   $0x2,0x8(%rsp)
  6de9a1:	call   *0x363ff9(%rip)        # a429a0 <_DYNAMIC+0x408>
  6de9a7:	jmp    6df7f2 <text_column_public_control::edit+0x1d32>
  6de9ac:	mov    $0x1f,%r13d
  6de9b2:	movsd  0x30(%rsp),%xmm0
  6de9b8:	mov    0x38(%rsp),%r9
  6de9bd:	mov    0x60(%rsp),%ecx
  6de9c1:	mov    0x63(%rsp),%edx
  6de9c5:	mov    %ecx,0xd0(%rsp)
  6de9cc:	mov    %edx,0xd3(%rsp)
  6de9d3:	mov    0x10(%rsp),%rbx
  6de9d8:	mov    %rbx,0x60(%rsp)
  6de9dd:	mov    %r13,0x68(%rsp)
  6de9e2:	mov    %rax,0x70(%rsp)
  6de9e7:	movsd  %xmm0,0x78(%rsp)
  6de9ed:	mov    %r9,0x80(%rsp)
  6de9f5:	mov    %r8b,0x88(%rsp)
  6de9fd:	mov    0x138(%rsp),%eax
  6dea04:	mov    0x13b(%rsp),%r8d
  6dea0c:	mov    %eax,0x89(%rsp)
  6dea13:	mov    %r8d,0x8c(%rsp)
  6dea1b:	mov    %r10,0x90(%rsp)
  6dea23:	mov    %r11,0x98(%rsp)
  6dea2b:	movsd  0x8(%rsp),%xmm0
  6dea31:	movsd  %xmm0,0xa0(%rsp)
  6dea3a:	mov    %rdi,0xa8(%rsp)
  6dea42:	mov    %cl,0xb0(%rsp)
  6dea49:	mov    0xd0(%rsp),%eax
  6dea50:	mov    0xd3(%rsp),%ecx
  6dea57:	mov    %eax,0xb1(%rsp)
  6dea5e:	mov    %ecx,0xb4(%rsp)
  6dea65:	mov    %rdx,0xb8(%rsp)
  6dea6d:	mov    %rsi,0xc0(%rsp)
  6dea75:	lea    -0x6912a5(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6dea7c:	lea    0x344825(%rip),%rcx        # a232a8 <__frame_dummy_init_array_entry+0x12b8>
  6dea83:	lea    0x34436e(%rip),%r8        # a22df8 <__frame_dummy_init_array_entry+0xe08>
  6dea8a:	lea    0x60(%rsp),%rdx
  6dea8f:	mov    $0x2b,%esi
  6dea94:	call   *0x363d3e(%rip)        # a427d8 <_DYNAMIC+0x240>
  6dea9a:	jmp    6df7f2 <text_column_public_control::edit+0x1d32>
  6dea9f:	mov    $0x1f,%eax
  6deaa4:	mov    %rax,0x20(%rsp)
  6deaa9:	cmpq   $0x0,0x8(%rsp)
  6deaaf:	jne    6defa3 <text_column_public_control::edit+0x14e3>
  6deab5:	mov    0x50(%rsp),%rax
  6deaba:	mov    %rax,0x90(%rsp)
  6deac2:	mov    0x20(%rsp),%rax
  6deac7:	mov    0x28(%rsp),%rcx
  6deacc:	movups 0x30(%rsp),%xmm0
  6dead1:	movups 0x40(%rsp),%xmm1
  6dead6:	movaps %xmm1,0x80(%rsp)
  6deade:	movaps %xmm0,0x70(%rsp)
  6deae3:	mov    %rax,0x60(%rsp)
  6deae8:	mov    %rcx,0x68(%rsp)
  6deaed:	lea    -0x69131d(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6deaf4:	lea    0x34472d(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6deafb:	lea    0x344276(%rip),%r8        # a22d78 <__frame_dummy_init_array_entry+0xd88>
  6deb02:	lea    0x60(%rsp),%rdx
  6deb07:	mov    $0x2b,%esi
  6deb0c:	call   *0x363cc6(%rip)        # a427d8 <_DYNAMIC+0x240>
  6deb12:	jmp    6df7f2 <text_column_public_control::edit+0x1d32>
  6deb17:	lea    -0x68e350(%rip),%rdi        # 507ce <GCC_except_table0+0x10986>
  6deb1e:	lea    0x34590b(%rip),%rdx        # a24430 <__frame_dummy_init_array_entry+0x2440>
  6deb25:	mov    $0x19,%esi
  6deb2a:	call   *0x363e70(%rip)        # a429a0 <_DYNAMIC+0x408>
  6deb30:	jmp    6df7f2 <text_column_public_control::edit+0x1d32>
  6deb35:	mov    $0x1f,%r14d
  6deb3b:	mov    0x8(%rsp),%r12
  6deb40:	mov    0x18(%rsp),%r15
  6deb45:	mov    %r15,0x60(%rsp)
  6deb4a:	mov    %r14,0x68(%rsp)
  6deb4f:	mov    %rsi,0x70(%rsp)
  6deb54:	mov    %r9,0x78(%rsp)
  6deb59:	mov    %rdi,0x80(%rsp)
  6deb61:	mov    %r8b,0x88(%rsp)
  6deb69:	mov    %r11d,0x89(%rsp)
  6deb71:	mov    %r11,%rsi
  6deb74:	shr    $0x30,%rsi
  6deb78:	mov    %sil,0x8f(%rsp)
  6deb80:	shr    $0x20,%r11
  6deb84:	mov    %r11w,0x8d(%rsp)
  6deb8d:	mov    %rbx,0x90(%rsp)
  6deb95:	mov    %r10,0x98(%rsp)
  6deb9d:	mov    %r12,0xa0(%rsp)
  6deba5:	mov    0x10(%rsp),%rdx
  6debaa:	mov    %rdx,0xa8(%rsp)
  6debb2:	mov    0x8(%rsp),%rdx
  6debb7:	mov    %rdx,0xb0(%rsp)
  6debbf:	mov    %rcx,0xb8(%rsp)
  6debc7:	mov    %rax,0xc0(%rsp)
  6debcf:	lea    -0x6913ff(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6debd6:	lea    0x34468b(%rip),%rcx        # a23268 <__frame_dummy_init_array_entry+0x1278>
  6debdd:	lea    0x3441d4(%rip),%r8        # a22db8 <__frame_dummy_init_array_entry+0xdc8>
  6debe4:	lea    0x60(%rsp),%rdx
  6debe9:	mov    $0x2b,%esi
  6debee:	call   *0x363be4(%rip)        # a427d8 <_DYNAMIC+0x240>
  6debf4:	jmp    6df7f2 <text_column_public_control::edit+0x1d32>
  6debf9:	lea    -0x68e432(%rip),%rdi        # 507ce <GCC_except_table0+0x10986>
  6dec00:	lea    0x345829(%rip),%rdx        # a24430 <__frame_dummy_init_array_entry+0x2440>
  6dec07:	mov    $0x19,%esi
  6dec0c:	call   *0x363d8e(%rip)        # a429a0 <_DYNAMIC+0x408>
  6dec12:	jmp    6df7f2 <text_column_public_control::edit+0x1d32>
  6dec17:	lea    -0x68e450(%rip),%rdi        # 507ce <GCC_except_table0+0x10986>
  6dec1e:	lea    0x34580b(%rip),%rdx        # a24430 <__frame_dummy_init_array_entry+0x2440>
  6dec25:	mov    $0x19,%esi
  6dec2a:	call   *0x363d70(%rip)        # a429a0 <_DYNAMIC+0x408>
  6dec30:	jmp    6df7f2 <text_column_public_control::edit+0x1d32>
  6dec35:	mov    %r12,0x68(%rsp)
  6dec3a:	mov    0x68(%rsp),%rax
  6dec3f:	mov    %rax,0xd0(%rsp)
  6dec47:	mov    0x70(%rsp),%rax
  6dec4c:	mov    %rax,0xd8(%rsp)
  6dec54:	mov    $0xb,%eax
  6dec59:	mov    0xd0(%rsp),%rcx
  6dec61:	mov    %rcx,0x30(%rsp)
  6dec66:	mov    0xd8(%rsp),%rcx
  6dec6e:	mov    %rcx,0x38(%rsp)
  6dec73:	mov    $0x20,%r13d
  6dec79:	jmp    6de7ab <text_column_public_control::edit+0xceb>
  6dec7e:	mov    %r12,0x68(%rsp)
  6dec83:	mov    0x68(%rsp),%rax
  6dec88:	mov    %rax,0xd0(%rsp)
  6dec90:	mov    0x70(%rsp),%rax
  6dec95:	mov    %rax,0xd8(%rsp)
  6dec9d:	mov    $0xb,%eax
  6deca2:	mov    0xd0(%rsp),%rcx
  6decaa:	mov    %rcx,0x30(%rsp)
  6decaf:	mov    0xd8(%rsp),%rcx
  6decb7:	mov    %rcx,0x38(%rsp)
  6decbc:	mov    $0x20,%r13d
  6decc2:	jmp    6df602 <text_column_public_control::edit+0x1b42>
  6decc7:	mov    %r12,0x68(%rsp)
  6deccc:	mov    0x68(%rsp),%rax
  6decd1:	mov    %rax,0xd0(%rsp)
  6decd9:	mov    0x70(%rsp),%rax
  6decde:	mov    %rax,0xd8(%rsp)
  6dece6:	mov    $0xb,%eax
  6deceb:	mov    0xd0(%rsp),%rcx
  6decf3:	mov    %rcx,0x30(%rsp)
  6decf8:	mov    0xd8(%rsp),%rcx
  6ded00:	mov    %rcx,0x38(%rsp)
  6ded05:	mov    $0x20,%r13d
  6ded0b:	jmp    6de9b2 <text_column_public_control::edit+0xef2>
  6ded10:	mov    %r12,0x68(%rsp)
  6ded15:	mov    0x68(%rsp),%rax
  6ded1a:	mov    %rax,0xd0(%rsp)
  6ded22:	mov    0x70(%rsp),%rax
  6ded27:	mov    %rax,0xd8(%rsp)
  6ded2f:	mov    $0xb,%esi
  6ded34:	mov    0xd0(%rsp),%rax
  6ded3c:	mov    %rax,0x30(%rsp)
  6ded41:	mov    0xd8(%rsp),%rax
  6ded49:	mov    %rax,0x38(%rsp)
  6ded4e:	mov    0x30(%rsp),%r9
  6ded53:	mov    0x38(%rsp),%rdi
  6ded58:	mov    $0x20,%r14d
  6ded5e:	mov    0x8(%rsp),%r12
  6ded63:	jmp    6deb40 <text_column_public_control::edit+0x1080>
  6ded68:	lea    0x111(%rsp),%rax
  6ded70:	mov    (%rax),%ecx
  6ded72:	mov    0x3(%rax),%eax
  6ded75:	mov    %eax,0x12b(%rsp)
  6ded7c:	mov    %ecx,0x128(%rsp)
  6ded83:	mov    $0xd,%r13d
  6ded89:	xor    %eax,%eax
  6ded8b:	mov    $0x2,%esi
  6ded90:	jmp    6de7dc <text_column_public_control::edit+0xd1c>
  6ded95:	movq   $0xd,0x20(%rsp)
  6ded9e:	movq   $0x0,0x28(%rsp)
  6deda7:	jmp    6de743 <text_column_public_control::edit+0xc83>
  6dedac:	mov    $0xe,%r13d
  6dedb2:	movzbl 0x18(%rsp),%r12d
  6dedb8:	jmp    6de7bb <text_column_public_control::edit+0xcfb>
  6dedbd:	movq   $0xe,0x20(%rsp)
  6dedc6:	jmp    6de743 <text_column_public_control::edit+0xc83>
  6dedcb:	mov    $0xa,%eax
  6dedd0:	jmp    6dec59 <text_column_public_control::edit+0x1199>
  6dedd5:	mov    $0xe,%r13d
  6deddb:	jmp    6de7ab <text_column_public_control::edit+0xceb>
  6dede0:	movzbl 0x40(%rsp),%r12d
  6dede6:	mov    0x48(%rsp),%rcx
  6dedeb:	mov    0x50(%rsp),%rdx
  6dedf0:	mov    0x30(%rsp),%rax
  6dedf5:	mov    %rax,0x8(%rsp)
  6dedfa:	mov    0x38(%rsp),%rax
  6dedff:	mov    %rax,0x10(%rsp)
  6dee04:	lea    0x41(%rsp),%rbx
  6dee09:	mov    0x6d0(%r15),%rax
  6dee10:	cmp    0x120(%rsp),%rax
  6dee18:	jne    6dee42 <text_column_public_control::edit+0x1382>
  6dee1a:	mov    $0x4,%esi
  6dee1f:	lea    0x130(%rsp),%r15
  6dee27:	mov    %rdx,%r10
  6dee2a:	mov    %rcx,%r11
  6dee2d:	mov    %r14,%rax
  6dee30:	mov    0x8(%rsp),%r8
  6dee35:	mov    0x10(%rsp),%r9
  6dee3a:	mov    %r12d,%edi
  6dee3d:	jmp    6df0b9 <text_column_public_control::edit+0x15f9>
  6dee42:	movzbl 0x78c(%r15),%edi
  6dee4a:	cmpq   $0x0,0x6f0(%r15)
  6dee52:	je     6dee6b <text_column_public_control::edit+0x13ab>
  6dee54:	test   %dil,%dil
  6dee57:	je     6df08e <text_column_public_control::edit+0x15ce>
  6dee5d:	cmpq   $0xffffffffffffffff,0x5f8(%r15)
  6dee65:	jne    6df08e <text_column_public_control::edit+0x15ce>
  6dee6b:	xor    %esi,%esi
  6dee6d:	jmp    6df09a <text_column_public_control::edit+0x15da>
  6dee72:	mov    (%rax),%ecx
  6dee74:	mov    0x3(%rax),%eax
  6dee77:	mov    %eax,0x143(%rsp)
  6dee7e:	mov    %ecx,0x140(%rsp)
  6dee85:	mov    $0xd,%r13d
  6dee8b:	mov    $0x2,%r9d
  6dee91:	xor    %eax,%eax
  6dee93:	jmp    6df71e <text_column_public_control::edit+0x1c5e>
  6dee98:	movq   $0xd,0x20(%rsp)
  6deea1:	movq   $0x0,0x28(%rsp)
  6deeaa:	jmp    6de8e9 <text_column_public_control::edit+0xe29>
  6deeaf:	mov    $0xe,%r13d
  6deeb5:	jmp    6df60c <text_column_public_control::edit+0x1b4c>
  6deeba:	movq   $0xe,0x20(%rsp)
  6deec3:	jmp    6de8e9 <text_column_public_control::edit+0xe29>
  6deec8:	mov    $0xa,%eax
  6deecd:	jmp    6deca2 <text_column_public_control::edit+0x11e2>
  6deed2:	mov    $0xe,%r13d
  6deed8:	jmp    6df602 <text_column_public_control::edit+0x1b42>
  6deedd:	movzbl 0x40(%rsp),%esi
  6deee2:	mov    0x48(%rsp),%rcx
  6deee7:	mov    %rcx,0x148(%rsp)
  6deeef:	movb   $0x2,0x8(%rsp)
  6deef4:	mov    0x50(%rsp),%rcx
  6deef9:	mov    %rcx,0x58(%rsp)
  6deefe:	jmp    6df602 <text_column_public_control::edit+0x1b42>
  6def03:	mov    $0x2,%eax
  6def08:	mov    %rax,0x10(%rsp)
  6def0d:	mov    $0xd,%r13d
  6def13:	xor    %eax,%eax
  6def15:	jmp    6de9d3 <text_column_public_control::edit+0xf13>
  6def1a:	mov    $0x2,%eax
  6def1f:	mov    %rax,0x10(%rsp)
  6def24:	mov    $0xe,%r13d
  6def2a:	jmp    6de9bd <text_column_public_control::edit+0xefd>
  6def2f:	mov    $0xa,%eax
  6def34:	jmp    6deceb <text_column_public_control::edit+0x122b>
  6def39:	mov    $0xe,%r13d
  6def3f:	jmp    6de9b2 <text_column_public_control::edit+0xef2>
  6def44:	mov    $0x2,%eax
  6def49:	mov    %rax,0x18(%rsp)
  6def4e:	mov    $0xd,%r14d
  6def54:	xor    %esi,%esi
  6def56:	jmp    6deb40 <text_column_public_control::edit+0x1080>
  6def5b:	movq   $0xd,0x20(%rsp)
  6def64:	movq   $0x0,0x28(%rsp)
  6def6d:	test   %r12,%r12
  6def70:	je     6deab5 <text_column_public_control::edit+0xff5>
  6def76:	jmp    6defa3 <text_column_public_control::edit+0x14e3>
  6def78:	mov    $0x2,%eax
  6def7d:	mov    %rax,0x18(%rsp)
  6def82:	mov    $0xe,%r14d
  6def88:	jmp    6deb3b <text_column_public_control::edit+0x107b>
  6def8d:	mov    $0xe,%eax
  6def92:	mov    %rax,0x20(%rsp)
  6def97:	cmpq   $0x0,0x8(%rsp)
  6def9d:	je     6deab5 <text_column_public_control::edit+0xff5>
  6defa3:	mov    $0x1,%edx
  6defa8:	mov    %r15,%rdi
  6defab:	mov    0x8(%rsp),%rsi
  6defb0:	call   *0x36384a(%rip)        # a42800 <_DYNAMIC+0x268>
  6defb6:	jmp    6deab5 <text_column_public_control::edit+0xff5>
  6defbb:	mov    $0xa,%esi
  6defc0:	jmp    6ded34 <text_column_public_control::edit+0x1274>
  6defc5:	movzbl 0x40(%rsp),%ecx
  6defca:	mov    0x48(%rsp),%rdx
  6defcf:	mov    0x50(%rsp),%rsi
  6defd4:	movsd  0x30(%rsp),%xmm0
  6defda:	movsd  %xmm0,0x8(%rsp)
  6defe0:	mov    0x38(%rsp),%rdi
  6defe5:	lea    0x41(%rsp),%rbx
  6defea:	mov    0x6d0(%r15),%rax
  6deff1:	cmp    0x120(%rsp),%rax
  6deff9:	jne    6df0ca <text_column_public_control::edit+0x160a>
  6defff:	mov    $0x4,%eax
  6df004:	mov    %rax,0x10(%rsp)
  6df009:	lea    0x138(%rsp),%rax
  6df011:	mov    %rax,0x18(%rsp)
  6df016:	mov    %rdx,%r10
  6df019:	mov    %rsi,%r11
  6df01c:	mov    %r14,%rax
  6df01f:	movsd  0x8(%rsp),%xmm0
  6df025:	mov    %rdi,%r9
  6df028:	mov    %ecx,%r8d
  6df02b:	jmp    6df14d <text_column_public_control::edit+0x168d>
  6df030:	mov    0x40(%rsp),%rax
  6df035:	mov    %rax,0x8(%rsp)
  6df03a:	mov    0x48(%rsp),%rcx
  6df03f:	mov    0x50(%rsp),%rax
  6df044:	mov    0x30(%rsp),%r12
  6df049:	mov    0x38(%rsp),%rdi
  6df04e:	mov    0x6d0(%r13),%rsi
  6df055:	cmp    0x120(%rsp),%rsi
  6df05d:	jne    6df0f6 <text_column_public_control::edit+0x1636>
  6df063:	mov    0x8(%rsp),%rsi
  6df068:	mov    %rsi,%r11
  6df06b:	shr    $0x8,%r11
  6df06f:	mov    $0x4,%r8d
  6df075:	mov    %r8,0x18(%rsp)
  6df07a:	mov    %rax,%r10
  6df07d:	mov    %rcx,%rbx
  6df080:	mov    %esi,%r8d
  6df083:	mov    %r12,%r9
  6df086:	mov    %rbp,%rsi
  6df089:	jmp    6deb40 <text_column_public_control::edit+0x1080>
  6df08e:	mov    0x700(%r15),%rbp
  6df095:	mov    $0x1,%esi
  6df09a:	mov    0x6d8(%r15),%r8
  6df0a1:	mov    0x778(%r15),%r9
  6df0a8:	lea    0x128(%rsp),%r15
  6df0b0:	mov    %r14,%r10
  6df0b3:	mov    %r13,%r11
  6df0b6:	mov    %rbp,%r13
  6df0b9:	mov    (%rbx),%ebp
  6df0bb:	mov    0x3(%rbx),%ebx
  6df0be:	mov    %ebx,0x3(%r15)
  6df0c2:	mov    %ebp,(%r15)
  6df0c5:	jmp    6de7dc <text_column_public_control::edit+0xd1c>
  6df0ca:	movzbl 0x78c(%r15),%r8d
  6df0d2:	cmpq   $0x0,0x6f0(%r15)
  6df0da:	je     6df0eb <text_column_public_control::edit+0x162b>
  6df0dc:	test   %r8b,%r8b
  6df0df:	je     6df122 <text_column_public_control::edit+0x1662>
  6df0e1:	cmpq   $0xffffffffffffffff,0x5f8(%r15)
  6df0e9:	jne    6df122 <text_column_public_control::edit+0x1662>
  6df0eb:	movq   $0x0,0x10(%rsp)
  6df0f4:	jmp    6df134 <text_column_public_control::edit+0x1674>
  6df0f6:	movzbl 0x78c(%r13),%r8d
  6df0fe:	cmpq   $0x0,0x6f0(%r13)
  6df106:	je     6df117 <text_column_public_control::edit+0x1657>
  6df108:	test   %r8b,%r8b
  6df10b:	je     6df179 <text_column_public_control::edit+0x16b9>
  6df10d:	cmpq   $0xffffffffffffffff,0x5f8(%r13)
  6df115:	jne    6df179 <text_column_public_control::edit+0x16b9>
  6df117:	movq   $0x0,0x18(%rsp)
  6df120:	jmp    6df18b <text_column_public_control::edit+0x16cb>
  6df122:	mov    0x700(%r15),%r12
  6df129:	mov    $0x1,%r9d
  6df12f:	mov    %r9,0x10(%rsp)
  6df134:	movsd  0x6d8(%r15),%xmm0
  6df13d:	mov    0x778(%r15),%r9
  6df144:	mov    %r13,%r10
  6df147:	mov    %r14,%r11
  6df14a:	mov    %r12,%r13
  6df14d:	mov    (%rbx),%ebp
  6df14f:	mov    0x3(%rbx),%ebx
  6df152:	mov    0x18(%rsp),%r14
  6df157:	mov    %ebx,0x3(%r14)
  6df15b:	mov    %ebp,(%r14)
  6df15e:	mov    0x60(%rsp),%ebx
  6df162:	mov    0x63(%rsp),%ebp
  6df166:	mov    %ebp,0xd3(%rsp)
  6df16d:	mov    %ebx,0xd0(%rsp)
  6df174:	jmp    6de9d3 <text_column_public_control::edit+0xf13>
  6df179:	mov    0x700(%r13),%r15
  6df180:	mov    $0x1,%r9d
  6df186:	mov    %r9,0x18(%rsp)
  6df18b:	mov    0x6d8(%r13),%r9
  6df192:	mov    %rdi,0x10(%rsp)
  6df197:	mov    0x778(%r13),%rdi
  6df19e:	mov    %rbp,%r10
  6df1a1:	mov    %r14,%rbx
  6df1a4:	mov    %r15,%r14
  6df1a7:	jmp    6deb40 <text_column_public_control::edit+0x1080>
  6df1ac:	jmp    6df1bd <text_column_public_control::edit+0x16fd>
  6df1ae:	jmp    6df256 <text_column_public_control::edit+0x1796>
  6df1b3:	jmp    6df2d8 <text_column_public_control::edit+0x1818>
  6df1b8:	jmp    6df353 <text_column_public_control::edit+0x1893>
  6df1bd:	mov    %rax,%rdi
  6df1c0:	call   *0x3638b2(%rip)        # a42a78 <_DYNAMIC+0x4e0>
  6df1c6:	mov    %rax,%r15
  6df1c9:	mov    %rdx,%rbp
  6df1cc:	mov    %rax,0x68(%rsp)
  6df1d1:	mov    %rdx,0x70(%rsp)
  6df1d6:	movq   $0xfffffffffffffffe,0x60(%rsp)
  6df1df:	mov    %r13,%rdi
  6df1e2:	call   71d120 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6df1e7:	mov    0x0(%rbp),%rax
  6df1eb:	test   %rax,%rax
  6df1ee:	je     6df1f5 <text_column_public_control::edit+0x1735>
  6df1f0:	mov    %r15,%rdi
  6df1f3:	call   *%rax
  6df1f5:	mov    0x8(%rbp),%rsi
  6df1f9:	mov    $0xf,%r14d
  6df1ff:	test   %rsi,%rsi
  6df202:	je     6df211 <text_column_public_control::edit+0x1751>
  6df204:	mov    0x10(%rbp),%rdx
  6df208:	mov    %r15,%rdi
  6df20b:	call   *0x3635ef(%rip)        # a42800 <_DYNAMIC+0x268>
  6df211:	jmp    6ded5e <text_column_public_control::edit+0x129e>
  6df216:	mov    %rax,%rbx
  6df219:	mov    0x8(%rbp),%rsi
  6df21d:	test   %rsi,%rsi
  6df220:	je     6df44c <text_column_public_control::edit+0x198c>
  6df226:	mov    0x10(%rbp),%rdx
  6df22a:	mov    %r15,%rdi
  6df22d:	call   *0x3635cd(%rip)        # a42800 <_DYNAMIC+0x268>
  6df233:	jmp    6df44c <text_column_public_control::edit+0x198c>
  6df238:	mov    %rax,%rbx
  6df23b:	lea    0x60(%rsp),%rdi
  6df240:	call   6bf920 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df245:	jmp    6df44c <text_column_public_control::edit+0x198c>
  6df24a:	call   *0x3635d8(%rip)        # a42828 <_DYNAMIC+0x290>
  6df250:	call   *0x36382a(%rip)        # a42a80 <_DYNAMIC+0x4e8>
  6df256:	mov    %rax,%rdi
  6df259:	call   *0x363819(%rip)        # a42a78 <_DYNAMIC+0x4e0>
  6df25f:	mov    %rax,%r14
  6df262:	mov    %rdx,%r12
  6df265:	mov    %rax,0x68(%rsp)
  6df26a:	mov    %rdx,0x70(%rsp)
  6df26f:	movq   $0xfffffffffffffffe,0x60(%rsp)
  6df278:	mov    %r15,%rdi
  6df27b:	call   71d120 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6df280:	mov    (%r12),%rax
  6df284:	test   %rax,%rax
  6df287:	je     6df28e <text_column_public_control::edit+0x17ce>
  6df289:	mov    %r14,%rdi
  6df28c:	call   *%rax
  6df28e:	mov    0x8(%r12),%rsi
  6df293:	mov    $0xf,%r13d
  6df299:	test   %rsi,%rsi
  6df29c:	je     6de9b2 <text_column_public_control::edit+0xef2>
  6df2a2:	mov    0x10(%r12),%rdx
  6df2a7:	mov    %r14,%rdi
  6df2aa:	call   *0x363550(%rip)        # a42800 <_DYNAMIC+0x268>
  6df2b0:	jmp    6de9b2 <text_column_public_control::edit+0xef2>
  6df2b5:	jmp    6df3b2 <text_column_public_control::edit+0x18f2>
  6df2ba:	mov    %rax,%rbx
  6df2bd:	lea    0x60(%rsp),%rdi
  6df2c2:	call   6bf920 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df2c7:	jmp    6df8b4 <text_column_public_control::edit+0x1df4>
  6df2cc:	call   *0x363556(%rip)        # a42828 <_DYNAMIC+0x290>
  6df2d2:	call   *0x3637a8(%rip)        # a42a80 <_DYNAMIC+0x4e8>
  6df2d8:	mov    %rax,%rdi
  6df2db:	call   *0x363797(%rip)        # a42a78 <_DYNAMIC+0x4e0>
  6df2e1:	mov    %rax,%r14
  6df2e4:	mov    %rdx,%r12
  6df2e7:	mov    %rax,0x68(%rsp)
  6df2ec:	mov    %rdx,0x70(%rsp)
  6df2f1:	movq   $0xfffffffffffffffe,0x60(%rsp)
  6df2fa:	mov    %r15,%rdi
  6df2fd:	call   71d120 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6df302:	mov    (%r12),%rax
  6df306:	test   %rax,%rax
  6df309:	je     6df310 <text_column_public_control::edit+0x1850>
  6df30b:	mov    %r14,%rdi
  6df30e:	call   *%rax
  6df310:	mov    0x8(%r12),%rsi
  6df315:	mov    $0xf,%r13d
  6df31b:	test   %rsi,%rsi
  6df31e:	je     6df32e <text_column_public_control::edit+0x186e>
  6df320:	mov    0x10(%r12),%rdx
  6df325:	mov    %r14,%rdi
  6df328:	call   *0x3634d2(%rip)        # a42800 <_DYNAMIC+0x268>
  6df32e:	jmp    6decc2 <text_column_public_control::edit+0x1202>
  6df333:	jmp    6df3b2 <text_column_public_control::edit+0x18f2>
  6df335:	mov    %rax,%rbx
  6df338:	lea    0x60(%rsp),%rdi
  6df33d:	call   6bf920 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df342:	jmp    6df8b4 <text_column_public_control::edit+0x1df4>
  6df347:	call   *0x3634db(%rip)        # a42828 <_DYNAMIC+0x290>
  6df34d:	call   *0x36372d(%rip)        # a42a80 <_DYNAMIC+0x4e8>
  6df353:	mov    %rax,%rdi
  6df356:	call   *0x36371c(%rip)        # a42a78 <_DYNAMIC+0x4e0>
  6df35c:	mov    %rax,%r14
  6df35f:	mov    %rdx,%r12
  6df362:	mov    %rax,0x68(%rsp)
  6df367:	mov    %rdx,0x70(%rsp)
  6df36c:	movq   $0xfffffffffffffffe,0x60(%rsp)
  6df375:	mov    %r15,%rdi
  6df378:	call   71d120 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6df37d:	mov    (%r12),%rax
  6df381:	test   %rax,%rax
  6df384:	je     6df38b <text_column_public_control::edit+0x18cb>
  6df386:	mov    %r14,%rdi
  6df389:	call   *%rax
  6df38b:	mov    0x8(%r12),%rsi
  6df390:	mov    $0xf,%r13d
  6df396:	test   %rsi,%rsi
  6df399:	je     6de7ab <text_column_public_control::edit+0xceb>
  6df39f:	mov    0x10(%r12),%rdx
  6df3a4:	mov    %r14,%rdi
  6df3a7:	call   *0x363453(%rip)        # a42800 <_DYNAMIC+0x268>
  6df3ad:	jmp    6de7ab <text_column_public_control::edit+0xceb>
  6df3b2:	mov    %rax,%rbx
  6df3b5:	mov    0x8(%r12),%rsi
  6df3ba:	test   %rsi,%rsi
  6df3bd:	je     6df8b4 <text_column_public_control::edit+0x1df4>
  6df3c3:	mov    0x10(%r12),%rdx
  6df3c8:	mov    %r14,%rdi
  6df3cb:	call   *0x36342f(%rip)        # a42800 <_DYNAMIC+0x268>
  6df3d1:	mov    %rbx,%rdi
  6df3d4:	call   a20c40 <_Unwind_Resume@plt>
  6df3d9:	mov    %rax,%rbx
  6df3dc:	lea    0x60(%rsp),%rdi
  6df3e1:	call   6bf920 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df3e6:	jmp    6df8b4 <text_column_public_control::edit+0x1df4>
  6df3eb:	call   *0x363437(%rip)        # a42828 <_DYNAMIC+0x290>
  6df3f1:	call   *0x363689(%rip)        # a42a80 <_DYNAMIC+0x4e8>
  6df3f7:	mov    %rax,%rdi
  6df3fa:	call   *0x363678(%rip)        # a42a78 <_DYNAMIC+0x4e0>
  6df400:	mov    %rax,0x68(%rsp)
  6df405:	mov    %rdx,0x70(%rsp)
  6df40a:	movq   $0xfffffffffffffffd,0x60(%rsp)
  6df413:	mov    %r13,%rdi
  6df416:	call   71d120 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6df41b:	lea    0x60(%rsp),%rdi
  6df420:	mov    0x8(%rsp),%r15
  6df425:	call   6bf990 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df42a:	mov    $0xf,%r14d
  6df430:	jmp    6deb3b <text_column_public_control::edit+0x107b>
  6df435:	mov    %r15,0x8(%rsp)
  6df43a:	mov    %rax,%rbx
  6df43d:	jmp    6df44c <text_column_public_control::edit+0x198c>
  6df43f:	mov    %rax,%rbx
  6df442:	lea    0x60(%rsp),%rdi
  6df447:	call   6bf990 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df44c:	cmpq   $0x0,0x8(%rsp)
  6df452:	jle    6df8b4 <text_column_public_control::edit+0x1df4>
  6df458:	mov    $0x1,%edx
  6df45d:	mov    0x10(%rsp),%rdi
  6df462:	mov    0x8(%rsp),%rsi
  6df467:	call   *0x363393(%rip)        # a42800 <_DYNAMIC+0x268>
  6df46d:	mov    %rbx,%rdi
  6df470:	call   a20c40 <_Unwind_Resume@plt>
  6df475:	call   *0x3633ad(%rip)        # a42828 <_DYNAMIC+0x290>
  6df47b:	call   *0x3635ff(%rip)        # a42a80 <_DYNAMIC+0x4e8>
  6df481:	mov    %rax,%rbx
  6df484:	cmpq   $0x0,0x8(%rsp)
  6df48a:	je     6df49f <text_column_public_control::edit+0x19df>
  6df48c:	mov    $0x1,%edx
  6df491:	mov    %r15,%rdi
  6df494:	mov    0x8(%rsp),%rsi
  6df499:	call   *0x363361(%rip)        # a42800 <_DYNAMIC+0x268>
  6df49f:	mov    %rbx,%rdi
  6df4a2:	call   *0x3635d0(%rip)        # a42a78 <_DYNAMIC+0x4e0>
  6df4a8:	mov    %rax,0x68(%rsp)
  6df4ad:	mov    %rdx,0x70(%rsp)
  6df4b2:	movq   $0xfffffffffffffffd,0x60(%rsp)
  6df4bb:	mov    %r13,%rdi
  6df4be:	call   71d120 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6df4c3:	movq   $0xf,0x20(%rsp)
  6df4cc:	lea    0x60(%rsp),%rdi
  6df4d1:	call   6bf990 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df4d6:	jmp    6deab5 <text_column_public_control::edit+0xff5>
  6df4db:	mov    %rax,%rbx
  6df4de:	lea    0x60(%rsp),%rdi
  6df4e3:	call   6bf990 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df4e8:	jmp    6df8b4 <text_column_public_control::edit+0x1df4>
  6df4ed:	call   *0x363335(%rip)        # a42828 <_DYNAMIC+0x290>
  6df4f3:	call   *0x363587(%rip)        # a42a80 <_DYNAMIC+0x4e8>
  6df4f9:	mov    %rax,%rdi
  6df4fc:	call   *0x363576(%rip)        # a42a78 <_DYNAMIC+0x4e0>
  6df502:	mov    %rax,0x68(%rsp)
  6df507:	mov    %rdx,0x70(%rsp)
  6df50c:	movq   $0xfffffffffffffffd,0x60(%rsp)
  6df515:	mov    %r15,%rdi
  6df518:	call   71d120 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6df51d:	lea    0x60(%rsp),%rdi
  6df522:	call   6bf990 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df527:	mov    $0xf,%r13d
  6df52d:	jmp    6de9b2 <text_column_public_control::edit+0xef2>
  6df532:	mov    %rax,%rbx
  6df535:	lea    0x60(%rsp),%rdi
  6df53a:	call   6bf990 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df53f:	jmp    6df8b4 <text_column_public_control::edit+0x1df4>
  6df544:	call   *0x3632de(%rip)        # a42828 <_DYNAMIC+0x290>
  6df54a:	call   *0x363530(%rip)        # a42a80 <_DYNAMIC+0x4e8>
  6df550:	mov    %rax,%rbx
  6df553:	lea    0x60(%rsp),%rdi
  6df558:	call   6c0950 <core::ptr::drop_glue::<gpui::runtime::SetError<alloc::string::String>>>
  6df55d:	mov    %rbx,%rdi
  6df560:	call   a20c40 <_Unwind_Resume@plt>
  6df565:	jmp    6df8c8 <text_column_public_control::edit+0x1e08>
  6df56a:	jmp    6df8dd <text_column_public_control::edit+0x1e1d>
  6df56f:	mov    %rax,%rdi
  6df572:	call   *0x363500(%rip)        # a42a78 <_DYNAMIC+0x4e0>
  6df578:	mov    %rax,0x68(%rsp)
  6df57d:	mov    %rdx,0x70(%rsp)
  6df582:	movq   $0xfffffffffffffffd,0x60(%rsp)
  6df58b:	mov    %r15,%rdi
  6df58e:	call   71d120 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6df593:	movq   $0xf,0x20(%rsp)
  6df59c:	lea    0x60(%rsp),%rdi
  6df5a1:	call   6bf990 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df5a6:	jmp    6de8e9 <text_column_public_control::edit+0xe29>
  6df5ab:	mov    %rax,%rbx
  6df5ae:	lea    0x60(%rsp),%rdi
  6df5b3:	call   6bf990 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df5b8:	jmp    6df8b4 <text_column_public_control::edit+0x1df4>
  6df5bd:	call   *0x363265(%rip)        # a42828 <_DYNAMIC+0x290>
  6df5c3:	call   *0x3634b7(%rip)        # a42a80 <_DYNAMIC+0x4e8>
  6df5c9:	jmp    6df8c8 <text_column_public_control::edit+0x1e08>
  6df5ce:	mov    %rax,%rdi
  6df5d1:	call   *0x3634a1(%rip)        # a42a78 <_DYNAMIC+0x4e0>
  6df5d7:	mov    %rax,0x68(%rsp)
  6df5dc:	mov    %rdx,0x70(%rsp)
  6df5e1:	movq   $0xfffffffffffffffd,0x60(%rsp)
  6df5ea:	mov    %r15,%rdi
  6df5ed:	call   71d120 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6df5f2:	lea    0x60(%rsp),%rdi
  6df5f7:	call   6bf990 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df5fc:	mov    $0xf,%r13d
  6df602:	mov    0x30(%rsp),%rdi
  6df607:	mov    0x38(%rsp),%r8
  6df60c:	lea    0x41(%rsp),%rbx
  6df611:	cmpb   $0x2,0x8(%rsp)
  6df616:	jne    6df651 <text_column_public_control::edit+0x1b91>
  6df618:	mov    0x6d0(%r15),%r10
  6df61f:	cmp    0x120(%rsp),%r10
  6df627:	jne    6df68b <text_column_public_control::edit+0x1bcb>
  6df629:	mov    $0x4,%r9d
  6df62f:	lea    0xf8(%rsp),%r14
  6df637:	mov    0x148(%rsp),%r15
  6df63f:	mov    0x58(%rsp),%rcx
  6df644:	mov    %rdi,%r12
  6df647:	mov    %r8,%rdx
  6df64a:	mov    %esi,%ebp
  6df64c:	jmp    6df6e0 <text_column_public_control::edit+0x1c20>
  6df651:	mov    (%rbx),%ecx
  6df653:	mov    0x3(%rbx),%edx
  6df656:	mov    %edx,0xfb(%rsp)
  6df65d:	mov    %ecx,0xf8(%rsp)
  6df664:	mov    0xc8(%rsp),%ecx
  6df66b:	mov    0xcb(%rsp),%edx
  6df672:	mov    %ecx,0x140(%rsp)
  6df679:	mov    %edx,0x143(%rsp)
  6df680:	mov    $0x2,%r9d
  6df686:	jmp    6df71e <text_column_public_control::edit+0x1c5e>
  6df68b:	movzbl 0x78c(%r15),%ebp
  6df693:	cmpq   $0x0,0x6f0(%r15)
  6df69b:	je     6df6ac <text_column_public_control::edit+0x1bec>
  6df69d:	test   %bpl,%bpl
  6df6a0:	je     6df6b1 <text_column_public_control::edit+0x1bf1>
  6df6a2:	cmpq   $0xffffffffffffffff,0x5f8(%r15)
  6df6aa:	jne    6df6b1 <text_column_public_control::edit+0x1bf1>
  6df6ac:	xor    %r9d,%r9d
  6df6af:	jmp    6df6be <text_column_public_control::edit+0x1bfe>
  6df6b1:	mov    0x700(%r15),%r11
  6df6b8:	mov    $0x1,%r9d
  6df6be:	mov    0x6d8(%r15),%r12
  6df6c5:	mov    0x778(%r15),%rdx
  6df6cc:	lea    0x140(%rsp),%r14
  6df6d4:	mov    %r13,%r15
  6df6d7:	mov    %rax,%rcx
  6df6da:	mov    %r11,%r13
  6df6dd:	mov    %r10,%rax
  6df6e0:	mov    %sil,0x8(%rsp)
  6df6e5:	mov    0x58(%rsp),%r10
  6df6ea:	mov    0x148(%rsp),%r11
  6df6f2:	mov    %r8,0x10(%rsp)
  6df6f7:	mov    (%rbx),%esi
  6df6f9:	mov    0x3(%rbx),%r8d
  6df6fd:	mov    %r8d,0x3(%r14)
  6df701:	mov    %esi,(%r14)
  6df704:	mov    %rdi,0x18(%rsp)
  6df709:	mov    %rcx,0x58(%rsp)
  6df70e:	mov    %r15,0x148(%rsp)
  6df716:	mov    %ebp,%esi
  6df718:	mov    %rdx,%r8
  6df71b:	mov    %r12,%rdi
  6df71e:	mov    %r9,0x60(%rsp)
  6df723:	mov    %r13,0x68(%rsp)
  6df728:	mov    %rax,0x70(%rsp)
  6df72d:	mov    %rdi,0x78(%rsp)
  6df732:	mov    %r8,0x80(%rsp)
  6df73a:	mov    %sil,0x88(%rsp)
  6df742:	mov    0xf8(%rsp),%eax
  6df749:	mov    0xfb(%rsp),%ecx
  6df750:	mov    %eax,0x89(%rsp)
  6df757:	mov    %ecx,0x8c(%rsp)
  6df75e:	mov    0x148(%rsp),%rax
  6df766:	mov    %rax,0x90(%rsp)
  6df76e:	mov    0x58(%rsp),%rax
  6df773:	mov    %rax,0x98(%rsp)
  6df77b:	mov    0x18(%rsp),%rax
  6df780:	mov    %rax,0xa0(%rsp)
  6df788:	mov    0x10(%rsp),%rax
  6df78d:	mov    %rax,0xa8(%rsp)
  6df795:	movzbl 0x8(%rsp),%eax
  6df79a:	mov    %al,0xb0(%rsp)
  6df7a1:	mov    0x140(%rsp),%eax
  6df7a8:	mov    0x143(%rsp),%ecx
  6df7af:	mov    %eax,0xb1(%rsp)
  6df7b6:	mov    %ecx,0xb4(%rsp)
  6df7bd:	mov    %r11,0xb8(%rsp)
  6df7c5:	mov    %r10,0xc0(%rsp)
  6df7cd:	lea    -0x691ffd(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6df7d4:	lea    0x343a6d(%rip),%rcx        # a23248 <__frame_dummy_init_array_entry+0x1258>
  6df7db:	lea    0x34366e(%rip),%r8        # a22e50 <__frame_dummy_init_array_entry+0xe60>
  6df7e2:	lea    0x60(%rsp),%rdx
  6df7e7:	mov    $0x2b,%esi
  6df7ec:	call   *0x362fe6(%rip)        # a427d8 <_DYNAMIC+0x240>
  6df7f2:	ud2
  6df7f4:	mov    %rax,%rbx
  6df7f7:	lea    0x60(%rsp),%rdi
  6df7fc:	call   6bf990 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df801:	jmp    6df8b4 <text_column_public_control::edit+0x1df4>
  6df806:	call   *0x36301c(%rip)        # a42828 <_DYNAMIC+0x290>
  6df80c:	call   *0x36326e(%rip)        # a42a80 <_DYNAMIC+0x4e8>
  6df812:	jmp    6df8dd <text_column_public_control::edit+0x1e1d>
  6df817:	mov    %rax,%rdi
  6df81a:	call   *0x363258(%rip)        # a42a78 <_DYNAMIC+0x4e0>
  6df820:	mov    %rax,0x68(%rsp)
  6df825:	mov    %rdx,0x70(%rsp)
  6df82a:	movq   $0xfffffffffffffffd,0x60(%rsp)
  6df833:	mov    %r15,%rdi
  6df836:	call   71d120 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6df83b:	lea    0x60(%rsp),%rdi
  6df840:	call   6bf990 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df845:	mov    $0xf,%r13d
  6df84b:	jmp    6de7ab <text_column_public_control::edit+0xceb>
  6df850:	mov    %rax,%rbx
  6df853:	lea    0x60(%rsp),%rdi
  6df858:	call   6bf990 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df85d:	jmp    6df8b4 <text_column_public_control::edit+0x1df4>
  6df85f:	call   *0x362fc3(%rip)        # a42828 <_DYNAMIC+0x290>
  6df865:	call   *0x363215(%rip)        # a42a80 <_DYNAMIC+0x4e8>
  6df86b:	mov    %rax,%rdi
  6df86e:	call   *0x363204(%rip)        # a42a78 <_DYNAMIC+0x4e0>
  6df874:	mov    %rax,0x68(%rsp)
  6df879:	mov    %rdx,0x70(%rsp)
  6df87e:	movq   $0xfffffffffffffffd,0x60(%rsp)
  6df887:	mov    %r15,%rdi
  6df88a:	call   71d120 <<gpui::runtime::Runtime<text_column_public_control::Model>>::poison>
  6df88f:	movq   $0xf,0x20(%rsp)
  6df898:	lea    0x60(%rsp),%rdi
  6df89d:	call   6bf990 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df8a2:	jmp    6de743 <text_column_public_control::edit+0xc83>
  6df8a7:	mov    %rax,%rbx
  6df8aa:	lea    0x60(%rsp),%rdi
  6df8af:	call   6bf990 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6df8b4:	mov    %rbx,%rdi
  6df8b7:	call   a20c40 <_Unwind_Resume@plt>
  6df8bc:	call   *0x362f66(%rip)        # a42828 <_DYNAMIC+0x290>
  6df8c2:	call   *0x3631b8(%rip)        # a42a80 <_DYNAMIC+0x4e8>
  6df8c8:	mov    %rax,%rbx
  6df8cb:	lea    0x60(%rsp),%rdi
  6df8d0:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6df8d5:	mov    %rbx,%rdi
  6df8d8:	call   a20c40 <_Unwind_Resume@plt>
  6df8dd:	mov    %rax,%rbx
  6df8e0:	lea    0x60(%rsp),%rdi
  6df8e5:	call   6c0890 <core::ptr::drop_glue::<gpui::runtime::SetError<text_column_public_control::Structural>>>
  6df8ea:	mov    %rbx,%rdi
  6df8ed:	call   a20c40 <_Unwind_Resume@plt>

text_column_public_control::main code=21602 fixed_stack=3704

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006df900 <text_column_public_control::main>:
  6df900:	push   %rbp
  6df901:	push   %r15
  6df903:	push   %r14
  6df905:	push   %r13
  6df907:	push   %r12
  6df909:	push   %rbx
  6df90a:	sub    $0xe48,%rsp
  6df911:	lea    0x9c0(%rsp),%rbx
  6df919:	mov    %rbx,%rdi
  6df91c:	call   *0x363166(%rip)        # a42a88 <_DYNAMIC+0x4f0>
  6df922:	lea    0x260(%rsp),%rdi
  6df92a:	mov    %rbx,%rsi
  6df92d:	call   *0x36315d(%rip)        # a42a90 <_DYNAMIC+0x4f8>
  6df933:	mov    0x260(%rsp),%r14
  6df93b:	cmp    $0xffffffffffffffff,%r14
  6df93f:	je     6e3831 <text_column_public_control::main+0x3f31>
  6df945:	mov    0x268(%rsp),%r15
  6df94d:	mov    0x9d8(%rsp),%rax
  6df955:	sub    0x9c8(%rsp),%rax
  6df95d:	mov    %rax,%rcx
  6df960:	shr    $0x3,%rcx
  6df964:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  6df96e:	imul   %rdx,%rcx
  6df972:	cmp    $0x4,%rcx
  6df976:	mov    $0x3,%ebp
  6df97b:	cmovae %rcx,%rbp
  6df97f:	lea    0x8(,%rbp,8),%rcx
  6df987:	lea    (%rcx,%rcx,2),%r12
  6df98b:	movabs $0x7fffffffffffffe0,%rcx
  6df995:	cmp    %rcx,%rax
  6df998:	jbe    6df9ae <text_column_public_control::main+0xae>
  6df99a:	xor    %r13d,%r13d
  6df99d:	mov    %r13,%rdi
  6df9a0:	mov    %r12,%rsi
  6df9a3:	call   *0x362ee7(%rip)        # a42890 <_DYNAMIC+0x2f8>
  6df9a9:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6df9ae:	mov    0x270(%rsp),%rax
  6df9b6:	test   %r12,%r12
  6df9b9:	je     6df9ec <text_column_public_control::main+0xec>
  6df9bb:	mov    %rax,0x10(%rsp)
  6df9c0:	call   *0x362e42(%rip)        # a42808 <_DYNAMIC+0x270>
  6df9c6:	mov    $0x8,%r13d
  6df9cc:	mov    $0x8,%esi
  6df9d1:	mov    %r12,%rdi
  6df9d4:	call   *0x362e36(%rip)        # a42810 <_DYNAMIC+0x278>
  6df9da:	test   %rax,%rax
  6df9dd:	je     6df99d <text_column_public_control::main+0x9d>
  6df9df:	mov    %rax,%rbx
  6df9e2:	inc    %rbp
  6df9e5:	mov    0x10(%rsp),%rax
  6df9ea:	jmp    6df9f3 <text_column_public_control::main+0xf3>
  6df9ec:	mov    $0x8,%ebx
  6df9f1:	xor    %ebp,%ebp
  6df9f3:	mov    %r14,(%rbx)
  6df9f6:	mov    %r15,0x8(%rbx)
  6df9fa:	mov    %rax,0x10(%rbx)
  6df9fe:	mov    %rbp,0x70(%rsp)
  6dfa03:	mov    %rbx,0x78(%rsp)
  6dfa08:	movq   $0x1,0x80(%rsp)
  6dfa14:	movups 0x9c0(%rsp),%xmm0
  6dfa1c:	movups 0x9d0(%rsp),%xmm1
  6dfa24:	movaps %xmm1,0x270(%rsp)
  6dfa2c:	movaps %xmm0,0x260(%rsp)
  6dfa34:	mov    $0x1,%r14d
  6dfa3a:	mov    $0x28,%r15d
  6dfa40:	jmp    6dfa72 <text_column_public_control::main+0x172>
  6dfa42:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6dfa50:	mov    0x78(%rsp),%rbx
  6dfa55:	mov    %rbp,-0x10(%rbx,%r15,1)
  6dfa5a:	mov    %r13,-0x8(%rbx,%r15,1)
  6dfa5f:	mov    %r12,(%rbx,%r15,1)
  6dfa63:	inc    %r14
  6dfa66:	mov    %r14,0x80(%rsp)
  6dfa6e:	add    $0x18,%r15
  6dfa72:	lea    0xc60(%rsp),%rdi
  6dfa7a:	lea    0x260(%rsp),%rsi
  6dfa82:	call   *0x363008(%rip)        # a42a90 <_DYNAMIC+0x4f8>
  6dfa88:	mov    0xc60(%rsp),%rbp
  6dfa90:	cmp    $0xffffffffffffffff,%rbp
  6dfa94:	je     6dfaef <text_column_public_control::main+0x1ef>
  6dfa96:	mov    0xc68(%rsp),%r13
  6dfa9e:	mov    0xc70(%rsp),%r12
  6dfaa6:	cmp    0x70(%rsp),%r14
  6dfaab:	jne    6dfa55 <text_column_public_control::main+0x155>
  6dfaad:	mov    0x278(%rsp),%rdx
  6dfab5:	sub    0x268(%rsp),%rdx
  6dfabd:	shr    $0x3,%rdx
  6dfac1:	movabs $0xaaaaaaaaaaaaaaab,%rax
  6dfacb:	imul   %rax,%rdx
  6dfacf:	inc    %rdx
  6dfad2:	mov    $0x8,%ecx
  6dfad7:	mov    $0x18,%r8d
  6dfadd:	lea    0x70(%rsp),%rdi
  6dfae2:	mov    %r14,%rsi
  6dfae5:	call   6d93e0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  6dfaea:	jmp    6dfa50 <text_column_public_control::main+0x150>
  6dfaef:	mov    0x268(%rsp),%r14
  6dfaf7:	mov    0x278(%rsp),%rcx
  6dfaff:	mov    %rcx,%rax
  6dfb02:	sub    %r14,%rax
  6dfb05:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  6dfb0f:	mul    %rdx
  6dfb12:	cmp    %r14,%rcx
  6dfb15:	je     6dfb4f <text_column_public_control::main+0x24f>
  6dfb17:	mov    %rdx,%rbx
  6dfb1a:	shr    $0x4,%rbx
  6dfb1e:	add    $0x8,%r14
  6dfb22:	mov    0x362cd7(%rip),%r15        # a42800 <_DYNAMIC+0x268>
  6dfb29:	jmp    6dfb39 <text_column_public_control::main+0x239>
  6dfb2b:	nopl   0x0(%rax,%rax,1)
  6dfb30:	add    $0x18,%r14
  6dfb34:	dec    %rbx
  6dfb37:	je     6dfb4f <text_column_public_control::main+0x24f>
  6dfb39:	mov    -0x8(%r14),%rsi
  6dfb3d:	test   %rsi,%rsi
  6dfb40:	je     6dfb30 <text_column_public_control::main+0x230>
  6dfb42:	mov    (%r14),%rdi
  6dfb45:	mov    $0x1,%edx
  6dfb4a:	call   *%r15
  6dfb4d:	jmp    6dfb30 <text_column_public_control::main+0x230>
  6dfb4f:	mov    0x270(%rsp),%rax
  6dfb57:	test   %rax,%rax
  6dfb5a:	je     6dfb77 <text_column_public_control::main+0x277>
  6dfb5c:	mov    0x260(%rsp),%rdi
  6dfb64:	shl    $0x3,%rax
  6dfb68:	lea    (%rax,%rax,2),%rsi
  6dfb6c:	mov    $0x8,%edx
  6dfb71:	call   *0x362c89(%rip)        # a42800 <_DYNAMIC+0x268>
  6dfb77:	movdqu 0x70(%rsp),%xmm0
  6dfb7d:	movdqa %xmm0,0x210(%rsp)
  6dfb86:	mov    0x80(%rsp),%r14
  6dfb8e:	mov    %r14,0x220(%rsp)
  6dfb96:	lea    0x3432cb(%rip),%rdx        # a22e68 <__frame_dummy_init_array_entry+0xe78>
  6dfb9d:	mov    $0x65,%esi
  6dfba2:	lea    -0x69255c(%rip),%rdi        # 4d64d <GCC_except_table0+0xd805>
  6dfba9:	cmp    $0x2,%r14
  6dfbad:	jb     6e38bc <text_column_public_control::main+0x3fbc>
  6dfbb3:	mov    0x218(%rsp),%rbx
  6dfbbb:	mov    0x20(%rbx),%rax
  6dfbbf:	mov    0x28(%rbx),%rcx
  6dfbc3:	cmp    $0x6,%rcx
  6dfbc7:	je     6dfc5e <text_column_public_control::main+0x35e>
  6dfbcd:	cmp    $0x9,%rcx
  6dfbd1:	jne    6dfcdd <text_column_public_control::main+0x3dd>
  6dfbd7:	movabs $0x6867696c66657270,%rcx
  6dfbe1:	xor    (%rax),%rcx
  6dfbe4:	movzbl 0x8(%rax),%eax
  6dfbe8:	xor    $0x74,%rax
  6dfbec:	or     %rcx,%rax
  6dfbef:	jne    6e38bc <text_column_public_control::main+0x3fbc>
  6dfbf5:	cmp    $0x2,%r14
  6dfbf9:	je     6e39e5 <text_column_public_control::main+0x40e5>
  6dfbff:	mov    0x38(%rbx),%rdi
  6dfc03:	mov    0x40(%rbx),%rsi
  6dfc07:	call   6e5920 <<text_column_public_control::Case>::parse>
  6dfc0c:	mov    %al,0x20(%rsp)
  6dfc10:	cmp    $0x4,%r14
  6dfc14:	jb     6e39ee <text_column_public_control::main+0x40ee>
  6dfc1a:	mov    0x50(%rbx),%rax
  6dfc1e:	mov    0x58(%rbx),%rcx
  6dfc22:	lea    0x343e67(%rip),%rdx        # a23a90 <__frame_dummy_init_array_entry+0x1aa0>
  6dfc29:	mov    $0x19,%esi
  6dfc2e:	lea    -0x68f8eb(%rip),%rdi        # 5034a <GCC_except_table0+0x10502>
  6dfc35:	cmp    $0x6,%rcx
  6dfc39:	jne    6e0456 <text_column_public_control::main+0xb56>
  6dfc3f:	mov    $0x61647075,%ecx
  6dfc44:	xor    (%rax),%ecx
  6dfc46:	movzwl 0x4(%rax),%eax
  6dfc4a:	xor    $0x6574,%eax
  6dfc4f:	or     %ecx,%eax
  6dfc51:	jne    6e38bc <text_column_public_control::main+0x3fbc>
  6dfc57:	xor    %ebx,%ebx
  6dfc59:	jmp    6e0478 <text_column_public_control::main+0xb78>
  6dfc5e:	mov    $0x706d6173,%ecx
  6dfc63:	xor    (%rax),%ecx
  6dfc65:	movzwl 0x4(%rax),%eax
  6dfc69:	xor    $0x656c,%eax
  6dfc6e:	or     %ecx,%eax
  6dfc70:	jne    6e38bc <text_column_public_control::main+0x3fbc>
  6dfc76:	cmp    $0x2,%r14
  6dfc7a:	je     6e39f7 <text_column_public_control::main+0x40f7>
  6dfc80:	mov    0x38(%rbx),%rdi
  6dfc84:	mov    0x40(%rbx),%rsi
  6dfc88:	call   6e5920 <<text_column_public_control::Case>::parse>
  6dfc8d:	cmp    $0x4,%r14
  6dfc91:	jb     6e3a05 <text_column_public_control::main+0x4105>
  6dfc97:	mov    %eax,%ebp
  6dfc99:	mov    0x50(%rbx),%rax
  6dfc9d:	mov    0x58(%rbx),%rcx
  6dfca1:	lea    0x343de8(%rip),%rdx        # a23a90 <__frame_dummy_init_array_entry+0x1aa0>
  6dfca8:	mov    $0x19,%esi
  6dfcad:	lea    -0x68f96a(%rip),%rdi        # 5034a <GCC_except_table0+0x10502>
  6dfcb4:	cmp    $0x6,%rcx
  6dfcb8:	jne    6e074a <text_column_public_control::main+0xe4a>
  6dfcbe:	mov    $0x61647075,%ecx
  6dfcc3:	xor    (%rax),%ecx
  6dfcc5:	movzwl 0x4(%rax),%eax
  6dfcc9:	xor    $0x6574,%eax
  6dfcce:	or     %ecx,%eax
  6dfcd0:	jne    6e38bc <text_column_public_control::main+0x3fbc>
  6dfcd6:	xor    %ebx,%ebx
  6dfcd8:	jmp    6e076c <text_column_public_control::main+0xe6c>
  6dfcdd:	cmp    $0x7,%rcx
  6dfce1:	jne    6e38bc <text_column_public_control::main+0x3fbc>
  6dfce7:	mov    $0x65646f63,%ecx
  6dfcec:	xor    (%rax),%ecx
  6dfcee:	mov    $0x6e656765,%r8d
  6dfcf4:	xor    0x3(%rax),%r8d
  6dfcf8:	or     %ecx,%r8d
  6dfcfb:	jne    6e38bc <text_column_public_control::main+0x3fbc>
  6dfd01:	call   *0x362b01(%rip)        # a42808 <_DYNAMIC+0x270>
  6dfd07:	mov    $0x13,%edi
  6dfd0c:	mov    $0x1,%esi
  6dfd11:	call   *0x362af9(%rip)        # a42810 <_DYNAMIC+0x278>
  6dfd17:	test   %rax,%rax
  6dfd1a:	je     6e3a64 <text_column_public_control::main+0x4164>
  6dfd20:	mov    %rax,%r14
  6dfd23:	movups -0x69278f(%rip),%xmm0        # 4d59b <GCC_except_table0+0xd753>
  6dfd2a:	movups %xmm0,(%rax)
  6dfd2d:	movl   $0x92d791d7,0xf(%rax)
  6dfd34:	lea    0x260(%rsp),%rdi
  6dfd3c:	movabs $0x19000000190,%rbx
  6dfd46:	movss  -0x69fea6(%rip),%xmm0        # 3fea8 <GCC_except_table0+0x60>
  6dfd4e:	mov    %rbx,%rsi
  6dfd51:	call   *0x362d41(%rip)        # a42a98 <_DYNAMIC+0x500>
  6dfd57:	mov    0x260(%rsp),%r12
  6dfd5f:	cmp    $0xfffffffffffffffe,%r12
  6dfd63:	jne    6e3a79 <text_column_public_control::main+0x4179>
  6dfd69:	movq   $0x0,0x278(%rsp)
  6dfd75:	movq   $0x8,0x280(%rsp)
  6dfd81:	xorps  %xmm0,%xmm0
  6dfd84:	movups %xmm0,0x288(%rsp)
  6dfd8c:	movq   $0xffffffffffffffff,0x260(%rsp)
  6dfd98:	movq   $0x8,0x298(%rsp)
  6dfda4:	movups %xmm0,0x2a0(%rsp)
  6dfdac:	movq   $0x8,0x2b0(%rsp)
  6dfdb8:	movq   $0x0,0x2b8(%rsp)
  6dfdc4:	movq   $0x1,0x2c0(%rsp)
  6dfdd0:	mov    $0x1,%edi
  6dfdd5:	call   *0x362cc5(%rip)        # a42aa0 <_DYNAMIC+0x508>
  6dfddb:	mov    %rax,%r13
  6dfdde:	cmp    $0x1,%r13d
  6dfde2:	je     6dfdf8 <text_column_public_control::main+0x4f8>
  6dfde4:	movq   $0x0,0x260(%rsp)
  6dfdf0:	mov    %r13,0x268(%rsp)
  6dfdf8:	call   *0x362a0a(%rip)        # a42808 <_DYNAMIC+0x270>
  6dfdfe:	mov    $0x28,%edi
  6dfe03:	mov    $0x8,%esi
  6dfe08:	call   *0x362a02(%rip)        # a42810 <_DYNAMIC+0x278>
  6dfe0e:	test   %rax,%rax
  6dfe11:	je     6e3490 <text_column_public_control::main+0x3b90>
  6dfe17:	mov    %rax,%r15
  6dfe1a:	lea    0x278(%rsp),%r12
  6dfe22:	mov    %r13,(%rax)
  6dfe25:	lea    -0x6927f5(%rip),%rax        # 4d637 <GCC_except_table0+0xd7ef>
  6dfe2c:	mov    %rax,0x8(%r15)
  6dfe30:	movq   $0x5,0x10(%r15)
  6dfe38:	lea    0x4a321(%rip),%rax        # 72a160 <<<text_column_public_control::Input as gpui::View>::sources::{closure#0} as core::ops::function::FnOnce<(&text_column_public_control::Input,)>>::call_once>
  6dfe3f:	mov    %rax,0x18(%r15)
  6dfe43:	lea    0x4a326(%rip),%rax        # 72a170 <<<text_column_public_control::Input as gpui::View>::sources::{closure#1} as core::ops::function::FnOnce<(&mut text_column_public_control::Input,)>>::call_once>
  6dfe4a:	mov    %rax,0x20(%r15)
  6dfe4e:	mov    %r12,%rdi
  6dfe51:	call   6f4780 <<alloc::raw_vec::RawVec<[core::option::Option<gpui::source::FieldId>; 2]>>::grow_one>
  6dfe56:	mov    0x280(%rsp),%rax
  6dfe5e:	mov    %r15,(%rax)
  6dfe61:	lea    0x3423d8(%rip),%rcx        # a22240 <__frame_dummy_init_array_entry+0x250>
  6dfe68:	mov    %rcx,0x8(%rax)
  6dfe6c:	movq   $0x1,0x288(%rsp)
  6dfe78:	mov    0x260(%rsp),%rax
  6dfe80:	movups 0x40(%r12),%xmm0
  6dfe86:	movaps %xmm0,0xa00(%rsp)
  6dfe8e:	movups (%r12),%xmm0
  6dfe93:	movups 0x10(%r12),%xmm1
  6dfe99:	movups 0x20(%r12),%xmm2
  6dfe9f:	movups 0x30(%r12),%xmm3
  6dfea5:	movaps %xmm3,0x9f0(%rsp)
  6dfead:	movaps %xmm2,0x9e0(%rsp)
  6dfeb5:	movaps %xmm1,0x9d0(%rsp)
  6dfebd:	movupd 0x268(%rsp),%xmm2
  6dfec6:	movups %xmm0,0x88(%rsp)
  6dfece:	movups %xmm1,0x98(%rsp)
  6dfed6:	mov    0x9e0(%rsp),%rcx
  6dfede:	mov    %rcx,0xa8(%rsp)
  6dfee6:	movups 0x9e8(%rsp),%xmm0
  6dfeee:	movups %xmm0,0xb0(%rsp)
  6dfef6:	movups 0x9f8(%rsp),%xmm0
  6dfefe:	movups %xmm0,0xc0(%rsp)
  6dff06:	mov    0xa08(%rsp),%rcx
  6dff0e:	mov    %rcx,0xd0(%rsp)
  6dff16:	mov    %rax,0x70(%rsp)
  6dff1b:	movupd %xmm2,0x78(%rsp)
  6dff21:	movl   $0x0,0x9c0(%rsp)
  6dff2c:	movl   $0x434b0000,0x9c8(%rsp)
  6dff37:	movw   $0x0,0x9cc(%rsp)
  6dff41:	lea    0x260(%rsp),%rdi
  6dff49:	lea    0x9c0(%rsp),%rcx
  6dff51:	mov    $0x190,%esi
  6dff56:	mov    $0x190,%edx
  6dff5b:	call   *0x362b47(%rip)        # a42aa8 <_DYNAMIC+0x510>
  6dff61:	mov    0x260(%rsp),%r12
  6dff69:	mov    0x268(%rsp),%r15d
  6dff71:	mov    0x26c(%rsp),%r13d
  6dff79:	cmp    $0x2,%r12
  6dff7d:	je     6e3b64 <text_column_public_control::main+0x4264>
  6dff83:	lea    0x270(%rsp),%rsi
  6dff8b:	lea    0xc70(%rsp),%rdi
  6dff93:	mov    $0x1d8,%edx
  6dff98:	call   *0x362882(%rip)        # a42820 <memcpy@GLIBC_2.14>
  6dff9e:	mov    %r12,0xc60(%rsp)
  6dffa6:	mov    %r15d,0xc68(%rsp)
  6dffae:	mov    %r13d,0xc6c(%rsp)
  6dffb6:	call   *0x362af4(%rip)        # a42ab0 <_DYNAMIC+0x518>
  6dffbc:	mov    %rax,%r15
  6dffbf:	lea    0x9c0(%rsp),%rdi
  6dffc7:	call   *0x362aeb(%rip)        # a42ab8 <_DYNAMIC+0x520>
  6dffcd:	movq   $0x13,0x500(%rsp)
  6dffd9:	movl   $0x0,0x508(%rsp)
  6dffe4:	movq   $0x0,0x510(%rsp)
  6dfff0:	movl   $0x0,0x518(%rsp)
  6dfffb:	movups 0x70(%rsp),%xmm0
  6e0000:	movups 0x80(%rsp),%xmm1
  6e0008:	movupd 0x90(%rsp),%xmm2
  6e0011:	movups 0xa0(%rsp),%xmm3
  6e0019:	movups %xmm0,0x488(%rsp)
  6e0021:	movups %xmm1,0x498(%rsp)
  6e0029:	movupd %xmm2,0x4a8(%rsp)
  6e0032:	movups %xmm3,0x4b8(%rsp)
  6e003a:	movups 0xb0(%rsp),%xmm0
  6e0042:	movups %xmm0,0x4c8(%rsp)
  6e004a:	movups 0xc0(%rsp),%xmm0
  6e0052:	movups %xmm0,0x4d8(%rsp)
  6e005a:	mov    0xd0(%rsp),%rax
  6e0062:	mov    %rax,0x4e8(%rsp)
  6e006a:	lea    0x550(%rsp),%rdi
  6e0072:	lea    0x9c0(%rsp),%rsi
  6e007a:	mov    0x36279f(%rip),%r12        # a42820 <memcpy@GLIBC_2.14>
  6e0081:	mov    $0x298,%edx
  6e0086:	call   *%r12
  6e0089:	lea    0x260(%rsp),%rdi
  6e0091:	lea    0xc60(%rsp),%rsi
  6e0099:	mov    $0x1e8,%edx
  6e009e:	call   *%r12
  6e00a1:	movq   $0x13,0x4f0(%rsp)
  6e00ad:	mov    %r14,0x4f8(%rsp)
  6e00b5:	movq   $0x0,0x520(%rsp)
  6e00c1:	movq   $0x8,0x528(%rsp)
  6e00cd:	xorps  %xmm0,%xmm0
  6e00d0:	movups %xmm0,0x530(%rsp)
  6e00d8:	movq   $0x8,0x540(%rsp)
  6e00e4:	movq   $0x0,0x548(%rsp)
  6e00f0:	movq   $0x0,0x868(%rsp)
  6e00fc:	movups %xmm0,0x448(%rsp)
  6e0104:	movups %xmm0,0x458(%rsp)
  6e010c:	movups %xmm0,0x850(%rsp)
  6e0114:	movq   $0x1,0x870(%rsp)
  6e0120:	movq   $0x0,0x878(%rsp)
  6e012c:	mov    %r15,0x840(%rsp)
  6e0134:	movq   $0x0,0x888(%rsp)
  6e0140:	movq   $0x0,0x8d0(%rsp)
  6e014c:	movups %xmm0,0x898(%rsp)
  6e0154:	movq   $0x0,0x8a8(%rsp)
  6e0160:	movups %xmm0,0x8b8(%rsp)
  6e0168:	movq   $0x0,0x7e8(%rsp)
  6e0174:	movq   $0x8,0x7f0(%rsp)
  6e0180:	movups %xmm0,0x7f8(%rsp)
  6e0188:	movq   $0x0,0x8d8(%rsp)
  6e0194:	movq   $0x0,0x8e8(%rsp)
  6e01a0:	movl   $0x1000101,0x9a8(%rsp)
  6e01ab:	movw   $0x0,0x9ac(%rsp)
  6e01b5:	movups %xmm0,0x8f0(%rsp)
  6e01bd:	movq   $0x0,0x900(%rsp)
  6e01c9:	mov    %rbx,0x908(%rsp)
  6e01d1:	movsd  -0x69f7a9(%rip),%xmm1        # 40a30 <GCC_except_table0+0xbe8>
  6e01d9:	movsd  %xmm1,0x9a0(%rsp)
  6e01e2:	movq   $0x1,0x848(%rsp)
  6e01ee:	movq   $0xffffffffffffffff,0x818(%rsp)
  6e01fa:	movq   $0x0,0x910(%rsp)
  6e0206:	movq   $0x0,0x920(%rsp)
  6e0212:	movq   $0x8,0x808(%rsp)
  6e021e:	movq   $0x0,0x810(%rsp)
  6e022a:	movb   $0x0,0x9ae(%rsp)
  6e0232:	movups %xmm0,0x988(%rsp)
  6e023a:	movups %xmm0,0x978(%rsp)
  6e0242:	movups %xmm0,0x968(%rsp)
  6e024a:	movups %xmm0,0x958(%rsp)
  6e0252:	movups %xmm0,0x948(%rsp)
  6e025a:	movups %xmm0,0x938(%rsp)
  6e0262:	movups %xmm0,0x928(%rsp)
  6e026a:	movq   $0x0,0x998(%rsp)
  6e0276:	call   *0x36258c(%rip)        # a42808 <_DYNAMIC+0x270>
  6e027c:	mov    $0x750,%edi
  6e0281:	mov    $0x8,%esi
  6e0286:	call   *0x362584(%rip)        # a42810 <_DYNAMIC+0x278>
  6e028c:	test   %rax,%rax
  6e028f:	je     6e34a5 <text_column_public_control::main+0x3ba5>
  6e0295:	mov    %rax,%rbx
  6e0298:	lea    0x260(%rsp),%rsi
  6e02a0:	mov    $0x750,%edx
  6e02a5:	mov    %rax,%rdi
  6e02a8:	call   *0x362572(%rip)        # a42820 <memcpy@GLIBC_2.14>
  6e02ae:	mov    %rbx,0x1e0(%rsp)
  6e02b6:	lea    0x1e8(%rsp),%rdx
  6e02be:	movq   $0x0,(%rsp)
  6e02c6:	lea    0x110(%rsp),%rdi
  6e02ce:	mov    $0x8,%r8d
  6e02d4:	mov    %rbx,%rsi
  6e02d7:	mov    $0x1,%ecx
  6e02dc:	xor    %r9d,%r9d
  6e02df:	call   6e8930 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::describe_with_changed>
  6e02e4:	mov    0x110(%rsp),%r12
  6e02ec:	cmp    $0xfffffffffffffffe,%r12
  6e02f0:	jne    6e3953 <text_column_public_control::main+0x4053>
  6e02f6:	lea    0x110(%rsp),%rdi
  6e02fe:	mov    %rbx,%rsi
  6e0301:	call   70d460 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present>
  6e0306:	mov    0x110(%rsp),%r12
  6e030e:	cmp    $0xfffffffffffffffe,%r12
  6e0312:	jne    6e3953 <text_column_public_control::main+0x4053>
  6e0318:	mov    0x1e0(%rsp),%rsi
  6e0320:	mov    %rsi,0x30(%rsp)
  6e0325:	lea    0x260(%rsp),%rdi
  6e032d:	call   6b5ea0 <text_column_public_control::ack::<text_column_public_control::Input>>
  6e0332:	mov    0x30(%rsp),%rbp
  6e0337:	test   %rbp,%rbp
  6e033a:	je     6e3bc9 <text_column_public_control::main+0x42c9>
  6e0340:	cmpb   $0x0,0x74e(%rbp)
  6e0347:	jne    6e3bd0 <text_column_public_control::main+0x42d0>
  6e034d:	mov    $0x12,%eax
  6e0352:	cmpb   $0x1,0x74a(%rbp)
  6e0359:	jne    6e3bd5 <text_column_public_control::main+0x42d5>
  6e035f:	cmpb   $0x0,0x74b(%rbp)
  6e0366:	jne    6e3bd5 <text_column_public_control::main+0x42d5>
  6e036c:	cmpb   $0x0,0x74c(%rbp)
  6e0373:	je     6e3bd5 <text_column_public_control::main+0x42d5>
  6e0379:	cmpq   $0xffffffffffffffff,0x5b8(%rbp)
  6e0381:	jne    6e3bd5 <text_column_public_control::main+0x42d5>
  6e0387:	mov    0x690(%rbp),%rcx
  6e038e:	cmp    0x698(%rbp),%rcx
  6e0395:	jne    6e3bd5 <text_column_public_control::main+0x42d5>
  6e039b:	mov    0x6a8(%rbp),%rbx
  6e03a2:	cmp    0x6a0(%rbp),%rbx
  6e03a9:	jne    6e3bd5 <text_column_public_control::main+0x42d5>
  6e03af:	movss  0x740(%rbp),%xmm0
  6e03b7:	ucomiss 0x744(%rbp),%xmm0
  6e03be:	jne    6e3bd5 <text_column_public_control::main+0x42d5>
  6e03c4:	jp     6e3bd5 <text_column_public_control::main+0x42d5>
  6e03ca:	mov    0x6c8(%rbp),%rax
  6e03d1:	mov    %rax,0x40(%rsp)
  6e03d6:	mov    0x5a8(%rbp),%rax
  6e03dd:	mov    %rax,0x10(%rsp)
  6e03e2:	mov    0x5b0(%rbp),%r12
  6e03e9:	movups 0x618(%rbp),%xmm0
  6e03f0:	movaps %xmm0,0x20(%rsp)
  6e03f5:	mov    0x640(%rbp),%r13
  6e03fc:	test   %r13,%r13
  6e03ff:	je     6e0db3 <text_column_public_control::main+0x14b3>
  6e0405:	mov    0xe0(%r13),%rax
  6e040c:	test   %rax,%rax
  6e040f:	je     6e0e4d <text_column_public_control::main+0x154d>
  6e0415:	mov    0x38(%rax),%ecx
  6e0418:	mov    %ecx,0xc70(%rsp)
  6e041f:	movups 0x28(%rax),%xmm0
  6e0423:	movaps %xmm0,0xc60(%rsp)
  6e042b:	movzbl 0x3c(%rax),%r15d
  6e0430:	movzbl 0x3f(%rax),%ecx
  6e0434:	mov    %cl,0x72(%rsp)
  6e0438:	movzwl 0x3d(%rax),%eax
  6e043c:	mov    %ax,0x70(%rsp)
  6e0441:	mov    0x100(%r13),%rsi
  6e0448:	test   %rsi,%rsi
  6e044b:	jne    6e0e60 <text_column_public_control::main+0x1560>
  6e0451:	jmp    6e0db6 <text_column_public_control::main+0x14b6>
  6e0456:	cmp    $0x5,%rcx
  6e045a:	jne    6e38bc <text_column_public_control::main+0x3fbc>
  6e0460:	mov    $0x65707974,%ecx
  6e0465:	xor    (%rax),%ecx
  6e0467:	movzbl 0x4(%rax),%eax
  6e046b:	xor    $0x64,%eax
  6e046e:	mov    $0x1,%bl
  6e0470:	or     %ecx,%eax
  6e0472:	jne    6e38bc <text_column_public_control::main+0x3fbc>
  6e0478:	movzbl 0x20(%rsp),%r15d
  6e047e:	movzbl %bl,%edx
  6e0481:	lea    0x260(%rsp),%rdi
  6e0489:	mov    %r15d,%esi
  6e048c:	mov    %edx,0x10(%rsp)
  6e0490:	call   6e4d70 <text_column_public_control::mount>
  6e0495:	mov    0x260(%rsp),%rdi
  6e049d:	mov    %rdi,0x8(%rsp)
  6e04a2:	movups 0x288(%rsp),%xmm0
  6e04aa:	movaps %xmm0,0x130(%rsp)
  6e04b2:	movups 0x278(%rsp),%xmm0
  6e04ba:	movaps %xmm0,0x120(%rsp)
  6e04c2:	movdqu 0x268(%rsp),%xmm0
  6e04cb:	movdqa %xmm0,0x110(%rsp)
  6e04d4:	lea    0x128(%rsp),%r14
  6e04dc:	mov    0x120(%rsp),%r12
  6e04e4:	cmp    0x128(%rsp),%r12
  6e04ec:	jne    6e34d8 <text_column_public_control::main+0x3bd8>
  6e04f2:	mov    %ebx,0x40(%rsp)
  6e04f6:	cmpq   $0x0,0x110(%rsp)
  6e04ff:	jne    6e3508 <text_column_public_control::main+0x3c08>
  6e0505:	lea    -0x692dd4(%rip),%rcx        # 4d738 <GCC_except_table0+0xd8f0>
  6e050c:	mov    $0x6,%r8d
  6e0512:	mov    %r15d,%esi
  6e0515:	mov    0x10(%rsp),%edx
  6e0519:	call   6dbc70 <text_column_public_control::emit_state>
  6e051e:	mov    0x8(%rsp),%rsi
  6e0523:	lea    0x1c0(%rsp),%rdi
  6e052b:	call   6b60e0 <text_column_public_control::observe::<text_column_public_control::Model>>
  6e0530:	mov    0x8(%rsp),%rsi
  6e0535:	lea    0xf8(%rsp),%rdi
  6e053d:	call   6e5640 <text_column_public_control::pointers>
  6e0542:	mov    0x8(%rsp),%rax
  6e0547:	test   %rax,%rax
  6e054a:	je     6e3acb <text_column_public_control::main+0x41cb>
  6e0550:	pxor   %xmm0,%xmm0
  6e0554:	movdqu %xmm0,0x760(%rax)
  6e055c:	movdqu %xmm0,0x750(%rax)
  6e0564:	movdqu %xmm0,0x740(%rax)
  6e056c:	movdqu %xmm0,0x730(%rax)
  6e0574:	movdqu %xmm0,0x720(%rax)
  6e057c:	movdqu %xmm0,0x710(%rax)
  6e0584:	movq   $0x0,0x770(%rax)
  6e058f:	lea    0x70(%rsp),%rdi
  6e0594:	lea    0x8(%rsp),%rsi
  6e0599:	mov    %r15d,%edx
  6e059c:	mov    0x10(%rsp),%ecx
  6e05a0:	xor    %r8d,%r8d
  6e05a3:	call   6ddac0 <text_column_public_control::edit>
  6e05a8:	mov    0x8(%rsp),%rsi
  6e05ad:	test   %rsi,%rsi
  6e05b0:	je     6e3b10 <text_column_public_control::main+0x4210>
  6e05b6:	cmpb   $0x0,0x78e(%rsi)
  6e05bd:	jne    6e3b17 <text_column_public_control::main+0x4217>
  6e05c3:	mov    0x6f0(%rsi),%rax
  6e05ca:	mov    %rax,0x150(%rsp)
  6e05d2:	test   %rax,%rax
  6e05d5:	je     6e3b1e <text_column_public_control::main+0x421e>
  6e05db:	mov    0x6f8(%rsi),%rax
  6e05e2:	mov    %rax,0x148(%rsp)
  6e05ea:	lea    0x260(%rsp),%rbx
  6e05f2:	mov    %rbx,%rdi
  6e05f5:	call   6b60e0 <text_column_public_control::observe::<text_column_public_control::Model>>
  6e05fa:	mov    0x260(%rsp),%rax
  6e0602:	cmp    0x1c0(%rsp),%rax
  6e060a:	jne    6e3401 <text_column_public_control::main+0x3b01>
  6e0610:	mov    0x268(%rsp),%rax
  6e0618:	cmp    0x1c8(%rsp),%rax
  6e0620:	jne    6e3401 <text_column_public_control::main+0x3b01>
  6e0626:	mov    0x270(%rsp),%rax
  6e062e:	cmp    0x1d0(%rsp),%rax
  6e0636:	jne    6e3401 <text_column_public_control::main+0x3b01>
  6e063c:	lea    0x1(%r12),%rax
  6e0641:	mov    %rax,0x260(%rsp)
  6e0649:	cmp    %rax,0x80(%rsp)
  6e0651:	jne    6e3568 <text_column_public_control::main+0x3c68>
  6e0657:	cmp    %r12,0x88(%rsp)
  6e065f:	jne    6e35d5 <text_column_public_control::main+0x3cd5>
  6e0665:	mov    %rax,0x268(%rsp)
  6e066d:	cmp    %rax,0x78(%rsp)
  6e0672:	movq   $0x1,0x260(%rsp)
  6e067e:	sete   %al
  6e0681:	cmpb   $0x0,0x70(%rsp)
  6e0686:	je     6e3424 <text_column_public_control::main+0x3b24>
  6e068c:	test   %al,%al
  6e068e:	je     6e342e <text_column_public_control::main+0x3b2e>
  6e0694:	mov    0x8(%rsp),%rdi
  6e0699:	lea    -0x69ec30(%rip),%rcx        # 41a70 <GCC_except_table0+0x1c28>
  6e06a0:	mov    $0x8,%r8d
  6e06a6:	mov    %r15d,%esi
  6e06a9:	mov    0x10(%rsp),%edx
  6e06ad:	call   6dbc70 <text_column_public_control::emit_state>
  6e06b2:	mov    0x8(%rsp),%rsi
  6e06b7:	lea    0xc60(%rsp),%rdi
  6e06bf:	call   6b5fc0 <text_column_public_control::ack::<text_column_public_control::Model>>
  6e06c4:	mov    0xc70(%rsp),%rax
  6e06cc:	cmp    0xc78(%rsp),%rax
  6e06d4:	jne    6e35fc <text_column_public_control::main+0x3cfc>
  6e06da:	cmpq   $0x0,0xc60(%rsp)
  6e06e3:	jne    6e3625 <text_column_public_control::main+0x3d25>
  6e06e9:	mov    0x8(%rsp),%rsi
  6e06ee:	lea    0x190(%rsp),%rdi
  6e06f6:	call   6e5640 <text_column_public_control::pointers>
  6e06fb:	mov    0x100(%rsp),%r13
  6e0703:	mov    0x108(%rsp),%rdi
  6e070b:	mov    0x198(%rsp),%r14
  6e0713:	mov    0x1a0(%rsp),%rcx
  6e071b:	cmp    %rdi,%rcx
  6e071e:	mov    %rdi,%rax
  6e0721:	mov    %rcx,0x50(%rsp)
  6e0726:	cmovb  %rcx,%rax
  6e072a:	test   %rax,%rax
  6e072d:	je     6e0dd5 <text_column_public_control::main+0x14d5>
  6e0733:	cmp    $0x4,%rax
  6e0737:	mov    0x40(%rsp),%ebp
  6e073b:	jae    6e0de0 <text_column_public_control::main+0x14e0>
  6e0741:	xor    %ebx,%ebx
  6e0743:	xor    %ecx,%ecx
  6e0745:	jmp    6e4282 <text_column_public_control::main+0x4982>
  6e074a:	cmp    $0x5,%rcx
  6e074e:	jne    6e38bc <text_column_public_control::main+0x3fbc>
  6e0754:	mov    $0x65707974,%ecx
  6e0759:	xor    (%rax),%ecx
  6e075b:	movzbl 0x4(%rax),%eax
  6e075f:	xor    $0x64,%eax
  6e0762:	or     %ecx,%eax
  6e0764:	mov    $0x1,%bl
  6e0766:	jne    6e38bc <text_column_public_control::main+0x3fbc>
  6e076c:	movzbl %bpl,%esi
  6e0770:	movzbl %bl,%r14d
  6e0774:	lea    0x260(%rsp),%rdi
  6e077c:	mov    %rsi,0x10(%rsp)
  6e0781:	mov    %r14d,%edx
  6e0784:	call   6e4d70 <text_column_public_control::mount>
  6e0789:	mov    0x260(%rsp),%rax
  6e0791:	mov    %rax,0x30(%rsp)
  6e0796:	cmp    $0x3,%bpl
  6e079a:	jne    6e07eb <text_column_public_control::main+0xeeb>
  6e079c:	lea    0x260(%rsp),%rdi
  6e07a4:	lea    0x30(%rsp),%rsi
  6e07a9:	mov    $0x3,%edx
  6e07ae:	mov    %r14d,%ecx
  6e07b1:	xor    %r8d,%r8d
  6e07b4:	call   6ddac0 <text_column_public_control::edit>
  6e07b9:	lea    0x260(%rsp),%rax
  6e07c1:	lea    0x260(%rsp),%rdi
  6e07c9:	lea    0x30(%rsp),%rsi
  6e07ce:	mov    $0x1,%r8d
  6e07d4:	mov    $0x3,%edx
  6e07d9:	mov    %r14d,%ecx
  6e07dc:	call   6ddac0 <text_column_public_control::edit>
  6e07e1:	lea    0x260(%rsp),%rax
  6e07e9:	jmp    6e0810 <text_column_public_control::main+0xf10>
  6e07eb:	lea    0x260(%rsp),%rdi
  6e07f3:	lea    0x30(%rsp),%rsi
  6e07f8:	mov    0x10(%rsp),%rdx
  6e07fd:	mov    %r14d,%ecx
  6e0800:	xor    %r8d,%r8d
  6e0803:	call   6ddac0 <text_column_public_control::edit>
  6e0808:	lea    0x260(%rsp),%rax
  6e0810:	mov    0x30(%rsp),%rsi
  6e0815:	lea    0x70(%rsp),%rdi
  6e081a:	call   6b5fc0 <text_column_public_control::ack::<text_column_public_control::Model>>
  6e081f:	mov    0x30(%rsp),%rax
  6e0824:	test   %rax,%rax
  6e0827:	je     6e3a1f <text_column_public_control::main+0x411f>
  6e082d:	pxor   %xmm0,%xmm0
  6e0831:	movdqu %xmm0,0x760(%rax)
  6e0839:	movdqu %xmm0,0x750(%rax)
  6e0841:	movdqu %xmm0,0x740(%rax)
  6e0849:	movdqu %xmm0,0x730(%rax)
  6e0851:	movdqu %xmm0,0x720(%rax)
  6e0859:	movdqu %xmm0,0x710(%rax)
  6e0861:	movq   $0x0,0x770(%rax)
  6e086c:	movdqu 0x70(%rsp),%xmm0
  6e0872:	movups 0x80(%rsp),%xmm1
  6e087a:	movdqu 0x90(%rsp),%xmm2
  6e0883:	movdqa %xmm2,0xc80(%rsp)
  6e088c:	movaps %xmm1,0xc70(%rsp)
  6e0894:	movdqa %xmm0,0xc60(%rsp)
  6e089d:	call   *0x36221d(%rip)        # a42ac0 <_DYNAMIC+0x528>
  6e08a3:	mov    %r14,0xd8(%rsp)
  6e08ab:	mov    %ebx,0x20(%rsp)
  6e08af:	mov    %bpl,0x50(%rsp)
  6e08b4:	mov    %rax,0xf8(%rsp)
  6e08bc:	mov    %edx,0x100(%rsp)
  6e08c3:	lea    -0x68fc02(%rip),%rcx        # 50cc8 <GCC_except_table0+0x10e80>
  6e08ca:	mov    0x10(%rsp),%rax
  6e08cf:	mov    (%rcx,%rax,8),%rax
  6e08d3:	mov    $0x1,%r15d
  6e08d9:	lea    0x260(%rsp),%r12
  6e08e1:	mov    $0x1,%ebx
  6e08e6:	mov    %rax,0x40(%rsp)
  6e08eb:	nopl   0x0(%rax,%rax,1)
  6e08f0:	cmp    %rax,%r15
  6e08f3:	adc    $0x0,%rbx
  6e08f7:	lea    0x30(%rsp),%rax
  6e08fc:	mov    %rax,0x260(%rsp)
  6e0904:	mov    0x260(%rsp),%r13
  6e090c:	mov    0x10(%rsp),%rax
  6e0911:	mov    %al,0x260(%rsp)
  6e0918:	movzbl 0x260(%rsp),%eax
  6e0920:	mov    0x20(%rsp),%ecx
  6e0924:	mov    %cl,0x260(%rsp)
  6e092b:	movzbl 0x260(%rsp),%ecx
  6e0933:	mov    %r15,0x260(%rsp)
  6e093b:	mov    0x260(%rsp),%rbp
  6e0943:	movzbl %cl,%r14d
  6e0947:	cmp    $0x3,%al
  6e0949:	jne    6e0990 <text_column_public_control::main+0x1090>
  6e094b:	add    %ebp,%ebp
  6e094d:	and    $0x2,%ebp
  6e0950:	mov    %r12,%rdi
  6e0953:	mov    %r13,%rsi
  6e0956:	mov    $0x3,%edx
  6e095b:	mov    %r14d,%ecx
  6e095e:	mov    %rbp,%r8
  6e0961:	call   6ddac0 <text_column_public_control::edit>
  6e0966:	or     $0x1,%rbp
  6e096a:	mov    %r12,%rdi
  6e096d:	mov    %r13,%rsi
  6e0970:	mov    $0x3,%edx
  6e0975:	mov    %r14d,%ecx
  6e0978:	mov    %rbp,%r8
  6e097b:	call   6ddac0 <text_column_public_control::edit>
  6e0980:	jmp    6e09a4 <text_column_public_control::main+0x10a4>
  6e0982:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6e0990:	movzbl %al,%edx
  6e0993:	mov    %r12,%rdi
  6e0996:	mov    %r13,%rsi
  6e0999:	mov    %r14d,%ecx
  6e099c:	mov    %rbp,%r8
  6e099f:	call   6ddac0 <text_column_public_control::edit>
  6e09a4:	mov    0x0(%r13),%rsi
  6e09a8:	mov    %r12,%rdi
  6e09ab:	call   6b5fc0 <text_column_public_control::ack::<text_column_public_control::Model>>
  6e09b0:	movups 0x260(%rsp),%xmm0
  6e09b8:	movups 0x270(%rsp),%xmm1
  6e09c0:	movups 0x280(%rsp),%xmm2
  6e09c8:	movaps %xmm2,0x9e0(%rsp)
  6e09d0:	movaps %xmm1,0x9d0(%rsp)
  6e09d8:	movaps %xmm0,0x9c0(%rsp)
  6e09e0:	lea    0x9c0(%rsp),%rax
  6e09e8:	movdqa 0x9c0(%rsp),%xmm0
  6e09f1:	movaps 0x9d0(%rsp),%xmm1
  6e09f9:	movdqa 0x9e0(%rsp),%xmm2
  6e0a02:	movdqa %xmm0,0xc60(%rsp)
  6e0a0b:	movaps %xmm1,0xc70(%rsp)
  6e0a13:	movdqa %xmm2,0xc80(%rsp)
  6e0a1c:	mov    0x40(%rsp),%rax
  6e0a21:	cmp    %rax,%r15
  6e0a24:	jae    6e0a32 <text_column_public_control::main+0x1132>
  6e0a26:	mov    %rbx,%r15
  6e0a29:	cmp    %rax,%rbx
  6e0a2c:	jbe    6e08f0 <text_column_public_control::main+0xff0>
  6e0a32:	lea    0xf8(%rsp),%rdi
  6e0a3a:	call   *0x362088(%rip)        # a42ac8 <_DYNAMIC+0x530>
  6e0a40:	movzbl 0x50(%rsp),%edi
  6e0a45:	mov    0x20(%rsp),%ebp
  6e0a49:	mov    0xd8(%rsp),%r14
  6e0a51:	lea    -0x68fd90(%rip),%r15        # 50cc8 <GCC_except_table0+0x10e80>
  6e0a58:	mov    %edx,%esi
  6e0a5a:	cmp    $0x3,%dil
  6e0a5e:	sete   %cl
  6e0a61:	mov    $0x3b9aca00,%edx
  6e0a66:	mul    %rdx
  6e0a69:	mov    %esi,%esi
  6e0a6b:	add    %rax,%rsi
  6e0a6e:	adc    $0x0,%rdx
  6e0a72:	mov    %rsi,0x190(%rsp)
  6e0a7a:	mov    %rdx,0x198(%rsp)
  6e0a82:	lea    0x30(%rsp),%rax
  6e0a87:	mov    %rax,0x260(%rsp)
  6e0a8f:	lea    0x260(%rsp),%rdx
  6e0a97:	mov    0x10(%rsp),%rax
  6e0a9c:	mov    (%r15,%rax,8),%rax
  6e0aa0:	shl    %cl,%rax
  6e0aa3:	mov    %rax,0x230(%rsp)
  6e0aab:	lea    0xc70(%rsp),%rbx
  6e0ab3:	mov    0x80(%rsp),%rcx
  6e0abb:	add    %rax,%rcx
  6e0abe:	mov    %rcx,0x260(%rsp)
  6e0ac6:	cmp    %rcx,0xc70(%rsp)
  6e0ace:	jne    6e34f9 <text_column_public_control::main+0x3bf9>
  6e0ad4:	lea    0xc78(%rsp),%r12
  6e0adc:	cmp    %rcx,0xc78(%rsp)
  6e0ae4:	jne    6e3526 <text_column_public_control::main+0x3c26>
  6e0aea:	cmpq   $0x0,0xc60(%rsp)
  6e0af3:	jne    6e3535 <text_column_public_control::main+0x3c35>
  6e0af9:	cmpb   $0x1,0xc88(%rsp)
  6e0b01:	jne    6e354a <text_column_public_control::main+0x3c4a>
  6e0b07:	mov    0x30(%rsp),%rsi
  6e0b0c:	test   %rsi,%rsi
  6e0b0f:	je     6e3b8c <text_column_public_control::main+0x428c>
  6e0b15:	mov    0x770(%rsi),%rcx
  6e0b1c:	mov    %rcx,0xa20(%rsp)
  6e0b24:	movups 0x760(%rsi),%xmm0
  6e0b2b:	movaps %xmm0,0xa10(%rsp)
  6e0b33:	movups 0x750(%rsi),%xmm0
  6e0b3a:	movaps %xmm0,0xa00(%rsp)
  6e0b42:	movdqu 0x710(%rsi),%xmm0
  6e0b4a:	movups 0x720(%rsi),%xmm1
  6e0b51:	movdqu 0x730(%rsi),%xmm2
  6e0b59:	movdqu 0x740(%rsi),%xmm3
  6e0b61:	movdqa %xmm3,0x9f0(%rsp)
  6e0b6a:	movdqa %xmm2,0x9e0(%rsp)
  6e0b73:	movaps %xmm1,0x9d0(%rsp)
  6e0b7b:	movdqa %xmm0,0x9c0(%rsp)
  6e0b84:	mov    %rax,0x260(%rsp)
  6e0b8c:	cmp    %rax,0x9d0(%rsp)
  6e0b94:	jne    6e357c <text_column_public_control::main+0x3c7c>
  6e0b9a:	cmp    $0x7,%dil
  6e0b9e:	setne  %al
  6e0ba1:	test   %bpl,%al
  6e0ba4:	je     6e0bcb <text_column_public_control::main+0x12cb>
  6e0ba6:	lea    -0x69f31d(%rip),%rdx        # 41890 <GCC_except_table0+0x1a48>
  6e0bad:	cmpq   $0x0,0x9c8(%rsp)
  6e0bb6:	jne    6e36cc <text_column_public_control::main+0x3dcc>
  6e0bbc:	cmpq   $0x0,0x9c0(%rsp)
  6e0bc5:	jne    6e36dd <text_column_public_control::main+0x3ddd>
  6e0bcb:	lea    0x260(%rsp),%rdi
  6e0bd3:	call   6b60e0 <text_column_public_control::observe::<text_column_public_control::Model>>
  6e0bd8:	mov    0x260(%rsp),%rax
  6e0be0:	mov    0x268(%rsp),%rcx
  6e0be8:	mov    %rax,0x160(%rsp)
  6e0bf0:	mov    %rcx,0x178(%rsp)
  6e0bf8:	mov    0x270(%rsp),%rax
  6e0c00:	mov    %rax,0xe0(%rsp)
  6e0c08:	mov    0x10(%rsp),%rdx
  6e0c0d:	shl    $0x3,%edx
  6e0c10:	lea    0x343d01(%rip),%rax        # a24918 <__frame_dummy_init_array_entry+0x2928>
  6e0c17:	mov    (%rdx,%rax,1),%rax
  6e0c1b:	lea    -0x68ff1a(%rip),%rcx        # 50d08 <GCC_except_table0+0x10ec0>
  6e0c22:	mov    (%rdx,%rcx,1),%rcx
  6e0c26:	mov    (%rdx,%r15,1),%rdx
  6e0c2a:	mov    %rax,0x1e0(%rsp)
  6e0c32:	mov    %rcx,0x1e8(%rsp)
  6e0c3a:	lea    -0x6936ab(%rip),%rax        # 4d596 <GCC_except_table0+0xd74e>
  6e0c41:	lea    -0x6936b8(%rip),%rcx        # 4d590 <GCC_except_table0+0xd748>
  6e0c48:	test   %bpl,%bpl
  6e0c4b:	cmovne %rax,%rcx
  6e0c4f:	mov    $0x6,%eax
  6e0c54:	sub    %r14,%rax
  6e0c57:	mov    %rcx,0x110(%rsp)
  6e0c5f:	mov    %rax,0x118(%rsp)
  6e0c67:	mov    %rdx,0x1c0(%rsp)
  6e0c6f:	lea    0x9c8(%rsp),%rax
  6e0c77:	lea    0x1e0(%rsp),%rcx
  6e0c7f:	mov    %rcx,0x260(%rsp)
  6e0c87:	lea    0x46322(%rip),%rcx        # 726fb0 <<&str as core::fmt::Display>::fmt>
  6e0c8e:	mov    %rcx,0x268(%rsp)
  6e0c96:	lea    0x110(%rsp),%rdx
  6e0c9e:	mov    %rdx,0x270(%rsp)
  6e0ca6:	mov    %rcx,0x278(%rsp)
  6e0cae:	lea    0x1c0(%rsp),%rcx
  6e0cb6:	mov    %rcx,0x280(%rsp)
  6e0cbe:	mov    0x361d8b(%rip),%rcx        # a42a50 <_DYNAMIC+0x4b8>
  6e0cc5:	mov    %rcx,0x288(%rsp)
  6e0ccd:	lea    0x230(%rsp),%rdx
  6e0cd5:	mov    %rdx,0x290(%rsp)
  6e0cdd:	mov    %rcx,0x298(%rsp)
  6e0ce5:	lea    0x160(%rsp),%rdx
  6e0ced:	mov    %rdx,0x2a0(%rsp)
  6e0cf5:	mov    %rcx,0x2a8(%rsp)
  6e0cfd:	lea    0x178(%rsp),%rdx
  6e0d05:	mov    %rdx,0x2b0(%rsp)
  6e0d0d:	mov    %rcx,0x2b8(%rsp)
  6e0d15:	lea    0xe0(%rsp),%rcx
  6e0d1d:	mov    %rcx,0x2c0(%rsp)
  6e0d25:	mov    0x361d2c(%rip),%rcx        # a42a58 <_DYNAMIC+0x4c0>
  6e0d2c:	mov    %rcx,0x2c8(%rsp)
  6e0d34:	mov    %rbx,0x2d0(%rsp)
  6e0d3c:	mov    %rcx,0x2d8(%rsp)
  6e0d44:	mov    %r12,0x2e0(%rsp)
  6e0d4c:	mov    %rcx,0x2e8(%rsp)
  6e0d54:	mov    %rax,0x2f0(%rsp)
  6e0d5c:	mov    %rcx,0x2f8(%rsp)
  6e0d64:	lea    0x190(%rsp),%rax
  6e0d6c:	mov    %rax,0x300(%rsp)
  6e0d74:	mov    0x361d55(%rip),%rax        # a42ad0 <_DYNAMIC+0x538>
  6e0d7b:	mov    %rax,0x308(%rsp)
  6e0d83:	lea    -0x695aee(%rip),%rdi        # 4b29c <GCC_except_table0+0xb454>
  6e0d8a:	lea    0x260(%rsp),%rsi
  6e0d92:	call   *0x361cd0(%rip)        # a42a68 <_DYNAMIC+0x4d0>
  6e0d98:	mov    0x30(%rsp),%r14
  6e0d9d:	test   %r14,%r14
  6e0da0:	je     6e4a7c <text_column_public_control::main+0x517c>
  6e0da6:	mov    %r14,%rdi
  6e0da9:	call   6c02e0 <core::ptr::drop_glue::<gpui::runtime::Runtime<text_column_public_control::Model>>>
  6e0dae:	jmp    6e4a69 <text_column_public_control::main+0x5169>
  6e0db3:	mov    $0x2,%r15b
  6e0db6:	movq   $0x4,0x9c0(%rsp)
  6e0dc2:	xorps  %xmm0,%xmm0
  6e0dc5:	movups %xmm0,0x9c8(%rsp)
  6e0dcd:	mov    %r12,%r14
  6e0dd0:	jmp    6e0e75 <text_column_public_control::main+0x1575>
  6e0dd5:	xor    %ebx,%ebx
  6e0dd7:	mov    0x40(%rsp),%ebp
  6e0ddb:	jmp    6e429d <text_column_public_control::main+0x499d>
  6e0de0:	mov    %rax,%rcx
  6e0de3:	and    $0xfffffffffffffffc,%rcx
  6e0de7:	pxor   %xmm0,%xmm0
  6e0deb:	xor    %edx,%edx
  6e0ded:	xorps  %xmm1,%xmm1
  6e0df0:	movdqu 0x0(%r13,%rdx,8),%xmm2
  6e0df7:	movdqu 0x10(%r13,%rdx,8),%xmm3
  6e0dfe:	movdqu (%r14,%rdx,8),%xmm4
  6e0e04:	pcmpeqd %xmm2,%xmm4
  6e0e08:	movdqu 0x10(%r14,%rdx,8),%xmm2
  6e0e0f:	pcmpeqd %xmm3,%xmm2
  6e0e13:	pshufd $0xb1,%xmm4,%xmm3
  6e0e18:	pand   %xmm4,%xmm3
  6e0e1c:	psubq  %xmm3,%xmm1
  6e0e20:	pshufd $0xb1,%xmm2,%xmm3
  6e0e25:	pand   %xmm2,%xmm3
  6e0e29:	psubq  %xmm3,%xmm0
  6e0e2d:	add    $0x4,%rdx
  6e0e31:	cmp    %rdx,%rcx
  6e0e34:	jne    6e0df0 <text_column_public_control::main+0x14f0>
  6e0e36:	paddq  %xmm1,%xmm0
  6e0e3a:	pshufd $0xee,%xmm0,%xmm1
  6e0e3f:	paddq  %xmm0,%xmm1
  6e0e43:	movq   %xmm1,%rbx
  6e0e48:	jmp    6e4298 <text_column_public_control::main+0x4998>
  6e0e4d:	mov    $0x2,%r15b
  6e0e50:	mov    0x100(%r13),%rsi
  6e0e57:	test   %rsi,%rsi
  6e0e5a:	je     6e0db6 <text_column_public_control::main+0x14b6>
  6e0e60:	lea    0x9c0(%rsp),%rdi
  6e0e68:	call   *0x361972(%rip)        # a427e0 <_DYNAMIC+0x248>
  6e0e6e:	mov    0x5b0(%rbp),%r14
  6e0e75:	lea    0x5e0(%rbp),%rax
  6e0e7c:	mov    %rax,0x50(%rsp)
  6e0e81:	mov    %rax,0x2b0(%rsp)
  6e0e89:	mov    0x40(%rsp),%rax
  6e0e8e:	mov    %rax,0x280(%rsp)
  6e0e96:	mov    %rbx,0x288(%rsp)
  6e0e9e:	mov    0x10(%rsp),%rax
  6e0ea3:	mov    %rax,0x270(%rsp)
  6e0eab:	mov    %r12,0x278(%rsp)
  6e0eb3:	movaps 0x20(%rsp),%xmm0
  6e0eb8:	movaps %xmm0,0x260(%rsp)
  6e0ec0:	mov    %r13,0x290(%rsp)
  6e0ec8:	mov    0x9c0(%rsp),%rax
  6e0ed0:	mov    %rax,0x298(%rsp)
  6e0ed8:	mov    0x9c8(%rsp),%rax
  6e0ee0:	mov    %rax,0x2a0(%rsp)
  6e0ee8:	mov    0x9d0(%rsp),%rax
  6e0ef0:	mov    %rax,0x2a8(%rsp)
  6e0ef8:	movaps 0xc60(%rsp),%xmm0
  6e0f00:	movups %xmm0,0x2b8(%rsp)
  6e0f08:	mov    0xc70(%rsp),%eax
  6e0f0f:	mov    %eax,0x2c8(%rsp)
  6e0f16:	mov    %r15b,0x2cc(%rsp)
  6e0f1e:	movzwl 0x70(%rsp),%eax
  6e0f23:	mov    %ax,0x2cd(%rsp)
  6e0f2b:	movzbl 0x72(%rsp),%eax
  6e0f30:	mov    %al,0x2cf(%rsp)
  6e0f37:	test   %r14,%r14
  6e0f3a:	je     6e39db <text_column_public_control::main+0x40db>
  6e0f40:	mov    $0x20,%r12d
  6e0f46:	xor    %r13d,%r13d
  6e0f49:	lea    0x260(%rsp),%r15
  6e0f51:	mov    0x361b80(%rip),%rbx        # a42ad8 <_DYNAMIC+0x540>
  6e0f58:	lea    0x342471(%rip),%rax        # a233d0 <__frame_dummy_init_array_entry+0x13e0>
  6e0f5f:	mov    %rax,0x40(%rsp)
  6e0f64:	movq   $0x0,0x20(%rsp)
  6e0f6d:	movq   $0x0,0x10(%rsp)
  6e0f76:	jmp    6e0f8c <text_column_public_control::main+0x168c>
  6e0f78:	nopl   0x0(%rax,%rax,1)
  6e0f80:	inc    %r13
  6e0f83:	add    $0x40,%r12
  6e0f87:	cmp    %r13,%r14
  6e0f8a:	je     6e0fe3 <text_column_public_control::main+0x16e3>
  6e0f8c:	mov    %r15,%rdi
  6e0f8f:	mov    %r13,%rsi
  6e0f92:	call   *%rbx
  6e0f94:	test   %rax,%rax
  6e0f97:	setne  %cl
  6e0f9a:	cmp    $0x5,%rdx
  6e0f9e:	sete   %dl
  6e0fa1:	and    %cl,%dl
  6e0fa3:	cmp    $0x1,%dl
  6e0fa6:	jne    6e0f80 <text_column_public_control::main+0x1680>
  6e0fa8:	mov    (%rax),%ecx
  6e0faa:	mov    $0x63656863,%edx
  6e0faf:	xor    %edx,%ecx
  6e0fb1:	movzbl 0x4(%rax),%eax
  6e0fb5:	xor    $0x6b,%eax
  6e0fb8:	or     %ecx,%eax
  6e0fba:	jne    6e0f80 <text_column_public_control::main+0x1680>
  6e0fbc:	mov    0x5b0(%rbp),%rsi
  6e0fc3:	cmp    %rsi,%r13
  6e0fc6:	jae    6e3d1f <text_column_public_control::main+0x441f>
  6e0fcc:	mov    0x5a8(%rbp),%rax
  6e0fd3:	incq   0x10(%rsp)
  6e0fd8:	mov    (%rax,%r12,1),%rax
  6e0fdc:	mov    %rax,0x20(%rsp)
  6e0fe1:	jmp    6e0f80 <text_column_public_control::main+0x1680>
  6e0fe3:	mov    0x10(%rsp),%rcx
  6e0fe8:	cmp    $0x1,%rcx
  6e0fec:	jne    6e39cd <text_column_public_control::main+0x40cd>
  6e0ff2:	mov    0x50(%rsp),%rdi
  6e0ff7:	mov    0x20(%rsp),%rsi
  6e0ffc:	call   *0x361a36(%rip)        # a42a38 <_DYNAMIC+0x4a0>
  6e1002:	mov    0x30(%rsp),%r12
  6e1007:	test   %r12,%r12
  6e100a:	je     6e3c17 <text_column_public_control::main+0x4317>
  6e1010:	mov    %rax,%r14
  6e1013:	lea    0x38(%rsp),%rax
  6e1018:	mov    %r12,0x70(%rsp)
  6e101d:	mov    %rax,0x78(%rsp)
  6e1022:	cmpb   $0x1,0x74e(%r12)
  6e102b:	je     6e3c34 <text_column_public_control::main+0x4334>
  6e1031:	cmp    0x5e0(%r12),%r14
  6e1039:	jne    6e3c45 <text_column_public_control::main+0x4345>
  6e103f:	mov    %rdx,%rbx
  6e1042:	lea    0x260(%rsp),%rdi
  6e104a:	mov    %r12,%rsi
  6e104d:	call   70cd00 <<gpui::runtime::Runtime<text_column_public_control::Input>>::resolve_identity>
  6e1052:	mov    0x260(%rsp),%rax
  6e105a:	cmp    $0xfffffffffffffffe,%rax
  6e105e:	jne    6e3c4c <text_column_public_control::main+0x434c>
  6e1064:	cmpb   $0x1,0x74a(%r12)
  6e106d:	jne    6e38c7 <text_column_public_control::main+0x3fc7>
  6e1073:	cmpb   $0x0,0x74b(%r12)
  6e107c:	jne    6e38c7 <text_column_public_control::main+0x3fc7>
  6e1082:	cmpb   $0x0,0x74c(%r12)
  6e108b:	je     6e38c7 <text_column_public_control::main+0x3fc7>
  6e1091:	cmpq   $0xffffffffffffffff,0x5b8(%r12)
  6e109a:	jne    6e38c7 <text_column_public_control::main+0x3fc7>
  6e10a0:	mov    0x690(%r12),%rax
  6e10a8:	cmp    0x698(%r12),%rax
  6e10b0:	jne    6e38c7 <text_column_public_control::main+0x3fc7>
  6e10b6:	mov    0x6a8(%r12),%rax
  6e10be:	cmp    0x6a0(%r12),%rax
  6e10c6:	jne    6e38c7 <text_column_public_control::main+0x3fc7>
  6e10cc:	movss  0x740(%r12),%xmm0
  6e10d6:	ucomiss 0x744(%r12),%xmm0
  6e10df:	jne    6e38c7 <text_column_public_control::main+0x3fc7>
  6e10e5:	jp     6e38c7 <text_column_public_control::main+0x3fc7>
  6e10eb:	mov    0x5a8(%r12),%r13
  6e10f3:	mov    0x5b0(%r12),%rax
  6e10fb:	lea    -0x38(%r13),%rcx
  6e10ff:	shl    $0x6,%rax
  6e1103:	neg    %rax
  6e1106:	xor    %r15d,%r15d
  6e1109:	nopl   0x0(%rax)
  6e1110:	cmp    %r15,%rax
  6e1113:	je     6e37a8 <text_column_public_control::main+0x3ea8>
  6e1119:	add    $0xffffffffffffffc0,%r15
  6e111d:	lea    0x40(%rcx),%rbp
  6e1121:	cmp    %rbx,0x58(%rcx)
  6e1125:	mov    %rbp,%rcx
  6e1128:	jne    6e1110 <text_column_public_control::main+0x1810>
  6e112a:	mov    0x640(%r12),%rax
  6e1132:	test   %rax,%rax
  6e1135:	je     6e1153 <text_column_public_control::main+0x1853>
  6e1137:	mov    0x100(%rax),%rsi
  6e113e:	test   %rsi,%rsi
  6e1141:	je     6e1153 <text_column_public_control::main+0x1853>
  6e1143:	lea    0x9c0(%rsp),%rdi
  6e114b:	call   *0x36168f(%rip)        # a427e0 <_DYNAMIC+0x248>
  6e1151:	jmp    6e116a <text_column_public_control::main+0x186a>
  6e1153:	movq   $0x4,0x9c0(%rsp)
  6e115f:	xorps  %xmm0,%xmm0
  6e1162:	movups %xmm0,0x9c8(%rsp)
  6e116a:	lea    0x9c0(%rsp),%rdi
  6e1172:	mov    %rdi,0x20(%rsp)
  6e1177:	call   *0x3618ab(%rip)        # a42a28 <_DYNAMIC+0x490>
  6e117d:	mov    %rdx,%rcx
  6e1180:	sub    %r15,%r13
  6e1183:	lea    -0x40(%r13),%rsi
  6e1187:	lea    0x260(%rsp),%rdi
  6e118f:	mov    %rax,%rdx
  6e1192:	call   *0x361898(%rip)        # a42a30 <_DYNAMIC+0x498>
  6e1198:	cmpb   $0x0,0x260(%rsp)
  6e11a0:	je     6e1241 <text_column_public_control::main+0x1941>
  6e11a6:	movss  -0x6a1252(%rip),%xmm0        # 3ff5c <GCC_except_table0+0x114>
  6e11ae:	movss  0x0(%rbp),%xmm1
  6e11b3:	mulss  %xmm0,%xmm1
  6e11b7:	mulss  0x4(%rbp),%xmm0
  6e11bc:	cvtss2sd %xmm1,%xmm1
  6e11c0:	cvtss2sd %xmm0,%xmm0
  6e11c4:	cvtps2pd 0x264(%rsp),%xmm2
  6e11cc:	movlhps %xmm1,%xmm1
  6e11cf:	mulpd  %xmm2,%xmm1
  6e11d3:	cvtps2pd 0x26c(%rsp),%xmm2
  6e11db:	movlhps %xmm0,%xmm0
  6e11de:	mulpd  %xmm2,%xmm0
  6e11e2:	cvtps2pd 0x274(%rsp),%xmm2
  6e11ea:	addpd  %xmm1,%xmm0
  6e11ee:	addpd  %xmm0,%xmm2
  6e11f2:	cvtpd2ps %xmm2,%xmm0
  6e11f6:	movapd %xmm0,%xmm1
  6e11fa:	shufps $0x55,%xmm0,%xmm1
  6e11fe:	movd   %xmm1,%eax
  6e1202:	movd   %xmm0,%ecx
  6e1206:	and    $0x7fffffff,%ecx
  6e120c:	cmp    $0x7f800000,%ecx
  6e1212:	setge  %cl
  6e1215:	and    $0x7fffffff,%eax
  6e121a:	cmp    $0x7f800000,%eax
  6e121f:	setge  %al
  6e1222:	or     %cl,%al
  6e1224:	jne    6e1241 <text_column_public_control::main+0x1941>
  6e1226:	add    $0xffffffffffffffd0,%r13
  6e122a:	mov    %r13,%rdi
  6e122d:	movaps %xmm0,0x10(%rsp)
  6e1232:	call   *0x3618a8(%rip)        # a42ae0 <_DYNAMIC+0x548>
  6e1238:	test   %al,%al
  6e123a:	movaps 0x10(%rsp),%xmm0
  6e123f:	jne    6e1277 <text_column_public_control::main+0x1977>
  6e1241:	movss  0x10(%rbp),%xmm3
  6e1246:	xorpd  %xmm2,%xmm2
  6e124a:	ucomiss %xmm2,%xmm3
  6e124d:	jne    6e1255 <text_column_public_control::main+0x1955>
  6e124f:	jnp    6e38f6 <text_column_public_control::main+0x3ff6>
  6e1255:	movss  0x14(%rbp),%xmm1
  6e125a:	ucomiss %xmm2,%xmm1
  6e125d:	jne    6e1265 <text_column_public_control::main+0x1965>
  6e125f:	jnp    6e38f6 <text_column_public_control::main+0x3ff6>
  6e1265:	unpcklps %xmm1,%xmm3
  6e1268:	mulps  -0x69fe9f(%rip),%xmm3        # 413d0 <GCC_except_table0+0x1588>
  6e126f:	movsd  0x8(%rbp),%xmm0
  6e1274:	addps  %xmm3,%xmm0
  6e1277:	movaps %xmm0,%xmm1
  6e127a:	shufps $0x55,%xmm0,%xmm1
  6e127e:	mov    %r12,%rdi
  6e1281:	movaps %xmm0,0x10(%rsp)
  6e1286:	movaps %xmm1,0x40(%rsp)
  6e128b:	call   70cfe0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit>
  6e1290:	test   $0x1,%al
  6e1292:	je     6e38f6 <text_column_public_control::main+0x3ff6>
  6e1298:	cmp    %rbx,%rdx
  6e129b:	jne    6e38f6 <text_column_public_control::main+0x3ff6>
  6e12a1:	cmp    0x5e0(%r12),%r14
  6e12a9:	jne    6e3cc9 <text_column_public_control::main+0x43c9>
  6e12af:	lea    0x260(%rsp),%rdi
  6e12b7:	mov    %r12,%rsi
  6e12ba:	mov    %rbx,%rdx
  6e12bd:	call   70cd00 <<gpui::runtime::Runtime<text_column_public_control::Input>>::resolve_identity>
  6e12c2:	mov    0x260(%rsp),%rax
  6e12ca:	mov    0x268(%rsp),%r13
  6e12d2:	cmp    $0xfffffffffffffffe,%rax
  6e12d6:	jne    6e3cce <text_column_public_control::main+0x43ce>
  6e12dc:	mov    0x2d0(%r12),%rsi
  6e12e4:	cmp    %rsi,%r13
  6e12e7:	movaps 0x10(%rsp),%xmm0
  6e12ec:	jae    6e3d13 <text_column_public_control::main+0x4413>
  6e12f2:	mov    0x2c8(%r12),%rax
  6e12fa:	lea    0x0(,%r13,4),%rcx
  6e1302:	add    %r13,%rcx
  6e1305:	mov    0x20(%rax,%rcx,8),%eax
  6e1309:	and    $0xf,%eax
  6e130c:	lea    -0x3(%rax),%ecx
  6e130f:	cmp    $0x7,%ecx
  6e1312:	jb     6e131d <text_column_public_control::main+0x1a1d>
  6e1314:	cmp    $0x2,%eax
  6e1317:	jae    6e3226 <text_column_public_control::main+0x3926>
  6e131d:	cmpb   $0x0,0x74e(%r12)
  6e1326:	je     6e1332 <text_column_public_control::main+0x1a32>
  6e1328:	mov    $0xe,%eax
  6e132d:	jmp    6e1487 <text_column_public_control::main+0x1b87>
  6e1332:	cmp    0x5e0(%r12),%r14
  6e133a:	jne    6e144e <text_column_public_control::main+0x1b4e>
  6e1340:	mov    0x618(%r12),%rbp
  6e1348:	mov    0x620(%r12),%r15
  6e1350:	lea    0x260(%rsp),%rdi
  6e1358:	mov    %r12,%rsi
  6e135b:	mov    %rbx,%rdx
  6e135e:	call   70cd00 <<gpui::runtime::Runtime<text_column_public_control::Input>>::resolve_identity>
  6e1363:	mov    0x260(%rsp),%rax
  6e136b:	mov    0x268(%rsp),%r13
  6e1373:	cmp    $0xfffffffffffffffe,%rax
  6e1377:	jne    6e1453 <text_column_public_control::main+0x1b53>
  6e137d:	mov    0x2d0(%r12),%rsi
  6e1385:	cmp    %rsi,%r13
  6e1388:	jae    6e3dbd <text_column_public_control::main+0x44bd>
  6e138e:	lea    0x0(,%r13,4),%rdi
  6e1396:	add    %r13,%rdi
  6e1399:	shl    $0x3,%rdi
  6e139d:	add    0x2c8(%r12),%rdi
  6e13a5:	call   *0x36173d(%rip)        # a42ae8 <_DYNAMIC+0x550>
  6e13ab:	test   %al,%al
  6e13ad:	je     6e324f <text_column_public_control::main+0x394f>
  6e13b3:	mov    %r14,0x618(%r12)
  6e13bb:	mov    %rbx,0x620(%r12)
  6e13c3:	movq   $0x0,0x738(%r12)
  6e13cf:	mov    0x690(%r12),%r13
  6e13d7:	mov    0x6b0(%r12),%rax
  6e13df:	mov    %rax,0x10(%rsp)
  6e13e4:	mov    0x6b8(%r12),%rax
  6e13ec:	mov    %rax,0x40(%rsp)
  6e13f1:	lea    0x260(%rsp),%rdi
  6e13f9:	mov    %r12,%rsi
  6e13fc:	call   6ec410 <<gpui::runtime::Runtime<text_column_public_control::Input>>::active_selection>
  6e1401:	cmpb   $0x2,0x274(%rsp)
  6e1409:	jne    6e3259 <text_column_public_control::main+0x3959>
  6e140f:	movq   $0x0,0x260(%rsp)
  6e141b:	lea    0x9c0(%rsp),%rdi
  6e1423:	lea    0x70(%rsp),%rsi
  6e1428:	lea    0x260(%rsp),%r8
  6e1430:	mov    %r14,%rdx
  6e1433:	mov    %rbx,%rcx
  6e1436:	call   6e8500 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::activate_with_editing>
  6e143b:	cmpl   $0xfffffffe,0x9c0(%rsp)
  6e1443:	je     6e14ca <text_column_public_control::main+0x1bca>
  6e1449:	jmp    6e333c <text_column_public_control::main+0x3a3c>
  6e144e:	mov    $0x11,%eax
  6e1453:	movups 0x270(%rsp),%xmm0
  6e145b:	movups 0x280(%rsp),%xmm1
  6e1463:	movzbl 0x290(%rsp),%ecx
  6e146b:	mov    0x291(%rsp),%edx
  6e1472:	mov    %edx,0x110(%rsp)
  6e1479:	mov    0x294(%rsp),%edx
  6e1480:	mov    %edx,0x113(%rsp)
  6e1487:	mov    0x110(%rsp),%edx
  6e148e:	mov    0x113(%rsp),%esi
  6e1495:	mov    %esi,0x9f4(%rsp)
  6e149c:	mov    %edx,0x9f1(%rsp)
  6e14a3:	mov    %rax,0x9c0(%rsp)
  6e14ab:	mov    %r13,0x9c8(%rsp)
  6e14b3:	movups %xmm0,0x9d0(%rsp)
  6e14bb:	movups %xmm1,0x9e0(%rsp)
  6e14c3:	mov    %cl,0x9f0(%rsp)
  6e14ca:	cmpq   $0xfffffffffffffffe,0x9c0(%rsp)
  6e14d3:	jne    6e37b4 <text_column_public_control::main+0x3eb4>
  6e14d9:	mov    0x30(%rsp),%rsi
  6e14de:	lea    0x190(%rsp),%rdi
  6e14e6:	call   6b5ea0 <text_column_public_control::ack::<text_column_public_control::Input>>
  6e14eb:	mov    0x30(%rsp),%rsi
  6e14f0:	test   %rsi,%rsi
  6e14f3:	je     6e3590 <text_column_public_control::main+0x3c90>
  6e14f9:	cmpq   $0x1,0x2b0(%rsi)
  6e1501:	jne    6e35e9 <text_column_public_control::main+0x3ce9>
  6e1507:	movsd  -0x6a09df(%rip),%xmm0        # 40b30 <GCC_except_table0+0xce8>
  6e150f:	movsd  %xmm0,0x260(%rsp)
  6e1518:	lea    0x260(%rsp),%rax
  6e1520:	movsd  0x260(%rsp),%xmm0
  6e1529:	movaps %xmm0,%xmm1
  6e152c:	shufps $0x55,%xmm0,%xmm1
  6e1530:	lea    0x30(%rsp),%rbp
  6e1535:	mov    %rbp,0x260(%rsp)
  6e153d:	lea    0x260(%rsp),%r12
  6e1545:	mov    0x260(%rsp),%rax
  6e154d:	mov    (%rax),%rdi
  6e1550:	movaps %xmm0,0x10(%rsp)
  6e1555:	call   6dd1f0 <text_column_public_control::public_hit>
  6e155a:	mov    %rdx,%rcx
  6e155d:	mov    %rax,0x9c0(%rsp)
  6e1565:	mov    %rdx,0x9c8(%rsp)
  6e156d:	mov    %r14,0x260(%rsp)
  6e1575:	mov    %rbx,0x268(%rsp)
  6e157d:	lea    0x34164c(%rip),%rdx        # a22bd0 <__frame_dummy_init_array_entry+0xbe0>
  6e1584:	test   %rax,%rax
  6e1587:	je     6e3651 <text_column_public_control::main+0x3d51>
  6e158d:	cmp    %r14,%rax
  6e1590:	jne    6e3651 <text_column_public_control::main+0x3d51>
  6e1596:	cmp    %rbx,%rcx
  6e1599:	jne    6e3651 <text_column_public_control::main+0x3d51>
  6e159f:	movsd  -0x6a1337(%rip),%xmm0        # 40270 <GCC_except_table0+0x428>
  6e15a7:	movsd  %xmm0,0x260(%rsp)
  6e15b0:	lea    0x260(%rsp),%rax
  6e15b8:	mov    %rax,0x20(%rsp)
  6e15bd:	movss  0x260(%rsp),%xmm0
  6e15c6:	movss  0x264(%rsp),%xmm1
  6e15cf:	mov    0x30(%rsp),%rdi
  6e15d4:	call   6dd1f0 <text_column_public_control::public_hit>
  6e15d9:	mov    %rax,0x260(%rsp)
  6e15e1:	mov    %rdx,0x268(%rsp)
  6e15e9:	test   %rax,%rax
  6e15ec:	jne    6e3643 <text_column_public_control::main+0x3d43>
  6e15f2:	mov    %rbp,0x260(%rsp)
  6e15fa:	lea    0x260(%rsp),%rax
  6e1602:	mov    0x260(%rsp),%rax
  6e160a:	mov    (%rax),%rsi
  6e160d:	lea    0x230(%rsp),%rdi
  6e1615:	call   6dd300 <text_column_public_control::public_query>
  6e161a:	movq   $0x3,0x9c8(%rsp)
  6e1626:	lea    0x9d0(%rsp),%rdx
  6e162e:	movl   $0x0,0x9d0(%rsp)
  6e1639:	movdqa 0x10(%rsp),%xmm0
  6e163f:	movq   %xmm0,0x9d4(%rsp)
  6e1648:	movl   $0x2,0x9e8(%rsp)
  6e1653:	movl   $0x5,0xa00(%rsp)
  6e165e:	mov    $0xffffffff,%eax
  6e1663:	mov    %rax,0x40(%rsp)
  6e1668:	pxor   %xmm0,%xmm0
  6e166c:	movd   %xmm0,0x10(%rsp)
  6e1672:	lea    0x3410d7(%rip),%rax        # a22750 <__frame_dummy_init_array_entry+0x760>
  6e1679:	mov    %rax,0xd8(%rsp)
  6e1681:	xor    %eax,%eax
  6e1683:	xor    %ebx,%ebx
  6e1685:	data16 cs nopw 0x0(%rax,%rax,1)
  6e1690:	lea    0x1(%rax),%rcx
  6e1694:	mov    %rcx,0x9c0(%rsp)
  6e169c:	lea    (%rax,%rax,2),%rcx
  6e16a0:	mov    (%rdx,%rcx,8),%eax
  6e16a3:	cmp    $0xffffffff,%eax
  6e16a6:	je     6e2ea9 <text_column_public_control::main+0x35a9>
  6e16ac:	lea    (%rdx,%rcx,8),%rcx
  6e16b0:	mov    %rbp,0x260(%rsp)
  6e16b8:	lea    0x260(%rsp),%rdx
  6e16c0:	mov    0x260(%rsp),%r15
  6e16c8:	mov    %eax,0x160(%rsp)
  6e16cf:	mov    0x14(%rcx),%eax
  6e16d2:	lea    0x164(%rsp),%rdx
  6e16da:	mov    %eax,0x10(%rdx)
  6e16dd:	movdqu 0x4(%rcx),%xmm0
  6e16e2:	movdqu %xmm0,(%rdx)
  6e16e6:	lea    0x160(%rsp),%rax
  6e16ee:	mov    0x160(%rsp),%r13d
  6e16f6:	lea    -0x69fb61(%rip),%rcx        # 41b9c <GCC_except_table0+0x1d54>
  6e16fd:	movslq (%rcx,%r13,4),%rax
  6e1701:	add    %rcx,%rax
  6e1704:	jmp    *%rax
  6e1706:	xor    %r12d,%r12d
  6e1709:	mov    (%r15),%r14
  6e170c:	test   %r14,%r14
  6e170f:	je     6e1999 <text_column_public_control::main+0x2099>
  6e1715:	add    $0x8,%r15
  6e1719:	mov    %r14,0xf8(%rsp)
  6e1721:	mov    %r15,0x100(%rsp)
  6e1729:	cmpb   $0x1,0x74e(%r14)
  6e1731:	jne    6e1750 <text_column_public_control::main+0x1e50>
  6e1733:	movq   $0xe,0x70(%rsp)
  6e173c:	jmp    6e1ee0 <text_column_public_control::main+0x25e0>
  6e1741:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6e1750:	movq   $0x0,0x738(%r14)
  6e175b:	cmp    $0x3,%r13d
  6e175f:	je     6e1ab5 <text_column_public_control::main+0x21b5>
  6e1765:	cmp    $0x2,%r13d
  6e1769:	je     6e19d6 <text_column_public_control::main+0x20d6>
  6e176f:	test   %r13d,%r13d
  6e1772:	jne    6e1d55 <text_column_public_control::main+0x2455>
  6e1778:	mov    0x640(%r14),%rax
  6e177f:	test   %rax,%rax
  6e1782:	je     6e179a <text_column_public_control::main+0x1e9a>
  6e1784:	mov    0xd8(%rax),%rax
  6e178b:	test   %rax,%rax
  6e178e:	je     6e179a <text_column_public_control::main+0x1e9a>
  6e1790:	cmpb   $0x0,0x12(%rax)
  6e1794:	jne    6e1d55 <text_column_public_control::main+0x2455>
  6e179a:	test   %r12,%r12
  6e179d:	jne    6e1ce6 <text_column_public_control::main+0x23e6>
  6e17a3:	xor    %r12d,%r12d
  6e17a6:	jmp    6e1d55 <text_column_public_control::main+0x2455>
  6e17ab:	movd   0x164(%rsp),%xmm1
  6e17b4:	movd   0x168(%rsp),%xmm0
  6e17bd:	movd   %xmm1,%edx
  6e17c1:	movd   %xmm0,%eax
  6e17c5:	mov    %edx,%ecx
  6e17c7:	and    $0x7fffffff,%ecx
  6e17cd:	cmp    $0x7f800000,%ecx
  6e17d3:	setge  %cl
  6e17d6:	and    $0x7fffffff,%eax
  6e17db:	cmp    $0x7f800000,%eax
  6e17e0:	setge  %al
  6e17e3:	or     %cl,%al
  6e17e5:	je     6e19b0 <text_column_public_control::main+0x20b0>
  6e17eb:	mov    $0xffffffff,%eax
  6e17f0:	mov    %rax,0x40(%rsp)
  6e17f5:	xor    %r12d,%r12d
  6e17f8:	xor    %ebx,%ebx
  6e17fa:	mov    (%r15),%r14
  6e17fd:	test   %r14,%r14
  6e1800:	jne    6e1715 <text_column_public_control::main+0x1e15>
  6e1806:	jmp    6e1999 <text_column_public_control::main+0x2099>
  6e180b:	cmpl   $0xffffffff,0x40(%rsp)
  6e1810:	je     6e1980 <text_column_public_control::main+0x2080>
  6e1816:	movups 0x168(%rsp),%xmm0
  6e181e:	movaps %xmm0,%xmm1
  6e1821:	unpckhpd %xmm0,%xmm1
  6e1825:	lea    0x260(%rsp),%rdi
  6e182d:	movaps %xmm0,0x50(%rsp)
  6e1832:	call   *0x3612b8(%rip)        # a42af0 <_DYNAMIC+0x558>
  6e1838:	cmpl   $0xfffffffe,0x260(%rsp)
  6e1840:	jne    6e1af2 <text_column_public_control::main+0x21f2>
  6e1846:	mov    (%r15),%r13
  6e1849:	test   %r13,%r13
  6e184c:	je     6e3d86 <text_column_public_control::main+0x4486>
  6e1852:	cmpb   $0x1,0x74e(%r13)
  6e185a:	mov    0x40(%rsp),%rdx
  6e185f:	je     6e3d9d <text_column_public_control::main+0x449d>
  6e1865:	cmpb   $0x1,0x74a(%r13)
  6e186d:	jne    6e3907 <text_column_public_control::main+0x4007>
  6e1873:	cmpb   $0x0,0x74b(%r13)
  6e187b:	jne    6e3907 <text_column_public_control::main+0x4007>
  6e1881:	cmpb   $0x0,0x74c(%r13)
  6e1889:	je     6e3907 <text_column_public_control::main+0x4007>
  6e188f:	cmpq   $0xffffffffffffffff,0x5b8(%r13)
  6e1897:	jne    6e3907 <text_column_public_control::main+0x4007>
  6e189d:	mov    0x690(%r13),%rax
  6e18a4:	cmp    0x698(%r13),%rax
  6e18ab:	jne    6e3907 <text_column_public_control::main+0x4007>
  6e18b1:	mov    0x6a0(%r13),%rax
  6e18b8:	cmp    %rax,0x6a8(%r13)
  6e18bf:	jne    6e3907 <text_column_public_control::main+0x4007>
  6e18c5:	movss  0x740(%r13),%xmm0
  6e18ce:	ucomiss 0x744(%r13),%xmm0
  6e18d6:	jne    6e3907 <text_column_public_control::main+0x4007>
  6e18dc:	jp     6e3907 <text_column_public_control::main+0x4007>
  6e18e2:	mov    %eax,%ecx
  6e18e4:	cvtsi2ss %rcx,%xmm2
  6e18e9:	lea    -0x1(%rdx),%ecx
  6e18ec:	shr    $0x20,%rax
  6e18f0:	mov    %eax,%eax
  6e18f2:	xorps  %xmm1,%xmm1
  6e18f5:	cvtsi2ss %rax,%xmm1
  6e18fa:	movd   %ecx,%xmm0
  6e18fe:	movq   $0x0,0x260(%rsp)
  6e190a:	movss  %xmm2,0x268(%rsp)
  6e1913:	movss  %xmm1,0x26c(%rsp)
  6e191c:	lea    0x260(%rsp),%rdi
  6e1924:	movd   %xmm0,0x20(%rsp)
  6e192a:	movss  0x10(%rsp),%xmm1
  6e1930:	call   *0x3611aa(%rip)        # a42ae0 <_DYNAMIC+0x548>
  6e1936:	test   %al,%al
  6e1938:	je     6e3735 <text_column_public_control::main+0x3e35>
  6e193e:	mov    0x640(%r13),%rax
  6e1945:	test   %rax,%rax
  6e1948:	je     6e1b37 <text_column_public_control::main+0x2237>
  6e194e:	mov    0x100(%rax),%rsi
  6e1955:	test   %rsi,%rsi
  6e1958:	je     6e1b37 <text_column_public_control::main+0x2237>
  6e195e:	lea    0x178(%rsp),%rdi
  6e1966:	call   *0x360e74(%rip)        # a427e0 <_DYNAMIC+0x248>
  6e196c:	jmp    6e1b53 <text_column_public_control::main+0x2253>
  6e1971:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6e1980:	mov    $0xffffffff,%eax
  6e1985:	mov    %rax,0x40(%rsp)
  6e198a:	xor    %r12d,%r12d
  6e198d:	mov    (%r15),%r14
  6e1990:	test   %r14,%r14
  6e1993:	jne    6e1715 <text_column_public_control::main+0x1e15>
  6e1999:	movq   $0xd,0x70(%rsp)
  6e19a2:	movq   $0x0,0x78(%rsp)
  6e19ab:	jmp    6e1ee0 <text_column_public_control::main+0x25e0>
  6e19b0:	inc    %edx
  6e19b2:	mov    %rdx,0x40(%rsp)
  6e19b7:	je     6e34ba <text_column_public_control::main+0x3bba>
  6e19bd:	movd   %xmm0,0x10(%rsp)
  6e19c3:	mov    %rbx,%r12
  6e19c6:	xor    %ebx,%ebx
  6e19c8:	mov    (%r15),%r14
  6e19cb:	test   %r14,%r14
  6e19ce:	jne    6e1715 <text_column_public_control::main+0x1e15>
  6e19d4:	jmp    6e1999 <text_column_public_control::main+0x2099>
  6e19d6:	test   %rbx,%rbx
  6e19d9:	sete   %r15b
  6e19dd:	cmpb   $0x1,0x74a(%r14)
  6e19e5:	jne    6e1ed7 <text_column_public_control::main+0x25d7>
  6e19eb:	cmpb   $0x0,0x74b(%r14)
  6e19f3:	jne    6e1ed7 <text_column_public_control::main+0x25d7>
  6e19f9:	cmpb   $0x0,0x74c(%r14)
  6e1a01:	je     6e1ed7 <text_column_public_control::main+0x25d7>
  6e1a07:	cmpq   $0xffffffffffffffff,0x5b8(%r14)
  6e1a0f:	jne    6e1ed7 <text_column_public_control::main+0x25d7>
  6e1a15:	mov    0x690(%r14),%rax
  6e1a1c:	cmp    0x698(%r14),%rax
  6e1a23:	jne    6e1ed7 <text_column_public_control::main+0x25d7>
  6e1a29:	mov    0x6a8(%r14),%rax
  6e1a30:	cmp    0x6a0(%r14),%rax
  6e1a37:	jne    6e1ed7 <text_column_public_control::main+0x25d7>
  6e1a3d:	movss  0x740(%r14),%xmm0
  6e1a46:	ucomiss 0x744(%r14),%xmm0
  6e1a4e:	jne    6e1ed7 <text_column_public_control::main+0x25d7>
  6e1a54:	jp     6e1ed7 <text_column_public_control::main+0x25d7>
  6e1a5a:	mov    0x40(%rsp),%rax
  6e1a5f:	cmp    $0xffffffff,%eax
  6e1a62:	je     6e20f0 <text_column_public_control::main+0x27f0>
  6e1a68:	dec    %eax
  6e1a6a:	movd   %eax,%xmm0
  6e1a6e:	mov    0x640(%r14),%rax
  6e1a75:	test   %rax,%rax
  6e1a78:	je     6e20bf <text_column_public_control::main+0x27bf>
  6e1a7e:	mov    0xd8(%rax),%rax
  6e1a85:	test   %rax,%rax
  6e1a88:	je     6e20bf <text_column_public_control::main+0x27bf>
  6e1a8e:	cmpb   $0x0,0x12(%rax)
  6e1a92:	je     6e20bf <text_column_public_control::main+0x27bf>
  6e1a98:	mov    %r14,%rdi
  6e1a9b:	movd   0x10(%rsp),%xmm1
  6e1aa1:	call   6f1ac0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::inspector_pick>
  6e1aa6:	mov    %rax,0x20(%rsp)
  6e1aab:	mov    %rdx,0x50(%rsp)
  6e1ab0:	jmp    6e221d <text_column_public_control::main+0x291d>
  6e1ab5:	test   %rbx,%rbx
  6e1ab8:	je     6e1d55 <text_column_public_control::main+0x2455>
  6e1abe:	mov    0x40(%rsp),%rax
  6e1ac3:	cmp    $0xffffffff,%eax
  6e1ac6:	je     6e1dc6 <text_column_public_control::main+0x24c6>
  6e1acc:	dec    %eax
  6e1ace:	mov    %eax,0xc64(%rsp)
  6e1ad5:	movss  0x10(%rsp),%xmm0
  6e1adb:	movss  %xmm0,0xc68(%rsp)
  6e1ae4:	movd   %eax,%xmm0
  6e1ae8:	mov    $0x1,%eax
  6e1aed:	jmp    6e1dc8 <text_column_public_control::main+0x24c8>
  6e1af2:	mov    0x290(%rsp),%rax
  6e1afa:	mov    %rax,0xa0(%rsp)
  6e1b02:	movups 0x260(%rsp),%xmm0
  6e1b0a:	movups 0x270(%rsp),%xmm1
  6e1b12:	movups 0x280(%rsp),%xmm2
  6e1b1a:	movaps %xmm2,0x90(%rsp)
  6e1b22:	movaps %xmm1,0x80(%rsp)
  6e1b2a:	movaps %xmm0,0x70(%rsp)
  6e1b2f:	xor    %r12d,%r12d
  6e1b32:	jmp    6e1ee0 <text_column_public_control::main+0x25e0>
  6e1b37:	movq   $0x4,0x178(%rsp)
  6e1b43:	lea    0x180(%rsp),%rax
  6e1b4b:	pxor   %xmm0,%xmm0
  6e1b4f:	movdqu %xmm0,(%rax)
  6e1b53:	mov    0x5b0(%r13),%rbp
  6e1b5a:	test   %rbp,%rbp
  6e1b5d:	je     6e3735 <text_column_public_control::main+0x3e35>
  6e1b63:	mov    0x5a8(%r13),%r14
  6e1b6a:	mov    %rbp,%rbx
  6e1b6d:	shl    $0x6,%rbx
  6e1b71:	lea    -0x1(%rbp),%r12
  6e1b75:	jmp    6e1b8d <text_column_public_control::main+0x228d>
  6e1b77:	nopw   0x0(%rax,%rax,1)
  6e1b80:	dec    %r12
  6e1b83:	add    $0xffffffffffffffc0,%rbx
  6e1b87:	je     6e3735 <text_column_public_control::main+0x3e35>
  6e1b8d:	cmpb   $0x0,-0x2(%r14,%rbx,1)
  6e1b93:	jne    6e1bc0 <text_column_public_control::main+0x22c0>
  6e1b95:	movzbl -0x3(%r14,%rbx,1),%eax
  6e1b9b:	sub    $0x2,%al
  6e1b9d:	movzbl %al,%eax
  6e1ba0:	mov    $0x8,%ecx
  6e1ba5:	cmovb  %ecx,%eax
  6e1ba8:	cmp    $0x7,%al
  6e1baa:	je     6e1bc0 <text_column_public_control::main+0x22c0>
  6e1bac:	movzbl %al,%eax
  6e1baf:	cmp    $0x4,%eax
  6e1bb2:	jne    6e1b80 <text_column_public_control::main+0x2280>
  6e1bb4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6e1bc0:	mov    0x188(%rsp),%rax
  6e1bc8:	mov    %rax,0x270(%rsp)
  6e1bd0:	movups 0x178(%rsp),%xmm0
  6e1bd8:	movaps %xmm0,0x260(%rsp)
  6e1be0:	mov    0x640(%r13),%rax
  6e1be7:	test   %rax,%rax
  6e1bea:	je     6e1c00 <text_column_public_control::main+0x2300>
  6e1bec:	cmpq   $0x0,(%rax)
  6e1bf0:	setne  %al
  6e1bf3:	jmp    6e1c02 <text_column_public_control::main+0x2302>
  6e1bf5:	data16 cs nopw 0x0(%rax,%rax,1)
  6e1c00:	xor    %eax,%eax
  6e1c02:	movzbl %al,%ecx
  6e1c05:	mov    %r14,%rdi
  6e1c08:	mov    %rbp,%rsi
  6e1c0b:	lea    0x260(%rsp),%rdx
  6e1c13:	mov    %r12,%r8
  6e1c16:	movd   0x20(%rsp),%xmm0
  6e1c1c:	movss  0x10(%rsp),%xmm1
  6e1c22:	call   *0x360ed0(%rip)        # a42af8 <_DYNAMIC+0x560>
  6e1c28:	test   %al,%al
  6e1c2a:	je     6e1b80 <text_column_public_control::main+0x2280>
  6e1c30:	mov    0x5a8(%r13),%rax
  6e1c37:	mov    0x5b0(%r13),%rsi
  6e1c3e:	mov    $0x1,%cl
  6e1c40:	mov    %r12,%rdi
  6e1c43:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6e1c50:	test   $0x1,%cl
  6e1c53:	je     6e3735 <text_column_public_control::main+0x3e35>
  6e1c59:	cmp    %rsi,%rdi
  6e1c5c:	jae    6e3dea <text_column_public_control::main+0x44ea>
  6e1c62:	shl    $0x6,%rdi
  6e1c66:	movzbl 0x3d(%rax,%rdi,1),%edx
  6e1c6b:	mov    0x38(%rax,%rdi,1),%edi
  6e1c6f:	and    $0x1ffff,%edi
  6e1c75:	cmp    $0x1ffff,%rdi
  6e1c7c:	setne  %cl
  6e1c7f:	sub    $0x2,%dl
  6e1c82:	movzbl %dl,%edx
  6e1c85:	mov    $0x8,%r8d
  6e1c8b:	cmovb  %r8d,%edx
  6e1c8f:	cmp    $0x4,%dl
  6e1c92:	je     6e1c9c <text_column_public_control::main+0x239c>
  6e1c94:	movzbl %dl,%edx
  6e1c97:	cmp    $0x7,%edx
  6e1c9a:	jne    6e1c50 <text_column_public_control::main+0x2350>
  6e1c9c:	mov    (%r15),%rbx
  6e1c9f:	test   %rbx,%rbx
  6e1ca2:	je     6e1cc7 <text_column_public_control::main+0x23c7>
  6e1ca4:	cmpb   $0x0,0x74e(%rbx)
  6e1cab:	lea    0x30(%rsp),%rbp
  6e1cb0:	je     6e1f7b <text_column_public_control::main+0x267b>
  6e1cb6:	movq   $0xe,0x70(%rsp)
  6e1cbf:	xor    %r12d,%r12d
  6e1cc2:	jmp    6e1ee0 <text_column_public_control::main+0x25e0>
  6e1cc7:	movq   $0xd,0x70(%rsp)
  6e1cd0:	movq   $0x0,0x78(%rsp)
  6e1cd9:	lea    0x30(%rsp),%rbp
  6e1cde:	xor    %r12d,%r12d
  6e1ce1:	jmp    6e1ee0 <text_column_public_control::main+0x25e0>
  6e1ce6:	cmp    0x5e0(%r14),%r12
  6e1ced:	jne    6e17a3 <text_column_public_control::main+0x1ea3>
  6e1cf3:	lea    0xc60(%rsp),%rdi
  6e1cfb:	mov    %r14,%rsi
  6e1cfe:	mov    0x68(%rsp),%rdx
  6e1d03:	call   70cd00 <<gpui::runtime::Runtime<text_column_public_control::Input>>::resolve_identity>
  6e1d08:	mov    0xc60(%rsp),%rax
  6e1d10:	cmp    $0xfffffffffffffffe,%rax
  6e1d14:	jne    6e206b <text_column_public_control::main+0x276b>
  6e1d1a:	mov    0xc68(%rsp),%rdi
  6e1d22:	mov    0x2d0(%r14),%rsi
  6e1d29:	cmp    %rsi,%rdi
  6e1d2c:	jae    6e3dc9 <text_column_public_control::main+0x44c9>
  6e1d32:	mov    0x2c8(%r14),%rax
  6e1d39:	lea    (%rdi,%rdi,4),%rcx
  6e1d3d:	mov    0x20(%rax,%rcx,8),%eax
  6e1d41:	and    $0xf,%eax
  6e1d44:	lea    -0x3(%rax),%ecx
  6e1d47:	cmp    $0x7,%ecx
  6e1d4a:	jb     6e1d55 <text_column_public_control::main+0x2455>
  6e1d4c:	cmp    $0x2,%eax
  6e1d4f:	jae    6e25e4 <text_column_public_control::main+0x2ce4>
  6e1d55:	movups 0x690(%r14),%xmm0
  6e1d5d:	movzbl 0x74c(%r14),%eax
  6e1d65:	cmpq   $0x0,0x6b0(%r14)
  6e1d6d:	je     6e1d7d <text_column_public_control::main+0x247d>
  6e1d6f:	test   %al,%al
  6e1d71:	je     6e1d81 <text_column_public_control::main+0x2481>
  6e1d73:	cmpq   $0xffffffffffffffff,0x5b8(%r14)
  6e1d7b:	jne    6e1d81 <text_column_public_control::main+0x2481>
  6e1d7d:	xor    %edx,%edx
  6e1d7f:	jmp    6e1d8d <text_column_public_control::main+0x248d>
  6e1d81:	mov    0x6c0(%r14),%rcx
  6e1d88:	mov    $0x1,%edx
  6e1d8d:	mov    0x738(%r14),%rsi
  6e1d94:	mov    %rdx,0x78(%rsp)
  6e1d99:	mov    %rcx,0x80(%rsp)
  6e1da1:	movups %xmm0,0x88(%rsp)
  6e1da9:	mov    %rsi,0x98(%rsp)
  6e1db1:	mov    %al,0xa0(%rsp)
  6e1db8:	movq   $0xfffffffffffffffe,0x70(%rsp)
  6e1dc1:	jmp    6e1ee0 <text_column_public_control::main+0x25e0>
  6e1dc6:	xor    %eax,%eax
  6e1dc8:	mov    %eax,0xc60(%rsp)
  6e1dcf:	movzbl 0x74b(%r14),%ecx
  6e1dd7:	xor    $0x1,%cl
  6e1dda:	and    0x74a(%r14),%cl
  6e1de1:	and    0x74c(%r14),%cl
  6e1de8:	mov    0x5b8(%r14),%rdx
  6e1def:	cmp    $0xffffffffffffffff,%rdx
  6e1df3:	sete   %sil
  6e1df7:	and    %cl,%sil
  6e1dfa:	cmp    $0x1,%sil
  6e1dfe:	jne    6e1e98 <text_column_public_control::main+0x2598>
  6e1e04:	mov    0x690(%r14),%rcx
  6e1e0b:	cmp    0x698(%r14),%rcx
  6e1e12:	jne    6e1ed7 <text_column_public_control::main+0x25d7>
  6e1e18:	mov    0x6a8(%r14),%rcx
  6e1e1f:	cmp    0x6a0(%r14),%rcx
  6e1e26:	jne    6e1ed7 <text_column_public_control::main+0x25d7>
  6e1e2c:	movss  0x740(%r14),%xmm1
  6e1e35:	ucomiss 0x744(%r14),%xmm1
  6e1e3d:	jne    6e1ed7 <text_column_public_control::main+0x25d7>
  6e1e43:	jp     6e1ed7 <text_column_public_control::main+0x25d7>
  6e1e49:	test   %eax,%eax
  6e1e4b:	je     6e2211 <text_column_public_control::main+0x2911>
  6e1e51:	mov    0x640(%r14),%rax
  6e1e58:	test   %rax,%rax
  6e1e5b:	je     6e21e3 <text_column_public_control::main+0x28e3>
  6e1e61:	mov    0xd8(%rax),%rax
  6e1e68:	test   %rax,%rax
  6e1e6b:	je     6e21e3 <text_column_public_control::main+0x28e3>
  6e1e71:	cmpb   $0x0,0x12(%rax)
  6e1e75:	je     6e21e3 <text_column_public_control::main+0x28e3>
  6e1e7b:	mov    %r14,%rdi
  6e1e7e:	movss  0x10(%rsp),%xmm1
  6e1e84:	call   6f1ac0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::inspector_pick>
  6e1e89:	mov    %rax,0x20(%rsp)
  6e1e8e:	mov    %rdx,0x50(%rsp)
  6e1e93:	jmp    6e221a <text_column_public_control::main+0x291a>
  6e1e98:	movq   $0x12,0x260(%rsp)
  6e1ea4:	test   %cl,%cl
  6e1ea6:	je     6e1ed7 <text_column_public_control::main+0x25d7>
  6e1ea8:	cmp    $0xffffffffffffffff,%rdx
  6e1eac:	je     6e1ed7 <text_column_public_control::main+0x25d7>
  6e1eae:	mov    0x6a8(%r14),%rax
  6e1eb5:	cmp    0x6a0(%r14),%rax
  6e1ebc:	jne    6e1ed7 <text_column_public_control::main+0x25d7>
  6e1ebe:	movss  0x740(%r14),%xmm0
  6e1ec7:	ucomiss 0x744(%r14),%xmm0
  6e1ecf:	jne    6e1ed7 <text_column_public_control::main+0x25d7>
  6e1ed1:	jnp    6e20fe <text_column_public_control::main+0x27fe>
  6e1ed7:	movq   $0x12,0x70(%rsp)
  6e1ee0:	cmpq   $0xfffffffffffffffe,0x70(%rsp)
  6e1ee6:	jne    6e373e <text_column_public_control::main+0x3e3e>
  6e1eec:	lea    0x78(%rsp),%rax
  6e1ef1:	movdqu (%rax),%xmm0
  6e1ef5:	movdqu 0x10(%rax),%xmm1
  6e1efa:	movupd 0x20(%rax),%xmm2
  6e1eff:	movapd %xmm2,0x200(%rsp)
  6e1f08:	movdqa %xmm1,0x1f0(%rsp)
  6e1f11:	movdqa %xmm0,0x1e0(%rsp)
  6e1f1a:	mov    0x1f0(%rsp),%rax
  6e1f22:	cmp    0x1a0(%rsp),%rax
  6e1f2a:	jne    6e337d <text_column_public_control::main+0x3a7d>
  6e1f30:	mov    0x1f8(%rsp),%rax
  6e1f38:	cmp    0x1a8(%rsp),%rax
  6e1f40:	jne    6e3396 <text_column_public_control::main+0x3a96>
  6e1f46:	cmpq   $0x0,0x1e0(%rsp)
  6e1f4f:	jne    6e33bc <text_column_public_control::main+0x3abc>
  6e1f55:	mov    0x9c0(%rsp),%rax
  6e1f5d:	mov    %r12,%rbx
  6e1f60:	cmp    %rax,0x9c8(%rsp)
  6e1f68:	lea    0x9d0(%rsp),%rdx
  6e1f70:	jne    6e1690 <text_column_public_control::main+0x1d90>
  6e1f76:	jmp    6e2ea9 <text_column_public_control::main+0x35a9>
  6e1f7b:	cmpb   $0x1,0x74a(%rbx)
  6e1f82:	jne    6e205a <text_column_public_control::main+0x275a>
  6e1f88:	cmpb   $0x0,0x74b(%rbx)
  6e1f8f:	jne    6e205a <text_column_public_control::main+0x275a>
  6e1f95:	cmpb   $0x0,0x74c(%rbx)
  6e1f9c:	je     6e205a <text_column_public_control::main+0x275a>
  6e1fa2:	cmpq   $0xffffffffffffffff,0x5b8(%rbx)
  6e1faa:	jne    6e205a <text_column_public_control::main+0x275a>
  6e1fb0:	mov    0x690(%rbx),%rax
  6e1fb7:	cmp    0x698(%rbx),%rax
  6e1fbe:	jne    6e205a <text_column_public_control::main+0x275a>
  6e1fc4:	mov    0x6a8(%rbx),%rcx
  6e1fcb:	cmp    0x6a0(%rbx),%rcx
  6e1fd2:	jne    6e205a <text_column_public_control::main+0x275a>
  6e1fd8:	movss  0x740(%rbx),%xmm0
  6e1fe0:	movss  0x744(%rbx),%xmm1
  6e1fe8:	movss  %xmm1,0x20(%rsp)
  6e1fee:	ucomiss %xmm1,%xmm0
  6e1ff1:	jne    6e205a <text_column_public_control::main+0x275a>
  6e1ff3:	jp     6e205a <text_column_public_control::main+0x275a>
  6e1ff5:	movq   $0x0,0xe0(%rsp)
  6e2001:	movq   $0x8,0xe8(%rsp)
  6e200d:	movq   $0x0,0xf0(%rsp)
  6e2019:	mov    0x640(%rbx),%r14
  6e2020:	test   %r14,%r14
  6e2023:	je     6e25a6 <text_column_public_control::main+0x2ca6>
  6e2029:	mov    0x5a8(%rbx),%r13
  6e2030:	mov    0x5b0(%rbx),%rbp
  6e2037:	mov    0x100(%r14),%rsi
  6e203e:	test   %rsi,%rsi
  6e2041:	je     6e26cc <text_column_public_control::main+0x2dcc>
  6e2047:	lea    0x260(%rsp),%rdi
  6e204f:	call   *0x36078b(%rip)        # a427e0 <_DYNAMIC+0x248>
  6e2055:	jmp    6e26e6 <text_column_public_control::main+0x2de6>
  6e205a:	movq   $0x12,0x70(%rsp)
  6e2063:	xor    %r12d,%r12d
  6e2066:	jmp    6e1ee0 <text_column_public_control::main+0x25e0>
  6e206b:	cmp    $0xd,%rax
  6e206f:	jl     6e2093 <text_column_public_control::main+0x2793>
  6e2071:	cmp    $0x21,%rax
  6e2075:	je     6e2093 <text_column_public_control::main+0x2793>
  6e2077:	cmp    $0x26,%rax
  6e207b:	jne    6e17a3 <text_column_public_control::main+0x1ea3>
  6e2081:	mov    0xc68(%rsp),%rsi
  6e2089:	lea    0xc70(%rsp),%rax
  6e2091:	jmp    6e20a3 <text_column_public_control::main+0x27a3>
  6e2093:	mov    0xc78(%rsp),%rsi
  6e209b:	lea    0xc80(%rsp),%rax
  6e20a3:	test   %rsi,%rsi
  6e20a6:	je     6e17a3 <text_column_public_control::main+0x1ea3>
  6e20ac:	mov    (%rax),%rdi
  6e20af:	mov    $0x1,%edx
  6e20b4:	call   *0x360746(%rip)        # a42800 <_DYNAMIC+0x268>
  6e20ba:	jmp    6e17a3 <text_column_public_control::main+0x1ea3>
  6e20bf:	mov    %r14,%rdi
  6e20c2:	movd   0x10(%rsp),%xmm1
  6e20c8:	call   70cfe0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit>
  6e20cd:	test   $0x1,%al
  6e20cf:	je     6e20f0 <text_column_public_control::main+0x27f0>
  6e20d1:	lea    0x5e0(%r14),%rdi
  6e20d8:	mov    %rdx,%rsi
  6e20db:	call   *0x360957(%rip)        # a42a38 <_DYNAMIC+0x4a0>
  6e20e1:	mov    %rax,0x20(%rsp)
  6e20e6:	mov    %rdx,0x50(%rsp)
  6e20eb:	jmp    6e221d <text_column_public_control::main+0x291d>
  6e20f0:	movq   $0x0,0x20(%rsp)
  6e20f9:	jmp    6e221d <text_column_public_control::main+0x291d>
  6e20fe:	mov    0x698(%r14),%rax
  6e2105:	cmp    $0xffffffffffffffff,%rax
  6e2109:	je     6e1ed7 <text_column_public_control::main+0x25d7>
  6e210f:	inc    %rax
  6e2112:	mov    0x690(%r14),%rcx
  6e2119:	cmp    %rcx,%rax
  6e211c:	jne    6e1ed7 <text_column_public_control::main+0x25d7>
  6e2122:	cmp    %rcx,0x6c0(%r14)
  6e2129:	jne    6e1ed7 <text_column_public_control::main+0x25d7>
  6e212f:	cmpq   $0x0,0x60(%rsp)
  6e2135:	je     6e1ed7 <text_column_public_control::main+0x25d7>
  6e213b:	cmpq   $0x0,0x6b0(%r14)
  6e2143:	je     6e1ed7 <text_column_public_control::main+0x25d7>
  6e2149:	mov    0x60(%rsp),%rax
  6e214e:	cmp    %rax,0x6b8(%r14)
  6e2155:	jne    6e1ed7 <text_column_public_control::main+0x25d7>
  6e215b:	cmp    0x5e0(%r14),%rbx
  6e2162:	jne    6e1ed7 <text_column_public_control::main+0x25d7>
  6e2168:	mov    %r14,%rdi
  6e216b:	lea    0xc60(%rsp),%rsi
  6e2173:	call   6f07e0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::pointer_hit>
  6e2178:	mov    %rdx,0x50(%rsp)
  6e217d:	mov    %rax,%r15
  6e2180:	mov    0x640(%r14),%rax
  6e2187:	test   %rax,%rax
  6e218a:	je     6e21cf <text_column_public_control::main+0x28cf>
  6e218c:	cmpq   $0x0,0xd8(%rax)
  6e2194:	je     6e21cf <text_column_public_control::main+0x28cf>
  6e2196:	cmp    %rbx,%r15
  6e2199:	jne    6e1ed7 <text_column_public_control::main+0x25d7>
  6e219f:	mov    0x50(%rsp),%rax
  6e21a4:	cmp    0x68(%rsp),%rax
  6e21a9:	jne    6e1ed7 <text_column_public_control::main+0x25d7>
  6e21af:	mov    %r14,%rdi
  6e21b2:	mov    %rbx,%rsi
  6e21b5:	mov    0x68(%rsp),%rdx
  6e21ba:	lea    0xc60(%rsp),%rcx
  6e21c2:	call   6f0910 <<gpui::runtime::Runtime<text_column_public_control::Input>>::inspector_focus_hit>
  6e21c7:	test   %al,%al
  6e21c9:	je     6e1ed7 <text_column_public_control::main+0x25d7>
  6e21cf:	mov    %r15,0x20(%rsp)
  6e21d4:	lea    0x260(%rsp),%rdi
  6e21dc:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e21e1:	jmp    6e221a <text_column_public_control::main+0x291a>
  6e21e3:	mov    %r14,%rdi
  6e21e6:	movss  0x10(%rsp),%xmm1
  6e21ec:	call   70cfe0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit>
  6e21f1:	test   $0x1,%al
  6e21f3:	je     6e2211 <text_column_public_control::main+0x2911>
  6e21f5:	lea    0x5e0(%r14),%rdi
  6e21fc:	mov    %rdx,%rsi
  6e21ff:	call   *0x360833(%rip)        # a42a38 <_DYNAMIC+0x4a0>
  6e2205:	mov    %rax,0x20(%rsp)
  6e220a:	mov    %rdx,0x50(%rsp)
  6e220f:	jmp    6e221a <text_column_public_control::main+0x291a>
  6e2211:	movq   $0x0,0x20(%rsp)
  6e221a:	xor    %r15d,%r15d
  6e221d:	mov    0x640(%r14),%rax
  6e2224:	test   %rax,%rax
  6e2227:	je     6e223b <text_column_public_control::main+0x293b>
  6e2229:	mov    0xd8(%rax),%rax
  6e2230:	test   %rax,%rax
  6e2233:	je     6e223b <text_column_public_control::main+0x293b>
  6e2235:	movzbl 0x12(%rax),%eax
  6e2239:	jmp    6e223d <text_column_public_control::main+0x293d>
  6e223b:	xor    %eax,%eax
  6e223d:	cmp    $0x2,%r13d
  6e2241:	jne    6e234c <text_column_public_control::main+0x2a4c>
  6e2247:	mov    0x618(%r14),%rbx
  6e224e:	mov    0x620(%r14),%r15
  6e2255:	mov    0x20(%rsp),%rdx
  6e225a:	test   %rdx,%rdx
  6e225d:	sete   %cl
  6e2260:	or     %al,%cl
  6e2262:	test   $0x1,%cl
  6e2265:	je     6e23bd <text_column_public_control::main+0x2abd>
  6e226b:	movq   $0x0,0x618(%r14)
  6e2276:	lea    0x260(%rsp),%rdi
  6e227e:	mov    %r14,%rsi
  6e2281:	mov    %rbx,%rdx
  6e2284:	mov    %r15,%rcx
  6e2287:	call   6f1810 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::publish_focus_change>
  6e228c:	mov    0x260(%rsp),%rax
  6e2294:	lea    0x268(%rsp),%rcx
  6e229c:	movups (%rcx),%xmm0
  6e229f:	movups 0x10(%rcx),%xmm1
  6e22a3:	movups 0x20(%rcx),%xmm2
  6e22a7:	movaps %xmm0,0xc60(%rsp)
  6e22af:	movaps %xmm1,0xc70(%rsp)
  6e22b7:	movaps %xmm2,0xc80(%rsp)
  6e22bf:	cmp    $0xfffffffffffffffe,%rax
  6e22c3:	jne    6e24ef <text_column_public_control::main+0x2bef>
  6e22c9:	movaps 0xc60(%rsp),%xmm0
  6e22d1:	movaps 0xc70(%rsp),%xmm1
  6e22d9:	movaps 0xc80(%rsp),%xmm2
  6e22e1:	movaps %xmm2,0x130(%rsp)
  6e22e9:	movaps %xmm1,0x120(%rsp)
  6e22f1:	movaps %xmm0,0x110(%rsp)
  6e22f9:	cmpq   $0xffffffffffffffff,0x5b8(%r14)
  6e2301:	je     6e267e <text_column_public_control::main+0x2d7e>
  6e2307:	mov    0x698(%r14),%rax
  6e230e:	cmp    $0xffffffffffffffff,%rax
  6e2312:	mov    0x20(%rsp),%r12
  6e2317:	je     6e2598 <text_column_public_control::main+0x2c98>
  6e231d:	inc    %rax
  6e2320:	cmp    0x690(%r14),%rax
  6e2327:	jne    6e2598 <text_column_public_control::main+0x2c98>
  6e232d:	cmpq   $0x0,0x6b0(%r14)
  6e2335:	je     6e2598 <text_column_public_control::main+0x2c98>
  6e233b:	mov    0x6b8(%r14),%rax
  6e2342:	mov    %rax,0x60(%rsp)
  6e2347:	jmp    6e268c <text_column_public_control::main+0x2d8c>
  6e234c:	test   %r15b,%r15b
  6e234f:	mov    0x20(%rsp),%rcx
  6e2354:	jne    6e238e <text_column_public_control::main+0x2a8e>
  6e2356:	test   %rcx,%rcx
  6e2359:	je     6e238e <text_column_public_control::main+0x2a8e>
  6e235b:	cmp    %rcx,%rbx
  6e235e:	jne    6e238e <text_column_public_control::main+0x2a8e>
  6e2360:	mov    0x50(%rsp),%rcx
  6e2365:	cmp    %rcx,0x68(%rsp)
  6e236a:	jne    6e238e <text_column_public_control::main+0x2a8e>
  6e236c:	test   %al,%al
  6e236e:	je     6e2565 <text_column_public_control::main+0x2c65>
  6e2374:	lea    0x70(%rsp),%rdi
  6e2379:	mov    %r14,%rsi
  6e237c:	mov    %rbx,%rdx
  6e237f:	mov    0x68(%rsp),%rcx
  6e2384:	call   6f5b60 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::inspector_select>
  6e2389:	jmp    6e1ee0 <text_column_public_control::main+0x25e0>
  6e238e:	movzbl 0x74c(%r14),%eax
  6e2396:	cmpq   $0x0,0x6b0(%r14)
  6e239e:	je     6e23b6 <text_column_public_control::main+0x2ab6>
  6e23a0:	test   %al,%al
  6e23a2:	je     6e2521 <text_column_public_control::main+0x2c21>
  6e23a8:	cmpq   $0xffffffffffffffff,0x5b8(%r14)
  6e23b0:	jne    6e2521 <text_column_public_control::main+0x2c21>
  6e23b6:	xor    %edx,%edx
  6e23b8:	jmp    6e252d <text_column_public_control::main+0x2c2d>
  6e23bd:	mov    $0x11,%eax
  6e23c2:	cmp    0x5e0(%r14),%rdx
  6e23c9:	jne    6e24bc <text_column_public_control::main+0x2bbc>
  6e23cf:	lea    0x260(%rsp),%rdi
  6e23d7:	mov    %r14,%rsi
  6e23da:	mov    0x50(%rsp),%rdx
  6e23df:	call   70cd00 <<gpui::runtime::Runtime<text_column_public_control::Input>>::resolve_identity>
  6e23e4:	mov    0x260(%rsp),%rax
  6e23ec:	mov    0x268(%rsp),%rdi
  6e23f4:	cmp    $0xfffffffffffffffe,%rax
  6e23f8:	jne    6e24bc <text_column_public_control::main+0x2bbc>
  6e23fe:	mov    0x2d0(%r14),%rsi
  6e2405:	cmp    %rsi,%rdi
  6e2408:	jae    6e3ddb <text_column_public_control::main+0x44db>
  6e240e:	mov    0x2c8(%r14),%rax
  6e2415:	lea    (%rdi,%rdi,4),%rcx
  6e2419:	mov    0x20(%rax,%rcx,8),%edi
  6e241d:	call   6f84b0 <<gpui::runtime::Node>::kind>
  6e2422:	cmp    $0x4,%al
  6e2424:	jne    6e2a7b <text_column_public_control::main+0x317b>
  6e242a:	mov    0x40(%rsp),%rax
  6e242f:	cmp    $0xffffffff,%eax
  6e2432:	mov    0x20(%rsp),%rdx
  6e2437:	je     6e3e0f <text_column_public_control::main+0x450f>
  6e243d:	dec    %eax
  6e243f:	movd   %eax,%xmm0
  6e2443:	lea    0x260(%rsp),%rdi
  6e244b:	mov    %r14,%rsi
  6e244e:	mov    0x50(%rsp),%rcx
  6e2453:	movss  0x10(%rsp),%xmm1
  6e2459:	xor    %r8d,%r8d
  6e245c:	call   6f11f0 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::select_pointer>
  6e2461:	mov    0x260(%rsp),%rax
  6e2469:	lea    0x268(%rsp),%rcx
  6e2471:	movups (%rcx),%xmm0
  6e2474:	movups 0x10(%rcx),%xmm1
  6e2478:	movups 0x20(%rcx),%xmm2
  6e247c:	lea    0x78(%rsp),%rcx
  6e2481:	movups %xmm2,0x20(%rcx)
  6e2485:	movups %xmm1,0x10(%rcx)
  6e2489:	movups %xmm0,(%rcx)
  6e248c:	cmp    $0xfffffffffffffffe,%rax
  6e2490:	jne    6e2b8c <text_column_public_control::main+0x328c>
  6e2496:	movq   $0xfffffffffffffffe,0x70(%rsp)
  6e249f:	mov    0x20(%rsp),%r12
  6e24a4:	mov    0x50(%rsp),%rax
  6e24a9:	mov    %rax,0x68(%rsp)
  6e24ae:	movq   $0x0,0x60(%rsp)
  6e24b7:	jmp    6e1ee0 <text_column_public_control::main+0x25e0>
  6e24bc:	lea    0x270(%rsp),%rdx
  6e24c4:	mov    0x20(%rdx),%rcx
  6e24c8:	lea    0x78(%rsp),%rsi
  6e24cd:	mov    %rcx,0x28(%rsi)
  6e24d1:	movups (%rdx),%xmm0
  6e24d4:	movups 0x10(%rdx),%xmm1
  6e24d8:	movups %xmm1,0x18(%rsi)
  6e24dc:	movups %xmm0,0x8(%rsi)
  6e24e0:	mov    %rax,0x70(%rsp)
  6e24e5:	mov    %rdi,0x78(%rsp)
  6e24ea:	jmp    6e1ee0 <text_column_public_control::main+0x25e0>
  6e24ef:	movaps 0xc60(%rsp),%xmm0
  6e24f7:	movaps 0xc70(%rsp),%xmm1
  6e24ff:	movaps 0xc80(%rsp),%xmm2
  6e2507:	lea    0x78(%rsp),%rcx
  6e250c:	movups %xmm2,0x20(%rcx)
  6e2510:	movups %xmm1,0x10(%rcx)
  6e2514:	movups %xmm0,(%rcx)
  6e2517:	mov    %rax,0x70(%rsp)
  6e251c:	jmp    6e1ee0 <text_column_public_control::main+0x25e0>
  6e2521:	mov    0x6c0(%r14),%rcx
  6e2528:	mov    $0x1,%edx
  6e252d:	movups 0x690(%r14),%xmm0
  6e2535:	mov    0x738(%r14),%rsi
  6e253c:	mov    %rdx,0x78(%rsp)
  6e2541:	mov    %rcx,0x80(%rsp)
  6e2549:	movups %xmm0,0x88(%rsp)
  6e2551:	mov    %rsi,0x98(%rsp)
  6e2559:	mov    %al,0xa0(%rsp)
  6e2560:	jmp    6e1eec <text_column_public_control::main+0x25ec>
  6e2565:	movq   $0x0,0x260(%rsp)
  6e2571:	lea    0x70(%rsp),%rdi
  6e2576:	lea    0xf8(%rsp),%rsi
  6e257e:	mov    %rbx,%rdx
  6e2581:	mov    0x68(%rsp),%rcx
  6e2586:	lea    0x260(%rsp),%r8
  6e258e:	call   6e8500 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::activate_with_editing>
  6e2593:	jmp    6e1ee0 <text_column_public_control::main+0x25e0>
  6e2598:	movq   $0x0,0x60(%rsp)
  6e25a1:	jmp    6e268c <text_column_public_control::main+0x2d8c>
  6e25a6:	mov    0x738(%rbx),%rcx
  6e25ad:	movq   $0x0,0x78(%rsp)
  6e25b6:	mov    %rax,0x88(%rsp)
  6e25be:	mov    %rax,0x90(%rsp)
  6e25c6:	mov    %rcx,0x98(%rsp)
  6e25ce:	movb   $0x1,0xa0(%rsp)
  6e25d6:	movq   $0xfffffffffffffffe,0x70(%rsp)
  6e25df:	jmp    6e2ea1 <text_column_public_control::main+0x35a1>
  6e25e4:	jne    6e38d8 <text_column_public_control::main+0x3fd8>
  6e25ea:	mov    0x40(%rsp),%rax
  6e25ef:	cmp    $0xffffffff,%eax
  6e25f2:	je     6e3dfd <text_column_public_control::main+0x44fd>
  6e25f8:	dec    %eax
  6e25fa:	movd   %eax,%xmm0
  6e25fe:	lea    0x260(%rsp),%rdi
  6e2606:	mov    %r14,%rsi
  6e2609:	mov    %r12,%rdx
  6e260c:	mov    0x68(%rsp),%rcx
  6e2611:	movd   0x10(%rsp),%xmm1
  6e2617:	mov    $0x1,%r8d
  6e261d:	call   6f11f0 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::select_pointer>
  6e2622:	mov    0x260(%rsp),%rax
  6e262a:	cmp    $0xfffffffffffffffe,%rax
  6e262e:	je     6e263c <text_column_public_control::main+0x2d3c>
  6e2630:	cmp    $0x11,%eax
  6e2633:	mov    $0x0,%eax
  6e2638:	cmove  %rax,%r12
  6e263c:	mov    0x290(%rsp),%rax
  6e2644:	mov    %rax,0xa0(%rsp)
  6e264c:	movups 0x260(%rsp),%xmm0
  6e2654:	movups 0x270(%rsp),%xmm1
  6e265c:	movups 0x280(%rsp),%xmm2
  6e2664:	movaps %xmm2,0x90(%rsp)
  6e266c:	movaps %xmm1,0x80(%rsp)
  6e2674:	movaps %xmm0,0x70(%rsp)
  6e2679:	jmp    6e1ee0 <text_column_public_control::main+0x25e0>
  6e267e:	movq   $0x0,0x60(%rsp)
  6e2687:	mov    0x20(%rsp),%r12
  6e268c:	movaps 0x110(%rsp),%xmm0
  6e2694:	movaps 0x120(%rsp),%xmm1
  6e269c:	movaps 0x130(%rsp),%xmm2
  6e26a4:	lea    0x78(%rsp),%rax
  6e26a9:	movups %xmm2,0x20(%rax)
  6e26ad:	movups %xmm1,0x10(%rax)
  6e26b1:	movups %xmm0,(%rax)
  6e26b4:	movq   $0xfffffffffffffffe,0x70(%rsp)
  6e26bd:	mov    0x50(%rsp),%rax
  6e26c2:	mov    %rax,0x68(%rsp)
  6e26c7:	jmp    6e1ee0 <text_column_public_control::main+0x25e0>
  6e26cc:	movq   $0x4,0x260(%rsp)
  6e26d8:	lea    0x268(%rsp),%rax
  6e26e0:	xorps  %xmm0,%xmm0
  6e26e3:	movups %xmm0,(%rax)
  6e26e6:	add    $0x8,%r15
  6e26ea:	movss  0x20(%rsp),%xmm0
  6e26f0:	cvtss2sd %xmm0,%xmm2
  6e26f4:	mov    0x270(%rsp),%rax
  6e26fc:	mov    %rax,0x1d0(%rsp)
  6e2704:	movups 0x260(%rsp),%xmm0
  6e270c:	movaps %xmm0,0x1c0(%rsp)
  6e2714:	movq   $0x3,0x260(%rsp)
  6e2720:	movq   $0x1,0x268(%rsp)
  6e272c:	mov    %r12,0x270(%rsp)
  6e2734:	movaps 0x50(%rsp),%xmm1
  6e2739:	movups %xmm1,0x278(%rsp)
  6e2741:	mov    %r13,0x148(%rsp)
  6e2749:	mov    %r13,0x290(%rsp)
  6e2751:	mov    %rbp,0x9b8(%rsp)
  6e2759:	mov    %rbp,0x298(%rsp)
  6e2761:	mov    %r14,0x150(%rsp)
  6e2769:	mov    %r14,0x2a0(%rsp)
  6e2771:	lea    0x268(%rsp),%rcx
  6e2779:	mov    %rax,0x50(%rcx)
  6e277d:	movups %xmm0,0x40(%rcx)
  6e2781:	movsd  %xmm2,0x9b0(%rsp)
  6e278a:	movsd  %xmm2,0x2c0(%rsp)
  6e2793:	mov    $0x8,%ebp
  6e2798:	xor    %r14d,%r14d
  6e279b:	movq   $0x0,0x20(%rsp)
  6e27a4:	jmp    6e27df <text_column_public_control::main+0x2edf>
  6e27a6:	mov    0xe8(%rsp),%rbp
  6e27ae:	lea    (%r14,%r14,2),%rax
  6e27b2:	movq   $0x1,0x0(%rbp,%rax,8)
  6e27bb:	movsd  0x158(%rsp),%xmm0
  6e27c4:	movsd  %xmm0,0x8(%rbp,%rax,8)
  6e27ca:	mov    %r13,0x10(%rbp,%rax,8)
  6e27cf:	inc    %r14
  6e27d2:	mov    %r14,0xf0(%rsp)
  6e27da:	incq   0x20(%rsp)
  6e27df:	lea    0xc60(%rsp),%rdi
  6e27e7:	lea    0x260(%rsp),%rsi
  6e27ef:	call   *0x36030b(%rip)        # a42b00 <_DYNAMIC+0x568>
  6e27f5:	mov    0xc78(%rsp),%rax
  6e27fd:	cmp    $0x2,%rax
  6e2801:	je     6e283d <text_column_public_control::main+0x2f3d>
  6e2803:	test   $0x1,%al
  6e2805:	je     6e27da <text_column_public_control::main+0x2eda>
  6e2807:	mov    0xc80(%rsp),%r13
  6e280f:	movsd  0xc68(%rsp),%xmm0
  6e2818:	movsd  %xmm0,0x158(%rsp)
  6e2821:	cmp    0xe0(%rsp),%r14
  6e2829:	jne    6e27ae <text_column_public_control::main+0x2eae>
  6e282b:	lea    0xe0(%rsp),%rdi
  6e2833:	call   6f48d0 <<alloc::raw_vec::RawVec<gpui::style_port::Draft>>::grow_one>
  6e2838:	jmp    6e27a6 <text_column_public_control::main+0x2ea6>
  6e283d:	cmpq   $0x0,0x20(%rsp)
  6e2843:	je     6e2a3e <text_column_public_control::main+0x313e>
  6e2849:	movq   $0x3,0x260(%rsp)
  6e2855:	movq   $0x1,0x268(%rsp)
  6e2861:	mov    %r12,0x270(%rsp)
  6e2869:	movaps 0x50(%rsp),%xmm0
  6e286e:	movups %xmm0,0x278(%rsp)
  6e2876:	mov    0x148(%rsp),%rax
  6e287e:	mov    %rax,0x290(%rsp)
  6e2886:	mov    0x9b8(%rsp),%rax
  6e288e:	mov    %rax,0x298(%rsp)
  6e2896:	mov    0x150(%rsp),%rax
  6e289e:	mov    %rax,0x2a0(%rsp)
  6e28a6:	mov    0x1d0(%rsp),%rax
  6e28ae:	lea    0x268(%rsp),%rcx
  6e28b6:	mov    %rax,0x50(%rcx)
  6e28ba:	movaps 0x1c0(%rsp),%xmm0
  6e28c2:	movups %xmm0,0x40(%rcx)
  6e28c6:	movsd  0x9b0(%rsp),%xmm0
  6e28cf:	movsd  %xmm0,0x2c0(%rsp)
  6e28d8:	lea    0x30(%rsp),%rbp
  6e28dd:	lea    0xc60(%rsp),%rdi
  6e28e5:	lea    0x260(%rsp),%rsi
  6e28ed:	call   *0x36020d(%rip)        # a42b00 <_DYNAMIC+0x568>
  6e28f3:	mov    0xc78(%rsp),%rax
  6e28fb:	cmp    $0x2,%rax
  6e28ff:	je     6e29b4 <text_column_public_control::main+0x30b4>
  6e2905:	cmp    $0x1,%eax
  6e2908:	je     6e28dd <text_column_public_control::main+0x2fdd>
  6e290a:	mov    0x648(%rbx),%rax
  6e2911:	test   %rax,%rax
  6e2914:	je     6e28dd <text_column_public_control::main+0x2fdd>
  6e2916:	movdqa 0xc60(%rsp),%xmm0
  6e291f:	mov    0xc70(%rsp),%rcx
  6e2927:	mov    0x650(%rbx),%rdx
  6e292e:	movzwl 0x58a(%rax),%r8d
  6e2936:	lea    0x48(%rax),%rdi
  6e293a:	mov    %r8d,%r9d
  6e293d:	shl    $0x4,%r9d
  6e2941:	mov    $0xffffffffffffffff,%rsi
  6e2948:	xor    %r10d,%r10d
  6e294b:	jmp    6e296e <text_column_public_control::main+0x306e>
  6e294d:	nopl   (%rax)
  6e2950:	cmp    0x8(%rax,%r10,1),%rcx
  6e2955:	seta   %r11b
  6e2959:	sbb    $0x0,%r11b
  6e295d:	add    $0x70,%rdi
  6e2961:	inc    %rsi
  6e2964:	add    $0x10,%r10
  6e2968:	cmp    $0x1,%r11b
  6e296c:	jne    6e297f <text_column_public_control::main+0x307f>
  6e296e:	cmp    %r10,%r9
  6e2971:	je     6e298a <text_column_public_control::main+0x308a>
  6e2973:	cmpq   $0x0,(%rax,%r10,1)
  6e2978:	jne    6e2950 <text_column_public_control::main+0x3050>
  6e297a:	mov    $0x1,%r11b
  6e297d:	jmp    6e295d <text_column_public_control::main+0x305d>
  6e297f:	movzbl %r11b,%r8d
  6e2983:	test   %r8d,%r8d
  6e2986:	jne    6e298d <text_column_public_control::main+0x308d>
  6e2988:	jmp    6e29a1 <text_column_public_control::main+0x30a1>
  6e298a:	mov    %r8,%rsi
  6e298d:	sub    $0x1,%rdx
  6e2991:	jb     6e28dd <text_column_public_control::main+0x2fdd>
  6e2997:	mov    0x590(%rax,%rsi,8),%rax
  6e299f:	jmp    6e292e <text_column_public_control::main+0x302e>
  6e29a1:	cmpl   $0x2,-0x8(%rdi)
  6e29a5:	jne    6e28dd <text_column_public_control::main+0x2fdd>
  6e29ab:	movdqu %xmm0,(%rdi)
  6e29af:	jmp    6e28dd <text_column_public_control::main+0x2fdd>
  6e29b4:	test   %r14,%r14
  6e29b7:	je     6e2b08 <text_column_public_control::main+0x3208>
  6e29bd:	mov    0xe8(%rsp),%r8
  6e29c5:	movq   $0x0,(%rsp)
  6e29cd:	lea    0xc60(%rsp),%rdi
  6e29d5:	mov    %rbx,%rsi
  6e29d8:	mov    %r15,%rdx
  6e29db:	xor    %ecx,%ecx
  6e29dd:	mov    %r14,%r9
  6e29e0:	call   6e8930 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::describe_with_changed>
  6e29e5:	mov    $0x1,%r14b
  6e29e8:	cmpl   $0xfffffffe,0xc60(%rsp)
  6e29f0:	je     6e2bff <text_column_public_control::main+0x32ff>
  6e29f6:	mov    0xc90(%rsp),%rax
  6e29fe:	mov    %rax,0x290(%rsp)
  6e2a06:	movups 0xc60(%rsp),%xmm0
  6e2a0e:	movups 0xc70(%rsp),%xmm1
  6e2a16:	movups 0xc80(%rsp),%xmm2
  6e2a1e:	movaps %xmm2,0x280(%rsp)
  6e2a26:	movaps %xmm1,0x270(%rsp)
  6e2a2e:	movaps %xmm0,0x260(%rsp)
  6e2a36:	mov    $0x1,%r14b
  6e2a39:	jmp    6e2c22 <text_column_public_control::main+0x3322>
  6e2a3e:	movzbl 0x74c(%rbx),%eax
  6e2a45:	cmpq   $0x0,0x6b0(%rbx)
  6e2a4d:	lea    0x30(%rsp),%rbp
  6e2a52:	je     6e2b4a <text_column_public_control::main+0x324a>
  6e2a58:	test   %al,%al
  6e2a5a:	je     6e2a6a <text_column_public_control::main+0x316a>
  6e2a5c:	cmpq   $0xffffffffffffffff,0x5b8(%rbx)
  6e2a64:	je     6e2b4a <text_column_public_control::main+0x324a>
  6e2a6a:	mov    0x6c0(%rbx),%rdx
  6e2a71:	mov    $0x1,%ecx
  6e2a76:	jmp    6e2b4c <text_column_public_control::main+0x324c>
  6e2a7b:	lea    0x260(%rsp),%rdi
  6e2a83:	mov    %r14,%rsi
  6e2a86:	mov    0x20(%rsp),%rdx
  6e2a8b:	mov    0x50(%rsp),%rcx
  6e2a90:	call   6f0da0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::focus>
  6e2a95:	mov    0x260(%rsp),%rax
  6e2a9d:	cmp    $0xfffffffffffffffe,%rax
  6e2aa1:	je     6e2276 <text_column_public_control::main+0x2976>
  6e2aa7:	mov    0x288(%rsp),%rcx
  6e2aaf:	movzbl 0x290(%rsp),%edx
  6e2ab7:	lea    0x268(%rsp),%rdi
  6e2abf:	mov    0x29(%rdi),%esi
  6e2ac2:	mov    0x2c(%rdi),%edi
  6e2ac5:	lea    0x78(%rsp),%r8
  6e2aca:	mov    %edi,0x2c(%r8)
  6e2ace:	mov    %esi,0x29(%r8)
  6e2ad2:	movups 0x268(%rsp),%xmm0
  6e2ada:	movups 0x278(%rsp),%xmm1
  6e2ae2:	mov    %rax,0x70(%rsp)
  6e2ae7:	movups %xmm0,0x78(%rsp)
  6e2aec:	movups %xmm1,0x88(%rsp)
  6e2af4:	mov    %rcx,0x98(%rsp)
  6e2afc:	mov    %dl,0xa0(%rsp)
  6e2b03:	jmp    6e1ee0 <text_column_public_control::main+0x25e0>
  6e2b08:	mov    0x648(%rbx),%rax
  6e2b0f:	test   %rax,%rax
  6e2b12:	je     6e2bf0 <text_column_public_control::main+0x32f0>
  6e2b18:	mov    0x650(%rbx),%rcx
  6e2b1f:	test   %rcx,%rcx
  6e2b22:	je     6e2bdd <text_column_public_control::main+0x32dd>
  6e2b28:	mov    %rcx,%rdx
  6e2b2b:	and    $0x7,%rdx
  6e2b2f:	je     6e2b96 <text_column_public_control::main+0x3296>
  6e2b31:	xor    %esi,%esi
  6e2b33:	mov    0x590(%rax),%rax
  6e2b3a:	inc    %rsi
  6e2b3d:	cmp    %rsi,%rdx
  6e2b40:	jne    6e2b33 <text_column_public_control::main+0x3233>
  6e2b42:	mov    %rcx,%rdx
  6e2b45:	sub    %rsi,%rdx
  6e2b48:	jmp    6e2b99 <text_column_public_control::main+0x3299>
  6e2b4a:	xor    %ecx,%ecx
  6e2b4c:	movups 0x690(%rbx),%xmm0
  6e2b53:	mov    0x738(%rbx),%rsi
  6e2b5a:	mov    %rcx,0x78(%rsp)
  6e2b5f:	mov    %rdx,0x80(%rsp)
  6e2b67:	movups %xmm0,0x88(%rsp)
  6e2b6f:	mov    %rsi,0x98(%rsp)
  6e2b77:	mov    %al,0xa0(%rsp)
  6e2b7e:	movq   $0xfffffffffffffffe,0x70(%rsp)
  6e2b87:	jmp    6e2e79 <text_column_public_control::main+0x3579>
  6e2b8c:	mov    %rax,0x70(%rsp)
  6e2b91:	jmp    6e1ee0 <text_column_public_control::main+0x25e0>
  6e2b96:	mov    %rcx,%rdx
  6e2b99:	cmp    $0x8,%rcx
  6e2b9d:	jb     6e2bdd <text_column_public_control::main+0x32dd>
  6e2b9f:	mov    0x590(%rax),%rax
  6e2ba6:	mov    0x590(%rax),%rax
  6e2bad:	mov    0x590(%rax),%rax
  6e2bb4:	mov    0x590(%rax),%rax
  6e2bbb:	mov    0x590(%rax),%rax
  6e2bc2:	mov    0x590(%rax),%rax
  6e2bc9:	mov    0x590(%rax),%rax
  6e2bd0:	mov    0x590(%rax),%rax
  6e2bd7:	add    $0xfffffffffffffff8,%rdx
  6e2bdb:	jne    6e2b9f <text_column_public_control::main+0x329f>
  6e2bdd:	cmpw   $0x0,0x58a(%rax)
  6e2be5:	je     6e2bf0 <text_column_public_control::main+0x32f0>
  6e2be7:	cmpl   $0x1,(%rax)
  6e2bea:	jne    6e29bd <text_column_public_control::main+0x30bd>
  6e2bf0:	movq   $0xfffffffffffffffe,0xc60(%rsp)
  6e2bfc:	xor    %r14d,%r14d
  6e2bff:	movb   $0x1,0x74b(%rbx)
  6e2c06:	mov    0x20(%rsp),%rax
  6e2c0b:	mov    %rax,0x738(%rbx)
  6e2c12:	lea    0x260(%rsp),%rdi
  6e2c1a:	mov    %rbx,%rsi
  6e2c1d:	call   70d460 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present>
  6e2c22:	cmpq   $0xfffffffffffffffe,0x260(%rsp)
  6e2c2b:	je     6e2e3c <text_column_public_control::main+0x353c>
  6e2c31:	cmpq   $0x0,0x640(%rbx)
  6e2c39:	je     6e2e30 <text_column_public_control::main+0x3530>
  6e2c3f:	mov    0x648(%rbx),%rax
  6e2c46:	test   %rax,%rax
  6e2c49:	je     6e2e30 <text_column_public_control::main+0x3530>
  6e2c4f:	mov    0x658(%rbx),%r15
  6e2c56:	test   %r15,%r15
  6e2c59:	je     6e2e30 <text_column_public_control::main+0x3530>
  6e2c5f:	mov    0x650(%rbx),%r13
  6e2c66:	xor    %r12d,%r12d
  6e2c69:	jmp    6e2c7e <text_column_public_control::main+0x337e>
  6e2c6b:	mov    $0x0,%eax
  6e2c70:	dec    %r15
  6e2c73:	lea    0x30(%rsp),%rbp
  6e2c78:	je     6e2e30 <text_column_public_control::main+0x3530>
  6e2c7e:	test   %r12,%r12
  6e2c81:	jne    6e2d00 <text_column_public_control::main+0x3400>
  6e2c83:	test   %r13,%r13
  6e2c86:	je     6e2cae <text_column_public_control::main+0x33ae>
  6e2c88:	mov    %r13,%rcx
  6e2c8b:	mov    %rax,%r12
  6e2c8e:	and    $0x7,%rcx
  6e2c92:	je     6e2cb3 <text_column_public_control::main+0x33b3>
  6e2c94:	xor    %edx,%edx
  6e2c96:	mov    0x590(%r12),%r12
  6e2c9e:	inc    %rdx
  6e2ca1:	cmp    %rdx,%rcx
  6e2ca4:	jne    6e2c96 <text_column_public_control::main+0x3396>
  6e2ca6:	mov    %r13,%rax
  6e2ca9:	sub    %rdx,%rax
  6e2cac:	jmp    6e2cb6 <text_column_public_control::main+0x33b6>
  6e2cae:	mov    %rax,%r12
  6e2cb1:	jmp    6e2cfb <text_column_public_control::main+0x33fb>
  6e2cb3:	mov    %r13,%rax
  6e2cb6:	cmp    $0x8,%r13
  6e2cba:	jb     6e2cfb <text_column_public_control::main+0x33fb>
  6e2cbc:	mov    0x590(%r12),%rcx
  6e2cc4:	mov    0x590(%rcx),%rcx
  6e2ccb:	mov    0x590(%rcx),%rcx
  6e2cd2:	mov    0x590(%rcx),%rcx
  6e2cd9:	mov    0x590(%rcx),%rcx
  6e2ce0:	mov    0x590(%rcx),%rcx
  6e2ce7:	mov    0x590(%rcx),%rcx
  6e2cee:	mov    0x590(%rcx),%r12
  6e2cf5:	add    $0xfffffffffffffff8,%rax
  6e2cf9:	jne    6e2cbc <text_column_public_control::main+0x33bc>
  6e2cfb:	xor    %r13d,%r13d
  6e2cfe:	xor    %eax,%eax
  6e2d00:	movzwl 0x58a(%r12),%ecx
  6e2d09:	cmp    %rcx,%r13
  6e2d0c:	jae    6e2d16 <text_column_public_control::main+0x3416>
  6e2d0e:	mov    %r13,%rdx
  6e2d11:	mov    %r12,%rcx
  6e2d14:	jmp    6e2d3f <text_column_public_control::main+0x343f>
  6e2d16:	mov    0x580(%r12),%rcx
  6e2d1e:	test   %rcx,%rcx
  6e2d21:	je     6e3dab <text_column_public_control::main+0x44ab>
  6e2d27:	inc    %rax
  6e2d2a:	movzwl 0x588(%r12),%edx
  6e2d33:	mov    %rcx,%r12
  6e2d36:	cmp    0x58a(%rcx),%dx
  6e2d3d:	jae    6e2d16 <text_column_public_control::main+0x3416>
  6e2d3f:	test   %rax,%rax
  6e2d42:	je     6e2d76 <text_column_public_control::main+0x3476>
  6e2d44:	lea    (%rcx,%rdx,8),%rsi
  6e2d48:	add    $0x598,%rsi
  6e2d4f:	mov    %rax,%rdi
  6e2d52:	and    $0x7,%rdi
  6e2d56:	je     6e2d7f <text_column_public_control::main+0x347f>
  6e2d58:	xor    %r8d,%r8d
  6e2d5b:	mov    (%rsi),%r12
  6e2d5e:	lea    0x590(%r12),%rsi
  6e2d66:	inc    %r8
  6e2d69:	cmp    %r8,%rdi
  6e2d6c:	jne    6e2d5b <text_column_public_control::main+0x345b>
  6e2d6e:	mov    %rax,%rdi
  6e2d71:	sub    %r8,%rdi
  6e2d74:	jmp    6e2d82 <text_column_public_control::main+0x3482>
  6e2d76:	lea    0x1(%rdx),%r13
  6e2d7a:	mov    %rcx,%r12
  6e2d7d:	jmp    6e2dcd <text_column_public_control::main+0x34cd>
  6e2d7f:	mov    %rax,%rdi
  6e2d82:	cmp    $0x8,%rax
  6e2d86:	jb     6e2dca <text_column_public_control::main+0x34ca>
  6e2d88:	mov    (%rsi),%rax
  6e2d8b:	mov    0x590(%rax),%rax
  6e2d92:	mov    0x590(%rax),%rax
  6e2d99:	mov    0x590(%rax),%rax
  6e2da0:	mov    0x590(%rax),%rax
  6e2da7:	mov    0x590(%rax),%rax
  6e2dae:	mov    0x590(%rax),%rax
  6e2db5:	mov    0x590(%rax),%r12
  6e2dbc:	lea    0x590(%r12),%rsi
  6e2dc4:	add    $0xfffffffffffffff8,%rdi
  6e2dc8:	jne    6e2d88 <text_column_public_control::main+0x3488>
  6e2dca:	xor    %r13d,%r13d
  6e2dcd:	mov    %rdx,%rax
  6e2dd0:	shl    $0x4,%rax
  6e2dd4:	cmpl   $0x1,(%rcx,%rax,1)
  6e2dd8:	jne    6e2c6b <text_column_public_control::main+0x336b>
  6e2dde:	imul   $0x70,%rdx,%rdx
  6e2de2:	lea    (%rcx,%rdx,1),%rbp
  6e2de6:	add    $0xb0,%rbp
  6e2ded:	cmpl   $0x2,0x0(%rbp)
  6e2df1:	jne    6e2c6b <text_column_public_control::main+0x336b>
  6e2df7:	mov    0x8(%rcx,%rax,1),%rdx
  6e2dfc:	mov    0x640(%rbx),%rsi
  6e2e03:	lea    0xf8(%rsp),%rdi
  6e2e0b:	call   *0x35fcf7(%rip)        # a42b08 <_DYNAMIC+0x570>
  6e2e11:	cmpl   $0x1,0xf8(%rsp)
  6e2e19:	jne    6e2c6b <text_column_public_control::main+0x336b>
  6e2e1f:	movups 0x100(%rsp),%xmm0
  6e2e27:	movups %xmm0,0x8(%rbp)
  6e2e2b:	jmp    6e2c6b <text_column_public_control::main+0x336b>
  6e2e30:	test   %r14b,%r14b
  6e2e33:	jne    6e2e3c <text_column_public_control::main+0x353c>
  6e2e35:	movb   $0x0,0x74b(%rbx)
  6e2e3c:	mov    0x290(%rsp),%rax
  6e2e44:	mov    %rax,0xa0(%rsp)
  6e2e4c:	movaps 0x260(%rsp),%xmm0
  6e2e54:	movaps 0x270(%rsp),%xmm1
  6e2e5c:	movaps 0x280(%rsp),%xmm2
  6e2e64:	movaps %xmm2,0x90(%rsp)
  6e2e6c:	movaps %xmm1,0x80(%rsp)
  6e2e74:	movaps %xmm0,0x70(%rsp)
  6e2e79:	mov    0xe0(%rsp),%rax
  6e2e81:	test   %rax,%rax
  6e2e84:	je     6e2ea1 <text_column_public_control::main+0x35a1>
  6e2e86:	mov    0xe8(%rsp),%rdi
  6e2e8e:	shl    $0x3,%rax
  6e2e92:	lea    (%rax,%rax,2),%rsi
  6e2e96:	mov    $0x8,%edx
  6e2e9b:	call   *0x35f95f(%rip)        # a42800 <_DYNAMIC+0x268>
  6e2ea1:	xor    %r12d,%r12d
  6e2ea4:	jmp    6e1ee0 <text_column_public_control::main+0x25e0>
  6e2ea9:	mov    0x30(%rsp),%rsi
  6e2eae:	lea    0x260(%rsp),%rbx
  6e2eb6:	mov    %rbx,%rdi
  6e2eb9:	call   6dd300 <text_column_public_control::public_query>
  6e2ebe:	mov    0x260(%rsp),%r12
  6e2ec6:	lea    0x33fd1b(%rip),%rcx        # a22be8 <__frame_dummy_init_array_entry+0xbf8>
  6e2ecd:	cmp    0x230(%rsp),%r12
  6e2ed5:	jne    6e346b <text_column_public_control::main+0x3b6b>
  6e2edb:	mov    0x268(%rsp),%r13
  6e2ee3:	cmp    0x238(%rsp),%r13
  6e2eeb:	jne    6e346b <text_column_public_control::main+0x3b6b>
  6e2ef1:	mov    %rbp,%rax
  6e2ef4:	mov    0x270(%rsp),%rbp
  6e2efc:	cmp    0x240(%rsp),%rbp
  6e2f04:	jne    6e346b <text_column_public_control::main+0x3b6b>
  6e2f0a:	mov    0x30(%rsp),%rsi
  6e2f0f:	test   %rsi,%rsi
  6e2f12:	je     6e3663 <text_column_public_control::main+0x3d63>
  6e2f18:	cmpq   $0x1,0x2b0(%rsi)
  6e2f20:	jne    6e36a8 <text_column_public_control::main+0x3da8>
  6e2f26:	mov    %rax,0x260(%rsp)
  6e2f2e:	lea    0x260(%rsp),%rax
  6e2f36:	mov    0x260(%rsp),%rsi
  6e2f3e:	movl   $0x3e000000,0x260(%rsp)
  6e2f49:	movss  0x260(%rsp),%xmm0
  6e2f52:	lea    0x260(%rsp),%rdi
  6e2f5a:	call   6dd980 <text_column_public_control::public_prepare>
  6e2f5f:	mov    0x30(%rsp),%rax
  6e2f64:	test   %rax,%rax
  6e2f67:	je     6e3d32 <text_column_public_control::main+0x4432>
  6e2f6d:	cmpb   $0x0,0x74e(%rax)
  6e2f74:	jne    6e3d39 <text_column_public_control::main+0x4439>
  6e2f7a:	mov    0x6b0(%rax),%r14
  6e2f81:	test   %r14,%r14
  6e2f84:	je     6e3d40 <text_column_public_control::main+0x4440>
  6e2f8a:	mov    0x6b8(%rax),%r15
  6e2f91:	movl   $0x3e800000,0x260(%rsp)
  6e2f9c:	lea    0x260(%rsp),%rax
  6e2fa4:	movd   0x260(%rsp),%xmm0
  6e2fad:	lea    0x260(%rsp),%rdi
  6e2fb5:	lea    0x30(%rsp),%rsi
  6e2fba:	call   6dd980 <text_column_public_control::public_prepare>
  6e2fbf:	mov    0x30(%rsp),%rsi
  6e2fc4:	lea    0x260(%rsp),%rbx
  6e2fcc:	mov    %rbx,%rdi
  6e2fcf:	call   6dd300 <text_column_public_control::public_query>
  6e2fd4:	cmp    %r13,0x268(%rsp)
  6e2fdc:	sete   %al
  6e2fdf:	cmp    %r12,0x260(%rsp)
  6e2fe7:	jne    6e3445 <text_column_public_control::main+0x3b45>
  6e2fed:	cmp    %rbp,0x270(%rsp)
  6e2ff5:	sete   %cl
  6e2ff8:	test   %al,%al
  6e2ffa:	je     6e345a <text_column_public_control::main+0x3b5a>
  6e3000:	test   %cl,%cl
  6e3002:	je     6e3464 <text_column_public_control::main+0x3b64>
  6e3008:	mov    0x30(%rsp),%rsi
  6e300d:	test   %rsi,%rsi
  6e3010:	je     6e302e <text_column_public_control::main+0x372e>
  6e3012:	cmpb   $0x0,0x74e(%rsi)
  6e3019:	je     6e304d <text_column_public_control::main+0x374d>
  6e301b:	movq   $0xe,0x260(%rsp)
  6e3027:	mov    $0xe,%ebx
  6e302c:	jmp    6e3072 <text_column_public_control::main+0x3772>
  6e302e:	movq   $0xd,0x260(%rsp)
  6e303a:	movq   $0x0,0x268(%rsp)
  6e3046:	mov    $0xd,%ebx
  6e304b:	jmp    6e3072 <text_column_public_control::main+0x3772>
  6e304d:	lea    0x260(%rsp),%rdi
  6e3055:	mov    %r14,%rdx
  6e3058:	mov    %r15,%rcx
  6e305b:	call   6fe1d0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge>
  6e3060:	mov    0x260(%rsp),%rbx
  6e3068:	cmp    $0xfffffffffffffffe,%rbx
  6e306c:	je     6e36fe <text_column_public_control::main+0x3dfe>
  6e3072:	lea    -0x695ac1(%rip),%rsi        # 4d5b8 <GCC_except_table0+0xd770>
  6e3079:	lea    0x260(%rsp),%rdi
  6e3081:	call   727d30 <<gpui::runtime::Error as core::cmp::PartialEq>::eq>
  6e3086:	test   %al,%al
  6e3088:	je     6e36fe <text_column_public_control::main+0x3dfe>
  6e308e:	sub    $0xd,%rbx
  6e3092:	mov    $0x14,%eax
  6e3097:	cmovge %rbx,%rax
  6e309b:	cmp    $0x14,%rax
  6e309f:	je     6e3208 <text_column_public_control::main+0x3908>
  6e30a5:	cmp    $0x19,%rax
  6e30a9:	jne    6e30ce <text_column_public_control::main+0x37ce>
  6e30ab:	mov    0x268(%rsp),%rsi
  6e30b3:	lea    0x270(%rsp),%rax
  6e30bb:	test   %rsi,%rsi
  6e30be:	je     6e30ce <text_column_public_control::main+0x37ce>
  6e30c0:	mov    (%rax),%rdi
  6e30c3:	mov    $0x1,%edx
  6e30c8:	call   *0x35f732(%rip)        # a42800 <_DYNAMIC+0x268>
  6e30ce:	mov    0x30(%rsp),%rsi
  6e30d3:	lea    0x9c0(%rsp),%rdi
  6e30db:	call   6b5ea0 <text_column_public_control::ack::<text_column_public_control::Input>>
  6e30e0:	mov    0x30(%rsp),%rsi
  6e30e5:	lea    0xc60(%rsp),%rbx
  6e30ed:	mov    %rbx,%rdi
  6e30f0:	call   6dd300 <text_column_public_control::public_query>
  6e30f5:	xor    0xc60(%rsp),%r12
  6e30fd:	xor    0xc68(%rsp),%r13
  6e3105:	cmp    %rbp,0xc70(%rsp)
  6e310d:	sete   %al
  6e3110:	or     %r12,%r13
  6e3113:	je     6e3117 <text_column_public_control::main+0x3817>
  6e3115:	xor    %eax,%eax
  6e3117:	test   %al,%al
  6e3119:	jne    6e346f <text_column_public_control::main+0x3b6f>
  6e311f:	lea    0xc68(%rsp),%rax
  6e3127:	lea    0x9d8(%rsp),%rcx
  6e312f:	lea    0xc60(%rsp),%rdx
  6e3137:	mov    %rdx,0x260(%rsp)
  6e313f:	mov    0x35f90a(%rip),%rdx        # a42a50 <_DYNAMIC+0x4b8>
  6e3146:	mov    %rdx,0x268(%rsp)
  6e314e:	mov    %rax,0x270(%rsp)
  6e3156:	mov    %rdx,0x278(%rsp)
  6e315e:	lea    0xc70(%rsp),%rax
  6e3166:	mov    %rax,0x280(%rsp)
  6e316e:	mov    0x35f8e3(%rip),%rax        # a42a58 <_DYNAMIC+0x4c0>
  6e3175:	mov    %rax,0x288(%rsp)
  6e317d:	lea    0x9d0(%rsp),%rsi
  6e3185:	mov    %rsi,0x290(%rsp)
  6e318d:	mov    %rax,0x298(%rsp)
  6e3195:	mov    %rcx,0x2a0(%rsp)
  6e319d:	mov    %rax,0x2a8(%rsp)
  6e31a5:	lea    -0x6a1914(%rip),%rax        # 41898 <GCC_except_table0+0x1a50>
  6e31ac:	mov    %rax,0x2b0(%rsp)
  6e31b4:	mov    %rdx,0x2b8(%rsp)
  6e31bc:	lea    -0x6a1a9b(%rip),%rax        # 41728 <GCC_except_table0+0x18e0>
  6e31c3:	mov    %rax,0x2c0(%rsp)
  6e31cb:	mov    %rdx,0x2c8(%rsp)
  6e31d3:	lea    -0x696223(%rip),%rdi        # 4cfb7 <GCC_except_table0+0xd16f>
  6e31da:	lea    0x260(%rsp),%rsi
  6e31e2:	call   *0x35f880(%rip)        # a42a68 <_DYNAMIC+0x4d0>
  6e31e8:	mov    0x30(%rsp),%r14
  6e31ed:	test   %r14,%r14
  6e31f0:	je     6e4a7c <text_column_public_control::main+0x517c>
  6e31f6:	mov    %r14,%rdi
  6e31f9:	call   6bfd30 <core::ptr::drop_glue::<gpui::runtime::Runtime<text_column_public_control::Input>>>
  6e31fe:	mov    $0x750,%esi
  6e3203:	jmp    6e4a6e <text_column_public_control::main+0x516e>
  6e3208:	mov    0x278(%rsp),%rsi
  6e3210:	test   %rsi,%rsi
  6e3213:	lea    0x280(%rsp),%rax
  6e321b:	jne    6e30c0 <text_column_public_control::main+0x37c0>
  6e3221:	jmp    6e30ce <text_column_public_control::main+0x37ce>
  6e3226:	jne    6e3717 <text_column_public_control::main+0x3e17>
  6e322c:	lea    0x9c0(%rsp),%rdi
  6e3234:	mov    %r12,%rsi
  6e3237:	mov    %r14,%rdx
  6e323a:	mov    %rbx,%rcx
  6e323d:	movaps 0x40(%rsp),%xmm1
  6e3242:	xor    %r8d,%r8d
  6e3245:	call   6f11f0 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::select_pointer>
  6e324a:	jmp    6e14ca <text_column_public_control::main+0x1bca>
  6e324f:	mov    $0x16,%eax
  6e3254:	jmp    6e132d <text_column_public_control::main+0x1a2d>
  6e3259:	mov    0x260(%rsp),%rcx
  6e3261:	test   %rbp,%rbp
  6e3264:	je     6e327f <text_column_public_control::main+0x397f>
  6e3266:	mov    0x5e0(%r12),%rax
  6e326e:	xor    %rbp,%rax
  6e3271:	mov    %r15,%rdx
  6e3274:	xor    %rcx,%rdx
  6e3277:	or     %rax,%rdx
  6e327a:	sete   %al
  6e327d:	jmp    6e3281 <text_column_public_control::main+0x3981>
  6e327f:	xor    %eax,%eax
  6e3281:	mov    0x268(%rsp),%edx
  6e3288:	mov    0x270(%rsp),%esi
  6e328f:	mov    0x618(%r12),%rdi
  6e3297:	test   %rdi,%rdi
  6e329a:	je     6e32b4 <text_column_public_control::main+0x39b4>
  6e329c:	xor    0x5e0(%r12),%rdi
  6e32a4:	xor    0x620(%r12),%rcx
  6e32ac:	or     %rdi,%rcx
  6e32af:	sete   %cl
  6e32b2:	jmp    6e32b6 <text_column_public_control::main+0x39b6>
  6e32b4:	xor    %ecx,%ecx
  6e32b6:	cmp    %esi,%edx
  6e32b8:	jne    6e140f <text_column_public_control::main+0x1b0f>
  6e32be:	xor    %cl,%al
  6e32c0:	je     6e140f <text_column_public_control::main+0x1b0f>
  6e32c6:	movq   $0x2,0x260(%rsp)
  6e32d2:	lea    0x9c0(%rsp),%rdi
  6e32da:	lea    0x70(%rsp),%rsi
  6e32df:	lea    0x260(%rsp),%r8
  6e32e7:	mov    %r14,%rdx
  6e32ea:	mov    %rbx,%rcx
  6e32ed:	call   6e8500 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::activate_with_editing>
  6e32f2:	cmpl   $0xfffffffe,0x9c0(%rsp)
  6e32fa:	jne    6e333c <text_column_public_control::main+0x3a3c>
  6e32fc:	mov    0x6b0(%r12),%rax
  6e3304:	test   %rax,%rax
  6e3307:	je     6e33da <text_column_public_control::main+0x3ada>
  6e330d:	cmpq   $0x0,0x10(%rsp)
  6e3313:	je     6e14ca <text_column_public_control::main+0x1bca>
  6e3319:	cmp    0x10(%rsp),%rax
  6e331e:	jne    6e14ca <text_column_public_control::main+0x1bca>
  6e3324:	mov    0x40(%rsp),%rax
  6e3329:	cmp    %rax,0x6b8(%r12)
  6e3331:	je     6e33e6 <text_column_public_control::main+0x3ae6>
  6e3337:	jmp    6e14ca <text_column_public_control::main+0x1bca>
  6e333c:	cmp    %r13,0x690(%r12)
  6e3344:	jne    6e14ca <text_column_public_control::main+0x1bca>
  6e334a:	cmpb   $0x1,0x74a(%r12)
  6e3353:	jne    6e14ca <text_column_public_control::main+0x1bca>
  6e3359:	cmpb   $0x0,0x74e(%r12)
  6e3362:	jne    6e14ca <text_column_public_control::main+0x1bca>
  6e3368:	mov    %rbp,0x618(%r12)
  6e3370:	mov    %r15,0x620(%r12)
  6e3378:	jmp    6e14ca <text_column_public_control::main+0x1bca>
  6e337d:	lea    0x1f0(%rsp),%rsi
  6e3385:	lea    0x1a0(%rsp),%rdx
  6e338d:	lea    0x33f8fc(%rip),%r9        # a22c90 <__frame_dummy_init_array_entry+0xca0>
  6e3394:	jmp    6e33ad <text_column_public_control::main+0x3aad>
  6e3396:	lea    0x1f8(%rsp),%rsi
  6e339e:	lea    0x1a8(%rsp),%rdx
  6e33a6:	lea    0x33f8fb(%rip),%r9        # a22ca8 <__frame_dummy_init_array_entry+0xcb8>
  6e33ad:	xor    %edi,%edi
  6e33af:	xor    %ecx,%ecx
  6e33b1:	call   *0x35f759(%rip)        # a42b10 <_DYNAMIC+0x578>
  6e33b7:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e33bc:	lea    -0x695dd3(%rip),%rdi        # 4d5f0 <GCC_except_table0+0xd7a8>
  6e33c3:	lea    0x33f8f6(%rip),%rdx        # a22cc0 <__frame_dummy_init_array_entry+0xcd0>
  6e33ca:	mov    $0x2c,%esi
  6e33cf:	call   *0x35f483(%rip)        # a42858 <_DYNAMIC+0x2c0>
  6e33d5:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e33da:	cmpq   $0x0,0x10(%rsp)
  6e33e0:	jne    6e14ca <text_column_public_control::main+0x1bca>
  6e33e6:	lea    0x9c0(%rsp),%rdi
  6e33ee:	mov    %r12,%rsi
  6e33f1:	mov    %rbp,%rdx
  6e33f4:	mov    %r15,%rcx
  6e33f7:	call   6f1810 <<gpui::runtime::RuntimeMut<text_column_public_control::Input, ()>>::publish_focus_change>
  6e33fc:	jmp    6e14ca <text_column_public_control::main+0x1bca>
  6e3401:	lea    0x33fc40(%rip),%rcx        # a23048 <__frame_dummy_init_array_entry+0x1058>
  6e3408:	lea    0x260(%rsp),%rsi
  6e3410:	lea    0x1c0(%rsp),%rdx
  6e3418:	xor    %edi,%edi
  6e341a:	call   6c88cd <core::panicking::assert_failed::<(usize, usize, u64), (usize, usize, u64)>>
  6e341f:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3424:	xor    %eax,%eax
  6e3426:	test   %al,%al
  6e3428:	jne    6e0694 <text_column_public_control::main+0xd94>
  6e342e:	lea    0x70(%rsp),%rdi
  6e3433:	lea    0x260(%rsp),%rsi
  6e343b:	call   6c87ec <core::panicking::assert_failed::<core::option::Option<u64>, core::option::Option<u64>>>
  6e3440:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3445:	xor    %eax,%eax
  6e3447:	cmp    %rbp,0x270(%rsp)
  6e344f:	sete   %cl
  6e3452:	test   %al,%al
  6e3454:	jne    6e3000 <text_column_public_control::main+0x3700>
  6e345a:	xor    %ecx,%ecx
  6e345c:	test   %cl,%cl
  6e345e:	jne    6e3008 <text_column_public_control::main+0x3708>
  6e3464:	lea    0x33f7c5(%rip),%rcx        # a22c30 <__frame_dummy_init_array_entry+0xc40>
  6e346b:	xor    %eax,%eax
  6e346d:	jmp    6e3478 <text_column_public_control::main+0x3b78>
  6e346f:	lea    0x33f7ea(%rip),%rcx        # a22c60 <__frame_dummy_init_array_entry+0xc70>
  6e3476:	mov    $0x1,%al
  6e3478:	movzbl %al,%edi
  6e347b:	lea    0x230(%rsp),%rdx
  6e3483:	mov    %rbx,%rsi
  6e3486:	call   6c88cd <core::panicking::assert_failed::<(usize, usize, u64), (usize, usize, u64)>>
  6e348b:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3490:	mov    $0x8,%edi
  6e3495:	mov    $0x28,%esi
  6e349a:	call   *0x35f378(%rip)        # a42818 <_DYNAMIC+0x280>
  6e34a0:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e34a5:	mov    $0x8,%edi
  6e34aa:	mov    $0x750,%esi
  6e34af:	call   *0x35f363(%rip)        # a42818 <_DYNAMIC+0x280>
  6e34b5:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e34ba:	lea    -0x6932f4(%rip),%rdi        # 501cd <GCC_except_table0+0x10385>
  6e34c1:	lea    0x3401c8(%rip),%rdx        # a23690 <__frame_dummy_init_array_entry+0x16a0>
  6e34c8:	mov    $0x22,%esi
  6e34cd:	call   *0x35f4cd(%rip)        # a429a0 <_DYNAMIC+0x408>
  6e34d3:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e34d8:	lea    0x120(%rsp),%rsi
  6e34e0:	lea    0x33fb01(%rip),%r9        # a22fe8 <__frame_dummy_init_array_entry+0xff8>
  6e34e7:	xor    %edi,%edi
  6e34e9:	mov    %r14,%rdx
  6e34ec:	xor    %ecx,%ecx
  6e34ee:	call   *0x35f61c(%rip)        # a42b10 <_DYNAMIC+0x578>
  6e34f4:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e34f9:	lea    0x33fa10(%rip),%r9        # a22f10 <__frame_dummy_init_array_entry+0xf20>
  6e3500:	mov    %rbx,%r12
  6e3503:	jmp    6e36ec <text_column_public_control::main+0x3dec>
  6e3508:	lea    -0x695e04(%rip),%rdi        # 4d70b <GCC_except_table0+0xd8c3>
  6e350f:	lea    0x33faea(%rip),%rdx        # a23000 <__frame_dummy_init_array_entry+0x1010>
  6e3516:	mov    $0x2d,%esi
  6e351b:	call   *0x35f337(%rip)        # a42858 <_DYNAMIC+0x2c0>
  6e3521:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3526:	lea    0x33f9fb(%rip),%r9        # a22f28 <__frame_dummy_init_array_entry+0xf38>
  6e352d:	mov    %rbx,%rdx
  6e3530:	jmp    6e36ec <text_column_public_control::main+0x3dec>
  6e3535:	lea    0x33fa04(%rip),%rdx        # a22f40 <__frame_dummy_init_array_entry+0xf50>
  6e353c:	mov    $0x37,%esi
  6e3541:	lea    -0x695ec9(%rip),%rdi        # 4d67f <GCC_except_table0+0xd837>
  6e3548:	jmp    6e355d <text_column_public_control::main+0x3c5d>
  6e354a:	lea    0x33fa07(%rip),%rdx        # a22f58 <__frame_dummy_init_array_entry+0xf68>
  6e3551:	mov    $0x31,%esi
  6e3556:	lea    -0x695ea7(%rip),%rdi        # 4d6b6 <GCC_except_table0+0xd86e>
  6e355d:	call   *0x35f2f5(%rip)        # a42858 <_DYNAMIC+0x2c0>
  6e3563:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3568:	lea    0x80(%rsp),%rsi
  6e3570:	lea    0x33fae9(%rip),%r9        # a23060 <__frame_dummy_init_array_entry+0x1070>
  6e3577:	jmp    6e3613 <text_column_public_control::main+0x3d13>
  6e357c:	lea    0x9d0(%rsp),%r12
  6e3584:	lea    0x33f9fd(%rip),%r9        # a22f88 <__frame_dummy_init_array_entry+0xf98>
  6e358b:	jmp    6e36ec <text_column_public_control::main+0x3dec>
  6e3590:	movq   $0xd,0x260(%rsp)
  6e359c:	movq   $0x0,0x268(%rsp)
  6e35a8:	lea    -0x695dd8(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6e35af:	lea    0x33fc72(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6e35b6:	lea    0x33f5fb(%rip),%r8        # a22bb8 <__frame_dummy_init_array_entry+0xbc8>
  6e35bd:	lea    0x260(%rsp),%rdx
  6e35c5:	mov    $0x2b,%esi
  6e35ca:	call   *0x35f208(%rip)        # a427d8 <_DYNAMIC+0x240>
  6e35d0:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e35d5:	lea    0x88(%rsp),%rsi
  6e35dd:	lea    0x33fa94(%rip),%r9        # a23078 <__frame_dummy_init_array_entry+0x1088>
  6e35e4:	mov    %r14,%rbx
  6e35e7:	jmp    6e3613 <text_column_public_control::main+0x3d13>
  6e35e9:	add    $0x2b0,%rsi
  6e35f0:	lea    0x33f6f9(%rip),%r9        # a22cf0 <__frame_dummy_init_array_entry+0xd00>
  6e35f7:	jmp    6e36b6 <text_column_public_control::main+0x3db6>
  6e35fc:	lea    0xc70(%rsp),%rsi
  6e3604:	lea    0xc78(%rsp),%rbx
  6e360c:	lea    0x33fa95(%rip),%r9        # a230a8 <__frame_dummy_init_array_entry+0x10b8>
  6e3613:	xor    %edi,%edi
  6e3615:	mov    %rbx,%rdx
  6e3618:	xor    %ecx,%ecx
  6e361a:	call   *0x35f4f0(%rip)        # a42b10 <_DYNAMIC+0x578>
  6e3620:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3625:	lea    -0x695eee(%rip),%rdi        # 4d73e <GCC_except_table0+0xd8f6>
  6e362c:	lea    0x33fa8d(%rip),%rdx        # a230c0 <__frame_dummy_init_array_entry+0x10d0>
  6e3633:	mov    $0x2d,%esi
  6e3638:	call   *0x35f21a(%rip)        # a42858 <_DYNAMIC+0x2c0>
  6e363e:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3643:	lea    0x33f68e(%rip),%rdx        # a22cd8 <__frame_dummy_init_array_entry+0xce8>
  6e364a:	lea    -0x6a24e1(%rip),%r12        # 41170 <GCC_except_table0+0x1328>
  6e3651:	mov    0x20(%rsp),%rdi
  6e3656:	mov    %r12,%rsi
  6e3659:	call   6c87bb <core::panicking::assert_failed::<core::option::Option<gpui::identity::Target>, core::option::Option<gpui::identity::Target>>>
  6e365e:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3663:	movq   $0xd,0x260(%rsp)
  6e366f:	movq   $0x0,0x268(%rsp)
  6e367b:	lea    -0x695eab(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6e3682:	lea    0x33fb9f(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6e3689:	lea    0x33f570(%rip),%r8        # a22c00 <__frame_dummy_init_array_entry+0xc10>
  6e3690:	lea    0x260(%rsp),%rdx
  6e3698:	mov    $0x2b,%esi
  6e369d:	call   *0x35f135(%rip)        # a427d8 <_DYNAMIC+0x240>
  6e36a3:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e36a8:	add    $0x2b0,%rsi
  6e36af:	lea    0x33f5c2(%rip),%r9        # a22c78 <__frame_dummy_init_array_entry+0xc88>
  6e36b6:	lea    -0x6a1e4d(%rip),%rdx        # 41870 <GCC_except_table0+0x1a28>
  6e36bd:	xor    %edi,%edi
  6e36bf:	xor    %ecx,%ecx
  6e36c1:	call   *0x35f3a9(%rip)        # a42a70 <_DYNAMIC+0x4d8>
  6e36c7:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e36cc:	lea    0x9c8(%rsp),%r12
  6e36d4:	lea    0x33f8dd(%rip),%r9        # a22fb8 <__frame_dummy_init_array_entry+0xfc8>
  6e36db:	jmp    6e36ec <text_column_public_control::main+0x3dec>
  6e36dd:	lea    0x33f8bc(%rip),%r9        # a22fa0 <__frame_dummy_init_array_entry+0xfb0>
  6e36e4:	lea    0x9c0(%rsp),%r12
  6e36ec:	xor    %edi,%edi
  6e36ee:	mov    %r12,%rsi
  6e36f1:	xor    %ecx,%ecx
  6e36f3:	call   *0x35f417(%rip)        # a42b10 <_DYNAMIC+0x578>
  6e36f9:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e36fe:	lea    0x33f543(%rip),%rsi        # a22c48 <__frame_dummy_init_array_entry+0xc58>
  6e3705:	lea    0x260(%rsp),%rdi
  6e370d:	call   6c8824 <core::panicking::assert_failed::<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>, core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>>
  6e3712:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3717:	lea    -0x6933a0(%rip),%rdi        # 5037e <GCC_except_table0+0x10536>
  6e371e:	lea    0x3403e3(%rip),%rdx        # a23b08 <__frame_dummy_init_array_entry+0x1b18>
  6e3725:	mov    $0x83,%esi
  6e372a:	call   *0x35f108(%rip)        # a42838 <_DYNAMIC+0x2a0>
  6e3730:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3735:	movq   $0x19,0x70(%rsp)
  6e373e:	mov    0xa0(%rsp),%rax
  6e3746:	mov    %rax,0x290(%rsp)
  6e374e:	movaps 0x70(%rsp),%xmm0
  6e3753:	movaps 0x80(%rsp),%xmm1
  6e375b:	movaps 0x90(%rsp),%xmm2
  6e3763:	movaps %xmm2,0x280(%rsp)
  6e376b:	movaps %xmm1,0x270(%rsp)
  6e3773:	movaps %xmm0,0x260(%rsp)
  6e377b:	lea    -0x695fab(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6e3782:	lea    0x33fa9f(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6e3789:	lea    0x33f3c8(%rip),%r8        # a22b58 <__frame_dummy_init_array_entry+0xb68>
  6e3790:	lea    0x260(%rsp),%rdx
  6e3798:	mov    $0x2b,%esi
  6e379d:	call   *0x35f035(%rip)        # a427d8 <_DYNAMIC+0x240>
  6e37a3:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e37a8:	movq   $0x11,0x9c0(%rsp)
  6e37b4:	mov    0x9f0(%rsp),%rax
  6e37bc:	mov    %rax,0x290(%rsp)
  6e37c4:	mov    0x9c0(%rsp),%rax
  6e37cc:	mov    0x9c8(%rsp),%rcx
  6e37d4:	movups 0x9d0(%rsp),%xmm0
  6e37dc:	movups 0x9e0(%rsp),%xmm1
  6e37e4:	movaps %xmm1,0x280(%rsp)
  6e37ec:	movaps %xmm0,0x270(%rsp)
  6e37f4:	mov    %rax,0x260(%rsp)
  6e37fc:	mov    %rcx,0x268(%rsp)
  6e3804:	lea    -0x696034(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6e380b:	lea    0x33fa16(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6e3812:	lea    0x33f387(%rip),%r8        # a22ba0 <__frame_dummy_init_array_entry+0xbb0>
  6e3819:	lea    0x260(%rsp),%rdx
  6e3821:	mov    $0x2b,%esi
  6e3826:	call   *0x35efac(%rip)        # a427d8 <_DYNAMIC+0x240>
  6e382c:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3831:	mov    0x9c8(%rsp),%r14
  6e3839:	mov    0x9d8(%rsp),%rcx
  6e3841:	mov    %rcx,%rax
  6e3844:	sub    %r14,%rax
  6e3847:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  6e3851:	mul    %rdx
  6e3854:	movq   $0x0,0x210(%rsp)
  6e3860:	movq   $0x8,0x218(%rsp)
  6e386c:	movq   $0x0,0x220(%rsp)
  6e3878:	cmp    %r14,%rcx
  6e387b:	jne    6e3915 <text_column_public_control::main+0x4015>
  6e3881:	mov    0x9d0(%rsp),%rax
  6e3889:	test   %rax,%rax
  6e388c:	je     6e38a9 <text_column_public_control::main+0x3fa9>
  6e388e:	mov    0x9c0(%rsp),%rdi
  6e3896:	shl    $0x3,%rax
  6e389a:	lea    (%rax,%rax,2),%rsi
  6e389e:	mov    $0x8,%edx
  6e38a3:	call   *0x35ef57(%rip)        # a42800 <_DYNAMIC+0x268>
  6e38a9:	lea    0x33f5b8(%rip),%rdx        # a22e68 <__frame_dummy_init_array_entry+0xe78>
  6e38b0:	mov    $0x65,%esi
  6e38b5:	lea    -0x69626f(%rip),%rdi        # 4d64d <GCC_except_table0+0xd805>
  6e38bc:	call   *0x35ef76(%rip)        # a42838 <_DYNAMIC+0x2a0>
  6e38c2:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e38c7:	movq   $0x12,0x9c0(%rsp)
  6e38d3:	jmp    6e37b4 <text_column_public_control::main+0x3eb4>
  6e38d8:	lea    -0x693561(%rip),%rdi        # 5037e <GCC_except_table0+0x10536>
  6e38df:	lea    0x340222(%rip),%rdx        # a23b08 <__frame_dummy_init_array_entry+0x1b18>
  6e38e6:	mov    $0x83,%esi
  6e38eb:	call   *0x35ef47(%rip)        # a42838 <_DYNAMIC+0x2a0>
  6e38f1:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e38f6:	movq   $0x19,0x9c0(%rsp)
  6e3902:	jmp    6e37b4 <text_column_public_control::main+0x3eb4>
  6e3907:	movq   $0x12,0x70(%rsp)
  6e3910:	jmp    6e373e <text_column_public_control::main+0x3e3e>
  6e3915:	mov    %rdx,%rbx
  6e3918:	shr    $0x4,%rbx
  6e391c:	add    $0x8,%r14
  6e3920:	mov    0x35eed9(%rip),%r15        # a42800 <_DYNAMIC+0x268>
  6e3927:	jmp    6e393d <text_column_public_control::main+0x403d>
  6e3929:	nopl   0x0(%rax)
  6e3930:	add    $0x18,%r14
  6e3934:	dec    %rbx
  6e3937:	je     6e3881 <text_column_public_control::main+0x3f81>
  6e393d:	mov    -0x8(%r14),%rsi
  6e3941:	test   %rsi,%rsi
  6e3944:	je     6e3930 <text_column_public_control::main+0x4030>
  6e3946:	mov    (%r14),%rdi
  6e3949:	mov    $0x1,%edx
  6e394e:	call   *%r15
  6e3951:	jmp    6e3930 <text_column_public_control::main+0x4030>
  6e3953:	mov    0x118(%rsp),%r15
  6e395b:	movups 0x120(%rsp),%xmm0
  6e3963:	movaps %xmm0,0x10(%rsp)
  6e3968:	movups 0x130(%rsp),%xmm0
  6e3970:	movaps %xmm0,0x20(%rsp)
  6e3975:	movzbl 0x140(%rsp),%ebx
  6e397d:	mov    0x141(%rsp),%eax
  6e3984:	mov    %eax,0x190(%rsp)
  6e398b:	mov    0x144(%rsp),%eax
  6e3992:	mov    %eax,0x193(%rsp)
  6e3999:	mov    0x1e0(%rsp),%r14
  6e39a1:	test   %r14,%r14
  6e39a4:	je     6e39c1 <text_column_public_control::main+0x40c1>
  6e39a6:	mov    %r14,%rdi
  6e39a9:	call   6bfd30 <core::ptr::drop_glue::<gpui::runtime::Runtime<text_column_public_control::Input>>>
  6e39ae:	mov    $0x750,%esi
  6e39b3:	mov    $0x8,%edx
  6e39b8:	mov    %r14,%rdi
  6e39bb:	call   *0x35ee3f(%rip)        # a42800 <_DYNAMIC+0x268>
  6e39c1:	mov    %r15,%r13
  6e39c4:	shr    $0x20,%r13
  6e39c8:	jmp    6e4056 <text_column_public_control::main+0x4756>
  6e39cd:	mov    $0x1b,%eax
  6e39d2:	test   %rcx,%rcx
  6e39d5:	jne    6e3bd5 <text_column_public_control::main+0x42d5>
  6e39db:	mov    $0x1a,%eax
  6e39e0:	jmp    6e3bd5 <text_column_public_control::main+0x42d5>
  6e39e5:	lea    0x33f4c4(%rip),%rdx        # a22eb0 <__frame_dummy_init_array_entry+0xec0>
  6e39ec:	jmp    6e39fe <text_column_public_control::main+0x40fe>
  6e39ee:	lea    0x33f4d3(%rip),%rdx        # a22ec8 <__frame_dummy_init_array_entry+0xed8>
  6e39f5:	jmp    6e3a0c <text_column_public_control::main+0x410c>
  6e39f7:	lea    0x33f482(%rip),%rdx        # a22e80 <__frame_dummy_init_array_entry+0xe90>
  6e39fe:	mov    $0x2,%edi
  6e3a03:	jmp    6e3a11 <text_column_public_control::main+0x4111>
  6e3a05:	lea    0x33f48c(%rip),%rdx        # a22e98 <__frame_dummy_init_array_entry+0xea8>
  6e3a0c:	mov    $0x3,%edi
  6e3a11:	mov    %rdi,%rsi
  6e3a14:	call   *0x35ee16(%rip)        # a42830 <_DYNAMIC+0x298>
  6e3a1a:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3a1f:	movq   $0xd,0x260(%rsp)
  6e3a2b:	movq   $0x0,0x268(%rsp)
  6e3a37:	lea    -0x696267(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6e3a3e:	lea    0x33f7e3(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6e3a45:	lea    0x33f4ac(%rip),%r8        # a22ef8 <__frame_dummy_init_array_entry+0xf08>
  6e3a4c:	lea    0x260(%rsp),%rdx
  6e3a54:	mov    $0x2b,%esi
  6e3a59:	call   *0x35ed79(%rip)        # a427d8 <_DYNAMIC+0x240>
  6e3a5f:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3a64:	mov    $0x1,%edi
  6e3a69:	mov    $0x13,%esi
  6e3a6e:	call   *0x35ee1c(%rip)        # a42890 <_DYNAMIC+0x2f8>
  6e3a74:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3a79:	mov    0x268(%rsp),%r15
  6e3a81:	mov    %r15,%r13
  6e3a84:	shr    $0x20,%r13
  6e3a88:	movups 0x270(%rsp),%xmm0
  6e3a90:	movaps %xmm0,0x10(%rsp)
  6e3a95:	movups 0x280(%rsp),%xmm0
  6e3a9d:	movaps %xmm0,0x20(%rsp)
  6e3aa2:	movzbl 0x290(%rsp),%ebx
  6e3aaa:	mov    0x291(%rsp),%eax
  6e3ab1:	mov    %eax,0x190(%rsp)
  6e3ab8:	mov    0x294(%rsp),%eax
  6e3abf:	mov    %eax,0x193(%rsp)
  6e3ac6:	jmp    6e3b74 <text_column_public_control::main+0x4274>
  6e3acb:	movq   $0xd,0x260(%rsp)
  6e3ad7:	movq   $0x0,0x268(%rsp)
  6e3ae3:	lea    -0x696313(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6e3aea:	lea    0x33f737(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6e3af1:	lea    0x33f520(%rip),%r8        # a23018 <__frame_dummy_init_array_entry+0x1028>
  6e3af8:	lea    0x260(%rsp),%rdx
  6e3b00:	mov    $0x2b,%esi
  6e3b05:	call   *0x35eccd(%rip)        # a427d8 <_DYNAMIC+0x240>
  6e3b0b:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3b10:	mov    $0xd,%eax
  6e3b15:	jmp    6e3b23 <text_column_public_control::main+0x4223>
  6e3b17:	mov    $0xe,%eax
  6e3b1c:	jmp    6e3b23 <text_column_public_control::main+0x4223>
  6e3b1e:	mov    $0x14,%eax
  6e3b23:	mov    %rax,0x260(%rsp)
  6e3b2b:	movq   $0x0,0x268(%rsp)
  6e3b37:	lea    -0x696367(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6e3b3e:	lea    0x33f6e3(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6e3b45:	lea    0x33f4e4(%rip),%r8        # a23030 <__frame_dummy_init_array_entry+0x1040>
  6e3b4c:	lea    0x260(%rsp),%rdx
  6e3b54:	mov    $0x2b,%esi
  6e3b59:	call   *0x35ec79(%rip)        # a427d8 <_DYNAMIC+0x240>
  6e3b5f:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3b64:	lea    0x70(%rsp),%rdi
  6e3b69:	call   6bfb20 <core::ptr::drop_glue::<gpui::source::Sources<text_column_public_control::Input>>>
  6e3b6e:	mov    $0x23,%r12d
  6e3b74:	mov    $0x13,%esi
  6e3b79:	mov    $0x1,%edx
  6e3b7e:	mov    %r14,%rdi
  6e3b81:	call   *0x35ec79(%rip)        # a42800 <_DYNAMIC+0x268>
  6e3b87:	jmp    6e4056 <text_column_public_control::main+0x4756>
  6e3b8c:	movq   $0xd,0x260(%rsp)
  6e3b98:	movq   $0x0,0x268(%rsp)
  6e3ba4:	lea    -0x6964c4(%rip),%rdi        # 4d6e7 <GCC_except_table0+0xd89f>
  6e3bab:	lea    0x33f676(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6e3bb2:	lea    0x33f3b7(%rip),%r8        # a22f70 <__frame_dummy_init_array_entry+0xf80>
  6e3bb9:	mov    $0x24,%esi
  6e3bbe:	call   *0x35ec14(%rip)        # a427d8 <_DYNAMIC+0x240>
  6e3bc4:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3bc9:	mov    $0xd,%eax
  6e3bce:	jmp    6e3bd5 <text_column_public_control::main+0x42d5>
  6e3bd0:	mov    $0xe,%eax
  6e3bd5:	mov    %rax,0x260(%rsp)
  6e3bdd:	mov    0x10(%rsp),%rax
  6e3be2:	mov    %rax,0x268(%rsp)
  6e3bea:	lea    -0x69641a(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6e3bf1:	lea    0x33f630(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6e3bf8:	lea    0x33ef89(%rip),%r8        # a22b88 <__frame_dummy_init_array_entry+0xb98>
  6e3bff:	lea    0x260(%rsp),%rdx
  6e3c07:	mov    $0x2b,%esi
  6e3c0c:	call   *0x35ebc6(%rip)        # a427d8 <_DYNAMIC+0x240>
  6e3c12:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3c17:	movq   $0xd,0x9c0(%rsp)
  6e3c23:	movq   $0x0,0x9c8(%rsp)
  6e3c2f:	jmp    6e37b4 <text_column_public_control::main+0x3eb4>
  6e3c34:	movq   $0xe,0x9c0(%rsp)
  6e3c40:	jmp    6e37b4 <text_column_public_control::main+0x3eb4>
  6e3c45:	mov    $0x11,%eax
  6e3c4a:	jmp    6e3c84 <text_column_public_control::main+0x4384>
  6e3c4c:	mov    0x268(%rsp),%rcx
  6e3c54:	movups 0x270(%rsp),%xmm0
  6e3c5c:	movaps %xmm0,0xc60(%rsp)
  6e3c64:	movups 0x280(%rsp),%xmm0
  6e3c6c:	movaps %xmm0,0xc70(%rsp)
  6e3c74:	mov    0x290(%rsp),%rdx
  6e3c7c:	mov    %rdx,0xc80(%rsp)
  6e3c84:	mov    %rax,0x9c0(%rsp)
  6e3c8c:	mov    %rcx,0x9c8(%rsp)
  6e3c94:	movaps 0xc60(%rsp),%xmm0
  6e3c9c:	movaps 0xc70(%rsp),%xmm1
  6e3ca4:	movups %xmm0,0x9d0(%rsp)
  6e3cac:	movups %xmm1,0x9e0(%rsp)
  6e3cb4:	mov    0xc80(%rsp),%rax
  6e3cbc:	mov    %rax,0x9f0(%rsp)
  6e3cc4:	jmp    6e37b4 <text_column_public_control::main+0x3eb4>
  6e3cc9:	mov    $0x11,%eax
  6e3cce:	mov    0x290(%rsp),%rcx
  6e3cd6:	mov    %rcx,0x9f0(%rsp)
  6e3cde:	movups 0x270(%rsp),%xmm0
  6e3ce6:	movups 0x280(%rsp),%xmm1
  6e3cee:	movups %xmm1,0x9e0(%rsp)
  6e3cf6:	movups %xmm0,0x9d0(%rsp)
  6e3cfe:	mov    %rax,0x9c0(%rsp)
  6e3d06:	mov    %r13,0x9c8(%rsp)
  6e3d0e:	jmp    6e37b4 <text_column_public_control::main+0x3eb4>
  6e3d13:	lea    0x33fe1e(%rip),%rax        # a23b38 <__frame_dummy_init_array_entry+0x1b48>
  6e3d1a:	mov    %rax,0x40(%rsp)
  6e3d1f:	mov    %r13,%rdi
  6e3d22:	mov    0x40(%rsp),%rdx
  6e3d27:	call   *0x35eb03(%rip)        # a42830 <_DYNAMIC+0x298>
  6e3d2d:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3d32:	mov    $0xd,%eax
  6e3d37:	jmp    6e3d45 <text_column_public_control::main+0x4445>
  6e3d39:	mov    $0xe,%eax
  6e3d3e:	jmp    6e3d45 <text_column_public_control::main+0x4445>
  6e3d40:	mov    $0x14,%eax
  6e3d45:	mov    %rax,0x260(%rsp)
  6e3d4d:	movq   $0x0,0x268(%rsp)
  6e3d59:	lea    -0x696589(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6e3d60:	lea    0x33f4c1(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6e3d67:	lea    0x33eeaa(%rip),%r8        # a22c18 <__frame_dummy_init_array_entry+0xc28>
  6e3d6e:	lea    0x260(%rsp),%rdx
  6e3d76:	mov    $0x2b,%esi
  6e3d7b:	call   *0x35ea57(%rip)        # a427d8 <_DYNAMIC+0x240>
  6e3d81:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3d86:	movq   $0xd,0x70(%rsp)
  6e3d8f:	movq   $0x0,0x78(%rsp)
  6e3d98:	jmp    6e373e <text_column_public_control::main+0x3e3e>
  6e3d9d:	movq   $0xe,0x70(%rsp)
  6e3da6:	jmp    6e373e <text_column_public_control::main+0x3e3e>
  6e3dab:	lea    0x33ea5e(%rip),%rdi        # a22810 <__frame_dummy_init_array_entry+0x820>
  6e3db2:	call   *0x35eae8(%rip)        # a428a0 <_DYNAMIC+0x308>
  6e3db8:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3dbd:	lea    0x33fa04(%rip),%rax        # a237c8 <__frame_dummy_init_array_entry+0x17d8>
  6e3dc4:	jmp    6e3d1a <text_column_public_control::main+0x441a>
  6e3dc9:	lea    0x33f8d8(%rip),%rdx        # a236a8 <__frame_dummy_init_array_entry+0x16b8>
  6e3dd0:	call   *0x35ea5a(%rip)        # a42830 <_DYNAMIC+0x298>
  6e3dd6:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3ddb:	lea    0x33f8f6(%rip),%rax        # a236d8 <__frame_dummy_init_array_entry+0x16e8>
  6e3de2:	mov    %rax,0xd8(%rsp)
  6e3dea:	mov    0xd8(%rsp),%rdx
  6e3df2:	call   *0x35ea38(%rip)        # a42830 <_DYNAMIC+0x298>
  6e3df8:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3dfd:	lea    0x33f8bc(%rip),%rdi        # a236c0 <__frame_dummy_init_array_entry+0x16d0>
  6e3e04:	call   *0x35ea96(%rip)        # a428a0 <_DYNAMIC+0x308>
  6e3e0a:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3e0f:	lea    0x33f8da(%rip),%rdi        # a236f0 <__frame_dummy_init_array_entry+0x1700>
  6e3e16:	call   *0x35ea84(%rip)        # a428a0 <_DYNAMIC+0x308>
  6e3e1c:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e3e21:	jmp    6e3fc9 <text_column_public_control::main+0x46c9>
  6e3e26:	jmp    6e3f43 <text_column_public_control::main+0x4643>
  6e3e2b:	mov    %rax,%rbx
  6e3e2e:	lea    0x260(%rsp),%rdi
  6e3e36:	call   6bfab0 <core::ptr::drop_glue::<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>>
  6e3e3b:	jmp    6e3e46 <text_column_public_control::main+0x4546>
  6e3e3d:	jmp    6e3e43 <text_column_public_control::main+0x4543>
  6e3e3f:	jmp    6e3e43 <text_column_public_control::main+0x4543>
  6e3e41:	ud2
  6e3e43:	mov    %rax,%rbx
  6e3e46:	mov    0xe0(%rsp),%rax
  6e3e4e:	test   %rax,%rax
  6e3e51:	je     6e417c <text_column_public_control::main+0x487c>
  6e3e57:	mov    0xe8(%rsp),%rdi
  6e3e5f:	shl    $0x3,%rax
  6e3e63:	lea    (%rax,%rax,2),%rsi
  6e3e67:	mov    $0x8,%edx
  6e3e6c:	call   *0x35e98e(%rip)        # a42800 <_DYNAMIC+0x268>
  6e3e72:	jmp    6e417c <text_column_public_control::main+0x487c>
  6e3e77:	mov    %rax,%rbx
  6e3e7a:	jmp    6e4192 <text_column_public_control::main+0x4892>
  6e3e7f:	mov    %rax,%rbx
  6e3e82:	jmp    6e4192 <text_column_public_control::main+0x4892>
  6e3e87:	jmp    6e4cc0 <text_column_public_control::main+0x53c0>
  6e3e8c:	jmp    6e3ecd <text_column_public_control::main+0x45cd>
  6e3e8e:	mov    %rax,%rbx
  6e3e91:	jmp    6e3f0f <text_column_public_control::main+0x460f>
  6e3e93:	mov    %rax,%rbx
  6e3e96:	lea    0x33e3a3(%rip),%rsi        # a22240 <__frame_dummy_init_array_entry+0x250>
  6e3e9d:	mov    %r15,%rdi
  6e3ea0:	call   6c1c70 <core::ptr::drop_glue::<alloc::boxed::Box<dyn for<'a, 'b> core::ops::function::Fn<(&'a mut gpui::element::El<'b>,), Output = ()>>>>
  6e3ea5:	jmp    6e3ffc <text_column_public_control::main+0x46fc>
  6e3eaa:	call   *0x35e978(%rip)        # a42828 <_DYNAMIC+0x290>
  6e3eb0:	jmp    6e3f29 <text_column_public_control::main+0x4629>
  6e3eb2:	mov    %rax,%rbx
  6e3eb5:	lea    0x260(%rsp),%rdi
  6e3ebd:	call   6bfb20 <core::ptr::drop_glue::<gpui::source::Sources<text_column_public_control::Input>>>
  6e3ec2:	jmp    6e4009 <text_column_public_control::main+0x4709>
  6e3ec7:	call   *0x35e95b(%rip)        # a42828 <_DYNAMIC+0x290>
  6e3ecd:	mov    %rax,%rbx
  6e3ed0:	lea    0x260(%rsp),%rdi
  6e3ed8:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e3edd:	jmp    6e415a <text_column_public_control::main+0x485a>
  6e3ee2:	mov    %rax,%rbx
  6e3ee5:	jmp    6e40f7 <text_column_public_control::main+0x47f7>
  6e3eea:	mov    %rax,%rbx
  6e3eed:	mov    0x1e0(%rsp),%rdi
  6e3ef5:	call   6bfc70 <core::ptr::drop_glue::<gpui::runtime::Win<text_column_public_control::Input>>>
  6e3efa:	jmp    6e4d47 <text_column_public_control::main+0x5447>
  6e3eff:	mov    %rax,%rbx
  6e3f02:	lea    0xc60(%rsp),%rdi
  6e3f0a:	call   6c6240 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  6e3f0f:	lea    0x70(%rsp),%rdi
  6e3f14:	call   6bfb20 <core::ptr::drop_glue::<gpui::source::Sources<text_column_public_control::Input>>>
  6e3f19:	jmp    6e40f7 <text_column_public_control::main+0x47f7>
  6e3f1e:	call   *0x35e904(%rip)        # a42828 <_DYNAMIC+0x290>
  6e3f24:	jmp    6e3fc9 <text_column_public_control::main+0x46c9>
  6e3f29:	mov    %rax,%rbx
  6e3f2c:	lea    0x260(%rsp),%rdi
  6e3f34:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e3f39:	jmp    6e4d19 <text_column_public_control::main+0x5419>
  6e3f3e:	jmp    6e4179 <text_column_public_control::main+0x4879>
  6e3f43:	mov    %rax,%rbx
  6e3f46:	lea    0xc60(%rsp),%rdi
  6e3f4e:	call   6bfab0 <core::ptr::drop_glue::<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>>
  6e3f53:	jmp    6e417c <text_column_public_control::main+0x487c>
  6e3f58:	mov    %rax,%rbx
  6e3f5b:	jmp    6e41ec <text_column_public_control::main+0x48ec>
  6e3f60:	jmp    6e3fc9 <text_column_public_control::main+0x46c9>
  6e3f62:	jmp    6e4179 <text_column_public_control::main+0x4879>
  6e3f67:	jmp    6e4179 <text_column_public_control::main+0x4879>
  6e3f6c:	jmp    6e3fc9 <text_column_public_control::main+0x46c9>
  6e3f6e:	mov    %rax,%rbx
  6e3f71:	test   %rbp,%rbp
  6e3f74:	je     6e3f93 <text_column_public_control::main+0x4693>
  6e3f76:	mov    $0x1,%edx
  6e3f7b:	mov    %r13,%rdi
  6e3f7e:	mov    %rbp,%rsi
  6e3f81:	call   *0x35e879(%rip)        # a42800 <_DYNAMIC+0x268>
  6e3f87:	jmp    6e3f93 <text_column_public_control::main+0x4693>
  6e3f89:	jmp    6e3fc9 <text_column_public_control::main+0x46c9>
  6e3f8b:	jmp    6e4157 <text_column_public_control::main+0x4857>
  6e3f90:	mov    %rax,%rbx
  6e3f93:	lea    0x260(%rsp),%rdi
  6e3f9b:	call   6c50a0 <core::ptr::drop_glue::<std::env::Args>>
  6e3fa0:	lea    0x70(%rsp),%rdi
  6e3fa5:	call   6c0fb0 <core::ptr::drop_glue::<alloc::vec::Vec<alloc::string::String>>>
  6e3faa:	mov    %rbx,%rdi
  6e3fad:	call   a20c40 <_Unwind_Resume@plt>
  6e3fb2:	mov    %rax,%rbx
  6e3fb5:	lea    0x260(%rsp),%rdi
  6e3fbd:	call   6bfab0 <core::ptr::drop_glue::<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>>
  6e3fc2:	jmp    6e417c <text_column_public_control::main+0x487c>
  6e3fc7:	jmp    6e3fc9 <text_column_public_control::main+0x46c9>
  6e3fc9:	mov    %rax,%rbx
  6e3fcc:	lea    0x260(%rsp),%rdi
  6e3fd4:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e3fd9:	jmp    6e417c <text_column_public_control::main+0x487c>
  6e3fde:	mov    %rax,%rbx
  6e3fe1:	lea    0x260(%rsp),%rdi
  6e3fe9:	call   6bfd30 <core::ptr::drop_glue::<gpui::runtime::Runtime<text_column_public_control::Input>>>
  6e3fee:	jmp    6e4d47 <text_column_public_control::main+0x5447>
  6e3ff3:	call   *0x35e82f(%rip)        # a42828 <_DYNAMIC+0x290>
  6e3ff9:	mov    %rax,%rbx
  6e3ffc:	lea    0x260(%rsp),%rdi
  6e4004:	call   6bfb20 <core::ptr::drop_glue::<gpui::source::Sources<text_column_public_control::Input>>>
  6e4009:	mov    %rbx,%rdi
  6e400c:	call   *0x35ea66(%rip)        # a42a78 <_DYNAMIC+0x4e0>
  6e4012:	mov    %rax,%r15
  6e4015:	mov    %rdx,%r12
  6e4018:	mov    (%rdx),%rax
  6e401b:	test   %rax,%rax
  6e401e:	je     6e4025 <text_column_public_control::main+0x4725>
  6e4020:	mov    %r15,%rdi
  6e4023:	call   *%rax
  6e4025:	mov    0x8(%r12),%rsi
  6e402a:	test   %rsi,%rsi
  6e402d:	je     6e403d <text_column_public_control::main+0x473d>
  6e402f:	mov    0x10(%r12),%rdx
  6e4034:	mov    %r15,%rdi
  6e4037:	call   *0x35e7c3(%rip)        # a42800 <_DYNAMIC+0x268>
  6e403d:	mov    $0x13,%esi
  6e4042:	mov    $0x1,%edx
  6e4047:	mov    %r14,%rdi
  6e404a:	call   *0x35e7b0(%rip)        # a42800 <_DYNAMIC+0x268>
  6e4050:	mov    $0xf,%r12d
  6e4056:	mov    %r12,0x9c0(%rsp)
  6e405e:	shl    $0x20,%r13
  6e4062:	mov    %r15d,%eax
  6e4065:	or     %r13,%rax
  6e4068:	mov    %rax,0x9c8(%rsp)
  6e4070:	movaps 0x10(%rsp),%xmm0
  6e4075:	movups %xmm0,0x9d0(%rsp)
  6e407d:	movdqa 0x20(%rsp),%xmm0
  6e4083:	movdqu %xmm0,0x9e0(%rsp)
  6e408c:	mov    %bl,0x9f0(%rsp)
  6e4093:	mov    0x190(%rsp),%eax
  6e409a:	mov    0x193(%rsp),%ecx
  6e40a1:	mov    %eax,0x9f1(%rsp)
  6e40a8:	mov    %ecx,0x9f4(%rsp)
  6e40af:	lea    -0x6968df(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6e40b6:	lea    0x33f16b(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6e40bd:	lea    0x33eaac(%rip),%r8        # a22b70 <__frame_dummy_init_array_entry+0xb80>
  6e40c4:	lea    0x9c0(%rsp),%rdx
  6e40cc:	mov    $0x2b,%esi
  6e40d1:	call   *0x35e701(%rip)        # a427d8 <_DYNAMIC+0x240>
  6e40d7:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e40dc:	mov    %rax,%rbx
  6e40df:	mov    0x8(%r12),%rsi
  6e40e4:	test   %rsi,%rsi
  6e40e7:	je     6e40f7 <text_column_public_control::main+0x47f7>
  6e40e9:	mov    0x10(%r12),%rdx
  6e40ee:	mov    %r15,%rdi
  6e40f1:	call   *0x35e709(%rip)        # a42800 <_DYNAMIC+0x268>
  6e40f7:	mov    $0x13,%esi
  6e40fc:	mov    $0x1,%edx
  6e4101:	jmp    6e419c <text_column_public_control::main+0x489c>
  6e4106:	mov    %rax,%rbx
  6e4109:	lea    0x9c0(%rsp),%rdi
  6e4111:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e4116:	lea    0x210(%rsp),%rdi
  6e411e:	call   6c0fb0 <core::ptr::drop_glue::<alloc::vec::Vec<alloc::string::String>>>
  6e4123:	mov    %rbx,%rdi
  6e4126:	call   a20c40 <_Unwind_Resume@plt>
  6e412b:	call   *0x35e94f(%rip)        # a42a80 <_DYNAMIC+0x4e8>
  6e4131:	call   *0x35e6f1(%rip)        # a42828 <_DYNAMIC+0x290>
  6e4137:	mov    %rax,%rbx
  6e413a:	jmp    6e4d3d <text_column_public_control::main+0x543d>
  6e413f:	mov    %rax,%rbx
  6e4142:	lea    0x210(%rsp),%rdi
  6e414a:	call   6c0fb0 <core::ptr::drop_glue::<alloc::vec::Vec<alloc::string::String>>>
  6e414f:	mov    %rbx,%rdi
  6e4152:	call   a20c40 <_Unwind_Resume@plt>
  6e4157:	mov    %rax,%rbx
  6e415a:	mov    0x30(%rsp),%rdi
  6e415f:	call   6bfcd0 <core::ptr::drop_glue::<gpui::runtime::Win<text_column_public_control::Model>>>
  6e4164:	jmp    6e4d47 <text_column_public_control::main+0x5447>
  6e4169:	call   *0x35e6b9(%rip)        # a42828 <_DYNAMIC+0x290>
  6e416f:	mov    %rax,%rbx
  6e4172:	jmp    6e4d19 <text_column_public_control::main+0x5419>
  6e4177:	jmp    6e4179 <text_column_public_control::main+0x4879>
  6e4179:	mov    %rax,%rbx
  6e417c:	mov    0x30(%rsp),%r14
  6e4181:	test   %r14,%r14
  6e4184:	je     6e4d47 <text_column_public_control::main+0x5447>
  6e418a:	mov    %r14,%rdi
  6e418d:	call   6bfd30 <core::ptr::drop_glue::<gpui::runtime::Runtime<text_column_public_control::Input>>>
  6e4192:	mov    $0x750,%esi
  6e4197:	mov    $0x8,%edx
  6e419c:	mov    %r14,%rdi
  6e419f:	call   *0x35e65b(%rip)        # a42800 <_DYNAMIC+0x268>
  6e41a5:	lea    0x210(%rsp),%rdi
  6e41ad:	call   6c0fb0 <core::ptr::drop_glue::<alloc::vec::Vec<alloc::string::String>>>
  6e41b2:	mov    %rbx,%rdi
  6e41b5:	call   a20c40 <_Unwind_Resume@plt>
  6e41ba:	mov    $0x750,%esi
  6e41bf:	mov    $0x8,%edx
  6e41c4:	mov    %r14,%rdi
  6e41c7:	call   *0x35e633(%rip)        # a42800 <_DYNAMIC+0x268>
  6e41cd:	call   *0x35e655(%rip)        # a42828 <_DYNAMIC+0x290>
  6e41d3:	mov    %rax,%rbx
  6e41d6:	test   %r14,%r14
  6e41d9:	je     6e41ec <text_column_public_control::main+0x48ec>
  6e41db:	mov    $0x1,%edx
  6e41e0:	mov    %r15,%rdi
  6e41e3:	mov    %r14,%rsi
  6e41e6:	call   *0x35e614(%rip)        # a42800 <_DYNAMIC+0x268>
  6e41ec:	mov    0x9c8(%rsp),%r15
  6e41f4:	mov    0x9d8(%rsp),%rcx
  6e41fc:	mov    %rcx,%rax
  6e41ff:	sub    %r15,%rax
  6e4202:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  6e420c:	mul    %rdx
  6e420f:	cmp    %r15,%rcx
  6e4212:	jne    6e4229 <text_column_public_control::main+0x4929>
  6e4214:	mov    0x9d0(%rsp),%rax
  6e421c:	test   %rax,%rax
  6e421f:	jne    6e425f <text_column_public_control::main+0x495f>
  6e4221:	mov    %rbx,%rdi
  6e4224:	call   a20c40 <_Unwind_Resume@plt>
  6e4229:	mov    %rdx,%r14
  6e422c:	shr    $0x4,%r14
  6e4230:	add    $0x8,%r15
  6e4234:	mov    0x35e5c5(%rip),%r12        # a42800 <_DYNAMIC+0x268>
  6e423b:	jmp    6e4249 <text_column_public_control::main+0x4949>
  6e423d:	nopl   (%rax)
  6e4240:	add    $0x18,%r15
  6e4244:	dec    %r14
  6e4247:	je     6e4214 <text_column_public_control::main+0x4914>
  6e4249:	mov    -0x8(%r15),%rsi
  6e424d:	test   %rsi,%rsi
  6e4250:	je     6e4240 <text_column_public_control::main+0x4940>
  6e4252:	mov    (%r15),%rdi
  6e4255:	mov    $0x1,%edx
  6e425a:	call   *%r12
  6e425d:	jmp    6e4240 <text_column_public_control::main+0x4940>
  6e425f:	mov    0x9c0(%rsp),%rdi
  6e4267:	shl    $0x3,%rax
  6e426b:	lea    (%rax,%rax,2),%rsi
  6e426f:	mov    $0x8,%edx
  6e4274:	call   *0x35e586(%rip)        # a42800 <_DYNAMIC+0x268>
  6e427a:	mov    %rbx,%rdi
  6e427d:	call   a20c40 <_Unwind_Resume@plt>
  6e4282:	mov    0x0(%r13,%rcx,8),%rdx
  6e4287:	xor    %esi,%esi
  6e4289:	cmp    (%r14,%rcx,8),%rdx
  6e428d:	lea    0x1(%rcx),%rcx
  6e4291:	sete   %sil
  6e4295:	add    %rsi,%rbx
  6e4298:	cmp    %rcx,%rax
  6e429b:	jne    6e4282 <text_column_public_control::main+0x4982>
  6e429d:	mov    %rbx,0x248(%rsp)
  6e42a5:	lea    -0x6a26f8(%rip),%rax        # 41bb4 <GCC_except_table0+0x1d6c>
  6e42ac:	movslq (%rax,%r15,4),%rcx
  6e42b0:	add    %rax,%rcx
  6e42b3:	jmp    *%rcx
  6e42b5:	cmp    0x50(%rsp),%rdi
  6e42ba:	jne    6e4b23 <text_column_public_control::main+0x5223>
  6e42c0:	lea    0x0(,%rdi,8),%rdx
  6e42c8:	mov    %rdi,%r12
  6e42cb:	mov    %r13,%rdi
  6e42ce:	mov    %r14,%rsi
  6e42d1:	call   *0x35e841(%rip)        # a42b18 <bcmp@GLIBC_2.2.5>
  6e42d7:	test   %eax,%eax
  6e42d9:	jne    6e4b23 <text_column_public_control::main+0x5223>
  6e42df:	mov    %r12,%rdi
  6e42e2:	cmpb   $0x4,0x20(%rsp)
  6e42e7:	je     6e4301 <text_column_public_control::main+0x4a01>
  6e42e9:	cmp    $0x5,%r15d
  6e42ed:	je     6e42f7 <text_column_public_control::main+0x49f7>
  6e42ef:	cmp    $0x6,%r15d
  6e42f3:	je     6e432f <text_column_public_control::main+0x4a2f>
  6e42f5:	jmp    6e433e <text_column_public_control::main+0x4a3e>
  6e42f7:	test   %rbx,%rbx
  6e42fa:	je     6e433e <text_column_public_control::main+0x4a3e>
  6e42fc:	jmp    6e4b9b <text_column_public_control::main+0x529b>
  6e4301:	movq   $0x7fff,0x260(%rsp)
  6e430d:	cmp    $0x7fff,%rbx
  6e4314:	je     6e433e <text_column_public_control::main+0x4a3e>
  6e4316:	lea    0x33edeb(%rip),%r9        # a23108 <__frame_dummy_init_array_entry+0x1118>
  6e431d:	lea    0x260(%rsp),%rdx
  6e4325:	jmp    6e4ba9 <text_column_public_control::main+0x52a9>
  6e432a:	test   %bpl,%bpl
  6e432d:	je     6e42b5 <text_column_public_control::main+0x49b5>
  6e432f:	test   %rbx,%rbx
  6e4332:	setne  %al
  6e4335:	test   %al,%bpl
  6e4338:	jne    6e4b9b <text_column_public_control::main+0x529b>
  6e433e:	mov    %rdi,0x60(%rsp)
  6e4343:	mov    0x8(%rsp),%rdi
  6e4348:	lea    -0x696be4(%rip),%rcx        # 4d76b <GCC_except_table0+0xd923>
  6e434f:	mov    $0x6,%r8d
  6e4355:	mov    %r15d,%esi
  6e4358:	mov    0x10(%rsp),%edx
  6e435c:	call   6dbc70 <text_column_public_control::emit_state>
  6e4361:	mov    0x8(%rsp),%rsi
  6e4366:	lea    0x1e0(%rsp),%rdi
  6e436e:	call   6b60e0 <text_column_public_control::observe::<text_column_public_control::Model>>
  6e4373:	lea    0x260(%rsp),%rdi
  6e437b:	lea    0x8(%rsp),%rsi
  6e4380:	mov    $0x1,%r8d
  6e4386:	mov    %r15d,%edx
  6e4389:	mov    0x10(%rsp),%ecx
  6e438d:	call   6ddac0 <text_column_public_control::edit>
  6e4392:	mov    0x8(%rsp),%rsi
  6e4397:	test   %rsi,%rsi
  6e439a:	je     6e4bd9 <text_column_public_control::main+0x52d9>
  6e43a0:	cmpb   $0x0,0x78e(%rsi)
  6e43a7:	jne    6e4be0 <text_column_public_control::main+0x52e0>
  6e43ad:	mov    0x6f0(%rsi),%r12
  6e43b4:	test   %r12,%r12
  6e43b7:	je     6e4be7 <text_column_public_control::main+0x52e7>
  6e43bd:	mov    0x6f8(%rsi),%rbx
  6e43c4:	mov    %r12,0x30(%rsp)
  6e43c9:	mov    %rbx,0x38(%rsp)
  6e43ce:	lea    0x260(%rsp),%rbp
  6e43d6:	mov    %rbp,%rdi
  6e43d9:	call   6b60e0 <text_column_public_control::observe::<text_column_public_control::Model>>
  6e43de:	mov    0x260(%rsp),%rax
  6e43e6:	lea    0x33ed4b(%rip),%rcx        # a23138 <__frame_dummy_init_array_entry+0x1148>
  6e43ed:	cmp    0x1e0(%rsp),%rax
  6e43f5:	jne    6e4b0c <text_column_public_control::main+0x520c>
  6e43fb:	mov    %rax,0xd8(%rsp)
  6e4403:	mov    0x268(%rsp),%rax
  6e440b:	mov    %rax,0x158(%rsp)
  6e4413:	cmp    0x1e8(%rsp),%rax
  6e441b:	jne    6e4b0c <text_column_public_control::main+0x520c>
  6e4421:	mov    0x270(%rsp),%rax
  6e4429:	mov    %rax,0x68(%rsp)
  6e442e:	cmp    0x1f0(%rsp),%rax
  6e4436:	jne    6e4b0c <text_column_public_control::main+0x520c>
  6e443c:	xor    %r8d,%r8d
  6e443f:	cmp    $0x3,%r15b
  6e4443:	sete   %r8b
  6e4447:	add    %r8d,%r8d
  6e444a:	lea    0x260(%rsp),%rdi
  6e4452:	lea    0x8(%rsp),%rsi
  6e4457:	mov    %r15d,%edx
  6e445a:	mov    0x10(%rsp),%ecx
  6e445e:	call   6ddac0 <text_column_public_control::edit>
  6e4463:	mov    0x8(%rsp),%rsi
  6e4468:	test   %rsi,%rsi
  6e446b:	je     6e4c2d <text_column_public_control::main+0x532d>
  6e4471:	cmpb   $0x0,0x78e(%rsi)
  6e4478:	jne    6e4c34 <text_column_public_control::main+0x5334>
  6e447e:	mov    0x6f0(%rsi),%rcx
  6e4485:	test   %rcx,%rcx
  6e4488:	je     6e4c3b <text_column_public_control::main+0x533b>
  6e448e:	mov    0x6f8(%rsi),%rax
  6e4495:	mov    %rcx,0x230(%rsp)
  6e449d:	mov    %rax,0x238(%rsp)
  6e44a5:	cmp    %rax,%rbx
  6e44a8:	sete   %al
  6e44ab:	cmp    %rcx,%r12
  6e44ae:	je     6e44b2 <text_column_public_control::main+0x4bb2>
  6e44b0:	xor    %eax,%eax
  6e44b2:	test   %al,%al
  6e44b4:	jne    6e4b56 <text_column_public_control::main+0x5256>
  6e44ba:	lea    0x260(%rsp),%rdi
  6e44c2:	mov    %r12,%rdx
  6e44c5:	mov    %rbx,%rcx
  6e44c8:	call   70d850 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge>
  6e44cd:	mov    0x260(%rsp),%rbx
  6e44d5:	cmp    $0xfffffffffffffffe,%rbx
  6e44d9:	je     6e4b3d <text_column_public_control::main+0x523d>
  6e44df:	lea    -0x696f2e(%rip),%rsi        # 4d5b8 <GCC_except_table0+0xd770>
  6e44e6:	lea    0x260(%rsp),%rdi
  6e44ee:	call   727d30 <<gpui::runtime::Error as core::cmp::PartialEq>::eq>
  6e44f3:	test   %al,%al
  6e44f5:	je     6e4b3d <text_column_public_control::main+0x523d>
  6e44fb:	sub    $0xd,%rbx
  6e44ff:	mov    $0x14,%eax
  6e4504:	cmovge %rbx,%rax
  6e4508:	cmp    $0x14,%rax
  6e450c:	je     6e452b <text_column_public_control::main+0x4c2b>
  6e450e:	cmp    $0x19,%rax
  6e4512:	jne    6e454e <text_column_public_control::main+0x4c4e>
  6e4514:	mov    0x268(%rsp),%rsi
  6e451c:	test   %rsi,%rsi
  6e451f:	je     6e454e <text_column_public_control::main+0x4c4e>
  6e4521:	lea    0x270(%rsp),%rax
  6e4529:	jmp    6e4540 <text_column_public_control::main+0x4c40>
  6e452b:	mov    0x278(%rsp),%rsi
  6e4533:	test   %rsi,%rsi
  6e4536:	je     6e454e <text_column_public_control::main+0x4c4e>
  6e4538:	lea    0x280(%rsp),%rax
  6e4540:	mov    (%rax),%rdi
  6e4543:	mov    $0x1,%edx
  6e4548:	call   *0x35e2b2(%rip)        # a42800 <_DYNAMIC+0x268>
  6e454e:	mov    0x8(%rsp),%rsi
  6e4553:	test   %rsi,%rsi
  6e4556:	je     6e4574 <text_column_public_control::main+0x4c74>
  6e4558:	cmpb   $0x0,0x78e(%rsi)
  6e455f:	je     6e4593 <text_column_public_control::main+0x4c93>
  6e4561:	movq   $0xe,0x260(%rsp)
  6e456d:	mov    $0xe,%ebx
  6e4572:	jmp    6e45c2 <text_column_public_control::main+0x4cc2>
  6e4574:	movq   $0xd,0x260(%rsp)
  6e4580:	movq   $0x0,0x268(%rsp)
  6e458c:	mov    $0xd,%ebx
  6e4591:	jmp    6e45c2 <text_column_public_control::main+0x4cc2>
  6e4593:	lea    0x260(%rsp),%rdi
  6e459b:	mov    0x150(%rsp),%rdx
  6e45a3:	mov    0x148(%rsp),%rcx
  6e45ab:	call   70d850 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge>
  6e45b0:	mov    0x260(%rsp),%rbx
  6e45b8:	cmp    $0xfffffffffffffffe,%rbx
  6e45bc:	je     6e4bc0 <text_column_public_control::main+0x52c0>
  6e45c2:	lea    -0x697011(%rip),%rsi        # 4d5b8 <GCC_except_table0+0xd770>
  6e45c9:	lea    0x260(%rsp),%rdi
  6e45d1:	call   727d30 <<gpui::runtime::Error as core::cmp::PartialEq>::eq>
  6e45d6:	test   %al,%al
  6e45d8:	je     6e4bc0 <text_column_public_control::main+0x52c0>
  6e45de:	sub    $0xd,%rbx
  6e45e2:	mov    $0x14,%eax
  6e45e7:	cmovge %rbx,%rax
  6e45eb:	cmp    $0x14,%rax
  6e45ef:	je     6e460e <text_column_public_control::main+0x4d0e>
  6e45f1:	cmp    $0x19,%rax
  6e45f5:	jne    6e4631 <text_column_public_control::main+0x4d31>
  6e45f7:	mov    0x268(%rsp),%rsi
  6e45ff:	test   %rsi,%rsi
  6e4602:	je     6e4631 <text_column_public_control::main+0x4d31>
  6e4604:	lea    0x270(%rsp),%rax
  6e460c:	jmp    6e4623 <text_column_public_control::main+0x4d23>
  6e460e:	mov    0x278(%rsp),%rsi
  6e4616:	test   %rsi,%rsi
  6e4619:	je     6e4631 <text_column_public_control::main+0x4d31>
  6e461b:	lea    0x280(%rsp),%rax
  6e4623:	mov    (%rax),%rdi
  6e4626:	mov    $0x1,%edx
  6e462b:	call   *0x35e1cf(%rip)        # a42800 <_DYNAMIC+0x268>
  6e4631:	mov    0x8(%rsp),%rsi
  6e4636:	lea    0x260(%rsp),%rbp
  6e463e:	mov    %rbp,%rdi
  6e4641:	call   6b60e0 <text_column_public_control::observe::<text_column_public_control::Model>>
  6e4646:	mov    0x158(%rsp),%rax
  6e464e:	cmp    %rax,0x268(%rsp)
  6e4656:	sete   %al
  6e4659:	mov    0xd8(%rsp),%rcx
  6e4661:	cmp    %rcx,0x260(%rsp)
  6e4669:	jne    6e4af4 <text_column_public_control::main+0x51f4>
  6e466f:	mov    0x68(%rsp),%rcx
  6e4674:	cmp    %rcx,0x270(%rsp)
  6e467c:	sete   %cl
  6e467f:	test   %al,%al
  6e4681:	je     6e4afb <text_column_public_control::main+0x51fb>
  6e4687:	test   %cl,%cl
  6e4689:	je     6e4b05 <text_column_public_control::main+0x5205>
  6e468f:	mov    0x8(%rsp),%rdi
  6e4694:	lea    -0x6a2c53(%rip),%rcx        # 41a48 <GCC_except_table0+0x1c00>
  6e469b:	mov    $0x8,%r8d
  6e46a1:	mov    %r15d,%esi
  6e46a4:	mov    0x10(%rsp),%edx
  6e46a8:	call   6dbc70 <text_column_public_control::emit_state>
  6e46ad:	mov    0x8(%rsp),%rsi
  6e46b2:	lea    0x260(%rsp),%rdi
  6e46ba:	call   6b5fc0 <text_column_public_control::ack::<text_column_public_control::Model>>
  6e46bf:	mov    0x8(%rsp),%rdi
  6e46c4:	lea    -0x696f5a(%rip),%rcx        # 4d771 <GCC_except_table0+0xd929>
  6e46cb:	mov    $0x6,%r8d
  6e46d1:	mov    %r15d,%esi
  6e46d4:	mov    0x10(%rsp),%edx
  6e46d8:	call   6dbc70 <text_column_public_control::emit_state>
  6e46dd:	mov    0x8(%rsp),%rax
  6e46e2:	test   %rax,%rax
  6e46e5:	je     6e4c7e <text_column_public_control::main+0x537e>
  6e46eb:	mov    0x770(%rax),%rcx
  6e46f2:	mov    %rcx,0xa20(%rsp)
  6e46fa:	movups 0x760(%rax),%xmm0
  6e4701:	movaps %xmm0,0xa10(%rsp)
  6e4709:	movups 0x750(%rax),%xmm0
  6e4710:	movaps %xmm0,0xa00(%rsp)
  6e4718:	movdqu 0x710(%rax),%xmm0
  6e4720:	movups 0x720(%rax),%xmm1
  6e4727:	movdqu 0x730(%rax),%xmm2
  6e472f:	movdqu 0x740(%rax),%xmm3
  6e4737:	movdqa %xmm3,0x9f0(%rsp)
  6e4740:	movdqa %xmm2,0x9e0(%rsp)
  6e4749:	movaps %xmm1,0x9d0(%rsp)
  6e4751:	movdqa %xmm0,0x9c0(%rsp)
  6e475a:	cmpb   $0x7,0x20(%rsp)
  6e475f:	setne  %al
  6e4762:	lea    0x9c8(%rsp),%rsi
  6e476a:	mov    0x40(%rsp),%edi
  6e476e:	test   %dil,%al
  6e4771:	je     6e4791 <text_column_public_control::main+0x4e91>
  6e4773:	cmpq   $0x0,0x9c8(%rsp)
  6e477c:	jne    6e4b6d <text_column_public_control::main+0x526d>
  6e4782:	cmpq   $0x0,0x9c0(%rsp)
  6e478b:	jne    6e4b76 <text_column_public_control::main+0x5276>
  6e4791:	lea    0x0(,%r15,8),%eax
  6e4799:	lea    0x340178(%rip),%rcx        # a24918 <__frame_dummy_init_array_entry+0x2928>
  6e47a0:	mov    (%rax,%rcx,1),%rcx
  6e47a4:	lea    -0x693aa3(%rip),%rdx        # 50d08 <GCC_except_table0+0x10ec0>
  6e47ab:	mov    (%rax,%rdx,1),%rax
  6e47af:	mov    %rcx,0x160(%rsp)
  6e47b7:	mov    %rax,0x168(%rsp)
  6e47bf:	lea    0x9d0(%rsp),%rcx
  6e47c7:	lea    0xa10(%rsp),%rax
  6e47cf:	test   %dil,%dil
  6e47d2:	je     6e4824 <text_column_public_control::main+0x4f24>
  6e47d4:	lea    -0x697245(%rip),%rdx        # 4d596 <GCC_except_table0+0xd74e>
  6e47db:	mov    %rdx,0x178(%rsp)
  6e47e3:	movq   $0x5,0x180(%rsp)
  6e47ef:	mov    0x60(%rsp),%rdx
  6e47f4:	mov    %rdx,0x250(%rsp)
  6e47fc:	mov    0x50(%rsp),%rdx
  6e4801:	mov    %rdx,0x258(%rsp)
  6e4809:	cmpb   $0x6,0x20(%rsp)
  6e480e:	je     6e4867 <text_column_public_control::main+0x4f67>
  6e4810:	cmp    $0x7,%r15d
  6e4814:	jne    6e4875 <text_column_public_control::main+0x4f75>
  6e4816:	mov    $0xc,%edx
  6e481b:	lea    -0x6970a1(%rip),%rdi        # 4d781 <GCC_except_table0+0xd939>
  6e4822:	jmp    6e4881 <text_column_public_control::main+0x4f81>
  6e4824:	lea    -0x69729b(%rip),%rdx        # 4d590 <GCC_except_table0+0xd748>
  6e482b:	mov    %rdx,0x178(%rsp)
  6e4833:	movq   $0x6,0x180(%rsp)
  6e483f:	mov    0x60(%rsp),%rdx
  6e4844:	mov    %rdx,0x250(%rsp)
  6e484c:	mov    0x50(%rsp),%rdx
  6e4851:	mov    %rdx,0x258(%rsp)
  6e4859:	mov    $0xa,%edx
  6e485e:	lea    -0x6970ee(%rip),%rdi        # 4d777 <GCC_except_table0+0xd92f>
  6e4865:	jmp    6e4881 <text_column_public_control::main+0x4f81>
  6e4867:	mov    $0x1c,%edx
  6e486c:	lea    -0x6970e6(%rip),%rdi        # 4d78d <GCC_except_table0+0xd945>
  6e4873:	jmp    6e4881 <text_column_public_control::main+0x4f81>
  6e4875:	mov    $0xd,%edx
  6e487a:	lea    -0x6970d8(%rip),%rdi        # 4d7a9 <GCC_except_table0+0xd961>
  6e4881:	mov    %rdi,0xe0(%rsp)
  6e4889:	mov    %rdx,0xe8(%rsp)
  6e4891:	lea    0x160(%rsp),%rdx
  6e4899:	mov    %rdx,0x260(%rsp)
  6e48a1:	lea    0x42708(%rip),%rdx        # 726fb0 <<&str as core::fmt::Display>::fmt>
  6e48a8:	mov    %rdx,0x268(%rsp)
  6e48b0:	lea    0x178(%rsp),%rdi
  6e48b8:	mov    %rdi,0x270(%rsp)
  6e48c0:	mov    %rdx,0x278(%rsp)
  6e48c8:	lea    0x250(%rsp),%rdi
  6e48d0:	mov    %rdi,0x280(%rsp)
  6e48d8:	mov    0x35e171(%rip),%rdi        # a42a50 <_DYNAMIC+0x4b8>
  6e48df:	mov    %rdi,0x288(%rsp)
  6e48e7:	lea    0x258(%rsp),%r8
  6e48ef:	mov    %r8,0x290(%rsp)
  6e48f7:	mov    %rdi,0x298(%rsp)
  6e48ff:	lea    0x248(%rsp),%r8
  6e4907:	mov    %r8,0x2a0(%rsp)
  6e490f:	mov    %rdi,0x2a8(%rsp)
  6e4917:	mov    %rsi,0x2b0(%rsp)
  6e491f:	mov    0x35e132(%rip),%rsi        # a42a58 <_DYNAMIC+0x4c0>
  6e4926:	mov    %rsi,0x2b8(%rsp)
  6e492e:	lea    0x9c0(%rsp),%rdi
  6e4936:	mov    %rdi,0x2c0(%rsp)
  6e493e:	mov    %rsi,0x2c8(%rsp)
  6e4946:	mov    %rcx,0x2d0(%rsp)
  6e494e:	mov    %rsi,0x2d8(%rsp)
  6e4956:	mov    %rax,0x2e0(%rsp)
  6e495e:	mov    %rsi,0x2e8(%rsp)
  6e4966:	lea    0xe0(%rsp),%rax
  6e496e:	mov    %rax,0x2f0(%rsp)
  6e4976:	mov    %rdx,0x2f8(%rsp)
  6e497e:	lea    -0x6a16f5(%rip),%rdi        # 43290 <GCC_except_table0+0x3448>
  6e4985:	lea    0x260(%rsp),%rsi
  6e498d:	call   *0x35e0d5(%rip)        # a42a68 <_DYNAMIC+0x4d0>
  6e4993:	cmpb   $0x3,0x20(%rsp)
  6e4998:	jne    6e49fb <text_column_public_control::main+0x50fb>
  6e499a:	lea    0x260(%rsp),%rdi
  6e49a2:	lea    0x8(%rsp),%rsi
  6e49a7:	mov    $0x3,%edx
  6e49ac:	mov    0x10(%rsp),%ecx
  6e49b0:	xor    %r8d,%r8d
  6e49b3:	call   6ddac0 <text_column_public_control::edit>
  6e49b8:	lea    0x260(%rsp),%rax
  6e49c0:	lea    0x260(%rsp),%rdi
  6e49c8:	lea    0x8(%rsp),%rsi
  6e49cd:	mov    $0x1,%r8d
  6e49d3:	mov    $0x3,%edx
  6e49d8:	mov    0x10(%rsp),%ecx
  6e49dc:	call   6ddac0 <text_column_public_control::edit>
  6e49e1:	lea    0x260(%rsp),%rax
  6e49e9:	mov    0x8(%rsp),%rsi
  6e49ee:	lea    0x260(%rsp),%rdi
  6e49f6:	call   6b5fc0 <text_column_public_control::ack::<text_column_public_control::Model>>
  6e49fb:	mov    0x8(%rsp),%rdi
  6e4a00:	lea    -0x697251(%rip),%rcx        # 4d7b6 <GCC_except_table0+0xd96e>
  6e4a07:	mov    $0xc,%r8d
  6e4a0d:	mov    %r15d,%esi
  6e4a10:	mov    0x10(%rsp),%edx
  6e4a14:	call   6dbc70 <text_column_public_control::emit_state>
  6e4a19:	mov    0x190(%rsp),%rsi
  6e4a21:	test   %rsi,%rsi
  6e4a24:	je     6e4a38 <text_column_public_control::main+0x5138>
  6e4a26:	shl    $0x3,%rsi
  6e4a2a:	mov    $0x8,%edx
  6e4a2f:	mov    %r14,%rdi
  6e4a32:	call   *0x35ddc8(%rip)        # a42800 <_DYNAMIC+0x268>
  6e4a38:	mov    0xf8(%rsp),%rsi
  6e4a40:	test   %rsi,%rsi
  6e4a43:	je     6e4a57 <text_column_public_control::main+0x5157>
  6e4a45:	shl    $0x3,%rsi
  6e4a49:	mov    $0x8,%edx
  6e4a4e:	mov    %r13,%rdi
  6e4a51:	call   *0x35dda9(%rip)        # a42800 <_DYNAMIC+0x268>
  6e4a57:	mov    0x8(%rsp),%r14
  6e4a5c:	test   %r14,%r14
  6e4a5f:	je     6e4a7c <text_column_public_control::main+0x517c>
  6e4a61:	mov    %r14,%rdi
  6e4a64:	call   6c02e0 <core::ptr::drop_glue::<gpui::runtime::Runtime<text_column_public_control::Model>>>
  6e4a69:	mov    $0x790,%esi
  6e4a6e:	mov    $0x8,%edx
  6e4a73:	mov    %r14,%rdi
  6e4a76:	call   *0x35dd84(%rip)        # a42800 <_DYNAMIC+0x268>
  6e4a7c:	mov    0x218(%rsp),%rbx
  6e4a84:	mov    0x220(%rsp),%r14
  6e4a8c:	test   %r14,%r14
  6e4a8f:	je     6e4abf <text_column_public_control::main+0x51bf>
  6e4a91:	lea    0x8(%rbx),%r15
  6e4a95:	mov    0x35dd64(%rip),%r12        # a42800 <_DYNAMIC+0x268>
  6e4a9c:	jmp    6e4aa9 <text_column_public_control::main+0x51a9>
  6e4a9e:	xchg   %ax,%ax
  6e4aa0:	add    $0x18,%r15
  6e4aa4:	dec    %r14
  6e4aa7:	je     6e4abf <text_column_public_control::main+0x51bf>
  6e4aa9:	mov    -0x8(%r15),%rsi
  6e4aad:	test   %rsi,%rsi
  6e4ab0:	je     6e4aa0 <text_column_public_control::main+0x51a0>
  6e4ab2:	mov    (%r15),%rdi
  6e4ab5:	mov    $0x1,%edx
  6e4aba:	call   *%r12
  6e4abd:	jmp    6e4aa0 <text_column_public_control::main+0x51a0>
  6e4abf:	mov    0x210(%rsp),%rax
  6e4ac7:	test   %rax,%rax
  6e4aca:	je     6e4ae2 <text_column_public_control::main+0x51e2>
  6e4acc:	shl    $0x3,%rax
  6e4ad0:	lea    (%rax,%rax,2),%rsi
  6e4ad4:	mov    $0x8,%edx
  6e4ad9:	mov    %rbx,%rdi
  6e4adc:	call   *0x35dd1e(%rip)        # a42800 <_DYNAMIC+0x268>
  6e4ae2:	add    $0xe48,%rsp
  6e4ae9:	pop    %rbx
  6e4aea:	pop    %r12
  6e4aec:	pop    %r13
  6e4aee:	pop    %r14
  6e4af0:	pop    %r15
  6e4af2:	pop    %rbp
  6e4af3:	ret
  6e4af4:	xor    %eax,%eax
  6e4af6:	jmp    6e466f <text_column_public_control::main+0x4d6f>
  6e4afb:	xor    %ecx,%ecx
  6e4afd:	test   %cl,%cl
  6e4aff:	jne    6e468f <text_column_public_control::main+0x4d8f>
  6e4b05:	lea    0x33e68c(%rip),%rcx        # a23198 <__frame_dummy_init_array_entry+0x11a8>
  6e4b0c:	lea    0x1e0(%rsp),%rdx
  6e4b14:	xor    %edi,%edi
  6e4b16:	mov    %rbp,%rsi
  6e4b19:	call   6c88cd <core::panicking::assert_failed::<(usize, usize, u64), (usize, usize, u64)>>
  6e4b1e:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e4b23:	lea    0xf8(%rsp),%rdi
  6e4b2b:	lea    0x190(%rsp),%rsi
  6e4b33:	call   6c885c <core::panicking::assert_failed::<alloc::vec::Vec<usize>, alloc::vec::Vec<usize>>>
  6e4b38:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e4b3d:	lea    0x33e624(%rip),%rsi        # a23168 <__frame_dummy_init_array_entry+0x1178>
  6e4b44:	lea    0x260(%rsp),%rdi
  6e4b4c:	call   6c8824 <core::panicking::assert_failed::<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>, core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>>
  6e4b51:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e4b56:	lea    0x30(%rsp),%rdi
  6e4b5b:	lea    0x230(%rsp),%rsi
  6e4b63:	call   6c8894 <core::panicking::assert_failed::<gpui::runtime::PresentationToken, gpui::runtime::PresentationToken>>
  6e4b68:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e4b6d:	lea    0x33e654(%rip),%r9        # a231c8 <__frame_dummy_init_array_entry+0x11d8>
  6e4b74:	jmp    6e4b85 <text_column_public_control::main+0x5285>
  6e4b76:	lea    0x33e633(%rip),%r9        # a231b0 <__frame_dummy_init_array_entry+0x11c0>
  6e4b7d:	lea    0x9c0(%rsp),%rsi
  6e4b85:	lea    -0x6a32fc(%rip),%rdx        # 41890 <GCC_except_table0+0x1a48>
  6e4b8c:	xor    %edi,%edi
  6e4b8e:	xor    %ecx,%ecx
  6e4b90:	call   *0x35df7a(%rip)        # a42b10 <_DYNAMIC+0x578>
  6e4b96:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e4b9b:	lea    0x33e54e(%rip),%r9        # a230f0 <__frame_dummy_init_array_entry+0x1100>
  6e4ba2:	lea    -0x6a3319(%rip),%rdx        # 41890 <GCC_except_table0+0x1a48>
  6e4ba9:	lea    0x248(%rsp),%rsi
  6e4bb1:	xor    %edi,%edi
  6e4bb3:	xor    %ecx,%ecx
  6e4bb5:	call   *0x35deb5(%rip)        # a42a70 <_DYNAMIC+0x4d8>
  6e4bbb:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e4bc0:	lea    0x33e5b9(%rip),%rsi        # a23180 <__frame_dummy_init_array_entry+0x1190>
  6e4bc7:	lea    0x260(%rsp),%rdi
  6e4bcf:	call   6c8824 <core::panicking::assert_failed::<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>, core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>>
  6e4bd4:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e4bd9:	mov    $0xd,%eax
  6e4bde:	jmp    6e4bec <text_column_public_control::main+0x52ec>
  6e4be0:	mov    $0xe,%eax
  6e4be5:	jmp    6e4bec <text_column_public_control::main+0x52ec>
  6e4be7:	mov    $0x14,%eax
  6e4bec:	mov    %rax,0x260(%rsp)
  6e4bf4:	movq   $0x0,0x268(%rsp)
  6e4c00:	lea    -0x697430(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6e4c07:	lea    0x33e61a(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6e4c0e:	lea    0x33e50b(%rip),%r8        # a23120 <__frame_dummy_init_array_entry+0x1130>
  6e4c15:	lea    0x260(%rsp),%rdx
  6e4c1d:	mov    $0x2b,%esi
  6e4c22:	call   *0x35dbb0(%rip)        # a427d8 <_DYNAMIC+0x240>
  6e4c28:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e4c2d:	mov    $0xd,%eax
  6e4c32:	jmp    6e4c40 <text_column_public_control::main+0x5340>
  6e4c34:	mov    $0xe,%eax
  6e4c39:	jmp    6e4c40 <text_column_public_control::main+0x5340>
  6e4c3b:	mov    $0x14,%eax
  6e4c40:	mov    %rax,0x260(%rsp)
  6e4c48:	movq   $0x0,0x268(%rsp)
  6e4c54:	lea    -0x697484(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6e4c5b:	lea    0x33e5c6(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6e4c62:	lea    0x33e4e7(%rip),%r8        # a23150 <__frame_dummy_init_array_entry+0x1160>
  6e4c69:	lea    0x260(%rsp),%rdx
  6e4c71:	mov    $0x2b,%esi
  6e4c76:	call   *0x35db5c(%rip)        # a427d8 <_DYNAMIC+0x240>
  6e4c7c:	jmp    6e4cbe <text_column_public_control::main+0x53be>
  6e4c7e:	movq   $0xd,0x260(%rsp)
  6e4c8a:	movq   $0x0,0x268(%rsp)
  6e4c96:	lea    -0x6975b6(%rip),%rdi        # 4d6e7 <GCC_except_table0+0xd89f>
  6e4c9d:	lea    0x33e584(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6e4ca4:	lea    0x33e2c5(%rip),%r8        # a22f70 <__frame_dummy_init_array_entry+0xf80>
  6e4cab:	lea    0x260(%rsp),%rdx
  6e4cb3:	mov    $0x24,%esi
  6e4cb8:	call   *0x35db1a(%rip)        # a427d8 <_DYNAMIC+0x240>
  6e4cbe:	ud2
  6e4cc0:	mov    %rax,%rbx
  6e4cc3:	mov    $0x790,%esi
  6e4cc8:	jmp    6e4197 <text_column_public_control::main+0x4897>
  6e4ccd:	jmp    6e4cd1 <text_column_public_control::main+0x53d1>
  6e4ccf:	jmp    6e4cd1 <text_column_public_control::main+0x53d1>
  6e4cd1:	mov    %rax,%rbx
  6e4cd4:	lea    0x260(%rsp),%rdi
  6e4cdc:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e4ce1:	jmp    6e4cfa <text_column_public_control::main+0x53fa>
  6e4ce3:	jmp    6e4ce5 <text_column_public_control::main+0x53e5>
  6e4ce5:	mov    %rax,%rbx
  6e4ce8:	lea    0x260(%rsp),%rdi
  6e4cf0:	call   6bfab0 <core::ptr::drop_glue::<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>>
  6e4cf5:	jmp    6e4cfa <text_column_public_control::main+0x53fa>
  6e4cf7:	mov    %rax,%rbx
  6e4cfa:	mov    0x190(%rsp),%rsi
  6e4d02:	test   %rsi,%rsi
  6e4d05:	je     6e4d19 <text_column_public_control::main+0x5419>
  6e4d07:	shl    $0x3,%rsi
  6e4d0b:	mov    $0x8,%edx
  6e4d10:	mov    %r14,%rdi
  6e4d13:	call   *0x35dae7(%rip)        # a42800 <_DYNAMIC+0x268>
  6e4d19:	mov    0xf8(%rsp),%rsi
  6e4d21:	test   %rsi,%rsi
  6e4d24:	je     6e4d3d <text_column_public_control::main+0x543d>
  6e4d26:	mov    0x100(%rsp),%rdi
  6e4d2e:	shl    $0x3,%rsi
  6e4d32:	mov    $0x8,%edx
  6e4d37:	call   *0x35dac3(%rip)        # a42800 <_DYNAMIC+0x268>
  6e4d3d:	mov    0x8(%rsp),%rdi
  6e4d42:	call   6bfcd0 <core::ptr::drop_glue::<gpui::runtime::Win<text_column_public_control::Model>>>
  6e4d47:	lea    0x210(%rsp),%rdi
  6e4d4f:	call   6c0fb0 <core::ptr::drop_glue::<alloc::vec::Vec<alloc::string::String>>>
  6e4d54:	mov    %rbx,%rdi
  6e4d57:	call   a20c40 <_Unwind_Resume@plt>
  6e4d5c:	call   *0x35dac6(%rip)        # a42828 <_DYNAMIC+0x290>

text_column_public_control::mount code=2251 fixed_stack=3416

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006e4d70 <text_column_public_control::mount>:
  6e4d70:	push   %rbp
  6e4d71:	push   %r15
  6e4d73:	push   %r14
  6e4d75:	push   %r13
  6e4d77:	push   %r12
  6e4d79:	push   %rbx
  6e4d7a:	sub    $0xd28,%rsp
  6e4d81:	mov    %edx,%r13d
  6e4d84:	mov    %esi,%ebp
  6e4d86:	mov    %rdi,%rbx
  6e4d89:	call   *0x35da79(%rip)        # a42808 <_DYNAMIC+0x270>
  6e4d8f:	mov    $0x1,%r15d
  6e4d95:	mov    $0x13,%edi
  6e4d9a:	mov    $0x1,%esi
  6e4d9f:	call   *0x35da6b(%rip)        # a42810 <_DYNAMIC+0x278>
  6e4da5:	test   %rax,%rax
  6e4da8:	je     6e540a <text_column_public_control::mount+0x69a>
  6e4dae:	movups -0x69781a(%rip),%xmm0        # 4d59b <GCC_except_table0+0xd753>
  6e4db5:	cmp    $0x1,%bpl
  6e4db9:	mov    $0x20,%ecx
  6e4dbe:	mov    $0x8000,%r12d
  6e4dc4:	cmove  %rcx,%r12
  6e4dc8:	movups %xmm0,(%rax)
  6e4dcb:	test   %bpl,%bpl
  6e4dce:	cmove  %r15,%r12
  6e4dd2:	mov    %rax,0x10(%rsp)
  6e4dd7:	movl   $0x92d791d7,0xf(%rax)
  6e4dde:	movups -0x697599(%rip),%xmm0        # 4d84c <GCC_except_table0+0xda04>
  6e4de5:	movups %xmm0,0xf8(%rsp)
  6e4ded:	movq   $0x0,0x108(%rsp)
  6e4df9:	lea    0x110(%rsp),%rdi
  6e4e01:	movabs $0x19000000190,%rsi
  6e4e0b:	movss  -0x6a4f6b(%rip),%xmm0        # 3fea8 <GCC_except_table0+0x60>
  6e4e13:	call   *0x35dc7f(%rip)        # a42a98 <_DYNAMIC+0x500>
  6e4e19:	mov    0x110(%rsp),%r15
  6e4e21:	cmp    $0xfffffffffffffffe,%r15
  6e4e25:	jne    6e541a <text_column_public_control::mount+0x6aa>
  6e4e2b:	mov    %rbx,0x20(%rsp)
  6e4e30:	lea    0x110(%rsp),%rdi
  6e4e38:	call   7253f0 <<text_column_public_control::Model as gpui::View>::sources>
  6e4e3d:	mov    %r13d,%ebx
  6e4e40:	mov    0x110(%rsp),%rax
  6e4e48:	movups 0x168(%rsp),%xmm0
  6e4e50:	movaps %xmm0,0x8e0(%rsp)
  6e4e58:	movups 0x158(%rsp),%xmm0
  6e4e60:	movaps %xmm0,0x8d0(%rsp)
  6e4e68:	movups 0x148(%rsp),%xmm0
  6e4e70:	movaps %xmm0,0x8c0(%rsp)
  6e4e78:	movups 0x138(%rsp),%xmm0
  6e4e80:	movaps %xmm0,0x8b0(%rsp)
  6e4e88:	movups 0x128(%rsp),%xmm1
  6e4e90:	movaps %xmm1,0x8a0(%rsp)
  6e4e98:	movups 0x118(%rsp),%xmm2
  6e4ea0:	movups %xmm1,0xa0(%rsp)
  6e4ea8:	movups %xmm0,0xb0(%rsp)
  6e4eb0:	mov    0x8c0(%rsp),%rcx
  6e4eb8:	mov    %rcx,0xc0(%rsp)
  6e4ec0:	mov    0x8e8(%rsp),%rcx
  6e4ec8:	mov    %rcx,0xe8(%rsp)
  6e4ed0:	movups 0x8d8(%rsp),%xmm0
  6e4ed8:	movups %xmm0,0xd8(%rsp)
  6e4ee0:	movups 0x8c8(%rsp),%xmm0
  6e4ee8:	movups %xmm0,0xc8(%rsp)
  6e4ef0:	mov    %rax,0x88(%rsp)
  6e4ef8:	movups %xmm2,0x90(%rsp)
  6e4f00:	movl   $0x0,0x8a0(%rsp)
  6e4f0b:	movl   $0x434b0000,0x8a8(%rsp)
  6e4f16:	movw   $0x0,0x8ac(%rsp)
  6e4f20:	lea    0x110(%rsp),%rdi
  6e4f28:	lea    0x8a0(%rsp),%rcx
  6e4f30:	mov    $0x190,%esi
  6e4f35:	mov    $0x190,%edx
  6e4f3a:	call   *0x35db68(%rip)        # a42aa8 <_DYNAMIC+0x510>
  6e4f40:	mov    0x110(%rsp),%r15
  6e4f48:	mov    0x118(%rsp),%r14d
  6e4f50:	mov    0x11c(%rsp),%r13d
  6e4f58:	cmp    $0x2,%r15
  6e4f5c:	je     6e5463 <text_column_public_control::mount+0x6f3>
  6e4f62:	lea    0x120(%rsp),%rsi
  6e4f6a:	lea    0xb50(%rsp),%rdi
  6e4f72:	mov    $0x1d8,%edx
  6e4f77:	call   *0x35d8a3(%rip)        # a42820 <memcpy@GLIBC_2.14>
  6e4f7d:	mov    %r15,0xb40(%rsp)
  6e4f85:	mov    %r14d,0xb48(%rsp)
  6e4f8d:	mov    %r13d,0xb4c(%rsp)
  6e4f95:	call   *0x35db15(%rip)        # a42ab0 <_DYNAMIC+0x518>
  6e4f9b:	mov    %rax,%r13
  6e4f9e:	lea    0x8a0(%rsp),%rdi
  6e4fa6:	call   *0x35db0c(%rip)        # a42ab8 <_DYNAMIC+0x520>
  6e4fac:	movq   $0x13,0x3b0(%rsp)
  6e4fb8:	movl   $0x0,0x3b8(%rsp)
  6e4fc3:	mov    %r12,0x3c0(%rsp)
  6e4fcb:	movabs $0x4000000000000000,%rax
  6e4fd5:	mov    %rax,0x3c8(%rsp)
  6e4fdd:	movb   $0x0,0x3d0(%rsp)
  6e4fe5:	movl   $0x0,0x3d8(%rsp)
  6e4ff0:	mov    %rax,0x3e0(%rsp)
  6e4ff8:	movl   $0x0,0x3e8(%rsp)
  6e5003:	movups 0xf4(%rsp),%xmm0
  6e500b:	movups 0x100(%rsp),%xmm1
  6e5013:	movups %xmm0,0x3ec(%rsp)
  6e501b:	movups %xmm1,0x3f8(%rsp)
  6e5023:	movl   $0x0,0x408(%rsp)
  6e502e:	mov    %bl,0x40c(%rsp)
  6e5035:	mov    %bpl,0x40d(%rsp)
  6e503d:	movups 0x88(%rsp),%xmm0
  6e5045:	movups 0x98(%rsp),%xmm1
  6e504d:	movups 0xa8(%rsp),%xmm2
  6e5055:	movups 0xb8(%rsp),%xmm3
  6e505d:	movups %xmm0,0x338(%rsp)
  6e5065:	movups %xmm1,0x348(%rsp)
  6e506d:	movups %xmm2,0x358(%rsp)
  6e5075:	movups %xmm3,0x368(%rsp)
  6e507d:	movups 0xc8(%rsp),%xmm0
  6e5085:	movups %xmm0,0x378(%rsp)
  6e508d:	movups 0xd8(%rsp),%xmm0
  6e5095:	movups %xmm0,0x388(%rsp)
  6e509d:	mov    0xe8(%rsp),%rax
  6e50a5:	mov    %rax,0x398(%rsp)
  6e50ad:	lea    0x440(%rsp),%rdi
  6e50b5:	lea    0x8a0(%rsp),%rsi
  6e50bd:	mov    0x35d75c(%rip),%r15        # a42820 <memcpy@GLIBC_2.14>
  6e50c4:	mov    $0x298,%edx
  6e50c9:	call   *%r15
  6e50cc:	lea    0x110(%rsp),%rdi
  6e50d4:	lea    0xb40(%rsp),%rsi
  6e50dc:	mov    $0x1e8,%edx
  6e50e1:	call   *%r15
  6e50e4:	movq   $0x13,0x3a0(%rsp)
  6e50f0:	mov    0x10(%rsp),%rax
  6e50f5:	mov    %rax,0x3a8(%rsp)
  6e50fd:	movq   $0x0,0x410(%rsp)
  6e5109:	movq   $0x8,0x418(%rsp)
  6e5115:	xorps  %xmm0,%xmm0
  6e5118:	movups %xmm0,0x420(%rsp)
  6e5120:	movq   $0x8,0x430(%rsp)
  6e512c:	movq   $0x0,0x438(%rsp)
  6e5138:	movq   $0x0,0x758(%rsp)
  6e5144:	movups %xmm0,0x2f8(%rsp)
  6e514c:	movups %xmm0,0x308(%rsp)
  6e5154:	movups %xmm0,0x740(%rsp)
  6e515c:	movq   $0x1,0x760(%rsp)
  6e5168:	movq   $0x0,0x768(%rsp)
  6e5174:	mov    %r13,0x730(%rsp)
  6e517c:	movq   $0x0,0x778(%rsp)
  6e5188:	movq   $0x0,0x7c0(%rsp)
  6e5194:	movups %xmm0,0x788(%rsp)
  6e519c:	movq   $0x0,0x798(%rsp)
  6e51a8:	movups %xmm0,0x7a8(%rsp)
  6e51b0:	movq   $0x0,0x6d8(%rsp)
  6e51bc:	movq   $0x8,0x6e0(%rsp)
  6e51c8:	movups %xmm0,0x6e8(%rsp)
  6e51d0:	movq   $0x0,0x7c8(%rsp)
  6e51dc:	movq   $0x0,0x7d8(%rsp)
  6e51e8:	movl   $0x1000101,0x898(%rsp)
  6e51f3:	movw   $0x0,0x89c(%rsp)
  6e51fd:	movups %xmm0,0x7e0(%rsp)
  6e5205:	movq   $0x0,0x7f0(%rsp)
  6e5211:	movabs $0x19000000190,%rax
  6e521b:	mov    %rax,0x7f8(%rsp)
  6e5223:	movsd  -0x6a47fb(%rip),%xmm1        # 40a30 <GCC_except_table0+0xbe8>
  6e522b:	movsd  %xmm1,0x890(%rsp)
  6e5234:	movq   $0x1,0x738(%rsp)
  6e5240:	movq   $0xffffffffffffffff,0x708(%rsp)
  6e524c:	movq   $0x0,0x800(%rsp)
  6e5258:	movq   $0x0,0x810(%rsp)
  6e5264:	movq   $0x8,0x6f8(%rsp)
  6e5270:	movq   $0x0,0x700(%rsp)
  6e527c:	movb   $0x0,0x89e(%rsp)
  6e5284:	movups %xmm0,0x878(%rsp)
  6e528c:	movups %xmm0,0x868(%rsp)
  6e5294:	movups %xmm0,0x858(%rsp)
  6e529c:	movups %xmm0,0x848(%rsp)
  6e52a4:	movups %xmm0,0x838(%rsp)
  6e52ac:	movups %xmm0,0x828(%rsp)
  6e52b4:	movups %xmm0,0x818(%rsp)
  6e52bc:	movq   $0x0,0x888(%rsp)
  6e52c8:	call   *0x35d53a(%rip)        # a42808 <_DYNAMIC+0x270>
  6e52ce:	mov    $0x790,%edi
  6e52d3:	mov    $0x8,%esi
  6e52d8:	call   *0x35d532(%rip)        # a42810 <_DYNAMIC+0x278>
  6e52de:	test   %rax,%rax
  6e52e1:	je     6e5396 <text_column_public_control::mount+0x626>
  6e52e7:	mov    %rax,%rbx
  6e52ea:	lea    0x110(%rsp),%rsi
  6e52f2:	mov    $0x790,%edx
  6e52f7:	mov    %rax,%rdi
  6e52fa:	call   *0x35d520(%rip)        # a42820 <memcpy@GLIBC_2.14>
  6e5300:	mov    %rbx,0x18(%rsp)
  6e5305:	lea    0x20(%rsp),%rdx
  6e530a:	lea    0x38(%rsp),%rdi
  6e530f:	mov    %rbx,%rsi
  6e5312:	mov    $0x1,%ecx
  6e5317:	call   6e8f60 <<gpui::runtime::RuntimeMut<text_column_public_control::Model, ()>>::describe_with_changed>
  6e531c:	mov    0x38(%rsp),%r15
  6e5321:	cmp    $0xfffffffffffffffe,%r15
  6e5325:	jne    6e53ab <text_column_public_control::mount+0x63b>
  6e532b:	lea    0x38(%rsp),%rdi
  6e5330:	mov    %rbx,%rsi
  6e5333:	call   71d230 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present>
  6e5338:	mov    0x38(%rsp),%r15
  6e533d:	cmp    $0xfffffffffffffffe,%r15
  6e5341:	jne    6e53ab <text_column_public_control::mount+0x63b>
  6e5343:	mov    0x18(%rsp),%rbx
  6e5348:	lea    0x110(%rsp),%rdi
  6e5350:	mov    %rbx,%rsi
  6e5353:	call   6b5fc0 <text_column_public_control::ack::<text_column_public_control::Model>>
  6e5358:	mov    0x20(%rsp),%rax
  6e535d:	mov    %rbx,(%rax)
  6e5360:	movups 0x110(%rsp),%xmm0
  6e5368:	movups 0x120(%rsp),%xmm1
  6e5370:	movups 0x130(%rsp),%xmm2
  6e5378:	movups %xmm0,0x8(%rax)
  6e537c:	movups %xmm1,0x18(%rax)
  6e5380:	movups %xmm2,0x28(%rax)
  6e5384:	add    $0xd28,%rsp
  6e538b:	pop    %rbx
  6e538c:	pop    %r12
  6e538e:	pop    %r13
  6e5390:	pop    %r14
  6e5392:	pop    %r15
  6e5394:	pop    %rbp
  6e5395:	ret
  6e5396:	mov    $0x8,%edi
  6e539b:	mov    $0x790,%esi
  6e53a0:	call   *0x35d472(%rip)        # a42818 <_DYNAMIC+0x280>
  6e53a6:	jmp    6e5505 <text_column_public_control::mount+0x795>
  6e53ab:	mov    0x40(%rsp),%r14
  6e53b0:	movups 0x48(%rsp),%xmm0
  6e53b5:	movaps %xmm0,0x20(%rsp)
  6e53ba:	movups 0x58(%rsp),%xmm0
  6e53bf:	movaps %xmm0,0x70(%rsp)
  6e53c4:	movzbl 0x68(%rsp),%ebp
  6e53c9:	mov    0x69(%rsp),%eax
  6e53cd:	mov    %eax,0x8(%rsp)
  6e53d1:	mov    0x6c(%rsp),%eax
  6e53d5:	mov    %eax,0xb(%rsp)
  6e53d9:	mov    0x18(%rsp),%rbx
  6e53de:	test   %rbx,%rbx
  6e53e1:	je     6e53fe <text_column_public_control::mount+0x68e>
  6e53e3:	mov    %rbx,%rdi
  6e53e6:	call   6c02e0 <core::ptr::drop_glue::<gpui::runtime::Runtime<text_column_public_control::Model>>>
  6e53eb:	mov    $0x790,%esi
  6e53f0:	mov    $0x8,%edx
  6e53f5:	mov    %rbx,%rdi
  6e53f8:	call   *0x35d402(%rip)        # a42800 <_DYNAMIC+0x268>
  6e53fe:	mov    %r14,%r13
  6e5401:	shr    $0x20,%r13
  6e5405:	jmp    6e548b <text_column_public_control::mount+0x71b>
  6e540a:	mov    $0x1,%edi
  6e540f:	mov    $0x13,%esi
  6e5414:	call   *0x35d476(%rip)        # a42890 <_DYNAMIC+0x2f8>
  6e541a:	mov    0x118(%rsp),%r13
  6e5422:	mov    %r13,%r14
  6e5425:	shr    $0x20,%r13
  6e5429:	movups 0x120(%rsp),%xmm0
  6e5431:	movaps %xmm0,0x20(%rsp)
  6e5436:	movups 0x130(%rsp),%xmm0
  6e543e:	movaps %xmm0,0x70(%rsp)
  6e5443:	movzbl 0x140(%rsp),%ebp
  6e544b:	mov    0x141(%rsp),%eax
  6e5452:	mov    %eax,0x8(%rsp)
  6e5456:	mov    0x144(%rsp),%eax
  6e545d:	mov    %eax,0xb(%rsp)
  6e5461:	jmp    6e5476 <text_column_public_control::mount+0x706>
  6e5463:	lea    0x88(%rsp),%rdi
  6e546b:	call   6bfb20 <core::ptr::drop_glue::<gpui::source::Sources<text_column_public_control::Input>>>
  6e5470:	mov    $0x23,%r15d
  6e5476:	mov    $0x13,%esi
  6e547b:	mov    $0x1,%edx
  6e5480:	mov    0x10(%rsp),%rdi
  6e5485:	call   *0x35d375(%rip)        # a42800 <_DYNAMIC+0x268>
  6e548b:	mov    %r15,0x8a0(%rsp)
  6e5493:	shl    $0x20,%r13
  6e5497:	mov    %r14d,%eax
  6e549a:	or     %r13,%rax
  6e549d:	mov    %rax,0x8a8(%rsp)
  6e54a5:	movaps 0x20(%rsp),%xmm0
  6e54aa:	movups %xmm0,0x8b0(%rsp)
  6e54b2:	movaps 0x70(%rsp),%xmm0
  6e54b7:	movups %xmm0,0x8c0(%rsp)
  6e54bf:	mov    %bpl,0x8d0(%rsp)
  6e54c7:	mov    0x8(%rsp),%eax
  6e54cb:	mov    0xb(%rsp),%ecx
  6e54cf:	mov    %eax,0x8d1(%rsp)
  6e54d6:	mov    %ecx,0x8d4(%rsp)
  6e54dd:	lea    -0x697d0d(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6e54e4:	lea    0x33dd3d(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6e54eb:	lea    0x33d9ee(%rip),%r8        # a22ee0 <__frame_dummy_init_array_entry+0xef0>
  6e54f2:	lea    0x8a0(%rsp),%rdx
  6e54fa:	mov    $0x2b,%esi
  6e54ff:	call   *0x35d2d3(%rip)        # a427d8 <_DYNAMIC+0x240>
  6e5505:	ud2
  6e5507:	mov    %rax,%r14
  6e550a:	mov    $0x790,%esi
  6e550f:	mov    $0x8,%edx
  6e5514:	mov    %rbx,%rdi
  6e5517:	jmp    6e55f1 <text_column_public_control::mount+0x881>
  6e551c:	mov    %rax,%r14
  6e551f:	mov    %rbx,%rdi
  6e5522:	call   6bfcd0 <core::ptr::drop_glue::<gpui::runtime::Win<text_column_public_control::Model>>>
  6e5527:	jmp    6e562d <text_column_public_control::mount+0x8bd>
  6e552c:	call   *0x35d2f6(%rip)        # a42828 <_DYNAMIC+0x290>
  6e5532:	mov    %rax,%r14
  6e5535:	jmp    6e55d5 <text_column_public_control::mount+0x865>
  6e553a:	mov    %rax,%rdi
  6e553d:	call   *0x35d535(%rip)        # a42a78 <_DYNAMIC+0x4e0>
  6e5543:	mov    %rax,%r15
  6e5546:	mov    %rdx,%r12
  6e5549:	mov    (%rdx),%rax
  6e554c:	test   %rax,%rax
  6e554f:	je     6e5556 <text_column_public_control::mount+0x7e6>
  6e5551:	mov    %r15,%rdi
  6e5554:	call   *%rax
  6e5556:	mov    0x8(%r12),%rsi
  6e555b:	test   %rsi,%rsi
  6e555e:	je     6e556e <text_column_public_control::mount+0x7fe>
  6e5560:	mov    0x10(%r12),%rdx
  6e5565:	mov    %r15,%rdi
  6e5568:	call   *0x35d292(%rip)        # a42800 <_DYNAMIC+0x268>
  6e556e:	mov    $0x13,%esi
  6e5573:	mov    $0x1,%edx
  6e5578:	mov    0x10(%rsp),%rdi
  6e557d:	call   *0x35d27d(%rip)        # a42800 <_DYNAMIC+0x268>
  6e5583:	mov    $0xf,%r15d
  6e5589:	jmp    6e548b <text_column_public_control::mount+0x71b>
  6e558e:	mov    %rax,%r14
  6e5591:	mov    0x8(%r12),%rsi
  6e5596:	test   %rsi,%rsi
  6e5599:	je     6e55e2 <text_column_public_control::mount+0x872>
  6e559b:	mov    0x10(%r12),%rdx
  6e55a0:	mov    %r15,%rdi
  6e55a3:	call   *0x35d257(%rip)        # a42800 <_DYNAMIC+0x268>
  6e55a9:	jmp    6e55e2 <text_column_public_control::mount+0x872>
  6e55ab:	call   *0x35d4cf(%rip)        # a42a80 <_DYNAMIC+0x4e8>
  6e55b1:	mov    %rax,%r14
  6e55b4:	jmp    6e55e2 <text_column_public_control::mount+0x872>
  6e55b6:	mov    %rax,%r14
  6e55b9:	mov    0x18(%rsp),%rdi
  6e55be:	call   6bfcd0 <core::ptr::drop_glue::<gpui::runtime::Win<text_column_public_control::Model>>>
  6e55c3:	jmp    6e562d <text_column_public_control::mount+0x8bd>
  6e55c5:	mov    %rax,%r14
  6e55c8:	lea    0xb40(%rsp),%rdi
  6e55d0:	call   6c6240 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  6e55d5:	lea    0x88(%rsp),%rdi
  6e55dd:	call   6bfb20 <core::ptr::drop_glue::<gpui::source::Sources<text_column_public_control::Input>>>
  6e55e2:	mov    $0x13,%esi
  6e55e7:	mov    $0x1,%edx
  6e55ec:	mov    0x10(%rsp),%rdi
  6e55f1:	call   *0x35d209(%rip)        # a42800 <_DYNAMIC+0x268>
  6e55f7:	mov    %r14,%rdi
  6e55fa:	call   a20c40 <_Unwind_Resume@plt>
  6e55ff:	call   *0x35d223(%rip)        # a42828 <_DYNAMIC+0x290>
  6e5605:	mov    %rax,%r14
  6e5608:	lea    0x8a0(%rsp),%rdi
  6e5610:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e5615:	mov    %r14,%rdi
  6e5618:	call   a20c40 <_Unwind_Resume@plt>
  6e561d:	mov    %rax,%r14
  6e5620:	lea    0x110(%rsp),%rdi
  6e5628:	call   6c02e0 <core::ptr::drop_glue::<gpui::runtime::Runtime<text_column_public_control::Model>>>
  6e562d:	mov    %r14,%rdi
  6e5630:	call   a20c40 <_Unwind_Resume@plt>
  6e5635:	call   *0x35d1ed(%rip)        # a42828 <_DYNAMIC+0x290>

text_column_public_control::pointers code=722 fixed_stack=296

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006e5640 <text_column_public_control::pointers>:
  6e5640:	push   %rbp
  6e5641:	push   %r15
  6e5643:	push   %r14
  6e5645:	push   %r13
  6e5647:	push   %r12
  6e5649:	push   %rbx
  6e564a:	sub    $0xf8,%rsp
  6e5651:	movq   $0x0,0x10(%rsp)
  6e565a:	movq   $0x8,0x18(%rsp)
  6e5663:	movq   $0x0,0x20(%rsp)
  6e566c:	test   %rsi,%rsi
  6e566f:	je     6e5884 <text_column_public_control::pointers+0x244>
  6e5675:	mov    %rsi,%r14
  6e5678:	cmpb   $0x0,0x78e(%rsi)
  6e567f:	jne    6e588b <text_column_public_control::pointers+0x24b>
  6e5685:	cmpb   $0x1,0x78c(%r14)
  6e568d:	jne    6e5892 <text_column_public_control::pointers+0x252>
  6e5693:	mov    0x708(%r14),%r12
  6e569a:	mov    0x6e0(%r14),%r13
  6e56a1:	mov    0x5e8(%r14),%r15
  6e56a8:	mov    0x5f0(%r14),%rbp
  6e56af:	movups 0x658(%r14),%xmm1
  6e56b7:	mov    0x680(%r14),%rbx
  6e56be:	test   %rbx,%rbx
  6e56c1:	mov    %rdi,0x48(%rsp)
  6e56c6:	je     6e5707 <text_column_public_control::pointers+0xc7>
  6e56c8:	mov    0xe0(%rbx),%rax
  6e56cf:	test   %rax,%rax
  6e56d2:	je     6e571d <text_column_public_control::pointers+0xdd>
  6e56d4:	mov    0x38(%rax),%ecx
  6e56d7:	mov    %ecx,0x60(%rsp)
  6e56db:	movups 0x28(%rax),%xmm0
  6e56df:	movaps %xmm0,0x50(%rsp)
  6e56e4:	movzbl 0x3c(%rax),%edi
  6e56e8:	movzbl 0x3f(%rax),%ecx
  6e56ec:	mov    %cl,0xe(%rsp)
  6e56f0:	movzwl 0x3d(%rax),%eax
  6e56f4:	mov    %ax,0xc(%rsp)
  6e56f9:	mov    0x100(%rbx),%rsi
  6e5700:	test   %rsi,%rsi
  6e5703:	jne    6e572c <text_column_public_control::pointers+0xec>
  6e5705:	jmp    6e570a <text_column_public_control::pointers+0xca>
  6e5707:	mov    $0x2,%dil
  6e570a:	movq   $0x4,0x28(%rsp)
  6e5713:	xorps  %xmm0,%xmm0
  6e5716:	movups %xmm0,0x30(%rsp)
  6e571b:	jmp    6e5751 <text_column_public_control::pointers+0x111>
  6e571d:	mov    $0x2,%dil
  6e5720:	mov    0x100(%rbx),%rsi
  6e5727:	test   %rsi,%rsi
  6e572a:	je     6e570a <text_column_public_control::pointers+0xca>
  6e572c:	mov    %dil,0xb(%rsp)
  6e5731:	lea    0x28(%rsp),%rdi
  6e5736:	movaps %xmm1,0xe0(%rsp)
  6e573e:	call   *0x35d09c(%rip)        # a427e0 <_DYNAMIC+0x248>
  6e5744:	movzbl 0xb(%rsp),%edi
  6e5749:	movaps 0xe0(%rsp),%xmm1
  6e5751:	add    $0x620,%r14
  6e5758:	mov    %r14,0xc0(%rsp)
  6e5760:	mov    %r12,0x90(%rsp)
  6e5768:	mov    %r13,0x98(%rsp)
  6e5770:	mov    %r15,0x80(%rsp)
  6e5778:	mov    %rbp,0x88(%rsp)
  6e5780:	movaps %xmm1,0x70(%rsp)
  6e5785:	mov    %rbx,0xa0(%rsp)
  6e578d:	mov    0x28(%rsp),%rax
  6e5792:	mov    %rax,0xa8(%rsp)
  6e579a:	mov    0x30(%rsp),%rax
  6e579f:	mov    %rax,0xb0(%rsp)
  6e57a7:	mov    0x38(%rsp),%rax
  6e57ac:	mov    %rax,0xb8(%rsp)
  6e57b4:	movaps 0x50(%rsp),%xmm0
  6e57b9:	movups %xmm0,0xc8(%rsp)
  6e57c1:	mov    0x60(%rsp),%eax
  6e57c5:	mov    %eax,0xd8(%rsp)
  6e57cc:	mov    %dil,0xdc(%rsp)
  6e57d4:	movzwl 0xc(%rsp),%eax
  6e57d9:	mov    %ax,0xdd(%rsp)
  6e57e1:	movzbl 0xe(%rsp),%eax
  6e57e6:	mov    %al,0xdf(%rsp)
  6e57ed:	test   %rbp,%rbp
  6e57f0:	je     6e585c <text_column_public_control::pointers+0x21c>
  6e57f2:	xor    %r14d,%r14d
  6e57f5:	lea    0x70(%rsp),%r12
  6e57fa:	mov    0x35cfef(%rip),%rbx        # a427f0 <_DYNAMIC+0x258>
  6e5801:	jmp    6e5829 <text_column_public_control::pointers+0x1e9>
  6e5803:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6e5810:	mov    0x18(%rsp),%rax
  6e5815:	mov    %r15,(%rax,%r13,8)
  6e5819:	inc    %r13
  6e581c:	mov    %r13,0x20(%rsp)
  6e5821:	inc    %r14
  6e5824:	cmp    %r14,%rbp
  6e5827:	je     6e585c <text_column_public_control::pointers+0x21c>
  6e5829:	lea    0x28(%rsp),%rdi
  6e582e:	mov    %r12,%rsi
  6e5831:	mov    %r14,%rdx
  6e5834:	call   *%rbx
  6e5836:	cmpq   $0x0,0x28(%rsp)
  6e583c:	je     6e5821 <text_column_public_control::pointers+0x1e1>
  6e583e:	mov    0x38(%rsp),%r15
  6e5843:	mov    0x20(%rsp),%r13
  6e5848:	cmp    0x10(%rsp),%r13
  6e584d:	jne    6e5810 <text_column_public_control::pointers+0x1d0>
  6e584f:	lea    0x10(%rsp),%rdi
  6e5854:	call   *0x35d2c6(%rip)        # a42b20 <_DYNAMIC+0x588>
  6e585a:	jmp    6e5810 <text_column_public_control::pointers+0x1d0>
  6e585c:	mov    0x20(%rsp),%rax
  6e5861:	mov    0x48(%rsp),%rcx
  6e5866:	mov    %rax,0x10(%rcx)
  6e586a:	movups 0x10(%rsp),%xmm0
  6e586f:	movups %xmm0,(%rcx)
  6e5872:	add    $0xf8,%rsp
  6e5879:	pop    %rbx
  6e587a:	pop    %r12
  6e587c:	pop    %r13
  6e587e:	pop    %r14
  6e5880:	pop    %r15
  6e5882:	pop    %rbp
  6e5883:	ret
  6e5884:	mov    $0xd,%eax
  6e5889:	jmp    6e5897 <text_column_public_control::pointers+0x257>
  6e588b:	mov    $0xe,%eax
  6e5890:	jmp    6e5897 <text_column_public_control::pointers+0x257>
  6e5892:	mov    $0x12,%eax
  6e5897:	mov    %rax,0x70(%rsp)
  6e589c:	movq   $0x0,0x78(%rsp)
  6e58a5:	lea    -0x6980d5(%rip),%rdi        # 4d7d7 <GCC_except_table0+0xd98f>
  6e58ac:	lea    0x33d975(%rip),%rcx        # a23228 <__frame_dummy_init_array_entry+0x1238>
  6e58b3:	lea    0x33d716(%rip),%r8        # a22fd0 <__frame_dummy_init_array_entry+0xfe0>
  6e58ba:	lea    0x70(%rsp),%rdx
  6e58bf:	mov    $0x2b,%esi
  6e58c4:	call   *0x35cf0e(%rip)        # a427d8 <_DYNAMIC+0x240>
  6e58ca:	ud2
  6e58cc:	mov    %rax,%rbx
  6e58cf:	lea    0x70(%rsp),%rdi
  6e58d4:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e58d9:	mov    %rbx,%rdi
  6e58dc:	call   a20c40 <_Unwind_Resume@plt>
  6e58e1:	mov    %rax,%rbx
  6e58e4:	mov    0x10(%rsp),%rsi
  6e58e9:	test   %rsi,%rsi
  6e58ec:	jne    6e58f6 <text_column_public_control::pointers+0x2b6>
  6e58ee:	mov    %rbx,%rdi
  6e58f1:	call   a20c40 <_Unwind_Resume@plt>
  6e58f6:	mov    0x18(%rsp),%rdi
  6e58fb:	shl    $0x3,%rsi
  6e58ff:	mov    $0x8,%edx
  6e5904:	call   *0x35cef6(%rip)        # a42800 <_DYNAMIC+0x268>
  6e590a:	mov    %rbx,%rdi
  6e590d:	call   a20c40 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<text_column_public_control::Input>>::pointer_hit code=93 fixed_stack=8

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006f07e0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::pointer_hit>:
  6f07e0:	cmpl   $0x1,(%rsi)
  6f07e3:	jne    6f0815 <<gpui::runtime::Runtime<text_column_public_control::Input>>::pointer_hit+0x35>
  6f07e5:	push   %rbx
  6f07e6:	movss  0x4(%rsi),%xmm0
  6f07eb:	movss  0x8(%rsi),%xmm1
  6f07f0:	mov    0x640(%rdi),%rax
  6f07f7:	test   %rax,%rax
  6f07fa:	je     6f0818 <<gpui::runtime::Runtime<text_column_public_control::Input>>::pointer_hit+0x38>
  6f07fc:	mov    0xd8(%rax),%rax
  6f0803:	test   %rax,%rax
  6f0806:	je     6f0818 <<gpui::runtime::Runtime<text_column_public_control::Input>>::pointer_hit+0x38>
  6f0808:	cmpb   $0x0,0x12(%rax)
  6f080c:	je     6f0818 <<gpui::runtime::Runtime<text_column_public_control::Input>>::pointer_hit+0x38>
  6f080e:	call   6f1ac0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::inspector_pick>
  6f0813:	pop    %rbx
  6f0814:	ret
  6f0815:	xor    %eax,%eax
  6f0817:	ret
  6f0818:	mov    %rdi,%rbx
  6f081b:	call   70cfe0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit>
  6f0820:	test   $0x1,%al
  6f0822:	je     6f0839 <<gpui::runtime::Runtime<text_column_public_control::Input>>::pointer_hit+0x59>
  6f0824:	mov    %rbx,%rdi
  6f0827:	add    $0x5e0,%rdi
  6f082e:	mov    %rdx,%rsi
  6f0831:	call   *0x352201(%rip)        # a42a38 <_DYNAMIC+0x4a0>
  6f0837:	pop    %rbx
  6f0838:	ret
  6f0839:	xor    %eax,%eax
  6f083b:	pop    %rbx
  6f083c:	ret

<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge code=1452 fixed_stack=184

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006fe1d0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge>:
  6fe1d0:	push   %r15
  6fe1d2:	push   %r14
  6fe1d4:	push   %r12
  6fe1d6:	push   %rbx
  6fe1d7:	sub    $0x98,%rsp
  6fe1de:	mov    %rdi,%r14
  6fe1e1:	cmp    %rdx,0x6b0(%rsi)
  6fe1e8:	jne    6fe51a <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x34a>
  6fe1ee:	mov    %rsi,%rbx
  6fe1f1:	cmp    %rcx,0x6b8(%rsi)
  6fe1f8:	jne    6fe51a <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x34a>
  6fe1fe:	lea    0x5f0(%rbx),%rdi
  6fe205:	mov    %rcx,%rsi
  6fe208:	call   *0x344a92(%rip)        # a42ca0 <_DYNAMIC+0x708>
  6fe20e:	mov    0x5d8(%rbx),%rax
  6fe215:	mov    %rax,0x30(%rsp)
  6fe21a:	movdqu 0x5b8(%rbx),%xmm0
  6fe222:	movdqu 0x5c8(%rbx),%xmm1
  6fe22a:	movdqa %xmm0,0x10(%rsp)
  6fe230:	movq   $0xffffffffffffffff,0x5b8(%rbx)
  6fe23b:	movzbl 0x74c(%rbx),%eax
  6fe242:	xor    $0x1,%rax
  6fe246:	cmpq   $0xffffffffffffffff,0x10(%rsp)
  6fe24c:	movdqa %xmm1,0x20(%rsp)
  6fe252:	mov    $0x1,%r12d
  6fe258:	cmove  %rax,%r12
  6fe25c:	je     6fe302 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x132>
  6fe262:	movdqa 0x30(%rsp),%xmm0
  6fe268:	movss  0x34(%rsp),%xmm2
  6fe26e:	movd   %xmm0,%eax
  6fe272:	pand   -0x6bcc9a(%rip),%xmm0        # 415e0 <GCC_except_table0+0x1798>
  6fe27a:	pxor   %xmm1,%xmm1
  6fe27e:	punpcklwd %xmm1,%xmm0
  6fe282:	movq   %xmm0,0x6a0(%rbx)
  6fe28a:	test   %ax,%ax
  6fe28d:	js     6fe526 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x356>
  6fe293:	movss  %xmm2,0xc(%rsp)
  6fe299:	lea    0x5a0(%rbx),%r15
  6fe2a0:	mov    %r15,%rdi
  6fe2a3:	call   6c13a0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  6fe2a8:	mov    0x20(%rsp),%rax
  6fe2ad:	mov    %rax,0x10(%r15)
  6fe2b1:	movaps 0x10(%rsp),%xmm0
  6fe2b6:	movups %xmm0,(%r15)
  6fe2ba:	mov    0x6c8(%rbx),%rdi
  6fe2c1:	test   %rdi,%rdi
  6fe2c4:	je     6fe2cc <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0xfc>
  6fe2c6:	call   *0x3449dc(%rip)        # a42ca8 <_DYNAMIC+0x710>
  6fe2cc:	mov    0x640(%rbx),%rax
  6fe2d3:	test   %rax,%rax
  6fe2d6:	je     6fe2f4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x124>
  6fe2d8:	mov    0xe0(%rax),%rax
  6fe2df:	test   %rax,%rax
  6fe2e2:	je     6fe2f4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x124>
  6fe2e4:	mov    0x50(%rax),%rcx
  6fe2e8:	mov    %rcx,0x38(%rax)
  6fe2ec:	movups 0x40(%rax),%xmm0
  6fe2f0:	movups %xmm0,0x28(%rax)
  6fe2f4:	movd   0xc(%rsp),%xmm0
  6fe2fa:	movd   %xmm0,0x744(%rbx)
  6fe302:	mov    0x640(%rbx),%rax
  6fe309:	test   %rax,%rax
  6fe30c:	je     6fe548 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe312:	mov    0x60(%rax),%r15
  6fe316:	movq   $0xffffffffffffffff,0x60(%rax)
  6fe31e:	cmp    $0xffffffffffffffff,%r15
  6fe322:	je     6fe3c6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x1f6>
  6fe328:	mov    0xb8(%rax),%rcx
  6fe32f:	mov    %rcx,0x90(%rsp)
  6fe337:	movups 0xa8(%rax),%xmm0
  6fe33e:	movaps %xmm0,0x80(%rsp)
  6fe346:	movups 0x68(%rax),%xmm0
  6fe34a:	movups 0x78(%rax),%xmm1
  6fe34e:	movups 0x88(%rax),%xmm2
  6fe355:	movups 0x98(%rax),%xmm3
  6fe35c:	movaps %xmm3,0x70(%rsp)
  6fe361:	movaps %xmm2,0x60(%rsp)
  6fe366:	movaps %xmm1,0x50(%rsp)
  6fe36b:	movaps %xmm0,0x40(%rsp)
  6fe370:	mov    0x640(%rbx),%rdi
  6fe377:	call   6c78e0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  6fe37c:	mov    0x640(%rbx),%rax
  6fe383:	mov    %r15,(%rax)
  6fe386:	movaps 0x40(%rsp),%xmm0
  6fe38b:	movdqa 0x50(%rsp),%xmm1
  6fe391:	movaps 0x60(%rsp),%xmm2
  6fe396:	movaps 0x70(%rsp),%xmm3
  6fe39b:	movups %xmm0,0x8(%rax)
  6fe39f:	movdqu %xmm1,0x18(%rax)
  6fe3a4:	movups %xmm2,0x28(%rax)
  6fe3a8:	movups %xmm3,0x38(%rax)
  6fe3ac:	movdqa 0x80(%rsp),%xmm0
  6fe3b5:	movdqu %xmm0,0x48(%rax)
  6fe3ba:	mov    0x90(%rsp),%rcx
  6fe3c2:	mov    %rcx,0x58(%rax)
  6fe3c6:	mov    0x640(%rbx),%r15
  6fe3cd:	test   %r15,%r15
  6fe3d0:	je     6fe548 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe3d6:	mov    0x100(%r15),%rdi
  6fe3dd:	test   %rdi,%rdi
  6fe3e0:	je     6fe430 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x260>
  6fe3e2:	call   *0x3448c8(%rip)        # a42cb0 <_DYNAMIC+0x718>
  6fe3e8:	mov    0x100(%r15),%rax
  6fe3ef:	cmpq   $0x0,0x10(%rax)
  6fe3f4:	jne    6fe430 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x260>
  6fe3f6:	cmpq   $0x0,0x58(%rax)
  6fe3fb:	jne    6fe430 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x260>
  6fe3fd:	cmpq   $0x0,0x28(%rax)
  6fe402:	jne    6fe430 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x260>
  6fe404:	cmpq   $0xffffffffffffffff,0x30(%rax)
  6fe409:	jne    6fe430 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x260>
  6fe40b:	mov    0x640(%rbx),%rax
  6fe412:	mov    0x100(%rax),%rdi
  6fe419:	call   6bf490 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::geometry::Geometry>>>>
  6fe41e:	mov    0x640(%rbx),%rax
  6fe425:	movq   $0x0,0x100(%rax)
  6fe430:	mov    0x640(%rbx),%r15
  6fe437:	test   %r15,%r15
  6fe43a:	je     6fe548 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe440:	mov    0xe0(%r15),%rdi
  6fe447:	test   %rdi,%rdi
  6fe44a:	je     6fe490 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x2c0>
  6fe44c:	cmpb   $0x2,0x24(%rdi)
  6fe450:	jne    6fe490 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x2c0>
  6fe452:	cmpb   $0x2,0x3c(%rdi)
  6fe456:	jne    6fe490 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x2c0>
  6fe458:	cmpb   $0x2,0x54(%rdi)
  6fe45c:	jne    6fe490 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x2c0>
  6fe45e:	mov    $0x58,%esi
  6fe463:	mov    $0x8,%edx
  6fe468:	call   *0x344392(%rip)        # a42800 <_DYNAMIC+0x268>
  6fe46e:	mov    0x640(%rbx),%rax
  6fe475:	movq   $0x0,0xe0(%rax)
  6fe480:	mov    0x640(%rbx),%r15
  6fe487:	test   %r15,%r15
  6fe48a:	je     6fe548 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe490:	cmpq   $0x0,0xd8(%r15)
  6fe498:	jne    6fe548 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe49e:	cmpq   $0x0,0xe0(%r15)
  6fe4a6:	jne    6fe548 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe4ac:	cmpq   $0x0,0x100(%r15)
  6fe4b4:	jne    6fe548 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe4ba:	cmpq   $0x0,0xd0(%r15)
  6fe4c2:	jne    6fe548 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe4c8:	cmpq   $0x0,0xf8(%r15)
  6fe4d0:	jne    6fe548 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe4d2:	mov    0x60(%r15),%rax
  6fe4d6:	cmp    $0xffffffff,%eax
  6fe4d9:	jne    6fe548 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe4db:	cmpq   $0x0,0x28(%r15)
  6fe4e0:	jne    6fe548 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe4e2:	mov    (%r15),%rax
  6fe4e5:	or     0x40(%r15),%rax
  6fe4e9:	jne    6fe548 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe4eb:	cmpq   $0x0,0x58(%r15)
  6fe4f0:	jne    6fe548 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe4f2:	mov    %r15,%rdi
  6fe4f5:	call   6c7980 <core::ptr::drop_glue::<gpui::runtime::metadata::Metadata>>
  6fe4fa:	mov    $0x108,%esi
  6fe4ff:	mov    $0x8,%edx
  6fe504:	mov    %r15,%rdi
  6fe507:	call   *0x3442f3(%rip)        # a42800 <_DYNAMIC+0x268>
  6fe50d:	movq   $0x0,0x640(%rbx)
  6fe518:	jmp    6fe548 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x378>
  6fe51a:	movq   $0x15,(%r14)
  6fe521:	jmp    6fe693 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x4c3>
  6fe526:	movss  %xmm2,0x744(%rbx)
  6fe52e:	lea    0x10(%rsp),%rdi
  6fe533:	call   6c13a0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  6fe538:	mov    0x640(%rbx),%rax
  6fe53f:	test   %rax,%rax
  6fe542:	jne    6fe312 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x142>
  6fe548:	mov    0x6c8(%rbx),%rdi
  6fe54f:	test   %rdi,%rdi
  6fe552:	je     6fe579 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x3a9>
  6fe554:	cmpq   $0x0,0x30(%rdi)
  6fe559:	jne    6fe579 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x3a9>
  6fe55b:	cmpq   $0x0,0x10(%rdi)
  6fe560:	jne    6fe579 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x3a9>
  6fe562:	cmpq   $0xffffffffffffffff,0x18(%rdi)
  6fe567:	jne    6fe579 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x3a9>
  6fe569:	call   6bf320 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::text_geometry::TextResources>>>>
  6fe56e:	movq   $0x0,0x6c8(%rbx)
  6fe579:	mov    0x618(%rbx),%rax
  6fe580:	test   %rax,%rax
  6fe583:	je     6fe62b <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x45b>
  6fe589:	cmp    0x5e0(%rbx),%rax
  6fe590:	jne    6fe620 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x450>
  6fe596:	mov    0x620(%rbx),%rdx
  6fe59d:	lea    0x40(%rsp),%rdi
  6fe5a2:	mov    %rbx,%rsi
  6fe5a5:	call   70cd00 <<gpui::runtime::Runtime<text_column_public_control::Input>>::resolve_identity>
  6fe5aa:	mov    0x40(%rsp),%rax
  6fe5af:	mov    0x48(%rsp),%rsi
  6fe5b4:	cmp    $0xfffffffffffffffe,%rax
  6fe5b8:	jne    6fe5e5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x415>
  6fe5ba:	mov    0x2d0(%rbx),%rax
  6fe5c1:	cmp    %rax,%rsi
  6fe5c4:	jae    6fe6a2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x4d2>
  6fe5ca:	lea    (%rsi,%rsi,4),%rdi
  6fe5ce:	shl    $0x3,%rdi
  6fe5d2:	add    0x2c8(%rbx),%rdi
  6fe5d9:	call   *0x344509(%rip)        # a42ae8 <_DYNAMIC+0x550>
  6fe5df:	test   %al,%al
  6fe5e1:	je     6fe620 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x450>
  6fe5e3:	jmp    6fe62b <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x45b>
  6fe5e5:	cmp    $0xd,%rax
  6fe5e9:	jl     6fe603 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x433>
  6fe5eb:	cmp    $0x21,%rax
  6fe5ef:	je     6fe603 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x433>
  6fe5f1:	cmp    $0x26,%rax
  6fe5f5:	jne    6fe620 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x450>
  6fe5f7:	test   %rsi,%rsi
  6fe5fa:	je     6fe620 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x450>
  6fe5fc:	lea    0x50(%rsp),%rax
  6fe601:	jmp    6fe612 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x442>
  6fe603:	mov    0x58(%rsp),%rsi
  6fe608:	test   %rsi,%rsi
  6fe60b:	je     6fe620 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge+0x450>
  6fe60d:	lea    0x60(%rsp),%rax
  6fe612:	mov    (%rax),%rdi
  6fe615:	mov    $0x1,%edx
  6fe61a:	call   *0x3441e0(%rip)        # a42800 <_DYNAMIC+0x268>
  6fe620:	movq   $0x0,0x618(%rbx)
  6fe62b:	mov    0x6c0(%rbx),%rax
  6fe632:	mov    %rax,0x698(%rbx)
  6fe639:	movb   $0x1,0x74c(%rbx)
  6fe640:	add    %r12,0x718(%rbx)
  6fe647:	cmpq   $0x0,0x6b0(%rbx)
  6fe64f:	setne  %cl
  6fe652:	cmpq   $0xffffffffffffffff,0x5b8(%rbx)
  6fe65a:	mov    0x690(%rbx),%rdx
  6fe661:	setne  %sil
  6fe665:	and    %cl,%sil
  6fe668:	movzbl %sil,%ecx
  6fe66c:	mov    0x738(%rbx),%rsi
  6fe673:	mov    %rcx,0x8(%r14)
  6fe677:	mov    %rax,0x10(%r14)
  6fe67b:	mov    %rdx,0x18(%r14)
  6fe67f:	mov    %rax,0x20(%r14)
  6fe683:	mov    %rsi,0x28(%r14)
  6fe687:	movb   $0x1,0x30(%r14)
  6fe68c:	movq   $0xfffffffffffffffe,(%r14)
  6fe693:	add    $0x98,%rsp
  6fe69a:	pop    %rbx
  6fe69b:	pop    %r12
  6fe69d:	pop    %r14
  6fe69f:	pop    %r15
  6fe6a1:	ret
  6fe6a2:	lea    0x324077(%rip),%rdx        # a22720 <__frame_dummy_init_array_entry+0x730>
  6fe6a9:	mov    %rsi,%rdi
  6fe6ac:	mov    %rax,%rsi
  6fe6af:	call   *0x34417b(%rip)        # a42830 <_DYNAMIC+0x298>
  6fe6b5:	mov    %rax,%r14
  6fe6b8:	mov    $0x108,%esi
  6fe6bd:	mov    $0x8,%edx
  6fe6c2:	mov    %r15,%rdi
  6fe6c5:	call   *0x344135(%rip)        # a42800 <_DYNAMIC+0x268>
  6fe6cb:	movq   $0x0,0x640(%rbx)
  6fe6d6:	mov    %r14,%rdi
  6fe6d9:	call   a20c40 <_Unwind_Resume@plt>
  6fe6de:	mov    %rax,%r14
  6fe6e1:	mov    0x640(%rbx),%rax
  6fe6e8:	movq   $0x0,0x100(%rax)
  6fe6f3:	mov    %r14,%rdi
  6fe6f6:	call   a20c40 <_Unwind_Resume@plt>
  6fe6fb:	movq   $0x0,0x6c8(%rbx)
  6fe706:	mov    %rax,%rdi
  6fe709:	call   a20c40 <_Unwind_Resume@plt>
  6fe70e:	mov    %rax,%r14
  6fe711:	mov    0x640(%rbx),%rax
  6fe718:	mov    %r15,(%rax)
  6fe71b:	movaps 0x40(%rsp),%xmm0
  6fe720:	movaps 0x50(%rsp),%xmm1
  6fe725:	movaps 0x60(%rsp),%xmm2
  6fe72a:	movaps 0x70(%rsp),%xmm3
  6fe72f:	movups %xmm0,0x8(%rax)
  6fe733:	movups %xmm1,0x18(%rax)
  6fe737:	movups %xmm2,0x28(%rax)
  6fe73b:	movups %xmm3,0x38(%rax)
  6fe73f:	movaps 0x80(%rsp),%xmm0
  6fe747:	movups %xmm0,0x48(%rax)
  6fe74b:	mov    0x90(%rsp),%rcx
  6fe753:	mov    %rcx,0x58(%rax)
  6fe757:	mov    %r14,%rdi
  6fe75a:	call   a20c40 <_Unwind_Resume@plt>
  6fe75f:	mov    %rax,%r14
  6fe762:	mov    0x20(%rsp),%rax
  6fe767:	mov    %rax,0x10(%r15)
  6fe76b:	movaps 0x10(%rsp),%xmm0
  6fe770:	movups %xmm0,(%r15)
  6fe774:	mov    %r14,%rdi
  6fe777:	call   a20c40 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner code=21452 fixed_stack=3560

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000006fe780 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner>:
  6fe780:	push   %rbp
  6fe781:	push   %r15
  6fe783:	push   %r14
  6fe785:	push   %r13
  6fe787:	push   %r12
  6fe789:	push   %rbx
  6fe78a:	sub    $0xdb8,%rsp
  6fe791:	mov    %rdi,0x48(%rsp)
  6fe796:	mov    0x5e8(%rsi),%rax
  6fe79d:	mov    %rax,0x2b8(%rsp)
  6fe7a5:	inc    %rax
  6fe7a8:	je     702eb7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4737>
  6fe7ae:	mov    %rsi,%r15
  6fe7b1:	mov    %rax,0x7f0(%rsp)
  6fe7b9:	mov    0x5e0(%rsi),%rax
  6fe7c0:	mov    %rax,0x310(%rsp)
  6fe7c8:	mov    0x6a8(%rsi),%rsi
  6fe7cf:	movq   %rsi,%xmm0
  6fe7d4:	movdqa %xmm0,0x100(%rsp)
  6fe7dd:	pshufd $0x55,%xmm0,%xmm0
  6fe7e2:	movd   %xmm0,%edx
  6fe7e6:	movss  0x740(%r15),%xmm0
  6fe7ef:	movss  %xmm0,0x7c(%rsp)
  6fe7f5:	mov    0x1a8(%r15),%eax
  6fe7fc:	mov    0x1b0(%r15),%rcx
  6fe803:	shl    $0x20,%rcx
  6fe807:	or     %rax,%rcx
  6fe80a:	cmp    %rsi,%rcx
  6fe80d:	mov    %rsi,0x2c0(%rsp)
  6fe815:	mov    %edx,0x15c(%rsp)
  6fe81c:	jne    6fe845 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xc5>
  6fe81e:	movq   $0x2,0xbd0(%rsp)
  6fe82a:	mov    $0x2,%ebx
  6fe82f:	cmpl   $0xffff,0x2c0(%rsp)
  6fe83a:	jbe    6fe8df <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x15f>
  6fe840:	jmp    6fe8ec <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x16c>
  6fe845:	movups 0x138(%r15),%xmm0
  6fe84d:	movaps %xmm0,0x8b0(%rsp)
  6fe855:	lea    0x480(%rsp),%rdi
  6fe85d:	lea    0x8b0(%rsp),%rcx
  6fe865:	call   *0x34423d(%rip)        # a42aa8 <_DYNAMIC+0x510>
  6fe86b:	mov    0x480(%rsp),%rbx
  6fe873:	mov    0x488(%rsp),%r14d
  6fe87b:	mov    0x48c(%rsp),%ebp
  6fe882:	cmp    $0x2,%rbx
  6fe886:	jne    6fe8a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x120>
  6fe888:	mov    0x48(%rsp),%rax
  6fe88d:	movq   $0x23,(%rax)
  6fe894:	mov    %r14d,0x8(%rax)
  6fe898:	mov    %ebp,0xc(%rax)
  6fe89b:	jmp    6fffb7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1837>
  6fe8a0:	lea    0x490(%rsp),%rsi
  6fe8a8:	lea    0xbe0(%rsp),%rdi
  6fe8b0:	mov    $0x1d8,%edx
  6fe8b5:	call   *0x343f65(%rip)        # a42820 <memcpy@GLIBC_2.14>
  6fe8bb:	mov    %rbx,0xbd0(%rsp)
  6fe8c3:	mov    %r14d,0xbd8(%rsp)
  6fe8cb:	mov    %ebp,0xbdc(%rsp)
  6fe8d2:	cmpl   $0xffff,0x2c0(%rsp)
  6fe8dd:	ja     6fe8ec <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x16c>
  6fe8df:	cmpl   $0xffff,0x15c(%rsp)
  6fe8ea:	jbe    6fe90d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x18d>
  6fe8ec:	mov    0x48(%rsp),%rax
  6fe8f1:	movq   $0x23,(%rax)
  6fe8f8:	movl   $0x0,0x8(%rax)
  6fe8ff:	cmp    $0x2,%ebx
  6fe902:	jne    6fffaa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x182a>
  6fe908:	jmp    6fffb7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1837>
  6fe90d:	cmpq   $0x0,0x2e8(%r15)
  6fe915:	mov    %r15,0x38(%rsp)
  6fe91a:	je     6fe92f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1af>
  6fe91c:	mov    0x6c8(%r15),%rax
  6fe923:	test   %rax,%rax
  6fe926:	je     6fe944 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1c4>
  6fe928:	cmpq   $0x0,0x30(%rax)
  6fe92d:	je     6fe991 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x211>
  6fe92f:	mov    0x6c8(%r15),%rax
  6fe936:	test   %rax,%rax
  6fe939:	jne    6fea8a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x30a>
  6fe93f:	jmp    6feacf <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x34f>
  6fe944:	call   *0x343ebe(%rip)        # a42808 <_DYNAMIC+0x270>
  6fe94a:	mov    $0x78,%edi
  6fe94f:	mov    $0x8,%esi
  6fe954:	call   *0x343eb6(%rip)        # a42810 <_DYNAMIC+0x278>
  6fe95a:	test   %rax,%rax
  6fe95d:	je     7031b2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4a32>
  6fe963:	movq   $0x0,(%rax)
  6fe96a:	movq   $0x8,0x8(%rax)
  6fe972:	movq   $0x0,0x10(%rax)
  6fe97a:	movq   $0xffffffffffffffff,0x18(%rax)
  6fe982:	movq   $0x0,0x30(%rax)
  6fe98a:	mov    %rax,0x6c8(%r15)
  6fe991:	mov    $0x1,%bpl
  6fe994:	lea    0x480(%rsp),%rdi
  6fe99c:	call   *0x344316(%rip)        # a42cb8 <_DYNAMIC+0x720>
  6fe9a2:	mov    0x480(%rsp),%r12
  6fe9aa:	mov    0x488(%rsp),%r14d
  6fe9b2:	mov    0x48c(%rsp),%ebp
  6fe9b9:	test   %r12,%r12
  6fe9bc:	je     6ffeb8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1738>
  6fe9c2:	mov    0x4c0(%rsp),%rax
  6fe9ca:	mov    %rax,0x8e0(%rsp)
  6fe9d2:	movups 0x490(%rsp),%xmm0
  6fe9da:	movups 0x4a0(%rsp),%xmm1
  6fe9e2:	movups 0x4b0(%rsp),%xmm2
  6fe9ea:	movaps %xmm2,0x8d0(%rsp)
  6fe9f2:	movaps %xmm1,0x8c0(%rsp)
  6fe9fa:	movaps %xmm0,0x8b0(%rsp)
  6fea02:	mov    0x6c8(%r15),%r15
  6fea09:	mov    0x30(%r15),%rax
  6fea0d:	test   %rax,%rax
  6fea10:	je     6fea3a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2ba>
  6fea12:	lock decq (%rax)
  6fea16:	jne    6fea22 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2a2>
  6fea18:	lea    0x30(%r15),%rdi
  6fea1c:	call   *0x343eae(%rip)        # a428d0 <_DYNAMIC+0x338>
  6fea22:	add    $0x38,%r15
  6fea26:	mov    %r15,%rdi
  6fea29:	call   6c5ef0 <core::ptr::drop_glue::<gpui_canvas::text::RasterCache>>
  6fea2e:	mov    0x38(%rsp),%rax
  6fea33:	mov    0x6c8(%rax),%r15
  6fea3a:	mov    %r12,0x30(%r15)
  6fea3e:	mov    %r14d,0x38(%r15)
  6fea42:	mov    %ebp,0x3c(%r15)
  6fea46:	movaps 0x8b0(%rsp),%xmm0
  6fea4e:	movaps 0x8c0(%rsp),%xmm1
  6fea56:	movaps 0x8d0(%rsp),%xmm2
  6fea5e:	movups %xmm0,0x40(%r15)
  6fea63:	movups %xmm1,0x50(%r15)
  6fea68:	movups %xmm2,0x60(%r15)
  6fea6d:	mov    0x8e0(%rsp),%rax
  6fea75:	mov    %rax,0x70(%r15)
  6fea79:	mov    0x38(%rsp),%r15
  6fea7e:	mov    0x6c8(%r15),%rax
  6fea85:	test   %rax,%rax
  6fea88:	je     6feacf <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x34f>
  6fea8a:	mov    0x30(%rax),%rax
  6fea8e:	test   %rax,%rax
  6fea91:	je     6feacf <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x34f>
  6fea93:	lock incq (%rax)
  6fea97:	jle    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  6fea9d:	mov    %rax,0x118(%rsp)
  6feaa5:	movq   $0xffffffffffffffff,0x160(%rsp)
  6feab1:	lea    0x118(%rsp),%rax
  6feab9:	mov    %rax,0x1b0(%rsp)
  6feac1:	movq   $0x0,0x1b8(%rsp)
  6feacd:	jmp    6feaf3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x373>
  6feacf:	movq   $0x0,0x118(%rsp)
  6feadb:	movq   $0xffffffffffffffff,0x160(%rsp)
  6feae7:	movq   $0x0,0x1b0(%rsp)
  6feaf3:	lea    0x428(%rsp),%rdi
  6feafb:	mov    %r15,%rsi
  6feafe:	call   6ec410 <<gpui::runtime::Runtime<text_column_public_control::Input>>::active_selection>
  6feb03:	lea    0x480(%rsp),%rdi
  6feb0b:	mov    %r15,%rsi
  6feb0e:	call   6ec410 <<gpui::runtime::Runtime<text_column_public_control::Input>>::active_selection>
  6feb13:	movzbl 0x494(%rsp),%ebx
  6feb1b:	cmp    $0x2,%bl
  6feb1e:	je     6feb76 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3f6>
  6feb20:	mov    0x480(%rsp),%rax
  6feb28:	mov    %rax,0x7e8(%rsp)
  6feb30:	test   %rax,%rax
  6feb33:	je     703194 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4a14>
  6feb39:	mov    0x490(%rsp),%eax
  6feb40:	mov    %eax,0x330(%rsp)
  6feb47:	mov    0x488(%rsp),%rax
  6feb4f:	mov    %rax,0x328(%rsp)
  6feb57:	movzwl 0x495(%rsp),%eax
  6feb5f:	mov    %ax,0xe8(%rsp)
  6feb67:	movzbl 0x497(%rsp),%eax
  6feb6f:	mov    %al,0xea(%rsp)
  6feb76:	lea    0x2f0(%r15),%rax
  6feb7d:	mov    %rax,0x58(%rsp)
  6feb82:	cmpb   $0x0,0x748(%r15)
  6feb8a:	mov    %bl,0x7b(%rsp)
  6feb8e:	jne    6feee2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x762>
  6feb94:	cmpb   $0x0,0x749(%r15)
  6feb9c:	jne    6feee2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x762>
  6feba2:	cmpb   $0x0,0x580(%r15)
  6febaa:	jne    6feee2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x762>
  6febb0:	mov    0x648(%r15),%rax
  6febb7:	mov    0x658(%r15),%r15
  6febbe:	test   %rax,%rax
  6febc1:	setne  %cl
  6febc4:	test   %r15,%r15
  6febc7:	setne  %dl
  6febca:	and    %cl,%dl
  6febcc:	cmp    $0x1,%dl
  6febcf:	jne    6ff426 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xca6>
  6febd5:	mov    0x38(%rsp),%rcx
  6febda:	mov    0x650(%rcx),%r14
  6febe1:	lea    0x1e8(%rcx),%rdx
  6febe8:	mov    %rdx,0x30(%rsp)
  6febed:	add    $0x678,%rcx
  6febf4:	mov    %rcx,0x40(%rsp)
  6febf9:	xor    %ebx,%ebx
  6febfb:	lea    0x32500e(%rip),%rcx        # a23c10 <__frame_dummy_init_array_entry+0x1c20>
  6fec02:	mov    %rcx,0x60(%rsp)
  6fec07:	jmp    6fec2b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4ab>
  6fec09:	nopl   0x0(%rax)
  6fec10:	mov    0x40(%rsp),%rdi
  6fec15:	mov    %r12,%rsi
  6fec18:	call   6fc770 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6fec1d:	mov    $0x0,%eax
  6fec22:	dec    %r15
  6fec25:	je     6ff426 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xca6>
  6fec2b:	test   %rbx,%rbx
  6fec2e:	je     6fec50 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d0>
  6fec30:	movzwl 0x58a(%rbx),%ecx
  6fec37:	cmp    %rcx,%r14
  6fec3a:	jae    6fed00 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x580>
  6fec40:	mov    %rbx,%rcx
  6fec43:	mov    %r14,%rdx
  6fec46:	jmp    6fed26 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5a6>
  6fec4b:	nopl   0x0(%rax,%rax,1)
  6fec50:	test   %r14,%r14
  6fec53:	je     6fec8d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x50d>
  6fec55:	mov    %r14,%rcx
  6fec58:	mov    %rax,%rbx
  6fec5b:	and    $0x7,%rcx
  6fec5f:	je     6fec92 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x512>
  6fec61:	xor    %edx,%edx
  6fec63:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fec70:	mov    0x590(%rbx),%rbx
  6fec77:	inc    %rdx
  6fec7a:	cmp    %rdx,%rcx
  6fec7d:	jne    6fec70 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4f0>
  6fec7f:	mov    %r14,%rax
  6fec82:	sub    %rdx,%rax
  6fec85:	cmp    $0x8,%r14
  6fec89:	jae    6feca0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x520>
  6fec8b:	jmp    6fecde <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x55e>
  6fec8d:	mov    %rax,%rbx
  6fec90:	jmp    6fecde <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x55e>
  6fec92:	mov    %r14,%rax
  6fec95:	cmp    $0x8,%r14
  6fec99:	jb     6fecde <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x55e>
  6fec9b:	nopl   0x0(%rax,%rax,1)
  6feca0:	mov    0x590(%rbx),%rcx
  6feca7:	mov    0x590(%rcx),%rcx
  6fecae:	mov    0x590(%rcx),%rcx
  6fecb5:	mov    0x590(%rcx),%rcx
  6fecbc:	mov    0x590(%rcx),%rcx
  6fecc3:	mov    0x590(%rcx),%rcx
  6fecca:	mov    0x590(%rcx),%rcx
  6fecd1:	mov    0x590(%rcx),%rbx
  6fecd8:	add    $0xfffffffffffffff8,%rax
  6fecdc:	jne    6feca0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x520>
  6fecde:	xor    %eax,%eax
  6fece0:	xor    %r14d,%r14d
  6fece3:	movzwl 0x58a(%rbx),%ecx
  6fecea:	cmp    %rcx,%r14
  6feced:	jb     6fec40 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c0>
  6fecf3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fed00:	mov    0x580(%rbx),%rcx
  6fed07:	test   %rcx,%rcx
  6fed0a:	je     7031ca <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4a4a>
  6fed10:	inc    %rax
  6fed13:	movzwl 0x588(%rbx),%edx
  6fed1a:	mov    %rcx,%rbx
  6fed1d:	cmp    0x58a(%rcx),%dx
  6fed24:	jae    6fed00 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x580>
  6fed26:	test   %rax,%rax
  6fed29:	je     6fedc0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x640>
  6fed2f:	lea    (%rcx,%rdx,8),%rsi
  6fed33:	add    $0x598,%rsi
  6fed3a:	mov    %rax,%rdi
  6fed3d:	and    $0x7,%rdi
  6fed41:	je     6feed0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x750>
  6fed47:	xor    %r8d,%r8d
  6fed4a:	nopw   0x0(%rax,%rax,1)
  6fed50:	mov    (%rsi),%rbx
  6fed53:	lea    0x590(%rbx),%rsi
  6fed5a:	inc    %r8
  6fed5d:	cmp    %r8,%rdi
  6fed60:	jne    6fed50 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5d0>
  6fed62:	mov    %rax,%rdi
  6fed65:	sub    %r8,%rdi
  6fed68:	cmp    $0x8,%rax
  6fed6c:	jb     6fedb1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x631>
  6fed6e:	xchg   %ax,%ax
  6fed70:	mov    (%rsi),%rax
  6fed73:	mov    0x590(%rax),%rax
  6fed7a:	mov    0x590(%rax),%rax
  6fed81:	mov    0x590(%rax),%rax
  6fed88:	mov    0x590(%rax),%rax
  6fed8f:	mov    0x590(%rax),%rax
  6fed96:	mov    0x590(%rax),%rax
  6fed9d:	mov    0x590(%rax),%rbx
  6feda4:	lea    0x590(%rbx),%rsi
  6fedab:	add    $0xfffffffffffffff8,%rdi
  6fedaf:	jne    6fed70 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5f0>
  6fedb1:	xor    %r14d,%r14d
  6fedb4:	jmp    6fedc7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x647>
  6fedb6:	cs nopw 0x0(%rax,%rax,1)
  6fedc0:	lea    0x1(%rdx),%r14
  6fedc4:	mov    %rcx,%rbx
  6fedc7:	imul   $0x70,%rdx,%rax
  6fedcb:	shl    $0x4,%rdx
  6fedcf:	lea    (%rcx,%rax,1),%rdi
  6fedd3:	add    $0xb0,%rdi
  6fedda:	mov    (%rcx,%rdx,1),%rsi
  6fedde:	mov    0x8(%rcx,%rdx,1),%rdx
  6fede3:	call   *0x343b8f(%rip)        # a42978 <_DYNAMIC+0x3e0>
  6fede9:	mov    %rax,%r12
  6fedec:	mov    0x30(%rsp),%rdi
  6fedf1:	mov    %rax,%rsi
  6fedf4:	call   6f7fd0 <<gpui::runtime::identity_index::IdentityIndex>::required>
  6fedf9:	mov    %rax,%rbp
  6fedfc:	mov    0x38(%rsp),%rax
  6fee01:	mov    0x2d0(%rax),%r13
  6fee08:	cmp    %r13,%rbp
  6fee0b:	jae    7033af <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c2f>
  6fee11:	mov    0x2c8(%rax),%rcx
  6fee18:	lea    0x0(,%rbp,4),%rax
  6fee20:	add    %rbp,%rax
  6fee23:	mov    0x18(%rcx,%rax,8),%ebp
  6fee27:	mov    $0xffffffff,%eax
  6fee2c:	cmp    %rax,%rbp
  6fee2f:	je     6fec1d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x49d>
  6fee35:	cmp    %rbp,%r13
  6fee38:	jbe    7032ef <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b6f>
  6fee3e:	mov    0x40(%rsp),%rax
  6fee43:	mov    (%rax),%rax
  6fee46:	test   %rax,%rax
  6fee49:	je     6fec1d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x49d>
  6fee4f:	lea    0x0(,%rbp,4),%rdx
  6fee57:	add    %rbp,%rdx
  6fee5a:	mov    (%rcx,%rdx,8),%rcx
  6fee5e:	mov    0x38(%rsp),%rdx
  6fee63:	mov    0x680(%rdx),%rdx
  6fee6a:	movzwl 0x62(%rax),%edi
  6fee6e:	mov    %edi,%r8d
  6fee71:	shl    $0x3,%r8d
  6fee75:	mov    $0xffffffffffffffff,%rsi
  6fee7c:	nopl   0x0(%rax)
  6fee80:	test   %r8,%r8
  6fee83:	je     6feeb0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x730>
  6fee85:	cmp    0x10(%rax,%rsi,8),%rcx
  6fee8a:	seta   %r9b
  6fee8e:	sbb    $0x0,%r9b
  6fee92:	inc    %rsi
  6fee95:	add    $0xfffffffffffffff8,%r8
  6fee99:	cmp    $0x1,%r9b
  6fee9d:	je     6fee80 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x700>
  6fee9f:	movzbl %r9b,%edi
  6feea3:	test   %edi,%edi
  6feea5:	je     6fec10 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x490>
  6feeab:	jmp    6feeb3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x733>
  6feead:	nopl   (%rax)
  6feeb0:	mov    %rdi,%rsi
  6feeb3:	sub    $0x1,%rdx
  6feeb7:	jb     6fec1d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x49d>
  6feebd:	mov    0x68(%rax,%rsi,8),%rax
  6feec2:	jmp    6fee6a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x6ea>
  6feec4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6feed0:	mov    %rax,%rdi
  6feed3:	cmp    $0x8,%rax
  6feed7:	jae    6fed70 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5f0>
  6feedd:	jmp    6fedb1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x631>
  6feee2:	lea    0x480(%rsp),%rdi
  6feeea:	call   *0x343bc8(%rip)        # a42ab8 <_DYNAMIC+0x520>
  6feef0:	lea    0x2f0(%r15),%r14
  6feef7:	mov    %r14,%rdi
  6feefa:	call   6c5760 <core::ptr::drop_glue::<gpui_reactivity_core::layout::LayoutTree>>
  6feeff:	lea    0x480(%rsp),%rsi
  6fef07:	mov    $0x298,%edx
  6fef0c:	mov    %r14,%rdi
  6fef0f:	call   *0x34390b(%rip)        # a42820 <memcpy@GLIBC_2.14>
  6fef15:	movq   $0x0,0x598(%r15)
  6fef20:	mov    0x2d0(%r15),%rax
  6fef27:	test   %rax,%rax
  6fef2a:	je     6ffa0b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x128b>
  6fef30:	lea    0x588(%r15),%rcx
  6fef37:	mov    %rcx,0x40(%rsp)
  6fef3c:	mov    0x2c8(%r15),%r12
  6fef43:	lea    (%rax,%rax,4),%rax
  6fef47:	lea    (%r12,%rax,8),%rax
  6fef4b:	mov    %rax,0x30(%rsp)
  6fef50:	xor    %r13d,%r13d
  6fef53:	lea    -0x6bd22e(%rip),%r14        # 41d2c <GCC_except_table0+0x1ee4>
  6fef5a:	lea    0x3238c7(%rip),%rax        # a22828 <__frame_dummy_init_array_entry+0x838>
  6fef61:	mov    %rax,0x60(%rsp)
  6fef66:	xor    %ebx,%ebx
  6fef68:	jmp    6fefab <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x82b>
  6fef6a:	nopw   0x0(%rax,%rax,1)
  6fef70:	add    $0x28,%r12
  6fef74:	inc    %rbx
  6fef77:	mov    0x38(%rsp),%r15
  6fef7c:	mov    0x590(%r15),%rax
  6fef83:	mov    %r13,%rcx
  6fef86:	shl    $0x4,%rcx
  6fef8a:	movaps 0x890(%rsp),%xmm0
  6fef92:	movups %xmm0,(%rax,%rcx,1)
  6fef96:	inc    %r13
  6fef99:	mov    %r13,0x598(%r15)
  6fefa0:	cmp    0x30(%rsp),%r12
  6fefa5:	je     6ffa0b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x128b>
  6fefab:	mov    0x18(%r12),%ebp
  6fefb0:	mov    $0xffffffff,%eax
  6fefb5:	cmp    %rax,%rbp
  6fefb8:	je     6feff0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x870>
  6fefba:	cmp    %rbp,%r13
  6fefbd:	jbe    7033af <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c2f>
  6fefc3:	mov    0x590(%r15),%rax
  6fefca:	mov    %rbp,%rcx
  6fefcd:	shl    $0x4,%rcx
  6fefd1:	movups (%rax,%rcx,1),%xmm0
  6fefd5:	lea    0xb98(%rsp),%rax
  6fefdd:	movups %xmm0,(%rax)
  6fefe0:	mov    $0x1,%eax
  6fefe5:	jmp    6feff2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x872>
  6fefe7:	nopw   0x0(%rax,%rax,1)
  6feff0:	xor    %eax,%eax
  6feff2:	mov    %rax,0xb90(%rsp)
  6feffa:	mov    0x20(%r12),%eax
  6fefff:	and    $0xf,%eax
  6ff002:	cmp    $0xa,%eax
  6ff005:	jae    703176 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x49f6>
  6ff00b:	lea    -0x6ae2c0(%rip),%rcx        # 50d52 <GCC_except_table0+0x10f0a>
  6ff012:	movzbl (%rax,%rcx,1),%r15d
  6ff017:	mov    0x38(%rsp),%rcx
  6ff01c:	mov    0x200(%rcx),%rax
  6ff023:	movslq (%r14,%rax,4),%rax
  6ff027:	add    %r14,%rax
  6ff02a:	jmp    *%rax
  6ff02c:	movups -0x6b1dcf(%rip),%xmm0        # 4d264 <GCC_except_table0+0xd41c>
  6ff033:	movaps %xmm0,0x8f0(%rsp)
  6ff03b:	movups -0x6b1dee(%rip),%xmm0        # 4d254 <GCC_except_table0+0xd40c>
  6ff042:	movaps %xmm0,0x8e0(%rsp)
  6ff04a:	movups -0x6b1e0d(%rip),%xmm0        # 4d244 <GCC_except_table0+0xd3fc>
  6ff051:	movaps %xmm0,0x8d0(%rsp)
  6ff059:	movups -0x6b1e2c(%rip),%xmm0        # 4d234 <GCC_except_table0+0xd3ec>
  6ff060:	movaps %xmm0,0x8c0(%rsp)
  6ff068:	movups -0x6b1e4b(%rip),%xmm0        # 4d224 <GCC_except_table0+0xd3dc>
  6ff06f:	movaps %xmm0,0x8b0(%rsp)
  6ff077:	movabs $0x3000100000000,%rax
  6ff081:	mov    %rax,0x900(%rsp)
  6ff089:	cmp    $0xffffffff,%ebp
  6ff08c:	jne    6ff121 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x9a1>
  6ff092:	jmp    6ff1d7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xa57>
  6ff097:	mov    0x220(%rcx),%r13
  6ff09e:	cmp    %r13,%rbx
  6ff0a1:	jae    703368 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4be8>
  6ff0a7:	mov    0x210(%rcx),%r13
  6ff0ae:	mov    0x218(%rcx),%rax
  6ff0b5:	movzbl (%rax,%rbx,1),%eax
  6ff0b9:	cmp    %rax,%r13
  6ff0bc:	jbe    703374 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4bf4>
  6ff0c2:	mov    0x208(%rcx),%rcx
  6ff0c9:	imul   $0x58,%rax,%rax
  6ff0cd:	mov    0x50(%rcx,%rax,1),%rdx
  6ff0d2:	mov    %rdx,0x900(%rsp)
  6ff0da:	movups 0x40(%rcx,%rax,1),%xmm0
  6ff0df:	movaps %xmm0,0x8f0(%rsp)
  6ff0e7:	movups (%rcx,%rax,1),%xmm0
  6ff0eb:	movups 0x10(%rcx,%rax,1),%xmm1
  6ff0f0:	movups 0x20(%rcx,%rax,1),%xmm2
  6ff0f5:	movupd 0x30(%rcx,%rax,1),%xmm3
  6ff0fb:	jmp    6ff1ad <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xa2d>
  6ff100:	mov    0x208(%rcx),%rsi
  6ff107:	lea    0x8b0(%rsp),%rdi
  6ff10f:	mov    %rbx,%rdx
  6ff112:	call   *0x343878(%rip)        # a42990 <_DYNAMIC+0x3f8>
  6ff118:	cmp    $0xffffffff,%ebp
  6ff11b:	je     6ff1d7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xa57>
  6ff121:	mov    0x38(%rsp),%rdx
  6ff126:	mov    0x200(%rdx),%rax
  6ff12d:	lea    -0x6bd3f8(%rip),%rsi        # 41d3c <GCC_except_table0+0x1ef4>
  6ff134:	movslq (%rsi,%rax,4),%rcx
  6ff138:	add    %rsi,%rcx
  6ff13b:	lea    -0x6b1f1e(%rip),%rax        # 4d224 <GCC_except_table0+0xd3dc>
  6ff142:	jmp    *%rcx
  6ff144:	mov    0x218(%rdx),%r13
  6ff14b:	cmp    %rbp,%r13
  6ff14e:	jbe    70335f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4bdf>
  6ff154:	imul   $0x58,%rbp,%rax
  6ff158:	add    0x210(%rdx),%rax
  6ff15f:	jmp    6ff229 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xaa9>
  6ff164:	mov    0x218(%rcx),%r13
  6ff16b:	cmp    %r13,%rbx
  6ff16e:	jae    703379 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4bf9>
  6ff174:	mov    0x210(%rcx),%rax
  6ff17b:	imul   $0x58,%rbx,%rcx
  6ff17f:	mov    0x50(%rax,%rcx,1),%rdx
  6ff184:	mov    %rdx,0x900(%rsp)
  6ff18c:	movups 0x40(%rax,%rcx,1),%xmm0
  6ff191:	movaps %xmm0,0x8f0(%rsp)
  6ff199:	movups (%rax,%rcx,1),%xmm0
  6ff19d:	movups 0x10(%rax,%rcx,1),%xmm1
  6ff1a2:	movups 0x20(%rax,%rcx,1),%xmm2
  6ff1a7:	movupd 0x30(%rax,%rcx,1),%xmm3
  6ff1ad:	movapd %xmm3,0x8e0(%rsp)
  6ff1b6:	movaps %xmm2,0x8d0(%rsp)
  6ff1be:	movaps %xmm1,0x8c0(%rsp)
  6ff1c6:	movaps %xmm0,0x8b0(%rsp)
  6ff1ce:	cmp    $0xffffffff,%ebp
  6ff1d1:	jne    6ff121 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x9a1>
  6ff1d7:	mov    $0x2,%al
  6ff1d9:	mov    0x38(%rsp),%rdx
  6ff1de:	mov    0x660(%rdx),%r8
  6ff1e5:	test   %r8,%r8
  6ff1e8:	jne    6ff2a9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xb29>
  6ff1ee:	jmp    6ff330 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xbb0>
  6ff1f3:	mov    0x220(%rdx),%r13
  6ff1fa:	cmp    %rbp,%r13
  6ff1fd:	jbe    703356 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4bd6>
  6ff203:	mov    0x210(%rdx),%r13
  6ff20a:	mov    0x218(%rdx),%rax
  6ff211:	movzbl (%rax,%rbp,1),%ebp
  6ff215:	cmp    %rbp,%r13
  6ff218:	jbe    7033a3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c23>
  6ff21e:	imul   $0x58,%rbp,%rax
  6ff222:	add    0x208(%rdx),%rax
  6ff229:	mov    0x50(%rax),%rcx
  6ff22d:	mov    %rcx,0x4d0(%rsp)
  6ff235:	movups 0x40(%rax),%xmm0
  6ff239:	movaps %xmm0,0x4c0(%rsp)
  6ff241:	movups (%rax),%xmm0
  6ff244:	movups 0x10(%rax),%xmm1
  6ff248:	movups 0x20(%rax),%xmm2
  6ff24c:	movupd 0x30(%rax),%xmm3
  6ff251:	movapd %xmm3,0x4b0(%rsp)
  6ff25a:	movaps %xmm2,0x4a0(%rsp)
  6ff262:	movaps %xmm1,0x490(%rsp)
  6ff26a:	movaps %xmm0,0x480(%rsp)
  6ff272:	jmp    6ff28c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xb0c>
  6ff274:	mov    0x208(%rdx),%rsi
  6ff27b:	lea    0x480(%rsp),%rdi
  6ff283:	mov    %rbp,%rdx
  6ff286:	call   *0x343704(%rip)        # a42990 <_DYNAMIC+0x3f8>
  6ff28c:	movzbl 0x4d4(%rsp),%eax
  6ff294:	mov    0x38(%rsp),%rdx
  6ff299:	mov    0x660(%rdx),%r8
  6ff2a0:	test   %r8,%r8
  6ff2a3:	je     6ff330 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xbb0>
  6ff2a9:	mov    (%r12),%rcx
  6ff2ad:	mov    0x668(%rdx),%rdx
  6ff2b4:	movzwl 0x1c2(%r8),%edi
  6ff2bc:	mov    %edi,%r10d
  6ff2bf:	shl    $0x5,%r10d
  6ff2c3:	mov    $0xffffffffffffffff,%rsi
  6ff2ca:	xor    %r9d,%r9d
  6ff2cd:	nopl   (%rax)
  6ff2d0:	mov    %r10,%r11
  6ff2d3:	add    %r9,%r11
  6ff2d6:	je     6ff300 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xb80>
  6ff2d8:	cmp    0x170(%r8,%rsi,8),%rcx
  6ff2e0:	seta   %r11b
  6ff2e4:	sbb    $0x0,%r11b
  6ff2e8:	add    $0xffffffffffffffe0,%r9
  6ff2ec:	inc    %rsi
  6ff2ef:	cmp    $0x1,%r11b
  6ff2f3:	je     6ff2d0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xb50>
  6ff2f5:	movzbl %r11b,%edi
  6ff2f9:	test   %edi,%edi
  6ff2fb:	jne    6ff303 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xb83>
  6ff2fd:	jmp    6ff320 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xba0>
  6ff2ff:	nop
  6ff300:	mov    %rdi,%rsi
  6ff303:	sub    $0x1,%rdx
  6ff307:	jb     6ff330 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xbb0>
  6ff309:	mov    0x1c8(%r8,%rsi,8),%r8
  6ff311:	jmp    6ff2b4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xb34>
  6ff313:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6ff320:	sub    %r9,%r8
  6ff323:	add    $0xffffffffffffffe0,%r8
  6ff327:	jmp    6ff333 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xbb3>
  6ff329:	nopl   0x0(%rax)
  6ff330:	xor    %r8d,%r8d
  6ff333:	movzbl %r15b,%esi
  6ff337:	movzbl %al,%ecx
  6ff33a:	lea    0x480(%rsp),%rdi
  6ff342:	lea    0x8b0(%rsp),%rdx
  6ff34a:	call   *0x343970(%rip)        # a42cc0 <_DYNAMIC+0x728>
  6ff350:	lea    0x760(%rsp),%rdi
  6ff358:	mov    0x58(%rsp),%rsi
  6ff35d:	lea    0xb90(%rsp),%rdx
  6ff365:	xor    %ecx,%ecx
  6ff367:	lea    0x480(%rsp),%r8
  6ff36f:	call   *0x343953(%rip)        # a42cc8 <_DYNAMIC+0x730>
  6ff375:	cmpb   $0x0,0x760(%rsp)
  6ff37d:	jne    6fff28 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x17a8>
  6ff383:	lea    0x768(%rsp),%rax
  6ff38b:	movups (%rax),%xmm0
  6ff38e:	lea    0x86(%rsp),%rax
  6ff396:	movups %xmm0,(%rax)
  6ff399:	movups (%rax),%xmm0
  6ff39c:	movaps %xmm0,0x890(%rsp)
  6ff3a4:	mov    0x20(%r12),%ecx
  6ff3a9:	mov    %ecx,%eax
  6ff3ab:	and    $0xf,%eax
  6ff3ae:	cmp    $0x9,%eax
  6ff3b1:	ja     703176 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x49f6>
  6ff3b7:	cmp    $0x6,%eax
  6ff3ba:	je     6ff3cc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xc4c>
  6ff3bc:	cmp    $0x10,%ecx
  6ff3bf:	setae  %cl
  6ff3c2:	cmp    $0x6,%eax
  6ff3c5:	sete   %al
  6ff3c8:	or     %cl,%al
  6ff3ca:	je     6ff3fe <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xc7e>
  6ff3cc:	movaps 0x890(%rsp),%xmm0
  6ff3d4:	movaps %xmm0,0x480(%rsp)
  6ff3dc:	mov    0x58(%rsp),%rdi
  6ff3e1:	lea    0x480(%rsp),%rsi
  6ff3e9:	mov    0x3438e0(%rip),%rdx        # a42cd0 <_DYNAMIC+0x738>
  6ff3f0:	call   *0x3438e2(%rip)        # a42cd8 <_DYNAMIC+0x740>
  6ff3f6:	test   $0x1,%al
  6ff3f8:	jne    6fff17 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1797>
  6ff3fe:	mov    0x38(%rsp),%rax
  6ff403:	mov    0x598(%rax),%r13
  6ff40a:	cmp    0x588(%rax),%r13
  6ff411:	jne    6fef70 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x7f0>
  6ff417:	mov    0x40(%rsp),%rdi
  6ff41c:	call   6f4780 <<alloc::raw_vec::RawVec<[core::option::Option<gpui::source::FieldId>; 2]>>::grow_one>
  6ff421:	jmp    6fef70 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x7f0>
  6ff426:	mov    0x38(%rsp),%r15
  6ff42b:	mov    0x678(%r15),%rax
  6ff432:	mov    0x688(%r15),%rdi
  6ff439:	test   %rax,%rax
  6ff43c:	setne  %cl
  6ff43f:	test   %rdi,%rdi
  6ff442:	setne  %dl
  6ff445:	and    %cl,%dl
  6ff447:	cmp    $0x1,%dl
  6ff44a:	jne    6ffa0b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x128b>
  6ff450:	mov    0x680(%r15),%rbx
  6ff457:	lea    0x1e8(%r15),%rcx
  6ff45e:	mov    %rcx,0x50(%rsp)
  6ff463:	xor    %r12d,%r12d
  6ff466:	lea    0x32475b(%rip),%rcx        # a23bc8 <__frame_dummy_init_array_entry+0x1bd8>
  6ff46d:	mov    %rcx,0x60(%rsp)
  6ff472:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6ff480:	test   %r12,%r12
  6ff483:	je     6ff49c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xd1c>
  6ff485:	movzwl 0x62(%r12),%ecx
  6ff48b:	cmp    %rcx,%rbx
  6ff48e:	jae    6ff520 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xda0>
  6ff494:	mov    %r12,%r15
  6ff497:	jmp    6ff540 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xdc0>
  6ff49c:	test   %rbx,%rbx
  6ff49f:	je     6ff4cb <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xd4b>
  6ff4a1:	mov    %rbx,%rcx
  6ff4a4:	mov    %rax,%r12
  6ff4a7:	and    $0x7,%rcx
  6ff4ab:	je     6ff4d0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xd50>
  6ff4ad:	xor    %edx,%edx
  6ff4af:	nop
  6ff4b0:	mov    0x68(%r12),%r12
  6ff4b5:	inc    %rdx
  6ff4b8:	cmp    %rdx,%rcx
  6ff4bb:	jne    6ff4b0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xd30>
  6ff4bd:	mov    %rbx,%rax
  6ff4c0:	sub    %rdx,%rax
  6ff4c3:	cmp    $0x8,%rbx
  6ff4c7:	jae    6ff4e0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xd60>
  6ff4c9:	jmp    6ff507 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xd87>
  6ff4cb:	mov    %rax,%r12
  6ff4ce:	jmp    6ff507 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xd87>
  6ff4d0:	mov    %rbx,%rax
  6ff4d3:	cmp    $0x8,%rbx
  6ff4d7:	jb     6ff507 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xd87>
  6ff4d9:	nopl   0x0(%rax)
  6ff4e0:	mov    0x68(%r12),%rcx
  6ff4e5:	mov    0x68(%rcx),%rcx
  6ff4e9:	mov    0x68(%rcx),%rcx
  6ff4ed:	mov    0x68(%rcx),%rcx
  6ff4f1:	mov    0x68(%rcx),%rcx
  6ff4f5:	mov    0x68(%rcx),%rcx
  6ff4f9:	mov    0x68(%rcx),%rcx
  6ff4fd:	mov    0x68(%rcx),%r12
  6ff501:	add    $0xfffffffffffffff8,%rax
  6ff505:	jne    6ff4e0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xd60>
  6ff507:	xor    %eax,%eax
  6ff509:	xor    %ebx,%ebx
  6ff50b:	movzwl 0x62(%r12),%ecx
  6ff511:	cmp    %rcx,%rbx
  6ff514:	jb     6ff494 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xd14>
  6ff51a:	nopw   0x0(%rax,%rax,1)
  6ff520:	mov    (%r12),%r15
  6ff524:	test   %r15,%r15
  6ff527:	je     7031e8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4a68>
  6ff52d:	inc    %rax
  6ff530:	movzwl 0x60(%r12),%ebx
  6ff536:	mov    %r15,%r12
  6ff539:	cmp    0x62(%r15),%bx
  6ff53e:	jae    6ff520 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xda0>
  6ff540:	test   %rax,%rax
  6ff543:	mov    %rdi,0x40(%rsp)
  6ff548:	je     6ff5c8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xe48>
  6ff54a:	lea    (%r15,%rbx,8),%rcx
  6ff54e:	add    $0x70,%rcx
  6ff552:	mov    %rax,%rdx
  6ff555:	and    $0x7,%rdx
  6ff559:	je     6ff823 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x10a3>
  6ff55f:	xor    %esi,%esi
  6ff561:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6ff570:	mov    (%rcx),%r12
  6ff573:	lea    0x68(%r12),%rcx
  6ff578:	inc    %rsi
  6ff57b:	cmp    %rsi,%rdx
  6ff57e:	jne    6ff570 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xdf0>
  6ff580:	mov    %rax,%rdx
  6ff583:	sub    %rsi,%rdx
  6ff586:	cmp    $0x8,%rax
  6ff58a:	jb     6ff5ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xe3a>
  6ff58c:	nopl   0x0(%rax)
  6ff590:	mov    (%rcx),%rax
  6ff593:	mov    0x68(%rax),%rax
  6ff597:	mov    0x68(%rax),%rax
  6ff59b:	mov    0x68(%rax),%rax
  6ff59f:	mov    0x68(%rax),%rax
  6ff5a3:	mov    0x68(%rax),%rax
  6ff5a7:	mov    0x68(%rax),%rax
  6ff5ab:	mov    0x68(%rax),%r12
  6ff5af:	lea    0x68(%r12),%rcx
  6ff5b4:	add    $0xfffffffffffffff8,%rdx
  6ff5b8:	jne    6ff590 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xe10>
  6ff5ba:	movq   $0x0,0x180(%rsp)
  6ff5c6:	jmp    6ff5d7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xe57>
  6ff5c8:	lea    0x1(%rbx),%rax
  6ff5cc:	mov    %rax,0x180(%rsp)
  6ff5d4:	mov    %r15,%r12
  6ff5d7:	mov    0x8(%r15,%rbx,8),%rsi
  6ff5dc:	mov    0x50(%rsp),%rdi
  6ff5e1:	call   6f7fd0 <<gpui::runtime::identity_index::IdentityIndex>::required>
  6ff5e6:	mov    %rax,%rbp
  6ff5e9:	mov    0x38(%rsp),%rdx
  6ff5ee:	mov    0x598(%rdx),%r13
  6ff5f5:	cmp    %r13,%rax
  6ff5f8:	jae    7033af <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c2f>
  6ff5fe:	mov    0x590(%rdx),%rax
  6ff605:	mov    %rbp,%rcx
  6ff608:	shl    $0x4,%rcx
  6ff60c:	movups (%rax,%rcx,1),%xmm0
  6ff610:	movaps %xmm0,0x80(%rsp)
  6ff618:	mov    0x2d0(%rdx),%r13
  6ff61f:	cmp    %r13,%rbp
  6ff622:	jae    703328 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4ba8>
  6ff628:	mov    0x2c8(%rdx),%rax
  6ff62f:	lea    0x0(,%rbp,4),%r14
  6ff637:	add    %rbp,%r14
  6ff63a:	mov    0x20(%rax,%r14,8),%eax
  6ff63f:	and    $0xf,%eax
  6ff642:	cmp    $0xa,%eax
  6ff645:	jae    703176 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x49f6>
  6ff64b:	lea    -0x6ae900(%rip),%rcx        # 50d52 <GCC_except_table0+0x10f0a>
  6ff652:	movzbl (%rax,%rcx,1),%eax
  6ff656:	mov    %al,0x30(%rsp)
  6ff65a:	mov    0x38(%rsp),%rdx
  6ff65f:	mov    0x200(%rdx),%rax
  6ff666:	lea    -0x6bd961(%rip),%rcx        # 41d0c <GCC_except_table0+0x1ec4>
  6ff66d:	movslq (%rcx,%rax,4),%rax
  6ff671:	add    %rcx,%rax
  6ff674:	jmp    *%rax
  6ff676:	movups -0x6b2419(%rip),%xmm0        # 4d264 <GCC_except_table0+0xd41c>
  6ff67d:	movaps %xmm0,0x8f0(%rsp)
  6ff685:	movups -0x6b2438(%rip),%xmm0        # 4d254 <GCC_except_table0+0xd40c>
  6ff68c:	movaps %xmm0,0x8e0(%rsp)
  6ff694:	movups -0x6b2457(%rip),%xmm0        # 4d244 <GCC_except_table0+0xd3fc>
  6ff69b:	movaps %xmm0,0x8d0(%rsp)
  6ff6a3:	movups -0x6b2476(%rip),%xmm0        # 4d234 <GCC_except_table0+0xd3ec>
  6ff6aa:	movaps %xmm0,0x8c0(%rsp)
  6ff6b2:	movups -0x6b2495(%rip),%xmm0        # 4d224 <GCC_except_table0+0xd3dc>
  6ff6b9:	movaps %xmm0,0x8b0(%rsp)
  6ff6c1:	movabs $0x3000100000000,%rax
  6ff6cb:	mov    %rax,0x900(%rsp)
  6ff6d3:	jmp    6ff7a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1020>
  6ff6d8:	mov    0x220(%rdx),%rax
  6ff6df:	cmp    %rax,%rbp
  6ff6e2:	jae    703391 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c11>
  6ff6e8:	mov    0x210(%rdx),%rax
  6ff6ef:	mov    0x218(%rdx),%rcx
  6ff6f6:	movzbl (%rcx,%rbp,1),%ecx
  6ff6fa:	cmp    %rcx,%rax
  6ff6fd:	jbe    70339d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c1d>
  6ff703:	mov    0x208(%rdx),%rax
  6ff70a:	imul   $0x58,%rcx,%rcx
  6ff70e:	jmp    6ff751 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xfd1>
  6ff710:	mov    0x208(%rdx),%rsi
  6ff717:	lea    0x8b0(%rsp),%rdi
  6ff71f:	mov    %rbp,%rdx
  6ff722:	call   *0x343268(%rip)        # a42990 <_DYNAMIC+0x3f8>
  6ff728:	mov    0x38(%rsp),%rax
  6ff72d:	mov    0x2d0(%rax),%r13
  6ff734:	jmp    6ff7a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1020>
  6ff736:	mov    0x218(%rdx),%rax
  6ff73d:	cmp    %rax,%rbp
  6ff740:	jae    703385 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c05>
  6ff746:	mov    0x210(%rdx),%rax
  6ff74d:	imul   $0x58,%rbp,%rcx
  6ff751:	mov    0x50(%rax,%rcx,1),%rdx
  6ff756:	mov    %rdx,0x900(%rsp)
  6ff75e:	movups 0x40(%rax,%rcx,1),%xmm0
  6ff763:	movaps %xmm0,0x8f0(%rsp)
  6ff76b:	movups (%rax,%rcx,1),%xmm0
  6ff76f:	movups 0x10(%rax,%rcx,1),%xmm1
  6ff774:	movups 0x20(%rax,%rcx,1),%xmm2
  6ff779:	movupd 0x30(%rax,%rcx,1),%xmm3
  6ff77f:	movapd %xmm3,0x8e0(%rsp)
  6ff788:	movaps %xmm2,0x8d0(%rsp)
  6ff790:	movaps %xmm1,0x8c0(%rsp)
  6ff798:	movaps %xmm0,0x8b0(%rsp)
  6ff7a0:	cmp    %r13,%rbp
  6ff7a3:	jae    703331 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4bb1>
  6ff7a9:	mov    0x38(%rsp),%rdx
  6ff7ae:	mov    0x2c8(%rdx),%rax
  6ff7b5:	mov    0x18(%rax,%r14,8),%ebp
  6ff7ba:	mov    $0xffffffff,%eax
  6ff7bf:	cmp    %rax,%rbp
  6ff7c2:	je     6ff7ff <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x107f>
  6ff7c4:	mov    0x200(%rdx),%rax
  6ff7cb:	lea    -0x6bdab6(%rip),%rsi        # 41d1c <GCC_except_table0+0x1ed4>
  6ff7d2:	movslq (%rsi,%rax,4),%rcx
  6ff7d6:	add    %rsi,%rcx
  6ff7d9:	lea    -0x6b25bc(%rip),%rax        # 4d224 <GCC_except_table0+0xd3dc>
  6ff7e0:	jmp    *%rcx
  6ff7e2:	mov    0x218(%rdx),%r13
  6ff7e9:	cmp    %rbp,%r13
  6ff7ec:	jbe    70335f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4bdf>
  6ff7f2:	imul   $0x58,%rbp,%rax
  6ff7f6:	add    0x210(%rdx),%rax
  6ff7fd:	jmp    6ff86b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x10eb>
  6ff7ff:	mov    $0x2,%al
  6ff801:	mov    0x38(%rsp),%rdx
  6ff806:	mov    0x660(%rdx),%r8
  6ff80d:	test   %r8,%r8
  6ff810:	jne    6ff8eb <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x116b>
  6ff816:	xor    %r8d,%r8d
  6ff819:	movzbl 0x30(%rsp),%ebx
  6ff81e:	jmp    6ff977 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x11f7>
  6ff823:	mov    %rax,%rdx
  6ff826:	cmp    $0x8,%rax
  6ff82a:	jae    6ff590 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xe10>
  6ff830:	jmp    6ff5ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xe3a>
  6ff835:	mov    0x220(%rdx),%r13
  6ff83c:	cmp    %rbp,%r13
  6ff83f:	jbe    703356 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4bd6>
  6ff845:	mov    0x210(%rdx),%r13
  6ff84c:	mov    0x218(%rdx),%rax
  6ff853:	movzbl (%rax,%rbp,1),%ebp
  6ff857:	cmp    %rbp,%r13
  6ff85a:	jbe    7033a3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c23>
  6ff860:	imul   $0x58,%rbp,%rax
  6ff864:	add    0x208(%rdx),%rax
  6ff86b:	mov    0x50(%rax),%rcx
  6ff86f:	mov    %rcx,0x4d0(%rsp)
  6ff877:	movups 0x40(%rax),%xmm0
  6ff87b:	movaps %xmm0,0x4c0(%rsp)
  6ff883:	movups (%rax),%xmm0
  6ff886:	movups 0x10(%rax),%xmm1
  6ff88a:	movups 0x20(%rax),%xmm2
  6ff88e:	movupd 0x30(%rax),%xmm3
  6ff893:	movapd %xmm3,0x4b0(%rsp)
  6ff89c:	movaps %xmm2,0x4a0(%rsp)
  6ff8a4:	movaps %xmm1,0x490(%rsp)
  6ff8ac:	movaps %xmm0,0x480(%rsp)
  6ff8b4:	jmp    6ff8ce <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x114e>
  6ff8b6:	mov    0x208(%rdx),%rsi
  6ff8bd:	lea    0x480(%rsp),%rdi
  6ff8c5:	mov    %rbp,%rdx
  6ff8c8:	call   *0x3430c2(%rip)        # a42990 <_DYNAMIC+0x3f8>
  6ff8ce:	movzbl 0x4d4(%rsp),%eax
  6ff8d6:	mov    0x38(%rsp),%rdx
  6ff8db:	mov    0x660(%rdx),%r8
  6ff8e2:	test   %r8,%r8
  6ff8e5:	je     6ff816 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1096>
  6ff8eb:	mov    0x8(%r15,%rbx,8),%rcx
  6ff8f0:	mov    0x668(%rdx),%rdx
  6ff8f7:	movzbl 0x30(%rsp),%ebx
  6ff8fc:	movzwl 0x1c2(%r8),%edi
  6ff904:	mov    %edi,%r10d
  6ff907:	shl    $0x5,%r10d
  6ff90b:	mov    $0xffffffffffffffff,%rsi
  6ff912:	xor    %r9d,%r9d
  6ff915:	data16 cs nopw 0x0(%rax,%rax,1)
  6ff920:	mov    %r10,%r11
  6ff923:	add    %r9,%r11
  6ff926:	je     6ff950 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x11d0>
  6ff928:	cmp    0x170(%r8,%rsi,8),%rcx
  6ff930:	seta   %r11b
  6ff934:	sbb    $0x0,%r11b
  6ff938:	add    $0xffffffffffffffe0,%r9
  6ff93c:	inc    %rsi
  6ff93f:	cmp    $0x1,%r11b
  6ff943:	je     6ff920 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x11a0>
  6ff945:	movzbl %r11b,%edi
  6ff949:	test   %edi,%edi
  6ff94b:	jne    6ff953 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x11d3>
  6ff94d:	jmp    6ff970 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x11f0>
  6ff94f:	nop
  6ff950:	mov    %rdi,%rsi
  6ff953:	sub    $0x1,%rdx
  6ff957:	jb     6ffa03 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1283>
  6ff95d:	mov    0x1c8(%r8,%rsi,8),%r8
  6ff965:	jmp    6ff8fc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x117c>
  6ff967:	nopw   0x0(%rax,%rax,1)
  6ff970:	sub    %r9,%r8
  6ff973:	add    $0xffffffffffffffe0,%r8
  6ff977:	movzbl %bl,%esi
  6ff97a:	movzbl %al,%ecx
  6ff97d:	lea    0x480(%rsp),%rdi
  6ff985:	lea    0x8b0(%rsp),%rdx
  6ff98d:	call   *0x34332d(%rip)        # a42cc0 <_DYNAMIC+0x728>
  6ff993:	movaps 0x80(%rsp),%xmm0
  6ff99b:	movaps %xmm0,0x760(%rsp)
  6ff9a3:	mov    0x58(%rsp),%rdi
  6ff9a8:	lea    0x760(%rsp),%rsi
  6ff9b0:	lea    0x480(%rsp),%rdx
  6ff9b8:	call   *0x343322(%rip)        # a42ce0 <_DYNAMIC+0x748>
  6ff9be:	test   $0x1,%al
  6ff9c0:	jne    6fff17 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1797>
  6ff9c6:	mov    0x58(%rsp),%rdi
  6ff9cb:	lea    0x80(%rsp),%rsi
  6ff9d3:	call   *0x34326f(%rip)        # a42c48 <_DYNAMIC+0x6b0>
  6ff9d9:	cmp    $0xff,%al
  6ff9db:	jne    6fff30 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x17b0>
  6ff9e1:	mov    $0x0,%eax
  6ff9e6:	mov    0x40(%rsp),%rdi
  6ff9eb:	dec    %rdi
  6ff9ee:	mov    0x38(%rsp),%r15
  6ff9f3:	mov    0x180(%rsp),%rbx
  6ff9fb:	jne    6ff480 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0xd00>
  6ffa01:	jmp    6ffa0b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x128b>
  6ffa03:	xor    %r8d,%r8d
  6ffa06:	jmp    6ff977 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x11f7>
  6ffa0b:	lea    0x2d8(%r15),%rax
  6ffa12:	mov    0x548(%r15),%r14
  6ffa19:	mov    0x568(%r15),%rbx
  6ffa20:	lea    0x588(%r15),%rcx
  6ffa27:	movq   $0xfffffffffffffffe,0x718(%rsp)
  6ffa33:	lea    0x2c0(%r15),%rdx
  6ffa3a:	lea    0x200(%r15),%rdi
  6ffa41:	lea    0x5f0(%r15),%rsi
  6ffa48:	mov    %rcx,0xb18(%rsp)
  6ffa50:	mov    %rdx,0xb20(%rsp)
  6ffa58:	mov    %rsi,0x180(%rsp)
  6ffa60:	mov    %rsi,0xb28(%rsp)
  6ffa68:	lea    0x1b0(%rsp),%rcx
  6ffa70:	mov    %rcx,0xb30(%rsp)
  6ffa78:	mov    %rax,0xb38(%rsp)
  6ffa80:	mov    %rdi,0x40(%rsp)
  6ffa85:	mov    %rdi,0xb40(%rsp)
  6ffa8d:	lea    0x718(%rsp),%rax
  6ffa95:	mov    %rax,0xb48(%rsp)
  6ffa9d:	cmpq   $0x0,0x598(%r15)
  6ffaa5:	je     7033c5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c45>
  6ffaab:	mov    0x590(%r15),%rax
  6ffab2:	movupd (%rax),%xmm0
  6ffab6:	movapd %xmm0,0x8b0(%rsp)
  6ffabf:	xorpd  %xmm0,%xmm0
  6ffac3:	movapd 0x100(%rsp),%xmm1
  6ffacc:	unpcklps %xmm0,%xmm1
  6ffacf:	movapd -0x6bead7(%rip),%xmm0        # 41000 <GCC_except_table0+0x11b8>
  6ffad7:	orpd   %xmm0,%xmm1
  6ffadb:	subpd  %xmm0,%xmm1
  6ffadf:	cvtpd2ps %xmm1,%xmm1
  6ffae3:	movapd %xmm1,%xmm0
  6ffae7:	shufps $0x55,%xmm1,%xmm0
  6ffaeb:	movaps %xmm1,0x100(%rsp)
  6ffaf3:	movss  0x7c(%rsp),%xmm2
  6ffaf9:	divss  %xmm2,%xmm1
  6ffafd:	divss  %xmm2,%xmm0
  6ffb01:	movl   $0x0,0x480(%rsp)
  6ffb0c:	movss  %xmm1,0x484(%rsp)
  6ffb15:	movl   $0x0,0x488(%rsp)
  6ffb20:	movss  %xmm0,0x48c(%rsp)
  6ffb29:	mov    $0x1,%r12b
  6ffb2c:	lea    0x32410d(%rip),%r8        # a23c40 <__frame_dummy_init_array_entry+0x1c50>
  6ffb33:	lea    0x8b0(%rsp),%rsi
  6ffb3b:	lea    0x480(%rsp),%rdx
  6ffb43:	lea    0xb18(%rsp),%rcx
  6ffb4b:	mov    $0x1,%bpl
  6ffb4e:	mov    0x58(%rsp),%rdi
  6ffb53:	call   *0x34318f(%rip)        # a42ce8 <_DYNAMIC+0x750>
  6ffb59:	test   $0x1,%al
  6ffb5b:	je     6ffbc3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1443>
  6ffb5d:	mov    0x48(%rsp),%rax
  6ffb62:	movq   $0x22,(%rax)
  6ffb69:	mov    %dl,0x8(%rax)
  6ffb6c:	mov    0x718(%rsp),%rax
  6ffb74:	mov    $0x1,%r12b
  6ffb77:	mov    $0x1,%bpl
  6ffb7a:	cmp    $0xfffffffffffffffe,%rax
  6ffb7e:	je     6fff45 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x17c5>
  6ffb84:	sub    $0xd,%rax
  6ffb88:	mov    $0x14,%ecx
  6ffb8d:	cmovge %rax,%rcx
  6ffb91:	cmp    $0x14,%rcx
  6ffb95:	je     700002 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1882>
  6ffb9b:	cmp    $0x19,%rcx
  6ffb9f:	jne    6fff45 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x17c5>
  6ffba5:	mov    0x720(%rsp),%rsi
  6ffbad:	test   %rsi,%rsi
  6ffbb0:	je     6fff45 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x17c5>
  6ffbb6:	lea    0x728(%rsp),%rax
  6ffbbe:	jmp    70001b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x189b>
  6ffbc3:	mov    0x548(%r15),%rax
  6ffbca:	sub    %r14,%rax
  6ffbcd:	mov    0x568(%r15),%rcx
  6ffbd4:	add    %rax,0x708(%r15)
  6ffbdb:	sub    %rbx,%rcx
  6ffbde:	add    %rcx,0x710(%r15)
  6ffbe5:	cmpl   $0xfffffffe,0x718(%rsp)
  6ffbed:	jne    6ffee1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1761>
  6ffbf3:	lea    0x480(%rsp),%rdi
  6ffbfb:	mov    $0x1,%bpl
  6ffbfe:	mov    %r15,%rsi
  6ffc01:	mov    $0x1,%edx
  6ffc06:	call   6f1d60 <<gpui::runtime::Runtime<text_column_public_control::Input>>::refresh_inspector>
  6ffc0b:	cmpl   $0xfffffffe,0x480(%rsp)
  6ffc13:	jne    6fffc9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1849>
  6ffc19:	mov    0x2d0(%r15),%rsi
  6ffc20:	lea    0x480(%rsp),%rdi
  6ffc28:	mov    $0x8,%ecx
  6ffc2d:	mov    $0x40,%r8d
  6ffc33:	xor    %edx,%edx
  6ffc35:	call   6f4e50 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6ffc3a:	mov    0x488(%rsp),%rdi
  6ffc42:	cmpl   $0x1,0x480(%rsp)
  6ffc4a:	je     703228 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4aa8>
  6ffc50:	mov    0x490(%rsp),%rax
  6ffc58:	mov    %rdi,0x1c0(%rsp)
  6ffc60:	mov    %rax,0x1c8(%rsp)
  6ffc68:	movq   $0x0,0x1d0(%rsp)
  6ffc74:	movq   $0x0,0x278(%rsp)
  6ffc80:	movq   $0x4,0x280(%rsp)
  6ffc8c:	movq   $0x0,0x288(%rsp)
  6ffc98:	mov    0x2d0(%r15),%rsi
  6ffc9f:	lea    0x480(%rsp),%rdi
  6ffca7:	mov    $0x8,%ecx
  6ffcac:	mov    $0x38,%r8d
  6ffcb2:	xor    %edx,%edx
  6ffcb4:	call   6f4e50 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6ffcb9:	mov    0x488(%rsp),%rdi
  6ffcc1:	cmpb   $0x0,0x480(%rsp)
  6ffcc9:	jne    70323e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4abe>
  6ffccf:	mov    0x490(%rsp),%rax
  6ffcd7:	mov    %rdi,0x1e8(%rsp)
  6ffcdf:	mov    %rax,0x1f0(%rsp)
  6ffce7:	movq   $0x0,0x1f8(%rsp)
  6ffcf3:	mov    0x658(%r15),%rbx
  6ffcfa:	test   %rbx,%rbx
  6ffcfd:	setne  0x2f(%rsp)
  6ffd02:	je     6ffd0b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x158b>
  6ffd04:	mov    0x2d0(%r15),%rbx
  6ffd0b:	lea    0x480(%rsp),%rdi
  6ffd13:	mov    $0x4,%ecx
  6ffd18:	mov    $0x10,%r8d
  6ffd1e:	mov    %rbx,%rsi
  6ffd21:	xor    %edx,%edx
  6ffd23:	call   6f4e50 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6ffd28:	mov    0x488(%rsp),%rdi
  6ffd30:	cmpb   $0x0,0x480(%rsp)
  6ffd38:	jne    703251 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4ad1>
  6ffd3e:	mov    0x490(%rsp),%rax
  6ffd46:	mov    %rdi,0x210(%rsp)
  6ffd4e:	mov    %rax,0x218(%rsp)
  6ffd56:	movq   $0x0,0x220(%rsp)
  6ffd62:	lea    0x480(%rsp),%rdi
  6ffd6a:	mov    $0x4,%ecx
  6ffd6f:	mov    $0x10,%r8d
  6ffd75:	mov    %rbx,%rsi
  6ffd78:	xor    %edx,%edx
  6ffd7a:	call   6f4e50 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6ffd7f:	mov    0x488(%rsp),%rdi
  6ffd87:	cmpb   $0x0,0x480(%rsp)
  6ffd8f:	jne    703264 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4ae4>
  6ffd95:	mov    0x490(%rsp),%rax
  6ffd9d:	mov    %rdi,0x228(%rsp)
  6ffda5:	mov    %rax,0x230(%rsp)
  6ffdad:	movq   $0x0,0x238(%rsp)
  6ffdb9:	lea    0x480(%rsp),%rdi
  6ffdc1:	mov    $0x1,%ecx
  6ffdc6:	mov    $0x1,%r8d
  6ffdcc:	mov    %rbx,%rsi
  6ffdcf:	xor    %edx,%edx
  6ffdd1:	call   6f4e50 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6ffdd6:	mov    0x488(%rsp),%rdi
  6ffdde:	cmpb   $0x0,0x480(%rsp)
  6ffde6:	jne    703277 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4af7>
  6ffdec:	mov    0x490(%rsp),%rax
  6ffdf4:	mov    %rdi,0x188(%rsp)
  6ffdfc:	mov    %rax,0x190(%rsp)
  6ffe04:	movq   $0x0,0x198(%rsp)
  6ffe10:	lea    0x480(%rsp),%rdi
  6ffe18:	mov    $0x4,%ecx
  6ffe1d:	mov    $0x4,%r8d
  6ffe23:	mov    %rbx,%rsi
  6ffe26:	xor    %edx,%edx
  6ffe28:	call   6f4e50 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6ffe2d:	mov    0x488(%rsp),%rdi
  6ffe35:	cmpb   $0x0,0x480(%rsp)
  6ffe3d:	jne    70328a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b0a>
  6ffe43:	mov    0x490(%rsp),%rax
  6ffe4b:	mov    %rdi,0x140(%rsp)
  6ffe53:	mov    %rax,0x148(%rsp)
  6ffe5b:	movq   $0x0,0x150(%rsp)
  6ffe67:	movq   $0x0,0x338(%rsp)
  6ffe73:	movq   $0x0,0x348(%rsp)
  6ffe7f:	mov    0x640(%r15),%rcx
  6ffe86:	test   %rcx,%rcx
  6ffe89:	je     70002e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x18ae>
  6ffe8f:	mov    0x2d0(%r15),%rsi
  6ffe96:	mov    0x670(%r15),%rdx
  6ffe9d:	mov    $0x1,%r12b
  6ffea0:	lea    0x760(%rsp),%rdi
  6ffea8:	mov    $0x1,%r13b
  6ffeab:	mov    $0x1,%bpl
  6ffeae:	call   6da500 <<gpui::runtime::Runtime<text_column_public_control::Input>>::metadata_sheet::{closure#0}>
  6ffeb3:	jmp    70003a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x18ba>
  6ffeb8:	mov    0x48(%rsp),%rax
  6ffebd:	movq   $0x23,(%rax)
  6ffec4:	mov    %r14d,0x8(%rax)
  6ffec8:	mov    %ebp,0xc(%rax)
  6ffecb:	mov    0xbd0(%rsp),%rbx
  6ffed3:	cmp    $0x2,%ebx
  6ffed6:	jne    6fffaa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x182a>
  6ffedc:	jmp    6fffb7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1837>
  6ffee1:	mov    0x748(%rsp),%rax
  6ffee9:	mov    0x48(%rsp),%rcx
  6ffeee:	mov    %rax,0x30(%rcx)
  6ffef2:	movups 0x718(%rsp),%xmm0
  6ffefa:	movups 0x728(%rsp),%xmm1
  6fff02:	movups 0x738(%rsp),%xmm2
  6fff0a:	movups %xmm2,0x20(%rcx)
  6fff0e:	movups %xmm1,0x10(%rcx)
  6fff12:	movups %xmm0,(%rcx)
  6fff15:	jmp    6fff3f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x17bf>
  6fff17:	mov    0x48(%rsp),%rax
  6fff1c:	movq   $0x22,(%rax)
  6fff23:	mov    %dl,0x8(%rax)
  6fff26:	jmp    6fff3f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x17bf>
  6fff28:	movzbl 0x761(%rsp),%eax
  6fff30:	mov    0x48(%rsp),%rcx
  6fff35:	movq   $0x22,(%rcx)
  6fff3c:	mov    %al,0x8(%rcx)
  6fff3f:	mov    $0x1,%r12b
  6fff42:	mov    $0x1,%bpl
  6fff45:	cmpq   $0x0,0x1b0(%rsp)
  6fff4e:	je     6fff5d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x17dd>
  6fff50:	mov    0x1b8(%rsp),%rdi
  6fff58:	call   6c5ca0 <core::ptr::drop_glue::<gpui_canvas::text::TextShaper>>
  6fff5d:	test   %r12b,%r12b
  6fff60:	je     6fff7a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x17fa>
  6fff62:	cmpq   $0xffffffffffffffff,0x160(%rsp)
  6fff6b:	je     6fff7a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x17fa>
  6fff6d:	lea    0x160(%rsp),%rdi
  6fff75:	call   6c1730 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  6fff7a:	mov    0x118(%rsp),%rax
  6fff82:	test   %rax,%rax
  6fff85:	je     6fff9b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x181b>
  6fff87:	lock decq (%rax)
  6fff8b:	jne    6fff9b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x181b>
  6fff8d:	lea    0x118(%rsp),%rdi
  6fff95:	call   *0x342935(%rip)        # a428d0 <_DYNAMIC+0x338>
  6fff9b:	cmpl   $0x2,0xbd0(%rsp)
  6fffa3:	je     6fffb7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1837>
  6fffa5:	test   %bpl,%bpl
  6fffa8:	je     6fffb7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1837>
  6fffaa:	lea    0xbd0(%rsp),%rdi
  6fffb2:	call   6c6240 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  6fffb7:	add    $0xdb8,%rsp
  6fffbe:	pop    %rbx
  6fffbf:	pop    %r12
  6fffc1:	pop    %r13
  6fffc3:	pop    %r14
  6fffc5:	pop    %r15
  6fffc7:	pop    %rbp
  6fffc8:	ret
  6fffc9:	mov    0x4b0(%rsp),%rax
  6fffd1:	mov    0x48(%rsp),%rcx
  6fffd6:	mov    %rax,0x30(%rcx)
  6fffda:	movups 0x480(%rsp),%xmm0
  6fffe2:	movups 0x490(%rsp),%xmm1
  6fffea:	movups 0x4a0(%rsp),%xmm2
  6ffff2:	movups %xmm2,0x20(%rcx)
  6ffff6:	movups %xmm1,0x10(%rcx)
  6ffffa:	movups %xmm0,(%rcx)
  6ffffd:	jmp    6ffb6c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x13ec>
  700002:	mov    0x730(%rsp),%rsi
  70000a:	test   %rsi,%rsi
  70000d:	je     6fff45 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x17c5>
  700013:	lea    0x738(%rsp),%rax
  70001b:	mov    (%rax),%rdi
  70001e:	mov    $0x1,%edx
  700023:	call   *0x3427d7(%rip)        # a42800 <_DYNAMIC+0x268>
  700029:	jmp    6fff45 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x17c5>
  70002e:	movq   $0xffffffffffffffff,0x760(%rsp)
  70003a:	lea    0x5f0(%r15),%rax
  700041:	mov    (%rax),%rsi
  700044:	test   %rsi,%rsi
  700047:	je     7000bc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x193c>
  700049:	mov    $0x1,%r12b
  70004c:	lea    0x480(%rsp),%rdi
  700054:	mov    $0x1,%r14b
  700057:	mov    $0x1,%r15b
  70005a:	mov    $0x1,%bpl
  70005d:	call   *0x342c8d(%rip)        # a42cf0 <_DYNAMIC+0x758>
  700063:	mov    0x480(%rsp),%rax
  70006b:	mov    0x488(%rsp),%rsi
  700073:	movups 0x490(%rsp),%xmm0
  70007b:	movaps %xmm0,0x80(%rsp)
  700083:	movups 0x4a0(%rsp),%xmm1
  70008b:	movaps %xmm1,0x8b0(%rsp)
  700093:	mov    0x4b0(%rsp),%rcx
  70009b:	mov    %rcx,0x8c0(%rsp)
  7000a3:	movaps %xmm0,0x440(%rsp)
  7000ab:	cmp    $0xfffffffffffffffe,%rax
  7000af:	jne    701f92 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3812>
  7000b5:	mov    0x38(%rsp),%r15
  7000ba:	jmp    7000c3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1943>
  7000bc:	mov    $0xffffffffffffffff,%rsi
  7000c3:	movaps 0x440(%rsp),%xmm0
  7000cb:	movups %xmm0,0x800(%rsp)
  7000d3:	mov    %rsi,0x258(%rsp)
  7000db:	mov    %rsi,0x7f8(%rsp)
  7000e3:	cmpb   $0x0,0x2f(%rsp)
  7000e8:	je     700182 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1a02>
  7000ee:	lea    0x480(%rsp),%rdi
  7000f6:	lea    0x1e8(%rsp),%rdx
  7000fe:	lea    0x140(%rsp),%rcx
  700106:	mov    %r15,%rsi
  700109:	call   6c8f20 <gpui::runtime::scroll::geometry::<text_column_public_control::Input>>
  70010e:	mov    0x480(%rsp),%rax
  700116:	movups 0x488(%rsp),%xmm0
  70011e:	movaps %xmm0,0x8b0(%rsp)
  700126:	movups 0x498(%rsp),%xmm0
  70012e:	movaps %xmm0,0x8c0(%rsp)
  700136:	movups 0x4a8(%rsp),%xmm0
  70013e:	movaps %xmm0,0x8d0(%rsp)
  700146:	cmp    $0xfffffffffffffffe,%rax
  70014a:	jne    70204f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x38cf>
  700150:	movaps 0x8b0(%rsp),%xmm0
  700158:	movaps 0x8c0(%rsp),%xmm1
  700160:	movaps 0x8d0(%rsp),%xmm2
  700168:	movaps %xmm2,0x390(%rsp)
  700170:	movaps %xmm1,0x380(%rsp)
  700178:	movaps %xmm0,0x370(%rsp)
  700180:	jmp    7001bd <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1a3d>
  700182:	movq   $0x0,0x370(%rsp)
  70018e:	movq   $0x8,0x378(%rsp)
  70019a:	xorps  %xmm0,%xmm0
  70019d:	movups %xmm0,0x380(%rsp)
  7001a5:	movq   $0x8,0x390(%rsp)
  7001b1:	movq   $0x0,0x398(%rsp)
  7001bd:	lea    0xba8(%rsp),%rdi
  7001c5:	mov    %r15,%rsi
  7001c8:	call   6f1ba0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::inspector_display>
  7001cd:	mov    0x40(%rsp),%rdi
  7001d2:	call   *0x342b20(%rip)        # a42cf8 <_DYNAMIC+0x760>
  7001d8:	movzbl 0xba8(%rsp),%eax
  7001e0:	movq   $0xffffffffffffffff,0x308(%rsp)
  7001ec:	mov    %al,0x7a(%rsp)
  7001f0:	test   %al,%al
  7001f2:	je     700204 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1a84>
  7001f4:	mov    0xbb0(%rsp),%rax
  7001fc:	mov    %rax,0x308(%rsp)
  700204:	cmpl   $0x2,0xbd0(%rsp)
  70020c:	lea    0xbd0(%rsp),%rsi
  700214:	cmove  %r15,%rsi
  700218:	lea    0x8b0(%rsp),%rdi
  700220:	call   *0x342ada(%rip)        # a42d00 <_DYNAMIC+0x768>
  700226:	movups -0x6c010d(%rip),%xmm0        # 40120 <GCC_except_table0+0x2d8>
  70022d:	movaps %xmm0,0x480(%rsp)
  700235:	lea    0x8b0(%rsp),%rdi
  70023d:	lea    0x480(%rsp),%rsi
  700245:	call   *0x342abd(%rip)        # a42d08 <_DYNAMIC+0x770>
  70024b:	incq   0x720(%r15)
  700252:	lea    0x640(%r15),%rax
  700259:	mov    %rax,0x260(%rsp)
  700261:	mov    0x2d0(%r15),%rax
  700268:	mov    %rax,0x2b0(%rsp)
  700270:	test   %rax,%rax
  700273:	je     701fe6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3866>
  700279:	movss  0x7c(%rsp),%xmm0
  70027f:	cvtss2sd %xmm0,%xmm0
  700283:	movsd  %xmm0,0x7c8(%rsp)
  70028c:	xorps  %xmm0,%xmm0
  70028f:	unpcklpd 0x100(%rsp),%xmm0
  700298:	movaps %xmm0,0x850(%rsp)
  7002a0:	xor    %edx,%edx
  7002a2:	lea    0x3239ef(%rip),%rax        # a23c98 <__frame_dummy_init_array_entry+0x1ca8>
  7002a9:	mov    %rax,0x250(%rsp)
  7002b1:	lea    0x3239f8(%rip),%rax        # a23cb0 <__frame_dummy_init_array_entry+0x1cc0>
  7002b8:	mov    %rax,0x70(%rsp)
  7002bd:	movabs $0x8000000000000000,%rax
  7002c7:	inc    %rax
  7002ca:	mov    %rax,0x7c0(%rsp)
  7002d2:	lea    0x323a37(%rip),%rax        # a23d10 <__frame_dummy_init_array_entry+0x1d20>
  7002d9:	mov    %rax,0x2f8(%rsp)
  7002e1:	movq   $0x0,0x178(%rsp)
  7002ed:	lea    0x0(,%rdx,8),%rax
  7002f5:	lea    (%rax,%rax,4),%r13
  7002f9:	imul   $0x58,%rdx,%rax
  7002fd:	mov    %rax,0x300(%rsp)
  700305:	mov    %rdx,%rsi
  700308:	shl    $0x4,%rsi
  70030c:	jmp    70035c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1bdc>
  70030e:	mov    0x148(%rsp),%rax
  700316:	mov    %ebx,(%rax,%r14,4)
  70031a:	inc    %r14
  70031d:	mov    %r14,0x150(%rsp)
  700325:	add    $0x28,%r13
  700329:	addq   $0x58,0x300(%rsp)
  700332:	mov    0x7e0(%rsp),%rsi
  70033a:	add    $0x10,%rsi
  70033e:	mov    0x7d8(%rsp),%rax
  700346:	mov    %rax,%rdx
  700349:	cmp    0x2b0(%rsp),%rax
  700351:	mov    0x38(%rsp),%r15
  700356:	jae    701ff2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3872>
  70035c:	cmp    %rdx,0x308(%rsp)
  700364:	mov    %rdx,0x50(%rsp)
  700369:	jne    7003f1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1c71>
  70036f:	cmpb   $0x0,0x7a(%rsp)
  700374:	je     7032ca <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b4a>
  70037a:	mov    %rsi,%rbx
  70037d:	mov    0x1c8(%rsp),%rdx
  700385:	mov    0x1d0(%rsp),%rcx
  70038d:	mov    0x280(%rsp),%r8
  700395:	mov    0x288(%rsp),%r9
  70039d:	movups 0x2e0(%r15),%xmm0
  7003a5:	movups 0x590(%r15),%xmm1
  7003ad:	movups %xmm1,0x18(%rsp)
  7003b2:	mov    0x58(%rsp),%rax
  7003b7:	mov    %rax,0x10(%rsp)
  7003bc:	movups %xmm0,(%rsp)
  7003c0:	lea    0x480(%rsp),%rdi
  7003c8:	lea    0xbb0(%rsp),%rsi
  7003d0:	call   *0x34293a(%rip)        # a42d10 <_DYNAMIC+0x778>
  7003d6:	cmpl   $0xfffffffe,0x480(%rsp)
  7003de:	jne    702f05 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4785>
  7003e4:	mov    0x38(%rsp),%r15
  7003e9:	mov    0x50(%rsp),%rdx
  7003ee:	mov    %rbx,%rsi
  7003f1:	mov    0x598(%r15),%rcx
  7003f8:	cmp    %rcx,%rdx
  7003fb:	jae    7034a7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d27>
  700401:	mov    0x590(%r15),%rax
  700408:	mov    %rsi,0x7e0(%rsp)
  700410:	movups (%rax,%rsi,1),%xmm0
  700414:	movaps %xmm0,0x80(%rsp)
  70041c:	lea    0x480(%rsp),%rdi
  700424:	mov    0x58(%rsp),%rsi
  700429:	lea    0x80(%rsp),%rdx
  700431:	call   *0x342549(%rip)        # a42980 <_DYNAMIC+0x3e8>
  700437:	cmpb   $0x0,0x480(%rsp)
  70043f:	jne    702e9b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x471b>
  700445:	mov    0x50(%rsp),%r9
  70044a:	lea    0x1(%r9),%rax
  70044e:	mov    0x38(%rsp),%r8
  700453:	mov    0x2d0(%r8),%rsi
  70045a:	cmp    %rsi,%rax
  70045d:	mov    %rax,0x7d8(%rsp)
  700465:	jae    70048f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1d0f>
  700467:	mov    0x2c8(%r8),%rax
  70046e:	mov    0x40(%rax,%r13,1),%eax
  700473:	mov    $0xffffffff,%ecx
  700478:	cmp    %rcx,%rax
  70047b:	setne  %cl
  70047e:	cmp    %rax,%r9
  700481:	sete   %al
  700484:	and    %cl,%al
  700486:	mov    %eax,0x1e4(%rsp)
  70048d:	jmp    70049a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1d1a>
  70048f:	movl   $0x0,0x1e4(%rsp)
  70049a:	movsd  0x4c4(%rsp),%xmm0
  7004a3:	movaps %xmm0,0x880(%rsp)
  7004ab:	movups 0x494(%rsp),%xmm0
  7004b3:	movaps %xmm0,0x870(%rsp)
  7004bb:	movss  0x498(%rsp),%xmm0
  7004c4:	movss  %xmm0,0xe0(%rsp)
  7004cd:	movups 0x4a4(%rsp),%xmm0
  7004d5:	movaps %xmm0,0x2d0(%rsp)
  7004dd:	movss  0x4ac(%rsp),%xmm0
  7004e6:	movaps %xmm0,0x750(%rsp)
  7004ee:	movss  0x4a8(%rsp),%xmm0
  7004f7:	movss  %xmm0,0x2cc(%rsp)
  700500:	movsd  0x4cc(%rsp),%xmm0
  700509:	movaps %xmm0,0x360(%rsp)
  700511:	movsd  0x4d4(%rsp),%xmm0
  70051a:	movaps %xmm0,0x860(%rsp)
  700522:	mov    0x40(%rsp),%rax
  700527:	mov    (%rax),%rax
  70052a:	lea    -0x6be7e5(%rip),%rcx        # 41d4c <GCC_except_table0+0x1f04>
  700531:	movslq (%rcx,%rax,4),%rax
  700535:	add    %rcx,%rax
  700538:	jmp    *%rax
  70053a:	movups -0x6b32dd(%rip),%xmm0        # 4d264 <GCC_except_table0+0xd41c>
  700541:	movaps %xmm0,0x4c0(%rsp)
  700549:	movups -0x6b32fc(%rip),%xmm0        # 4d254 <GCC_except_table0+0xd40c>
  700550:	movaps %xmm0,0x4b0(%rsp)
  700558:	movups -0x6b331b(%rip),%xmm0        # 4d244 <GCC_except_table0+0xd3fc>
  70055f:	movaps %xmm0,0x4a0(%rsp)
  700567:	movups -0x6b333a(%rip),%xmm0        # 4d234 <GCC_except_table0+0xd3ec>
  70056e:	movaps %xmm0,0x490(%rsp)
  700576:	movups -0x6b3359(%rip),%xmm0        # 4d224 <GCC_except_table0+0xd3dc>
  70057d:	movaps %xmm0,0x480(%rsp)
  700585:	movabs $0x3000100000000,%rax
  70058f:	mov    %rax,0x4d0(%rsp)
  700597:	jmp    70069c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1f1c>
  70059c:	mov    0x220(%r8),%rcx
  7005a3:	cmp    %rcx,%r9
  7005a6:	jae    70345a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4cda>
  7005ac:	mov    0x210(%r8),%rcx
  7005b3:	mov    0x218(%r8),%rax
  7005ba:	movzbl (%rax,%r9,1),%eax
  7005bf:	cmp    %rax,%rcx
  7005c2:	jbe    703463 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4ce3>
  7005c8:	mov    0x208(%r8),%rcx
  7005cf:	imul   $0x58,%rax,%rax
  7005d3:	mov    0x50(%rcx,%rax,1),%rdx
  7005d8:	mov    %rdx,0x4d0(%rsp)
  7005e0:	movups 0x40(%rcx,%rax,1),%xmm0
  7005e5:	movaps %xmm0,0x4c0(%rsp)
  7005ed:	movups (%rcx,%rax,1),%xmm0
  7005f1:	movups 0x10(%rcx,%rax,1),%xmm1
  7005f6:	movups 0x20(%rcx,%rax,1),%xmm2
  7005fb:	movupd 0x30(%rcx,%rax,1),%xmm3
  700601:	jmp    70067b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1efb>
  700603:	mov    0x208(%r8),%rsi
  70060a:	lea    0x480(%rsp),%rdi
  700612:	mov    %r9,%rdx
  700615:	call   *0x342375(%rip)        # a42990 <_DYNAMIC+0x3f8>
  70061b:	mov    0x38(%rsp),%r8
  700620:	mov    0x2d0(%r8),%rsi
  700627:	mov    0x50(%rsp),%r9
  70062c:	jmp    70069c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1f1c>
  70062e:	mov    0x218(%r8),%rcx
  700635:	cmp    %rcx,%r9
  700638:	jae    703471 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4cf1>
  70063e:	mov    0x210(%r8),%rax
  700645:	mov    0x300(%rsp),%rdx
  70064d:	mov    0x50(%rax,%rdx,1),%rcx
  700652:	mov    %rcx,0x4d0(%rsp)
  70065a:	movups 0x40(%rax,%rdx,1),%xmm0
  70065f:	movaps %xmm0,0x4c0(%rsp)
  700667:	movups (%rax,%rdx,1),%xmm0
  70066b:	movups 0x10(%rax,%rdx,1),%xmm1
  700670:	movups 0x20(%rax,%rdx,1),%xmm2
  700675:	movupd 0x30(%rax,%rdx,1),%xmm3
  70067b:	movapd %xmm3,0x4b0(%rsp)
  700684:	movaps %xmm2,0x4a0(%rsp)
  70068c:	movaps %xmm1,0x490(%rsp)
  700694:	movaps %xmm0,0x480(%rsp)
  70069c:	cmp    %rsi,%r9
  70069f:	jae    7033e1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c61>
  7006a5:	mov    0x2c8(%r8),%rdi
  7006ac:	mov    0x18(%rdi,%r13,1),%edx
  7006b1:	mov    $0xffffffff,%eax
  7006b6:	cmp    %rax,%rdx
  7006b9:	je     7006da <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1f5a>
  7006bb:	call   6db360 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}>
  7006c0:	mov    %eax,0xf4(%rsp)
  7006c7:	mov    0x38(%rsp),%r8
  7006cc:	mov    0x2d0(%r8),%rsi
  7006d3:	mov    0x50(%rsp),%r9
  7006d8:	jmp    7006e5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1f65>
  7006da:	movl   $0x0,0xf4(%rsp)
  7006e5:	cmp    %rsi,%r9
  7006e8:	jae    7033f0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c70>
  7006ee:	mov    0x2c8(%r8),%rax
  7006f5:	mov    0x18(%rax,%r13,1),%ebx
  7006fa:	mov    $0xffffffff,%ecx
  7006ff:	cmp    %rcx,%rbx
  700702:	je     70071d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1f9d>
  700704:	cmp    %rbx,%rsi
  700707:	jbe    70340e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c8e>
  70070d:	lea    (%rbx,%rbx,4),%rcx
  700711:	mov    (%rax,%rcx,8),%rcx
  700715:	mov    %rcx,0x7d0(%rsp)
  70071d:	mov    0x260(%rsp),%rcx
  700725:	mov    (%rcx),%rcx
  700728:	xorps  %xmm0,%xmm0
  70072b:	movss  %xmm0,0xdc(%rsp)
  700734:	test   %rcx,%rcx
  700737:	je     700769 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1fe9>
  700739:	mov    0x100(%rcx),%rdi
  700740:	test   %rdi,%rdi
  700743:	je     700769 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1fe9>
  700745:	mov    (%rax,%r13,1),%rsi
  700749:	call   *0x342539(%rip)        # a42c88 <_DYNAMIC+0x6f0>
  70074f:	movss  %xmm0,0xdc(%rsp)
  700758:	mov    0x38(%rsp),%r8
  70075d:	mov    0x2d0(%r8),%rsi
  700764:	mov    0x50(%rsp),%r9
  700769:	cmp    %rsi,%r9
  70076c:	jae    7033ff <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c7f>
  700772:	mov    0x2c8(%r8),%rax
  700779:	mov    %rax,0x30(%rsp)
  70077e:	mov    0x18(%rax,%r13,1),%eax
  700783:	mov    $0xffffffff,%ecx
  700788:	cmp    %rcx,%rax
  70078b:	je     7008a7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2127>
  700791:	mov    0x1f8(%rsp),%rcx
  700799:	cmp    %rax,%rcx
  70079c:	jbe    703422 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4ca2>
  7007a2:	imul   $0x38,%rax,%rax
  7007a6:	mov    0x1f0(%rsp),%rcx
  7007ae:	movups (%rcx,%rax,1),%xmm0
  7007b2:	movaps %xmm0,0x60(%rsp)
  7007b7:	movups 0x10(%rcx,%rax,1),%xmm0
  7007bc:	movaps %xmm0,0x200(%rsp)
  7007c4:	movups 0x20(%rcx,%rax,1),%xmm0
  7007c9:	movaps %xmm0,0x350(%rsp)
  7007d1:	movzbl 0x30(%rcx,%rax,1),%ebp
  7007d6:	mov    0x31(%rcx,%rax,1),%edx
  7007da:	mov    %edx,0xc0(%rsp)
  7007e1:	mov    0x34(%rcx,%rax,1),%eax
  7007e5:	mov    %eax,0xc3(%rsp)
  7007ec:	cmp    $0xffffffff,%ebx
  7007ef:	je     7031dc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4a5c>
  7007f5:	lea    0x80(%rsp),%rdi
  7007fd:	lea    0x370(%rsp),%rsi
  700805:	mov    0x7d0(%rsp),%rdx
  70080d:	call   *0x342505(%rip)        # a42d18 <_DYNAMIC+0x780>
  700813:	cmpl   $0x1,0x80(%rsp)
  70081b:	jne    7008db <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x215b>
  700821:	movq   0x88(%rsp),%xmm0
  70082a:	movq   0x90(%rsp),%xmm1
  700833:	movq   %xmm0,%rax
  700838:	movq   %xmm1,%rcx
  70083d:	movabs $0x7fffffffffffffff,%rdx
  700847:	and    %rdx,%rax
  70084a:	movabs $0x7fefffffffffffff,%rsi
  700854:	cmp    %rsi,%rax
  700857:	setg   %al
  70085a:	and    %rdx,%rcx
  70085d:	cmp    %rsi,%rcx
  700860:	setg   %cl
  700863:	or     %al,%cl
  700865:	or     %bpl,%cl
  700868:	and    $0x1,%cl
  70086b:	punpcklqdq %xmm1,%xmm1
  70086f:	pxor   -0x6bf537(%rip),%xmm1        # 41340 <GCC_except_table0+0x14f8>
  700877:	movapd 0x200(%rsp),%xmm3
  700880:	mulpd  %xmm3,%xmm1
  700884:	punpcklqdq %xmm0,%xmm0
  700888:	movapd 0x60(%rsp),%xmm2
  70088e:	mulpd  %xmm2,%xmm0
  700892:	subpd  %xmm0,%xmm1
  700896:	movapd 0x350(%rsp),%xmm0
  70089f:	addpd  %xmm1,%xmm0
  7008a3:	mov    %ecx,%ebp
  7008a5:	jmp    70090e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x218e>
  7008a7:	movsd  0x7c8(%rsp),%xmm0
  7008b0:	movsd  %xmm0,0x440(%rsp)
  7008b9:	lea    0x471(%rsp),%rax
  7008c1:	xorps  %xmm1,%xmm1
  7008c4:	movups %xmm1,-0x29(%rax)
  7008c8:	movsd  %xmm0,0x458(%rsp)
  7008d1:	movaps %xmm1,-0x11(%rax)
  7008d5:	movb   $0x0,-0x1(%rax)
  7008d9:	jmp    700931 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x21b1>
  7008db:	mov    0xc0(%rsp),%eax
  7008e2:	mov    0xc3(%rsp),%ecx
  7008e9:	lea    0x471(%rsp),%rdx
  7008f1:	mov    %ecx,0x3(%rdx)
  7008f4:	mov    %eax,(%rdx)
  7008f6:	movapd 0x60(%rsp),%xmm2
  7008fc:	movapd 0x200(%rsp),%xmm3
  700905:	movapd 0x350(%rsp),%xmm0
  70090e:	movapd %xmm2,0x440(%rsp)
  700917:	movapd %xmm3,0x450(%rsp)
  700920:	movapd %xmm0,0x460(%rsp)
  700929:	mov    %bpl,0x470(%rsp)
  700931:	movaps -0x6bf2e8(%rip),%xmm0        # 41650 <GCC_except_table0+0x1808>
  700938:	movaps %xmm0,0xc0(%rsp)
  700940:	movaps 0x880(%rsp),%xmm0
  700948:	movlps %xmm0,0xd0(%rsp)
  700950:	lea    0x80(%rsp),%rdi
  700958:	lea    0x440(%rsp),%rsi
  700960:	lea    0xc0(%rsp),%rdx
  700968:	call   *0x34201a(%rip)        # a42988 <_DYNAMIC+0x3f0>
  70096e:	lea    0xae0(%rsp),%rdi
  700976:	lea    0x80(%rsp),%rsi
  70097e:	lea    0x4bc(%rsp),%rdx
  700986:	call   *0x341ffc(%rip)        # a42988 <_DYNAMIC+0x3f0>
  70098c:	mov    0x1f8(%rsp),%rbx
  700994:	cmp    0x1e8(%rsp),%rbx
  70099c:	jne    7009ab <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x222b>
  70099e:	lea    0x1e8(%rsp),%rdi
  7009a6:	call   6f4c50 <<alloc::raw_vec::RawVec<gpui::semantic::AnnotationDraft>>::grow_one>
  7009ab:	mov    0x1f0(%rsp),%rax
  7009b3:	imul   $0x38,%rbx,%rcx
  7009b7:	mov    0xb10(%rsp),%rdx
  7009bf:	mov    %rdx,0x30(%rax,%rcx,1)
  7009c4:	movups 0xae0(%rsp),%xmm0
  7009cc:	movups 0xaf0(%rsp),%xmm1
  7009d4:	movups 0xb00(%rsp),%xmm2
  7009dc:	movups %xmm2,0x20(%rax,%rcx,1)
  7009e1:	movups %xmm1,0x10(%rax,%rcx,1)
  7009e6:	movups %xmm0,(%rax,%rcx,1)
  7009ea:	inc    %rbx
  7009ed:	mov    %rbx,0x1f8(%rsp)
  7009f5:	movups 0xae0(%rsp),%xmm0
  7009fd:	movaps %xmm0,0x200(%rsp)
  700a05:	movups 0xaf0(%rsp),%xmm0
  700a0d:	movaps %xmm0,0x350(%rsp)
  700a15:	movups 0xb00(%rsp),%xmm0
  700a1d:	movaps %xmm0,0x60(%rsp)
  700a22:	lea    0xae0(%rsp),%rdi
  700a2a:	call   *0x3422f0(%rip)        # a42d20 <_DYNAMIC+0x788>
  700a30:	xor    %ebx,%ebx
  700a32:	test   %al,%al
  700a34:	je     700b5f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x23df>
  700a3a:	cvtpd2ps 0x350(%rsp),%xmm0
  700a43:	cvtpd2ps 0x200(%rsp),%xmm1
  700a4c:	cvtpd2ps 0x60(%rsp),%xmm2
  700a52:	unpcklpd %xmm0,%xmm1
  700a56:	movd   %xmm1,%eax
  700a5a:	and    $0x7fffffff,%eax
  700a5f:	movapd %xmm1,%xmm0
  700a63:	shufps $0x55,%xmm1,%xmm0
  700a67:	movd   %xmm0,%ecx
  700a6b:	and    $0x7fffffff,%ecx
  700a71:	cmp    $0x7f800000,%ecx
  700a77:	setge  %cl
  700a7a:	movdqa %xmm1,%xmm0
  700a7e:	punpckhqdq %xmm1,%xmm0
  700a82:	movd   %xmm0,%edx
  700a86:	and    $0x7fffffff,%edx
  700a8c:	cmp    $0x7f800000,%edx
  700a92:	setge  %dl
  700a95:	movaps %xmm1,%xmm0
  700a98:	shufps $0xff,%xmm1,%xmm0
  700a9c:	movd   %xmm0,%esi
  700aa0:	and    $0x7fffffff,%esi
  700aa6:	cmp    $0x7f800000,%esi
  700aac:	setge  %sil
  700ab0:	movd   %xmm2,%edi
  700ab4:	and    $0x7fffffff,%edi
  700aba:	cmp    $0x7f800000,%edi
  700ac0:	setge  %dil
  700ac4:	movapd %xmm2,%xmm0
  700ac8:	shufps $0x55,%xmm2,%xmm0
  700acc:	movd   %xmm0,%r8d
  700ad1:	and    $0x7fffffff,%r8d
  700ad8:	cmp    $0x7f800000,%r8d
  700adf:	setl   %r8b
  700ae3:	cmp    $0x7f7fffff,%eax
  700ae8:	mov    0x30(%rsp),%r9
  700aed:	jg     700b64 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x23e4>
  700aef:	test   %cl,%cl
  700af1:	jne    700b64 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x23e4>
  700af3:	test   %dl,%dl
  700af5:	jne    700b64 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x23e4>
  700af7:	test   %sil,%sil
  700afa:	jne    700b64 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x23e4>
  700afc:	test   %dil,%dil
  700aff:	jne    700b64 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x23e4>
  700b01:	test   %r8b,%r8b
  700b04:	je     700b64 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x23e4>
  700b06:	movaps %xmm1,0x60(%rsp)
  700b0b:	movaps %xmm1,0x80(%rsp)
  700b13:	movaps %xmm2,0x200(%rsp)
  700b1b:	movlpd %xmm2,0x90(%rsp)
  700b24:	lea    0x80(%rsp),%rdi
  700b2c:	call   *0x3421f6(%rip)        # a42d28 <_DYNAMIC+0x790>
  700b32:	test   %al,%al
  700b34:	mov    0x30(%rsp),%r9
  700b39:	je     700b64 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x23e4>
  700b3b:	movaps 0x60(%rsp),%xmm0
  700b40:	movups %xmm0,0x298(%rsp)
  700b48:	movaps 0x200(%rsp),%xmm0
  700b50:	movlps %xmm0,0x2a8(%rsp)
  700b58:	mov    $0x1,%ebx
  700b5d:	jmp    700b64 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x23e4>
  700b5f:	mov    0x30(%rsp),%r9
  700b64:	mov    %ebx,0x294(%rsp)
  700b6b:	xorps  %xmm0,%xmm0
  700b6e:	unpcklpd 0x360(%rsp),%xmm0
  700b77:	movups %xmm0,0x318(%rsp)
  700b7f:	cmpb   $0x0,0x2f(%rsp)
  700b84:	je     700bf4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2474>
  700b86:	mov    0x18(%r9,%r13,1),%eax
  700b8b:	mov    $0xffffffff,%ecx
  700b90:	cmp    %rcx,%rax
  700b93:	je     700c1d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x249d>
  700b99:	mov    0x220(%rsp),%rcx
  700ba1:	cmp    %rax,%rcx
  700ba4:	jbe    703430 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4cb0>
  700baa:	mov    0x218(%rsp),%rcx
  700bb2:	mov    %rax,%rdx
  700bb5:	shl    $0x4,%rdx
  700bb9:	movups (%rcx,%rdx,1),%xmm1
  700bbd:	xorps  %xmm0,%xmm0
  700bc0:	unpcklpd 0x100(%rsp),%xmm0
  700bc9:	movups %xmm0,0x80(%rsp)
  700bd1:	mov    0x238(%rsp),%rcx
  700bd9:	cmp    %rax,%rcx
  700bdc:	jbe    70343e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4cbe>
  700be2:	movaps %xmm1,0x200(%rsp)
  700bea:	add    0x230(%rsp),%rdx
  700bf2:	jmp    700c49 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x24c9>
  700bf4:	xorps  %xmm0,%xmm0
  700bf7:	unpcklpd 0x100(%rsp),%xmm0
  700c00:	movups %xmm0,0x240(%rsp)
  700c08:	movl   $0x0,0x60(%rsp)
  700c10:	movaps 0x850(%rsp),%xmm0
  700c18:	jmp    700cc0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2540>
  700c1d:	xorps  %xmm0,%xmm0
  700c20:	unpcklpd 0x100(%rsp),%xmm0
  700c29:	movups %xmm0,0x80(%rsp)
  700c31:	lea    0x80(%rsp),%rdx
  700c39:	movaps 0x850(%rsp),%xmm0
  700c41:	movaps %xmm0,0x200(%rsp)
  700c49:	movups (%rdx),%xmm0
  700c4c:	movaps %xmm0,0x240(%rsp)
  700c54:	mov    0x20(%r9,%r13,1),%edi
  700c59:	call   6f84b0 <<gpui::runtime::Node>::kind>
  700c5e:	mov    $0x1,%cl
  700c60:	mov    %ecx,0x60(%rsp)
  700c64:	cmp    $0x7,%al
  700c66:	jne    700c77 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x24f7>
  700c68:	mov    0x30(%rsp),%r9
  700c6d:	movaps 0x200(%rsp),%xmm0
  700c75:	jmp    700cc0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2540>
  700c77:	mov    0x30(%rsp),%r9
  700c7c:	mov    0x18(%r9,%r13,1),%eax
  700c81:	mov    $0xffffffff,%ecx
  700c86:	cmp    %rcx,%rax
  700c89:	movaps 0x200(%rsp),%xmm0
  700c91:	je     700cb8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2538>
  700c93:	mov    0x198(%rsp),%rcx
  700c9b:	cmp    %rax,%rcx
  700c9e:	jbe    703488 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d08>
  700ca4:	mov    0x190(%rsp),%rcx
  700cac:	movzbl (%rcx,%rax,1),%eax
  700cb0:	and    $0x1,%al
  700cb2:	mov    %eax,0x60(%rsp)
  700cb6:	jmp    700cc0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2540>
  700cb8:	movl   $0x0,0x60(%rsp)
  700cc0:	movaps %xmm0,0x1a0(%rsp)
  700cc8:	mov    0x20(%r9,%r13,1),%eax
  700ccd:	and    $0xf,%eax
  700cd0:	cmp    $0x7,%eax
  700cd3:	jb     700ce1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2561>
  700cd5:	lea    -0x8(%rax),%ecx
  700cd8:	cmp    $0x2,%ecx
  700cdb:	jae    70186e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x30ee>
  700ce1:	mov    0x18(%r9,%r13,1),%ecx
  700ce6:	xor    %ebp,%ebp
  700ce8:	mov    $0xffffffff,%edx
  700ced:	cmp    %rdx,%rcx
  700cf0:	je     700d0f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x258f>
  700cf2:	cmp    %rcx,0x198(%rsp)
  700cfa:	jbe    700d0f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x258f>
  700cfc:	mov    0x190(%rsp),%rdx
  700d04:	movzbl (%rdx,%rcx,1),%ebp
  700d08:	and    $0x2,%bpl
  700d0c:	shr    $1,%bpl
  700d0f:	cmpb   $0x0,0x2f(%rsp)
  700d14:	je     700d65 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x25e5>
  700d16:	mov    0x198(%rsp),%r14
  700d1e:	cmp    0x188(%rsp),%r14
  700d26:	jne    700d36 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x25b6>
  700d28:	lea    0x188(%rsp),%rdi
  700d30:	call   *0x341ffa(%rip)        # a42d30 <_DYNAMIC+0x798>
  700d36:	lea    0x0(,%rbp,2),%eax
  700d3d:	add    0x60(%rsp),%al
  700d41:	mov    0x190(%rsp),%rcx
  700d49:	mov    %al,(%rcx,%r14,1)
  700d4d:	inc    %r14
  700d50:	mov    %r14,0x198(%rsp)
  700d58:	mov    0x30(%rsp),%rax
  700d5d:	mov    0x20(%rax,%r13,1),%eax
  700d62:	and    $0xf,%eax
  700d65:	cmp    $0x9,%eax
  700d68:	ja     70329d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b1d>
  700d6e:	mov    $0x34f,%ecx
  700d73:	bt     %eax,%ecx
  700d76:	jb     700dff <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x267f>
  700d7c:	movaps 0x1a0(%rsp),%xmm0
  700d84:	movaps %xmm0,0xc0(%rsp)
  700d8c:	movups 0x318(%rsp),%xmm0
  700d94:	movaps %xmm0,0x80(%rsp)
  700d9c:	lea    0x810(%rsp),%rdi
  700da4:	lea    0xc0(%rsp),%rsi
  700dac:	lea    0x240(%rsp),%rdx
  700db4:	lea    0x294(%rsp),%rcx
  700dbc:	lea    0x80(%rsp),%r8
  700dc4:	mov    0x2c0(%rsp),%r9
  700dcc:	call   *0x341f66(%rip)        # a42d38 <_DYNAMIC+0x7a0>
  700dd2:	cmpl   $0xfffffffe,0x810(%rsp)
  700dda:	jne    702f3e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x47be>
  700de0:	lea    0x818(%rsp),%rax
  700de8:	movups (%rax),%xmm0
  700deb:	movaps %xmm0,0x1a0(%rsp)
  700df3:	movups 0x10(%rax),%xmm0
  700df7:	movaps %xmm0,0x240(%rsp)
  700dff:	cmpb   $0x0,0x2f(%rsp)
  700e04:	je     700ea4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2724>
  700e0a:	movaps 0x1a0(%rsp),%xmm0
  700e12:	movaps %xmm0,0x80(%rsp)
  700e1a:	mov    0x220(%rsp),%r14
  700e22:	cmp    0x210(%rsp),%r14
  700e2a:	jne    700e39 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x26b9>
  700e2c:	lea    0x210(%rsp),%rdi
  700e34:	call   6f4cc0 <<alloc::raw_vec::RawVec<gpui_reactivity_core::geometry::Rect>>::grow_one>
  700e39:	mov    0x218(%rsp),%rax
  700e41:	mov    %r14,%rcx
  700e44:	shl    $0x4,%rcx
  700e48:	movaps 0x80(%rsp),%xmm0
  700e50:	movups %xmm0,(%rax,%rcx,1)
  700e54:	inc    %r14
  700e57:	mov    %r14,0x220(%rsp)
  700e5f:	mov    0x238(%rsp),%r14
  700e67:	cmp    0x228(%rsp),%r14
  700e6f:	jne    700e7e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x26fe>
  700e71:	lea    0x228(%rsp),%rdi
  700e79:	call   6f4cc0 <<alloc::raw_vec::RawVec<gpui_reactivity_core::geometry::Rect>>::grow_one>
  700e7e:	mov    0x230(%rsp),%rax
  700e86:	mov    %r14,%rcx
  700e89:	shl    $0x4,%rcx
  700e8d:	movaps 0x240(%rsp),%xmm0
  700e95:	movups %xmm0,(%rax,%rcx,1)
  700e99:	inc    %r14
  700e9c:	mov    %r14,0x238(%rsp)
  700ea4:	test   %ebx,%ebx
  700ea6:	je     700edc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x275c>
  700ea8:	lea    0x80(%rsp),%rdi
  700eb0:	lea    0x318(%rsp),%rsi
  700eb8:	lea    0x298(%rsp),%rdx
  700ec0:	call   6db480 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#24}>
  700ec5:	cmpl   $0x1,0x80(%rsp)
  700ecd:	jne    700edc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x275c>
  700ecf:	lea    0x84(%rsp),%rax
  700ed7:	movups (%rax),%xmm0
  700eda:	jmp    700edf <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x275f>
  700edc:	xorps  %xmm0,%xmm0
  700edf:	movaps %xmm0,0x3a0(%rsp)
  700ee7:	mov    0x60(%rsp),%eax
  700eeb:	or     %bpl,%al
  700eee:	cmp    $0x1,%al
  700ef0:	je     700f05 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2785>
  700ef2:	mov    0x30(%rsp),%rax
  700ef7:	mov    0x20(%rax,%r13,1),%edi
  700efc:	call   6f84b0 <<gpui::runtime::Node>::kind>
  700f01:	cmp    $0x6,%al
  700f03:	jne    700f25 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x27a5>
  700f05:	lea    0x268(%rsp),%rdi
  700f0d:	lea    0x3a0(%rsp),%rsi
  700f15:	lea    0x240(%rsp),%rdx
  700f1d:	call   *0x341e1d(%rip)        # a42d40 <_DYNAMIC+0x7a8>
  700f23:	jmp    700f92 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2812>
  700f25:	movsd  0x3a0(%rsp),%xmm0
  700f2e:	movsd  0x3a8(%rsp),%xmm1
  700f37:	movaps %xmm0,%xmm2
  700f3a:	addps  %xmm0,%xmm1
  700f3d:	xorps  %xmm4,%xmm4
  700f40:	maxps  %xmm4,%xmm0
  700f43:	movaps %xmm0,%xmm3
  700f46:	cmpunordps %xmm0,%xmm3
  700f4a:	andps  %xmm3,%xmm2
  700f4d:	andnps %xmm0,%xmm3
  700f50:	orps   %xmm2,%xmm3
  700f53:	movaps %xmm1,%xmm0
  700f56:	minps  0x100(%rsp),%xmm0
  700f5e:	movaps %xmm0,%xmm2
  700f61:	cmpunordps %xmm0,%xmm2
  700f65:	andps  %xmm2,%xmm1
  700f68:	andnps %xmm0,%xmm2
  700f6b:	orps   %xmm1,%xmm2
  700f6e:	subps  %xmm3,%xmm2
  700f71:	movaps %xmm2,%xmm0
  700f74:	maxps  %xmm4,%xmm0
  700f77:	movaps %xmm0,%xmm1
  700f7a:	cmpunordps %xmm0,%xmm1
  700f7e:	andps  %xmm1,%xmm2
  700f81:	andnps %xmm0,%xmm1
  700f84:	orps   %xmm2,%xmm1
  700f87:	movlhps %xmm1,%xmm3
  700f8a:	movups %xmm3,0x268(%rsp)
  700f92:	test   %bpl,%bpl
  700f95:	mov    0x30(%rsp),%rsi
  700f9a:	je     700fca <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x284a>
  700f9c:	movss  0x270(%rsp),%xmm0
  700fa5:	xor    %r15d,%r15d
  700fa8:	xorps  %xmm1,%xmm1
  700fab:	ucomiss %xmm1,%xmm0
  700fae:	jne    700fb6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2836>
  700fb0:	jnp    70124c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2acc>
  700fb6:	movss  0x274(%rsp),%xmm0
  700fbf:	ucomiss %xmm1,%xmm0
  700fc2:	jne    700fca <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x284a>
  700fc4:	jnp    70124c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2acc>
  700fca:	mov    0x4b8(%rsp),%eax
  700fd1:	mov    $0x3fffffff,%ecx
  700fd6:	and    %ecx,%eax
  700fd8:	cmp    $0x3f800001,%eax
  700fdd:	mov    $0x80000000,%ecx
  700fe2:	cmove  %ecx,%eax
  700fe5:	movd   %eax,%xmm0
  700fe9:	xorps  %xmm1,%xmm1
  700fec:	ucomiss %xmm1,%xmm0
  700fef:	jbe    7010d5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2955>
  700ff5:	movl   $0x1,0x88(%rsp)
  701000:	movq   $0x23,0x80(%rsp)
  70100c:	test   %bl,%bl
  70100e:	je     70230c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3b8c>
  701014:	lea    0x80(%rsp),%rbx
  70101c:	mov    %rbx,%rdi
  70101f:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  701024:	lea    0x298(%rsp),%rax
  70102c:	movups (%rax),%xmm0
  70102f:	movaps %xmm0,0xaa0(%rsp)
  701037:	mov    0x10(%rax),%rax
  70103b:	mov    %rax,0xab0(%rsp)
  701043:	mov    %rbx,%rdi
  701046:	mov    0x40(%rsp),%rsi
  70104b:	mov    0x50(%rsp),%rdx
  701050:	xor    %ecx,%ecx
  701052:	call   *0x341cf0(%rip)        # a42d48 <_DYNAMIC+0x7b0>
  701058:	mov    0x90(%rsp),%r9
  701060:	test   %r9,%r9
  701063:	je     7011d0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2a50>
  701069:	movups 0x80(%rsp),%xmm0
  701071:	movaps %xmm0,0x2e0(%rsp)
  701079:	movaps 0x1a0(%rsp),%xmm0
  701081:	movaps %xmm0,0x120(%rsp)
  701089:	movups 0x318(%rsp),%xmm0
  701091:	movaps %xmm0,0xc0(%rsp)
  701099:	lea    0x8b0(%rsp),%rdi
  7010a1:	lea    0xc0(%rsp),%rsi
  7010a9:	movss  0xdc(%rsp),%xmm0
  7010b2:	lea    0xaa0(%rsp),%rdx
  7010ba:	lea    0x120(%rsp),%rcx
  7010c2:	lea    0x2e0(%rsp),%r8
  7010ca:	call   *0x341c80(%rip)        # a42d50 <_DYNAMIC+0x7b8>
  7010d0:	jmp    7011bd <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2a3d>
  7010d5:	cmpq   $0x0,0x8(%rsi,%r13,1)
  7010db:	jne    7010f7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2977>
  7010dd:	mov    0x20(%rsi,%r13,1),%edi
  7010e2:	call   6f84b0 <<gpui::runtime::Node>::kind>
  7010e7:	mov    $0x1,%r15b
  7010ea:	cmp    $0x4,%al
  7010ec:	mov    0x30(%rsp),%rsi
  7010f1:	jne    70124c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2acc>
  7010f7:	movl   $0x1,0x88(%rsp)
  701102:	movq   $0x23,0x80(%rsp)
  70110e:	test   %bl,%bl
  701110:	je     70230c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3b8c>
  701116:	lea    0x80(%rsp),%rbx
  70111e:	mov    %rbx,%rdi
  701121:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  701126:	lea    0x298(%rsp),%rcx
  70112e:	movups (%rcx),%xmm0
  701131:	movaps %xmm0,0x120(%rsp)
  701139:	mov    0x10(%rcx),%rax
  70113d:	mov    %rax,0x130(%rsp)
  701145:	movups (%rcx),%xmm0
  701148:	movaps %xmm0,0xb50(%rsp)
  701150:	mov    0x10(%rcx),%rax
  701154:	mov    %rax,0xb60(%rsp)
  70115c:	movaps 0x1a0(%rsp),%xmm0
  701164:	movaps %xmm0,0x2e0(%rsp)
  70116c:	movups 0x318(%rsp),%xmm0
  701174:	movaps %xmm0,0xc0(%rsp)
  70117c:	movups -0x6bfca3(%rip),%xmm0        # 414e0 <GCC_except_table0+0x1698>
  701183:	movaps %xmm0,0x80(%rsp)
  70118b:	lea    0x8b0(%rsp),%rdi
  701193:	lea    0xc0(%rsp),%rsi
  70119b:	movss  0xdc(%rsp),%xmm0
  7011a4:	lea    0xb50(%rsp),%rdx
  7011ac:	lea    0x2e0(%rsp),%rcx
  7011b4:	mov    %rbx,%r8
  7011b7:	call   *0x341b9b(%rip)        # a42d58 <_DYNAMIC+0x7c0>
  7011bd:	cmp    $0xffffffff,%eax
  7011c0:	jne    702345 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3bc5>
  7011c6:	mov    $0x1,%r15b
  7011c9:	mov    0x30(%rsp),%rsi
  7011ce:	jmp    70124c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2acc>
  7011d0:	movaps 0x1a0(%rsp),%xmm0
  7011d8:	movaps %xmm0,0x120(%rsp)
  7011e0:	lea    0x4bc(%rsp),%rax
  7011e8:	movups -0x10(%rax),%xmm0
  7011ec:	movaps %xmm0,0xc0(%rsp)
  7011f4:	movups 0x318(%rsp),%xmm0
  7011fc:	movaps %xmm0,0x80(%rsp)
  701204:	lea    0x8b0(%rsp),%rdi
  70120c:	lea    0x80(%rsp),%rsi
  701214:	movss  0xdc(%rsp),%xmm0
  70121d:	lea    0xaa0(%rsp),%rdx
  701225:	lea    0x120(%rsp),%rcx
  70122d:	lea    0xc0(%rsp),%r8
  701235:	call   *0x341b1d(%rip)        # a42d58 <_DYNAMIC+0x7c0>
  70123b:	mov    $0x1,%r15b
  70123e:	cmp    $0xffffffff,%eax
  701241:	mov    0x30(%rsp),%rsi
  701246:	jne    702345 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3bc5>
  70124c:	mov    0x20(%rsi,%r13,1),%edi
  701251:	mov    %edi,%eax
  701253:	and    $0xf,%eax
  701256:	cmp    $0x9,%eax
  701259:	ja     70329d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b1d>
  70125f:	cmp    $0x6,%eax
  701262:	je     70187f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x30ff>
  701268:	shr    $0x4,%edi
  70126b:	dec    %edi
  70126d:	mov    0x38(%rsp),%rax
  701272:	mov    0x2e0(%rax),%rsi
  701279:	mov    0x2e8(%rax),%rdx
  701280:	call   6f83a0 <<gpui::runtime::TextSlot>::get_mut>
  701285:	test   %rax,%rax
  701288:	je     70164f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2ecf>
  70128e:	lea    0x4bc(%rsp),%rcx
  701296:	movups -0x20(%rcx),%xmm0
  70129a:	movaps %xmm0,0x8a0(%rsp)
  7012a2:	mov    0x38(%rsp),%rcx
  7012a7:	mov    0x6c8(%rcx),%rbx
  7012ae:	test   %rbx,%rbx
  7012b1:	mov    0x30(%rsp),%rdx
  7012b6:	je     703209 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4a89>
  7012bc:	cmpq   $0x0,0x30(%rbx)
  7012c1:	je     703209 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4a89>
  7012c7:	movzbl 0x43c(%rsp),%ecx
  7012cf:	mov    $0x2,%r12b
  7012d2:	cmp    $0x2,%cl
  7012d5:	je     701345 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2bc5>
  7012d7:	mov    (%rdx,%r13,1),%rdx
  7012db:	cmp    %rdx,0x428(%rsp)
  7012e3:	jne    701345 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2bc5>
  7012e5:	mov    0x438(%rsp),%edx
  7012ec:	mov    %edx,0x1dc(%rsp)
  7012f3:	movzbl 0x434(%rsp),%edx
  7012fb:	mov    %dl,0x79(%rsp)
  7012ff:	mov    0x430(%rsp),%edx
  701306:	mov    %edx,0x158(%rsp)
  70130d:	lea    0x435(%rsp),%rsi
  701315:	movzwl (%rsi),%edx
  701318:	mov    %dx,0xf0(%rsp)
  701320:	movzbl 0x2(%rsi),%edx
  701324:	mov    %dl,0xf2(%rsp)
  70132b:	movzwl 0x8(%rsi),%edx
  70132f:	mov    %dx,0xec(%rsp)
  701337:	movzbl 0xa(%rsi),%edx
  70133b:	mov    %dl,0xee(%rsp)
  701342:	mov    %ecx,%r12d
  701345:	cmpq   $0x0,0x1b0(%rsp)
  70134e:	je     7031fa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4a7a>
  701354:	movss  0x498(%rsp),%xmm0
  70135d:	movaps 0x360(%rsp),%xmm1
  701365:	subss  0x2d0(%rsp),%xmm1
  70136e:	subss  0x2cc(%rsp),%xmm1
  701377:	subss  0x870(%rsp),%xmm1
  701380:	subss  0xe0(%rsp),%xmm1
  701389:	subss  0x860(%rsp),%xmm1
  701392:	lea    0x80(%rsp),%rdi
  70139a:	mov    %rax,%rsi
  70139d:	lea    0x1b0(%rsp),%rdx
  7013a5:	mov    $0x1,%ecx
  7013aa:	mov    $0x1,%r8d
  7013b0:	call   *0x34164a(%rip)        # a42a00 <_DYNAMIC+0x468>
  7013b6:	mov    0x80(%rsp),%rax
  7013be:	mov    0x88(%rsp),%rcx
  7013c6:	mov    %rcx,0xe0(%rsp)
  7013ce:	cmp    $0xfffffffffffffffe,%rax
  7013d2:	jne    702ec8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4748>
  7013d8:	movaps 0x2d0(%rsp),%xmm0
  7013e0:	movss  %xmm0,0xf8(%rsp)
  7013e9:	movaps 0x750(%rsp),%xmm1
  7013f1:	movss  %xmm1,0xfc(%rsp)
  7013fa:	test   %r15b,%r15b
  7013fd:	je     701665 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2ee5>
  701403:	testb  $0x1,0x294(%rsp)
  70140b:	movl   $0x1,0x88(%rsp)
  701416:	movq   $0x23,0x80(%rsp)
  701422:	je     70230c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3b8c>
  701428:	lea    0x80(%rsp),%rdi
  701430:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  701435:	lea    0x298(%rsp),%rcx
  70143d:	movups (%rcx),%xmm0
  701440:	movaps %xmm0,0xac0(%rsp)
  701448:	mov    0x10(%rcx),%rax
  70144c:	mov    %rax,0xad0(%rsp)
  701454:	movups (%rcx),%xmm0
  701457:	movaps %xmm0,0x2e0(%rsp)
  70145f:	mov    0x10(%rcx),%rax
  701463:	mov    %rax,0x2f0(%rsp)
  70146b:	cmp    $0x2,%r12b
  70146f:	je     70157e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2dfe>
  701475:	mov    0x158(%rsp),%eax
  70147c:	mov    %eax,0xc0(%rsp)
  701483:	movzbl 0x79(%rsp),%eax
  701488:	mov    %al,0xc4(%rsp)
  70148f:	movzbl 0xf2(%rsp),%eax
  701497:	lea    0xc5(%rsp),%rcx
  70149f:	mov    %al,0x2(%rcx)
  7014a2:	movzwl 0xf0(%rsp),%eax
  7014aa:	mov    %ax,(%rcx)
  7014ad:	mov    0x1dc(%rsp),%eax
  7014b4:	mov    %eax,0xc8(%rsp)
  7014bb:	mov    %r12b,0xcc(%rsp)
  7014c3:	movzbl 0xee(%rsp),%eax
  7014cb:	mov    %al,0xa(%rcx)
  7014ce:	movzwl 0xec(%rsp),%eax
  7014d6:	mov    %ax,0x8(%rcx)
  7014da:	movl   $0xffffffff,0x120(%rsp)
  7014e5:	lea    0x120(%rsp),%rax
  7014ed:	mov    %rax,0x80(%rsp)
  7014f5:	lea    0x8b0(%rsp),%rax
  7014fd:	mov    %rax,0x88(%rsp)
  701505:	lea    0xf8(%rsp),%rax
  70150d:	mov    %rax,0x90(%rsp)
  701515:	lea    0xfc(%rsp),%rax
  70151d:	mov    %rax,0x98(%rsp)
  701525:	lea    0x2e0(%rsp),%rax
  70152d:	mov    %rax,0xa0(%rsp)
  701535:	lea    0x1a0(%rsp),%rax
  70153d:	mov    %rax,0xa8(%rsp)
  701545:	mov    0xe0(%rsp),%rax
  70154d:	mov    0x20(%rax),%rdi
  701551:	lea    0xc0(%rsp),%rsi
  701559:	lea    0x80(%rsp),%rdx
  701561:	call   6b8220 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>>
  701566:	test   %al,%al
  701568:	je     702fde <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x485e>
  70156e:	mov    0x120(%rsp),%eax
  701575:	cmp    $0xffffffff,%eax
  701578:	jne    702fec <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x486c>
  70157e:	lea    0xc0(%rsp),%rdi
  701586:	mov    0x40(%rsp),%rsi
  70158b:	mov    0x50(%rsp),%rdx
  701590:	mov    $0x1,%ecx
  701595:	call   *0x3417ad(%rip)        # a42d48 <_DYNAMIC+0x7b0>
  70159b:	add    $0x30,%rbx
  70159f:	mov    0xd0(%rsp),%rax
  7015a7:	test   %rax,%rax
  7015aa:	je     701680 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2f00>
  7015b0:	movups 0xc0(%rsp),%xmm0
  7015b8:	movaps %xmm0,0x3b0(%rsp)
  7015c0:	movaps 0x1a0(%rsp),%xmm0
  7015c8:	movaps %xmm0,0x120(%rsp)
  7015d0:	movss  0xf8(%rsp),%xmm0
  7015d9:	movss  0xfc(%rsp),%xmm1
  7015e2:	lea    0x298(%rsp),%rdx
  7015ea:	mov    0x10(%rdx),%rcx
  7015ee:	mov    %rcx,0x90(%rsp)
  7015f6:	movups (%rdx),%xmm2
  7015f9:	movaps %xmm2,0x80(%rsp)
  701601:	mov    %rax,(%rsp)
  701605:	lea    0x8b0(%rsp),%rdi
  70160d:	mov    %rbx,%rsi
  701610:	mov    0xe0(%rsp),%rdx
  701618:	lea    0x80(%rsp),%rcx
  701620:	lea    0x120(%rsp),%r8
  701628:	lea    0x3b0(%rsp),%r9
  701630:	movss  0x7c(%rsp),%xmm2
  701636:	call   *0x341724(%rip)        # a42d60 <_DYNAMIC+0x7c8>
  70163c:	cmp    $0xffffffff,%eax
  70163f:	jne    702345 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3bc5>
  701645:	mov    0x30(%rsp),%rsi
  70164a:	jmp    701716 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2f96>
  70164f:	movq   $0x0,0xe0(%rsp)
  70165b:	mov    0x30(%rsp),%rsi
  701660:	jmp    7018f9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3179>
  701665:	movss  %xmm0,0x1e0(%rsp)
  70166e:	mov    0x30(%rsp),%rsi
  701673:	movaps 0x750(%rsp),%xmm0
  70167b:	jmp    7018f0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3170>
  701680:	movaps 0x1a0(%rsp),%xmm0
  701688:	movaps %xmm0,0x120(%rsp)
  701690:	movss  0xf8(%rsp),%xmm0
  701699:	movss  0xfc(%rsp),%xmm1
  7016a2:	lea    0x298(%rsp),%rcx
  7016aa:	mov    0x10(%rcx),%rax
  7016ae:	mov    %rax,0x90(%rsp)
  7016b6:	movups (%rcx),%xmm2
  7016b9:	movaps %xmm2,0x80(%rsp)
  7016c1:	movaps 0x8a0(%rsp),%xmm2
  7016c9:	movaps %xmm2,0xc0(%rsp)
  7016d1:	lea    0x8b0(%rsp),%rdi
  7016d9:	mov    %rbx,%rsi
  7016dc:	mov    0xe0(%rsp),%rdx
  7016e4:	lea    0x80(%rsp),%rcx
  7016ec:	lea    0x120(%rsp),%r8
  7016f4:	lea    0xc0(%rsp),%r9
  7016fc:	movss  0x7c(%rsp),%xmm2
  701702:	call   *0x341660(%rip)        # a42d68 <_DYNAMIC+0x7d0>
  701708:	cmp    $0xffffffff,%eax
  70170b:	mov    0x30(%rsp),%rsi
  701710:	jne    702345 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3bc5>
  701716:	cmp    $0x2,%r12b
  70171a:	je     7018d5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3155>
  701720:	mov    0x158(%rsp),%eax
  701727:	cmp    0x1dc(%rsp),%eax
  70172e:	jne    7018d5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3155>
  701734:	mov    0x38(%rsp),%rax
  701739:	mov    0x618(%rax),%rax
  701740:	test   %rax,%rax
  701743:	je     7018d5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3155>
  701749:	mov    0x38(%rsp),%rcx
  70174e:	cmp    0x5e0(%rcx),%rax
  701755:	jne    7018d5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3155>
  70175b:	mov    (%rsi,%r13,1),%rax
  70175f:	mov    0x38(%rsp),%rcx
  701764:	cmp    %rax,0x620(%rcx)
  70176b:	jne    7018d5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3155>
  701771:	movzbl %r12b,%ecx
  701775:	lea    0xc0(%rsp),%rdi
  70177d:	mov    0xe0(%rsp),%rsi
  701785:	mov    0x158(%rsp),%edx
  70178c:	call   *0x341476(%rip)        # a42c08 <_DYNAMIC+0x670>
  701792:	movq   $0x18,0x80(%rsp)
  70179e:	cmpl   $0x1,0xc0(%rsp)
  7017a6:	jne    702fde <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x485e>
  7017ac:	lea    0x80(%rsp),%rbx
  7017b4:	mov    %rbx,%rdi
  7017b7:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  7017bc:	movsd  0xc4(%rsp),%xmm0
  7017c5:	movaps 0x2d0(%rsp),%xmm1
  7017cd:	unpcklps 0x750(%rsp),%xmm1
  7017d5:	addps  %xmm0,%xmm1
  7017d8:	movhps 0xcc(%rsp),%xmm1
  7017e0:	movups %xmm1,0x3b0(%rsp)
  7017e8:	mov    %rbx,%rdi
  7017eb:	mov    0x40(%rsp),%rsi
  7017f0:	mov    0x50(%rsp),%rdx
  7017f5:	mov    $0x1,%ecx
  7017fa:	call   *0x341548(%rip)        # a42d48 <_DYNAMIC+0x7b0>
  701800:	mov    0x90(%rsp),%r9
  701808:	test   %r9,%r9
  70180b:	je     701889 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3109>
  70180d:	movups 0x80(%rsp),%xmm0
  701815:	movaps %xmm0,0x120(%rsp)
  70181d:	movaps 0x1a0(%rsp),%xmm0
  701825:	movaps %xmm0,0xc0(%rsp)
  70182d:	xorps  %xmm0,%xmm0
  701830:	lea    0x8b0(%rsp),%rdi
  701838:	lea    0x3b0(%rsp),%rsi
  701840:	lea    0xac0(%rsp),%rdx
  701848:	lea    0xc0(%rsp),%rcx
  701850:	lea    0x120(%rsp),%r8
  701858:	call   *0x3414f2(%rip)        # a42d50 <_DYNAMIC+0x7b8>
  70185e:	cmp    $0xffffffff,%eax
  701861:	jne    702345 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3bc5>
  701867:	mov    0x30(%rsp),%rsi
  70186c:	jmp    7018d5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3155>
  70186e:	mov    $0x1,%bpl
  701871:	cmp    $0x7,%eax
  701874:	je     700d0f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x258f>
  70187a:	jmp    70329d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b1d>
  70187f:	mov    $0xffffffff,%edi
  701884:	jmp    70126d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x2aed>
  701889:	movaps 0x1a0(%rsp),%xmm0
  701891:	movaps %xmm0,0x80(%rsp)
  701899:	lea    0x8b0(%rsp),%rdi
  7018a1:	lea    0x3b0(%rsp),%rsi
  7018a9:	lea    0xac0(%rsp),%rdx
  7018b1:	lea    0x80(%rsp),%rcx
  7018b9:	lea    0x8a0(%rsp),%r8
  7018c1:	call   *0x340fb9(%rip)        # a42880 <_DYNAMIC+0x2e8>
  7018c7:	cmp    $0xffffffff,%eax
  7018ca:	mov    0x30(%rsp),%rsi
  7018cf:	jne    702345 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3bc5>
  7018d5:	movss  0xf8(%rsp),%xmm0
  7018de:	movss  %xmm0,0x1e0(%rsp)
  7018e7:	movss  0xfc(%rsp),%xmm0
  7018f0:	movss  %xmm0,0x2c8(%rsp)
  7018f9:	test   %r15b,%r15b
  7018fc:	je     701a5d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x32dd>
  701902:	mov    0x20(%rsi,%r13,1),%edi
  701907:	call   *0x3410eb(%rip)        # a429f8 <_DYNAMIC+0x460>
  70190d:	mov    %edx,%ebx
  70190f:	cmp    $0x2,%dl
  701912:	mov    0x30(%rsp),%rsi
  701917:	je     701a5d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x32dd>
  70191d:	mov    0x180(%rsp),%rcx
  701925:	mov    (%rcx),%rdx
  701928:	test   %rdx,%rdx
  70192b:	je     7032bb <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b3b>
  701931:	mov    0x10(%rdx),%rcx
  701935:	mov    %eax,%eax
  701937:	cmp    %rax,%rcx
  70193a:	jbe    70347a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4cfa>
  701940:	mov    0x8(%rdx),%rcx
  701944:	movaps 0x870(%rsp),%xmm3
  70194c:	movaps %xmm3,%xmm0
  70194f:	shufps $0xe8,%xmm3,%xmm0
  701953:	movaps 0x880(%rsp),%xmm5
  70195b:	addps  %xmm0,%xmm5
  70195e:	movaps 0x2d0(%rsp),%xmm4
  701966:	movaps %xmm4,%xmm1
  701969:	shufps $0xe8,%xmm4,%xmm1
  70196d:	movaps 0x360(%rsp),%xmm2
  701975:	subps  %xmm1,%xmm2
  701978:	addps  %xmm5,%xmm1
  70197b:	shufps $0xed,%xmm4,%xmm4
  70197f:	subps  %xmm4,%xmm2
  701982:	subps  %xmm0,%xmm2
  701985:	shufps $0xed,%xmm3,%xmm3
  701989:	subps  %xmm3,%xmm2
  70198c:	subps  0x860(%rsp),%xmm2
  701994:	movlhps %xmm2,%xmm1
  701997:	movups %xmm1,0x2e0(%rsp)
  70199f:	testb  $0x1,0x294(%rsp)
  7019a7:	movl   $0x1,0x88(%rsp)
  7019b2:	movq   $0x23,0x80(%rsp)
  7019be:	je     70230c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3b8c>
  7019c4:	lea    (%rcx,%rax,8),%r15
  7019c8:	lea    0x80(%rsp),%r14
  7019d0:	mov    %r14,%rdi
  7019d3:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  7019d8:	lea    0x298(%rsp),%rcx
  7019e0:	movups (%rcx),%xmm0
  7019e3:	movaps %xmm0,0x120(%rsp)
  7019eb:	mov    0x10(%rcx),%rax
  7019ef:	mov    %rax,0x130(%rsp)
  7019f7:	movups (%rcx),%xmm0
  7019fa:	movaps %xmm0,0xb70(%rsp)
  701a02:	mov    0x10(%rcx),%rax
  701a06:	mov    %rax,0xb80(%rsp)
  701a0e:	movaps 0x1a0(%rsp),%xmm0
  701a16:	movaps %xmm0,0x80(%rsp)
  701a1e:	movzbl %bl,%r9d
  701a22:	lea    0x8b0(%rsp),%rdi
  701a2a:	mov    %r15,%rsi
  701a2d:	lea    0x2e0(%rsp),%rdx
  701a35:	lea    0xb70(%rsp),%rcx
  701a3d:	mov    %r14,%r8
  701a40:	movss  0xdc(%rsp),%xmm0
  701a49:	call   *0x341321(%rip)        # a42d70 <_DYNAMIC+0x7d8>
  701a4f:	cmp    $0xffffffff,%eax
  701a52:	jne    702345 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3bc5>
  701a58:	mov    0x30(%rsp),%rsi
  701a5d:	mov    0x18(%rsi,%r13,1),%ebx
  701a62:	cmpb   $0x0,0x2f(%rsp)
  701a67:	je     701a91 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3311>
  701a69:	cmp    $0xffffffff,%ebx
  701a6c:	je     701a8c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x330c>
  701a6e:	mov    0x150(%rsp),%rcx
  701a76:	cmp    %rbx,%rcx
  701a79:	jbe    70344c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4ccc>
  701a7f:	mov    0x148(%rsp),%rax
  701a87:	mov    (%rax,%rbx,4),%ebx
  701a8a:	jmp    701a91 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3311>
  701a8c:	mov    $0xffffffff,%ebx
  701a91:	cmpb   $0x0,0x60(%rsp)
  701a96:	je     701b36 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x33b6>
  701a9c:	movss  0x270(%rsp),%xmm0
  701aa5:	xorps  %xmm1,%xmm1
  701aa8:	ucomiss %xmm1,%xmm0
  701aab:	jne    701aaf <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x332f>
  701aad:	jnp    701abf <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x333f>
  701aaf:	movss  0x274(%rsp),%xmm0
  701ab8:	ucomiss %xmm1,%xmm0
  701abb:	jne    701b36 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x33b6>
  701abd:	jp     701b36 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x33b6>
  701abf:	cmpb   $0x0,0x1e4(%rsp)
  701ac7:	je     701ae9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3369>
  701ac9:	movss  0x248(%rsp),%xmm0
  701ad2:	ucomiss %xmm1,%xmm0
  701ad5:	jne    701ad9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3359>
  701ad7:	jnp    701ae9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3369>
  701ad9:	movss  0x24c(%rsp),%xmm0
  701ae2:	ucomiss %xmm1,%xmm0
  701ae5:	jne    701b36 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x33b6>
  701ae7:	jp     701b36 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x33b6>
  701ae9:	test   %bpl,%bpl
  701aec:	je     701b0e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x338e>
  701aee:	movss  0x248(%rsp),%xmm0
  701af7:	ucomiss %xmm1,%xmm0
  701afa:	jne    701afe <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x337e>
  701afc:	jnp    701b0e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x338e>
  701afe:	movss  0x24c(%rsp),%xmm0
  701b07:	ucomiss %xmm1,%xmm0
  701b0a:	jne    701b36 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x33b6>
  701b0c:	jp     701b36 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x33b6>
  701b0e:	mov    0x150(%rsp),%r14
  701b16:	cmp    0x140(%rsp),%r14
  701b1e:	jne    70030e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1b8e>
  701b24:	lea    0x140(%rsp),%rdi
  701b2c:	call   6f4b70 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  701b31:	jmp    70030e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1b8e>
  701b36:	mov    0x20(%rsi,%r13,1),%edi
  701b3b:	call   6f84b0 <<gpui::runtime::Node>::kind>
  701b40:	cmp    $0x7,%al
  701b42:	jne    701b5a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x33da>
  701b44:	mov    0x30(%rsp),%rax
  701b49:	mov    (%rax,%r13,1),%rsi
  701b4d:	lea    0x338(%rsp),%rdi
  701b55:	call   6fc770 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  701b5a:	cmpb   $0x0,0x2f(%rsp)
  701b5f:	je     701bac <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x342c>
  701b61:	mov    0x1d0(%rsp),%rsi
  701b69:	mov    $0x1,%edi
  701b6e:	call   *0x340ccc(%rip)        # a42840 <_DYNAMIC+0x2a8>
  701b74:	mov    %eax,%ebp
  701b76:	mov    0x150(%rsp),%r14
  701b7e:	cmp    0x140(%rsp),%r14
  701b86:	jne    701b95 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3415>
  701b88:	lea    0x140(%rsp),%rdi
  701b90:	call   6f4b70 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  701b95:	mov    0x148(%rsp),%rax
  701b9d:	mov    %ebp,(%rax,%r14,4)
  701ba1:	inc    %r14
  701ba4:	mov    %r14,0x150(%rsp)
  701bac:	movss  0x270(%rsp),%xmm0
  701bb5:	xor    %ebp,%ebp
  701bb7:	xorps  %xmm1,%xmm1
  701bba:	ucomiss %xmm1,%xmm0
  701bbd:	jne    701bc5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3445>
  701bbf:	jnp    701c4d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x34cd>
  701bc5:	movss  0x274(%rsp),%xmm0
  701bce:	ucomiss %xmm1,%xmm0
  701bd1:	mov    $0x0,%r12d
  701bd7:	mov    0x30(%rsp),%rax
  701bdc:	jne    701be0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3460>
  701bde:	jnp    701c50 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x34d0>
  701be0:	mov    0x20(%rax,%r13,1),%edi
  701be5:	mov    %edi,%eax
  701be7:	and    $0xf,%eax
  701bea:	cmp    $0x9,%eax
  701bed:	ja     70329d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b1d>
  701bf3:	cmp    $0x6,%eax
  701bf6:	mov    0x30(%rsp),%rdx
  701bfb:	je     701c05 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3485>
  701bfd:	mov    $0x1,%r12b
  701c00:	cmp    $0xf,%edi
  701c03:	ja     701c50 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x34d0>
  701c05:	mov    0x4b8(%rsp),%eax
  701c0c:	mov    $0x3fffffff,%ecx
  701c11:	and    %ecx,%eax
  701c13:	cmp    $0x3f800001,%eax
  701c18:	mov    $0x80000000,%ecx
  701c1d:	cmove  %ecx,%eax
  701c20:	movd   %eax,%xmm0
  701c24:	mov    $0x1,%r12b
  701c27:	ucomiss %xmm1,%xmm0
  701c2a:	ja     701c50 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x34d0>
  701c2c:	cmpq   $0x0,0x8(%rdx,%r13,1)
  701c32:	jne    701c50 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x34d0>
  701c34:	call   6f84b0 <<gpui::runtime::Node>::kind>
  701c39:	lea    -0x4(%rax),%ecx
  701c3c:	cmp    $0x2,%al
  701c3e:	setae  %al
  701c41:	test   $0xfb,%cl
  701c44:	sete   %r12b
  701c48:	and    %al,%r12b
  701c4b:	jmp    701c50 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x34d0>
  701c4d:	xor    %r12d,%r12d
  701c50:	mov    0x1d0(%rsp),%rax
  701c58:	test   %rax,%rax
  701c5b:	je     701c72 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x34f2>
  701c5d:	mov    0x1c8(%rsp),%rcx
  701c65:	shl    $0x6,%rax
  701c69:	mov    -0x8(%rcx,%rax,1),%ecx
  701c6d:	mov    $0x1,%ebp
  701c72:	mov    %r12d,%eax
  701c75:	xor    $0x1,%al
  701c77:	movzbl %al,%esi
  701c7a:	mov    %ebx,%edi
  701c7c:	mov    %ebp,%edx
  701c7e:	call   *0x3410f4(%rip)        # a42d78 <_DYNAMIC+0x7e0>
  701c84:	mov    %eax,%ebp
  701c86:	cmpq   $0x0,0xe0(%rsp)
  701c8f:	je     701cfa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x357a>
  701c91:	mov    0x38(%rsp),%rax
  701c96:	mov    0x6c8(%rax),%rax
  701c9d:	test   %rax,%rax
  701ca0:	je     70331f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b9f>
  701ca6:	mov    0x8(%rax),%rsi
  701caa:	mov    0x10(%rax),%rdx
  701cae:	mov    0x1d0(%rsp),%r9d
  701cb6:	mov    0xe0(%rsp),%rax
  701cbe:	mov    %rax,(%rsp)
  701cc2:	lea    0x160(%rsp),%rdi
  701cca:	mov    0x2b0(%rsp),%rcx
  701cd2:	mov    0x178(%rsp),%r8
  701cda:	movss  0x1e0(%rsp),%xmm0
  701ce3:	movss  0x2c8(%rsp),%xmm1
  701cec:	call   *0x34108e(%rip)        # a42d80 <_DYNAMIC+0x7e8>
  701cf2:	incq   0x178(%rsp)
  701cfa:	cmp    $0xffffffff,%ebx
  701cfd:	je     701d32 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x35b2>
  701cff:	mov    %ebx,%eax
  701d01:	mov    0x1d0(%rsp),%rcx
  701d09:	cmp    %rax,%rcx
  701d0c:	jbe    703496 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d16>
  701d12:	mov    0x1c8(%rsp),%rcx
  701d1a:	shl    $0x6,%rax
  701d1e:	mov    0x30(%rcx,%rax,1),%rax
  701d23:	mov    %rax,0x84(%rsp)
  701d2b:	mov    $0x1,%eax
  701d30:	jmp    701d34 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x35b4>
  701d32:	xor    %eax,%eax
  701d34:	mov    %eax,0x80(%rsp)
  701d3b:	lea    0x294(%rsp),%rdi
  701d43:	lea    0x80(%rsp),%rsi
  701d4b:	lea    0x278(%rsp),%rdx
  701d53:	call   *0x34102f(%rip)        # a42d88 <_DYNAMIC+0x7f0>
  701d59:	mov    %rax,%rbx
  701d5c:	mov    0x30(%rsp),%rax
  701d61:	mov    (%rax,%r13,1),%r14
  701d65:	mov    0x20(%rax,%r13,1),%edi
  701d6a:	call   6f84b0 <<gpui::runtime::Node>::kind>
  701d6f:	mov    %eax,%r15d
  701d72:	mov    0x30(%rsp),%rax
  701d77:	mov    0x20(%rax,%r13,1),%edi
  701d7c:	mov    %edi,%eax
  701d7e:	and    $0xf,%eax
  701d81:	cmp    $0x9,%eax
  701d84:	ja     70329d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b1d>
  701d8a:	cmp    $0x6,%eax
  701d8d:	je     701f88 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3808>
  701d93:	shr    $0x4,%edi
  701d96:	dec    %edi
  701d98:	mov    0x38(%rsp),%rax
  701d9d:	mov    0x2e0(%rax),%rsi
  701da4:	mov    0x2e8(%rax),%rdx
  701dab:	call   6f8350 <<gpui::runtime::TextSlot>::get>
  701db0:	mov    %ebp,0x60(%rsp)
  701db4:	test   %rax,%rax
  701db7:	mov    %rbx,0x2d0(%rsp)
  701dbf:	je     701dfb <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x367b>
  701dc1:	mov    0x40(%rax),%rbp
  701dc5:	testb  $0x1,0x0(%rbp)
  701dc9:	jne    701df6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3676>
  701dcb:	mov    0x8(%rbp),%rax
  701dcf:	test   $0x1,%al
  701dd1:	jne    701df6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3676>
  701dd3:	mov    $0x2,%eax
  701dd8:	lock xadd %rax,0x8(%rbp)
  701dde:	and    0x7c0(%rsp),%rax
  701de6:	mov    %r12d,%ebx
  701de9:	neg    %rax
  701dec:	jno    701e00 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3680>
  701dee:	lock orq $0x1,0x8(%rbp)
  701df4:	jmp    701e00 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3680>
  701df6:	mov    %r12d,%ebx
  701df9:	jmp    701e00 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3680>
  701dfb:	mov    %r12d,%ebx
  701dfe:	xor    %ebp,%ebp
  701e00:	movdqa 0x360(%rsp),%xmm0
  701e09:	movd   %xmm0,%esi
  701e0d:	shufps $0x55,%xmm0,%xmm0
  701e11:	movd   %xmm0,%eax
  701e15:	shl    $0x20,%rax
  701e19:	or     %rax,%rsi
  701e1c:	lea    0xc0(%rsp),%rdi
  701e24:	lea    0x294(%rsp),%rdx
  701e2c:	call   *0x340f5e(%rip)        # a42d90 <_DYNAMIC+0x7f8>
  701e32:	mov    0x30(%rsp),%r12
  701e37:	mov    0x20(%r12,%r13,1),%edi
  701e3c:	call   6f84b0 <<gpui::runtime::Node>::kind>
  701e41:	xor    %esi,%esi
  701e43:	cmpq   $0x0,0x8(%r12,%r13,1)
  701e49:	setne  %sil
  701e4d:	movzbl %al,%edi
  701e50:	call   6f8100 <<gpui::runtime::semantics::Actions>::for_node>
  701e55:	mov    0x18(%r12,%r13,1),%ecx
  701e5a:	mov    $0xffffffff,%edx
  701e5f:	cmp    %rdx,%rcx
  701e62:	je     701e88 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3708>
  701e64:	cmp    %rcx,0x198(%rsp)
  701e6c:	jbe    701e88 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3708>
  701e6e:	mov    0x190(%rsp),%rdx
  701e76:	cmpb   $0x0,(%rdx,%rcx,1)
  701e7a:	setne  %cl
  701e7d:	mov    0xf4(%rsp),%edx
  701e84:	or     %cl,%dl
  701e86:	jmp    701e8f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x370f>
  701e88:	mov    0xf4(%rsp),%edx
  701e8f:	movzbl %al,%ecx
  701e92:	or     $0x20,%al
  701e94:	movzbl %al,%eax
  701e97:	test   %dl,%dl
  701e99:	cmove  %ecx,%eax
  701e9c:	mov    %r14,0xa0(%rsp)
  701ea4:	mov    0x60(%rsp),%ecx
  701ea8:	mov    %ecx,0xb8(%rsp)
  701eaf:	mov    %r15b,0xbd(%rsp)
  701eb7:	mov    %rbp,0xa8(%rsp)
  701ebf:	movups 0xc0(%rsp),%xmm0
  701ec7:	movaps %xmm0,0x80(%rsp)
  701ecf:	mov    0x2d0(%rsp),%rcx
  701ed7:	mov    %rcx,0xb0(%rsp)
  701edf:	movups 0x268(%rsp),%xmm0
  701ee7:	lea    0x84(%rsp),%rcx
  701eef:	movups %xmm0,0xc(%rcx)
  701ef3:	mov    %bl,0xbe(%rsp)
  701efa:	mov    %al,0xbc(%rsp)
  701f01:	lea    0x1c0(%rsp),%rdi
  701f09:	lea    0x80(%rsp),%rsi
  701f11:	call   6f7dd0 <<alloc::vec::Vec<gpui::runtime::Presented>>::push_mut>
  701f16:	cmpl   $0xffffffff,0x760(%rsp)
  701f1e:	je     701f6b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x37eb>
  701f20:	mov    0x260(%rsp),%rax
  701f28:	mov    (%rax),%rbx
  701f2b:	test   %rbx,%rbx
  701f2e:	je     701f6b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x37eb>
  701f30:	mov    0x30(%rsp),%rax
  701f35:	mov    (%rax,%r13,1),%r15
  701f39:	mov    0x38(%rsp),%rax
  701f3e:	mov    0x660(%rax),%rdi
  701f45:	mov    0x668(%rax),%rsi
  701f4c:	mov    %r15,%rdx
  701f4f:	call   6be6b0 <<alloc::collections::btree::map::BTreeMap<u64, gpui::runtime::list::ListRow>>::get::<u64>>
  701f54:	lea    0x760(%rsp),%rdi
  701f5c:	mov    %rbx,%rsi
  701f5f:	mov    %r15,%rdx
  701f62:	mov    %rax,%rcx
  701f65:	call   *0x340ca5(%rip)        # a42c10 <_DYNAMIC+0x678>
  701f6b:	mov    0x50(%rsp),%rdx
  701f70:	inc    %rdx
  701f73:	cmp    0x2b0(%rsp),%rdx
  701f7b:	mov    0x38(%rsp),%r15
  701f80:	jb     7002ed <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1b6d>
  701f86:	jmp    701ff2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3872>
  701f88:	mov    $0xffffffff,%edi
  701f8d:	jmp    701d98 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3618>
  701f92:	mov    0x8c0(%rsp),%rcx
  701f9a:	mov    0x48(%rsp),%rdx
  701f9f:	mov    %rcx,0x30(%rdx)
  701fa3:	movaps 0x8b0(%rsp),%xmm0
  701fab:	movups %xmm0,0x20(%rdx)
  701faf:	movaps 0x440(%rsp),%xmm0
  701fb7:	movaps %xmm0,0x370(%rsp)
  701fbf:	movups %xmm0,0x10(%rdx)
  701fc3:	mov    %rax,(%rdx)
  701fc6:	mov    %rsi,0x8(%rdx)
  701fca:	mov    $0x1,%r12b
  701fcd:	cmpl   $0xffffffff,0x760(%rsp)
  701fd5:	mov    $0x1,%r13b
  701fd8:	mov    $0x1,%bpl
  701fdb:	jne    70305f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x48df>
  701fe1:	jmp    70306c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x48ec>
  701fe6:	movq   $0x0,0x178(%rsp)
  701ff2:	mov    0x160(%rsp),%rax
  701ffa:	cmp    $0xffffffffffffffff,%rax
  701ffe:	je     70209e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x391e>
  702004:	mov    0x170(%rsp),%rsi
  70200c:	lea    0x0(,%rsi,4),%rcx
  702014:	cmp    %rcx,%rax
  702017:	jbe    702149 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x39c9>
  70201d:	lea    0x160(%rsp),%rdi
  702025:	mov    $0x8,%edx
  70202a:	mov    $0x18,%ecx
  70202f:	call   6f0750 <<alloc::raw_vec::RawVecInner>::shrink>
  702034:	cmp    $0xffffffffffffffff,%rax
  702038:	je     702149 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x39c9>
  70203e:	mov    %rax,%rdi
  702041:	mov    %rdx,%rsi
  702044:	call   *0x340846(%rip)        # a42890 <_DYNAMIC+0x2f8>
  70204a:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  70204f:	movaps 0x8b0(%rsp),%xmm0
  702057:	movaps 0x8c0(%rsp),%xmm1
  70205f:	movaps 0x8d0(%rsp),%xmm2
  702067:	mov    0x48(%rsp),%rcx
  70206c:	movups %xmm2,0x28(%rcx)
  702070:	movups %xmm1,0x18(%rcx)
  702074:	movups %xmm0,0x8(%rcx)
  702078:	mov    %rax,(%rcx)
  70207b:	mov    $0x1,%r12b
  70207e:	mov    $0x1,%r14b
  702081:	mov    $0x1,%r13b
  702084:	mov    $0x1,%bpl
  702087:	mov    $0x1,%r15b
  70208a:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  702093:	jne    703040 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x48c0>
  702099:	jmp    703050 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x48d0>
  70209e:	mov    0x6c8(%r15),%rax
  7020a5:	test   %rax,%rax
  7020a8:	je     702149 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x39c9>
  7020ae:	mov    0x10(%rax),%rdx
  7020b2:	cmp    %rdx,0x178(%rsp)
  7020ba:	je     702149 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x39c9>
  7020c0:	ja     70333a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4bba>
  7020c6:	mov    0x8(%rax),%rsi
  7020ca:	lea    0x480(%rsp),%rdi
  7020d2:	mov    0x178(%rsp),%rdx
  7020da:	call   6d9460 <<gpui::runtime::text_geometry::Entry as <[_]>::to_vec_in::ConvertVec>::to_vec::<alloc::alloc::Global>>
  7020df:	mov    0x490(%rsp),%rax
  7020e7:	mov    %rax,0x90(%rsp)
  7020ef:	movups 0x480(%rsp),%xmm0
  7020f7:	movaps %xmm0,0x80(%rsp)
  7020ff:	cmpq   $0xffffffffffffffff,0x160(%rsp)
  702108:	je     702117 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3997>
  70210a:	lea    0x160(%rsp),%rdi
  702112:	call   6c1730 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  702117:	mov    0x90(%rsp),%rax
  70211f:	mov    %rax,0x170(%rsp)
  702127:	movaps 0x80(%rsp),%xmm0
  70212f:	movaps %xmm0,0x160(%rsp)
  702137:	mov    0x160(%rsp),%rax
  70213f:	cmp    $0xffffffffffffffff,%rax
  702143:	jne    702004 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3884>
  702149:	cmpl   $0xffffffff,0x760(%rsp)
  702151:	je     702161 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x39e1>
  702153:	lea    0x760(%rsp),%rdi
  70215b:	call   *0x340ab7(%rip)        # a42c18 <_DYNAMIC+0x680>
  702161:	lea    0x1e8(%r15),%rbx
  702168:	mov    0x640(%r15),%rax
  70216f:	test   %rax,%rax
  702172:	je     702200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3a80>
  702178:	mov    0x100(%rax),%rdx
  70217f:	lea    0x278(%rsp),%rax
  702187:	mov    %rax,0x480(%rsp)
  70218f:	lea    0x2f(%rsp),%rax
  702194:	mov    %rax,0x488(%rsp)
  70219c:	mov    %rbx,0x490(%rsp)
  7021a4:	lea    0x140(%rsp),%rax
  7021ac:	mov    %rax,0x498(%rsp)
  7021b4:	lea    0x1c0(%rsp),%rax
  7021bc:	mov    %rax,0x4a0(%rsp)
  7021c4:	test   %rdx,%rdx
  7021c7:	je     702200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3a80>
  7021c9:	lea    0x80(%rsp),%rdi
  7021d1:	lea    0x480(%rsp),%rsi
  7021d9:	call   6db4c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}>
  7021de:	mov    0x90(%rsp),%rax
  7021e6:	mov    %rax,0x450(%rsp)
  7021ee:	movups 0x80(%rsp),%xmm0
  7021f6:	movaps %xmm0,0x440(%rsp)
  7021fe:	jmp    70220c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3a8c>
  702200:	movq   $0xffffffffffffffff,0x440(%rsp)
  70220c:	mov    %rbx,0x30(%rsp)
  702211:	mov    0x288(%rsp),%rax
  702219:	mov    %rax,0x490(%rsp)
  702221:	movups 0x278(%rsp),%xmm0
  702229:	movaps %xmm0,0x480(%rsp)
  702231:	lea    0xc0(%rsp),%rdi
  702239:	lea    0x440(%rsp),%rsi
  702241:	lea    0x480(%rsp),%rdx
  702249:	call   6b6810 <<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#37}>>
  70224e:	cmpb   $0x0,0x74d(%r15)
  702256:	je     7022ad <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3b2d>
  702258:	lea    0x480(%rsp),%rbx
  702260:	lea    0x8b0(%rsp),%rsi
  702268:	mov    $0x1f0,%edx
  70226d:	mov    %rbx,%rdi
  702270:	call   *0x3405aa(%rip)        # a42820 <memcpy@GLIBC_2.14>
  702276:	mov    $0x1,%al
  702278:	mov    %eax,0x58(%rsp)
  70227c:	mov    $0x1,%r12b
  70227f:	mov    $0x1,%al
  702281:	mov    %eax,0x40(%rsp)
  702285:	mov    $0x1,%r14b
  702288:	mov    $0x1,%r15b
  70228b:	mov    $0x1,%bpl
  70228e:	movb   $0x1,0x100(%rsp)
  702296:	mov    %rbx,%rdi
  702299:	call   *0x340af9(%rip)        # a42d98 <_DYNAMIC+0x800>
  70229f:	movq   $0x0,0x50(%rsp)
  7022a8:	jmp    70238c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3c0c>
  7022ad:	lea    0x480(%rsp),%rbx
  7022b5:	lea    0x8b0(%rsp),%rsi
  7022bd:	mov    $0x1f0,%edx
  7022c2:	mov    %rbx,%rdi
  7022c5:	call   *0x340555(%rip)        # a42820 <memcpy@GLIBC_2.14>
  7022cb:	mov    $0x1,%al
  7022cd:	mov    %eax,0x58(%rsp)
  7022d1:	mov    $0x1,%r12b
  7022d4:	mov    $0x1,%al
  7022d6:	mov    %eax,0x40(%rsp)
  7022da:	mov    $0x1,%r14b
  7022dd:	mov    $0x1,%r15b
  7022e0:	mov    $0x1,%bpl
  7022e3:	movb   $0x1,0x100(%rsp)
  7022eb:	mov    %rbx,%rdi
  7022ee:	call   *0x340aac(%rip)        # a42da0 <_DYNAMIC+0x808>
  7022f4:	mov    0x38(%rsp),%rcx
  7022f9:	cmpq   $0xffffffffffffffff,0x5b8(%rcx)
  702301:	je     70235c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3bdc>
  702303:	mov    0x5d0(%rcx),%rsi
  70230a:	jmp    70235e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3bde>
  70230c:	lea    0x84(%rsp),%rcx
  702314:	mov    0x14(%rcx),%rax
  702318:	movups 0x4(%rcx),%xmm0
  70231c:	movaps %xmm0,0x120(%rsp)
  702324:	mov    %rax,0x130(%rsp)
  70232c:	mov    0x48(%rsp),%rcx
  702331:	mov    %rax,0x18(%rcx)
  702335:	movups %xmm0,0x8(%rcx)
  702339:	movq   $0x23,(%rcx)
  702340:	jmp    703005 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4885>
  702345:	mov    0x48(%rsp),%rcx
  70234a:	movq   $0x23,(%rcx)
  702351:	mov    %eax,0x8(%rcx)
  702354:	mov    %edx,0xc(%rcx)
  702357:	jmp    703005 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4885>
  70235c:	xor    %esi,%esi
  70235e:	mov    $0x1,%cl
  702360:	mov    %ecx,0x58(%rsp)
  702364:	mov    $0x1,%r12b
  702367:	mov    $0x1,%cl
  702369:	mov    %ecx,0x40(%rsp)
  70236d:	mov    $0x1,%r14b
  702370:	mov    $0x1,%r15b
  702373:	mov    $0x1,%bpl
  702376:	movb   $0x1,0x100(%rsp)
  70237e:	mov    %rax,%rdi
  702381:	call   *0x340861(%rip)        # a42be8 <_DYNAMIC+0x650>
  702387:	mov    %rax,0x50(%rsp)
  70238c:	mov    0x38(%rsp),%rcx
  702391:	mov    0x648(%rcx),%rax
  702398:	mov    0x658(%rcx),%r12
  70239f:	test   %rax,%rax
  7023a2:	setne  %cl
  7023a5:	test   %r12,%r12
  7023a8:	setne  %dl
  7023ab:	test   %dl,%cl
  7023ad:	je     70259e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3e1e>
  7023b3:	mov    0x38(%rsp),%rcx
  7023b8:	mov    0x650(%rcx),%r13
  7023bf:	xor    %r14d,%r14d
  7023c2:	lea    0x480(%rsp),%rbx
  7023ca:	lea    0x370(%rsp),%r15
  7023d2:	jmp    7023e2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3c62>
  7023d4:	mov    $0x0,%eax
  7023d9:	dec    %r12
  7023dc:	je     70259e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3e1e>
  7023e2:	test   %r14,%r14
  7023e5:	jne    702468 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3ce8>
  7023eb:	test   %r13,%r13
  7023ee:	je     702417 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3c97>
  7023f0:	mov    %r13,%rcx
  7023f3:	mov    %rax,%r14
  7023f6:	and    $0x7,%rcx
  7023fa:	je     70241c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3c9c>
  7023fc:	xor    %edx,%edx
  7023fe:	xchg   %ax,%ax
  702400:	mov    0x590(%r14),%r14
  702407:	inc    %rdx
  70240a:	cmp    %rdx,%rcx
  70240d:	jne    702400 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3c80>
  70240f:	mov    %r13,%rax
  702412:	sub    %rdx,%rax
  702415:	jmp    70241f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3c9f>
  702417:	mov    %rax,%r14
  70241a:	jmp    702463 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3ce3>
  70241c:	mov    %r13,%rax
  70241f:	cmp    $0x8,%r13
  702423:	jb     702463 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3ce3>
  702425:	mov    0x590(%r14),%rcx
  70242c:	mov    0x590(%rcx),%rcx
  702433:	mov    0x590(%rcx),%rcx
  70243a:	mov    0x590(%rcx),%rcx
  702441:	mov    0x590(%rcx),%rcx
  702448:	mov    0x590(%rcx),%rcx
  70244f:	mov    0x590(%rcx),%rcx
  702456:	mov    0x590(%rcx),%r14
  70245d:	add    $0xfffffffffffffff8,%rax
  702461:	jne    702425 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3ca5>
  702463:	xor    %r13d,%r13d
  702466:	xor    %eax,%eax
  702468:	movzwl 0x58a(%r14),%ecx
  702470:	cmp    %rcx,%r13
  702473:	jae    702480 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3d00>
  702475:	mov    %r13,%rdx
  702478:	mov    %r14,%rcx
  70247b:	jmp    7024a7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3d27>
  70247d:	nopl   (%rax)
  702480:	mov    0x580(%r14),%rcx
  702487:	test   %rcx,%rcx
  70248a:	je     7032fb <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b7b>
  702490:	inc    %rax
  702493:	movzwl 0x588(%r14),%edx
  70249b:	mov    %rcx,%r14
  70249e:	cmp    0x58a(%rcx),%dx
  7024a5:	jae    702480 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3d00>
  7024a7:	test   %rax,%rax
  7024aa:	je     7024ea <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3d6a>
  7024ac:	lea    (%rcx,%rdx,8),%rsi
  7024b0:	add    $0x598,%rsi
  7024b7:	mov    %rax,%rdi
  7024ba:	and    $0x7,%rdi
  7024be:	je     7024f3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3d73>
  7024c0:	xor    %r8d,%r8d
  7024c3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7024d0:	mov    (%rsi),%r14
  7024d3:	lea    0x590(%r14),%rsi
  7024da:	inc    %r8
  7024dd:	cmp    %r8,%rdi
  7024e0:	jne    7024d0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3d50>
  7024e2:	mov    %rax,%rdi
  7024e5:	sub    %r8,%rdi
  7024e8:	jmp    7024f6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3d76>
  7024ea:	lea    0x1(%rdx),%r13
  7024ee:	mov    %rcx,%r14
  7024f1:	jmp    702544 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3dc4>
  7024f3:	mov    %rax,%rdi
  7024f6:	cmp    $0x8,%rax
  7024fa:	jb     702541 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3dc1>
  7024fc:	nopl   0x0(%rax)
  702500:	mov    (%rsi),%rax
  702503:	mov    0x590(%rax),%rax
  70250a:	mov    0x590(%rax),%rax
  702511:	mov    0x590(%rax),%rax
  702518:	mov    0x590(%rax),%rax
  70251f:	mov    0x590(%rax),%rax
  702526:	mov    0x590(%rax),%rax
  70252d:	mov    0x590(%rax),%r14
  702534:	lea    0x590(%r14),%rsi
  70253b:	add    $0xfffffffffffffff8,%rdi
  70253f:	jne    702500 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3d80>
  702541:	xor    %r13d,%r13d
  702544:	mov    %rdx,%rax
  702547:	shl    $0x4,%rax
  70254b:	cmpl   $0x1,(%rcx,%rax,1)
  70254f:	jne    7023d4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3c54>
  702555:	imul   $0x70,%rdx,%rdx
  702559:	lea    (%rcx,%rdx,1),%rbp
  70255d:	add    $0xb0,%rbp
  702564:	cmpl   $0x2,0x0(%rbp)
  702568:	jne    7023d4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3c54>
  70256e:	mov    0x8(%rcx,%rax,1),%rdx
  702573:	mov    %rbx,%rdi
  702576:	mov    %r15,%rsi
  702579:	call   *0x340799(%rip)        # a42d18 <_DYNAMIC+0x780>
  70257f:	cmpl   $0x1,0x480(%rsp)
  702587:	jne    7023d4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3c54>
  70258d:	movups 0x488(%rsp),%xmm0
  702595:	movups %xmm0,0x8(%rbp)
  702599:	jmp    7023d4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3c54>
  70259e:	mov    0x38(%rsp),%r15
  7025a3:	mov    0x660(%r15),%r8
  7025aa:	mov    0x670(%r15),%rax
  7025b1:	test   %r8,%r8
  7025b4:	setne  %cl
  7025b7:	test   %rax,%rax
  7025ba:	setne  %dl
  7025bd:	test   %dl,%cl
  7025bf:	mov    0x2c0(%rsp),%rbx
  7025c7:	mov    0x260(%rsp),%r13
  7025cf:	je     7027e8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4068>
  7025d5:	mov    0x668(%r15),%rsi
  7025dc:	xor    %ecx,%ecx
  7025de:	jmp    702603 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3e83>
  7025e0:	mov    $0x1,%r8b
  7025e3:	mov    %r12,%rbx
  7025e6:	dec    %rax
  7025e9:	shl    $0x5,%rdi
  7025ed:	add    %rdi,%rdx
  7025f0:	mov    %r8b,0x1c(%rdx)
  7025f4:	mov    $0x0,%r8d
  7025fa:	test   %rax,%rax
  7025fd:	je     7027e8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4068>
  702603:	test   %rcx,%rcx
  702606:	jne    702688 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3f08>
  70260c:	test   %rsi,%rsi
  70260f:	je     702637 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3eb7>
  702611:	mov    %rsi,%rdx
  702614:	mov    %r8,%rcx
  702617:	and    $0x7,%rdx
  70261b:	je     70263c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3ebc>
  70261d:	xor    %edi,%edi
  70261f:	nop
  702620:	mov    0x1c8(%rcx),%rcx
  702627:	inc    %rdi
  70262a:	cmp    %rdi,%rdx
  70262d:	jne    702620 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3ea0>
  70262f:	mov    %rsi,%rdx
  702632:	sub    %rdi,%rdx
  702635:	jmp    70263f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3ebf>
  702637:	mov    %r8,%rcx
  70263a:	jmp    702683 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3f03>
  70263c:	mov    %rsi,%rdx
  70263f:	cmp    $0x8,%rsi
  702643:	jb     702683 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3f03>
  702645:	mov    0x1c8(%rcx),%rcx
  70264c:	mov    0x1c8(%rcx),%rcx
  702653:	mov    0x1c8(%rcx),%rcx
  70265a:	mov    0x1c8(%rcx),%rcx
  702661:	mov    0x1c8(%rcx),%rcx
  702668:	mov    0x1c8(%rcx),%rcx
  70266f:	mov    0x1c8(%rcx),%rcx
  702676:	mov    0x1c8(%rcx),%rcx
  70267d:	add    $0xfffffffffffffff8,%rdx
  702681:	jne    702645 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3ec5>
  702683:	xor    %esi,%esi
  702685:	xor    %r8d,%r8d
  702688:	movzwl 0x1c2(%rcx),%edx
  70268f:	cmp    %rdx,%rsi
  702692:	jae    7026a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3f20>
  702694:	mov    %rsi,%rdi
  702697:	mov    %rcx,%rdx
  70269a:	jmp    7026c6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3f46>
  70269c:	nopl   0x0(%rax)
  7026a0:	mov    0x160(%rcx),%rdx
  7026a7:	test   %rdx,%rdx
  7026aa:	je     70330d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b8d>
  7026b0:	inc    %r8
  7026b3:	movzwl 0x1c0(%rcx),%edi
  7026ba:	mov    %rdx,%rcx
  7026bd:	cmp    0x1c2(%rdx),%di
  7026c4:	jae    7026a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3f20>
  7026c6:	test   %r8,%r8
  7026c9:	je     70270a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3f8a>
  7026cb:	lea    (%rdx,%rdi,8),%rsi
  7026cf:	add    $0x1d0,%rsi
  7026d6:	mov    %r8,%r9
  7026d9:	and    $0x7,%r9
  7026dd:	je     702713 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3f93>
  7026df:	xor    %r10d,%r10d
  7026e2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7026f0:	mov    (%rsi),%rcx
  7026f3:	lea    0x1c8(%rcx),%rsi
  7026fa:	inc    %r10
  7026fd:	cmp    %r10,%r9
  702700:	jne    7026f0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3f70>
  702702:	mov    %r8,%r9
  702705:	sub    %r10,%r9
  702708:	jmp    702716 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3f96>
  70270a:	lea    0x1(%rdi),%rsi
  70270e:	mov    %rdx,%rcx
  702711:	jmp    702763 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3fe3>
  702713:	mov    %r8,%r9
  702716:	cmp    $0x8,%r8
  70271a:	jb     702761 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3fe1>
  70271c:	nopl   0x0(%rax)
  702720:	mov    (%rsi),%rcx
  702723:	mov    0x1c8(%rcx),%rcx
  70272a:	mov    0x1c8(%rcx),%rcx
  702731:	mov    0x1c8(%rcx),%rcx
  702738:	mov    0x1c8(%rcx),%rcx
  70273f:	mov    0x1c8(%rcx),%rcx
  702746:	mov    0x1c8(%rcx),%rcx
  70274d:	mov    0x1c8(%rcx),%rcx
  702754:	lea    0x1c8(%rcx),%rsi
  70275b:	add    $0xfffffffffffffff8,%r9
  70275f:	jne    702720 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3fa0>
  702761:	xor    %esi,%esi
  702763:	mov    0x338(%rsp),%r8
  70276b:	test   %r8,%r8
  70276e:	je     7027e0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4060>
  702770:	mov    %rbx,%r12
  702773:	mov    0x168(%rdx,%rdi,8),%r9
  70277b:	mov    0x340(%rsp),%r10
  702783:	movzwl 0x62(%r8),%ebx
  702788:	mov    %ebx,%r14d
  70278b:	shl    $0x3,%r14d
  70278f:	mov    $0xffffffffffffffff,%r11
  702796:	cs nopw 0x0(%rax,%rax,1)
  7027a0:	test   %r14,%r14
  7027a3:	je     7027cd <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x404d>
  7027a5:	cmp    0x10(%r8,%r11,8),%r9
  7027aa:	seta   %bpl
  7027ae:	sbb    $0x0,%bpl
  7027b2:	inc    %r11
  7027b5:	add    $0xfffffffffffffff8,%r14
  7027b9:	cmp    $0x1,%bpl
  7027bd:	je     7027a0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4020>
  7027bf:	movzbl %bpl,%ebx
  7027c3:	test   %ebx,%ebx
  7027c5:	je     7025e0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3e60>
  7027cb:	jmp    7027d0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4050>
  7027cd:	mov    %rbx,%r11
  7027d0:	mov    %r12,%rbx
  7027d3:	sub    $0x1,%r10
  7027d7:	jb     7027e0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4060>
  7027d9:	mov    0x68(%r8,%r11,8),%r8
  7027de:	jmp    702783 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4003>
  7027e0:	xor    %r8d,%r8d
  7027e3:	jmp    7025e6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x3e66>
  7027e8:	cmpl   $0x2,0xbd0(%rsp)
  7027f0:	mov    $0x1,%bpl
  7027f3:	je     702830 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x40b0>
  7027f5:	lea    0x480(%rsp),%rdi
  7027fd:	lea    0xbd0(%rsp),%rsi
  702805:	mov    $0x1e8,%edx
  70280a:	call   *0x340010(%rip)        # a42820 <memcpy@GLIBC_2.14>
  702810:	mov    %r15,%rdi
  702813:	call   6c6240 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  702818:	lea    0x480(%rsp),%rsi
  702820:	mov    $0x1e8,%edx
  702825:	mov    %r15,%rdi
  702828:	call   *0x33fff2(%rip)        # a42820 <memcpy@GLIBC_2.14>
  70282e:	xor    %ebp,%ebp
  702830:	mov    $0x1,%al
  702832:	mov    %eax,0x58(%rsp)
  702836:	cmpl   $0xffffffff,0x760(%rsp)
  70283e:	mov    $0x1,%r14b
  702841:	je     7029d9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4259>
  702847:	movups 0x7b0(%rsp),%xmm0
  70284f:	movaps %xmm0,0x410(%rsp)
  702857:	movups 0x7a0(%rsp),%xmm0
  70285f:	movaps %xmm0,0x400(%rsp)
  702867:	movups 0x760(%rsp),%xmm0
  70286f:	movups 0x770(%rsp),%xmm1
  702877:	movups 0x780(%rsp),%xmm2
  70287f:	movupd 0x790(%rsp),%xmm3
  702888:	movapd %xmm3,0x3f0(%rsp)
  702891:	movaps %xmm2,0x3e0(%rsp)
  702899:	movaps %xmm1,0x3d0(%rsp)
  7028a1:	movaps %xmm0,0x3c0(%rsp)
  7028a9:	cmpq   $0x0,0x0(%r13)
  7028ae:	je     7029af <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x422f>
  7028b4:	mov    0x30(%rsp),%rax
  7028b9:	mov    %rax,0x480(%rsp)
  7028c1:	lea    0x140(%rsp),%rax
  7028c9:	mov    %rax,0x488(%rsp)
  7028d1:	lea    0x1c0(%rsp),%rax
  7028d9:	mov    %rax,0x490(%rsp)
  7028e1:	lea    0x80(%rsp),%rdi
  7028e9:	lea    0x370(%rsp),%rsi
  7028f1:	lea    0x480(%rsp),%rdx
  7028f9:	call   6b86e0 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>>
  7028fe:	lea    0x3c0(%rsp),%rdi
  702906:	call   6c74f0 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportColumn>>
  70290b:	mov    0x90(%rsp),%rax
  702913:	mov    %rax,0x3d0(%rsp)
  70291b:	movups 0x80(%rsp),%xmm0
  702923:	movaps %xmm0,0x3c0(%rsp)
  70292b:	mov    0x0(%r13),%rdi
  70292f:	cmpl   $0xffffffff,0x60(%rdi)
  702933:	je     702942 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x41c2>
  702935:	add    $0x60,%rdi
  702939:	call   6c78e0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  70293e:	mov    0x0(%r13),%rdi
  702942:	movaps 0x410(%rsp),%xmm0
  70294a:	movups %xmm0,0xb0(%rdi)
  702951:	movaps 0x400(%rsp),%xmm0
  702959:	movups %xmm0,0xa0(%rdi)
  702960:	movaps 0x3c0(%rsp),%xmm0
  702968:	mov    0x3d0(%rsp),%rax
  702970:	mov    0x3d8(%rsp),%rcx
  702978:	movaps 0x3e0(%rsp),%xmm1
  702980:	movaps 0x3f0(%rsp),%xmm2
  702988:	movups %xmm2,0x90(%rdi)
  70298f:	movups %xmm1,0x80(%rdi)
  702996:	mov    %rax,0x70(%rdi)
  70299a:	mov    %rcx,0x78(%rdi)
  70299e:	movups %xmm0,0x60(%rdi)
  7029a2:	movl   $0x0,0x58(%rsp)
  7029aa:	xor    %r14d,%r14d
  7029ad:	jmp    7029d9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4259>
  7029af:	mov    $0x1,%al
  7029b1:	mov    %eax,0x58(%rsp)
  7029b5:	xor    %r14d,%r14d
  7029b8:	lea    0x3c0(%rsp),%rdi
  7029c0:	mov    $0x1,%r12b
  7029c3:	mov    $0x1,%al
  7029c5:	mov    %eax,0x40(%rsp)
  7029c9:	mov    $0x1,%r15b
  7029cc:	movb   $0x1,0x100(%rsp)
  7029d4:	call   6c78e0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  7029d9:	mov    %r14d,0x30(%rsp)
  7029de:	mov    0xc0(%rsp),%r15
  7029e6:	cmp    $0xffffffffffffffff,%r15
  7029ea:	sete   0x100(%rsp)
  7029f2:	je     702a5e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x42de>
  7029f4:	mov    %rbx,%r12
  7029f7:	mov    0xc8(%rsp),%rax
  7029ff:	mov    %rax,0x40(%rsp)
  702a04:	mov    0xd0(%rsp),%r14
  702a0c:	mov    %r13,%rdi
  702a0f:	call   6b6a20 <<core::option::Option<alloc::boxed::Box<gpui::runtime::metadata::Metadata>>>::get_or_insert_with::<<alloc::boxed::Box<gpui::runtime::metadata::Metadata> as core::default::Default>::default>>
  702a14:	mov    $0x100,%ebx
  702a19:	add    0x0(%r13),%rbx
  702a1d:	mov    %rbx,%rdi
  702a20:	call   6b6880 <<core::option::Option<alloc::boxed::Box<gpui::runtime::geometry::Geometry>>>::get_or_insert_with::<<alloc::boxed::Box<gpui::runtime::geometry::Geometry> as core::default::Default>::default>>
  702a25:	mov    (%rbx),%rdi
  702a28:	mov    %r15,0x480(%rsp)
  702a30:	mov    0x40(%rsp),%rax
  702a35:	mov    %rax,0x488(%rsp)
  702a3d:	mov    %r14,0x490(%rsp)
  702a45:	lea    0x480(%rsp),%rsi
  702a4d:	call   *0x340355(%rip)        # a42da8 <_DYNAMIC+0x810>
  702a53:	mov    %r12,%rbx
  702a56:	mov    0x260(%rsp),%r13
  702a5e:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  702a67:	je     702aa2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4322>
  702a69:	mov    0x180(%rsp),%rax
  702a71:	mov    (%rax),%rdi
  702a74:	test   %rdi,%rdi
  702a77:	mov    0x38(%rsp),%r14
  702a7c:	je     7032dd <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b5d>
  702a82:	lea    0x7f8(%rsp),%rdx
  702a8a:	mov    0x2b8(%rsp),%rsi
  702a92:	call   *0x340318(%rip)        # a42db0 <_DYNAMIC+0x818>
  702a98:	movl   $0x0,0x40(%rsp)
  702aa0:	jmp    702aad <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x432d>
  702aa2:	mov    $0x1,%al
  702aa4:	mov    %eax,0x40(%rsp)
  702aa8:	mov    0x38(%rsp),%r14
  702aad:	mov    0x0(%r13),%rax
  702ab1:	test   %rax,%rax
  702ab4:	je     702b03 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4383>
  702ab6:	mov    0xe0(%rax),%rax
  702abd:	test   %rax,%rax
  702ac0:	je     702b03 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4383>
  702ac2:	mov    0x7e8(%rsp),%rcx
  702aca:	mov    %rcx,0x40(%rax)
  702ace:	mov    0x328(%rsp),%rcx
  702ad6:	mov    %rcx,0x48(%rax)
  702ada:	mov    0x330(%rsp),%ecx
  702ae1:	mov    %ecx,0x50(%rax)
  702ae4:	movzbl 0x7b(%rsp),%ecx
  702ae9:	mov    %cl,0x54(%rax)
  702aec:	movzwl 0xe8(%rsp),%ecx
  702af4:	mov    %cx,0x55(%rax)
  702af8:	movzbl 0xea(%rsp),%ecx
  702b00:	mov    %cl,0x57(%rax)
  702b03:	mov    0x6c8(%r14),%rdi
  702b0a:	test   %rdi,%rdi
  702b0d:	je     702b63 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x43e3>
  702b0f:	mov    0x170(%rsp),%rax
  702b17:	mov    %rax,0x490(%rsp)
  702b1f:	movaps 0x160(%rsp),%xmm0
  702b27:	movaps %xmm0,0x480(%rsp)
  702b2f:	cmpq   $0xffffffffffffffff,0x18(%rdi)
  702b34:	je     702b46 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x43c6>
  702b36:	add    $0x18,%rdi
  702b3a:	call   6c1730 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  702b3f:	mov    0x6c8(%r14),%rdi
  702b46:	mov    0x490(%rsp),%rax
  702b4e:	mov    %rax,0x28(%rdi)
  702b52:	movaps 0x480(%rsp),%xmm0
  702b5a:	movups %xmm0,0x18(%rdi)
  702b5e:	xor    %r12d,%r12d
  702b61:	jmp    702b66 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x43e6>
  702b63:	mov    $0x1,%r12b
  702b66:	mov    0x1d0(%rsp),%rax
  702b6e:	mov    %rax,0x490(%rsp)
  702b76:	movups 0x1c0(%rsp),%xmm0
  702b7e:	movaps %xmm0,0x480(%rsp)
  702b86:	lea    0x5b8(%r14),%r15
  702b8d:	cmpq   $0xffffffffffffffff,0x5b8(%r14)
  702b95:	je     702b9f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x441f>
  702b97:	mov    %r15,%rdi
  702b9a:	call   6c13a0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  702b9f:	mov    0x490(%rsp),%rax
  702ba7:	mov    %rax,0x10(%r15)
  702bab:	movaps 0x480(%rsp),%xmm0
  702bb3:	movups %xmm0,(%r15)
  702bb7:	mov    0x38(%rsp),%rdi
  702bbc:	mov    0x50(%rsp),%rax
  702bc1:	mov    %rax,0x5d0(%rdi)
  702bc8:	mov    %bx,0x5d8(%rdi)
  702bcf:	mov    0x15c(%rsp),%eax
  702bd6:	mov    %ax,0x5da(%rdi)
  702bdd:	movss  0x7c(%rsp),%xmm0
  702be3:	movss  %xmm0,0x5dc(%rdi)
  702beb:	xor    %r15d,%r15d
  702bee:	mov    0x30(%rsp),%r14d
  702bf3:	call   6f0840 <<gpui::runtime::Runtime<text_column_public_control::Input>>::prune_focus>
  702bf8:	mov    0x38(%rsp),%r14
  702bfd:	mov    0x310(%rsp),%rax
  702c05:	mov    %rax,0x6b0(%r14)
  702c0c:	mov    0x2b8(%rsp),%rax
  702c14:	mov    %rax,0x6b8(%r14)
  702c1b:	mov    0x690(%r14),%rax
  702c22:	mov    0x6c8(%r14),%rdi
  702c29:	mov    %rax,0x6c0(%r14)
  702c30:	mov    0x7f0(%rsp),%rax
  702c38:	mov    %rax,0x5e8(%r14)
  702c3f:	cmpq   $0x0,0x2e8(%r14)
  702c47:	setne  %al
  702c4a:	test   %rdi,%rdi
  702c4d:	sete   %cl
  702c50:	or     %al,%cl
  702c52:	cmp    $0x1,%cl
  702c55:	je     702c6f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x44ef>
  702c57:	add    $0x30,%rdi
  702c5b:	call   6bf7e0 <core::ptr::drop_glue::<core::option::Option<gpui_canvas::text::TextSystem>>>
  702c60:	mov    0x6c8(%r14),%rax
  702c67:	movq   $0x0,0x30(%rax)
  702c6f:	movb   $0x0,0x74b(%r14)
  702c77:	movw   $0x0,0x748(%r14)
  702c81:	lea    0x678(%r14),%rdi
  702c88:	xor    %r15d,%r15d
  702c8b:	mov    0x30(%rsp),%r14d
  702c90:	call   6f84e0 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::clear>
  702c95:	mov    0x38(%rsp),%rsi
  702c9a:	cmpb   $0x0,0x74d(%rsi)
  702ca1:	je     702cd5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4555>
  702ca3:	xor    %r15d,%r15d
  702ca6:	lea    0x480(%rsp),%rdi
  702cae:	mov    0x310(%rsp),%rdx
  702cb6:	mov    0x2b8(%rsp),%rcx
  702cbe:	call   6fe1d0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::acknowledge>
  702cc3:	mov    0x480(%rsp),%rax
  702ccb:	cmp    $0xfffffffffffffffe,%rax
  702ccf:	jne    702e18 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4698>
  702cd5:	mov    0x48(%rsp),%rax
  702cda:	movq   $0xfffffffffffffffe,(%rax)
  702ce1:	cmpb   $0x0,0x58(%rsp)
  702ce6:	je     702cf5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4575>
  702ce8:	lea    0x370(%rsp),%rdi
  702cf0:	call   6c74a0 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportBuild>>
  702cf5:	xor    %r13d,%r13d
  702cf8:	lea    0x338(%rsp),%rdi
  702d00:	call   6c4400 <core::ptr::drop_glue::<alloc::collections::btree::set::BTreeSet<gpui::list::ListId>>>
  702d05:	mov    0x140(%rsp),%rsi
  702d0d:	test   %rsi,%rsi
  702d10:	je     702d29 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x45a9>
  702d12:	mov    0x148(%rsp),%rdi
  702d1a:	shl    $0x2,%rsi
  702d1e:	mov    $0x4,%edx
  702d23:	call   *0x33fad7(%rip)        # a42800 <_DYNAMIC+0x268>
  702d29:	mov    0x188(%rsp),%rsi
  702d31:	test   %rsi,%rsi
  702d34:	je     702d49 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x45c9>
  702d36:	mov    0x190(%rsp),%rdi
  702d3e:	mov    $0x1,%edx
  702d43:	call   *0x33fab7(%rip)        # a42800 <_DYNAMIC+0x268>
  702d49:	mov    0x228(%rsp),%rsi
  702d51:	test   %rsi,%rsi
  702d54:	je     702d6d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x45ed>
  702d56:	mov    0x230(%rsp),%rdi
  702d5e:	shl    $0x4,%rsi
  702d62:	mov    $0x4,%edx
  702d67:	call   *0x33fa93(%rip)        # a42800 <_DYNAMIC+0x268>
  702d6d:	mov    0x210(%rsp),%rsi
  702d75:	test   %rsi,%rsi
  702d78:	je     702d91 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4611>
  702d7a:	mov    0x218(%rsp),%rdi
  702d82:	shl    $0x4,%rsi
  702d86:	mov    $0x4,%edx
  702d8b:	call   *0x33fa6f(%rip)        # a42800 <_DYNAMIC+0x268>
  702d91:	mov    0x1e8(%rsp),%rax
  702d99:	test   %rax,%rax
  702d9c:	je     702db5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4635>
  702d9e:	mov    0x1f0(%rsp),%rdi
  702da6:	imul   $0x38,%rax,%rsi
  702daa:	mov    $0x8,%edx
  702daf:	call   *0x33fa4b(%rip)        # a42800 <_DYNAMIC+0x268>
  702db5:	cmpq   $0x0,0x1b0(%rsp)
  702dbe:	je     702dcd <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x464d>
  702dc0:	mov    0x1b8(%rsp),%rdi
  702dc8:	call   6c5ca0 <core::ptr::drop_glue::<gpui_canvas::text::TextShaper>>
  702dcd:	test   %r12b,%r12b
  702dd0:	je     702dea <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x466a>
  702dd2:	cmpq   $0xffffffffffffffff,0x160(%rsp)
  702ddb:	je     702dea <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x466a>
  702ddd:	lea    0x160(%rsp),%rdi
  702de5:	call   6c1730 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  702dea:	mov    0x118(%rsp),%rax
  702df2:	test   %rax,%rax
  702df5:	je     6fffb7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1837>
  702dfb:	lock decq (%rax)
  702dff:	jne    6fffb7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1837>
  702e05:	lea    0x118(%rsp),%rdi
  702e0d:	call   *0x33fabd(%rip)        # a428d0 <_DYNAMIC+0x338>
  702e13:	jmp    6fffb7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1837>
  702e18:	mov    0x4a8(%rsp),%rcx
  702e20:	movzbl 0x4b0(%rsp),%edx
  702e28:	mov    0x4b1(%rsp),%esi
  702e2f:	mov    %esi,0x80(%rsp)
  702e36:	mov    0x4b4(%rsp),%esi
  702e3d:	mov    %esi,0x83(%rsp)
  702e44:	movups 0x488(%rsp),%xmm0
  702e4c:	movups 0x498(%rsp),%xmm1
  702e54:	mov    0x80(%rsp),%esi
  702e5b:	mov    0x83(%rsp),%edi
  702e62:	mov    0x48(%rsp),%r8
  702e67:	mov    %edi,0x34(%r8)
  702e6b:	mov    %esi,0x31(%r8)
  702e6f:	mov    %rax,(%r8)
  702e72:	movups %xmm0,0x8(%r8)
  702e77:	movups %xmm1,0x18(%r8)
  702e7c:	mov    %rcx,0x28(%r8)
  702e80:	mov    %dl,0x30(%r8)
  702e84:	xor    %r13d,%r13d
  702e87:	cmpb   $0x0,0x58(%rsp)
  702e8c:	mov    0x40(%rsp),%ebx
  702e90:	jne    703020 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x48a0>
  702e96:	jmp    70302d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x48ad>
  702e9b:	movzbl 0x481(%rsp),%eax
  702ea3:	mov    0x48(%rsp),%rcx
  702ea8:	movq   $0x22,(%rcx)
  702eaf:	mov    %al,0x8(%rcx)
  702eb2:	jmp    703005 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4885>
  702eb7:	mov    0x48(%rsp),%rax
  702ebc:	movq   $0x1f,(%rax)
  702ec3:	jmp    6fffb7 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1837>
  702ec8:	mov    0xb0(%rsp),%rcx
  702ed0:	mov    0x48(%rsp),%rdx
  702ed5:	mov    %rcx,0x30(%rdx)
  702ed9:	movups 0x90(%rsp),%xmm0
  702ee1:	movups 0xa0(%rsp),%xmm1
  702ee9:	movups %xmm1,0x20(%rdx)
  702eed:	movups %xmm0,0x10(%rdx)
  702ef1:	mov    %rax,(%rdx)
  702ef4:	mov    0xe0(%rsp),%rax
  702efc:	mov    %rax,0x8(%rdx)
  702f00:	jmp    703005 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4885>
  702f05:	mov    0x4b0(%rsp),%rax
  702f0d:	mov    0x48(%rsp),%rcx
  702f12:	mov    %rax,0x30(%rcx)
  702f16:	movups 0x480(%rsp),%xmm0
  702f1e:	movups 0x490(%rsp),%xmm1
  702f26:	movups 0x4a0(%rsp),%xmm2
  702f2e:	movups %xmm2,0x20(%rcx)
  702f32:	movups %xmm1,0x10(%rcx)
  702f36:	movups %xmm0,(%rcx)
  702f39:	jmp    703005 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4885>
  702f3e:	mov    0x30(%rsp),%rax
  702f43:	mov    0x20(%rax,%r13,1),%esi
  702f48:	lea    0x80(%rsp),%rdi
  702f50:	lea    0x810(%rsp),%rdx
  702f58:	call   6db3f0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#23}>
  702f5d:	mov    0xb0(%rsp),%rax
  702f65:	mov    %rax,0x840(%rsp)
  702f6d:	movups 0x80(%rsp),%xmm0
  702f75:	movups 0x90(%rsp),%xmm1
  702f7d:	movups 0xa0(%rsp),%xmm2
  702f85:	movaps %xmm2,0x830(%rsp)
  702f8d:	movaps %xmm1,0x820(%rsp)
  702f95:	movaps %xmm0,0x810(%rsp)
  702f9d:	mov    0x810(%rsp),%rax
  702fa5:	mov    0x838(%rsp),%rcx
  702fad:	mov    0x48(%rsp),%rdx
  702fb2:	mov    %rcx,0x28(%rdx)
  702fb6:	mov    0x840(%rsp),%rcx
  702fbe:	mov    %rcx,0x30(%rdx)
  702fc2:	lea    0x818(%rsp),%rcx
  702fca:	movups (%rcx),%xmm0
  702fcd:	movups 0x10(%rcx),%xmm1
  702fd1:	movups %xmm0,0x8(%rdx)
  702fd5:	movups %xmm1,0x18(%rdx)
  702fd9:	mov    %rax,(%rdx)
  702fdc:	jmp    703005 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4885>
  702fde:	mov    0x48(%rsp),%rax
  702fe3:	movq   $0x18,(%rax)
  702fea:	jmp    703005 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4885>
  702fec:	mov    0x124(%rsp),%ecx
  702ff3:	mov    0x48(%rsp),%rdx
  702ff8:	movq   $0x23,(%rdx)
  702fff:	mov    %eax,0x8(%rdx)
  703002:	mov    %ecx,0xc(%rdx)
  703005:	lea    0x8b0(%rsp),%rdi
  70300d:	call   6c6240 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  703012:	mov    $0x1,%r12b
  703015:	mov    $0x1,%bl
  703017:	mov    $0x1,%r14b
  70301a:	mov    $0x1,%r13b
  70301d:	mov    $0x1,%bpl
  703020:	lea    0x370(%rsp),%rdi
  703028:	call   6c74a0 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportBuild>>
  70302d:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  703036:	setne  %al
  703039:	mov    %r13d,%r15d
  70303c:	test   %bl,%al
  70303e:	je     703050 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x48d0>
  703040:	lea    0x7f8(%rsp),%rdi
  703048:	call   6c1520 <core::ptr::drop_glue::<alloc::vec::Vec<gpui_canvas::image::Image>>>
  70304d:	mov    %r15d,%r13d
  703050:	cmpl   $0xffffffff,0x760(%rsp)
  703058:	je     70306c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x48ec>
  70305a:	test   %r14b,%r14b
  70305d:	je     70306c <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x48ec>
  70305f:	lea    0x760(%rsp),%rdi
  703067:	call   6c78e0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  70306c:	lea    0x338(%rsp),%rdi
  703074:	call   6c4400 <core::ptr::drop_glue::<alloc::collections::btree::set::BTreeSet<gpui::list::ListId>>>
  703079:	mov    0x140(%rsp),%rsi
  703081:	test   %rsi,%rsi
  703084:	je     70309d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x491d>
  703086:	mov    0x148(%rsp),%rdi
  70308e:	shl    $0x2,%rsi
  703092:	mov    $0x4,%edx
  703097:	call   *0x33f763(%rip)        # a42800 <_DYNAMIC+0x268>
  70309d:	mov    0x188(%rsp),%rsi
  7030a5:	test   %rsi,%rsi
  7030a8:	je     7030bd <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x493d>
  7030aa:	mov    0x190(%rsp),%rdi
  7030b2:	mov    $0x1,%edx
  7030b7:	call   *0x33f743(%rip)        # a42800 <_DYNAMIC+0x268>
  7030bd:	mov    0x228(%rsp),%rsi
  7030c5:	test   %rsi,%rsi
  7030c8:	je     7030e1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4961>
  7030ca:	mov    0x230(%rsp),%rdi
  7030d2:	shl    $0x4,%rsi
  7030d6:	mov    $0x4,%edx
  7030db:	call   *0x33f71f(%rip)        # a42800 <_DYNAMIC+0x268>
  7030e1:	mov    0x210(%rsp),%rsi
  7030e9:	test   %rsi,%rsi
  7030ec:	je     703105 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4985>
  7030ee:	mov    0x218(%rsp),%rdi
  7030f6:	shl    $0x4,%rsi
  7030fa:	mov    $0x4,%edx
  7030ff:	call   *0x33f6fb(%rip)        # a42800 <_DYNAMIC+0x268>
  703105:	mov    0x1e8(%rsp),%rax
  70310d:	test   %rax,%rax
  703110:	je     703129 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x49a9>
  703112:	mov    0x1f0(%rsp),%rdi
  70311a:	imul   $0x38,%rax,%rsi
  70311e:	mov    $0x8,%edx
  703123:	call   *0x33f6d7(%rip)        # a42800 <_DYNAMIC+0x268>
  703129:	test   %r13b,%r13b
  70312c:	je     70315f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x49df>
  70312e:	mov    0x278(%rsp),%rsi
  703136:	test   %rsi,%rsi
  703139:	je     703152 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x49d2>
  70313b:	mov    0x280(%rsp),%rdi
  703143:	shl    $0x4,%rsi
  703147:	mov    $0x4,%edx
  70314c:	call   *0x33f6ae(%rip)        # a42800 <_DYNAMIC+0x268>
  703152:	lea    0x1c0(%rsp),%rdi
  70315a:	call   6c13a0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  70315f:	mov    0x718(%rsp),%rax
  703167:	cmp    $0xfffffffffffffffe,%rax
  70316b:	jne    6ffb84 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x1404>
  703171:	jmp    6fff45 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x17c5>
  703176:	lea    -0x6b2dff(%rip),%rdi        # 5037e <GCC_except_table0+0x10536>
  70317d:	lea    0x320984(%rip),%rdx        # a23b08 <__frame_dummy_init_array_entry+0x1b18>
  703184:	mov    $0x83,%esi
  703189:	call   *0x33f6a9(%rip)        # a42838 <_DYNAMIC+0x2a0>
  70318f:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  703194:	lea    -0x6b30b7(%rip),%rdi        # 500e4 <GCC_except_table0+0x1029c>
  70319b:	lea    0x32042e(%rip),%rdx        # a235d0 <__frame_dummy_init_array_entry+0x15e0>
  7031a2:	mov    $0x1c,%esi
  7031a7:	call   *0x33f7f3(%rip)        # a429a0 <_DYNAMIC+0x408>
  7031ad:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  7031b2:	mov    $0x1,%bpl
  7031b5:	mov    $0x8,%edi
  7031ba:	mov    $0x78,%esi
  7031bf:	call   *0x33f653(%rip)        # a42818 <_DYNAMIC+0x280>
  7031c5:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  7031ca:	lea    0x31f627(%rip),%rdi        # a227f8 <__frame_dummy_init_array_entry+0x808>
  7031d1:	call   *0x33f6c9(%rip)        # a428a0 <_DYNAMIC+0x308>
  7031d7:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  7031dc:	lea    0x31f765(%rip),%rax        # a22948 <__frame_dummy_init_array_entry+0x958>
  7031e3:	jmp    7032c2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b42>
  7031e8:	lea    0x31f609(%rip),%rdi        # a227f8 <__frame_dummy_init_array_entry+0x808>
  7031ef:	call   *0x33f6ab(%rip)        # a428a0 <_DYNAMIC+0x308>
  7031f5:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  7031fa:	lea    0x320b27(%rip),%rax        # a23d28 <__frame_dummy_init_array_entry+0x1d38>
  703201:	mov    %rax,0x2f8(%rsp)
  703209:	lea    -0x6b2e51(%rip),%rdi        # 503bf <GCC_except_table0+0x10577>
  703210:	mov    $0x1e,%esi
  703215:	mov    0x2f8(%rsp),%rdx
  70321d:	call   *0x33f77d(%rip)        # a429a0 <_DYNAMIC+0x408>
  703223:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  703228:	mov    0x490(%rsp),%rsi
  703230:	mov    $0x1,%bpl
  703233:	call   *0x33f657(%rip)        # a42890 <_DYNAMIC+0x2f8>
  703239:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  70323e:	mov    0x490(%rsp),%rsi
  703246:	call   *0x33f644(%rip)        # a42890 <_DYNAMIC+0x2f8>
  70324c:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  703251:	mov    0x490(%rsp),%rsi
  703259:	call   *0x33f631(%rip)        # a42890 <_DYNAMIC+0x2f8>
  70325f:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  703264:	mov    0x490(%rsp),%rsi
  70326c:	call   *0x33f61e(%rip)        # a42890 <_DYNAMIC+0x2f8>
  703272:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  703277:	mov    0x490(%rsp),%rsi
  70327f:	call   *0x33f60b(%rip)        # a42890 <_DYNAMIC+0x2f8>
  703285:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  70328a:	mov    0x490(%rsp),%rsi
  703292:	call   *0x33f5f8(%rip)        # a42890 <_DYNAMIC+0x2f8>
  703298:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  70329d:	lea    -0x6b2f26(%rip),%rdi        # 5037e <GCC_except_table0+0x10536>
  7032a4:	lea    0x32085d(%rip),%rdx        # a23b08 <__frame_dummy_init_array_entry+0x1b18>
  7032ab:	mov    $0x83,%esi
  7032b0:	call   *0x33f582(%rip)        # a42838 <_DYNAMIC+0x2a0>
  7032b6:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  7032bb:	lea    0x320a7e(%rip),%rax        # a23d40 <__frame_dummy_init_array_entry+0x1d50>
  7032c2:	mov    %rax,0x250(%rsp)
  7032ca:	mov    0x250(%rsp),%rdi
  7032d2:	call   *0x33f5c8(%rip)        # a428a0 <_DYNAMIC+0x308>
  7032d8:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  7032dd:	lea    0x32099c(%rip),%rdi        # a23c80 <__frame_dummy_init_array_entry+0x1c90>
  7032e4:	call   *0x33f5b6(%rip)        # a428a0 <_DYNAMIC+0x308>
  7032ea:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  7032ef:	lea    0x31f54a(%rip),%rax        # a22840 <__frame_dummy_init_array_entry+0x850>
  7032f6:	jmp    7033aa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c2a>
  7032fb:	lea    0x31f50e(%rip),%rdi        # a22810 <__frame_dummy_init_array_entry+0x820>
  703302:	call   *0x33f598(%rip)        # a428a0 <_DYNAMIC+0x308>
  703308:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  70330d:	lea    0x31f4fc(%rip),%rdi        # a22810 <__frame_dummy_init_array_entry+0x820>
  703314:	call   *0x33f586(%rip)        # a428a0 <_DYNAMIC+0x308>
  70331a:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  70331f:	lea    0x320a32(%rip),%rax        # a23d58 <__frame_dummy_init_array_entry+0x1d68>
  703326:	jmp    7032c2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4b42>
  703328:	lea    0x3208b1(%rip),%rax        # a23be0 <__frame_dummy_init_array_entry+0x1bf0>
  70332f:	jmp    7033aa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c2a>
  703331:	lea    0x3208c0(%rip),%rax        # a23bf8 <__frame_dummy_init_array_entry+0x1c08>
  703338:	jmp    7033aa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c2a>
  70333a:	lea    0x320927(%rip),%rcx        # a23c68 <__frame_dummy_init_array_entry+0x1c78>
  703341:	xor    %edi,%edi
  703343:	mov    0x178(%rsp),%rsi
  70334b:	call   *0x33f66f(%rip)        # a429c0 <_DYNAMIC+0x428>
  703351:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  703356:	lea    0x3200a3(%rip),%rax        # a23400 <__frame_dummy_init_array_entry+0x1410>
  70335d:	jmp    7033aa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c2a>
  70335f:	lea    0x320082(%rip),%rax        # a233e8 <__frame_dummy_init_array_entry+0x13f8>
  703366:	jmp    7033aa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c2a>
  703368:	mov    %rbx,%rbp
  70336b:	lea    0x32008e(%rip),%rax        # a23400 <__frame_dummy_init_array_entry+0x1410>
  703372:	jmp    7033aa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c2a>
  703374:	mov    %rax,%rbp
  703377:	jmp    7033a3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c23>
  703379:	mov    %rbx,%rbp
  70337c:	lea    0x320065(%rip),%rax        # a233e8 <__frame_dummy_init_array_entry+0x13f8>
  703383:	jmp    7033aa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c2a>
  703385:	mov    %rax,%r13
  703388:	lea    0x320059(%rip),%rax        # a233e8 <__frame_dummy_init_array_entry+0x13f8>
  70338f:	jmp    7033aa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c2a>
  703391:	mov    %rax,%r13
  703394:	lea    0x320065(%rip),%rax        # a23400 <__frame_dummy_init_array_entry+0x1410>
  70339b:	jmp    7033aa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4c2a>
  70339d:	mov    %rcx,%rbp
  7033a0:	mov    %rax,%r13
  7033a3:	lea    0x32006e(%rip),%rax        # a23418 <__frame_dummy_init_array_entry+0x1428>
  7033aa:	mov    %rax,0x60(%rsp)
  7033af:	mov    %rbp,%rdi
  7033b2:	mov    %r13,%rsi
  7033b5:	mov    0x60(%rsp),%rdx
  7033ba:	call   *0x33f470(%rip)        # a42830 <_DYNAMIC+0x298>
  7033c0:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  7033c5:	mov    $0x1,%r12b
  7033c8:	lea    0x320859(%rip),%rdx        # a23c28 <__frame_dummy_init_array_entry+0x1c38>
  7033cf:	mov    $0x1,%bpl
  7033d2:	xor    %edi,%edi
  7033d4:	xor    %esi,%esi
  7033d6:	call   *0x33f454(%rip)        # a42830 <_DYNAMIC+0x298>
  7033dc:	jmp    7034ba <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d3a>
  7033e1:	mov    %rsi,%rcx
  7033e4:	lea    0x3208dd(%rip),%rax        # a23cc8 <__frame_dummy_init_array_entry+0x1cd8>
  7033eb:	jmp    7034a2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d22>
  7033f0:	mov    %rsi,%rcx
  7033f3:	lea    0x3208e6(%rip),%rax        # a23ce0 <__frame_dummy_init_array_entry+0x1cf0>
  7033fa:	jmp    7034a2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d22>
  7033ff:	mov    %rsi,%rcx
  703402:	lea    0x3208ef(%rip),%rax        # a23cf8 <__frame_dummy_init_array_entry+0x1d08>
  703409:	jmp    7034a2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d22>
  70340e:	mov    %rbx,0x50(%rsp)
  703413:	mov    %rsi,%rcx
  703416:	lea    0x31f4fb(%rip),%rax        # a22918 <__frame_dummy_init_array_entry+0x928>
  70341d:	jmp    7034a2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d22>
  703422:	mov    %rax,0x50(%rsp)
  703427:	lea    0x31f502(%rip),%rax        # a22930 <__frame_dummy_init_array_entry+0x940>
  70342e:	jmp    7034a2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d22>
  703430:	mov    %rax,0x50(%rsp)
  703435:	lea    0x31f524(%rip),%rax        # a22960 <__frame_dummy_init_array_entry+0x970>
  70343c:	jmp    7034a2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d22>
  70343e:	mov    %rax,0x50(%rsp)
  703443:	lea    0x31f52e(%rip),%rax        # a22978 <__frame_dummy_init_array_entry+0x988>
  70344a:	jmp    7034a2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d22>
  70344c:	mov    %rbx,0x50(%rsp)
  703451:	lea    0x31f550(%rip),%rax        # a229a8 <__frame_dummy_init_array_entry+0x9b8>
  703458:	jmp    7034a2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d22>
  70345a:	lea    0x31ff9f(%rip),%rax        # a23400 <__frame_dummy_init_array_entry+0x1410>
  703461:	jmp    7034a2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d22>
  703463:	mov    %rax,0x50(%rsp)
  703468:	lea    0x31ffa9(%rip),%rax        # a23418 <__frame_dummy_init_array_entry+0x1428>
  70346f:	jmp    7034a2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d22>
  703471:	lea    0x31ff70(%rip),%rax        # a233e8 <__frame_dummy_init_array_entry+0x13f8>
  703478:	jmp    7034a2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d22>
  70347a:	mov    %rax,0x50(%rsp)
  70347f:	lea    0x31f41a(%rip),%rax        # a228a0 <__frame_dummy_init_array_entry+0x8b0>
  703486:	jmp    7034a2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d22>
  703488:	mov    %rax,0x50(%rsp)
  70348d:	lea    0x31f4fc(%rip),%rax        # a22990 <__frame_dummy_init_array_entry+0x9a0>
  703494:	jmp    7034a2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4d22>
  703496:	mov    %rax,0x50(%rsp)
  70349b:	lea    0x31f51e(%rip),%rax        # a229c0 <__frame_dummy_init_array_entry+0x9d0>
  7034a2:	mov    %rax,0x70(%rsp)
  7034a7:	mov    0x50(%rsp),%rdi
  7034ac:	mov    %rcx,%rsi
  7034af:	mov    0x70(%rsp),%rdx
  7034b4:	call   *0x33f376(%rip)        # a42830 <_DYNAMIC+0x298>
  7034ba:	ud2
  7034bc:	mov    %rax,%rbx
  7034bf:	mov    0x90(%rsp),%rax
  7034c7:	mov    %rax,0x170(%rsp)
  7034cf:	movaps 0x80(%rsp),%xmm0
  7034d7:	movaps %xmm0,0x160(%rsp)
  7034df:	jmp    703943 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x51c3>
  7034e4:	mov    %rax,%rbx
  7034e7:	mov    0x0(%r13),%rax
  7034eb:	movaps 0x410(%rsp),%xmm0
  7034f3:	movups %xmm0,0xb0(%rax)
  7034fa:	movaps 0x400(%rsp),%xmm0
  703502:	movups %xmm0,0xa0(%rax)
  703509:	movaps 0x3c0(%rsp),%xmm0
  703511:	movaps 0x3d0(%rsp),%xmm1
  703519:	movaps 0x3e0(%rsp),%xmm2
  703521:	movapd 0x3f0(%rsp),%xmm3
  70352a:	movupd %xmm3,0x90(%rax)
  703532:	movups %xmm2,0x80(%rax)
  703539:	movups %xmm1,0x70(%rax)
  70353d:	movups %xmm0,0x60(%rax)
  703541:	jmp    7035c2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4e42>
  703543:	mov    %rax,%rbx
  703546:	mov    0x6c8(%r14),%rax
  70354d:	mov    0x490(%rsp),%rcx
  703555:	mov    %rcx,0x28(%rax)
  703559:	movaps 0x480(%rsp),%xmm0
  703561:	movups %xmm0,0x18(%rax)
  703565:	mov    $0x1,%r15b
  703568:	xor    %r12d,%r12d
  70356b:	jmp    70385d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x50dd>
  703570:	mov    %rax,%rbx
  703573:	lea    0x3d8(%rsp),%rdi
  70357b:	call   6c1900 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::metadata::TextSlot>>>
  703580:	lea    0x3f0(%rsp),%rdi
  703588:	call   6c1900 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::metadata::TextSlot>>>
  70358d:	lea    0x3c0(%rsp),%rdi
  703595:	call   6c74f0 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportColumn>>
  70359a:	mov    0x408(%rsp),%rax
  7035a2:	test   %rax,%rax
  7035a5:	je     7035c2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4e42>
  7035a7:	mov    0x410(%rsp),%rdi
  7035af:	shl    $0x3,%rax
  7035b3:	lea    (%rax,%rax,2),%rsi
  7035b7:	mov    $0x8,%edx
  7035bc:	call   *0x33f23e(%rip)        # a42800 <_DYNAMIC+0x268>
  7035c2:	mov    $0x1,%r12b
  7035c5:	movl   $0x0,0x58(%rsp)
  7035cd:	mov    $0x1,%al
  7035cf:	mov    %eax,0x40(%rsp)
  7035d3:	movl   $0x0,0x30(%rsp)
  7035db:	mov    $0x1,%r15b
  7035de:	jmp    70374a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4fca>
  7035e3:	mov    %rax,%rbx
  7035e6:	mov    0x6c8(%r14),%rax
  7035ed:	movq   $0x0,0x30(%rax)
  7035f5:	xor    %r15d,%r15d
  7035f8:	jmp    70385d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x50dd>
  7035fd:	mov    %rax,%rbx
  703600:	lea    0x480(%rsp),%rsi
  703608:	mov    $0x1e8,%edx
  70360d:	mov    %r15,%rdi
  703610:	call   *0x33f20a(%rip)        # a42820 <memcpy@GLIBC_2.14>
  703616:	mov    $0x1,%al
  703618:	mov    %eax,0x58(%rsp)
  70361c:	xor    %ebp,%ebp
  70361e:	mov    $0x1,%r12b
  703621:	mov    $0x1,%al
  703623:	mov    %eax,0x40(%rsp)
  703627:	mov    $0x1,%al
  703629:	mov    %eax,0x30(%rsp)
  70362d:	mov    $0x1,%r15b
  703630:	jmp    70374a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4fca>
  703635:	mov    %rax,%rbx
  703638:	jmp    70384f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x50cf>
  70363d:	mov    %rbx,%rcx
  703640:	mov    %rax,%rbx
  703643:	mov    0x490(%rsp),%rax
  70364b:	mov    %rax,0x10(%r15)
  70364f:	movaps 0x480(%rsp),%xmm0
  703657:	movups %xmm0,(%r15)
  70365b:	mov    0x38(%rsp),%rax
  703660:	mov    0x50(%rsp),%rdx
  703665:	mov    %rdx,0x5d0(%rax)
  70366c:	mov    %cx,0x5d8(%rax)
  703673:	mov    0x15c(%rsp),%ecx
  70367a:	mov    %cx,0x5da(%rax)
  703681:	movss  0x7c(%rsp),%xmm0
  703687:	movss  %xmm0,0x5dc(%rax)
  70368f:	xor    %r15d,%r15d
  703692:	jmp    70385d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x50dd>
  703697:	mov    %rax,%rbx
  70369a:	mov    $0x1,%r12b
  70369d:	jmp    7036d1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4f51>
  70369f:	mov    %rax,%rbx
  7036a2:	mov    %rbp,%rdi
  7036a5:	call   6bf630 <core::ptr::drop_glue::<core::option::Option<gpui::shared_text::SharedText>>>
  7036aa:	jmp    703943 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x51c3>
  7036af:	mov    %rax,%rbx
  7036b2:	mov    $0x1,%r12b
  7036b5:	test   %r15,%r15
  7036b8:	je     7036d1 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x4f51>
  7036ba:	shl    $0x4,%r15
  7036be:	mov    $0x4,%edx
  7036c3:	mov    0x40(%rsp),%rdi
  7036c8:	mov    %r15,%rsi
  7036cb:	call   *0x33f12f(%rip)        # a42800 <_DYNAMIC+0x268>
  7036d1:	mov    $0x1,%al
  7036d3:	mov    %eax,0x40(%rsp)
  7036d7:	mov    $0x1,%r15b
  7036da:	xor    %r13d,%r13d
  7036dd:	cmpb   $0x0,0x58(%rsp)
  7036e2:	je     7038a8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5128>
  7036e8:	jmp    703968 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x51e8>
  7036ed:	mov    %rax,%rbx
  7036f0:	mov    $0x1,%r12b
  7036f3:	mov    $0x1,%al
  7036f5:	mov    %eax,0x40(%rsp)
  7036f9:	mov    $0x1,%al
  7036fb:	mov    %eax,0x30(%rsp)
  7036ff:	mov    $0x1,%r13b
  703702:	mov    $0x1,%r15b
  703705:	mov    $0x1,%bpl
  703708:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  703711:	jne    703980 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5200>
  703717:	jmp    703994 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5214>
  70371c:	mov    %r14d,0x30(%rsp)
  703721:	mov    %rax,%rbx
  703724:	mov    %r15d,%r13d
  703727:	jmp    703994 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5214>
  70372c:	mov    %rax,%rbx
  70372f:	mov    $0x1,%al
  703731:	mov    %eax,0x58(%rsp)
  703735:	mov    $0x1,%r12b
  703738:	mov    $0x1,%al
  70373a:	mov    %eax,0x40(%rsp)
  70373e:	mov    $0x1,%al
  703740:	mov    %eax,0x30(%rsp)
  703744:	mov    $0x1,%r15b
  703747:	mov    $0x1,%bpl
  70374a:	movb   $0x1,0x100(%rsp)
  703752:	jmp    70385d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x50dd>
  703757:	mov    %rax,%rbx
  70375a:	mov    %r13d,%r15d
  70375d:	jmp    7039bf <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x523f>
  703762:	mov    %r14d,0x30(%rsp)
  703767:	mov    %rax,%rbx
  70376a:	jmp    70385d <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x50dd>
  70376f:	mov    %rax,%rbx
  703772:	mov    %r13d,%r15d
  703775:	jmp    7039b2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5232>
  70377a:	mov    %rax,%rbx
  70377d:	add    $0x38,%r15
  703781:	mov    %r15,%rdi
  703784:	call   6c5ef0 <core::ptr::drop_glue::<gpui_canvas::text::RasterCache>>
  703789:	jmp    7037b9 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5039>
  70378b:	call   *0x33f097(%rip)        # a42828 <_DYNAMIC+0x290>
  703791:	jmp    703940 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x51c0>
  703796:	mov    %rax,%rbx
  703799:	mov    $0x1,%bpl
  70379c:	mov    $0x1,%r15b
  70379f:	mov    $0x1,%r13b
  7037a2:	mov    $0x1,%al
  7037a4:	mov    %eax,0x30(%rsp)
  7037a8:	mov    $0x1,%al
  7037aa:	mov    %eax,0x40(%rsp)
  7037ae:	mov    $0x1,%r12b
  7037b1:	jmp    703968 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x51e8>
  7037b6:	mov    %rax,%rbx
  7037b9:	mov    0x38(%rsp),%rax
  7037be:	mov    0x6c8(%rax),%rax
  7037c5:	mov    %r12,0x30(%rax)
  7037c9:	mov    %r14d,0x38(%rax)
  7037cd:	mov    %ebp,0x3c(%rax)
  7037d0:	movaps 0x8b0(%rsp),%xmm0
  7037d8:	movaps 0x8c0(%rsp),%xmm1
  7037e0:	movaps 0x8d0(%rsp),%xmm2
  7037e8:	movups %xmm0,0x40(%rax)
  7037ec:	movups %xmm1,0x50(%rax)
  7037f0:	movups %xmm2,0x60(%rax)
  7037f4:	mov    0x8e0(%rsp),%rcx
  7037fc:	mov    %rcx,0x70(%rax)
  703800:	mov    $0x1,%bpl
  703803:	jmp    703b22 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x53a2>
  703808:	mov    %rax,%rbx
  70380b:	jmp    703b01 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5381>
  703810:	mov    %rax,%rbx
  703813:	lea    0x480(%rsp),%rsi
  70381b:	mov    $0x298,%edx
  703820:	mov    %r14,%rdi
  703823:	call   *0x33eff7(%rip)        # a42820 <memcpy@GLIBC_2.14>
  703829:	jmp    703ac6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5346>
  70382e:	mov    %rax,%rbx
  703831:	jmp    703ae4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5364>
  703836:	jmp    703940 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x51c0>
  70383b:	ud2
  70383d:	ud2
  70383f:	mov    %rax,%rbx
  703842:	lea    0x7f8(%rsp),%rdi
  70384a:	call   6c1520 <core::ptr::drop_glue::<alloc::vec::Vec<gpui_canvas::image::Image>>>
  70384f:	mov    $0x1,%r12b
  703852:	movl   $0x0,0x40(%rsp)
  70385a:	mov    $0x1,%r15b
  70385d:	mov    0xc0(%rsp),%rsi
  703865:	test   %rsi,%rsi
  703868:	setg   %al
  70386b:	test   %al,0x100(%rsp)
  703872:	je     70389a <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x511a>
  703874:	mov    0xc8(%rsp),%rdi
  70387c:	shl    $0x4,%rsi
  703880:	mov    $0x4,%edx
  703885:	call   *0x33ef75(%rip)        # a42800 <_DYNAMIC+0x268>
  70388b:	xor    %r13d,%r13d
  70388e:	cmpb   $0x0,0x58(%rsp)
  703893:	je     7038a8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5128>
  703895:	jmp    703968 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x51e8>
  70389a:	xor    %r13d,%r13d
  70389d:	cmpb   $0x0,0x58(%rsp)
  7038a2:	jne    703968 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x51e8>
  7038a8:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  7038b1:	jne    703980 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5200>
  7038b7:	jmp    703994 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5214>
  7038bc:	jmp    703ac3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5343>
  7038c1:	jmp    703ac3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5343>
  7038c6:	jmp    703ac3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5343>
  7038cb:	mov    %rax,%rbx
  7038ce:	mov    $0x1,%r12b
  7038d1:	mov    $0x1,%r13b
  7038d4:	mov    $0x1,%r15b
  7038d7:	mov    $0x1,%bpl
  7038da:	jmp    7039e3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5263>
  7038df:	mov    %rax,%rbx
  7038e2:	mov    $0x1,%r12b
  7038e5:	mov    $0x1,%r13b
  7038e8:	mov    $0x1,%r15b
  7038eb:	mov    $0x1,%bpl
  7038ee:	jmp    703a03 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5283>
  7038f3:	mov    %rax,%rbx
  7038f6:	mov    $0x1,%r12b
  7038f9:	mov    $0x1,%r13b
  7038fc:	mov    $0x1,%r15b
  7038ff:	mov    $0x1,%bpl
  703902:	jmp    703a27 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x52a7>
  703907:	mov    %rax,%rbx
  70390a:	mov    $0x1,%r12b
  70390d:	mov    $0x1,%r13b
  703910:	mov    $0x1,%r15b
  703913:	mov    $0x1,%bpl
  703916:	jmp    703a4b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x52cb>
  70391b:	mov    %rax,%rbx
  70391e:	mov    $0x1,%bpl
  703921:	mov    $0x1,%r15b
  703924:	mov    $0x1,%r12b
  703927:	jmp    703a74 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x52f4>
  70392c:	mov    %rax,%rbx
  70392f:	jmp    703aaa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x532a>
  703934:	ud2
  703936:	ud2
  703938:	mov    %rax,%rbx
  70393b:	jmp    703b22 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x53a2>
  703940:	mov    %rax,%rbx
  703943:	mov    $0x1,%bpl
  703946:	lea    0x8b0(%rsp),%rdi
  70394e:	call   6c6240 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  703953:	mov    $0x1,%r15b
  703956:	mov    $0x1,%r13b
  703959:	mov    $0x1,%al
  70395b:	mov    %eax,0x30(%rsp)
  70395f:	mov    $0x1,%al
  703961:	mov    %eax,0x40(%rsp)
  703965:	mov    $0x1,%r12b
  703968:	lea    0x370(%rsp),%rdi
  703970:	call   6c74a0 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportBuild>>
  703975:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  70397e:	je     703994 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5214>
  703980:	cmpb   $0x0,0x40(%rsp)
  703985:	je     703994 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5214>
  703987:	lea    0x7f8(%rsp),%rdi
  70398f:	call   6c1520 <core::ptr::drop_glue::<alloc::vec::Vec<gpui_canvas::image::Image>>>
  703994:	cmpl   $0xffffffff,0x760(%rsp)
  70399c:	je     7039b2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5232>
  70399e:	cmpb   $0x0,0x30(%rsp)
  7039a3:	je     7039b2 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5232>
  7039a5:	lea    0x760(%rsp),%rdi
  7039ad:	call   6c78e0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  7039b2:	lea    0x338(%rsp),%rdi
  7039ba:	call   6c4400 <core::ptr::drop_glue::<alloc::collections::btree::set::BTreeSet<gpui::list::ListId>>>
  7039bf:	mov    0x140(%rsp),%rsi
  7039c7:	test   %rsi,%rsi
  7039ca:	je     7039e3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5263>
  7039cc:	mov    0x148(%rsp),%rdi
  7039d4:	shl    $0x2,%rsi
  7039d8:	mov    $0x4,%edx
  7039dd:	call   *0x33ee1d(%rip)        # a42800 <_DYNAMIC+0x268>
  7039e3:	mov    0x188(%rsp),%rsi
  7039eb:	test   %rsi,%rsi
  7039ee:	je     703a03 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5283>
  7039f0:	mov    0x190(%rsp),%rdi
  7039f8:	mov    $0x1,%edx
  7039fd:	call   *0x33edfd(%rip)        # a42800 <_DYNAMIC+0x268>
  703a03:	mov    0x228(%rsp),%rsi
  703a0b:	test   %rsi,%rsi
  703a0e:	je     703a27 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x52a7>
  703a10:	mov    0x230(%rsp),%rdi
  703a18:	shl    $0x4,%rsi
  703a1c:	mov    $0x4,%edx
  703a21:	call   *0x33edd9(%rip)        # a42800 <_DYNAMIC+0x268>
  703a27:	mov    0x210(%rsp),%rsi
  703a2f:	test   %rsi,%rsi
  703a32:	je     703a4b <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x52cb>
  703a34:	mov    0x218(%rsp),%rdi
  703a3c:	shl    $0x4,%rsi
  703a40:	mov    $0x4,%edx
  703a45:	call   *0x33edb5(%rip)        # a42800 <_DYNAMIC+0x268>
  703a4b:	mov    0x1e8(%rsp),%rax
  703a53:	test   %rax,%rax
  703a56:	je     703a6f <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x52ef>
  703a58:	mov    0x1f0(%rsp),%rdi
  703a60:	imul   $0x38,%rax,%rsi
  703a64:	mov    $0x8,%edx
  703a69:	call   *0x33ed91(%rip)        # a42800 <_DYNAMIC+0x268>
  703a6f:	test   %r13b,%r13b
  703a72:	je     703a98 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5318>
  703a74:	mov    0x278(%rsp),%rsi
  703a7c:	test   %rsi,%rsi
  703a7f:	je     703a98 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5318>
  703a81:	mov    0x280(%rsp),%rdi
  703a89:	shl    $0x4,%rsi
  703a8d:	mov    $0x4,%edx
  703a92:	call   *0x33ed68(%rip)        # a42800 <_DYNAMIC+0x268>
  703a98:	test   %r15b,%r15b
  703a9b:	je     703aaa <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x532a>
  703a9d:	lea    0x1c0(%rsp),%rdi
  703aa5:	call   6c13a0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  703aaa:	cmpl   $0xfffffffe,0x718(%rsp)
  703ab2:	je     703acc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x534c>
  703ab4:	lea    0x718(%rsp),%rdi
  703abc:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  703ac1:	jmp    703acc <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x534c>
  703ac3:	mov    %rax,%rbx
  703ac6:	mov    $0x1,%r12b
  703ac9:	mov    $0x1,%bpl
  703acc:	cmpq   $0x0,0x1b0(%rsp)
  703ad5:	je     703ae4 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5364>
  703ad7:	mov    0x1b8(%rsp),%rdi
  703adf:	call   6c5ca0 <core::ptr::drop_glue::<gpui_canvas::text::TextShaper>>
  703ae4:	test   %r12b,%r12b
  703ae7:	je     703b01 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5381>
  703ae9:	cmpq   $0xffffffffffffffff,0x160(%rsp)
  703af2:	je     703b01 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x5381>
  703af4:	lea    0x160(%rsp),%rdi
  703afc:	call   6c1730 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  703b01:	mov    0x118(%rsp),%rax
  703b09:	test   %rax,%rax
  703b0c:	je     703b22 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x53a2>
  703b0e:	lock decq (%rax)
  703b12:	jne    703b22 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x53a2>
  703b14:	lea    0x118(%rsp),%rdi
  703b1c:	call   *0x33edae(%rip)        # a428d0 <_DYNAMIC+0x338>
  703b22:	cmpl   $0x2,0xbd0(%rsp)
  703b2a:	je     703b3e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x53be>
  703b2c:	test   %bpl,%bpl
  703b2f:	je     703b3e <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner+0x53be>
  703b31:	lea    0xbd0(%rsp),%rdi
  703b39:	call   6c6240 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  703b3e:	mov    %rbx,%rdi
  703b41:	call   a20c40 <_Unwind_Resume@plt>
  703b46:	call   *0x33ecdc(%rip)        # a42828 <_DYNAMIC+0x290>

<gpui::runtime::Runtime<text_column_public_control::Input>>::hit code=874 fixed_stack=120

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

000000000070cfe0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit>:
  70cfe0:	push   %rbp
  70cfe1:	push   %r15
  70cfe3:	push   %r14
  70cfe5:	push   %r13
  70cfe7:	push   %r12
  70cfe9:	push   %rbx
  70cfea:	sub    $0x48,%rsp
  70cfee:	movss  %xmm1,0xc(%rsp)
  70cff4:	movss  %xmm0,0x8(%rsp)
  70cffa:	mov    %rdi,%r15
  70cffd:	mov    0x5a8(%rdi),%r14
  70d004:	mov    0x5b0(%rdi),%rax
  70d00b:	mov    %rax,(%rsp)
  70d00f:	mov    0x640(%rdi),%rbx
  70d016:	test   %rbx,%rbx
  70d019:	je     70d034 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x54>
  70d01b:	mov    0x100(%rbx),%rsi
  70d022:	test   %rsi,%rsi
  70d025:	je     70d049 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x69>
  70d027:	lea    0x30(%rsp),%rdi
  70d02c:	call   *0x3357ae(%rip)        # a427e0 <_DYNAMIC+0x248>
  70d032:	jmp    70d05a <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x7a>
  70d034:	movq   $0x4,0x30(%rsp)
  70d03d:	xorps  %xmm0,%xmm0
  70d040:	movups %xmm0,0x38(%rsp)
  70d045:	xor    %ebx,%ebx
  70d047:	jmp    70d061 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x81>
  70d049:	movq   $0x4,0x30(%rsp)
  70d052:	xorps  %xmm0,%xmm0
  70d055:	movups %xmm0,0x38(%rsp)
  70d05a:	cmpq   $0x0,(%rbx)
  70d05e:	setne  %bl
  70d061:	mov    0x6a0(%r15),%rax
  70d068:	mov    %eax,%ecx
  70d06a:	xorps  %xmm0,%xmm0
  70d06d:	cvtsi2ss %rcx,%xmm0
  70d072:	shr    $0x20,%rax
  70d076:	xorps  %xmm1,%xmm1
  70d079:	cvtsi2ss %rax,%xmm1
  70d07e:	movq   $0x0,0x10(%rsp)
  70d087:	movss  %xmm0,0x18(%rsp)
  70d08d:	movss  %xmm1,0x1c(%rsp)
  70d093:	lea    0x10(%rsp),%rdi
  70d098:	movss  0x8(%rsp),%xmm0
  70d09e:	movss  0xc(%rsp),%xmm1
  70d0a4:	call   *0x335a36(%rip)        # a42ae0 <_DYNAMIC+0x548>
  70d0aa:	xor    %r12d,%r12d
  70d0ad:	cmpq   $0x0,(%rsp)
  70d0b2:	je     70d16d <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x18d>
  70d0b8:	test   %al,%al
  70d0ba:	je     70d16d <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x18d>
  70d0c0:	mov    (%rsp),%rax
  70d0c4:	shl    $0x6,%rax
  70d0c8:	add    %r14,%rax
  70d0cb:	movzbl %bl,%ebp
  70d0ce:	xor    %r12d,%r12d
  70d0d1:	jmp    70d12d <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x14d>
  70d0d3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  70d0e0:	mov    %rbx,%r13
  70d0e3:	sub    %r14,%r13
  70d0e6:	shr    $0x6,%r13
  70d0ea:	mov    0x40(%rsp),%rax
  70d0ef:	mov    %rax,0x20(%rsp)
  70d0f4:	movups 0x30(%rsp),%xmm0
  70d0f9:	movaps %xmm0,0x10(%rsp)
  70d0fe:	mov    %r14,%rdi
  70d101:	mov    (%rsp),%rsi
  70d105:	lea    0x10(%rsp),%rdx
  70d10a:	mov    %ebp,%ecx
  70d10c:	mov    %r13,%r8
  70d10f:	movss  0x8(%rsp),%xmm0
  70d115:	movss  0xc(%rsp),%xmm1
  70d11b:	call   *0x3359d7(%rip)        # a42af8 <_DYNAMIC+0x560>
  70d121:	test   %al,%al
  70d123:	jne    70d17f <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x19f>
  70d125:	mov    %rbx,%rax
  70d128:	cmp    %rbx,%r14
  70d12b:	je     70d16d <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x18d>
  70d12d:	lea    -0x40(%rax),%rbx
  70d131:	cmpb   $0x0,-0x2(%rax)
  70d135:	jne    70d0e0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x100>
  70d137:	mov    -0x8(%rax),%eax
  70d13a:	cmp    $0x3ffff,%rax
  70d140:	jbe    70d125 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x145>
  70d142:	shr    $0x11,%eax
  70d145:	mov    %rbx,%rcx
  70d148:	sub    %r14,%rcx
  70d14b:	shr    $0x6,%rcx
  70d14f:	mov    $0x2,%edx
  70d154:	sub    %rax,%rdx
  70d157:	add    $0xfffffffffffffffe,%rax
  70d15b:	shl    $0x6,%rdx
  70d15f:	cmp    %rcx,%rax
  70d162:	lea    -0x40(%rbx,%rdx,1),%rbx
  70d167:	cmovae %r14,%rbx
  70d16b:	jmp    70d125 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x145>
  70d16d:	mov    %r12,%rax
  70d170:	add    $0x48,%rsp
  70d174:	pop    %rbx
  70d175:	pop    %r12
  70d177:	pop    %r13
  70d179:	pop    %r14
  70d17b:	pop    %r15
  70d17d:	pop    %rbp
  70d17e:	ret
  70d17f:	mov    0x1e8(%r15),%rax
  70d186:	mov    0x1f0(%r15),%rcx
  70d18d:	mov    0x1f8(%r15),%r8
  70d194:	mov    0x2d0(%r15),%rsi
  70d19b:	mov    0x2c8(%r15),%r9
  70d1a2:	jmp    70d1c8 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x1e8>
  70d1a4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  70d1b0:	mov    0x38(%r10),%r13d
  70d1b4:	and    $0x1ffff,%r13d
  70d1bb:	cmp    $0x1ffff,%r13
  70d1c2:	je     70d321 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x341>
  70d1c8:	cmp    (%rsp),%r13
  70d1cc:	jae    70d329 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x349>
  70d1d2:	shl    $0x6,%r13
  70d1d6:	lea    (%r14,%r13,1),%r10
  70d1da:	mov    0x20(%r14,%r13,1),%rdx
  70d1df:	test   %rax,%rax
  70d1e2:	je     70d200 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x220>
  70d1e4:	cmp    $0x1,%eax
  70d1e7:	jne    70d220 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x240>
  70d1e9:	test   %r8,%r8
  70d1ec:	je     70d1b0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x1d0>
  70d1ee:	cmp    $0x1,%r8
  70d1f2:	jne    70d240 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x260>
  70d1f4:	xor    %edi,%edi
  70d1f6:	jmp    70d274 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x294>
  70d1f8:	nopl   0x0(%rax,%rax,1)
  70d200:	mov    %rdx,%rdi
  70d203:	sub    %rcx,%rdi
  70d206:	setae  %r11b
  70d20a:	cmp    %r8,%rdi
  70d20d:	setb   %bl
  70d210:	test   %bl,%r11b
  70d213:	je     70d1b0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x1d0>
  70d215:	jmp    70d2f6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x316>
  70d21a:	nopw   0x0(%rax,%rax,1)
  70d220:	test   %r8,%r8
  70d223:	je     70d1b0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x1d0>
  70d225:	cmp    $0x1,%r8
  70d229:	jne    70d2b5 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x2d5>
  70d22f:	mov    %rcx,%rdi
  70d232:	cmp    %rdx,(%rcx)
  70d235:	jne    70d1b0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x1d0>
  70d23b:	jmp    70d2f3 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x313>
  70d240:	mov    %r8,%r11
  70d243:	xor    %edi,%edi
  70d245:	data16 cs nopw 0x0(%rax,%rax,1)
  70d250:	mov    %rdi,%rbx
  70d253:	mov    %r11,%r15
  70d256:	shr    $1,%r15
  70d259:	add    %r15,%rdi
  70d25c:	mov    %rdi,%r12
  70d25f:	shl    $0x4,%r12
  70d263:	cmp    %rdx,(%rcx,%r12,1)
  70d267:	cmova  %rbx,%rdi
  70d26b:	sub    %r15,%r11
  70d26e:	cmp    $0x1,%r11
  70d272:	ja     70d250 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x270>
  70d274:	mov    %rdi,%rbx
  70d277:	shl    $0x4,%rbx
  70d27b:	xor    %r11d,%r11d
  70d27e:	cmp    %rdx,(%rcx,%rbx,1)
  70d282:	setbe  %r11b
  70d286:	add    %rdi,%r11
  70d289:	je     70d1b0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x1d0>
  70d28f:	shl    $0x4,%r11
  70d293:	mov    %rdx,%rdi
  70d296:	sub    -0x10(%rcx,%r11,1),%rdi
  70d29b:	mov    -0x4(%rcx,%r11,1),%ebx
  70d2a0:	cmp    %rbx,%rdi
  70d2a3:	jae    70d1b0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x1d0>
  70d2a9:	add    %rcx,%r11
  70d2ac:	mov    -0x8(%r11),%r11d
  70d2b0:	add    %r11,%rdi
  70d2b3:	jmp    70d2f6 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x316>
  70d2b5:	mov    %r8,%rdi
  70d2b8:	xor    %r11d,%r11d
  70d2bb:	nopl   0x0(%rax,%rax,1)
  70d2c0:	mov    %r11,%rbx
  70d2c3:	mov    %rdi,%r15
  70d2c6:	shr    $1,%r15
  70d2c9:	add    %r15,%r11
  70d2cc:	lea    (%r11,%r11,2),%r12
  70d2d0:	cmp    %rdx,(%rcx,%r12,4)
  70d2d4:	cmova  %rbx,%r11
  70d2d8:	sub    %r15,%rdi
  70d2db:	cmp    $0x1,%rdi
  70d2df:	ja     70d2c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x2e0>
  70d2e1:	lea    (%r11,%r11,2),%rdi
  70d2e5:	cmp    %rdx,(%rcx,%rdi,4)
  70d2e9:	jne    70d1b0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x1d0>
  70d2ef:	lea    (%rcx,%rdi,4),%rdi
  70d2f3:	mov    0x8(%rdi),%edi
  70d2f6:	cmp    %rsi,%rdi
  70d2f9:	jae    70d33d <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x35d>
  70d2fb:	lea    (%rdi,%rdi,4),%rdi
  70d2ff:	mov    $0x1,%r12d
  70d305:	cmpq   $0x0,0x8(%r9,%rdi,8)
  70d30b:	jne    70d16d <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x18d>
  70d311:	cmpb   $0x4,0x3d(%r10)
  70d316:	jne    70d1b0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x1d0>
  70d31c:	jmp    70d16d <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x18d>
  70d321:	xor    %r12d,%r12d
  70d324:	jmp    70d16d <<gpui::runtime::Runtime<text_column_public_control::Input>>::hit+0x18d>
  70d329:	lea    0x316868(%rip),%rdx        # a23b98 <__frame_dummy_init_array_entry+0x1ba8>
  70d330:	mov    %r13,%rdi
  70d333:	mov    (%rsp),%rsi
  70d337:	call   *0x3354f3(%rip)        # a42830 <_DYNAMIC+0x298>
  70d33d:	lea    0x31686c(%rip),%rdx        # a23bb0 <__frame_dummy_init_array_entry+0x1bc0>
  70d344:	call   *0x3354e6(%rip)        # a42830 <_DYNAMIC+0x298>

<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge code=1446 fixed_stack=184

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

000000000070d850 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge>:
  70d850:	push   %r15
  70d852:	push   %r14
  70d854:	push   %r12
  70d856:	push   %rbx
  70d857:	sub    $0x98,%rsp
  70d85e:	mov    %rdi,%r14
  70d861:	cmp    %rdx,0x6f0(%rsi)
  70d868:	jne    70db9a <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x34a>
  70d86e:	mov    %rsi,%rbx
  70d871:	cmp    %rcx,0x6f8(%rsi)
  70d878:	jne    70db9a <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x34a>
  70d87e:	lea    0x630(%rbx),%rdi
  70d885:	mov    %rcx,%rsi
  70d888:	call   *0x335412(%rip)        # a42ca0 <_DYNAMIC+0x708>
  70d88e:	mov    0x618(%rbx),%rax
  70d895:	mov    %rax,0x30(%rsp)
  70d89a:	movdqu 0x5f8(%rbx),%xmm0
  70d8a2:	movdqu 0x608(%rbx),%xmm1
  70d8aa:	movdqa %xmm0,0x10(%rsp)
  70d8b0:	movq   $0xffffffffffffffff,0x5f8(%rbx)
  70d8bb:	movzbl 0x78c(%rbx),%eax
  70d8c2:	xor    $0x1,%rax
  70d8c6:	cmpq   $0xffffffffffffffff,0x10(%rsp)
  70d8cc:	movdqa %xmm1,0x20(%rsp)
  70d8d2:	mov    $0x1,%r12d
  70d8d8:	cmove  %rax,%r12
  70d8dc:	je     70d982 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x132>
  70d8e2:	movdqa 0x30(%rsp),%xmm0
  70d8e8:	movss  0x34(%rsp),%xmm2
  70d8ee:	movd   %xmm0,%eax
  70d8f2:	pand   -0x6cc31a(%rip),%xmm0        # 415e0 <GCC_except_table0+0x1798>
  70d8fa:	pxor   %xmm1,%xmm1
  70d8fe:	punpcklwd %xmm1,%xmm0
  70d902:	movq   %xmm0,0x6e0(%rbx)
  70d90a:	test   %ax,%ax
  70d90d:	js     70dba6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x356>
  70d913:	movss  %xmm2,0xc(%rsp)
  70d919:	lea    0x5e0(%rbx),%r15
  70d920:	mov    %r15,%rdi
  70d923:	call   6c13a0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  70d928:	mov    0x20(%rsp),%rax
  70d92d:	mov    %rax,0x10(%r15)
  70d931:	movaps 0x10(%rsp),%xmm0
  70d936:	movups %xmm0,(%r15)
  70d93a:	mov    0x708(%rbx),%rdi
  70d941:	test   %rdi,%rdi
  70d944:	je     70d94c <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0xfc>
  70d946:	call   *0x33535c(%rip)        # a42ca8 <_DYNAMIC+0x710>
  70d94c:	mov    0x680(%rbx),%rax
  70d953:	test   %rax,%rax
  70d956:	je     70d974 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x124>
  70d958:	mov    0xe0(%rax),%rax
  70d95f:	test   %rax,%rax
  70d962:	je     70d974 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x124>
  70d964:	mov    0x50(%rax),%rcx
  70d968:	mov    %rcx,0x38(%rax)
  70d96c:	movups 0x40(%rax),%xmm0
  70d970:	movups %xmm0,0x28(%rax)
  70d974:	movd   0xc(%rsp),%xmm0
  70d97a:	movd   %xmm0,0x784(%rbx)
  70d982:	mov    0x680(%rbx),%rax
  70d989:	test   %rax,%rax
  70d98c:	je     70dbc8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70d992:	mov    0x60(%rax),%r15
  70d996:	movq   $0xffffffffffffffff,0x60(%rax)
  70d99e:	cmp    $0xffffffffffffffff,%r15
  70d9a2:	je     70da46 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x1f6>
  70d9a8:	mov    0xb8(%rax),%rcx
  70d9af:	mov    %rcx,0x90(%rsp)
  70d9b7:	movups 0xa8(%rax),%xmm0
  70d9be:	movaps %xmm0,0x80(%rsp)
  70d9c6:	movups 0x68(%rax),%xmm0
  70d9ca:	movups 0x78(%rax),%xmm1
  70d9ce:	movups 0x88(%rax),%xmm2
  70d9d5:	movups 0x98(%rax),%xmm3
  70d9dc:	movaps %xmm3,0x70(%rsp)
  70d9e1:	movaps %xmm2,0x60(%rsp)
  70d9e6:	movaps %xmm1,0x50(%rsp)
  70d9eb:	movaps %xmm0,0x40(%rsp)
  70d9f0:	mov    0x680(%rbx),%rdi
  70d9f7:	call   6c78e0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  70d9fc:	mov    0x680(%rbx),%rax
  70da03:	mov    %r15,(%rax)
  70da06:	movaps 0x40(%rsp),%xmm0
  70da0b:	movdqa 0x50(%rsp),%xmm1
  70da11:	movaps 0x60(%rsp),%xmm2
  70da16:	movaps 0x70(%rsp),%xmm3
  70da1b:	movups %xmm0,0x8(%rax)
  70da1f:	movdqu %xmm1,0x18(%rax)
  70da24:	movups %xmm2,0x28(%rax)
  70da28:	movups %xmm3,0x38(%rax)
  70da2c:	movdqa 0x80(%rsp),%xmm0
  70da35:	movdqu %xmm0,0x48(%rax)
  70da3a:	mov    0x90(%rsp),%rcx
  70da42:	mov    %rcx,0x58(%rax)
  70da46:	mov    0x680(%rbx),%r15
  70da4d:	test   %r15,%r15
  70da50:	je     70dbc8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70da56:	mov    0x100(%r15),%rdi
  70da5d:	test   %rdi,%rdi
  70da60:	je     70dab0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x260>
  70da62:	call   *0x335248(%rip)        # a42cb0 <_DYNAMIC+0x718>
  70da68:	mov    0x100(%r15),%rax
  70da6f:	cmpq   $0x0,0x10(%rax)
  70da74:	jne    70dab0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x260>
  70da76:	cmpq   $0x0,0x58(%rax)
  70da7b:	jne    70dab0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x260>
  70da7d:	cmpq   $0x0,0x28(%rax)
  70da82:	jne    70dab0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x260>
  70da84:	cmpq   $0xffffffffffffffff,0x30(%rax)
  70da89:	jne    70dab0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x260>
  70da8b:	mov    0x680(%rbx),%rax
  70da92:	mov    0x100(%rax),%rdi
  70da99:	call   6bf490 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::geometry::Geometry>>>>
  70da9e:	mov    0x680(%rbx),%rax
  70daa5:	movq   $0x0,0x100(%rax)
  70dab0:	mov    0x680(%rbx),%r15
  70dab7:	test   %r15,%r15
  70daba:	je     70dbc8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70dac0:	mov    0xe0(%r15),%rdi
  70dac7:	test   %rdi,%rdi
  70daca:	je     70db10 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x2c0>
  70dacc:	cmpb   $0x2,0x24(%rdi)
  70dad0:	jne    70db10 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x2c0>
  70dad2:	cmpb   $0x2,0x3c(%rdi)
  70dad6:	jne    70db10 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x2c0>
  70dad8:	cmpb   $0x2,0x54(%rdi)
  70dadc:	jne    70db10 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x2c0>
  70dade:	mov    $0x58,%esi
  70dae3:	mov    $0x8,%edx
  70dae8:	call   *0x334d12(%rip)        # a42800 <_DYNAMIC+0x268>
  70daee:	mov    0x680(%rbx),%rax
  70daf5:	movq   $0x0,0xe0(%rax)
  70db00:	mov    0x680(%rbx),%r15
  70db07:	test   %r15,%r15
  70db0a:	je     70dbc8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70db10:	cmpq   $0x0,0xd8(%r15)
  70db18:	jne    70dbc8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70db1e:	cmpq   $0x0,0xe0(%r15)
  70db26:	jne    70dbc8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70db2c:	cmpq   $0x0,0x100(%r15)
  70db34:	jne    70dbc8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70db3a:	cmpq   $0x0,0xd0(%r15)
  70db42:	jne    70dbc8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70db48:	cmpq   $0x0,0xf8(%r15)
  70db50:	jne    70dbc8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70db52:	mov    0x60(%r15),%rax
  70db56:	cmp    $0xffffffff,%eax
  70db59:	jne    70dbc8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70db5b:	cmpq   $0x0,0x28(%r15)
  70db60:	jne    70dbc8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70db62:	mov    (%r15),%rax
  70db65:	or     0x40(%r15),%rax
  70db69:	jne    70dbc8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70db6b:	cmpq   $0x0,0x58(%r15)
  70db70:	jne    70dbc8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70db72:	mov    %r15,%rdi
  70db75:	call   6c7980 <core::ptr::drop_glue::<gpui::runtime::metadata::Metadata>>
  70db7a:	mov    $0x108,%esi
  70db7f:	mov    $0x8,%edx
  70db84:	mov    %r15,%rdi
  70db87:	call   *0x334c73(%rip)        # a42800 <_DYNAMIC+0x268>
  70db8d:	movq   $0x0,0x680(%rbx)
  70db98:	jmp    70dbc8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x378>
  70db9a:	movq   $0x15,(%r14)
  70dba1:	jmp    70dd0d <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x4bd>
  70dba6:	movss  %xmm2,0x784(%rbx)
  70dbae:	lea    0x10(%rsp),%rdi
  70dbb3:	call   6c13a0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  70dbb8:	mov    0x680(%rbx),%rax
  70dbbf:	test   %rax,%rax
  70dbc2:	jne    70d992 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x142>
  70dbc8:	mov    0x708(%rbx),%rdi
  70dbcf:	test   %rdi,%rdi
  70dbd2:	je     70dbf9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x3a9>
  70dbd4:	cmpq   $0x0,0x30(%rdi)
  70dbd9:	jne    70dbf9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x3a9>
  70dbdb:	cmpq   $0x0,0x10(%rdi)
  70dbe0:	jne    70dbf9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x3a9>
  70dbe2:	cmpq   $0xffffffffffffffff,0x18(%rdi)
  70dbe7:	jne    70dbf9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x3a9>
  70dbe9:	call   6bf320 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::text_geometry::TextResources>>>>
  70dbee:	movq   $0x0,0x708(%rbx)
  70dbf9:	mov    0x658(%rbx),%rdx
  70dc00:	test   %rdx,%rdx
  70dc03:	je     70dca5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x455>
  70dc09:	mov    0x660(%rbx),%rcx
  70dc10:	lea    0x40(%rsp),%rdi
  70dc15:	mov    %rbx,%rsi
  70dc18:	call   7131d0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::resolve_index>
  70dc1d:	mov    0x40(%rsp),%rax
  70dc22:	mov    0x48(%rsp),%rsi
  70dc27:	cmp    $0xfffffffffffffffe,%rax
  70dc2b:	jne    70dc58 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x408>
  70dc2d:	mov    0x310(%rbx),%rax
  70dc34:	cmp    %rax,%rsi
  70dc37:	jae    70dd1c <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x4cc>
  70dc3d:	lea    (%rsi,%rsi,4),%rdi
  70dc41:	shl    $0x3,%rdi
  70dc45:	add    0x308(%rbx),%rdi
  70dc4c:	call   *0x334e96(%rip)        # a42ae8 <_DYNAMIC+0x550>
  70dc52:	test   %al,%al
  70dc54:	je     70dc9a <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x44a>
  70dc56:	jmp    70dca5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x455>
  70dc58:	sub    $0xd,%rax
  70dc5c:	mov    $0x14,%ecx
  70dc61:	cmovge %rax,%rcx
  70dc65:	cmp    $0x14,%rcx
  70dc69:	je     70dc7d <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x42d>
  70dc6b:	cmp    $0x19,%rcx
  70dc6f:	jne    70dc9a <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x44a>
  70dc71:	test   %rsi,%rsi
  70dc74:	je     70dc9a <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x44a>
  70dc76:	lea    0x50(%rsp),%rax
  70dc7b:	jmp    70dc8c <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x43c>
  70dc7d:	mov    0x58(%rsp),%rsi
  70dc82:	test   %rsi,%rsi
  70dc85:	je     70dc9a <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge+0x44a>
  70dc87:	lea    0x60(%rsp),%rax
  70dc8c:	mov    (%rax),%rdi
  70dc8f:	mov    $0x1,%edx
  70dc94:	call   *0x334b66(%rip)        # a42800 <_DYNAMIC+0x268>
  70dc9a:	movq   $0x0,0x658(%rbx)
  70dca5:	mov    0x700(%rbx),%rax
  70dcac:	mov    %rax,0x6d8(%rbx)
  70dcb3:	movb   $0x1,0x78c(%rbx)
  70dcba:	add    %r12,0x758(%rbx)
  70dcc1:	cmpq   $0x0,0x6f0(%rbx)
  70dcc9:	setne  %cl
  70dccc:	cmpq   $0xffffffffffffffff,0x5f8(%rbx)
  70dcd4:	mov    0x6d0(%rbx),%rdx
  70dcdb:	setne  %sil
  70dcdf:	and    %cl,%sil
  70dce2:	movzbl %sil,%ecx
  70dce6:	mov    0x778(%rbx),%rsi
  70dced:	mov    %rcx,0x8(%r14)
  70dcf1:	mov    %rax,0x10(%r14)
  70dcf5:	mov    %rdx,0x18(%r14)
  70dcf9:	mov    %rax,0x20(%r14)
  70dcfd:	mov    %rsi,0x28(%r14)
  70dd01:	movb   $0x1,0x30(%r14)
  70dd06:	movq   $0xfffffffffffffffe,(%r14)
  70dd0d:	add    $0x98,%rsp
  70dd14:	pop    %rbx
  70dd15:	pop    %r12
  70dd17:	pop    %r14
  70dd19:	pop    %r15
  70dd1b:	ret
  70dd1c:	lea    0x3149fd(%rip),%rdx        # a22720 <__frame_dummy_init_array_entry+0x730>
  70dd23:	mov    %rsi,%rdi
  70dd26:	mov    %rax,%rsi
  70dd29:	call   *0x334b01(%rip)        # a42830 <_DYNAMIC+0x298>
  70dd2f:	mov    %rax,%r14
  70dd32:	mov    $0x108,%esi
  70dd37:	mov    $0x8,%edx
  70dd3c:	mov    %r15,%rdi
  70dd3f:	call   *0x334abb(%rip)        # a42800 <_DYNAMIC+0x268>
  70dd45:	movq   $0x0,0x680(%rbx)
  70dd50:	mov    %r14,%rdi
  70dd53:	call   a20c40 <_Unwind_Resume@plt>
  70dd58:	mov    %rax,%r14
  70dd5b:	mov    0x680(%rbx),%rax
  70dd62:	movq   $0x0,0x100(%rax)
  70dd6d:	mov    %r14,%rdi
  70dd70:	call   a20c40 <_Unwind_Resume@plt>
  70dd75:	movq   $0x0,0x708(%rbx)
  70dd80:	mov    %rax,%rdi
  70dd83:	call   a20c40 <_Unwind_Resume@plt>
  70dd88:	mov    %rax,%r14
  70dd8b:	mov    0x680(%rbx),%rax
  70dd92:	mov    %r15,(%rax)
  70dd95:	movaps 0x40(%rsp),%xmm0
  70dd9a:	movaps 0x50(%rsp),%xmm1
  70dd9f:	movaps 0x60(%rsp),%xmm2
  70dda4:	movaps 0x70(%rsp),%xmm3
  70dda9:	movups %xmm0,0x8(%rax)
  70ddad:	movups %xmm1,0x18(%rax)
  70ddb1:	movups %xmm2,0x28(%rax)
  70ddb5:	movups %xmm3,0x38(%rax)
  70ddb9:	movaps 0x80(%rsp),%xmm0
  70ddc1:	movups %xmm0,0x48(%rax)
  70ddc5:	mov    0x90(%rsp),%rcx
  70ddcd:	mov    %rcx,0x58(%rax)
  70ddd1:	mov    %r14,%rdi
  70ddd4:	call   a20c40 <_Unwind_Resume@plt>
  70ddd9:	mov    %rax,%r14
  70dddc:	mov    0x20(%rsp),%rax
  70dde1:	mov    %rax,0x10(%r15)
  70dde5:	movaps 0x10(%rsp),%xmm0
  70ddea:	movups %xmm0,(%r15)
  70ddee:	mov    %r14,%rdi
  70ddf1:	call   a20c40 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner code=21452 fixed_stack=3560

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

000000000070de00 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner>:
  70de00:	push   %rbp
  70de01:	push   %r15
  70de03:	push   %r14
  70de05:	push   %r13
  70de07:	push   %r12
  70de09:	push   %rbx
  70de0a:	sub    $0xdb8,%rsp
  70de11:	mov    %rdi,0x48(%rsp)
  70de16:	mov    0x628(%rsi),%rax
  70de1d:	mov    %rax,0x2b8(%rsp)
  70de25:	inc    %rax
  70de28:	je     712537 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4737>
  70de2e:	mov    %rsi,%r15
  70de31:	mov    %rax,0x7f0(%rsp)
  70de39:	mov    0x620(%rsi),%rax
  70de40:	mov    %rax,0x310(%rsp)
  70de48:	mov    0x6e8(%rsi),%rsi
  70de4f:	movq   %rsi,%xmm0
  70de54:	movdqa %xmm0,0x100(%rsp)
  70de5d:	pshufd $0x55,%xmm0,%xmm0
  70de62:	movd   %xmm0,%edx
  70de66:	movss  0x780(%r15),%xmm0
  70de6f:	movss  %xmm0,0x7c(%rsp)
  70de75:	mov    0x1a8(%r15),%eax
  70de7c:	mov    0x1b0(%r15),%rcx
  70de83:	shl    $0x20,%rcx
  70de87:	or     %rax,%rcx
  70de8a:	cmp    %rsi,%rcx
  70de8d:	mov    %rsi,0x2c0(%rsp)
  70de95:	mov    %edx,0x15c(%rsp)
  70de9c:	jne    70dec5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xc5>
  70de9e:	movq   $0x2,0xbd0(%rsp)
  70deaa:	mov    $0x2,%ebx
  70deaf:	cmpl   $0xffff,0x2c0(%rsp)
  70deba:	jbe    70df5f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x15f>
  70dec0:	jmp    70df6c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x16c>
  70dec5:	movups 0x138(%r15),%xmm0
  70decd:	movaps %xmm0,0x8b0(%rsp)
  70ded5:	lea    0x480(%rsp),%rdi
  70dedd:	lea    0x8b0(%rsp),%rcx
  70dee5:	call   *0x334bbd(%rip)        # a42aa8 <_DYNAMIC+0x510>
  70deeb:	mov    0x480(%rsp),%rbx
  70def3:	mov    0x488(%rsp),%r14d
  70defb:	mov    0x48c(%rsp),%ebp
  70df02:	cmp    $0x2,%rbx
  70df06:	jne    70df20 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x120>
  70df08:	mov    0x48(%rsp),%rax
  70df0d:	movq   $0x23,(%rax)
  70df14:	mov    %r14d,0x8(%rax)
  70df18:	mov    %ebp,0xc(%rax)
  70df1b:	jmp    70f637 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1837>
  70df20:	lea    0x490(%rsp),%rsi
  70df28:	lea    0xbe0(%rsp),%rdi
  70df30:	mov    $0x1d8,%edx
  70df35:	call   *0x3348e5(%rip)        # a42820 <memcpy@GLIBC_2.14>
  70df3b:	mov    %rbx,0xbd0(%rsp)
  70df43:	mov    %r14d,0xbd8(%rsp)
  70df4b:	mov    %ebp,0xbdc(%rsp)
  70df52:	cmpl   $0xffff,0x2c0(%rsp)
  70df5d:	ja     70df6c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x16c>
  70df5f:	cmpl   $0xffff,0x15c(%rsp)
  70df6a:	jbe    70df8d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x18d>
  70df6c:	mov    0x48(%rsp),%rax
  70df71:	movq   $0x23,(%rax)
  70df78:	movl   $0x0,0x8(%rax)
  70df7f:	cmp    $0x2,%ebx
  70df82:	jne    70f62a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x182a>
  70df88:	jmp    70f637 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1837>
  70df8d:	cmpq   $0x0,0x328(%r15)
  70df95:	mov    %r15,0x38(%rsp)
  70df9a:	je     70dfaf <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1af>
  70df9c:	mov    0x708(%r15),%rax
  70dfa3:	test   %rax,%rax
  70dfa6:	je     70dfc4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1c4>
  70dfa8:	cmpq   $0x0,0x30(%rax)
  70dfad:	je     70e011 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x211>
  70dfaf:	mov    0x708(%r15),%rax
  70dfb6:	test   %rax,%rax
  70dfb9:	jne    70e10a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x30a>
  70dfbf:	jmp    70e14f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x34f>
  70dfc4:	call   *0x33483e(%rip)        # a42808 <_DYNAMIC+0x270>
  70dfca:	mov    $0x78,%edi
  70dfcf:	mov    $0x8,%esi
  70dfd4:	call   *0x334836(%rip)        # a42810 <_DYNAMIC+0x278>
  70dfda:	test   %rax,%rax
  70dfdd:	je     712832 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4a32>
  70dfe3:	movq   $0x0,(%rax)
  70dfea:	movq   $0x8,0x8(%rax)
  70dff2:	movq   $0x0,0x10(%rax)
  70dffa:	movq   $0xffffffffffffffff,0x18(%rax)
  70e002:	movq   $0x0,0x30(%rax)
  70e00a:	mov    %rax,0x708(%r15)
  70e011:	mov    $0x1,%bpl
  70e014:	lea    0x480(%rsp),%rdi
  70e01c:	call   *0x334c96(%rip)        # a42cb8 <_DYNAMIC+0x720>
  70e022:	mov    0x480(%rsp),%r12
  70e02a:	mov    0x488(%rsp),%r14d
  70e032:	mov    0x48c(%rsp),%ebp
  70e039:	test   %r12,%r12
  70e03c:	je     70f538 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1738>
  70e042:	mov    0x4c0(%rsp),%rax
  70e04a:	mov    %rax,0x8e0(%rsp)
  70e052:	movups 0x490(%rsp),%xmm0
  70e05a:	movups 0x4a0(%rsp),%xmm1
  70e062:	movups 0x4b0(%rsp),%xmm2
  70e06a:	movaps %xmm2,0x8d0(%rsp)
  70e072:	movaps %xmm1,0x8c0(%rsp)
  70e07a:	movaps %xmm0,0x8b0(%rsp)
  70e082:	mov    0x708(%r15),%r15
  70e089:	mov    0x30(%r15),%rax
  70e08d:	test   %rax,%rax
  70e090:	je     70e0ba <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2ba>
  70e092:	lock decq (%rax)
  70e096:	jne    70e0a2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2a2>
  70e098:	lea    0x30(%r15),%rdi
  70e09c:	call   *0x33482e(%rip)        # a428d0 <_DYNAMIC+0x338>
  70e0a2:	add    $0x38,%r15
  70e0a6:	mov    %r15,%rdi
  70e0a9:	call   6c5ef0 <core::ptr::drop_glue::<gpui_canvas::text::RasterCache>>
  70e0ae:	mov    0x38(%rsp),%rax
  70e0b3:	mov    0x708(%rax),%r15
  70e0ba:	mov    %r12,0x30(%r15)
  70e0be:	mov    %r14d,0x38(%r15)
  70e0c2:	mov    %ebp,0x3c(%r15)
  70e0c6:	movaps 0x8b0(%rsp),%xmm0
  70e0ce:	movaps 0x8c0(%rsp),%xmm1
  70e0d6:	movaps 0x8d0(%rsp),%xmm2
  70e0de:	movups %xmm0,0x40(%r15)
  70e0e3:	movups %xmm1,0x50(%r15)
  70e0e8:	movups %xmm2,0x60(%r15)
  70e0ed:	mov    0x8e0(%rsp),%rax
  70e0f5:	mov    %rax,0x70(%r15)
  70e0f9:	mov    0x38(%rsp),%r15
  70e0fe:	mov    0x708(%r15),%rax
  70e105:	test   %rax,%rax
  70e108:	je     70e14f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x34f>
  70e10a:	mov    0x30(%rax),%rax
  70e10e:	test   %rax,%rax
  70e111:	je     70e14f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x34f>
  70e113:	lock incq (%rax)
  70e117:	jle    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  70e11d:	mov    %rax,0x118(%rsp)
  70e125:	movq   $0xffffffffffffffff,0x160(%rsp)
  70e131:	lea    0x118(%rsp),%rax
  70e139:	mov    %rax,0x1b0(%rsp)
  70e141:	movq   $0x0,0x1b8(%rsp)
  70e14d:	jmp    70e173 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x373>
  70e14f:	movq   $0x0,0x118(%rsp)
  70e15b:	movq   $0xffffffffffffffff,0x160(%rsp)
  70e167:	movq   $0x0,0x1b0(%rsp)
  70e173:	lea    0x428(%rsp),%rdi
  70e17b:	mov    %r15,%rsi
  70e17e:	call   6ed6d0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::active_selection>
  70e183:	lea    0x480(%rsp),%rdi
  70e18b:	mov    %r15,%rsi
  70e18e:	call   6ed6d0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::active_selection>
  70e193:	movzbl 0x494(%rsp),%ebx
  70e19b:	cmp    $0x2,%bl
  70e19e:	je     70e1f6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3f6>
  70e1a0:	mov    0x480(%rsp),%rax
  70e1a8:	mov    %rax,0x7e8(%rsp)
  70e1b0:	test   %rax,%rax
  70e1b3:	je     712814 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4a14>
  70e1b9:	mov    0x490(%rsp),%eax
  70e1c0:	mov    %eax,0x330(%rsp)
  70e1c7:	mov    0x488(%rsp),%rax
  70e1cf:	mov    %rax,0x328(%rsp)
  70e1d7:	movzwl 0x495(%rsp),%eax
  70e1df:	mov    %ax,0xe8(%rsp)
  70e1e7:	movzbl 0x497(%rsp),%eax
  70e1ef:	mov    %al,0xea(%rsp)
  70e1f6:	lea    0x330(%r15),%rax
  70e1fd:	mov    %rax,0x58(%rsp)
  70e202:	cmpb   $0x0,0x788(%r15)
  70e20a:	mov    %bl,0x7b(%rsp)
  70e20e:	jne    70e562 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x762>
  70e214:	cmpb   $0x0,0x789(%r15)
  70e21c:	jne    70e562 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x762>
  70e222:	cmpb   $0x0,0x5c0(%r15)
  70e22a:	jne    70e562 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x762>
  70e230:	mov    0x688(%r15),%rax
  70e237:	mov    0x698(%r15),%r15
  70e23e:	test   %rax,%rax
  70e241:	setne  %cl
  70e244:	test   %r15,%r15
  70e247:	setne  %dl
  70e24a:	and    %cl,%dl
  70e24c:	cmp    $0x1,%dl
  70e24f:	jne    70eaa6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xca6>
  70e255:	mov    0x38(%rsp),%rcx
  70e25a:	mov    0x690(%rcx),%r14
  70e261:	lea    0x1e8(%rcx),%rdx
  70e268:	mov    %rdx,0x30(%rsp)
  70e26d:	add    $0x6b8,%rcx
  70e274:	mov    %rcx,0x40(%rsp)
  70e279:	xor    %ebx,%ebx
  70e27b:	lea    0x31598e(%rip),%rcx        # a23c10 <__frame_dummy_init_array_entry+0x1c20>
  70e282:	mov    %rcx,0x60(%rsp)
  70e287:	jmp    70e2ab <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4ab>
  70e289:	nopl   0x0(%rax)
  70e290:	mov    0x40(%rsp),%rdi
  70e295:	mov    %r12,%rsi
  70e298:	call   6fc770 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  70e29d:	mov    $0x0,%eax
  70e2a2:	dec    %r15
  70e2a5:	je     70eaa6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xca6>
  70e2ab:	test   %rbx,%rbx
  70e2ae:	je     70e2d0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d0>
  70e2b0:	movzwl 0x58a(%rbx),%ecx
  70e2b7:	cmp    %rcx,%r14
  70e2ba:	jae    70e380 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x580>
  70e2c0:	mov    %rbx,%rcx
  70e2c3:	mov    %r14,%rdx
  70e2c6:	jmp    70e3a6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5a6>
  70e2cb:	nopl   0x0(%rax,%rax,1)
  70e2d0:	test   %r14,%r14
  70e2d3:	je     70e30d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x50d>
  70e2d5:	mov    %r14,%rcx
  70e2d8:	mov    %rax,%rbx
  70e2db:	and    $0x7,%rcx
  70e2df:	je     70e312 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x512>
  70e2e1:	xor    %edx,%edx
  70e2e3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  70e2f0:	mov    0x590(%rbx),%rbx
  70e2f7:	inc    %rdx
  70e2fa:	cmp    %rdx,%rcx
  70e2fd:	jne    70e2f0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4f0>
  70e2ff:	mov    %r14,%rax
  70e302:	sub    %rdx,%rax
  70e305:	cmp    $0x8,%r14
  70e309:	jae    70e320 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x520>
  70e30b:	jmp    70e35e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x55e>
  70e30d:	mov    %rax,%rbx
  70e310:	jmp    70e35e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x55e>
  70e312:	mov    %r14,%rax
  70e315:	cmp    $0x8,%r14
  70e319:	jb     70e35e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x55e>
  70e31b:	nopl   0x0(%rax,%rax,1)
  70e320:	mov    0x590(%rbx),%rcx
  70e327:	mov    0x590(%rcx),%rcx
  70e32e:	mov    0x590(%rcx),%rcx
  70e335:	mov    0x590(%rcx),%rcx
  70e33c:	mov    0x590(%rcx),%rcx
  70e343:	mov    0x590(%rcx),%rcx
  70e34a:	mov    0x590(%rcx),%rcx
  70e351:	mov    0x590(%rcx),%rbx
  70e358:	add    $0xfffffffffffffff8,%rax
  70e35c:	jne    70e320 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x520>
  70e35e:	xor    %eax,%eax
  70e360:	xor    %r14d,%r14d
  70e363:	movzwl 0x58a(%rbx),%ecx
  70e36a:	cmp    %rcx,%r14
  70e36d:	jb     70e2c0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c0>
  70e373:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  70e380:	mov    0x580(%rbx),%rcx
  70e387:	test   %rcx,%rcx
  70e38a:	je     71284a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4a4a>
  70e390:	inc    %rax
  70e393:	movzwl 0x588(%rbx),%edx
  70e39a:	mov    %rcx,%rbx
  70e39d:	cmp    0x58a(%rcx),%dx
  70e3a4:	jae    70e380 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x580>
  70e3a6:	test   %rax,%rax
  70e3a9:	je     70e440 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x640>
  70e3af:	lea    (%rcx,%rdx,8),%rsi
  70e3b3:	add    $0x598,%rsi
  70e3ba:	mov    %rax,%rdi
  70e3bd:	and    $0x7,%rdi
  70e3c1:	je     70e550 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x750>
  70e3c7:	xor    %r8d,%r8d
  70e3ca:	nopw   0x0(%rax,%rax,1)
  70e3d0:	mov    (%rsi),%rbx
  70e3d3:	lea    0x590(%rbx),%rsi
  70e3da:	inc    %r8
  70e3dd:	cmp    %r8,%rdi
  70e3e0:	jne    70e3d0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5d0>
  70e3e2:	mov    %rax,%rdi
  70e3e5:	sub    %r8,%rdi
  70e3e8:	cmp    $0x8,%rax
  70e3ec:	jb     70e431 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x631>
  70e3ee:	xchg   %ax,%ax
  70e3f0:	mov    (%rsi),%rax
  70e3f3:	mov    0x590(%rax),%rax
  70e3fa:	mov    0x590(%rax),%rax
  70e401:	mov    0x590(%rax),%rax
  70e408:	mov    0x590(%rax),%rax
  70e40f:	mov    0x590(%rax),%rax
  70e416:	mov    0x590(%rax),%rax
  70e41d:	mov    0x590(%rax),%rbx
  70e424:	lea    0x590(%rbx),%rsi
  70e42b:	add    $0xfffffffffffffff8,%rdi
  70e42f:	jne    70e3f0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5f0>
  70e431:	xor    %r14d,%r14d
  70e434:	jmp    70e447 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x647>
  70e436:	cs nopw 0x0(%rax,%rax,1)
  70e440:	lea    0x1(%rdx),%r14
  70e444:	mov    %rcx,%rbx
  70e447:	imul   $0x70,%rdx,%rax
  70e44b:	shl    $0x4,%rdx
  70e44f:	lea    (%rcx,%rax,1),%rdi
  70e453:	add    $0xb0,%rdi
  70e45a:	mov    (%rcx,%rdx,1),%rsi
  70e45e:	mov    0x8(%rcx,%rdx,1),%rdx
  70e463:	call   *0x33450f(%rip)        # a42978 <_DYNAMIC+0x3e0>
  70e469:	mov    %rax,%r12
  70e46c:	mov    0x30(%rsp),%rdi
  70e471:	mov    %rax,%rsi
  70e474:	call   6f7fd0 <<gpui::runtime::identity_index::IdentityIndex>::required>
  70e479:	mov    %rax,%rbp
  70e47c:	mov    0x38(%rsp),%rax
  70e481:	mov    0x310(%rax),%r13
  70e488:	cmp    %r13,%rbp
  70e48b:	jae    712a2f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c2f>
  70e491:	mov    0x308(%rax),%rcx
  70e498:	lea    0x0(,%rbp,4),%rax
  70e4a0:	add    %rbp,%rax
  70e4a3:	mov    0x18(%rcx,%rax,8),%ebp
  70e4a7:	mov    $0xffffffff,%eax
  70e4ac:	cmp    %rax,%rbp
  70e4af:	je     70e29d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x49d>
  70e4b5:	cmp    %rbp,%r13
  70e4b8:	jbe    71296f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b6f>
  70e4be:	mov    0x40(%rsp),%rax
  70e4c3:	mov    (%rax),%rax
  70e4c6:	test   %rax,%rax
  70e4c9:	je     70e29d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x49d>
  70e4cf:	lea    0x0(,%rbp,4),%rdx
  70e4d7:	add    %rbp,%rdx
  70e4da:	mov    (%rcx,%rdx,8),%rcx
  70e4de:	mov    0x38(%rsp),%rdx
  70e4e3:	mov    0x6c0(%rdx),%rdx
  70e4ea:	movzwl 0x62(%rax),%edi
  70e4ee:	mov    %edi,%r8d
  70e4f1:	shl    $0x3,%r8d
  70e4f5:	mov    $0xffffffffffffffff,%rsi
  70e4fc:	nopl   0x0(%rax)
  70e500:	test   %r8,%r8
  70e503:	je     70e530 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x730>
  70e505:	cmp    0x10(%rax,%rsi,8),%rcx
  70e50a:	seta   %r9b
  70e50e:	sbb    $0x0,%r9b
  70e512:	inc    %rsi
  70e515:	add    $0xfffffffffffffff8,%r8
  70e519:	cmp    $0x1,%r9b
  70e51d:	je     70e500 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x700>
  70e51f:	movzbl %r9b,%edi
  70e523:	test   %edi,%edi
  70e525:	je     70e290 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x490>
  70e52b:	jmp    70e533 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x733>
  70e52d:	nopl   (%rax)
  70e530:	mov    %rdi,%rsi
  70e533:	sub    $0x1,%rdx
  70e537:	jb     70e29d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x49d>
  70e53d:	mov    0x68(%rax,%rsi,8),%rax
  70e542:	jmp    70e4ea <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x6ea>
  70e544:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  70e550:	mov    %rax,%rdi
  70e553:	cmp    $0x8,%rax
  70e557:	jae    70e3f0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5f0>
  70e55d:	jmp    70e431 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x631>
  70e562:	lea    0x480(%rsp),%rdi
  70e56a:	call   *0x334548(%rip)        # a42ab8 <_DYNAMIC+0x520>
  70e570:	lea    0x330(%r15),%r14
  70e577:	mov    %r14,%rdi
  70e57a:	call   6c5760 <core::ptr::drop_glue::<gpui_reactivity_core::layout::LayoutTree>>
  70e57f:	lea    0x480(%rsp),%rsi
  70e587:	mov    $0x298,%edx
  70e58c:	mov    %r14,%rdi
  70e58f:	call   *0x33428b(%rip)        # a42820 <memcpy@GLIBC_2.14>
  70e595:	movq   $0x0,0x5d8(%r15)
  70e5a0:	mov    0x310(%r15),%rax
  70e5a7:	test   %rax,%rax
  70e5aa:	je     70f08b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x128b>
  70e5b0:	lea    0x5c8(%r15),%rcx
  70e5b7:	mov    %rcx,0x40(%rsp)
  70e5bc:	mov    0x308(%r15),%r12
  70e5c3:	lea    (%rax,%rax,4),%rax
  70e5c7:	lea    (%r12,%rax,8),%rax
  70e5cb:	mov    %rax,0x30(%rsp)
  70e5d0:	xor    %r13d,%r13d
  70e5d3:	lea    -0x6cc85e(%rip),%r14        # 41d7c <GCC_except_table0+0x1f34>
  70e5da:	lea    0x314247(%rip),%rax        # a22828 <__frame_dummy_init_array_entry+0x838>
  70e5e1:	mov    %rax,0x60(%rsp)
  70e5e6:	xor    %ebx,%ebx
  70e5e8:	jmp    70e62b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x82b>
  70e5ea:	nopw   0x0(%rax,%rax,1)
  70e5f0:	add    $0x28,%r12
  70e5f4:	inc    %rbx
  70e5f7:	mov    0x38(%rsp),%r15
  70e5fc:	mov    0x5d0(%r15),%rax
  70e603:	mov    %r13,%rcx
  70e606:	shl    $0x4,%rcx
  70e60a:	movaps 0x890(%rsp),%xmm0
  70e612:	movups %xmm0,(%rax,%rcx,1)
  70e616:	inc    %r13
  70e619:	mov    %r13,0x5d8(%r15)
  70e620:	cmp    0x30(%rsp),%r12
  70e625:	je     70f08b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x128b>
  70e62b:	mov    0x18(%r12),%ebp
  70e630:	mov    $0xffffffff,%eax
  70e635:	cmp    %rax,%rbp
  70e638:	je     70e670 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x870>
  70e63a:	cmp    %rbp,%r13
  70e63d:	jbe    712a2f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c2f>
  70e643:	mov    0x5d0(%r15),%rax
  70e64a:	mov    %rbp,%rcx
  70e64d:	shl    $0x4,%rcx
  70e651:	movups (%rax,%rcx,1),%xmm0
  70e655:	lea    0xb98(%rsp),%rax
  70e65d:	movups %xmm0,(%rax)
  70e660:	mov    $0x1,%eax
  70e665:	jmp    70e672 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x872>
  70e667:	nopw   0x0(%rax,%rax,1)
  70e670:	xor    %eax,%eax
  70e672:	mov    %rax,0xb90(%rsp)
  70e67a:	mov    0x20(%r12),%eax
  70e67f:	and    $0xf,%eax
  70e682:	cmp    $0xa,%eax
  70e685:	jae    7127f6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x49f6>
  70e68b:	lea    -0x6bd940(%rip),%rcx        # 50d52 <GCC_except_table0+0x10f0a>
  70e692:	movzbl (%rax,%rcx,1),%r15d
  70e697:	mov    0x38(%rsp),%rcx
  70e69c:	mov    0x200(%rcx),%rax
  70e6a3:	movslq (%r14,%rax,4),%rax
  70e6a7:	add    %r14,%rax
  70e6aa:	jmp    *%rax
  70e6ac:	movups -0x6c144f(%rip),%xmm0        # 4d264 <GCC_except_table0+0xd41c>
  70e6b3:	movaps %xmm0,0x8f0(%rsp)
  70e6bb:	movups -0x6c146e(%rip),%xmm0        # 4d254 <GCC_except_table0+0xd40c>
  70e6c2:	movaps %xmm0,0x8e0(%rsp)
  70e6ca:	movups -0x6c148d(%rip),%xmm0        # 4d244 <GCC_except_table0+0xd3fc>
  70e6d1:	movaps %xmm0,0x8d0(%rsp)
  70e6d9:	movups -0x6c14ac(%rip),%xmm0        # 4d234 <GCC_except_table0+0xd3ec>
  70e6e0:	movaps %xmm0,0x8c0(%rsp)
  70e6e8:	movups -0x6c14cb(%rip),%xmm0        # 4d224 <GCC_except_table0+0xd3dc>
  70e6ef:	movaps %xmm0,0x8b0(%rsp)
  70e6f7:	movabs $0x3000100000000,%rax
  70e701:	mov    %rax,0x900(%rsp)
  70e709:	cmp    $0xffffffff,%ebp
  70e70c:	jne    70e7a1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x9a1>
  70e712:	jmp    70e857 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xa57>
  70e717:	mov    0x220(%rcx),%r13
  70e71e:	cmp    %r13,%rbx
  70e721:	jae    7129e8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4be8>
  70e727:	mov    0x210(%rcx),%r13
  70e72e:	mov    0x218(%rcx),%rax
  70e735:	movzbl (%rax,%rbx,1),%eax
  70e739:	cmp    %rax,%r13
  70e73c:	jbe    7129f4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4bf4>
  70e742:	mov    0x208(%rcx),%rcx
  70e749:	imul   $0x58,%rax,%rax
  70e74d:	mov    0x50(%rcx,%rax,1),%rdx
  70e752:	mov    %rdx,0x900(%rsp)
  70e75a:	movups 0x40(%rcx,%rax,1),%xmm0
  70e75f:	movaps %xmm0,0x8f0(%rsp)
  70e767:	movups (%rcx,%rax,1),%xmm0
  70e76b:	movups 0x10(%rcx,%rax,1),%xmm1
  70e770:	movups 0x20(%rcx,%rax,1),%xmm2
  70e775:	movupd 0x30(%rcx,%rax,1),%xmm3
  70e77b:	jmp    70e82d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xa2d>
  70e780:	mov    0x208(%rcx),%rsi
  70e787:	lea    0x8b0(%rsp),%rdi
  70e78f:	mov    %rbx,%rdx
  70e792:	call   *0x3341f8(%rip)        # a42990 <_DYNAMIC+0x3f8>
  70e798:	cmp    $0xffffffff,%ebp
  70e79b:	je     70e857 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xa57>
  70e7a1:	mov    0x38(%rsp),%rdx
  70e7a6:	mov    0x200(%rdx),%rax
  70e7ad:	lea    -0x6cca28(%rip),%rsi        # 41d8c <GCC_except_table0+0x1f44>
  70e7b4:	movslq (%rsi,%rax,4),%rcx
  70e7b8:	add    %rsi,%rcx
  70e7bb:	lea    -0x6c159e(%rip),%rax        # 4d224 <GCC_except_table0+0xd3dc>
  70e7c2:	jmp    *%rcx
  70e7c4:	mov    0x218(%rdx),%r13
  70e7cb:	cmp    %rbp,%r13
  70e7ce:	jbe    7129df <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4bdf>
  70e7d4:	imul   $0x58,%rbp,%rax
  70e7d8:	add    0x210(%rdx),%rax
  70e7df:	jmp    70e8a9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xaa9>
  70e7e4:	mov    0x218(%rcx),%r13
  70e7eb:	cmp    %r13,%rbx
  70e7ee:	jae    7129f9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4bf9>
  70e7f4:	mov    0x210(%rcx),%rax
  70e7fb:	imul   $0x58,%rbx,%rcx
  70e7ff:	mov    0x50(%rax,%rcx,1),%rdx
  70e804:	mov    %rdx,0x900(%rsp)
  70e80c:	movups 0x40(%rax,%rcx,1),%xmm0
  70e811:	movaps %xmm0,0x8f0(%rsp)
  70e819:	movups (%rax,%rcx,1),%xmm0
  70e81d:	movups 0x10(%rax,%rcx,1),%xmm1
  70e822:	movups 0x20(%rax,%rcx,1),%xmm2
  70e827:	movupd 0x30(%rax,%rcx,1),%xmm3
  70e82d:	movapd %xmm3,0x8e0(%rsp)
  70e836:	movaps %xmm2,0x8d0(%rsp)
  70e83e:	movaps %xmm1,0x8c0(%rsp)
  70e846:	movaps %xmm0,0x8b0(%rsp)
  70e84e:	cmp    $0xffffffff,%ebp
  70e851:	jne    70e7a1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x9a1>
  70e857:	mov    $0x2,%al
  70e859:	mov    0x38(%rsp),%rdx
  70e85e:	mov    0x6a0(%rdx),%r8
  70e865:	test   %r8,%r8
  70e868:	jne    70e929 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xb29>
  70e86e:	jmp    70e9b0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xbb0>
  70e873:	mov    0x220(%rdx),%r13
  70e87a:	cmp    %rbp,%r13
  70e87d:	jbe    7129d6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4bd6>
  70e883:	mov    0x210(%rdx),%r13
  70e88a:	mov    0x218(%rdx),%rax
  70e891:	movzbl (%rax,%rbp,1),%ebp
  70e895:	cmp    %rbp,%r13
  70e898:	jbe    712a23 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c23>
  70e89e:	imul   $0x58,%rbp,%rax
  70e8a2:	add    0x208(%rdx),%rax
  70e8a9:	mov    0x50(%rax),%rcx
  70e8ad:	mov    %rcx,0x4d0(%rsp)
  70e8b5:	movups 0x40(%rax),%xmm0
  70e8b9:	movaps %xmm0,0x4c0(%rsp)
  70e8c1:	movups (%rax),%xmm0
  70e8c4:	movups 0x10(%rax),%xmm1
  70e8c8:	movups 0x20(%rax),%xmm2
  70e8cc:	movupd 0x30(%rax),%xmm3
  70e8d1:	movapd %xmm3,0x4b0(%rsp)
  70e8da:	movaps %xmm2,0x4a0(%rsp)
  70e8e2:	movaps %xmm1,0x490(%rsp)
  70e8ea:	movaps %xmm0,0x480(%rsp)
  70e8f2:	jmp    70e90c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xb0c>
  70e8f4:	mov    0x208(%rdx),%rsi
  70e8fb:	lea    0x480(%rsp),%rdi
  70e903:	mov    %rbp,%rdx
  70e906:	call   *0x334084(%rip)        # a42990 <_DYNAMIC+0x3f8>
  70e90c:	movzbl 0x4d4(%rsp),%eax
  70e914:	mov    0x38(%rsp),%rdx
  70e919:	mov    0x6a0(%rdx),%r8
  70e920:	test   %r8,%r8
  70e923:	je     70e9b0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xbb0>
  70e929:	mov    (%r12),%rcx
  70e92d:	mov    0x6a8(%rdx),%rdx
  70e934:	movzwl 0x1c2(%r8),%edi
  70e93c:	mov    %edi,%r10d
  70e93f:	shl    $0x5,%r10d
  70e943:	mov    $0xffffffffffffffff,%rsi
  70e94a:	xor    %r9d,%r9d
  70e94d:	nopl   (%rax)
  70e950:	mov    %r10,%r11
  70e953:	add    %r9,%r11
  70e956:	je     70e980 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xb80>
  70e958:	cmp    0x170(%r8,%rsi,8),%rcx
  70e960:	seta   %r11b
  70e964:	sbb    $0x0,%r11b
  70e968:	add    $0xffffffffffffffe0,%r9
  70e96c:	inc    %rsi
  70e96f:	cmp    $0x1,%r11b
  70e973:	je     70e950 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xb50>
  70e975:	movzbl %r11b,%edi
  70e979:	test   %edi,%edi
  70e97b:	jne    70e983 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xb83>
  70e97d:	jmp    70e9a0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xba0>
  70e97f:	nop
  70e980:	mov    %rdi,%rsi
  70e983:	sub    $0x1,%rdx
  70e987:	jb     70e9b0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xbb0>
  70e989:	mov    0x1c8(%r8,%rsi,8),%r8
  70e991:	jmp    70e934 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xb34>
  70e993:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  70e9a0:	sub    %r9,%r8
  70e9a3:	add    $0xffffffffffffffe0,%r8
  70e9a7:	jmp    70e9b3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xbb3>
  70e9a9:	nopl   0x0(%rax)
  70e9b0:	xor    %r8d,%r8d
  70e9b3:	movzbl %r15b,%esi
  70e9b7:	movzbl %al,%ecx
  70e9ba:	lea    0x480(%rsp),%rdi
  70e9c2:	lea    0x8b0(%rsp),%rdx
  70e9ca:	call   *0x3342f0(%rip)        # a42cc0 <_DYNAMIC+0x728>
  70e9d0:	lea    0x760(%rsp),%rdi
  70e9d8:	mov    0x58(%rsp),%rsi
  70e9dd:	lea    0xb90(%rsp),%rdx
  70e9e5:	xor    %ecx,%ecx
  70e9e7:	lea    0x480(%rsp),%r8
  70e9ef:	call   *0x3342d3(%rip)        # a42cc8 <_DYNAMIC+0x730>
  70e9f5:	cmpb   $0x0,0x760(%rsp)
  70e9fd:	jne    70f5a8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x17a8>
  70ea03:	lea    0x768(%rsp),%rax
  70ea0b:	movups (%rax),%xmm0
  70ea0e:	lea    0x86(%rsp),%rax
  70ea16:	movups %xmm0,(%rax)
  70ea19:	movups (%rax),%xmm0
  70ea1c:	movaps %xmm0,0x890(%rsp)
  70ea24:	mov    0x20(%r12),%ecx
  70ea29:	mov    %ecx,%eax
  70ea2b:	and    $0xf,%eax
  70ea2e:	cmp    $0x9,%eax
  70ea31:	ja     7127f6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x49f6>
  70ea37:	cmp    $0x6,%eax
  70ea3a:	je     70ea4c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xc4c>
  70ea3c:	cmp    $0x10,%ecx
  70ea3f:	setae  %cl
  70ea42:	cmp    $0x6,%eax
  70ea45:	sete   %al
  70ea48:	or     %cl,%al
  70ea4a:	je     70ea7e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xc7e>
  70ea4c:	movaps 0x890(%rsp),%xmm0
  70ea54:	movaps %xmm0,0x480(%rsp)
  70ea5c:	mov    0x58(%rsp),%rdi
  70ea61:	lea    0x480(%rsp),%rsi
  70ea69:	mov    0x334260(%rip),%rdx        # a42cd0 <_DYNAMIC+0x738>
  70ea70:	call   *0x334262(%rip)        # a42cd8 <_DYNAMIC+0x740>
  70ea76:	test   $0x1,%al
  70ea78:	jne    70f597 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1797>
  70ea7e:	mov    0x38(%rsp),%rax
  70ea83:	mov    0x5d8(%rax),%r13
  70ea8a:	cmp    0x5c8(%rax),%r13
  70ea91:	jne    70e5f0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x7f0>
  70ea97:	mov    0x40(%rsp),%rdi
  70ea9c:	call   6f4780 <<alloc::raw_vec::RawVec<[core::option::Option<gpui::source::FieldId>; 2]>>::grow_one>
  70eaa1:	jmp    70e5f0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x7f0>
  70eaa6:	mov    0x38(%rsp),%r15
  70eaab:	mov    0x6b8(%r15),%rax
  70eab2:	mov    0x6c8(%r15),%rdi
  70eab9:	test   %rax,%rax
  70eabc:	setne  %cl
  70eabf:	test   %rdi,%rdi
  70eac2:	setne  %dl
  70eac5:	and    %cl,%dl
  70eac7:	cmp    $0x1,%dl
  70eaca:	jne    70f08b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x128b>
  70ead0:	mov    0x6c0(%r15),%rbx
  70ead7:	lea    0x1e8(%r15),%rcx
  70eade:	mov    %rcx,0x50(%rsp)
  70eae3:	xor    %r12d,%r12d
  70eae6:	lea    0x3150db(%rip),%rcx        # a23bc8 <__frame_dummy_init_array_entry+0x1bd8>
  70eaed:	mov    %rcx,0x60(%rsp)
  70eaf2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  70eb00:	test   %r12,%r12
  70eb03:	je     70eb1c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xd1c>
  70eb05:	movzwl 0x62(%r12),%ecx
  70eb0b:	cmp    %rcx,%rbx
  70eb0e:	jae    70eba0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xda0>
  70eb14:	mov    %r12,%r15
  70eb17:	jmp    70ebc0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xdc0>
  70eb1c:	test   %rbx,%rbx
  70eb1f:	je     70eb4b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xd4b>
  70eb21:	mov    %rbx,%rcx
  70eb24:	mov    %rax,%r12
  70eb27:	and    $0x7,%rcx
  70eb2b:	je     70eb50 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xd50>
  70eb2d:	xor    %edx,%edx
  70eb2f:	nop
  70eb30:	mov    0x68(%r12),%r12
  70eb35:	inc    %rdx
  70eb38:	cmp    %rdx,%rcx
  70eb3b:	jne    70eb30 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xd30>
  70eb3d:	mov    %rbx,%rax
  70eb40:	sub    %rdx,%rax
  70eb43:	cmp    $0x8,%rbx
  70eb47:	jae    70eb60 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xd60>
  70eb49:	jmp    70eb87 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xd87>
  70eb4b:	mov    %rax,%r12
  70eb4e:	jmp    70eb87 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xd87>
  70eb50:	mov    %rbx,%rax
  70eb53:	cmp    $0x8,%rbx
  70eb57:	jb     70eb87 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xd87>
  70eb59:	nopl   0x0(%rax)
  70eb60:	mov    0x68(%r12),%rcx
  70eb65:	mov    0x68(%rcx),%rcx
  70eb69:	mov    0x68(%rcx),%rcx
  70eb6d:	mov    0x68(%rcx),%rcx
  70eb71:	mov    0x68(%rcx),%rcx
  70eb75:	mov    0x68(%rcx),%rcx
  70eb79:	mov    0x68(%rcx),%rcx
  70eb7d:	mov    0x68(%rcx),%r12
  70eb81:	add    $0xfffffffffffffff8,%rax
  70eb85:	jne    70eb60 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xd60>
  70eb87:	xor    %eax,%eax
  70eb89:	xor    %ebx,%ebx
  70eb8b:	movzwl 0x62(%r12),%ecx
  70eb91:	cmp    %rcx,%rbx
  70eb94:	jb     70eb14 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xd14>
  70eb9a:	nopw   0x0(%rax,%rax,1)
  70eba0:	mov    (%r12),%r15
  70eba4:	test   %r15,%r15
  70eba7:	je     712868 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4a68>
  70ebad:	inc    %rax
  70ebb0:	movzwl 0x60(%r12),%ebx
  70ebb6:	mov    %r15,%r12
  70ebb9:	cmp    0x62(%r15),%bx
  70ebbe:	jae    70eba0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xda0>
  70ebc0:	test   %rax,%rax
  70ebc3:	mov    %rdi,0x40(%rsp)
  70ebc8:	je     70ec48 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xe48>
  70ebca:	lea    (%r15,%rbx,8),%rcx
  70ebce:	add    $0x70,%rcx
  70ebd2:	mov    %rax,%rdx
  70ebd5:	and    $0x7,%rdx
  70ebd9:	je     70eea3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x10a3>
  70ebdf:	xor    %esi,%esi
  70ebe1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  70ebf0:	mov    (%rcx),%r12
  70ebf3:	lea    0x68(%r12),%rcx
  70ebf8:	inc    %rsi
  70ebfb:	cmp    %rsi,%rdx
  70ebfe:	jne    70ebf0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xdf0>
  70ec00:	mov    %rax,%rdx
  70ec03:	sub    %rsi,%rdx
  70ec06:	cmp    $0x8,%rax
  70ec0a:	jb     70ec3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xe3a>
  70ec0c:	nopl   0x0(%rax)
  70ec10:	mov    (%rcx),%rax
  70ec13:	mov    0x68(%rax),%rax
  70ec17:	mov    0x68(%rax),%rax
  70ec1b:	mov    0x68(%rax),%rax
  70ec1f:	mov    0x68(%rax),%rax
  70ec23:	mov    0x68(%rax),%rax
  70ec27:	mov    0x68(%rax),%rax
  70ec2b:	mov    0x68(%rax),%r12
  70ec2f:	lea    0x68(%r12),%rcx
  70ec34:	add    $0xfffffffffffffff8,%rdx
  70ec38:	jne    70ec10 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xe10>
  70ec3a:	movq   $0x0,0x180(%rsp)
  70ec46:	jmp    70ec57 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xe57>
  70ec48:	lea    0x1(%rbx),%rax
  70ec4c:	mov    %rax,0x180(%rsp)
  70ec54:	mov    %r15,%r12
  70ec57:	mov    0x8(%r15,%rbx,8),%rsi
  70ec5c:	mov    0x50(%rsp),%rdi
  70ec61:	call   6f7fd0 <<gpui::runtime::identity_index::IdentityIndex>::required>
  70ec66:	mov    %rax,%rbp
  70ec69:	mov    0x38(%rsp),%rdx
  70ec6e:	mov    0x5d8(%rdx),%r13
  70ec75:	cmp    %r13,%rax
  70ec78:	jae    712a2f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c2f>
  70ec7e:	mov    0x5d0(%rdx),%rax
  70ec85:	mov    %rbp,%rcx
  70ec88:	shl    $0x4,%rcx
  70ec8c:	movups (%rax,%rcx,1),%xmm0
  70ec90:	movaps %xmm0,0x80(%rsp)
  70ec98:	mov    0x310(%rdx),%r13
  70ec9f:	cmp    %r13,%rbp
  70eca2:	jae    7129a8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4ba8>
  70eca8:	mov    0x308(%rdx),%rax
  70ecaf:	lea    0x0(,%rbp,4),%r14
  70ecb7:	add    %rbp,%r14
  70ecba:	mov    0x20(%rax,%r14,8),%eax
  70ecbf:	and    $0xf,%eax
  70ecc2:	cmp    $0xa,%eax
  70ecc5:	jae    7127f6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x49f6>
  70eccb:	lea    -0x6bdf80(%rip),%rcx        # 50d52 <GCC_except_table0+0x10f0a>
  70ecd2:	movzbl (%rax,%rcx,1),%eax
  70ecd6:	mov    %al,0x30(%rsp)
  70ecda:	mov    0x38(%rsp),%rdx
  70ecdf:	mov    0x200(%rdx),%rax
  70ece6:	lea    -0x6ccf91(%rip),%rcx        # 41d5c <GCC_except_table0+0x1f14>
  70eced:	movslq (%rcx,%rax,4),%rax
  70ecf1:	add    %rcx,%rax
  70ecf4:	jmp    *%rax
  70ecf6:	movups -0x6c1a99(%rip),%xmm0        # 4d264 <GCC_except_table0+0xd41c>
  70ecfd:	movaps %xmm0,0x8f0(%rsp)
  70ed05:	movups -0x6c1ab8(%rip),%xmm0        # 4d254 <GCC_except_table0+0xd40c>
  70ed0c:	movaps %xmm0,0x8e0(%rsp)
  70ed14:	movups -0x6c1ad7(%rip),%xmm0        # 4d244 <GCC_except_table0+0xd3fc>
  70ed1b:	movaps %xmm0,0x8d0(%rsp)
  70ed23:	movups -0x6c1af6(%rip),%xmm0        # 4d234 <GCC_except_table0+0xd3ec>
  70ed2a:	movaps %xmm0,0x8c0(%rsp)
  70ed32:	movups -0x6c1b15(%rip),%xmm0        # 4d224 <GCC_except_table0+0xd3dc>
  70ed39:	movaps %xmm0,0x8b0(%rsp)
  70ed41:	movabs $0x3000100000000,%rax
  70ed4b:	mov    %rax,0x900(%rsp)
  70ed53:	jmp    70ee20 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1020>
  70ed58:	mov    0x220(%rdx),%rax
  70ed5f:	cmp    %rax,%rbp
  70ed62:	jae    712a11 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c11>
  70ed68:	mov    0x210(%rdx),%rax
  70ed6f:	mov    0x218(%rdx),%rcx
  70ed76:	movzbl (%rcx,%rbp,1),%ecx
  70ed7a:	cmp    %rcx,%rax
  70ed7d:	jbe    712a1d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c1d>
  70ed83:	mov    0x208(%rdx),%rax
  70ed8a:	imul   $0x58,%rcx,%rcx
  70ed8e:	jmp    70edd1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xfd1>
  70ed90:	mov    0x208(%rdx),%rsi
  70ed97:	lea    0x8b0(%rsp),%rdi
  70ed9f:	mov    %rbp,%rdx
  70eda2:	call   *0x333be8(%rip)        # a42990 <_DYNAMIC+0x3f8>
  70eda8:	mov    0x38(%rsp),%rax
  70edad:	mov    0x310(%rax),%r13
  70edb4:	jmp    70ee20 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1020>
  70edb6:	mov    0x218(%rdx),%rax
  70edbd:	cmp    %rax,%rbp
  70edc0:	jae    712a05 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c05>
  70edc6:	mov    0x210(%rdx),%rax
  70edcd:	imul   $0x58,%rbp,%rcx
  70edd1:	mov    0x50(%rax,%rcx,1),%rdx
  70edd6:	mov    %rdx,0x900(%rsp)
  70edde:	movups 0x40(%rax,%rcx,1),%xmm0
  70ede3:	movaps %xmm0,0x8f0(%rsp)
  70edeb:	movups (%rax,%rcx,1),%xmm0
  70edef:	movups 0x10(%rax,%rcx,1),%xmm1
  70edf4:	movups 0x20(%rax,%rcx,1),%xmm2
  70edf9:	movupd 0x30(%rax,%rcx,1),%xmm3
  70edff:	movapd %xmm3,0x8e0(%rsp)
  70ee08:	movaps %xmm2,0x8d0(%rsp)
  70ee10:	movaps %xmm1,0x8c0(%rsp)
  70ee18:	movaps %xmm0,0x8b0(%rsp)
  70ee20:	cmp    %r13,%rbp
  70ee23:	jae    7129b1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4bb1>
  70ee29:	mov    0x38(%rsp),%rdx
  70ee2e:	mov    0x308(%rdx),%rax
  70ee35:	mov    0x18(%rax,%r14,8),%ebp
  70ee3a:	mov    $0xffffffff,%eax
  70ee3f:	cmp    %rax,%rbp
  70ee42:	je     70ee7f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x107f>
  70ee44:	mov    0x200(%rdx),%rax
  70ee4b:	lea    -0x6cd0e6(%rip),%rsi        # 41d6c <GCC_except_table0+0x1f24>
  70ee52:	movslq (%rsi,%rax,4),%rcx
  70ee56:	add    %rsi,%rcx
  70ee59:	lea    -0x6c1c3c(%rip),%rax        # 4d224 <GCC_except_table0+0xd3dc>
  70ee60:	jmp    *%rcx
  70ee62:	mov    0x218(%rdx),%r13
  70ee69:	cmp    %rbp,%r13
  70ee6c:	jbe    7129df <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4bdf>
  70ee72:	imul   $0x58,%rbp,%rax
  70ee76:	add    0x210(%rdx),%rax
  70ee7d:	jmp    70eeeb <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x10eb>
  70ee7f:	mov    $0x2,%al
  70ee81:	mov    0x38(%rsp),%rdx
  70ee86:	mov    0x6a0(%rdx),%r8
  70ee8d:	test   %r8,%r8
  70ee90:	jne    70ef6b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x116b>
  70ee96:	xor    %r8d,%r8d
  70ee99:	movzbl 0x30(%rsp),%ebx
  70ee9e:	jmp    70eff7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x11f7>
  70eea3:	mov    %rax,%rdx
  70eea6:	cmp    $0x8,%rax
  70eeaa:	jae    70ec10 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xe10>
  70eeb0:	jmp    70ec3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xe3a>
  70eeb5:	mov    0x220(%rdx),%r13
  70eebc:	cmp    %rbp,%r13
  70eebf:	jbe    7129d6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4bd6>
  70eec5:	mov    0x210(%rdx),%r13
  70eecc:	mov    0x218(%rdx),%rax
  70eed3:	movzbl (%rax,%rbp,1),%ebp
  70eed7:	cmp    %rbp,%r13
  70eeda:	jbe    712a23 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c23>
  70eee0:	imul   $0x58,%rbp,%rax
  70eee4:	add    0x208(%rdx),%rax
  70eeeb:	mov    0x50(%rax),%rcx
  70eeef:	mov    %rcx,0x4d0(%rsp)
  70eef7:	movups 0x40(%rax),%xmm0
  70eefb:	movaps %xmm0,0x4c0(%rsp)
  70ef03:	movups (%rax),%xmm0
  70ef06:	movups 0x10(%rax),%xmm1
  70ef0a:	movups 0x20(%rax),%xmm2
  70ef0e:	movupd 0x30(%rax),%xmm3
  70ef13:	movapd %xmm3,0x4b0(%rsp)
  70ef1c:	movaps %xmm2,0x4a0(%rsp)
  70ef24:	movaps %xmm1,0x490(%rsp)
  70ef2c:	movaps %xmm0,0x480(%rsp)
  70ef34:	jmp    70ef4e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x114e>
  70ef36:	mov    0x208(%rdx),%rsi
  70ef3d:	lea    0x480(%rsp),%rdi
  70ef45:	mov    %rbp,%rdx
  70ef48:	call   *0x333a42(%rip)        # a42990 <_DYNAMIC+0x3f8>
  70ef4e:	movzbl 0x4d4(%rsp),%eax
  70ef56:	mov    0x38(%rsp),%rdx
  70ef5b:	mov    0x6a0(%rdx),%r8
  70ef62:	test   %r8,%r8
  70ef65:	je     70ee96 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1096>
  70ef6b:	mov    0x8(%r15,%rbx,8),%rcx
  70ef70:	mov    0x6a8(%rdx),%rdx
  70ef77:	movzbl 0x30(%rsp),%ebx
  70ef7c:	movzwl 0x1c2(%r8),%edi
  70ef84:	mov    %edi,%r10d
  70ef87:	shl    $0x5,%r10d
  70ef8b:	mov    $0xffffffffffffffff,%rsi
  70ef92:	xor    %r9d,%r9d
  70ef95:	data16 cs nopw 0x0(%rax,%rax,1)
  70efa0:	mov    %r10,%r11
  70efa3:	add    %r9,%r11
  70efa6:	je     70efd0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x11d0>
  70efa8:	cmp    0x170(%r8,%rsi,8),%rcx
  70efb0:	seta   %r11b
  70efb4:	sbb    $0x0,%r11b
  70efb8:	add    $0xffffffffffffffe0,%r9
  70efbc:	inc    %rsi
  70efbf:	cmp    $0x1,%r11b
  70efc3:	je     70efa0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x11a0>
  70efc5:	movzbl %r11b,%edi
  70efc9:	test   %edi,%edi
  70efcb:	jne    70efd3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x11d3>
  70efcd:	jmp    70eff0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x11f0>
  70efcf:	nop
  70efd0:	mov    %rdi,%rsi
  70efd3:	sub    $0x1,%rdx
  70efd7:	jb     70f083 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1283>
  70efdd:	mov    0x1c8(%r8,%rsi,8),%r8
  70efe5:	jmp    70ef7c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x117c>
  70efe7:	nopw   0x0(%rax,%rax,1)
  70eff0:	sub    %r9,%r8
  70eff3:	add    $0xffffffffffffffe0,%r8
  70eff7:	movzbl %bl,%esi
  70effa:	movzbl %al,%ecx
  70effd:	lea    0x480(%rsp),%rdi
  70f005:	lea    0x8b0(%rsp),%rdx
  70f00d:	call   *0x333cad(%rip)        # a42cc0 <_DYNAMIC+0x728>
  70f013:	movaps 0x80(%rsp),%xmm0
  70f01b:	movaps %xmm0,0x760(%rsp)
  70f023:	mov    0x58(%rsp),%rdi
  70f028:	lea    0x760(%rsp),%rsi
  70f030:	lea    0x480(%rsp),%rdx
  70f038:	call   *0x333ca2(%rip)        # a42ce0 <_DYNAMIC+0x748>
  70f03e:	test   $0x1,%al
  70f040:	jne    70f597 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1797>
  70f046:	mov    0x58(%rsp),%rdi
  70f04b:	lea    0x80(%rsp),%rsi
  70f053:	call   *0x333bef(%rip)        # a42c48 <_DYNAMIC+0x6b0>
  70f059:	cmp    $0xff,%al
  70f05b:	jne    70f5b0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x17b0>
  70f061:	mov    $0x0,%eax
  70f066:	mov    0x40(%rsp),%rdi
  70f06b:	dec    %rdi
  70f06e:	mov    0x38(%rsp),%r15
  70f073:	mov    0x180(%rsp),%rbx
  70f07b:	jne    70eb00 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0xd00>
  70f081:	jmp    70f08b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x128b>
  70f083:	xor    %r8d,%r8d
  70f086:	jmp    70eff7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x11f7>
  70f08b:	lea    0x318(%r15),%rax
  70f092:	mov    0x588(%r15),%r14
  70f099:	mov    0x5a8(%r15),%rbx
  70f0a0:	lea    0x5c8(%r15),%rcx
  70f0a7:	movq   $0xfffffffffffffffe,0x718(%rsp)
  70f0b3:	lea    0x300(%r15),%rdx
  70f0ba:	lea    0x200(%r15),%rdi
  70f0c1:	lea    0x630(%r15),%rsi
  70f0c8:	mov    %rcx,0xb18(%rsp)
  70f0d0:	mov    %rdx,0xb20(%rsp)
  70f0d8:	mov    %rsi,0x180(%rsp)
  70f0e0:	mov    %rsi,0xb28(%rsp)
  70f0e8:	lea    0x1b0(%rsp),%rcx
  70f0f0:	mov    %rcx,0xb30(%rsp)
  70f0f8:	mov    %rax,0xb38(%rsp)
  70f100:	mov    %rdi,0x40(%rsp)
  70f105:	mov    %rdi,0xb40(%rsp)
  70f10d:	lea    0x718(%rsp),%rax
  70f115:	mov    %rax,0xb48(%rsp)
  70f11d:	cmpq   $0x0,0x5d8(%r15)
  70f125:	je     712a45 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c45>
  70f12b:	mov    0x5d0(%r15),%rax
  70f132:	movupd (%rax),%xmm0
  70f136:	movapd %xmm0,0x8b0(%rsp)
  70f13f:	xorpd  %xmm0,%xmm0
  70f143:	movapd 0x100(%rsp),%xmm1
  70f14c:	unpcklps %xmm0,%xmm1
  70f14f:	movapd -0x6ce157(%rip),%xmm0        # 41000 <GCC_except_table0+0x11b8>
  70f157:	orpd   %xmm0,%xmm1
  70f15b:	subpd  %xmm0,%xmm1
  70f15f:	cvtpd2ps %xmm1,%xmm1
  70f163:	movapd %xmm1,%xmm0
  70f167:	shufps $0x55,%xmm1,%xmm0
  70f16b:	movaps %xmm1,0x100(%rsp)
  70f173:	movss  0x7c(%rsp),%xmm2
  70f179:	divss  %xmm2,%xmm1
  70f17d:	divss  %xmm2,%xmm0
  70f181:	movl   $0x0,0x480(%rsp)
  70f18c:	movss  %xmm1,0x484(%rsp)
  70f195:	movl   $0x0,0x488(%rsp)
  70f1a0:	movss  %xmm0,0x48c(%rsp)
  70f1a9:	mov    $0x1,%r12b
  70f1ac:	lea    0x314e6d(%rip),%r8        # a24020 <__frame_dummy_init_array_entry+0x2030>
  70f1b3:	lea    0x8b0(%rsp),%rsi
  70f1bb:	lea    0x480(%rsp),%rdx
  70f1c3:	lea    0xb18(%rsp),%rcx
  70f1cb:	mov    $0x1,%bpl
  70f1ce:	mov    0x58(%rsp),%rdi
  70f1d3:	call   *0x333b0f(%rip)        # a42ce8 <_DYNAMIC+0x750>
  70f1d9:	test   $0x1,%al
  70f1db:	je     70f243 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1443>
  70f1dd:	mov    0x48(%rsp),%rax
  70f1e2:	movq   $0x22,(%rax)
  70f1e9:	mov    %dl,0x8(%rax)
  70f1ec:	mov    0x718(%rsp),%rax
  70f1f4:	mov    $0x1,%r12b
  70f1f7:	mov    $0x1,%bpl
  70f1fa:	cmp    $0xfffffffffffffffe,%rax
  70f1fe:	je     70f5c5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x17c5>
  70f204:	sub    $0xd,%rax
  70f208:	mov    $0x14,%ecx
  70f20d:	cmovge %rax,%rcx
  70f211:	cmp    $0x14,%rcx
  70f215:	je     70f682 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1882>
  70f21b:	cmp    $0x19,%rcx
  70f21f:	jne    70f5c5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x17c5>
  70f225:	mov    0x720(%rsp),%rsi
  70f22d:	test   %rsi,%rsi
  70f230:	je     70f5c5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x17c5>
  70f236:	lea    0x728(%rsp),%rax
  70f23e:	jmp    70f69b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x189b>
  70f243:	mov    0x588(%r15),%rax
  70f24a:	sub    %r14,%rax
  70f24d:	mov    0x5a8(%r15),%rcx
  70f254:	add    %rax,0x748(%r15)
  70f25b:	sub    %rbx,%rcx
  70f25e:	add    %rcx,0x750(%r15)
  70f265:	cmpl   $0xfffffffe,0x718(%rsp)
  70f26d:	jne    70f561 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1761>
  70f273:	lea    0x480(%rsp),%rdi
  70f27b:	mov    $0x1,%bpl
  70f27e:	mov    %r15,%rsi
  70f281:	mov    $0x1,%edx
  70f286:	call   6f3550 <<gpui::runtime::Runtime<text_column_public_control::Model>>::refresh_inspector>
  70f28b:	cmpl   $0xfffffffe,0x480(%rsp)
  70f293:	jne    70f649 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1849>
  70f299:	mov    0x310(%r15),%rsi
  70f2a0:	lea    0x480(%rsp),%rdi
  70f2a8:	mov    $0x8,%ecx
  70f2ad:	mov    $0x40,%r8d
  70f2b3:	xor    %edx,%edx
  70f2b5:	call   6f4e50 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  70f2ba:	mov    0x488(%rsp),%rdi
  70f2c2:	cmpl   $0x1,0x480(%rsp)
  70f2ca:	je     7128a8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4aa8>
  70f2d0:	mov    0x490(%rsp),%rax
  70f2d8:	mov    %rdi,0x1c0(%rsp)
  70f2e0:	mov    %rax,0x1c8(%rsp)
  70f2e8:	movq   $0x0,0x1d0(%rsp)
  70f2f4:	movq   $0x0,0x278(%rsp)
  70f300:	movq   $0x4,0x280(%rsp)
  70f30c:	movq   $0x0,0x288(%rsp)
  70f318:	mov    0x310(%r15),%rsi
  70f31f:	lea    0x480(%rsp),%rdi
  70f327:	mov    $0x8,%ecx
  70f32c:	mov    $0x38,%r8d
  70f332:	xor    %edx,%edx
  70f334:	call   6f4e50 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  70f339:	mov    0x488(%rsp),%rdi
  70f341:	cmpb   $0x0,0x480(%rsp)
  70f349:	jne    7128be <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4abe>
  70f34f:	mov    0x490(%rsp),%rax
  70f357:	mov    %rdi,0x1e8(%rsp)
  70f35f:	mov    %rax,0x1f0(%rsp)
  70f367:	movq   $0x0,0x1f8(%rsp)
  70f373:	mov    0x698(%r15),%rbx
  70f37a:	test   %rbx,%rbx
  70f37d:	setne  0x2f(%rsp)
  70f382:	je     70f38b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x158b>
  70f384:	mov    0x310(%r15),%rbx
  70f38b:	lea    0x480(%rsp),%rdi
  70f393:	mov    $0x4,%ecx
  70f398:	mov    $0x10,%r8d
  70f39e:	mov    %rbx,%rsi
  70f3a1:	xor    %edx,%edx
  70f3a3:	call   6f4e50 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  70f3a8:	mov    0x488(%rsp),%rdi
  70f3b0:	cmpb   $0x0,0x480(%rsp)
  70f3b8:	jne    7128d1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4ad1>
  70f3be:	mov    0x490(%rsp),%rax
  70f3c6:	mov    %rdi,0x210(%rsp)
  70f3ce:	mov    %rax,0x218(%rsp)
  70f3d6:	movq   $0x0,0x220(%rsp)
  70f3e2:	lea    0x480(%rsp),%rdi
  70f3ea:	mov    $0x4,%ecx
  70f3ef:	mov    $0x10,%r8d
  70f3f5:	mov    %rbx,%rsi
  70f3f8:	xor    %edx,%edx
  70f3fa:	call   6f4e50 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  70f3ff:	mov    0x488(%rsp),%rdi
  70f407:	cmpb   $0x0,0x480(%rsp)
  70f40f:	jne    7128e4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4ae4>
  70f415:	mov    0x490(%rsp),%rax
  70f41d:	mov    %rdi,0x228(%rsp)
  70f425:	mov    %rax,0x230(%rsp)
  70f42d:	movq   $0x0,0x238(%rsp)
  70f439:	lea    0x480(%rsp),%rdi
  70f441:	mov    $0x1,%ecx
  70f446:	mov    $0x1,%r8d
  70f44c:	mov    %rbx,%rsi
  70f44f:	xor    %edx,%edx
  70f451:	call   6f4e50 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  70f456:	mov    0x488(%rsp),%rdi
  70f45e:	cmpb   $0x0,0x480(%rsp)
  70f466:	jne    7128f7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4af7>
  70f46c:	mov    0x490(%rsp),%rax
  70f474:	mov    %rdi,0x188(%rsp)
  70f47c:	mov    %rax,0x190(%rsp)
  70f484:	movq   $0x0,0x198(%rsp)
  70f490:	lea    0x480(%rsp),%rdi
  70f498:	mov    $0x4,%ecx
  70f49d:	mov    $0x4,%r8d
  70f4a3:	mov    %rbx,%rsi
  70f4a6:	xor    %edx,%edx
  70f4a8:	call   6f4e50 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  70f4ad:	mov    0x488(%rsp),%rdi
  70f4b5:	cmpb   $0x0,0x480(%rsp)
  70f4bd:	jne    71290a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b0a>
  70f4c3:	mov    0x490(%rsp),%rax
  70f4cb:	mov    %rdi,0x140(%rsp)
  70f4d3:	mov    %rax,0x148(%rsp)
  70f4db:	movq   $0x0,0x150(%rsp)
  70f4e7:	movq   $0x0,0x338(%rsp)
  70f4f3:	movq   $0x0,0x348(%rsp)
  70f4ff:	mov    0x680(%r15),%rcx
  70f506:	test   %rcx,%rcx
  70f509:	je     70f6ae <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x18ae>
  70f50f:	mov    0x310(%r15),%rsi
  70f516:	mov    0x6b0(%r15),%rdx
  70f51d:	mov    $0x1,%r12b
  70f520:	lea    0x760(%rsp),%rdi
  70f528:	mov    $0x1,%r13b
  70f52b:	mov    $0x1,%bpl
  70f52e:	call   6da500 <<gpui::runtime::Runtime<text_column_public_control::Input>>::metadata_sheet::{closure#0}>
  70f533:	jmp    70f6ba <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x18ba>
  70f538:	mov    0x48(%rsp),%rax
  70f53d:	movq   $0x23,(%rax)
  70f544:	mov    %r14d,0x8(%rax)
  70f548:	mov    %ebp,0xc(%rax)
  70f54b:	mov    0xbd0(%rsp),%rbx
  70f553:	cmp    $0x2,%ebx
  70f556:	jne    70f62a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x182a>
  70f55c:	jmp    70f637 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1837>
  70f561:	mov    0x748(%rsp),%rax
  70f569:	mov    0x48(%rsp),%rcx
  70f56e:	mov    %rax,0x30(%rcx)
  70f572:	movups 0x718(%rsp),%xmm0
  70f57a:	movups 0x728(%rsp),%xmm1
  70f582:	movups 0x738(%rsp),%xmm2
  70f58a:	movups %xmm2,0x20(%rcx)
  70f58e:	movups %xmm1,0x10(%rcx)
  70f592:	movups %xmm0,(%rcx)
  70f595:	jmp    70f5bf <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x17bf>
  70f597:	mov    0x48(%rsp),%rax
  70f59c:	movq   $0x22,(%rax)
  70f5a3:	mov    %dl,0x8(%rax)
  70f5a6:	jmp    70f5bf <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x17bf>
  70f5a8:	movzbl 0x761(%rsp),%eax
  70f5b0:	mov    0x48(%rsp),%rcx
  70f5b5:	movq   $0x22,(%rcx)
  70f5bc:	mov    %al,0x8(%rcx)
  70f5bf:	mov    $0x1,%r12b
  70f5c2:	mov    $0x1,%bpl
  70f5c5:	cmpq   $0x0,0x1b0(%rsp)
  70f5ce:	je     70f5dd <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x17dd>
  70f5d0:	mov    0x1b8(%rsp),%rdi
  70f5d8:	call   6c5ca0 <core::ptr::drop_glue::<gpui_canvas::text::TextShaper>>
  70f5dd:	test   %r12b,%r12b
  70f5e0:	je     70f5fa <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x17fa>
  70f5e2:	cmpq   $0xffffffffffffffff,0x160(%rsp)
  70f5eb:	je     70f5fa <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x17fa>
  70f5ed:	lea    0x160(%rsp),%rdi
  70f5f5:	call   6c1730 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  70f5fa:	mov    0x118(%rsp),%rax
  70f602:	test   %rax,%rax
  70f605:	je     70f61b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x181b>
  70f607:	lock decq (%rax)
  70f60b:	jne    70f61b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x181b>
  70f60d:	lea    0x118(%rsp),%rdi
  70f615:	call   *0x3332b5(%rip)        # a428d0 <_DYNAMIC+0x338>
  70f61b:	cmpl   $0x2,0xbd0(%rsp)
  70f623:	je     70f637 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1837>
  70f625:	test   %bpl,%bpl
  70f628:	je     70f637 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1837>
  70f62a:	lea    0xbd0(%rsp),%rdi
  70f632:	call   6c6240 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  70f637:	add    $0xdb8,%rsp
  70f63e:	pop    %rbx
  70f63f:	pop    %r12
  70f641:	pop    %r13
  70f643:	pop    %r14
  70f645:	pop    %r15
  70f647:	pop    %rbp
  70f648:	ret
  70f649:	mov    0x4b0(%rsp),%rax
  70f651:	mov    0x48(%rsp),%rcx
  70f656:	mov    %rax,0x30(%rcx)
  70f65a:	movups 0x480(%rsp),%xmm0
  70f662:	movups 0x490(%rsp),%xmm1
  70f66a:	movups 0x4a0(%rsp),%xmm2
  70f672:	movups %xmm2,0x20(%rcx)
  70f676:	movups %xmm1,0x10(%rcx)
  70f67a:	movups %xmm0,(%rcx)
  70f67d:	jmp    70f1ec <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x13ec>
  70f682:	mov    0x730(%rsp),%rsi
  70f68a:	test   %rsi,%rsi
  70f68d:	je     70f5c5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x17c5>
  70f693:	lea    0x738(%rsp),%rax
  70f69b:	mov    (%rax),%rdi
  70f69e:	mov    $0x1,%edx
  70f6a3:	call   *0x333157(%rip)        # a42800 <_DYNAMIC+0x268>
  70f6a9:	jmp    70f5c5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x17c5>
  70f6ae:	movq   $0xffffffffffffffff,0x760(%rsp)
  70f6ba:	lea    0x630(%r15),%rax
  70f6c1:	mov    (%rax),%rsi
  70f6c4:	test   %rsi,%rsi
  70f6c7:	je     70f73c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x193c>
  70f6c9:	mov    $0x1,%r12b
  70f6cc:	lea    0x480(%rsp),%rdi
  70f6d4:	mov    $0x1,%r14b
  70f6d7:	mov    $0x1,%r15b
  70f6da:	mov    $0x1,%bpl
  70f6dd:	call   *0x33360d(%rip)        # a42cf0 <_DYNAMIC+0x758>
  70f6e3:	mov    0x480(%rsp),%rax
  70f6eb:	mov    0x488(%rsp),%rsi
  70f6f3:	movups 0x490(%rsp),%xmm0
  70f6fb:	movaps %xmm0,0x80(%rsp)
  70f703:	movups 0x4a0(%rsp),%xmm1
  70f70b:	movaps %xmm1,0x8b0(%rsp)
  70f713:	mov    0x4b0(%rsp),%rcx
  70f71b:	mov    %rcx,0x8c0(%rsp)
  70f723:	movaps %xmm0,0x440(%rsp)
  70f72b:	cmp    $0xfffffffffffffffe,%rax
  70f72f:	jne    711612 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3812>
  70f735:	mov    0x38(%rsp),%r15
  70f73a:	jmp    70f743 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1943>
  70f73c:	mov    $0xffffffffffffffff,%rsi
  70f743:	movaps 0x440(%rsp),%xmm0
  70f74b:	movups %xmm0,0x800(%rsp)
  70f753:	mov    %rsi,0x258(%rsp)
  70f75b:	mov    %rsi,0x7f8(%rsp)
  70f763:	cmpb   $0x0,0x2f(%rsp)
  70f768:	je     70f802 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1a02>
  70f76e:	lea    0x480(%rsp),%rdi
  70f776:	lea    0x1e8(%rsp),%rdx
  70f77e:	lea    0x140(%rsp),%rcx
  70f786:	mov    %r15,%rsi
  70f789:	call   6ca780 <gpui::runtime::scroll::geometry::<text_column_public_control::Model>>
  70f78e:	mov    0x480(%rsp),%rax
  70f796:	movups 0x488(%rsp),%xmm0
  70f79e:	movaps %xmm0,0x8b0(%rsp)
  70f7a6:	movups 0x498(%rsp),%xmm0
  70f7ae:	movaps %xmm0,0x8c0(%rsp)
  70f7b6:	movups 0x4a8(%rsp),%xmm0
  70f7be:	movaps %xmm0,0x8d0(%rsp)
  70f7c6:	cmp    $0xfffffffffffffffe,%rax
  70f7ca:	jne    7116cf <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x38cf>
  70f7d0:	movaps 0x8b0(%rsp),%xmm0
  70f7d8:	movaps 0x8c0(%rsp),%xmm1
  70f7e0:	movaps 0x8d0(%rsp),%xmm2
  70f7e8:	movaps %xmm2,0x390(%rsp)
  70f7f0:	movaps %xmm1,0x380(%rsp)
  70f7f8:	movaps %xmm0,0x370(%rsp)
  70f800:	jmp    70f83d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1a3d>
  70f802:	movq   $0x0,0x370(%rsp)
  70f80e:	movq   $0x8,0x378(%rsp)
  70f81a:	xorps  %xmm0,%xmm0
  70f81d:	movups %xmm0,0x380(%rsp)
  70f825:	movq   $0x8,0x390(%rsp)
  70f831:	movq   $0x0,0x398(%rsp)
  70f83d:	lea    0xba8(%rsp),%rdi
  70f845:	mov    %r15,%rsi
  70f848:	call   6f33a0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::inspector_display>
  70f84d:	mov    0x40(%rsp),%rdi
  70f852:	call   *0x3334a0(%rip)        # a42cf8 <_DYNAMIC+0x760>
  70f858:	movzbl 0xba8(%rsp),%eax
  70f860:	movq   $0xffffffffffffffff,0x308(%rsp)
  70f86c:	mov    %al,0x7a(%rsp)
  70f870:	test   %al,%al
  70f872:	je     70f884 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1a84>
  70f874:	mov    0xbb0(%rsp),%rax
  70f87c:	mov    %rax,0x308(%rsp)
  70f884:	cmpl   $0x2,0xbd0(%rsp)
  70f88c:	lea    0xbd0(%rsp),%rsi
  70f894:	cmove  %r15,%rsi
  70f898:	lea    0x8b0(%rsp),%rdi
  70f8a0:	call   *0x33345a(%rip)        # a42d00 <_DYNAMIC+0x768>
  70f8a6:	movups -0x6cf78d(%rip),%xmm0        # 40120 <GCC_except_table0+0x2d8>
  70f8ad:	movaps %xmm0,0x480(%rsp)
  70f8b5:	lea    0x8b0(%rsp),%rdi
  70f8bd:	lea    0x480(%rsp),%rsi
  70f8c5:	call   *0x33343d(%rip)        # a42d08 <_DYNAMIC+0x770>
  70f8cb:	incq   0x760(%r15)
  70f8d2:	lea    0x680(%r15),%rax
  70f8d9:	mov    %rax,0x260(%rsp)
  70f8e1:	mov    0x310(%r15),%rax
  70f8e8:	mov    %rax,0x2b0(%rsp)
  70f8f0:	test   %rax,%rax
  70f8f3:	je     711666 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3866>
  70f8f9:	movss  0x7c(%rsp),%xmm0
  70f8ff:	cvtss2sd %xmm0,%xmm0
  70f903:	movsd  %xmm0,0x7c8(%rsp)
  70f90c:	xorps  %xmm0,%xmm0
  70f90f:	unpcklpd 0x100(%rsp),%xmm0
  70f918:	movaps %xmm0,0x850(%rsp)
  70f920:	xor    %edx,%edx
  70f922:	lea    0x31436f(%rip),%rax        # a23c98 <__frame_dummy_init_array_entry+0x1ca8>
  70f929:	mov    %rax,0x250(%rsp)
  70f931:	lea    0x314378(%rip),%rax        # a23cb0 <__frame_dummy_init_array_entry+0x1cc0>
  70f938:	mov    %rax,0x70(%rsp)
  70f93d:	movabs $0x8000000000000000,%rax
  70f947:	inc    %rax
  70f94a:	mov    %rax,0x7c0(%rsp)
  70f952:	lea    0x3143b7(%rip),%rax        # a23d10 <__frame_dummy_init_array_entry+0x1d20>
  70f959:	mov    %rax,0x2f8(%rsp)
  70f961:	movq   $0x0,0x178(%rsp)
  70f96d:	lea    0x0(,%rdx,8),%rax
  70f975:	lea    (%rax,%rax,4),%r13
  70f979:	imul   $0x58,%rdx,%rax
  70f97d:	mov    %rax,0x300(%rsp)
  70f985:	mov    %rdx,%rsi
  70f988:	shl    $0x4,%rsi
  70f98c:	jmp    70f9dc <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1bdc>
  70f98e:	mov    0x148(%rsp),%rax
  70f996:	mov    %ebx,(%rax,%r14,4)
  70f99a:	inc    %r14
  70f99d:	mov    %r14,0x150(%rsp)
  70f9a5:	add    $0x28,%r13
  70f9a9:	addq   $0x58,0x300(%rsp)
  70f9b2:	mov    0x7e0(%rsp),%rsi
  70f9ba:	add    $0x10,%rsi
  70f9be:	mov    0x7d8(%rsp),%rax
  70f9c6:	mov    %rax,%rdx
  70f9c9:	cmp    0x2b0(%rsp),%rax
  70f9d1:	mov    0x38(%rsp),%r15
  70f9d6:	jae    711672 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3872>
  70f9dc:	cmp    %rdx,0x308(%rsp)
  70f9e4:	mov    %rdx,0x50(%rsp)
  70f9e9:	jne    70fa71 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1c71>
  70f9ef:	cmpb   $0x0,0x7a(%rsp)
  70f9f4:	je     71294a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b4a>
  70f9fa:	mov    %rsi,%rbx
  70f9fd:	mov    0x1c8(%rsp),%rdx
  70fa05:	mov    0x1d0(%rsp),%rcx
  70fa0d:	mov    0x280(%rsp),%r8
  70fa15:	mov    0x288(%rsp),%r9
  70fa1d:	movups 0x320(%r15),%xmm0
  70fa25:	movups 0x5d0(%r15),%xmm1
  70fa2d:	movups %xmm1,0x18(%rsp)
  70fa32:	mov    0x58(%rsp),%rax
  70fa37:	mov    %rax,0x10(%rsp)
  70fa3c:	movups %xmm0,(%rsp)
  70fa40:	lea    0x480(%rsp),%rdi
  70fa48:	lea    0xbb0(%rsp),%rsi
  70fa50:	call   *0x3332ba(%rip)        # a42d10 <_DYNAMIC+0x778>
  70fa56:	cmpl   $0xfffffffe,0x480(%rsp)
  70fa5e:	jne    712585 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4785>
  70fa64:	mov    0x38(%rsp),%r15
  70fa69:	mov    0x50(%rsp),%rdx
  70fa6e:	mov    %rbx,%rsi
  70fa71:	mov    0x5d8(%r15),%rcx
  70fa78:	cmp    %rcx,%rdx
  70fa7b:	jae    712b27 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d27>
  70fa81:	mov    0x5d0(%r15),%rax
  70fa88:	mov    %rsi,0x7e0(%rsp)
  70fa90:	movups (%rax,%rsi,1),%xmm0
  70fa94:	movaps %xmm0,0x80(%rsp)
  70fa9c:	lea    0x480(%rsp),%rdi
  70faa4:	mov    0x58(%rsp),%rsi
  70faa9:	lea    0x80(%rsp),%rdx
  70fab1:	call   *0x332ec9(%rip)        # a42980 <_DYNAMIC+0x3e8>
  70fab7:	cmpb   $0x0,0x480(%rsp)
  70fabf:	jne    71251b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x471b>
  70fac5:	mov    0x50(%rsp),%r9
  70faca:	lea    0x1(%r9),%rax
  70face:	mov    0x38(%rsp),%r8
  70fad3:	mov    0x310(%r8),%rsi
  70fada:	cmp    %rsi,%rax
  70fadd:	mov    %rax,0x7d8(%rsp)
  70fae5:	jae    70fb0f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1d0f>
  70fae7:	mov    0x308(%r8),%rax
  70faee:	mov    0x40(%rax,%r13,1),%eax
  70faf3:	mov    $0xffffffff,%ecx
  70faf8:	cmp    %rcx,%rax
  70fafb:	setne  %cl
  70fafe:	cmp    %rax,%r9
  70fb01:	sete   %al
  70fb04:	and    %cl,%al
  70fb06:	mov    %eax,0x1e4(%rsp)
  70fb0d:	jmp    70fb1a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1d1a>
  70fb0f:	movl   $0x0,0x1e4(%rsp)
  70fb1a:	movsd  0x4c4(%rsp),%xmm0
  70fb23:	movaps %xmm0,0x880(%rsp)
  70fb2b:	movups 0x494(%rsp),%xmm0
  70fb33:	movaps %xmm0,0x870(%rsp)
  70fb3b:	movss  0x498(%rsp),%xmm0
  70fb44:	movss  %xmm0,0xe0(%rsp)
  70fb4d:	movups 0x4a4(%rsp),%xmm0
  70fb55:	movaps %xmm0,0x2d0(%rsp)
  70fb5d:	movss  0x4ac(%rsp),%xmm0
  70fb66:	movaps %xmm0,0x750(%rsp)
  70fb6e:	movss  0x4a8(%rsp),%xmm0
  70fb77:	movss  %xmm0,0x2cc(%rsp)
  70fb80:	movsd  0x4cc(%rsp),%xmm0
  70fb89:	movaps %xmm0,0x360(%rsp)
  70fb91:	movsd  0x4d4(%rsp),%xmm0
  70fb9a:	movaps %xmm0,0x860(%rsp)
  70fba2:	mov    0x40(%rsp),%rax
  70fba7:	mov    (%rax),%rax
  70fbaa:	lea    -0x6cde15(%rip),%rcx        # 41d9c <GCC_except_table0+0x1f54>
  70fbb1:	movslq (%rcx,%rax,4),%rax
  70fbb5:	add    %rcx,%rax
  70fbb8:	jmp    *%rax
  70fbba:	movups -0x6c295d(%rip),%xmm0        # 4d264 <GCC_except_table0+0xd41c>
  70fbc1:	movaps %xmm0,0x4c0(%rsp)
  70fbc9:	movups -0x6c297c(%rip),%xmm0        # 4d254 <GCC_except_table0+0xd40c>
  70fbd0:	movaps %xmm0,0x4b0(%rsp)
  70fbd8:	movups -0x6c299b(%rip),%xmm0        # 4d244 <GCC_except_table0+0xd3fc>
  70fbdf:	movaps %xmm0,0x4a0(%rsp)
  70fbe7:	movups -0x6c29ba(%rip),%xmm0        # 4d234 <GCC_except_table0+0xd3ec>
  70fbee:	movaps %xmm0,0x490(%rsp)
  70fbf6:	movups -0x6c29d9(%rip),%xmm0        # 4d224 <GCC_except_table0+0xd3dc>
  70fbfd:	movaps %xmm0,0x480(%rsp)
  70fc05:	movabs $0x3000100000000,%rax
  70fc0f:	mov    %rax,0x4d0(%rsp)
  70fc17:	jmp    70fd1c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1f1c>
  70fc1c:	mov    0x220(%r8),%rcx
  70fc23:	cmp    %rcx,%r9
  70fc26:	jae    712ada <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4cda>
  70fc2c:	mov    0x210(%r8),%rcx
  70fc33:	mov    0x218(%r8),%rax
  70fc3a:	movzbl (%rax,%r9,1),%eax
  70fc3f:	cmp    %rax,%rcx
  70fc42:	jbe    712ae3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4ce3>
  70fc48:	mov    0x208(%r8),%rcx
  70fc4f:	imul   $0x58,%rax,%rax
  70fc53:	mov    0x50(%rcx,%rax,1),%rdx
  70fc58:	mov    %rdx,0x4d0(%rsp)
  70fc60:	movups 0x40(%rcx,%rax,1),%xmm0
  70fc65:	movaps %xmm0,0x4c0(%rsp)
  70fc6d:	movups (%rcx,%rax,1),%xmm0
  70fc71:	movups 0x10(%rcx,%rax,1),%xmm1
  70fc76:	movups 0x20(%rcx,%rax,1),%xmm2
  70fc7b:	movupd 0x30(%rcx,%rax,1),%xmm3
  70fc81:	jmp    70fcfb <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1efb>
  70fc83:	mov    0x208(%r8),%rsi
  70fc8a:	lea    0x480(%rsp),%rdi
  70fc92:	mov    %r9,%rdx
  70fc95:	call   *0x332cf5(%rip)        # a42990 <_DYNAMIC+0x3f8>
  70fc9b:	mov    0x38(%rsp),%r8
  70fca0:	mov    0x310(%r8),%rsi
  70fca7:	mov    0x50(%rsp),%r9
  70fcac:	jmp    70fd1c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1f1c>
  70fcae:	mov    0x218(%r8),%rcx
  70fcb5:	cmp    %rcx,%r9
  70fcb8:	jae    712af1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4cf1>
  70fcbe:	mov    0x210(%r8),%rax
  70fcc5:	mov    0x300(%rsp),%rdx
  70fccd:	mov    0x50(%rax,%rdx,1),%rcx
  70fcd2:	mov    %rcx,0x4d0(%rsp)
  70fcda:	movups 0x40(%rax,%rdx,1),%xmm0
  70fcdf:	movaps %xmm0,0x4c0(%rsp)
  70fce7:	movups (%rax,%rdx,1),%xmm0
  70fceb:	movups 0x10(%rax,%rdx,1),%xmm1
  70fcf0:	movups 0x20(%rax,%rdx,1),%xmm2
  70fcf5:	movupd 0x30(%rax,%rdx,1),%xmm3
  70fcfb:	movapd %xmm3,0x4b0(%rsp)
  70fd04:	movaps %xmm2,0x4a0(%rsp)
  70fd0c:	movaps %xmm1,0x490(%rsp)
  70fd14:	movaps %xmm0,0x480(%rsp)
  70fd1c:	cmp    %rsi,%r9
  70fd1f:	jae    712a61 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c61>
  70fd25:	mov    0x308(%r8),%rdi
  70fd2c:	mov    0x18(%rdi,%r13,1),%edx
  70fd31:	mov    $0xffffffff,%eax
  70fd36:	cmp    %rax,%rdx
  70fd39:	je     70fd5a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1f5a>
  70fd3b:	call   6db360 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#13}>
  70fd40:	mov    %eax,0xf4(%rsp)
  70fd47:	mov    0x38(%rsp),%r8
  70fd4c:	mov    0x310(%r8),%rsi
  70fd53:	mov    0x50(%rsp),%r9
  70fd58:	jmp    70fd65 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1f65>
  70fd5a:	movl   $0x0,0xf4(%rsp)
  70fd65:	cmp    %rsi,%r9
  70fd68:	jae    712a70 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c70>
  70fd6e:	mov    0x308(%r8),%rax
  70fd75:	mov    0x18(%rax,%r13,1),%ebx
  70fd7a:	mov    $0xffffffff,%ecx
  70fd7f:	cmp    %rcx,%rbx
  70fd82:	je     70fd9d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1f9d>
  70fd84:	cmp    %rbx,%rsi
  70fd87:	jbe    712a8e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c8e>
  70fd8d:	lea    (%rbx,%rbx,4),%rcx
  70fd91:	mov    (%rax,%rcx,8),%rcx
  70fd95:	mov    %rcx,0x7d0(%rsp)
  70fd9d:	mov    0x260(%rsp),%rcx
  70fda5:	mov    (%rcx),%rcx
  70fda8:	xorps  %xmm0,%xmm0
  70fdab:	movss  %xmm0,0xdc(%rsp)
  70fdb4:	test   %rcx,%rcx
  70fdb7:	je     70fde9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1fe9>
  70fdb9:	mov    0x100(%rcx),%rdi
  70fdc0:	test   %rdi,%rdi
  70fdc3:	je     70fde9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1fe9>
  70fdc5:	mov    (%rax,%r13,1),%rsi
  70fdc9:	call   *0x332eb9(%rip)        # a42c88 <_DYNAMIC+0x6f0>
  70fdcf:	movss  %xmm0,0xdc(%rsp)
  70fdd8:	mov    0x38(%rsp),%r8
  70fddd:	mov    0x310(%r8),%rsi
  70fde4:	mov    0x50(%rsp),%r9
  70fde9:	cmp    %rsi,%r9
  70fdec:	jae    712a7f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c7f>
  70fdf2:	mov    0x308(%r8),%rax
  70fdf9:	mov    %rax,0x30(%rsp)
  70fdfe:	mov    0x18(%rax,%r13,1),%eax
  70fe03:	mov    $0xffffffff,%ecx
  70fe08:	cmp    %rcx,%rax
  70fe0b:	je     70ff27 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2127>
  70fe11:	mov    0x1f8(%rsp),%rcx
  70fe19:	cmp    %rax,%rcx
  70fe1c:	jbe    712aa2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4ca2>
  70fe22:	imul   $0x38,%rax,%rax
  70fe26:	mov    0x1f0(%rsp),%rcx
  70fe2e:	movups (%rcx,%rax,1),%xmm0
  70fe32:	movaps %xmm0,0x60(%rsp)
  70fe37:	movups 0x10(%rcx,%rax,1),%xmm0
  70fe3c:	movaps %xmm0,0x200(%rsp)
  70fe44:	movups 0x20(%rcx,%rax,1),%xmm0
  70fe49:	movaps %xmm0,0x350(%rsp)
  70fe51:	movzbl 0x30(%rcx,%rax,1),%ebp
  70fe56:	mov    0x31(%rcx,%rax,1),%edx
  70fe5a:	mov    %edx,0xc0(%rsp)
  70fe61:	mov    0x34(%rcx,%rax,1),%eax
  70fe65:	mov    %eax,0xc3(%rsp)
  70fe6c:	cmp    $0xffffffff,%ebx
  70fe6f:	je     71285c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4a5c>
  70fe75:	lea    0x80(%rsp),%rdi
  70fe7d:	lea    0x370(%rsp),%rsi
  70fe85:	mov    0x7d0(%rsp),%rdx
  70fe8d:	call   *0x332e85(%rip)        # a42d18 <_DYNAMIC+0x780>
  70fe93:	cmpl   $0x1,0x80(%rsp)
  70fe9b:	jne    70ff5b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x215b>
  70fea1:	movq   0x88(%rsp),%xmm0
  70feaa:	movq   0x90(%rsp),%xmm1
  70feb3:	movq   %xmm0,%rax
  70feb8:	movq   %xmm1,%rcx
  70febd:	movabs $0x7fffffffffffffff,%rdx
  70fec7:	and    %rdx,%rax
  70feca:	movabs $0x7fefffffffffffff,%rsi
  70fed4:	cmp    %rsi,%rax
  70fed7:	setg   %al
  70feda:	and    %rdx,%rcx
  70fedd:	cmp    %rsi,%rcx
  70fee0:	setg   %cl
  70fee3:	or     %al,%cl
  70fee5:	or     %bpl,%cl
  70fee8:	and    $0x1,%cl
  70feeb:	punpcklqdq %xmm1,%xmm1
  70feef:	pxor   -0x6cebb7(%rip),%xmm1        # 41340 <GCC_except_table0+0x14f8>
  70fef7:	movapd 0x200(%rsp),%xmm3
  70ff00:	mulpd  %xmm3,%xmm1
  70ff04:	punpcklqdq %xmm0,%xmm0
  70ff08:	movapd 0x60(%rsp),%xmm2
  70ff0e:	mulpd  %xmm2,%xmm0
  70ff12:	subpd  %xmm0,%xmm1
  70ff16:	movapd 0x350(%rsp),%xmm0
  70ff1f:	addpd  %xmm1,%xmm0
  70ff23:	mov    %ecx,%ebp
  70ff25:	jmp    70ff8e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x218e>
  70ff27:	movsd  0x7c8(%rsp),%xmm0
  70ff30:	movsd  %xmm0,0x440(%rsp)
  70ff39:	lea    0x471(%rsp),%rax
  70ff41:	xorps  %xmm1,%xmm1
  70ff44:	movups %xmm1,-0x29(%rax)
  70ff48:	movsd  %xmm0,0x458(%rsp)
  70ff51:	movaps %xmm1,-0x11(%rax)
  70ff55:	movb   $0x0,-0x1(%rax)
  70ff59:	jmp    70ffb1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x21b1>
  70ff5b:	mov    0xc0(%rsp),%eax
  70ff62:	mov    0xc3(%rsp),%ecx
  70ff69:	lea    0x471(%rsp),%rdx
  70ff71:	mov    %ecx,0x3(%rdx)
  70ff74:	mov    %eax,(%rdx)
  70ff76:	movapd 0x60(%rsp),%xmm2
  70ff7c:	movapd 0x200(%rsp),%xmm3
  70ff85:	movapd 0x350(%rsp),%xmm0
  70ff8e:	movapd %xmm2,0x440(%rsp)
  70ff97:	movapd %xmm3,0x450(%rsp)
  70ffa0:	movapd %xmm0,0x460(%rsp)
  70ffa9:	mov    %bpl,0x470(%rsp)
  70ffb1:	movaps -0x6ce968(%rip),%xmm0        # 41650 <GCC_except_table0+0x1808>
  70ffb8:	movaps %xmm0,0xc0(%rsp)
  70ffc0:	movaps 0x880(%rsp),%xmm0
  70ffc8:	movlps %xmm0,0xd0(%rsp)
  70ffd0:	lea    0x80(%rsp),%rdi
  70ffd8:	lea    0x440(%rsp),%rsi
  70ffe0:	lea    0xc0(%rsp),%rdx
  70ffe8:	call   *0x33299a(%rip)        # a42988 <_DYNAMIC+0x3f0>
  70ffee:	lea    0xae0(%rsp),%rdi
  70fff6:	lea    0x80(%rsp),%rsi
  70fffe:	lea    0x4bc(%rsp),%rdx
  710006:	call   *0x33297c(%rip)        # a42988 <_DYNAMIC+0x3f0>
  71000c:	mov    0x1f8(%rsp),%rbx
  710014:	cmp    0x1e8(%rsp),%rbx
  71001c:	jne    71002b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x222b>
  71001e:	lea    0x1e8(%rsp),%rdi
  710026:	call   6f4c50 <<alloc::raw_vec::RawVec<gpui::semantic::AnnotationDraft>>::grow_one>
  71002b:	mov    0x1f0(%rsp),%rax
  710033:	imul   $0x38,%rbx,%rcx
  710037:	mov    0xb10(%rsp),%rdx
  71003f:	mov    %rdx,0x30(%rax,%rcx,1)
  710044:	movups 0xae0(%rsp),%xmm0
  71004c:	movups 0xaf0(%rsp),%xmm1
  710054:	movups 0xb00(%rsp),%xmm2
  71005c:	movups %xmm2,0x20(%rax,%rcx,1)
  710061:	movups %xmm1,0x10(%rax,%rcx,1)
  710066:	movups %xmm0,(%rax,%rcx,1)
  71006a:	inc    %rbx
  71006d:	mov    %rbx,0x1f8(%rsp)
  710075:	movups 0xae0(%rsp),%xmm0
  71007d:	movaps %xmm0,0x200(%rsp)
  710085:	movups 0xaf0(%rsp),%xmm0
  71008d:	movaps %xmm0,0x350(%rsp)
  710095:	movups 0xb00(%rsp),%xmm0
  71009d:	movaps %xmm0,0x60(%rsp)
  7100a2:	lea    0xae0(%rsp),%rdi
  7100aa:	call   *0x332c70(%rip)        # a42d20 <_DYNAMIC+0x788>
  7100b0:	xor    %ebx,%ebx
  7100b2:	test   %al,%al
  7100b4:	je     7101df <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x23df>
  7100ba:	cvtpd2ps 0x350(%rsp),%xmm0
  7100c3:	cvtpd2ps 0x200(%rsp),%xmm1
  7100cc:	cvtpd2ps 0x60(%rsp),%xmm2
  7100d2:	unpcklpd %xmm0,%xmm1
  7100d6:	movd   %xmm1,%eax
  7100da:	and    $0x7fffffff,%eax
  7100df:	movapd %xmm1,%xmm0
  7100e3:	shufps $0x55,%xmm1,%xmm0
  7100e7:	movd   %xmm0,%ecx
  7100eb:	and    $0x7fffffff,%ecx
  7100f1:	cmp    $0x7f800000,%ecx
  7100f7:	setge  %cl
  7100fa:	movdqa %xmm1,%xmm0
  7100fe:	punpckhqdq %xmm1,%xmm0
  710102:	movd   %xmm0,%edx
  710106:	and    $0x7fffffff,%edx
  71010c:	cmp    $0x7f800000,%edx
  710112:	setge  %dl
  710115:	movaps %xmm1,%xmm0
  710118:	shufps $0xff,%xmm1,%xmm0
  71011c:	movd   %xmm0,%esi
  710120:	and    $0x7fffffff,%esi
  710126:	cmp    $0x7f800000,%esi
  71012c:	setge  %sil
  710130:	movd   %xmm2,%edi
  710134:	and    $0x7fffffff,%edi
  71013a:	cmp    $0x7f800000,%edi
  710140:	setge  %dil
  710144:	movapd %xmm2,%xmm0
  710148:	shufps $0x55,%xmm2,%xmm0
  71014c:	movd   %xmm0,%r8d
  710151:	and    $0x7fffffff,%r8d
  710158:	cmp    $0x7f800000,%r8d
  71015f:	setl   %r8b
  710163:	cmp    $0x7f7fffff,%eax
  710168:	mov    0x30(%rsp),%r9
  71016d:	jg     7101e4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x23e4>
  71016f:	test   %cl,%cl
  710171:	jne    7101e4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x23e4>
  710173:	test   %dl,%dl
  710175:	jne    7101e4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x23e4>
  710177:	test   %sil,%sil
  71017a:	jne    7101e4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x23e4>
  71017c:	test   %dil,%dil
  71017f:	jne    7101e4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x23e4>
  710181:	test   %r8b,%r8b
  710184:	je     7101e4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x23e4>
  710186:	movaps %xmm1,0x60(%rsp)
  71018b:	movaps %xmm1,0x80(%rsp)
  710193:	movaps %xmm2,0x200(%rsp)
  71019b:	movlpd %xmm2,0x90(%rsp)
  7101a4:	lea    0x80(%rsp),%rdi
  7101ac:	call   *0x332b76(%rip)        # a42d28 <_DYNAMIC+0x790>
  7101b2:	test   %al,%al
  7101b4:	mov    0x30(%rsp),%r9
  7101b9:	je     7101e4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x23e4>
  7101bb:	movaps 0x60(%rsp),%xmm0
  7101c0:	movups %xmm0,0x298(%rsp)
  7101c8:	movaps 0x200(%rsp),%xmm0
  7101d0:	movlps %xmm0,0x2a8(%rsp)
  7101d8:	mov    $0x1,%ebx
  7101dd:	jmp    7101e4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x23e4>
  7101df:	mov    0x30(%rsp),%r9
  7101e4:	mov    %ebx,0x294(%rsp)
  7101eb:	xorps  %xmm0,%xmm0
  7101ee:	unpcklpd 0x360(%rsp),%xmm0
  7101f7:	movups %xmm0,0x318(%rsp)
  7101ff:	cmpb   $0x0,0x2f(%rsp)
  710204:	je     710274 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2474>
  710206:	mov    0x18(%r9,%r13,1),%eax
  71020b:	mov    $0xffffffff,%ecx
  710210:	cmp    %rcx,%rax
  710213:	je     71029d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x249d>
  710219:	mov    0x220(%rsp),%rcx
  710221:	cmp    %rax,%rcx
  710224:	jbe    712ab0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4cb0>
  71022a:	mov    0x218(%rsp),%rcx
  710232:	mov    %rax,%rdx
  710235:	shl    $0x4,%rdx
  710239:	movups (%rcx,%rdx,1),%xmm1
  71023d:	xorps  %xmm0,%xmm0
  710240:	unpcklpd 0x100(%rsp),%xmm0
  710249:	movups %xmm0,0x80(%rsp)
  710251:	mov    0x238(%rsp),%rcx
  710259:	cmp    %rax,%rcx
  71025c:	jbe    712abe <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4cbe>
  710262:	movaps %xmm1,0x200(%rsp)
  71026a:	add    0x230(%rsp),%rdx
  710272:	jmp    7102c9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x24c9>
  710274:	xorps  %xmm0,%xmm0
  710277:	unpcklpd 0x100(%rsp),%xmm0
  710280:	movups %xmm0,0x240(%rsp)
  710288:	movl   $0x0,0x60(%rsp)
  710290:	movaps 0x850(%rsp),%xmm0
  710298:	jmp    710340 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2540>
  71029d:	xorps  %xmm0,%xmm0
  7102a0:	unpcklpd 0x100(%rsp),%xmm0
  7102a9:	movups %xmm0,0x80(%rsp)
  7102b1:	lea    0x80(%rsp),%rdx
  7102b9:	movaps 0x850(%rsp),%xmm0
  7102c1:	movaps %xmm0,0x200(%rsp)
  7102c9:	movups (%rdx),%xmm0
  7102cc:	movaps %xmm0,0x240(%rsp)
  7102d4:	mov    0x20(%r9,%r13,1),%edi
  7102d9:	call   6f84b0 <<gpui::runtime::Node>::kind>
  7102de:	mov    $0x1,%cl
  7102e0:	mov    %ecx,0x60(%rsp)
  7102e4:	cmp    $0x7,%al
  7102e6:	jne    7102f7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x24f7>
  7102e8:	mov    0x30(%rsp),%r9
  7102ed:	movaps 0x200(%rsp),%xmm0
  7102f5:	jmp    710340 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2540>
  7102f7:	mov    0x30(%rsp),%r9
  7102fc:	mov    0x18(%r9,%r13,1),%eax
  710301:	mov    $0xffffffff,%ecx
  710306:	cmp    %rcx,%rax
  710309:	movaps 0x200(%rsp),%xmm0
  710311:	je     710338 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2538>
  710313:	mov    0x198(%rsp),%rcx
  71031b:	cmp    %rax,%rcx
  71031e:	jbe    712b08 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d08>
  710324:	mov    0x190(%rsp),%rcx
  71032c:	movzbl (%rcx,%rax,1),%eax
  710330:	and    $0x1,%al
  710332:	mov    %eax,0x60(%rsp)
  710336:	jmp    710340 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2540>
  710338:	movl   $0x0,0x60(%rsp)
  710340:	movaps %xmm0,0x1a0(%rsp)
  710348:	mov    0x20(%r9,%r13,1),%eax
  71034d:	and    $0xf,%eax
  710350:	cmp    $0x7,%eax
  710353:	jb     710361 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2561>
  710355:	lea    -0x8(%rax),%ecx
  710358:	cmp    $0x2,%ecx
  71035b:	jae    710eee <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x30ee>
  710361:	mov    0x18(%r9,%r13,1),%ecx
  710366:	xor    %ebp,%ebp
  710368:	mov    $0xffffffff,%edx
  71036d:	cmp    %rdx,%rcx
  710370:	je     71038f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x258f>
  710372:	cmp    %rcx,0x198(%rsp)
  71037a:	jbe    71038f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x258f>
  71037c:	mov    0x190(%rsp),%rdx
  710384:	movzbl (%rdx,%rcx,1),%ebp
  710388:	and    $0x2,%bpl
  71038c:	shr    $1,%bpl
  71038f:	cmpb   $0x0,0x2f(%rsp)
  710394:	je     7103e5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x25e5>
  710396:	mov    0x198(%rsp),%r14
  71039e:	cmp    0x188(%rsp),%r14
  7103a6:	jne    7103b6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x25b6>
  7103a8:	lea    0x188(%rsp),%rdi
  7103b0:	call   *0x33297a(%rip)        # a42d30 <_DYNAMIC+0x798>
  7103b6:	lea    0x0(,%rbp,2),%eax
  7103bd:	add    0x60(%rsp),%al
  7103c1:	mov    0x190(%rsp),%rcx
  7103c9:	mov    %al,(%rcx,%r14,1)
  7103cd:	inc    %r14
  7103d0:	mov    %r14,0x198(%rsp)
  7103d8:	mov    0x30(%rsp),%rax
  7103dd:	mov    0x20(%rax,%r13,1),%eax
  7103e2:	and    $0xf,%eax
  7103e5:	cmp    $0x9,%eax
  7103e8:	ja     71291d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b1d>
  7103ee:	mov    $0x34f,%ecx
  7103f3:	bt     %eax,%ecx
  7103f6:	jb     71047f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x267f>
  7103fc:	movaps 0x1a0(%rsp),%xmm0
  710404:	movaps %xmm0,0xc0(%rsp)
  71040c:	movups 0x318(%rsp),%xmm0
  710414:	movaps %xmm0,0x80(%rsp)
  71041c:	lea    0x810(%rsp),%rdi
  710424:	lea    0xc0(%rsp),%rsi
  71042c:	lea    0x240(%rsp),%rdx
  710434:	lea    0x294(%rsp),%rcx
  71043c:	lea    0x80(%rsp),%r8
  710444:	mov    0x2c0(%rsp),%r9
  71044c:	call   *0x3328e6(%rip)        # a42d38 <_DYNAMIC+0x7a0>
  710452:	cmpl   $0xfffffffe,0x810(%rsp)
  71045a:	jne    7125be <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x47be>
  710460:	lea    0x818(%rsp),%rax
  710468:	movups (%rax),%xmm0
  71046b:	movaps %xmm0,0x1a0(%rsp)
  710473:	movups 0x10(%rax),%xmm0
  710477:	movaps %xmm0,0x240(%rsp)
  71047f:	cmpb   $0x0,0x2f(%rsp)
  710484:	je     710524 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2724>
  71048a:	movaps 0x1a0(%rsp),%xmm0
  710492:	movaps %xmm0,0x80(%rsp)
  71049a:	mov    0x220(%rsp),%r14
  7104a2:	cmp    0x210(%rsp),%r14
  7104aa:	jne    7104b9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x26b9>
  7104ac:	lea    0x210(%rsp),%rdi
  7104b4:	call   6f4cc0 <<alloc::raw_vec::RawVec<gpui_reactivity_core::geometry::Rect>>::grow_one>
  7104b9:	mov    0x218(%rsp),%rax
  7104c1:	mov    %r14,%rcx
  7104c4:	shl    $0x4,%rcx
  7104c8:	movaps 0x80(%rsp),%xmm0
  7104d0:	movups %xmm0,(%rax,%rcx,1)
  7104d4:	inc    %r14
  7104d7:	mov    %r14,0x220(%rsp)
  7104df:	mov    0x238(%rsp),%r14
  7104e7:	cmp    0x228(%rsp),%r14
  7104ef:	jne    7104fe <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x26fe>
  7104f1:	lea    0x228(%rsp),%rdi
  7104f9:	call   6f4cc0 <<alloc::raw_vec::RawVec<gpui_reactivity_core::geometry::Rect>>::grow_one>
  7104fe:	mov    0x230(%rsp),%rax
  710506:	mov    %r14,%rcx
  710509:	shl    $0x4,%rcx
  71050d:	movaps 0x240(%rsp),%xmm0
  710515:	movups %xmm0,(%rax,%rcx,1)
  710519:	inc    %r14
  71051c:	mov    %r14,0x238(%rsp)
  710524:	test   %ebx,%ebx
  710526:	je     71055c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x275c>
  710528:	lea    0x80(%rsp),%rdi
  710530:	lea    0x318(%rsp),%rsi
  710538:	lea    0x298(%rsp),%rdx
  710540:	call   6db480 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#24}>
  710545:	cmpl   $0x1,0x80(%rsp)
  71054d:	jne    71055c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x275c>
  71054f:	lea    0x84(%rsp),%rax
  710557:	movups (%rax),%xmm0
  71055a:	jmp    71055f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x275f>
  71055c:	xorps  %xmm0,%xmm0
  71055f:	movaps %xmm0,0x3a0(%rsp)
  710567:	mov    0x60(%rsp),%eax
  71056b:	or     %bpl,%al
  71056e:	cmp    $0x1,%al
  710570:	je     710585 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2785>
  710572:	mov    0x30(%rsp),%rax
  710577:	mov    0x20(%rax,%r13,1),%edi
  71057c:	call   6f84b0 <<gpui::runtime::Node>::kind>
  710581:	cmp    $0x6,%al
  710583:	jne    7105a5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x27a5>
  710585:	lea    0x268(%rsp),%rdi
  71058d:	lea    0x3a0(%rsp),%rsi
  710595:	lea    0x240(%rsp),%rdx
  71059d:	call   *0x33279d(%rip)        # a42d40 <_DYNAMIC+0x7a8>
  7105a3:	jmp    710612 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2812>
  7105a5:	movsd  0x3a0(%rsp),%xmm0
  7105ae:	movsd  0x3a8(%rsp),%xmm1
  7105b7:	movaps %xmm0,%xmm2
  7105ba:	addps  %xmm0,%xmm1
  7105bd:	xorps  %xmm4,%xmm4
  7105c0:	maxps  %xmm4,%xmm0
  7105c3:	movaps %xmm0,%xmm3
  7105c6:	cmpunordps %xmm0,%xmm3
  7105ca:	andps  %xmm3,%xmm2
  7105cd:	andnps %xmm0,%xmm3
  7105d0:	orps   %xmm2,%xmm3
  7105d3:	movaps %xmm1,%xmm0
  7105d6:	minps  0x100(%rsp),%xmm0
  7105de:	movaps %xmm0,%xmm2
  7105e1:	cmpunordps %xmm0,%xmm2
  7105e5:	andps  %xmm2,%xmm1
  7105e8:	andnps %xmm0,%xmm2
  7105eb:	orps   %xmm1,%xmm2
  7105ee:	subps  %xmm3,%xmm2
  7105f1:	movaps %xmm2,%xmm0
  7105f4:	maxps  %xmm4,%xmm0
  7105f7:	movaps %xmm0,%xmm1
  7105fa:	cmpunordps %xmm0,%xmm1
  7105fe:	andps  %xmm1,%xmm2
  710601:	andnps %xmm0,%xmm1
  710604:	orps   %xmm2,%xmm1
  710607:	movlhps %xmm1,%xmm3
  71060a:	movups %xmm3,0x268(%rsp)
  710612:	test   %bpl,%bpl
  710615:	mov    0x30(%rsp),%rsi
  71061a:	je     71064a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x284a>
  71061c:	movss  0x270(%rsp),%xmm0
  710625:	xor    %r15d,%r15d
  710628:	xorps  %xmm1,%xmm1
  71062b:	ucomiss %xmm1,%xmm0
  71062e:	jne    710636 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2836>
  710630:	jnp    7108cc <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2acc>
  710636:	movss  0x274(%rsp),%xmm0
  71063f:	ucomiss %xmm1,%xmm0
  710642:	jne    71064a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x284a>
  710644:	jnp    7108cc <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2acc>
  71064a:	mov    0x4b8(%rsp),%eax
  710651:	mov    $0x3fffffff,%ecx
  710656:	and    %ecx,%eax
  710658:	cmp    $0x3f800001,%eax
  71065d:	mov    $0x80000000,%ecx
  710662:	cmove  %ecx,%eax
  710665:	movd   %eax,%xmm0
  710669:	xorps  %xmm1,%xmm1
  71066c:	ucomiss %xmm1,%xmm0
  71066f:	jbe    710755 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2955>
  710675:	movl   $0x1,0x88(%rsp)
  710680:	movq   $0x23,0x80(%rsp)
  71068c:	test   %bl,%bl
  71068e:	je     71198c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3b8c>
  710694:	lea    0x80(%rsp),%rbx
  71069c:	mov    %rbx,%rdi
  71069f:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  7106a4:	lea    0x298(%rsp),%rax
  7106ac:	movups (%rax),%xmm0
  7106af:	movaps %xmm0,0xaa0(%rsp)
  7106b7:	mov    0x10(%rax),%rax
  7106bb:	mov    %rax,0xab0(%rsp)
  7106c3:	mov    %rbx,%rdi
  7106c6:	mov    0x40(%rsp),%rsi
  7106cb:	mov    0x50(%rsp),%rdx
  7106d0:	xor    %ecx,%ecx
  7106d2:	call   *0x332670(%rip)        # a42d48 <_DYNAMIC+0x7b0>
  7106d8:	mov    0x90(%rsp),%r9
  7106e0:	test   %r9,%r9
  7106e3:	je     710850 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2a50>
  7106e9:	movups 0x80(%rsp),%xmm0
  7106f1:	movaps %xmm0,0x2e0(%rsp)
  7106f9:	movaps 0x1a0(%rsp),%xmm0
  710701:	movaps %xmm0,0x120(%rsp)
  710709:	movups 0x318(%rsp),%xmm0
  710711:	movaps %xmm0,0xc0(%rsp)
  710719:	lea    0x8b0(%rsp),%rdi
  710721:	lea    0xc0(%rsp),%rsi
  710729:	movss  0xdc(%rsp),%xmm0
  710732:	lea    0xaa0(%rsp),%rdx
  71073a:	lea    0x120(%rsp),%rcx
  710742:	lea    0x2e0(%rsp),%r8
  71074a:	call   *0x332600(%rip)        # a42d50 <_DYNAMIC+0x7b8>
  710750:	jmp    71083d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2a3d>
  710755:	cmpq   $0x0,0x8(%rsi,%r13,1)
  71075b:	jne    710777 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2977>
  71075d:	mov    0x20(%rsi,%r13,1),%edi
  710762:	call   6f84b0 <<gpui::runtime::Node>::kind>
  710767:	mov    $0x1,%r15b
  71076a:	cmp    $0x4,%al
  71076c:	mov    0x30(%rsp),%rsi
  710771:	jne    7108cc <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2acc>
  710777:	movl   $0x1,0x88(%rsp)
  710782:	movq   $0x23,0x80(%rsp)
  71078e:	test   %bl,%bl
  710790:	je     71198c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3b8c>
  710796:	lea    0x80(%rsp),%rbx
  71079e:	mov    %rbx,%rdi
  7107a1:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  7107a6:	lea    0x298(%rsp),%rcx
  7107ae:	movups (%rcx),%xmm0
  7107b1:	movaps %xmm0,0x120(%rsp)
  7107b9:	mov    0x10(%rcx),%rax
  7107bd:	mov    %rax,0x130(%rsp)
  7107c5:	movups (%rcx),%xmm0
  7107c8:	movaps %xmm0,0xb50(%rsp)
  7107d0:	mov    0x10(%rcx),%rax
  7107d4:	mov    %rax,0xb60(%rsp)
  7107dc:	movaps 0x1a0(%rsp),%xmm0
  7107e4:	movaps %xmm0,0x2e0(%rsp)
  7107ec:	movups 0x318(%rsp),%xmm0
  7107f4:	movaps %xmm0,0xc0(%rsp)
  7107fc:	movups -0x6cf323(%rip),%xmm0        # 414e0 <GCC_except_table0+0x1698>
  710803:	movaps %xmm0,0x80(%rsp)
  71080b:	lea    0x8b0(%rsp),%rdi
  710813:	lea    0xc0(%rsp),%rsi
  71081b:	movss  0xdc(%rsp),%xmm0
  710824:	lea    0xb50(%rsp),%rdx
  71082c:	lea    0x2e0(%rsp),%rcx
  710834:	mov    %rbx,%r8
  710837:	call   *0x33251b(%rip)        # a42d58 <_DYNAMIC+0x7c0>
  71083d:	cmp    $0xffffffff,%eax
  710840:	jne    7119c5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3bc5>
  710846:	mov    $0x1,%r15b
  710849:	mov    0x30(%rsp),%rsi
  71084e:	jmp    7108cc <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2acc>
  710850:	movaps 0x1a0(%rsp),%xmm0
  710858:	movaps %xmm0,0x120(%rsp)
  710860:	lea    0x4bc(%rsp),%rax
  710868:	movups -0x10(%rax),%xmm0
  71086c:	movaps %xmm0,0xc0(%rsp)
  710874:	movups 0x318(%rsp),%xmm0
  71087c:	movaps %xmm0,0x80(%rsp)
  710884:	lea    0x8b0(%rsp),%rdi
  71088c:	lea    0x80(%rsp),%rsi
  710894:	movss  0xdc(%rsp),%xmm0
  71089d:	lea    0xaa0(%rsp),%rdx
  7108a5:	lea    0x120(%rsp),%rcx
  7108ad:	lea    0xc0(%rsp),%r8
  7108b5:	call   *0x33249d(%rip)        # a42d58 <_DYNAMIC+0x7c0>
  7108bb:	mov    $0x1,%r15b
  7108be:	cmp    $0xffffffff,%eax
  7108c1:	mov    0x30(%rsp),%rsi
  7108c6:	jne    7119c5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3bc5>
  7108cc:	mov    0x20(%rsi,%r13,1),%edi
  7108d1:	mov    %edi,%eax
  7108d3:	and    $0xf,%eax
  7108d6:	cmp    $0x9,%eax
  7108d9:	ja     71291d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b1d>
  7108df:	cmp    $0x6,%eax
  7108e2:	je     710eff <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x30ff>
  7108e8:	shr    $0x4,%edi
  7108eb:	dec    %edi
  7108ed:	mov    0x38(%rsp),%rax
  7108f2:	mov    0x320(%rax),%rsi
  7108f9:	mov    0x328(%rax),%rdx
  710900:	call   6f83a0 <<gpui::runtime::TextSlot>::get_mut>
  710905:	test   %rax,%rax
  710908:	je     710ccf <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2ecf>
  71090e:	lea    0x4bc(%rsp),%rcx
  710916:	movups -0x20(%rcx),%xmm0
  71091a:	movaps %xmm0,0x8a0(%rsp)
  710922:	mov    0x38(%rsp),%rcx
  710927:	mov    0x708(%rcx),%rbx
  71092e:	test   %rbx,%rbx
  710931:	mov    0x30(%rsp),%rdx
  710936:	je     712889 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4a89>
  71093c:	cmpq   $0x0,0x30(%rbx)
  710941:	je     712889 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4a89>
  710947:	movzbl 0x43c(%rsp),%ecx
  71094f:	mov    $0x2,%r12b
  710952:	cmp    $0x2,%cl
  710955:	je     7109c5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2bc5>
  710957:	mov    (%rdx,%r13,1),%rdx
  71095b:	cmp    %rdx,0x428(%rsp)
  710963:	jne    7109c5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2bc5>
  710965:	mov    0x438(%rsp),%edx
  71096c:	mov    %edx,0x1dc(%rsp)
  710973:	movzbl 0x434(%rsp),%edx
  71097b:	mov    %dl,0x79(%rsp)
  71097f:	mov    0x430(%rsp),%edx
  710986:	mov    %edx,0x158(%rsp)
  71098d:	lea    0x435(%rsp),%rsi
  710995:	movzwl (%rsi),%edx
  710998:	mov    %dx,0xf0(%rsp)
  7109a0:	movzbl 0x2(%rsi),%edx
  7109a4:	mov    %dl,0xf2(%rsp)
  7109ab:	movzwl 0x8(%rsi),%edx
  7109af:	mov    %dx,0xec(%rsp)
  7109b7:	movzbl 0xa(%rsi),%edx
  7109bb:	mov    %dl,0xee(%rsp)
  7109c2:	mov    %ecx,%r12d
  7109c5:	cmpq   $0x0,0x1b0(%rsp)
  7109ce:	je     71287a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4a7a>
  7109d4:	movss  0x498(%rsp),%xmm0
  7109dd:	movaps 0x360(%rsp),%xmm1
  7109e5:	subss  0x2d0(%rsp),%xmm1
  7109ee:	subss  0x2cc(%rsp),%xmm1
  7109f7:	subss  0x870(%rsp),%xmm1
  710a00:	subss  0xe0(%rsp),%xmm1
  710a09:	subss  0x860(%rsp),%xmm1
  710a12:	lea    0x80(%rsp),%rdi
  710a1a:	mov    %rax,%rsi
  710a1d:	lea    0x1b0(%rsp),%rdx
  710a25:	mov    $0x1,%ecx
  710a2a:	mov    $0x1,%r8d
  710a30:	call   *0x331fca(%rip)        # a42a00 <_DYNAMIC+0x468>
  710a36:	mov    0x80(%rsp),%rax
  710a3e:	mov    0x88(%rsp),%rcx
  710a46:	mov    %rcx,0xe0(%rsp)
  710a4e:	cmp    $0xfffffffffffffffe,%rax
  710a52:	jne    712548 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4748>
  710a58:	movaps 0x2d0(%rsp),%xmm0
  710a60:	movss  %xmm0,0xf8(%rsp)
  710a69:	movaps 0x750(%rsp),%xmm1
  710a71:	movss  %xmm1,0xfc(%rsp)
  710a7a:	test   %r15b,%r15b
  710a7d:	je     710ce5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2ee5>
  710a83:	testb  $0x1,0x294(%rsp)
  710a8b:	movl   $0x1,0x88(%rsp)
  710a96:	movq   $0x23,0x80(%rsp)
  710aa2:	je     71198c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3b8c>
  710aa8:	lea    0x80(%rsp),%rdi
  710ab0:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  710ab5:	lea    0x298(%rsp),%rcx
  710abd:	movups (%rcx),%xmm0
  710ac0:	movaps %xmm0,0xac0(%rsp)
  710ac8:	mov    0x10(%rcx),%rax
  710acc:	mov    %rax,0xad0(%rsp)
  710ad4:	movups (%rcx),%xmm0
  710ad7:	movaps %xmm0,0x2e0(%rsp)
  710adf:	mov    0x10(%rcx),%rax
  710ae3:	mov    %rax,0x2f0(%rsp)
  710aeb:	cmp    $0x2,%r12b
  710aef:	je     710bfe <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2dfe>
  710af5:	mov    0x158(%rsp),%eax
  710afc:	mov    %eax,0xc0(%rsp)
  710b03:	movzbl 0x79(%rsp),%eax
  710b08:	mov    %al,0xc4(%rsp)
  710b0f:	movzbl 0xf2(%rsp),%eax
  710b17:	lea    0xc5(%rsp),%rcx
  710b1f:	mov    %al,0x2(%rcx)
  710b22:	movzwl 0xf0(%rsp),%eax
  710b2a:	mov    %ax,(%rcx)
  710b2d:	mov    0x1dc(%rsp),%eax
  710b34:	mov    %eax,0xc8(%rsp)
  710b3b:	mov    %r12b,0xcc(%rsp)
  710b43:	movzbl 0xee(%rsp),%eax
  710b4b:	mov    %al,0xa(%rcx)
  710b4e:	movzwl 0xec(%rsp),%eax
  710b56:	mov    %ax,0x8(%rcx)
  710b5a:	movl   $0xffffffff,0x120(%rsp)
  710b65:	lea    0x120(%rsp),%rax
  710b6d:	mov    %rax,0x80(%rsp)
  710b75:	lea    0x8b0(%rsp),%rax
  710b7d:	mov    %rax,0x88(%rsp)
  710b85:	lea    0xf8(%rsp),%rax
  710b8d:	mov    %rax,0x90(%rsp)
  710b95:	lea    0xfc(%rsp),%rax
  710b9d:	mov    %rax,0x98(%rsp)
  710ba5:	lea    0x2e0(%rsp),%rax
  710bad:	mov    %rax,0xa0(%rsp)
  710bb5:	lea    0x1a0(%rsp),%rax
  710bbd:	mov    %rax,0xa8(%rsp)
  710bc5:	mov    0xe0(%rsp),%rax
  710bcd:	mov    0x20(%rax),%rdi
  710bd1:	lea    0xc0(%rsp),%rsi
  710bd9:	lea    0x80(%rsp),%rdx
  710be1:	call   6b8220 <<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#28}>>
  710be6:	test   %al,%al
  710be8:	je     71265e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x485e>
  710bee:	mov    0x120(%rsp),%eax
  710bf5:	cmp    $0xffffffff,%eax
  710bf8:	jne    71266c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x486c>
  710bfe:	lea    0xc0(%rsp),%rdi
  710c06:	mov    0x40(%rsp),%rsi
  710c0b:	mov    0x50(%rsp),%rdx
  710c10:	mov    $0x1,%ecx
  710c15:	call   *0x33212d(%rip)        # a42d48 <_DYNAMIC+0x7b0>
  710c1b:	add    $0x30,%rbx
  710c1f:	mov    0xd0(%rsp),%rax
  710c27:	test   %rax,%rax
  710c2a:	je     710d00 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2f00>
  710c30:	movups 0xc0(%rsp),%xmm0
  710c38:	movaps %xmm0,0x3b0(%rsp)
  710c40:	movaps 0x1a0(%rsp),%xmm0
  710c48:	movaps %xmm0,0x120(%rsp)
  710c50:	movss  0xf8(%rsp),%xmm0
  710c59:	movss  0xfc(%rsp),%xmm1
  710c62:	lea    0x298(%rsp),%rdx
  710c6a:	mov    0x10(%rdx),%rcx
  710c6e:	mov    %rcx,0x90(%rsp)
  710c76:	movups (%rdx),%xmm2
  710c79:	movaps %xmm2,0x80(%rsp)
  710c81:	mov    %rax,(%rsp)
  710c85:	lea    0x8b0(%rsp),%rdi
  710c8d:	mov    %rbx,%rsi
  710c90:	mov    0xe0(%rsp),%rdx
  710c98:	lea    0x80(%rsp),%rcx
  710ca0:	lea    0x120(%rsp),%r8
  710ca8:	lea    0x3b0(%rsp),%r9
  710cb0:	movss  0x7c(%rsp),%xmm2
  710cb6:	call   *0x3320a4(%rip)        # a42d60 <_DYNAMIC+0x7c8>
  710cbc:	cmp    $0xffffffff,%eax
  710cbf:	jne    7119c5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3bc5>
  710cc5:	mov    0x30(%rsp),%rsi
  710cca:	jmp    710d96 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2f96>
  710ccf:	movq   $0x0,0xe0(%rsp)
  710cdb:	mov    0x30(%rsp),%rsi
  710ce0:	jmp    710f79 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3179>
  710ce5:	movss  %xmm0,0x1e0(%rsp)
  710cee:	mov    0x30(%rsp),%rsi
  710cf3:	movaps 0x750(%rsp),%xmm0
  710cfb:	jmp    710f70 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3170>
  710d00:	movaps 0x1a0(%rsp),%xmm0
  710d08:	movaps %xmm0,0x120(%rsp)
  710d10:	movss  0xf8(%rsp),%xmm0
  710d19:	movss  0xfc(%rsp),%xmm1
  710d22:	lea    0x298(%rsp),%rcx
  710d2a:	mov    0x10(%rcx),%rax
  710d2e:	mov    %rax,0x90(%rsp)
  710d36:	movups (%rcx),%xmm2
  710d39:	movaps %xmm2,0x80(%rsp)
  710d41:	movaps 0x8a0(%rsp),%xmm2
  710d49:	movaps %xmm2,0xc0(%rsp)
  710d51:	lea    0x8b0(%rsp),%rdi
  710d59:	mov    %rbx,%rsi
  710d5c:	mov    0xe0(%rsp),%rdx
  710d64:	lea    0x80(%rsp),%rcx
  710d6c:	lea    0x120(%rsp),%r8
  710d74:	lea    0xc0(%rsp),%r9
  710d7c:	movss  0x7c(%rsp),%xmm2
  710d82:	call   *0x331fe0(%rip)        # a42d68 <_DYNAMIC+0x7d0>
  710d88:	cmp    $0xffffffff,%eax
  710d8b:	mov    0x30(%rsp),%rsi
  710d90:	jne    7119c5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3bc5>
  710d96:	cmp    $0x2,%r12b
  710d9a:	je     710f55 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3155>
  710da0:	mov    0x158(%rsp),%eax
  710da7:	cmp    0x1dc(%rsp),%eax
  710dae:	jne    710f55 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3155>
  710db4:	mov    0x38(%rsp),%rax
  710db9:	mov    0x658(%rax),%rax
  710dc0:	test   %rax,%rax
  710dc3:	je     710f55 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3155>
  710dc9:	mov    0x38(%rsp),%rcx
  710dce:	cmp    0x620(%rcx),%rax
  710dd5:	jne    710f55 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3155>
  710ddb:	mov    (%rsi,%r13,1),%rax
  710ddf:	mov    0x38(%rsp),%rcx
  710de4:	cmp    %rax,0x660(%rcx)
  710deb:	jne    710f55 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3155>
  710df1:	movzbl %r12b,%ecx
  710df5:	lea    0xc0(%rsp),%rdi
  710dfd:	mov    0xe0(%rsp),%rsi
  710e05:	mov    0x158(%rsp),%edx
  710e0c:	call   *0x331df6(%rip)        # a42c08 <_DYNAMIC+0x670>
  710e12:	movq   $0x18,0x80(%rsp)
  710e1e:	cmpl   $0x1,0xc0(%rsp)
  710e26:	jne    71265e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x485e>
  710e2c:	lea    0x80(%rsp),%rbx
  710e34:	mov    %rbx,%rdi
  710e37:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  710e3c:	movsd  0xc4(%rsp),%xmm0
  710e45:	movaps 0x2d0(%rsp),%xmm1
  710e4d:	unpcklps 0x750(%rsp),%xmm1
  710e55:	addps  %xmm0,%xmm1
  710e58:	movhps 0xcc(%rsp),%xmm1
  710e60:	movups %xmm1,0x3b0(%rsp)
  710e68:	mov    %rbx,%rdi
  710e6b:	mov    0x40(%rsp),%rsi
  710e70:	mov    0x50(%rsp),%rdx
  710e75:	mov    $0x1,%ecx
  710e7a:	call   *0x331ec8(%rip)        # a42d48 <_DYNAMIC+0x7b0>
  710e80:	mov    0x90(%rsp),%r9
  710e88:	test   %r9,%r9
  710e8b:	je     710f09 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3109>
  710e8d:	movups 0x80(%rsp),%xmm0
  710e95:	movaps %xmm0,0x120(%rsp)
  710e9d:	movaps 0x1a0(%rsp),%xmm0
  710ea5:	movaps %xmm0,0xc0(%rsp)
  710ead:	xorps  %xmm0,%xmm0
  710eb0:	lea    0x8b0(%rsp),%rdi
  710eb8:	lea    0x3b0(%rsp),%rsi
  710ec0:	lea    0xac0(%rsp),%rdx
  710ec8:	lea    0xc0(%rsp),%rcx
  710ed0:	lea    0x120(%rsp),%r8
  710ed8:	call   *0x331e72(%rip)        # a42d50 <_DYNAMIC+0x7b8>
  710ede:	cmp    $0xffffffff,%eax
  710ee1:	jne    7119c5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3bc5>
  710ee7:	mov    0x30(%rsp),%rsi
  710eec:	jmp    710f55 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3155>
  710eee:	mov    $0x1,%bpl
  710ef1:	cmp    $0x7,%eax
  710ef4:	je     71038f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x258f>
  710efa:	jmp    71291d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b1d>
  710eff:	mov    $0xffffffff,%edi
  710f04:	jmp    7108ed <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x2aed>
  710f09:	movaps 0x1a0(%rsp),%xmm0
  710f11:	movaps %xmm0,0x80(%rsp)
  710f19:	lea    0x8b0(%rsp),%rdi
  710f21:	lea    0x3b0(%rsp),%rsi
  710f29:	lea    0xac0(%rsp),%rdx
  710f31:	lea    0x80(%rsp),%rcx
  710f39:	lea    0x8a0(%rsp),%r8
  710f41:	call   *0x331939(%rip)        # a42880 <_DYNAMIC+0x2e8>
  710f47:	cmp    $0xffffffff,%eax
  710f4a:	mov    0x30(%rsp),%rsi
  710f4f:	jne    7119c5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3bc5>
  710f55:	movss  0xf8(%rsp),%xmm0
  710f5e:	movss  %xmm0,0x1e0(%rsp)
  710f67:	movss  0xfc(%rsp),%xmm0
  710f70:	movss  %xmm0,0x2c8(%rsp)
  710f79:	test   %r15b,%r15b
  710f7c:	je     7110dd <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x32dd>
  710f82:	mov    0x20(%rsi,%r13,1),%edi
  710f87:	call   *0x331a6b(%rip)        # a429f8 <_DYNAMIC+0x460>
  710f8d:	mov    %edx,%ebx
  710f8f:	cmp    $0x2,%dl
  710f92:	mov    0x30(%rsp),%rsi
  710f97:	je     7110dd <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x32dd>
  710f9d:	mov    0x180(%rsp),%rcx
  710fa5:	mov    (%rcx),%rdx
  710fa8:	test   %rdx,%rdx
  710fab:	je     71293b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b3b>
  710fb1:	mov    0x10(%rdx),%rcx
  710fb5:	mov    %eax,%eax
  710fb7:	cmp    %rax,%rcx
  710fba:	jbe    712afa <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4cfa>
  710fc0:	mov    0x8(%rdx),%rcx
  710fc4:	movaps 0x870(%rsp),%xmm3
  710fcc:	movaps %xmm3,%xmm0
  710fcf:	shufps $0xe8,%xmm3,%xmm0
  710fd3:	movaps 0x880(%rsp),%xmm5
  710fdb:	addps  %xmm0,%xmm5
  710fde:	movaps 0x2d0(%rsp),%xmm4
  710fe6:	movaps %xmm4,%xmm1
  710fe9:	shufps $0xe8,%xmm4,%xmm1
  710fed:	movaps 0x360(%rsp),%xmm2
  710ff5:	subps  %xmm1,%xmm2
  710ff8:	addps  %xmm5,%xmm1
  710ffb:	shufps $0xed,%xmm4,%xmm4
  710fff:	subps  %xmm4,%xmm2
  711002:	subps  %xmm0,%xmm2
  711005:	shufps $0xed,%xmm3,%xmm3
  711009:	subps  %xmm3,%xmm2
  71100c:	subps  0x860(%rsp),%xmm2
  711014:	movlhps %xmm2,%xmm1
  711017:	movups %xmm1,0x2e0(%rsp)
  71101f:	testb  $0x1,0x294(%rsp)
  711027:	movl   $0x1,0x88(%rsp)
  711032:	movq   $0x23,0x80(%rsp)
  71103e:	je     71198c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3b8c>
  711044:	lea    (%rcx,%rax,8),%r15
  711048:	lea    0x80(%rsp),%r14
  711050:	mov    %r14,%rdi
  711053:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  711058:	lea    0x298(%rsp),%rcx
  711060:	movups (%rcx),%xmm0
  711063:	movaps %xmm0,0x120(%rsp)
  71106b:	mov    0x10(%rcx),%rax
  71106f:	mov    %rax,0x130(%rsp)
  711077:	movups (%rcx),%xmm0
  71107a:	movaps %xmm0,0xb70(%rsp)
  711082:	mov    0x10(%rcx),%rax
  711086:	mov    %rax,0xb80(%rsp)
  71108e:	movaps 0x1a0(%rsp),%xmm0
  711096:	movaps %xmm0,0x80(%rsp)
  71109e:	movzbl %bl,%r9d
  7110a2:	lea    0x8b0(%rsp),%rdi
  7110aa:	mov    %r15,%rsi
  7110ad:	lea    0x2e0(%rsp),%rdx
  7110b5:	lea    0xb70(%rsp),%rcx
  7110bd:	mov    %r14,%r8
  7110c0:	movss  0xdc(%rsp),%xmm0
  7110c9:	call   *0x331ca1(%rip)        # a42d70 <_DYNAMIC+0x7d8>
  7110cf:	cmp    $0xffffffff,%eax
  7110d2:	jne    7119c5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3bc5>
  7110d8:	mov    0x30(%rsp),%rsi
  7110dd:	mov    0x18(%rsi,%r13,1),%ebx
  7110e2:	cmpb   $0x0,0x2f(%rsp)
  7110e7:	je     711111 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3311>
  7110e9:	cmp    $0xffffffff,%ebx
  7110ec:	je     71110c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x330c>
  7110ee:	mov    0x150(%rsp),%rcx
  7110f6:	cmp    %rbx,%rcx
  7110f9:	jbe    712acc <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4ccc>
  7110ff:	mov    0x148(%rsp),%rax
  711107:	mov    (%rax,%rbx,4),%ebx
  71110a:	jmp    711111 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3311>
  71110c:	mov    $0xffffffff,%ebx
  711111:	cmpb   $0x0,0x60(%rsp)
  711116:	je     7111b6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x33b6>
  71111c:	movss  0x270(%rsp),%xmm0
  711125:	xorps  %xmm1,%xmm1
  711128:	ucomiss %xmm1,%xmm0
  71112b:	jne    71112f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x332f>
  71112d:	jnp    71113f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x333f>
  71112f:	movss  0x274(%rsp),%xmm0
  711138:	ucomiss %xmm1,%xmm0
  71113b:	jne    7111b6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x33b6>
  71113d:	jp     7111b6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x33b6>
  71113f:	cmpb   $0x0,0x1e4(%rsp)
  711147:	je     711169 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3369>
  711149:	movss  0x248(%rsp),%xmm0
  711152:	ucomiss %xmm1,%xmm0
  711155:	jne    711159 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3359>
  711157:	jnp    711169 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3369>
  711159:	movss  0x24c(%rsp),%xmm0
  711162:	ucomiss %xmm1,%xmm0
  711165:	jne    7111b6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x33b6>
  711167:	jp     7111b6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x33b6>
  711169:	test   %bpl,%bpl
  71116c:	je     71118e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x338e>
  71116e:	movss  0x248(%rsp),%xmm0
  711177:	ucomiss %xmm1,%xmm0
  71117a:	jne    71117e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x337e>
  71117c:	jnp    71118e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x338e>
  71117e:	movss  0x24c(%rsp),%xmm0
  711187:	ucomiss %xmm1,%xmm0
  71118a:	jne    7111b6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x33b6>
  71118c:	jp     7111b6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x33b6>
  71118e:	mov    0x150(%rsp),%r14
  711196:	cmp    0x140(%rsp),%r14
  71119e:	jne    70f98e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1b8e>
  7111a4:	lea    0x140(%rsp),%rdi
  7111ac:	call   6f4b70 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  7111b1:	jmp    70f98e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1b8e>
  7111b6:	mov    0x20(%rsi,%r13,1),%edi
  7111bb:	call   6f84b0 <<gpui::runtime::Node>::kind>
  7111c0:	cmp    $0x7,%al
  7111c2:	jne    7111da <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x33da>
  7111c4:	mov    0x30(%rsp),%rax
  7111c9:	mov    (%rax,%r13,1),%rsi
  7111cd:	lea    0x338(%rsp),%rdi
  7111d5:	call   6fc770 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  7111da:	cmpb   $0x0,0x2f(%rsp)
  7111df:	je     71122c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x342c>
  7111e1:	mov    0x1d0(%rsp),%rsi
  7111e9:	mov    $0x1,%edi
  7111ee:	call   *0x33164c(%rip)        # a42840 <_DYNAMIC+0x2a8>
  7111f4:	mov    %eax,%ebp
  7111f6:	mov    0x150(%rsp),%r14
  7111fe:	cmp    0x140(%rsp),%r14
  711206:	jne    711215 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3415>
  711208:	lea    0x140(%rsp),%rdi
  711210:	call   6f4b70 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  711215:	mov    0x148(%rsp),%rax
  71121d:	mov    %ebp,(%rax,%r14,4)
  711221:	inc    %r14
  711224:	mov    %r14,0x150(%rsp)
  71122c:	movss  0x270(%rsp),%xmm0
  711235:	xor    %ebp,%ebp
  711237:	xorps  %xmm1,%xmm1
  71123a:	ucomiss %xmm1,%xmm0
  71123d:	jne    711245 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3445>
  71123f:	jnp    7112cd <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x34cd>
  711245:	movss  0x274(%rsp),%xmm0
  71124e:	ucomiss %xmm1,%xmm0
  711251:	mov    $0x0,%r12d
  711257:	mov    0x30(%rsp),%rax
  71125c:	jne    711260 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3460>
  71125e:	jnp    7112d0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x34d0>
  711260:	mov    0x20(%rax,%r13,1),%edi
  711265:	mov    %edi,%eax
  711267:	and    $0xf,%eax
  71126a:	cmp    $0x9,%eax
  71126d:	ja     71291d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b1d>
  711273:	cmp    $0x6,%eax
  711276:	mov    0x30(%rsp),%rdx
  71127b:	je     711285 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3485>
  71127d:	mov    $0x1,%r12b
  711280:	cmp    $0xf,%edi
  711283:	ja     7112d0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x34d0>
  711285:	mov    0x4b8(%rsp),%eax
  71128c:	mov    $0x3fffffff,%ecx
  711291:	and    %ecx,%eax
  711293:	cmp    $0x3f800001,%eax
  711298:	mov    $0x80000000,%ecx
  71129d:	cmove  %ecx,%eax
  7112a0:	movd   %eax,%xmm0
  7112a4:	mov    $0x1,%r12b
  7112a7:	ucomiss %xmm1,%xmm0
  7112aa:	ja     7112d0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x34d0>
  7112ac:	cmpq   $0x0,0x8(%rdx,%r13,1)
  7112b2:	jne    7112d0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x34d0>
  7112b4:	call   6f84b0 <<gpui::runtime::Node>::kind>
  7112b9:	lea    -0x4(%rax),%ecx
  7112bc:	cmp    $0x2,%al
  7112be:	setae  %al
  7112c1:	test   $0xfb,%cl
  7112c4:	sete   %r12b
  7112c8:	and    %al,%r12b
  7112cb:	jmp    7112d0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x34d0>
  7112cd:	xor    %r12d,%r12d
  7112d0:	mov    0x1d0(%rsp),%rax
  7112d8:	test   %rax,%rax
  7112db:	je     7112f2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x34f2>
  7112dd:	mov    0x1c8(%rsp),%rcx
  7112e5:	shl    $0x6,%rax
  7112e9:	mov    -0x8(%rcx,%rax,1),%ecx
  7112ed:	mov    $0x1,%ebp
  7112f2:	mov    %r12d,%eax
  7112f5:	xor    $0x1,%al
  7112f7:	movzbl %al,%esi
  7112fa:	mov    %ebx,%edi
  7112fc:	mov    %ebp,%edx
  7112fe:	call   *0x331a74(%rip)        # a42d78 <_DYNAMIC+0x7e0>
  711304:	mov    %eax,%ebp
  711306:	cmpq   $0x0,0xe0(%rsp)
  71130f:	je     71137a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x357a>
  711311:	mov    0x38(%rsp),%rax
  711316:	mov    0x708(%rax),%rax
  71131d:	test   %rax,%rax
  711320:	je     71299f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b9f>
  711326:	mov    0x8(%rax),%rsi
  71132a:	mov    0x10(%rax),%rdx
  71132e:	mov    0x1d0(%rsp),%r9d
  711336:	mov    0xe0(%rsp),%rax
  71133e:	mov    %rax,(%rsp)
  711342:	lea    0x160(%rsp),%rdi
  71134a:	mov    0x2b0(%rsp),%rcx
  711352:	mov    0x178(%rsp),%r8
  71135a:	movss  0x1e0(%rsp),%xmm0
  711363:	movss  0x2c8(%rsp),%xmm1
  71136c:	call   *0x331a0e(%rip)        # a42d80 <_DYNAMIC+0x7e8>
  711372:	incq   0x178(%rsp)
  71137a:	cmp    $0xffffffff,%ebx
  71137d:	je     7113b2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x35b2>
  71137f:	mov    %ebx,%eax
  711381:	mov    0x1d0(%rsp),%rcx
  711389:	cmp    %rax,%rcx
  71138c:	jbe    712b16 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d16>
  711392:	mov    0x1c8(%rsp),%rcx
  71139a:	shl    $0x6,%rax
  71139e:	mov    0x30(%rcx,%rax,1),%rax
  7113a3:	mov    %rax,0x84(%rsp)
  7113ab:	mov    $0x1,%eax
  7113b0:	jmp    7113b4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x35b4>
  7113b2:	xor    %eax,%eax
  7113b4:	mov    %eax,0x80(%rsp)
  7113bb:	lea    0x294(%rsp),%rdi
  7113c3:	lea    0x80(%rsp),%rsi
  7113cb:	lea    0x278(%rsp),%rdx
  7113d3:	call   *0x3319af(%rip)        # a42d88 <_DYNAMIC+0x7f0>
  7113d9:	mov    %rax,%rbx
  7113dc:	mov    0x30(%rsp),%rax
  7113e1:	mov    (%rax,%r13,1),%r14
  7113e5:	mov    0x20(%rax,%r13,1),%edi
  7113ea:	call   6f84b0 <<gpui::runtime::Node>::kind>
  7113ef:	mov    %eax,%r15d
  7113f2:	mov    0x30(%rsp),%rax
  7113f7:	mov    0x20(%rax,%r13,1),%edi
  7113fc:	mov    %edi,%eax
  7113fe:	and    $0xf,%eax
  711401:	cmp    $0x9,%eax
  711404:	ja     71291d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b1d>
  71140a:	cmp    $0x6,%eax
  71140d:	je     711608 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3808>
  711413:	shr    $0x4,%edi
  711416:	dec    %edi
  711418:	mov    0x38(%rsp),%rax
  71141d:	mov    0x320(%rax),%rsi
  711424:	mov    0x328(%rax),%rdx
  71142b:	call   6f8350 <<gpui::runtime::TextSlot>::get>
  711430:	mov    %ebp,0x60(%rsp)
  711434:	test   %rax,%rax
  711437:	mov    %rbx,0x2d0(%rsp)
  71143f:	je     71147b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x367b>
  711441:	mov    0x40(%rax),%rbp
  711445:	testb  $0x1,0x0(%rbp)
  711449:	jne    711476 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3676>
  71144b:	mov    0x8(%rbp),%rax
  71144f:	test   $0x1,%al
  711451:	jne    711476 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3676>
  711453:	mov    $0x2,%eax
  711458:	lock xadd %rax,0x8(%rbp)
  71145e:	and    0x7c0(%rsp),%rax
  711466:	mov    %r12d,%ebx
  711469:	neg    %rax
  71146c:	jno    711480 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3680>
  71146e:	lock orq $0x1,0x8(%rbp)
  711474:	jmp    711480 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3680>
  711476:	mov    %r12d,%ebx
  711479:	jmp    711480 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3680>
  71147b:	mov    %r12d,%ebx
  71147e:	xor    %ebp,%ebp
  711480:	movdqa 0x360(%rsp),%xmm0
  711489:	movd   %xmm0,%esi
  71148d:	shufps $0x55,%xmm0,%xmm0
  711491:	movd   %xmm0,%eax
  711495:	shl    $0x20,%rax
  711499:	or     %rax,%rsi
  71149c:	lea    0xc0(%rsp),%rdi
  7114a4:	lea    0x294(%rsp),%rdx
  7114ac:	call   *0x3318de(%rip)        # a42d90 <_DYNAMIC+0x7f8>
  7114b2:	mov    0x30(%rsp),%r12
  7114b7:	mov    0x20(%r12,%r13,1),%edi
  7114bc:	call   6f84b0 <<gpui::runtime::Node>::kind>
  7114c1:	xor    %esi,%esi
  7114c3:	cmpq   $0x0,0x8(%r12,%r13,1)
  7114c9:	setne  %sil
  7114cd:	movzbl %al,%edi
  7114d0:	call   6f8100 <<gpui::runtime::semantics::Actions>::for_node>
  7114d5:	mov    0x18(%r12,%r13,1),%ecx
  7114da:	mov    $0xffffffff,%edx
  7114df:	cmp    %rdx,%rcx
  7114e2:	je     711508 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3708>
  7114e4:	cmp    %rcx,0x198(%rsp)
  7114ec:	jbe    711508 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3708>
  7114ee:	mov    0x190(%rsp),%rdx
  7114f6:	cmpb   $0x0,(%rdx,%rcx,1)
  7114fa:	setne  %cl
  7114fd:	mov    0xf4(%rsp),%edx
  711504:	or     %cl,%dl
  711506:	jmp    71150f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x370f>
  711508:	mov    0xf4(%rsp),%edx
  71150f:	movzbl %al,%ecx
  711512:	or     $0x20,%al
  711514:	movzbl %al,%eax
  711517:	test   %dl,%dl
  711519:	cmove  %ecx,%eax
  71151c:	mov    %r14,0xa0(%rsp)
  711524:	mov    0x60(%rsp),%ecx
  711528:	mov    %ecx,0xb8(%rsp)
  71152f:	mov    %r15b,0xbd(%rsp)
  711537:	mov    %rbp,0xa8(%rsp)
  71153f:	movups 0xc0(%rsp),%xmm0
  711547:	movaps %xmm0,0x80(%rsp)
  71154f:	mov    0x2d0(%rsp),%rcx
  711557:	mov    %rcx,0xb0(%rsp)
  71155f:	movups 0x268(%rsp),%xmm0
  711567:	lea    0x84(%rsp),%rcx
  71156f:	movups %xmm0,0xc(%rcx)
  711573:	mov    %bl,0xbe(%rsp)
  71157a:	mov    %al,0xbc(%rsp)
  711581:	lea    0x1c0(%rsp),%rdi
  711589:	lea    0x80(%rsp),%rsi
  711591:	call   6f7dd0 <<alloc::vec::Vec<gpui::runtime::Presented>>::push_mut>
  711596:	cmpl   $0xffffffff,0x760(%rsp)
  71159e:	je     7115eb <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x37eb>
  7115a0:	mov    0x260(%rsp),%rax
  7115a8:	mov    (%rax),%rbx
  7115ab:	test   %rbx,%rbx
  7115ae:	je     7115eb <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x37eb>
  7115b0:	mov    0x30(%rsp),%rax
  7115b5:	mov    (%rax,%r13,1),%r15
  7115b9:	mov    0x38(%rsp),%rax
  7115be:	mov    0x6a0(%rax),%rdi
  7115c5:	mov    0x6a8(%rax),%rsi
  7115cc:	mov    %r15,%rdx
  7115cf:	call   6be6b0 <<alloc::collections::btree::map::BTreeMap<u64, gpui::runtime::list::ListRow>>::get::<u64>>
  7115d4:	lea    0x760(%rsp),%rdi
  7115dc:	mov    %rbx,%rsi
  7115df:	mov    %r15,%rdx
  7115e2:	mov    %rax,%rcx
  7115e5:	call   *0x331625(%rip)        # a42c10 <_DYNAMIC+0x678>
  7115eb:	mov    0x50(%rsp),%rdx
  7115f0:	inc    %rdx
  7115f3:	cmp    0x2b0(%rsp),%rdx
  7115fb:	mov    0x38(%rsp),%r15
  711600:	jb     70f96d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1b6d>
  711606:	jmp    711672 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3872>
  711608:	mov    $0xffffffff,%edi
  71160d:	jmp    711418 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3618>
  711612:	mov    0x8c0(%rsp),%rcx
  71161a:	mov    0x48(%rsp),%rdx
  71161f:	mov    %rcx,0x30(%rdx)
  711623:	movaps 0x8b0(%rsp),%xmm0
  71162b:	movups %xmm0,0x20(%rdx)
  71162f:	movaps 0x440(%rsp),%xmm0
  711637:	movaps %xmm0,0x370(%rsp)
  71163f:	movups %xmm0,0x10(%rdx)
  711643:	mov    %rax,(%rdx)
  711646:	mov    %rsi,0x8(%rdx)
  71164a:	mov    $0x1,%r12b
  71164d:	cmpl   $0xffffffff,0x760(%rsp)
  711655:	mov    $0x1,%r13b
  711658:	mov    $0x1,%bpl
  71165b:	jne    7126df <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x48df>
  711661:	jmp    7126ec <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x48ec>
  711666:	movq   $0x0,0x178(%rsp)
  711672:	mov    0x160(%rsp),%rax
  71167a:	cmp    $0xffffffffffffffff,%rax
  71167e:	je     71171e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x391e>
  711684:	mov    0x170(%rsp),%rsi
  71168c:	lea    0x0(,%rsi,4),%rcx
  711694:	cmp    %rcx,%rax
  711697:	jbe    7117c9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x39c9>
  71169d:	lea    0x160(%rsp),%rdi
  7116a5:	mov    $0x8,%edx
  7116aa:	mov    $0x18,%ecx
  7116af:	call   6f0750 <<alloc::raw_vec::RawVecInner>::shrink>
  7116b4:	cmp    $0xffffffffffffffff,%rax
  7116b8:	je     7117c9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x39c9>
  7116be:	mov    %rax,%rdi
  7116c1:	mov    %rdx,%rsi
  7116c4:	call   *0x3311c6(%rip)        # a42890 <_DYNAMIC+0x2f8>
  7116ca:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  7116cf:	movaps 0x8b0(%rsp),%xmm0
  7116d7:	movaps 0x8c0(%rsp),%xmm1
  7116df:	movaps 0x8d0(%rsp),%xmm2
  7116e7:	mov    0x48(%rsp),%rcx
  7116ec:	movups %xmm2,0x28(%rcx)
  7116f0:	movups %xmm1,0x18(%rcx)
  7116f4:	movups %xmm0,0x8(%rcx)
  7116f8:	mov    %rax,(%rcx)
  7116fb:	mov    $0x1,%r12b
  7116fe:	mov    $0x1,%r14b
  711701:	mov    $0x1,%r13b
  711704:	mov    $0x1,%bpl
  711707:	mov    $0x1,%r15b
  71170a:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  711713:	jne    7126c0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x48c0>
  711719:	jmp    7126d0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x48d0>
  71171e:	mov    0x708(%r15),%rax
  711725:	test   %rax,%rax
  711728:	je     7117c9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x39c9>
  71172e:	mov    0x10(%rax),%rdx
  711732:	cmp    %rdx,0x178(%rsp)
  71173a:	je     7117c9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x39c9>
  711740:	ja     7129ba <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4bba>
  711746:	mov    0x8(%rax),%rsi
  71174a:	lea    0x480(%rsp),%rdi
  711752:	mov    0x178(%rsp),%rdx
  71175a:	call   6d9460 <<gpui::runtime::text_geometry::Entry as <[_]>::to_vec_in::ConvertVec>::to_vec::<alloc::alloc::Global>>
  71175f:	mov    0x490(%rsp),%rax
  711767:	mov    %rax,0x90(%rsp)
  71176f:	movups 0x480(%rsp),%xmm0
  711777:	movaps %xmm0,0x80(%rsp)
  71177f:	cmpq   $0xffffffffffffffff,0x160(%rsp)
  711788:	je     711797 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3997>
  71178a:	lea    0x160(%rsp),%rdi
  711792:	call   6c1730 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  711797:	mov    0x90(%rsp),%rax
  71179f:	mov    %rax,0x170(%rsp)
  7117a7:	movaps 0x80(%rsp),%xmm0
  7117af:	movaps %xmm0,0x160(%rsp)
  7117b7:	mov    0x160(%rsp),%rax
  7117bf:	cmp    $0xffffffffffffffff,%rax
  7117c3:	jne    711684 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3884>
  7117c9:	cmpl   $0xffffffff,0x760(%rsp)
  7117d1:	je     7117e1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x39e1>
  7117d3:	lea    0x760(%rsp),%rdi
  7117db:	call   *0x331437(%rip)        # a42c18 <_DYNAMIC+0x680>
  7117e1:	lea    0x1e8(%r15),%rbx
  7117e8:	mov    0x680(%r15),%rax
  7117ef:	test   %rax,%rax
  7117f2:	je     711880 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3a80>
  7117f8:	mov    0x100(%rax),%rdx
  7117ff:	lea    0x278(%rsp),%rax
  711807:	mov    %rax,0x480(%rsp)
  71180f:	lea    0x2f(%rsp),%rax
  711814:	mov    %rax,0x488(%rsp)
  71181c:	mov    %rbx,0x490(%rsp)
  711824:	lea    0x140(%rsp),%rax
  71182c:	mov    %rax,0x498(%rsp)
  711834:	lea    0x1c0(%rsp),%rax
  71183c:	mov    %rax,0x4a0(%rsp)
  711844:	test   %rdx,%rdx
  711847:	je     711880 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3a80>
  711849:	lea    0x80(%rsp),%rdi
  711851:	lea    0x480(%rsp),%rsi
  711859:	call   6db4c0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#36}>
  71185e:	mov    0x90(%rsp),%rax
  711866:	mov    %rax,0x450(%rsp)
  71186e:	movups 0x80(%rsp),%xmm0
  711876:	movaps %xmm0,0x440(%rsp)
  71187e:	jmp    71188c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3a8c>
  711880:	movq   $0xffffffffffffffff,0x440(%rsp)
  71188c:	mov    %rbx,0x30(%rsp)
  711891:	mov    0x288(%rsp),%rax
  711899:	mov    %rax,0x490(%rsp)
  7118a1:	movups 0x278(%rsp),%xmm0
  7118a9:	movaps %xmm0,0x480(%rsp)
  7118b1:	lea    0xc0(%rsp),%rdi
  7118b9:	lea    0x440(%rsp),%rsi
  7118c1:	lea    0x480(%rsp),%rdx
  7118c9:	call   6b6810 <<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#37}>>
  7118ce:	cmpb   $0x0,0x78d(%r15)
  7118d6:	je     71192d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3b2d>
  7118d8:	lea    0x480(%rsp),%rbx
  7118e0:	lea    0x8b0(%rsp),%rsi
  7118e8:	mov    $0x1f0,%edx
  7118ed:	mov    %rbx,%rdi
  7118f0:	call   *0x330f2a(%rip)        # a42820 <memcpy@GLIBC_2.14>
  7118f6:	mov    $0x1,%al
  7118f8:	mov    %eax,0x58(%rsp)
  7118fc:	mov    $0x1,%r12b
  7118ff:	mov    $0x1,%al
  711901:	mov    %eax,0x40(%rsp)
  711905:	mov    $0x1,%r14b
  711908:	mov    $0x1,%r15b
  71190b:	mov    $0x1,%bpl
  71190e:	movb   $0x1,0x100(%rsp)
  711916:	mov    %rbx,%rdi
  711919:	call   *0x331479(%rip)        # a42d98 <_DYNAMIC+0x800>
  71191f:	movq   $0x0,0x50(%rsp)
  711928:	jmp    711a0c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3c0c>
  71192d:	lea    0x480(%rsp),%rbx
  711935:	lea    0x8b0(%rsp),%rsi
  71193d:	mov    $0x1f0,%edx
  711942:	mov    %rbx,%rdi
  711945:	call   *0x330ed5(%rip)        # a42820 <memcpy@GLIBC_2.14>
  71194b:	mov    $0x1,%al
  71194d:	mov    %eax,0x58(%rsp)
  711951:	mov    $0x1,%r12b
  711954:	mov    $0x1,%al
  711956:	mov    %eax,0x40(%rsp)
  71195a:	mov    $0x1,%r14b
  71195d:	mov    $0x1,%r15b
  711960:	mov    $0x1,%bpl
  711963:	movb   $0x1,0x100(%rsp)
  71196b:	mov    %rbx,%rdi
  71196e:	call   *0x33142c(%rip)        # a42da0 <_DYNAMIC+0x808>
  711974:	mov    0x38(%rsp),%rcx
  711979:	cmpq   $0xffffffffffffffff,0x5f8(%rcx)
  711981:	je     7119dc <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3bdc>
  711983:	mov    0x610(%rcx),%rsi
  71198a:	jmp    7119de <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3bde>
  71198c:	lea    0x84(%rsp),%rcx
  711994:	mov    0x14(%rcx),%rax
  711998:	movups 0x4(%rcx),%xmm0
  71199c:	movaps %xmm0,0x120(%rsp)
  7119a4:	mov    %rax,0x130(%rsp)
  7119ac:	mov    0x48(%rsp),%rcx
  7119b1:	mov    %rax,0x18(%rcx)
  7119b5:	movups %xmm0,0x8(%rcx)
  7119b9:	movq   $0x23,(%rcx)
  7119c0:	jmp    712685 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4885>
  7119c5:	mov    0x48(%rsp),%rcx
  7119ca:	movq   $0x23,(%rcx)
  7119d1:	mov    %eax,0x8(%rcx)
  7119d4:	mov    %edx,0xc(%rcx)
  7119d7:	jmp    712685 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4885>
  7119dc:	xor    %esi,%esi
  7119de:	mov    $0x1,%cl
  7119e0:	mov    %ecx,0x58(%rsp)
  7119e4:	mov    $0x1,%r12b
  7119e7:	mov    $0x1,%cl
  7119e9:	mov    %ecx,0x40(%rsp)
  7119ed:	mov    $0x1,%r14b
  7119f0:	mov    $0x1,%r15b
  7119f3:	mov    $0x1,%bpl
  7119f6:	movb   $0x1,0x100(%rsp)
  7119fe:	mov    %rax,%rdi
  711a01:	call   *0x3311e1(%rip)        # a42be8 <_DYNAMIC+0x650>
  711a07:	mov    %rax,0x50(%rsp)
  711a0c:	mov    0x38(%rsp),%rcx
  711a11:	mov    0x688(%rcx),%rax
  711a18:	mov    0x698(%rcx),%r12
  711a1f:	test   %rax,%rax
  711a22:	setne  %cl
  711a25:	test   %r12,%r12
  711a28:	setne  %dl
  711a2b:	test   %dl,%cl
  711a2d:	je     711c1e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3e1e>
  711a33:	mov    0x38(%rsp),%rcx
  711a38:	mov    0x690(%rcx),%r13
  711a3f:	xor    %r14d,%r14d
  711a42:	lea    0x480(%rsp),%rbx
  711a4a:	lea    0x370(%rsp),%r15
  711a52:	jmp    711a62 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3c62>
  711a54:	mov    $0x0,%eax
  711a59:	dec    %r12
  711a5c:	je     711c1e <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3e1e>
  711a62:	test   %r14,%r14
  711a65:	jne    711ae8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3ce8>
  711a6b:	test   %r13,%r13
  711a6e:	je     711a97 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3c97>
  711a70:	mov    %r13,%rcx
  711a73:	mov    %rax,%r14
  711a76:	and    $0x7,%rcx
  711a7a:	je     711a9c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3c9c>
  711a7c:	xor    %edx,%edx
  711a7e:	xchg   %ax,%ax
  711a80:	mov    0x590(%r14),%r14
  711a87:	inc    %rdx
  711a8a:	cmp    %rdx,%rcx
  711a8d:	jne    711a80 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3c80>
  711a8f:	mov    %r13,%rax
  711a92:	sub    %rdx,%rax
  711a95:	jmp    711a9f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3c9f>
  711a97:	mov    %rax,%r14
  711a9a:	jmp    711ae3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3ce3>
  711a9c:	mov    %r13,%rax
  711a9f:	cmp    $0x8,%r13
  711aa3:	jb     711ae3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3ce3>
  711aa5:	mov    0x590(%r14),%rcx
  711aac:	mov    0x590(%rcx),%rcx
  711ab3:	mov    0x590(%rcx),%rcx
  711aba:	mov    0x590(%rcx),%rcx
  711ac1:	mov    0x590(%rcx),%rcx
  711ac8:	mov    0x590(%rcx),%rcx
  711acf:	mov    0x590(%rcx),%rcx
  711ad6:	mov    0x590(%rcx),%r14
  711add:	add    $0xfffffffffffffff8,%rax
  711ae1:	jne    711aa5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3ca5>
  711ae3:	xor    %r13d,%r13d
  711ae6:	xor    %eax,%eax
  711ae8:	movzwl 0x58a(%r14),%ecx
  711af0:	cmp    %rcx,%r13
  711af3:	jae    711b00 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3d00>
  711af5:	mov    %r13,%rdx
  711af8:	mov    %r14,%rcx
  711afb:	jmp    711b27 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3d27>
  711afd:	nopl   (%rax)
  711b00:	mov    0x580(%r14),%rcx
  711b07:	test   %rcx,%rcx
  711b0a:	je     71297b <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b7b>
  711b10:	inc    %rax
  711b13:	movzwl 0x588(%r14),%edx
  711b1b:	mov    %rcx,%r14
  711b1e:	cmp    0x58a(%rcx),%dx
  711b25:	jae    711b00 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3d00>
  711b27:	test   %rax,%rax
  711b2a:	je     711b6a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3d6a>
  711b2c:	lea    (%rcx,%rdx,8),%rsi
  711b30:	add    $0x598,%rsi
  711b37:	mov    %rax,%rdi
  711b3a:	and    $0x7,%rdi
  711b3e:	je     711b73 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3d73>
  711b40:	xor    %r8d,%r8d
  711b43:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  711b50:	mov    (%rsi),%r14
  711b53:	lea    0x590(%r14),%rsi
  711b5a:	inc    %r8
  711b5d:	cmp    %r8,%rdi
  711b60:	jne    711b50 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3d50>
  711b62:	mov    %rax,%rdi
  711b65:	sub    %r8,%rdi
  711b68:	jmp    711b76 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3d76>
  711b6a:	lea    0x1(%rdx),%r13
  711b6e:	mov    %rcx,%r14
  711b71:	jmp    711bc4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3dc4>
  711b73:	mov    %rax,%rdi
  711b76:	cmp    $0x8,%rax
  711b7a:	jb     711bc1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3dc1>
  711b7c:	nopl   0x0(%rax)
  711b80:	mov    (%rsi),%rax
  711b83:	mov    0x590(%rax),%rax
  711b8a:	mov    0x590(%rax),%rax
  711b91:	mov    0x590(%rax),%rax
  711b98:	mov    0x590(%rax),%rax
  711b9f:	mov    0x590(%rax),%rax
  711ba6:	mov    0x590(%rax),%rax
  711bad:	mov    0x590(%rax),%r14
  711bb4:	lea    0x590(%r14),%rsi
  711bbb:	add    $0xfffffffffffffff8,%rdi
  711bbf:	jne    711b80 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3d80>
  711bc1:	xor    %r13d,%r13d
  711bc4:	mov    %rdx,%rax
  711bc7:	shl    $0x4,%rax
  711bcb:	cmpl   $0x1,(%rcx,%rax,1)
  711bcf:	jne    711a54 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3c54>
  711bd5:	imul   $0x70,%rdx,%rdx
  711bd9:	lea    (%rcx,%rdx,1),%rbp
  711bdd:	add    $0xb0,%rbp
  711be4:	cmpl   $0x2,0x0(%rbp)
  711be8:	jne    711a54 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3c54>
  711bee:	mov    0x8(%rcx,%rax,1),%rdx
  711bf3:	mov    %rbx,%rdi
  711bf6:	mov    %r15,%rsi
  711bf9:	call   *0x331119(%rip)        # a42d18 <_DYNAMIC+0x780>
  711bff:	cmpl   $0x1,0x480(%rsp)
  711c07:	jne    711a54 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3c54>
  711c0d:	movups 0x488(%rsp),%xmm0
  711c15:	movups %xmm0,0x8(%rbp)
  711c19:	jmp    711a54 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3c54>
  711c1e:	mov    0x38(%rsp),%r15
  711c23:	mov    0x6a0(%r15),%r8
  711c2a:	mov    0x6b0(%r15),%rax
  711c31:	test   %r8,%r8
  711c34:	setne  %cl
  711c37:	test   %rax,%rax
  711c3a:	setne  %dl
  711c3d:	test   %dl,%cl
  711c3f:	mov    0x2c0(%rsp),%rbx
  711c47:	mov    0x260(%rsp),%r13
  711c4f:	je     711e68 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4068>
  711c55:	mov    0x6a8(%r15),%rsi
  711c5c:	xor    %ecx,%ecx
  711c5e:	jmp    711c83 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3e83>
  711c60:	mov    $0x1,%r8b
  711c63:	mov    %r12,%rbx
  711c66:	dec    %rax
  711c69:	shl    $0x5,%rdi
  711c6d:	add    %rdi,%rdx
  711c70:	mov    %r8b,0x1c(%rdx)
  711c74:	mov    $0x0,%r8d
  711c7a:	test   %rax,%rax
  711c7d:	je     711e68 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4068>
  711c83:	test   %rcx,%rcx
  711c86:	jne    711d08 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3f08>
  711c8c:	test   %rsi,%rsi
  711c8f:	je     711cb7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3eb7>
  711c91:	mov    %rsi,%rdx
  711c94:	mov    %r8,%rcx
  711c97:	and    $0x7,%rdx
  711c9b:	je     711cbc <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3ebc>
  711c9d:	xor    %edi,%edi
  711c9f:	nop
  711ca0:	mov    0x1c8(%rcx),%rcx
  711ca7:	inc    %rdi
  711caa:	cmp    %rdi,%rdx
  711cad:	jne    711ca0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3ea0>
  711caf:	mov    %rsi,%rdx
  711cb2:	sub    %rdi,%rdx
  711cb5:	jmp    711cbf <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3ebf>
  711cb7:	mov    %r8,%rcx
  711cba:	jmp    711d03 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3f03>
  711cbc:	mov    %rsi,%rdx
  711cbf:	cmp    $0x8,%rsi
  711cc3:	jb     711d03 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3f03>
  711cc5:	mov    0x1c8(%rcx),%rcx
  711ccc:	mov    0x1c8(%rcx),%rcx
  711cd3:	mov    0x1c8(%rcx),%rcx
  711cda:	mov    0x1c8(%rcx),%rcx
  711ce1:	mov    0x1c8(%rcx),%rcx
  711ce8:	mov    0x1c8(%rcx),%rcx
  711cef:	mov    0x1c8(%rcx),%rcx
  711cf6:	mov    0x1c8(%rcx),%rcx
  711cfd:	add    $0xfffffffffffffff8,%rdx
  711d01:	jne    711cc5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3ec5>
  711d03:	xor    %esi,%esi
  711d05:	xor    %r8d,%r8d
  711d08:	movzwl 0x1c2(%rcx),%edx
  711d0f:	cmp    %rdx,%rsi
  711d12:	jae    711d20 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3f20>
  711d14:	mov    %rsi,%rdi
  711d17:	mov    %rcx,%rdx
  711d1a:	jmp    711d46 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3f46>
  711d1c:	nopl   0x0(%rax)
  711d20:	mov    0x160(%rcx),%rdx
  711d27:	test   %rdx,%rdx
  711d2a:	je     71298d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b8d>
  711d30:	inc    %r8
  711d33:	movzwl 0x1c0(%rcx),%edi
  711d3a:	mov    %rdx,%rcx
  711d3d:	cmp    0x1c2(%rdx),%di
  711d44:	jae    711d20 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3f20>
  711d46:	test   %r8,%r8
  711d49:	je     711d8a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3f8a>
  711d4b:	lea    (%rdx,%rdi,8),%rsi
  711d4f:	add    $0x1d0,%rsi
  711d56:	mov    %r8,%r9
  711d59:	and    $0x7,%r9
  711d5d:	je     711d93 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3f93>
  711d5f:	xor    %r10d,%r10d
  711d62:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  711d70:	mov    (%rsi),%rcx
  711d73:	lea    0x1c8(%rcx),%rsi
  711d7a:	inc    %r10
  711d7d:	cmp    %r10,%r9
  711d80:	jne    711d70 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3f70>
  711d82:	mov    %r8,%r9
  711d85:	sub    %r10,%r9
  711d88:	jmp    711d96 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3f96>
  711d8a:	lea    0x1(%rdi),%rsi
  711d8e:	mov    %rdx,%rcx
  711d91:	jmp    711de3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3fe3>
  711d93:	mov    %r8,%r9
  711d96:	cmp    $0x8,%r8
  711d9a:	jb     711de1 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3fe1>
  711d9c:	nopl   0x0(%rax)
  711da0:	mov    (%rsi),%rcx
  711da3:	mov    0x1c8(%rcx),%rcx
  711daa:	mov    0x1c8(%rcx),%rcx
  711db1:	mov    0x1c8(%rcx),%rcx
  711db8:	mov    0x1c8(%rcx),%rcx
  711dbf:	mov    0x1c8(%rcx),%rcx
  711dc6:	mov    0x1c8(%rcx),%rcx
  711dcd:	mov    0x1c8(%rcx),%rcx
  711dd4:	lea    0x1c8(%rcx),%rsi
  711ddb:	add    $0xfffffffffffffff8,%r9
  711ddf:	jne    711da0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3fa0>
  711de1:	xor    %esi,%esi
  711de3:	mov    0x338(%rsp),%r8
  711deb:	test   %r8,%r8
  711dee:	je     711e60 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4060>
  711df0:	mov    %rbx,%r12
  711df3:	mov    0x168(%rdx,%rdi,8),%r9
  711dfb:	mov    0x340(%rsp),%r10
  711e03:	movzwl 0x62(%r8),%ebx
  711e08:	mov    %ebx,%r14d
  711e0b:	shl    $0x3,%r14d
  711e0f:	mov    $0xffffffffffffffff,%r11
  711e16:	cs nopw 0x0(%rax,%rax,1)
  711e20:	test   %r14,%r14
  711e23:	je     711e4d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x404d>
  711e25:	cmp    0x10(%r8,%r11,8),%r9
  711e2a:	seta   %bpl
  711e2e:	sbb    $0x0,%bpl
  711e32:	inc    %r11
  711e35:	add    $0xfffffffffffffff8,%r14
  711e39:	cmp    $0x1,%bpl
  711e3d:	je     711e20 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4020>
  711e3f:	movzbl %bpl,%ebx
  711e43:	test   %ebx,%ebx
  711e45:	je     711c60 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3e60>
  711e4b:	jmp    711e50 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4050>
  711e4d:	mov    %rbx,%r11
  711e50:	mov    %r12,%rbx
  711e53:	sub    $0x1,%r10
  711e57:	jb     711e60 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4060>
  711e59:	mov    0x68(%r8,%r11,8),%r8
  711e5e:	jmp    711e03 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4003>
  711e60:	xor    %r8d,%r8d
  711e63:	jmp    711c66 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x3e66>
  711e68:	cmpl   $0x2,0xbd0(%rsp)
  711e70:	mov    $0x1,%bpl
  711e73:	je     711eb0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x40b0>
  711e75:	lea    0x480(%rsp),%rdi
  711e7d:	lea    0xbd0(%rsp),%rsi
  711e85:	mov    $0x1e8,%edx
  711e8a:	call   *0x330990(%rip)        # a42820 <memcpy@GLIBC_2.14>
  711e90:	mov    %r15,%rdi
  711e93:	call   6c6240 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  711e98:	lea    0x480(%rsp),%rsi
  711ea0:	mov    $0x1e8,%edx
  711ea5:	mov    %r15,%rdi
  711ea8:	call   *0x330972(%rip)        # a42820 <memcpy@GLIBC_2.14>
  711eae:	xor    %ebp,%ebp
  711eb0:	mov    $0x1,%al
  711eb2:	mov    %eax,0x58(%rsp)
  711eb6:	cmpl   $0xffffffff,0x760(%rsp)
  711ebe:	mov    $0x1,%r14b
  711ec1:	je     712059 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4259>
  711ec7:	movups 0x7b0(%rsp),%xmm0
  711ecf:	movaps %xmm0,0x410(%rsp)
  711ed7:	movups 0x7a0(%rsp),%xmm0
  711edf:	movaps %xmm0,0x400(%rsp)
  711ee7:	movups 0x760(%rsp),%xmm0
  711eef:	movups 0x770(%rsp),%xmm1
  711ef7:	movups 0x780(%rsp),%xmm2
  711eff:	movupd 0x790(%rsp),%xmm3
  711f08:	movapd %xmm3,0x3f0(%rsp)
  711f11:	movaps %xmm2,0x3e0(%rsp)
  711f19:	movaps %xmm1,0x3d0(%rsp)
  711f21:	movaps %xmm0,0x3c0(%rsp)
  711f29:	cmpq   $0x0,0x0(%r13)
  711f2e:	je     71202f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x422f>
  711f34:	mov    0x30(%rsp),%rax
  711f39:	mov    %rax,0x480(%rsp)
  711f41:	lea    0x140(%rsp),%rax
  711f49:	mov    %rax,0x488(%rsp)
  711f51:	lea    0x1c0(%rsp),%rax
  711f59:	mov    %rax,0x490(%rsp)
  711f61:	lea    0x80(%rsp),%rdi
  711f69:	lea    0x370(%rsp),%rsi
  711f71:	lea    0x480(%rsp),%rdx
  711f79:	call   6b86e0 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#39}>>
  711f7e:	lea    0x3c0(%rsp),%rdi
  711f86:	call   6c74f0 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportColumn>>
  711f8b:	mov    0x90(%rsp),%rax
  711f93:	mov    %rax,0x3d0(%rsp)
  711f9b:	movups 0x80(%rsp),%xmm0
  711fa3:	movaps %xmm0,0x3c0(%rsp)
  711fab:	mov    0x0(%r13),%rdi
  711faf:	cmpl   $0xffffffff,0x60(%rdi)
  711fb3:	je     711fc2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x41c2>
  711fb5:	add    $0x60,%rdi
  711fb9:	call   6c78e0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  711fbe:	mov    0x0(%r13),%rdi
  711fc2:	movaps 0x410(%rsp),%xmm0
  711fca:	movups %xmm0,0xb0(%rdi)
  711fd1:	movaps 0x400(%rsp),%xmm0
  711fd9:	movups %xmm0,0xa0(%rdi)
  711fe0:	movaps 0x3c0(%rsp),%xmm0
  711fe8:	mov    0x3d0(%rsp),%rax
  711ff0:	mov    0x3d8(%rsp),%rcx
  711ff8:	movaps 0x3e0(%rsp),%xmm1
  712000:	movaps 0x3f0(%rsp),%xmm2
  712008:	movups %xmm2,0x90(%rdi)
  71200f:	movups %xmm1,0x80(%rdi)
  712016:	mov    %rax,0x70(%rdi)
  71201a:	mov    %rcx,0x78(%rdi)
  71201e:	movups %xmm0,0x60(%rdi)
  712022:	movl   $0x0,0x58(%rsp)
  71202a:	xor    %r14d,%r14d
  71202d:	jmp    712059 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4259>
  71202f:	mov    $0x1,%al
  712031:	mov    %eax,0x58(%rsp)
  712035:	xor    %r14d,%r14d
  712038:	lea    0x3c0(%rsp),%rdi
  712040:	mov    $0x1,%r12b
  712043:	mov    $0x1,%al
  712045:	mov    %eax,0x40(%rsp)
  712049:	mov    $0x1,%r15b
  71204c:	movb   $0x1,0x100(%rsp)
  712054:	call   6c78e0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  712059:	mov    %r14d,0x30(%rsp)
  71205e:	mov    0xc0(%rsp),%r15
  712066:	cmp    $0xffffffffffffffff,%r15
  71206a:	sete   0x100(%rsp)
  712072:	je     7120de <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x42de>
  712074:	mov    %rbx,%r12
  712077:	mov    0xc8(%rsp),%rax
  71207f:	mov    %rax,0x40(%rsp)
  712084:	mov    0xd0(%rsp),%r14
  71208c:	mov    %r13,%rdi
  71208f:	call   6b6a20 <<core::option::Option<alloc::boxed::Box<gpui::runtime::metadata::Metadata>>>::get_or_insert_with::<<alloc::boxed::Box<gpui::runtime::metadata::Metadata> as core::default::Default>::default>>
  712094:	mov    $0x100,%ebx
  712099:	add    0x0(%r13),%rbx
  71209d:	mov    %rbx,%rdi
  7120a0:	call   6b6880 <<core::option::Option<alloc::boxed::Box<gpui::runtime::geometry::Geometry>>>::get_or_insert_with::<<alloc::boxed::Box<gpui::runtime::geometry::Geometry> as core::default::Default>::default>>
  7120a5:	mov    (%rbx),%rdi
  7120a8:	mov    %r15,0x480(%rsp)
  7120b0:	mov    0x40(%rsp),%rax
  7120b5:	mov    %rax,0x488(%rsp)
  7120bd:	mov    %r14,0x490(%rsp)
  7120c5:	lea    0x480(%rsp),%rsi
  7120cd:	call   *0x330cd5(%rip)        # a42da8 <_DYNAMIC+0x810>
  7120d3:	mov    %r12,%rbx
  7120d6:	mov    0x260(%rsp),%r13
  7120de:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  7120e7:	je     712122 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4322>
  7120e9:	mov    0x180(%rsp),%rax
  7120f1:	mov    (%rax),%rdi
  7120f4:	test   %rdi,%rdi
  7120f7:	mov    0x38(%rsp),%r14
  7120fc:	je     71295d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b5d>
  712102:	lea    0x7f8(%rsp),%rdx
  71210a:	mov    0x2b8(%rsp),%rsi
  712112:	call   *0x330c98(%rip)        # a42db0 <_DYNAMIC+0x818>
  712118:	movl   $0x0,0x40(%rsp)
  712120:	jmp    71212d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x432d>
  712122:	mov    $0x1,%al
  712124:	mov    %eax,0x40(%rsp)
  712128:	mov    0x38(%rsp),%r14
  71212d:	mov    0x0(%r13),%rax
  712131:	test   %rax,%rax
  712134:	je     712183 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4383>
  712136:	mov    0xe0(%rax),%rax
  71213d:	test   %rax,%rax
  712140:	je     712183 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4383>
  712142:	mov    0x7e8(%rsp),%rcx
  71214a:	mov    %rcx,0x40(%rax)
  71214e:	mov    0x328(%rsp),%rcx
  712156:	mov    %rcx,0x48(%rax)
  71215a:	mov    0x330(%rsp),%ecx
  712161:	mov    %ecx,0x50(%rax)
  712164:	movzbl 0x7b(%rsp),%ecx
  712169:	mov    %cl,0x54(%rax)
  71216c:	movzwl 0xe8(%rsp),%ecx
  712174:	mov    %cx,0x55(%rax)
  712178:	movzbl 0xea(%rsp),%ecx
  712180:	mov    %cl,0x57(%rax)
  712183:	mov    0x708(%r14),%rdi
  71218a:	test   %rdi,%rdi
  71218d:	je     7121e3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x43e3>
  71218f:	mov    0x170(%rsp),%rax
  712197:	mov    %rax,0x490(%rsp)
  71219f:	movaps 0x160(%rsp),%xmm0
  7121a7:	movaps %xmm0,0x480(%rsp)
  7121af:	cmpq   $0xffffffffffffffff,0x18(%rdi)
  7121b4:	je     7121c6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x43c6>
  7121b6:	add    $0x18,%rdi
  7121ba:	call   6c1730 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  7121bf:	mov    0x708(%r14),%rdi
  7121c6:	mov    0x490(%rsp),%rax
  7121ce:	mov    %rax,0x28(%rdi)
  7121d2:	movaps 0x480(%rsp),%xmm0
  7121da:	movups %xmm0,0x18(%rdi)
  7121de:	xor    %r12d,%r12d
  7121e1:	jmp    7121e6 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x43e6>
  7121e3:	mov    $0x1,%r12b
  7121e6:	mov    0x1d0(%rsp),%rax
  7121ee:	mov    %rax,0x490(%rsp)
  7121f6:	movups 0x1c0(%rsp),%xmm0
  7121fe:	movaps %xmm0,0x480(%rsp)
  712206:	lea    0x5f8(%r14),%r15
  71220d:	cmpq   $0xffffffffffffffff,0x5f8(%r14)
  712215:	je     71221f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x441f>
  712217:	mov    %r15,%rdi
  71221a:	call   6c13a0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  71221f:	mov    0x490(%rsp),%rax
  712227:	mov    %rax,0x10(%r15)
  71222b:	movaps 0x480(%rsp),%xmm0
  712233:	movups %xmm0,(%r15)
  712237:	mov    0x38(%rsp),%rdi
  71223c:	mov    0x50(%rsp),%rax
  712241:	mov    %rax,0x610(%rdi)
  712248:	mov    %bx,0x618(%rdi)
  71224f:	mov    0x15c(%rsp),%eax
  712256:	mov    %ax,0x61a(%rdi)
  71225d:	movss  0x7c(%rsp),%xmm0
  712263:	movss  %xmm0,0x61c(%rdi)
  71226b:	xor    %r15d,%r15d
  71226e:	mov    0x30(%rsp),%r14d
  712273:	call   6f0ef0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::prune_focus>
  712278:	mov    0x38(%rsp),%r14
  71227d:	mov    0x310(%rsp),%rax
  712285:	mov    %rax,0x6f0(%r14)
  71228c:	mov    0x2b8(%rsp),%rax
  712294:	mov    %rax,0x6f8(%r14)
  71229b:	mov    0x6d0(%r14),%rax
  7122a2:	mov    0x708(%r14),%rdi
  7122a9:	mov    %rax,0x700(%r14)
  7122b0:	mov    0x7f0(%rsp),%rax
  7122b8:	mov    %rax,0x628(%r14)
  7122bf:	cmpq   $0x0,0x328(%r14)
  7122c7:	setne  %al
  7122ca:	test   %rdi,%rdi
  7122cd:	sete   %cl
  7122d0:	or     %al,%cl
  7122d2:	cmp    $0x1,%cl
  7122d5:	je     7122ef <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x44ef>
  7122d7:	add    $0x30,%rdi
  7122db:	call   6bf7e0 <core::ptr::drop_glue::<core::option::Option<gpui_canvas::text::TextSystem>>>
  7122e0:	mov    0x708(%r14),%rax
  7122e7:	movq   $0x0,0x30(%rax)
  7122ef:	movb   $0x0,0x78b(%r14)
  7122f7:	movw   $0x0,0x788(%r14)
  712301:	lea    0x6b8(%r14),%rdi
  712308:	xor    %r15d,%r15d
  71230b:	mov    0x30(%rsp),%r14d
  712310:	call   6f84e0 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::clear>
  712315:	mov    0x38(%rsp),%rsi
  71231a:	cmpb   $0x0,0x78d(%rsi)
  712321:	je     712355 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4555>
  712323:	xor    %r15d,%r15d
  712326:	lea    0x480(%rsp),%rdi
  71232e:	mov    0x310(%rsp),%rdx
  712336:	mov    0x2b8(%rsp),%rcx
  71233e:	call   70d850 <<gpui::runtime::Runtime<text_column_public_control::Model>>::acknowledge>
  712343:	mov    0x480(%rsp),%rax
  71234b:	cmp    $0xfffffffffffffffe,%rax
  71234f:	jne    712498 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4698>
  712355:	mov    0x48(%rsp),%rax
  71235a:	movq   $0xfffffffffffffffe,(%rax)
  712361:	cmpb   $0x0,0x58(%rsp)
  712366:	je     712375 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4575>
  712368:	lea    0x370(%rsp),%rdi
  712370:	call   6c74a0 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportBuild>>
  712375:	xor    %r13d,%r13d
  712378:	lea    0x338(%rsp),%rdi
  712380:	call   6c4400 <core::ptr::drop_glue::<alloc::collections::btree::set::BTreeSet<gpui::list::ListId>>>
  712385:	mov    0x140(%rsp),%rsi
  71238d:	test   %rsi,%rsi
  712390:	je     7123a9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x45a9>
  712392:	mov    0x148(%rsp),%rdi
  71239a:	shl    $0x2,%rsi
  71239e:	mov    $0x4,%edx
  7123a3:	call   *0x330457(%rip)        # a42800 <_DYNAMIC+0x268>
  7123a9:	mov    0x188(%rsp),%rsi
  7123b1:	test   %rsi,%rsi
  7123b4:	je     7123c9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x45c9>
  7123b6:	mov    0x190(%rsp),%rdi
  7123be:	mov    $0x1,%edx
  7123c3:	call   *0x330437(%rip)        # a42800 <_DYNAMIC+0x268>
  7123c9:	mov    0x228(%rsp),%rsi
  7123d1:	test   %rsi,%rsi
  7123d4:	je     7123ed <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x45ed>
  7123d6:	mov    0x230(%rsp),%rdi
  7123de:	shl    $0x4,%rsi
  7123e2:	mov    $0x4,%edx
  7123e7:	call   *0x330413(%rip)        # a42800 <_DYNAMIC+0x268>
  7123ed:	mov    0x210(%rsp),%rsi
  7123f5:	test   %rsi,%rsi
  7123f8:	je     712411 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4611>
  7123fa:	mov    0x218(%rsp),%rdi
  712402:	shl    $0x4,%rsi
  712406:	mov    $0x4,%edx
  71240b:	call   *0x3303ef(%rip)        # a42800 <_DYNAMIC+0x268>
  712411:	mov    0x1e8(%rsp),%rax
  712419:	test   %rax,%rax
  71241c:	je     712435 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4635>
  71241e:	mov    0x1f0(%rsp),%rdi
  712426:	imul   $0x38,%rax,%rsi
  71242a:	mov    $0x8,%edx
  71242f:	call   *0x3303cb(%rip)        # a42800 <_DYNAMIC+0x268>
  712435:	cmpq   $0x0,0x1b0(%rsp)
  71243e:	je     71244d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x464d>
  712440:	mov    0x1b8(%rsp),%rdi
  712448:	call   6c5ca0 <core::ptr::drop_glue::<gpui_canvas::text::TextShaper>>
  71244d:	test   %r12b,%r12b
  712450:	je     71246a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x466a>
  712452:	cmpq   $0xffffffffffffffff,0x160(%rsp)
  71245b:	je     71246a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x466a>
  71245d:	lea    0x160(%rsp),%rdi
  712465:	call   6c1730 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  71246a:	mov    0x118(%rsp),%rax
  712472:	test   %rax,%rax
  712475:	je     70f637 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1837>
  71247b:	lock decq (%rax)
  71247f:	jne    70f637 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1837>
  712485:	lea    0x118(%rsp),%rdi
  71248d:	call   *0x33043d(%rip)        # a428d0 <_DYNAMIC+0x338>
  712493:	jmp    70f637 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1837>
  712498:	mov    0x4a8(%rsp),%rcx
  7124a0:	movzbl 0x4b0(%rsp),%edx
  7124a8:	mov    0x4b1(%rsp),%esi
  7124af:	mov    %esi,0x80(%rsp)
  7124b6:	mov    0x4b4(%rsp),%esi
  7124bd:	mov    %esi,0x83(%rsp)
  7124c4:	movups 0x488(%rsp),%xmm0
  7124cc:	movups 0x498(%rsp),%xmm1
  7124d4:	mov    0x80(%rsp),%esi
  7124db:	mov    0x83(%rsp),%edi
  7124e2:	mov    0x48(%rsp),%r8
  7124e7:	mov    %edi,0x34(%r8)
  7124eb:	mov    %esi,0x31(%r8)
  7124ef:	mov    %rax,(%r8)
  7124f2:	movups %xmm0,0x8(%r8)
  7124f7:	movups %xmm1,0x18(%r8)
  7124fc:	mov    %rcx,0x28(%r8)
  712500:	mov    %dl,0x30(%r8)
  712504:	xor    %r13d,%r13d
  712507:	cmpb   $0x0,0x58(%rsp)
  71250c:	mov    0x40(%rsp),%ebx
  712510:	jne    7126a0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x48a0>
  712516:	jmp    7126ad <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x48ad>
  71251b:	movzbl 0x481(%rsp),%eax
  712523:	mov    0x48(%rsp),%rcx
  712528:	movq   $0x22,(%rcx)
  71252f:	mov    %al,0x8(%rcx)
  712532:	jmp    712685 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4885>
  712537:	mov    0x48(%rsp),%rax
  71253c:	movq   $0x1f,(%rax)
  712543:	jmp    70f637 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1837>
  712548:	mov    0xb0(%rsp),%rcx
  712550:	mov    0x48(%rsp),%rdx
  712555:	mov    %rcx,0x30(%rdx)
  712559:	movups 0x90(%rsp),%xmm0
  712561:	movups 0xa0(%rsp),%xmm1
  712569:	movups %xmm1,0x20(%rdx)
  71256d:	movups %xmm0,0x10(%rdx)
  712571:	mov    %rax,(%rdx)
  712574:	mov    0xe0(%rsp),%rax
  71257c:	mov    %rax,0x8(%rdx)
  712580:	jmp    712685 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4885>
  712585:	mov    0x4b0(%rsp),%rax
  71258d:	mov    0x48(%rsp),%rcx
  712592:	mov    %rax,0x30(%rcx)
  712596:	movups 0x480(%rsp),%xmm0
  71259e:	movups 0x490(%rsp),%xmm1
  7125a6:	movups 0x4a0(%rsp),%xmm2
  7125ae:	movups %xmm2,0x20(%rcx)
  7125b2:	movups %xmm1,0x10(%rcx)
  7125b6:	movups %xmm0,(%rcx)
  7125b9:	jmp    712685 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4885>
  7125be:	mov    0x30(%rsp),%rax
  7125c3:	mov    0x20(%rax,%r13,1),%esi
  7125c8:	lea    0x80(%rsp),%rdi
  7125d0:	lea    0x810(%rsp),%rdx
  7125d8:	call   6db3f0 <<gpui::runtime::Runtime<text_column_public_control::Input>>::present_inner::{closure#23}>
  7125dd:	mov    0xb0(%rsp),%rax
  7125e5:	mov    %rax,0x840(%rsp)
  7125ed:	movups 0x80(%rsp),%xmm0
  7125f5:	movups 0x90(%rsp),%xmm1
  7125fd:	movups 0xa0(%rsp),%xmm2
  712605:	movaps %xmm2,0x830(%rsp)
  71260d:	movaps %xmm1,0x820(%rsp)
  712615:	movaps %xmm0,0x810(%rsp)
  71261d:	mov    0x810(%rsp),%rax
  712625:	mov    0x838(%rsp),%rcx
  71262d:	mov    0x48(%rsp),%rdx
  712632:	mov    %rcx,0x28(%rdx)
  712636:	mov    0x840(%rsp),%rcx
  71263e:	mov    %rcx,0x30(%rdx)
  712642:	lea    0x818(%rsp),%rcx
  71264a:	movups (%rcx),%xmm0
  71264d:	movups 0x10(%rcx),%xmm1
  712651:	movups %xmm0,0x8(%rdx)
  712655:	movups %xmm1,0x18(%rdx)
  712659:	mov    %rax,(%rdx)
  71265c:	jmp    712685 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4885>
  71265e:	mov    0x48(%rsp),%rax
  712663:	movq   $0x18,(%rax)
  71266a:	jmp    712685 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4885>
  71266c:	mov    0x124(%rsp),%ecx
  712673:	mov    0x48(%rsp),%rdx
  712678:	movq   $0x23,(%rdx)
  71267f:	mov    %eax,0x8(%rdx)
  712682:	mov    %ecx,0xc(%rdx)
  712685:	lea    0x8b0(%rsp),%rdi
  71268d:	call   6c6240 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  712692:	mov    $0x1,%r12b
  712695:	mov    $0x1,%bl
  712697:	mov    $0x1,%r14b
  71269a:	mov    $0x1,%r13b
  71269d:	mov    $0x1,%bpl
  7126a0:	lea    0x370(%rsp),%rdi
  7126a8:	call   6c74a0 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportBuild>>
  7126ad:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  7126b6:	setne  %al
  7126b9:	mov    %r13d,%r15d
  7126bc:	test   %bl,%al
  7126be:	je     7126d0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x48d0>
  7126c0:	lea    0x7f8(%rsp),%rdi
  7126c8:	call   6c1520 <core::ptr::drop_glue::<alloc::vec::Vec<gpui_canvas::image::Image>>>
  7126cd:	mov    %r15d,%r13d
  7126d0:	cmpl   $0xffffffff,0x760(%rsp)
  7126d8:	je     7126ec <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x48ec>
  7126da:	test   %r14b,%r14b
  7126dd:	je     7126ec <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x48ec>
  7126df:	lea    0x760(%rsp),%rdi
  7126e7:	call   6c78e0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  7126ec:	lea    0x338(%rsp),%rdi
  7126f4:	call   6c4400 <core::ptr::drop_glue::<alloc::collections::btree::set::BTreeSet<gpui::list::ListId>>>
  7126f9:	mov    0x140(%rsp),%rsi
  712701:	test   %rsi,%rsi
  712704:	je     71271d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x491d>
  712706:	mov    0x148(%rsp),%rdi
  71270e:	shl    $0x2,%rsi
  712712:	mov    $0x4,%edx
  712717:	call   *0x3300e3(%rip)        # a42800 <_DYNAMIC+0x268>
  71271d:	mov    0x188(%rsp),%rsi
  712725:	test   %rsi,%rsi
  712728:	je     71273d <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x493d>
  71272a:	mov    0x190(%rsp),%rdi
  712732:	mov    $0x1,%edx
  712737:	call   *0x3300c3(%rip)        # a42800 <_DYNAMIC+0x268>
  71273d:	mov    0x228(%rsp),%rsi
  712745:	test   %rsi,%rsi
  712748:	je     712761 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4961>
  71274a:	mov    0x230(%rsp),%rdi
  712752:	shl    $0x4,%rsi
  712756:	mov    $0x4,%edx
  71275b:	call   *0x33009f(%rip)        # a42800 <_DYNAMIC+0x268>
  712761:	mov    0x210(%rsp),%rsi
  712769:	test   %rsi,%rsi
  71276c:	je     712785 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4985>
  71276e:	mov    0x218(%rsp),%rdi
  712776:	shl    $0x4,%rsi
  71277a:	mov    $0x4,%edx
  71277f:	call   *0x33007b(%rip)        # a42800 <_DYNAMIC+0x268>
  712785:	mov    0x1e8(%rsp),%rax
  71278d:	test   %rax,%rax
  712790:	je     7127a9 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x49a9>
  712792:	mov    0x1f0(%rsp),%rdi
  71279a:	imul   $0x38,%rax,%rsi
  71279e:	mov    $0x8,%edx
  7127a3:	call   *0x330057(%rip)        # a42800 <_DYNAMIC+0x268>
  7127a9:	test   %r13b,%r13b
  7127ac:	je     7127df <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x49df>
  7127ae:	mov    0x278(%rsp),%rsi
  7127b6:	test   %rsi,%rsi
  7127b9:	je     7127d2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x49d2>
  7127bb:	mov    0x280(%rsp),%rdi
  7127c3:	shl    $0x4,%rsi
  7127c7:	mov    $0x4,%edx
  7127cc:	call   *0x33002e(%rip)        # a42800 <_DYNAMIC+0x268>
  7127d2:	lea    0x1c0(%rsp),%rdi
  7127da:	call   6c13a0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  7127df:	mov    0x718(%rsp),%rax
  7127e7:	cmp    $0xfffffffffffffffe,%rax
  7127eb:	jne    70f204 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x1404>
  7127f1:	jmp    70f5c5 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x17c5>
  7127f6:	lea    -0x6c247f(%rip),%rdi        # 5037e <GCC_except_table0+0x10536>
  7127fd:	lea    0x311304(%rip),%rdx        # a23b08 <__frame_dummy_init_array_entry+0x1b18>
  712804:	mov    $0x83,%esi
  712809:	call   *0x330029(%rip)        # a42838 <_DYNAMIC+0x2a0>
  71280f:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  712814:	lea    -0x6c2737(%rip),%rdi        # 500e4 <GCC_except_table0+0x1029c>
  71281b:	lea    0x310dae(%rip),%rdx        # a235d0 <__frame_dummy_init_array_entry+0x15e0>
  712822:	mov    $0x1c,%esi
  712827:	call   *0x330173(%rip)        # a429a0 <_DYNAMIC+0x408>
  71282d:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  712832:	mov    $0x1,%bpl
  712835:	mov    $0x8,%edi
  71283a:	mov    $0x78,%esi
  71283f:	call   *0x32ffd3(%rip)        # a42818 <_DYNAMIC+0x280>
  712845:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  71284a:	lea    0x30ffa7(%rip),%rdi        # a227f8 <__frame_dummy_init_array_entry+0x808>
  712851:	call   *0x330049(%rip)        # a428a0 <_DYNAMIC+0x308>
  712857:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  71285c:	lea    0x3100e5(%rip),%rax        # a22948 <__frame_dummy_init_array_entry+0x958>
  712863:	jmp    712942 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b42>
  712868:	lea    0x30ff89(%rip),%rdi        # a227f8 <__frame_dummy_init_array_entry+0x808>
  71286f:	call   *0x33002b(%rip)        # a428a0 <_DYNAMIC+0x308>
  712875:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  71287a:	lea    0x3114a7(%rip),%rax        # a23d28 <__frame_dummy_init_array_entry+0x1d38>
  712881:	mov    %rax,0x2f8(%rsp)
  712889:	lea    -0x6c24d1(%rip),%rdi        # 503bf <GCC_except_table0+0x10577>
  712890:	mov    $0x1e,%esi
  712895:	mov    0x2f8(%rsp),%rdx
  71289d:	call   *0x3300fd(%rip)        # a429a0 <_DYNAMIC+0x408>
  7128a3:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  7128a8:	mov    0x490(%rsp),%rsi
  7128b0:	mov    $0x1,%bpl
  7128b3:	call   *0x32ffd7(%rip)        # a42890 <_DYNAMIC+0x2f8>
  7128b9:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  7128be:	mov    0x490(%rsp),%rsi
  7128c6:	call   *0x32ffc4(%rip)        # a42890 <_DYNAMIC+0x2f8>
  7128cc:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  7128d1:	mov    0x490(%rsp),%rsi
  7128d9:	call   *0x32ffb1(%rip)        # a42890 <_DYNAMIC+0x2f8>
  7128df:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  7128e4:	mov    0x490(%rsp),%rsi
  7128ec:	call   *0x32ff9e(%rip)        # a42890 <_DYNAMIC+0x2f8>
  7128f2:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  7128f7:	mov    0x490(%rsp),%rsi
  7128ff:	call   *0x32ff8b(%rip)        # a42890 <_DYNAMIC+0x2f8>
  712905:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  71290a:	mov    0x490(%rsp),%rsi
  712912:	call   *0x32ff78(%rip)        # a42890 <_DYNAMIC+0x2f8>
  712918:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  71291d:	lea    -0x6c25a6(%rip),%rdi        # 5037e <GCC_except_table0+0x10536>
  712924:	lea    0x3111dd(%rip),%rdx        # a23b08 <__frame_dummy_init_array_entry+0x1b18>
  71292b:	mov    $0x83,%esi
  712930:	call   *0x32ff02(%rip)        # a42838 <_DYNAMIC+0x2a0>
  712936:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  71293b:	lea    0x3113fe(%rip),%rax        # a23d40 <__frame_dummy_init_array_entry+0x1d50>
  712942:	mov    %rax,0x250(%rsp)
  71294a:	mov    0x250(%rsp),%rdi
  712952:	call   *0x32ff48(%rip)        # a428a0 <_DYNAMIC+0x308>
  712958:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  71295d:	lea    0x31131c(%rip),%rdi        # a23c80 <__frame_dummy_init_array_entry+0x1c90>
  712964:	call   *0x32ff36(%rip)        # a428a0 <_DYNAMIC+0x308>
  71296a:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  71296f:	lea    0x30feca(%rip),%rax        # a22840 <__frame_dummy_init_array_entry+0x850>
  712976:	jmp    712a2a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c2a>
  71297b:	lea    0x30fe8e(%rip),%rdi        # a22810 <__frame_dummy_init_array_entry+0x820>
  712982:	call   *0x32ff18(%rip)        # a428a0 <_DYNAMIC+0x308>
  712988:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  71298d:	lea    0x30fe7c(%rip),%rdi        # a22810 <__frame_dummy_init_array_entry+0x820>
  712994:	call   *0x32ff06(%rip)        # a428a0 <_DYNAMIC+0x308>
  71299a:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  71299f:	lea    0x3113b2(%rip),%rax        # a23d58 <__frame_dummy_init_array_entry+0x1d68>
  7129a6:	jmp    712942 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4b42>
  7129a8:	lea    0x311231(%rip),%rax        # a23be0 <__frame_dummy_init_array_entry+0x1bf0>
  7129af:	jmp    712a2a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c2a>
  7129b1:	lea    0x311240(%rip),%rax        # a23bf8 <__frame_dummy_init_array_entry+0x1c08>
  7129b8:	jmp    712a2a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c2a>
  7129ba:	lea    0x3112a7(%rip),%rcx        # a23c68 <__frame_dummy_init_array_entry+0x1c78>
  7129c1:	xor    %edi,%edi
  7129c3:	mov    0x178(%rsp),%rsi
  7129cb:	call   *0x32ffef(%rip)        # a429c0 <_DYNAMIC+0x428>
  7129d1:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  7129d6:	lea    0x310a23(%rip),%rax        # a23400 <__frame_dummy_init_array_entry+0x1410>
  7129dd:	jmp    712a2a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c2a>
  7129df:	lea    0x310a02(%rip),%rax        # a233e8 <__frame_dummy_init_array_entry+0x13f8>
  7129e6:	jmp    712a2a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c2a>
  7129e8:	mov    %rbx,%rbp
  7129eb:	lea    0x310a0e(%rip),%rax        # a23400 <__frame_dummy_init_array_entry+0x1410>
  7129f2:	jmp    712a2a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c2a>
  7129f4:	mov    %rax,%rbp
  7129f7:	jmp    712a23 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c23>
  7129f9:	mov    %rbx,%rbp
  7129fc:	lea    0x3109e5(%rip),%rax        # a233e8 <__frame_dummy_init_array_entry+0x13f8>
  712a03:	jmp    712a2a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c2a>
  712a05:	mov    %rax,%r13
  712a08:	lea    0x3109d9(%rip),%rax        # a233e8 <__frame_dummy_init_array_entry+0x13f8>
  712a0f:	jmp    712a2a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c2a>
  712a11:	mov    %rax,%r13
  712a14:	lea    0x3109e5(%rip),%rax        # a23400 <__frame_dummy_init_array_entry+0x1410>
  712a1b:	jmp    712a2a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4c2a>
  712a1d:	mov    %rcx,%rbp
  712a20:	mov    %rax,%r13
  712a23:	lea    0x3109ee(%rip),%rax        # a23418 <__frame_dummy_init_array_entry+0x1428>
  712a2a:	mov    %rax,0x60(%rsp)
  712a2f:	mov    %rbp,%rdi
  712a32:	mov    %r13,%rsi
  712a35:	mov    0x60(%rsp),%rdx
  712a3a:	call   *0x32fdf0(%rip)        # a42830 <_DYNAMIC+0x298>
  712a40:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  712a45:	mov    $0x1,%r12b
  712a48:	lea    0x3111d9(%rip),%rdx        # a23c28 <__frame_dummy_init_array_entry+0x1c38>
  712a4f:	mov    $0x1,%bpl
  712a52:	xor    %edi,%edi
  712a54:	xor    %esi,%esi
  712a56:	call   *0x32fdd4(%rip)        # a42830 <_DYNAMIC+0x298>
  712a5c:	jmp    712b3a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d3a>
  712a61:	mov    %rsi,%rcx
  712a64:	lea    0x31125d(%rip),%rax        # a23cc8 <__frame_dummy_init_array_entry+0x1cd8>
  712a6b:	jmp    712b22 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d22>
  712a70:	mov    %rsi,%rcx
  712a73:	lea    0x311266(%rip),%rax        # a23ce0 <__frame_dummy_init_array_entry+0x1cf0>
  712a7a:	jmp    712b22 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d22>
  712a7f:	mov    %rsi,%rcx
  712a82:	lea    0x31126f(%rip),%rax        # a23cf8 <__frame_dummy_init_array_entry+0x1d08>
  712a89:	jmp    712b22 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d22>
  712a8e:	mov    %rbx,0x50(%rsp)
  712a93:	mov    %rsi,%rcx
  712a96:	lea    0x30fe7b(%rip),%rax        # a22918 <__frame_dummy_init_array_entry+0x928>
  712a9d:	jmp    712b22 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d22>
  712aa2:	mov    %rax,0x50(%rsp)
  712aa7:	lea    0x30fe82(%rip),%rax        # a22930 <__frame_dummy_init_array_entry+0x940>
  712aae:	jmp    712b22 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d22>
  712ab0:	mov    %rax,0x50(%rsp)
  712ab5:	lea    0x30fea4(%rip),%rax        # a22960 <__frame_dummy_init_array_entry+0x970>
  712abc:	jmp    712b22 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d22>
  712abe:	mov    %rax,0x50(%rsp)
  712ac3:	lea    0x30feae(%rip),%rax        # a22978 <__frame_dummy_init_array_entry+0x988>
  712aca:	jmp    712b22 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d22>
  712acc:	mov    %rbx,0x50(%rsp)
  712ad1:	lea    0x30fed0(%rip),%rax        # a229a8 <__frame_dummy_init_array_entry+0x9b8>
  712ad8:	jmp    712b22 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d22>
  712ada:	lea    0x31091f(%rip),%rax        # a23400 <__frame_dummy_init_array_entry+0x1410>
  712ae1:	jmp    712b22 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d22>
  712ae3:	mov    %rax,0x50(%rsp)
  712ae8:	lea    0x310929(%rip),%rax        # a23418 <__frame_dummy_init_array_entry+0x1428>
  712aef:	jmp    712b22 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d22>
  712af1:	lea    0x3108f0(%rip),%rax        # a233e8 <__frame_dummy_init_array_entry+0x13f8>
  712af8:	jmp    712b22 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d22>
  712afa:	mov    %rax,0x50(%rsp)
  712aff:	lea    0x30fd9a(%rip),%rax        # a228a0 <__frame_dummy_init_array_entry+0x8b0>
  712b06:	jmp    712b22 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d22>
  712b08:	mov    %rax,0x50(%rsp)
  712b0d:	lea    0x30fe7c(%rip),%rax        # a22990 <__frame_dummy_init_array_entry+0x9a0>
  712b14:	jmp    712b22 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4d22>
  712b16:	mov    %rax,0x50(%rsp)
  712b1b:	lea    0x30fe9e(%rip),%rax        # a229c0 <__frame_dummy_init_array_entry+0x9d0>
  712b22:	mov    %rax,0x70(%rsp)
  712b27:	mov    0x50(%rsp),%rdi
  712b2c:	mov    %rcx,%rsi
  712b2f:	mov    0x70(%rsp),%rdx
  712b34:	call   *0x32fcf6(%rip)        # a42830 <_DYNAMIC+0x298>
  712b3a:	ud2
  712b3c:	mov    %rax,%rbx
  712b3f:	mov    0x90(%rsp),%rax
  712b47:	mov    %rax,0x170(%rsp)
  712b4f:	movaps 0x80(%rsp),%xmm0
  712b57:	movaps %xmm0,0x160(%rsp)
  712b5f:	jmp    712fc3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x51c3>
  712b64:	mov    %rax,%rbx
  712b67:	mov    0x0(%r13),%rax
  712b6b:	movaps 0x410(%rsp),%xmm0
  712b73:	movups %xmm0,0xb0(%rax)
  712b7a:	movaps 0x400(%rsp),%xmm0
  712b82:	movups %xmm0,0xa0(%rax)
  712b89:	movaps 0x3c0(%rsp),%xmm0
  712b91:	movaps 0x3d0(%rsp),%xmm1
  712b99:	movaps 0x3e0(%rsp),%xmm2
  712ba1:	movapd 0x3f0(%rsp),%xmm3
  712baa:	movupd %xmm3,0x90(%rax)
  712bb2:	movups %xmm2,0x80(%rax)
  712bb9:	movups %xmm1,0x70(%rax)
  712bbd:	movups %xmm0,0x60(%rax)
  712bc1:	jmp    712c42 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4e42>
  712bc3:	mov    %rax,%rbx
  712bc6:	mov    0x708(%r14),%rax
  712bcd:	mov    0x490(%rsp),%rcx
  712bd5:	mov    %rcx,0x28(%rax)
  712bd9:	movaps 0x480(%rsp),%xmm0
  712be1:	movups %xmm0,0x18(%rax)
  712be5:	mov    $0x1,%r15b
  712be8:	xor    %r12d,%r12d
  712beb:	jmp    712edd <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x50dd>
  712bf0:	mov    %rax,%rbx
  712bf3:	lea    0x3d8(%rsp),%rdi
  712bfb:	call   6c1900 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::metadata::TextSlot>>>
  712c00:	lea    0x3f0(%rsp),%rdi
  712c08:	call   6c1900 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::metadata::TextSlot>>>
  712c0d:	lea    0x3c0(%rsp),%rdi
  712c15:	call   6c74f0 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportColumn>>
  712c1a:	mov    0x408(%rsp),%rax
  712c22:	test   %rax,%rax
  712c25:	je     712c42 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4e42>
  712c27:	mov    0x410(%rsp),%rdi
  712c2f:	shl    $0x3,%rax
  712c33:	lea    (%rax,%rax,2),%rsi
  712c37:	mov    $0x8,%edx
  712c3c:	call   *0x32fbbe(%rip)        # a42800 <_DYNAMIC+0x268>
  712c42:	mov    $0x1,%r12b
  712c45:	movl   $0x0,0x58(%rsp)
  712c4d:	mov    $0x1,%al
  712c4f:	mov    %eax,0x40(%rsp)
  712c53:	movl   $0x0,0x30(%rsp)
  712c5b:	mov    $0x1,%r15b
  712c5e:	jmp    712dca <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4fca>
  712c63:	mov    %rax,%rbx
  712c66:	mov    0x708(%r14),%rax
  712c6d:	movq   $0x0,0x30(%rax)
  712c75:	xor    %r15d,%r15d
  712c78:	jmp    712edd <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x50dd>
  712c7d:	mov    %rax,%rbx
  712c80:	lea    0x480(%rsp),%rsi
  712c88:	mov    $0x1e8,%edx
  712c8d:	mov    %r15,%rdi
  712c90:	call   *0x32fb8a(%rip)        # a42820 <memcpy@GLIBC_2.14>
  712c96:	mov    $0x1,%al
  712c98:	mov    %eax,0x58(%rsp)
  712c9c:	xor    %ebp,%ebp
  712c9e:	mov    $0x1,%r12b
  712ca1:	mov    $0x1,%al
  712ca3:	mov    %eax,0x40(%rsp)
  712ca7:	mov    $0x1,%al
  712ca9:	mov    %eax,0x30(%rsp)
  712cad:	mov    $0x1,%r15b
  712cb0:	jmp    712dca <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4fca>
  712cb5:	mov    %rax,%rbx
  712cb8:	jmp    712ecf <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x50cf>
  712cbd:	mov    %rbx,%rcx
  712cc0:	mov    %rax,%rbx
  712cc3:	mov    0x490(%rsp),%rax
  712ccb:	mov    %rax,0x10(%r15)
  712ccf:	movaps 0x480(%rsp),%xmm0
  712cd7:	movups %xmm0,(%r15)
  712cdb:	mov    0x38(%rsp),%rax
  712ce0:	mov    0x50(%rsp),%rdx
  712ce5:	mov    %rdx,0x610(%rax)
  712cec:	mov    %cx,0x618(%rax)
  712cf3:	mov    0x15c(%rsp),%ecx
  712cfa:	mov    %cx,0x61a(%rax)
  712d01:	movss  0x7c(%rsp),%xmm0
  712d07:	movss  %xmm0,0x61c(%rax)
  712d0f:	xor    %r15d,%r15d
  712d12:	jmp    712edd <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x50dd>
  712d17:	mov    %rax,%rbx
  712d1a:	mov    $0x1,%r12b
  712d1d:	jmp    712d51 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4f51>
  712d1f:	mov    %rax,%rbx
  712d22:	mov    %rbp,%rdi
  712d25:	call   6bf630 <core::ptr::drop_glue::<core::option::Option<gpui::shared_text::SharedText>>>
  712d2a:	jmp    712fc3 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x51c3>
  712d2f:	mov    %rax,%rbx
  712d32:	mov    $0x1,%r12b
  712d35:	test   %r15,%r15
  712d38:	je     712d51 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x4f51>
  712d3a:	shl    $0x4,%r15
  712d3e:	mov    $0x4,%edx
  712d43:	mov    0x40(%rsp),%rdi
  712d48:	mov    %r15,%rsi
  712d4b:	call   *0x32faaf(%rip)        # a42800 <_DYNAMIC+0x268>
  712d51:	mov    $0x1,%al
  712d53:	mov    %eax,0x40(%rsp)
  712d57:	mov    $0x1,%r15b
  712d5a:	xor    %r13d,%r13d
  712d5d:	cmpb   $0x0,0x58(%rsp)
  712d62:	je     712f28 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5128>
  712d68:	jmp    712fe8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x51e8>
  712d6d:	mov    %rax,%rbx
  712d70:	mov    $0x1,%r12b
  712d73:	mov    $0x1,%al
  712d75:	mov    %eax,0x40(%rsp)
  712d79:	mov    $0x1,%al
  712d7b:	mov    %eax,0x30(%rsp)
  712d7f:	mov    $0x1,%r13b
  712d82:	mov    $0x1,%r15b
  712d85:	mov    $0x1,%bpl
  712d88:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  712d91:	jne    713000 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5200>
  712d97:	jmp    713014 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5214>
  712d9c:	mov    %r14d,0x30(%rsp)
  712da1:	mov    %rax,%rbx
  712da4:	mov    %r15d,%r13d
  712da7:	jmp    713014 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5214>
  712dac:	mov    %rax,%rbx
  712daf:	mov    $0x1,%al
  712db1:	mov    %eax,0x58(%rsp)
  712db5:	mov    $0x1,%r12b
  712db8:	mov    $0x1,%al
  712dba:	mov    %eax,0x40(%rsp)
  712dbe:	mov    $0x1,%al
  712dc0:	mov    %eax,0x30(%rsp)
  712dc4:	mov    $0x1,%r15b
  712dc7:	mov    $0x1,%bpl
  712dca:	movb   $0x1,0x100(%rsp)
  712dd2:	jmp    712edd <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x50dd>
  712dd7:	mov    %rax,%rbx
  712dda:	mov    %r13d,%r15d
  712ddd:	jmp    71303f <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x523f>
  712de2:	mov    %r14d,0x30(%rsp)
  712de7:	mov    %rax,%rbx
  712dea:	jmp    712edd <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x50dd>
  712def:	mov    %rax,%rbx
  712df2:	mov    %r13d,%r15d
  712df5:	jmp    713032 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5232>
  712dfa:	mov    %rax,%rbx
  712dfd:	add    $0x38,%r15
  712e01:	mov    %r15,%rdi
  712e04:	call   6c5ef0 <core::ptr::drop_glue::<gpui_canvas::text::RasterCache>>
  712e09:	jmp    712e39 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5039>
  712e0b:	call   *0x32fa17(%rip)        # a42828 <_DYNAMIC+0x290>
  712e11:	jmp    712fc0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x51c0>
  712e16:	mov    %rax,%rbx
  712e19:	mov    $0x1,%bpl
  712e1c:	mov    $0x1,%r15b
  712e1f:	mov    $0x1,%r13b
  712e22:	mov    $0x1,%al
  712e24:	mov    %eax,0x30(%rsp)
  712e28:	mov    $0x1,%al
  712e2a:	mov    %eax,0x40(%rsp)
  712e2e:	mov    $0x1,%r12b
  712e31:	jmp    712fe8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x51e8>
  712e36:	mov    %rax,%rbx
  712e39:	mov    0x38(%rsp),%rax
  712e3e:	mov    0x708(%rax),%rax
  712e45:	mov    %r12,0x30(%rax)
  712e49:	mov    %r14d,0x38(%rax)
  712e4d:	mov    %ebp,0x3c(%rax)
  712e50:	movaps 0x8b0(%rsp),%xmm0
  712e58:	movaps 0x8c0(%rsp),%xmm1
  712e60:	movaps 0x8d0(%rsp),%xmm2
  712e68:	movups %xmm0,0x40(%rax)
  712e6c:	movups %xmm1,0x50(%rax)
  712e70:	movups %xmm2,0x60(%rax)
  712e74:	mov    0x8e0(%rsp),%rcx
  712e7c:	mov    %rcx,0x70(%rax)
  712e80:	mov    $0x1,%bpl
  712e83:	jmp    7131a2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x53a2>
  712e88:	mov    %rax,%rbx
  712e8b:	jmp    713181 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5381>
  712e90:	mov    %rax,%rbx
  712e93:	lea    0x480(%rsp),%rsi
  712e9b:	mov    $0x298,%edx
  712ea0:	mov    %r14,%rdi
  712ea3:	call   *0x32f977(%rip)        # a42820 <memcpy@GLIBC_2.14>
  712ea9:	jmp    713146 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5346>
  712eae:	mov    %rax,%rbx
  712eb1:	jmp    713164 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5364>
  712eb6:	jmp    712fc0 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x51c0>
  712ebb:	ud2
  712ebd:	ud2
  712ebf:	mov    %rax,%rbx
  712ec2:	lea    0x7f8(%rsp),%rdi
  712eca:	call   6c1520 <core::ptr::drop_glue::<alloc::vec::Vec<gpui_canvas::image::Image>>>
  712ecf:	mov    $0x1,%r12b
  712ed2:	movl   $0x0,0x40(%rsp)
  712eda:	mov    $0x1,%r15b
  712edd:	mov    0xc0(%rsp),%rsi
  712ee5:	test   %rsi,%rsi
  712ee8:	setg   %al
  712eeb:	test   %al,0x100(%rsp)
  712ef2:	je     712f1a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x511a>
  712ef4:	mov    0xc8(%rsp),%rdi
  712efc:	shl    $0x4,%rsi
  712f00:	mov    $0x4,%edx
  712f05:	call   *0x32f8f5(%rip)        # a42800 <_DYNAMIC+0x268>
  712f0b:	xor    %r13d,%r13d
  712f0e:	cmpb   $0x0,0x58(%rsp)
  712f13:	je     712f28 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5128>
  712f15:	jmp    712fe8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x51e8>
  712f1a:	xor    %r13d,%r13d
  712f1d:	cmpb   $0x0,0x58(%rsp)
  712f22:	jne    712fe8 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x51e8>
  712f28:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  712f31:	jne    713000 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5200>
  712f37:	jmp    713014 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5214>
  712f3c:	jmp    713143 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5343>
  712f41:	jmp    713143 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5343>
  712f46:	jmp    713143 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5343>
  712f4b:	mov    %rax,%rbx
  712f4e:	mov    $0x1,%r12b
  712f51:	mov    $0x1,%r13b
  712f54:	mov    $0x1,%r15b
  712f57:	mov    $0x1,%bpl
  712f5a:	jmp    713063 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5263>
  712f5f:	mov    %rax,%rbx
  712f62:	mov    $0x1,%r12b
  712f65:	mov    $0x1,%r13b
  712f68:	mov    $0x1,%r15b
  712f6b:	mov    $0x1,%bpl
  712f6e:	jmp    713083 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5283>
  712f73:	mov    %rax,%rbx
  712f76:	mov    $0x1,%r12b
  712f79:	mov    $0x1,%r13b
  712f7c:	mov    $0x1,%r15b
  712f7f:	mov    $0x1,%bpl
  712f82:	jmp    7130a7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x52a7>
  712f87:	mov    %rax,%rbx
  712f8a:	mov    $0x1,%r12b
  712f8d:	mov    $0x1,%r13b
  712f90:	mov    $0x1,%r15b
  712f93:	mov    $0x1,%bpl
  712f96:	jmp    7130cb <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x52cb>
  712f9b:	mov    %rax,%rbx
  712f9e:	mov    $0x1,%bpl
  712fa1:	mov    $0x1,%r15b
  712fa4:	mov    $0x1,%r12b
  712fa7:	jmp    7130f4 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x52f4>
  712fac:	mov    %rax,%rbx
  712faf:	jmp    71312a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x532a>
  712fb4:	ud2
  712fb6:	ud2
  712fb8:	mov    %rax,%rbx
  712fbb:	jmp    7131a2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x53a2>
  712fc0:	mov    %rax,%rbx
  712fc3:	mov    $0x1,%bpl
  712fc6:	lea    0x8b0(%rsp),%rdi
  712fce:	call   6c6240 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  712fd3:	mov    $0x1,%r15b
  712fd6:	mov    $0x1,%r13b
  712fd9:	mov    $0x1,%al
  712fdb:	mov    %eax,0x30(%rsp)
  712fdf:	mov    $0x1,%al
  712fe1:	mov    %eax,0x40(%rsp)
  712fe5:	mov    $0x1,%r12b
  712fe8:	lea    0x370(%rsp),%rdi
  712ff0:	call   6c74a0 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportBuild>>
  712ff5:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  712ffe:	je     713014 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5214>
  713000:	cmpb   $0x0,0x40(%rsp)
  713005:	je     713014 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5214>
  713007:	lea    0x7f8(%rsp),%rdi
  71300f:	call   6c1520 <core::ptr::drop_glue::<alloc::vec::Vec<gpui_canvas::image::Image>>>
  713014:	cmpl   $0xffffffff,0x760(%rsp)
  71301c:	je     713032 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5232>
  71301e:	cmpb   $0x0,0x30(%rsp)
  713023:	je     713032 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5232>
  713025:	lea    0x760(%rsp),%rdi
  71302d:	call   6c78e0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  713032:	lea    0x338(%rsp),%rdi
  71303a:	call   6c4400 <core::ptr::drop_glue::<alloc::collections::btree::set::BTreeSet<gpui::list::ListId>>>
  71303f:	mov    0x140(%rsp),%rsi
  713047:	test   %rsi,%rsi
  71304a:	je     713063 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5263>
  71304c:	mov    0x148(%rsp),%rdi
  713054:	shl    $0x2,%rsi
  713058:	mov    $0x4,%edx
  71305d:	call   *0x32f79d(%rip)        # a42800 <_DYNAMIC+0x268>
  713063:	mov    0x188(%rsp),%rsi
  71306b:	test   %rsi,%rsi
  71306e:	je     713083 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5283>
  713070:	mov    0x190(%rsp),%rdi
  713078:	mov    $0x1,%edx
  71307d:	call   *0x32f77d(%rip)        # a42800 <_DYNAMIC+0x268>
  713083:	mov    0x228(%rsp),%rsi
  71308b:	test   %rsi,%rsi
  71308e:	je     7130a7 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x52a7>
  713090:	mov    0x230(%rsp),%rdi
  713098:	shl    $0x4,%rsi
  71309c:	mov    $0x4,%edx
  7130a1:	call   *0x32f759(%rip)        # a42800 <_DYNAMIC+0x268>
  7130a7:	mov    0x210(%rsp),%rsi
  7130af:	test   %rsi,%rsi
  7130b2:	je     7130cb <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x52cb>
  7130b4:	mov    0x218(%rsp),%rdi
  7130bc:	shl    $0x4,%rsi
  7130c0:	mov    $0x4,%edx
  7130c5:	call   *0x32f735(%rip)        # a42800 <_DYNAMIC+0x268>
  7130cb:	mov    0x1e8(%rsp),%rax
  7130d3:	test   %rax,%rax
  7130d6:	je     7130ef <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x52ef>
  7130d8:	mov    0x1f0(%rsp),%rdi
  7130e0:	imul   $0x38,%rax,%rsi
  7130e4:	mov    $0x8,%edx
  7130e9:	call   *0x32f711(%rip)        # a42800 <_DYNAMIC+0x268>
  7130ef:	test   %r13b,%r13b
  7130f2:	je     713118 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5318>
  7130f4:	mov    0x278(%rsp),%rsi
  7130fc:	test   %rsi,%rsi
  7130ff:	je     713118 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5318>
  713101:	mov    0x280(%rsp),%rdi
  713109:	shl    $0x4,%rsi
  71310d:	mov    $0x4,%edx
  713112:	call   *0x32f6e8(%rip)        # a42800 <_DYNAMIC+0x268>
  713118:	test   %r15b,%r15b
  71311b:	je     71312a <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x532a>
  71311d:	lea    0x1c0(%rsp),%rdi
  713125:	call   6c13a0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  71312a:	cmpl   $0xfffffffe,0x718(%rsp)
  713132:	je     71314c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x534c>
  713134:	lea    0x718(%rsp),%rdi
  71313c:	call   6c5550 <core::ptr::drop_glue::<gpui::runtime::Error>>
  713141:	jmp    71314c <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x534c>
  713143:	mov    %rax,%rbx
  713146:	mov    $0x1,%r12b
  713149:	mov    $0x1,%bpl
  71314c:	cmpq   $0x0,0x1b0(%rsp)
  713155:	je     713164 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5364>
  713157:	mov    0x1b8(%rsp),%rdi
  71315f:	call   6c5ca0 <core::ptr::drop_glue::<gpui_canvas::text::TextShaper>>
  713164:	test   %r12b,%r12b
  713167:	je     713181 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5381>
  713169:	cmpq   $0xffffffffffffffff,0x160(%rsp)
  713172:	je     713181 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x5381>
  713174:	lea    0x160(%rsp),%rdi
  71317c:	call   6c1730 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  713181:	mov    0x118(%rsp),%rax
  713189:	test   %rax,%rax
  71318c:	je     7131a2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x53a2>
  71318e:	lock decq (%rax)
  713192:	jne    7131a2 <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x53a2>
  713194:	lea    0x118(%rsp),%rdi
  71319c:	call   *0x32f72e(%rip)        # a428d0 <_DYNAMIC+0x338>
  7131a2:	cmpl   $0x2,0xbd0(%rsp)
  7131aa:	je     7131be <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x53be>
  7131ac:	test   %bpl,%bpl
  7131af:	je     7131be <<gpui::runtime::Runtime<text_column_public_control::Model>>::present_inner+0x53be>
  7131b1:	lea    0xbd0(%rsp),%rdi
  7131b9:	call   6c6240 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  7131be:	mov    %rbx,%rdi
  7131c1:	call   a20c40 <_Unwind_Resume@plt>
  7131c6:	call   *0x32f65c(%rip)        # a42828 <_DYNAMIC+0x290>

<gpui::runtime::text_geometry::TextResources>::acknowledge code=71 fixed_stack=24

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

000000000072e940 <<gpui::runtime::text_geometry::TextResources>::acknowledge>:
  72e940:	push   %r15
  72e942:	push   %r14
  72e944:	push   %rbx
  72e945:	mov    0x18(%rdi),%r14
  72e949:	movq   $0xffffffffffffffff,0x18(%rdi)
  72e951:	cmp    $0xffffffffffffffff,%r14
  72e955:	je     72e96e <<gpui::runtime::text_geometry::TextResources>::acknowledge+0x2e>
  72e957:	mov    %rdi,%rbx
  72e95a:	lea    0x20(%rdi),%r15
  72e95e:	call   72aa50 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  72e963:	mov    %r14,(%rbx)
  72e966:	movups (%r15),%xmm0
  72e96a:	movups %xmm0,0x8(%rbx)
  72e96e:	pop    %rbx
  72e96f:	pop    %r14
  72e971:	pop    %r15
  72e973:	ret
  72e974:	mov    %r14,(%rbx)
  72e977:	movups (%r15),%xmm0
  72e97b:	movups %xmm0,0x8(%rbx)
  72e97f:	mov    %rax,%rdi
  72e982:	call   a20c40 <_Unwind_Resume@plt>

<gpui::runtime::geometry::Geometry>::acknowledge code=76 fixed_stack=24

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

00000000007356c0 <<gpui::runtime::geometry::Geometry>::acknowledge>:
  7356c0:	push   %r15
  7356c2:	push   %r14
  7356c4:	push   %rbx
  7356c5:	mov    0x30(%rdi),%r14
  7356c9:	movq   $0xffffffffffffffff,0x30(%rdi)
  7356d1:	cmp    $0xffffffffffffffff,%r14
  7356d5:	je     735706 <<gpui::runtime::geometry::Geometry>::acknowledge+0x46>
  7356d7:	mov    %rdi,%rbx
  7356da:	lea    0x38(%rdi),%r15
  7356de:	mov    0x18(%rdi),%rsi
  7356e2:	test   %rsi,%rsi
  7356e5:	je     7356fa <<gpui::runtime::geometry::Geometry>::acknowledge+0x3a>
  7356e7:	mov    0x20(%rbx),%rdi
  7356eb:	shl    $0x4,%rsi
  7356ef:	mov    $0x4,%edx
  7356f4:	call   *0x30d106(%rip)        # a42800 <_DYNAMIC+0x268>
  7356fa:	mov    %r14,0x18(%rbx)
  7356fe:	movups (%r15),%xmm0
  735702:	movups %xmm0,0x20(%rbx)
  735706:	pop    %rbx
  735707:	pop    %r14
  735709:	pop    %r15
  73570b:	ret

gpui::runtime::text_geometry::append code=731 fixed_stack=120

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

0000000000738fe0 <gpui::runtime::text_geometry::append>:
  738fe0:	push   %rbp
  738fe1:	push   %r15
  738fe3:	push   %r14
  738fe5:	push   %r13
  738fe7:	push   %r12
  738fe9:	push   %rbx
  738fea:	sub    $0x48,%rsp
  738fee:	movss  %xmm1,0x4(%rsp)
  738ff4:	movd   %xmm0,0x8(%rsp)
  738ffa:	mov    %r9d,%ebp
  738ffd:	mov    %rdi,%rbx
  739000:	mov    0x80(%rsp),%r12
  739008:	mov    (%rdi),%rax
  73900b:	cmp    $0xffffffffffffffff,%rax
  73900f:	jne    739158 <gpui::runtime::text_geometry::append+0x178>
  739015:	mov    %rdx,%r13
  739018:	mov    %rsi,%r15
  73901b:	cmp    %rdx,%r8
  73901e:	jae    739060 <gpui::runtime::text_geometry::append+0x80>
  739020:	lea    (%r8,%r8,2),%rax
  739024:	cmp    %ebp,0x10(%r15,%rax,8)
  739029:	jne    739060 <gpui::runtime::text_geometry::append+0x80>
  73902b:	movd   0x8(%rsp),%xmm0
  739031:	movd   %xmm0,%edx
  739035:	lea    (%r15,%rax,8),%rax
  739039:	cmp    %edx,0x8(%rax)
  73903c:	jne    739060 <gpui::runtime::text_geometry::append+0x80>
  73903e:	movd   0x4(%rsp),%xmm0
  739044:	movd   %xmm0,%edx
  739048:	cmp    %edx,0xc(%rax)
  73904b:	jne    739060 <gpui::runtime::text_geometry::append+0x80>
  73904d:	mov    0x20(%r12),%rdx
  739052:	test   %rdx,%rdx
  739055:	je     739060 <gpui::runtime::text_geometry::append+0x80>
  739057:	cmp    %rdx,(%rax)
  73905a:	je     7391ed <gpui::runtime::text_geometry::append+0x20d>
  739060:	cmp    %r13,%rcx
  739063:	mov    %r13,%r14
  739066:	cmovb  %rcx,%r14
  73906a:	test   %r14,%r14
  73906d:	je     7390b2 <gpui::runtime::text_geometry::append+0xd2>
  73906f:	mov    %ebp,0xc(%rsp)
  739073:	mov    %rcx,0x40(%rsp)
  739078:	mov    %r8,%rbp
  73907b:	lea    0x0(,%r14,8),%rax
  739083:	lea    (%rax,%rax,2),%r12
  739087:	call   *0x30977b(%rip)        # a42808 <_DYNAMIC+0x270>
  73908d:	mov    $0x8,%esi
  739092:	mov    %r12,%rdi
  739095:	call   *0x309775(%rip)        # a42810 <_DYNAMIC+0x278>
  73909b:	test   %rax,%rax
  73909e:	je     739263 <gpui::runtime::text_geometry::append+0x283>
  7390a4:	mov    %rbp,%r8
  7390a7:	mov    0x40(%rsp),%rcx
  7390ac:	mov    0xc(%rsp),%ebp
  7390b0:	jmp    7390b7 <gpui::runtime::text_geometry::append+0xd7>
  7390b2:	mov    $0x8,%eax
  7390b7:	mov    %r14,0x10(%rsp)
  7390bc:	mov    %rax,0x18(%rsp)
  7390c1:	movq   $0x0,0x20(%rsp)
  7390ca:	cmp    %r13,%r8
  7390cd:	ja     73921d <gpui::runtime::text_geometry::append+0x23d>
  7390d3:	cmp    %r8,%rcx
  7390d6:	mov    0x80(%rsp),%r12
  7390de:	jb     739234 <gpui::runtime::text_geometry::append+0x254>
  7390e4:	xor    %ecx,%ecx
  7390e6:	test   %r8,%r8
  7390e9:	je     739138 <gpui::runtime::text_geometry::append+0x158>
  7390eb:	lea    (%rcx,%rcx,2),%rdx
  7390ef:	lea    (%rax,%rdx,8),%rax
  7390f3:	mov    %r8,%rdx
  7390f6:	neg    %rdx
  7390f9:	mov    $0x10,%edi
  7390fe:	xor    %esi,%esi
  739100:	mov    (%r15,%rdi,1),%r9d
  739104:	movq   -0x8(%r15,%rdi,1),%xmm0
  73910b:	mov    -0x10(%r15,%rdi,1),%r10
  739110:	lock incq (%r10)
  739114:	jle    739232 <gpui::runtime::text_geometry::append+0x252>
  73911a:	mov    %r10,-0x10(%rax,%rdi,1)
  73911f:	movq   %xmm0,-0x8(%rax,%rdi,1)
  739125:	mov    %r9d,(%rax,%rdi,1)
  739129:	dec    %rsi
  73912c:	add    $0x18,%rdi
  739130:	cmp    %rsi,%rdx
  739133:	jne    739100 <gpui::runtime::text_geometry::append+0x120>
  739135:	sub    %rsi,%rcx
  739138:	mov    %rcx,0x20(%rsp)
  73913d:	movdqu 0x10(%rsp),%xmm0
  739143:	movdqu %xmm0,(%rbx)
  739147:	mov    %rcx,0x10(%rbx)
  73914b:	mov    (%rbx),%rax
  73914e:	cmp    $0xffffffffffffffff,%rax
  739152:	je     7391e4 <gpui::runtime::text_geometry::append+0x204>
  739158:	mov    0x20(%r12),%r14
  73915d:	test   %r14,%r14
  739160:	je     7391f7 <gpui::runtime::text_geometry::append+0x217>
  739166:	lock incq (%r14)
  73916a:	jle    739232 <gpui::runtime::text_geometry::append+0x252>
  739170:	mov    %ebp,0x38(%rsp)
  739174:	movss  0x8(%rsp),%xmm0
  73917a:	movss  %xmm0,0x30(%rsp)
  739180:	movd   0x4(%rsp),%xmm0
  739186:	movd   %xmm0,0x34(%rsp)
  73918c:	mov    %r14,0x28(%rsp)
  739191:	mov    0x10(%rbx),%r15
  739195:	cmp    %rax,%r15
  739198:	jne    7391a3 <gpui::runtime::text_geometry::append+0x1c3>
  73919a:	mov    %rbx,%rdi
  73919d:	call   *0x309e7d(%rip)        # a43020 <_DYNAMIC+0xa88>
  7391a3:	mov    0x8(%rbx),%rax
  7391a7:	lea    (%r15,%r15,2),%rcx
  7391ab:	mov    0x38(%rsp),%rdx
  7391b0:	mov    %rdx,0x10(%rax,%rcx,8)
  7391b5:	movdqu 0x28(%rsp),%xmm0
  7391bb:	movdqu %xmm0,(%rax,%rcx,8)
  7391c0:	inc    %r15
  7391c3:	mov    %r15,0x10(%rbx)
  7391c7:	je     739210 <gpui::runtime::text_geometry::append+0x230>
  7391c9:	lea    (%r15,%r15,2),%rcx
  7391cd:	lea    (%rax,%rcx,8),%rax
  7391d1:	add    $0xffffffffffffffe8,%rax
  7391d5:	add    $0x48,%rsp
  7391d9:	pop    %rbx
  7391da:	pop    %r12
  7391dc:	pop    %r13
  7391de:	pop    %r14
  7391e0:	pop    %r15
  7391e2:	pop    %rbp
  7391e3:	ret
  7391e4:	cmp    %r13,%r8
  7391e7:	jae    739271 <gpui::runtime::text_geometry::append+0x291>
  7391ed:	lea    (%r8,%r8,2),%rax
  7391f1:	lea    (%r15,%rax,8),%rax
  7391f5:	jmp    7391d5 <gpui::runtime::text_geometry::append+0x1f5>
  7391f7:	lea    -0x6e77fa(%rip),%rdi        # 51a04 <GCC_except_table0+0x11bbc>
  7391fe:	lea    0x2ec2ab(%rip),%rdx        # a254b0 <gpui::property::WRAP_DECL+0x50>
  739205:	mov    $0x1f,%esi
  73920a:	call   *0x309790(%rip)        # a429a0 <_DYNAMIC+0x408>
  739210:	lea    0x2ec2b1(%rip),%rdi        # a254c8 <gpui::property::WRAP_DECL+0x68>
  739217:	call   *0x309683(%rip)        # a428a0 <_DYNAMIC+0x308>
  73921d:	lea    0x2ec274(%rip),%rcx        # a25498 <gpui::property::WRAP_DECL+0x38>
  739224:	xor    %edi,%edi
  739226:	mov    %r8,%rsi
  739229:	mov    %r13,%rdx
  73922c:	call   *0x30978e(%rip)        # a429c0 <_DYNAMIC+0x428>
  739232:	ud2
  739234:	lea    0x10(%rsp),%rdi
  739239:	mov    $0x8,%ecx
  73923e:	mov    %r8,%rdx
  739241:	mov    $0x18,%r8d
  739247:	xor    %esi,%esi
  739249:	mov    %rdx,%r14
  73924c:	call   72e5f0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  739251:	mov    0x18(%rsp),%rax
  739256:	mov    0x20(%rsp),%rcx
  73925b:	mov    %r14,%r8
  73925e:	jmp    7390eb <gpui::runtime::text_geometry::append+0x10b>
  739263:	mov    $0x8,%edi
  739268:	mov    %r12,%rsi
  73926b:	call   *0x30961f(%rip)        # a42890 <_DYNAMIC+0x2f8>
  739271:	lea    0x2ec268(%rip),%rdx        # a254e0 <gpui::property::WRAP_DECL+0x80>
  739278:	mov    %r8,%rdi
  73927b:	mov    %r13,%rsi
  73927e:	call   *0x3095ac(%rip)        # a42830 <_DYNAMIC+0x298>
  739284:	mov    %rax,%rbx
  739287:	lock decq (%r14)
  73928b:	jne    7392ad <gpui::runtime::text_geometry::append+0x2cd>
  73928d:	lea    0x28(%rsp),%rdi
  739292:	call   *0x309648(%rip)        # a428e0 <_DYNAMIC+0x348>
  739298:	jmp    7392ad <gpui::runtime::text_geometry::append+0x2cd>
  73929a:	call   *0x309588(%rip)        # a42828 <_DYNAMIC+0x290>
  7392a0:	mov    %rax,%rbx
  7392a3:	lea    0x10(%rsp),%rdi
  7392a8:	call   72aa50 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  7392ad:	mov    %rbx,%rdi
  7392b0:	call   a20c40 <_Unwind_Resume@plt>
  7392b5:	call   *0x30956d(%rip)        # a42828 <_DYNAMIC+0x290>

gpui::runtime::image::acknowledge code=157 fixed_stack=40

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

000000000073a1d0 <gpui::runtime::image::acknowledge>:
  73a1d0:	push   %r15
  73a1d2:	push   %r14
  73a1d4:	push   %rbx
  73a1d5:	sub    $0x10,%rsp
  73a1d9:	mov    (%rdi),%r14
  73a1dc:	test   %r14,%r14
  73a1df:	je     73a23f <gpui::runtime::image::acknowledge+0x6f>
  73a1e1:	mov    %rdi,%rbx
  73a1e4:	mov    0x38(%r14),%r15
  73a1e8:	cmp    $0xffffffffffffffff,%r15
  73a1ec:	je     73a21b <gpui::runtime::image::acknowledge+0x4b>
  73a1ee:	cmp    %rsi,0x30(%r14)
  73a1f2:	jne    73a21b <gpui::runtime::image::acknowledge+0x4b>
  73a1f4:	movups 0x40(%r14),%xmm0
  73a1f9:	movaps %xmm0,(%rsp)
  73a1fd:	movq   $0xffffffffffffffff,0x38(%r14)
  73a205:	lea    0x18(%r14),%rdi
  73a209:	call   72a950 <core::ptr::drop_glue::<alloc::vec::Vec<gpui_canvas::image::Image>>>
  73a20e:	mov    %r15,0x18(%r14)
  73a212:	movaps (%rsp),%xmm0
  73a216:	movups %xmm0,0x20(%r14)
  73a21b:	cmpq   $0x0,0x10(%r14)
  73a220:	jne    73a23f <gpui::runtime::image::acknowledge+0x6f>
  73a222:	cmpq   $0x0,0x28(%r14)
  73a227:	jne    73a23f <gpui::runtime::image::acknowledge+0x6f>
  73a229:	cmpq   $0xffffffffffffffff,0x38(%r14)
  73a22e:	jne    73a23f <gpui::runtime::image::acknowledge+0x6f>
  73a230:	mov    %r14,%rdi
  73a233:	call   72a5f0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::image::Images>>>>
  73a238:	movq   $0x0,(%rbx)
  73a23f:	add    $0x10,%rsp
  73a243:	pop    %rbx
  73a244:	pop    %r14
  73a246:	pop    %r15
  73a248:	ret
  73a249:	movq   $0x0,(%rbx)
  73a250:	mov    %rax,%rdi
  73a253:	call   a20c40 <_Unwind_Resume@plt>
  73a258:	mov    %r15,0x18(%r14)
  73a25c:	movaps (%rsp),%xmm0
  73a260:	movups %xmm0,0x20(%r14)
  73a265:	mov    %rax,%rdi
  73a268:	call   a20c40 <_Unwind_Resume@plt>

gpui::runtime::query::contains_point code=922 fixed_stack=168

/tmp/gpui-text-column-cpu-evidence/codegen-candidate-frozen:     file format elf64-x86-64


Disassembly of section .text:

000000000073bf90 <gpui::runtime::query::contains_point>:
  73bf90:	push   %rbp
  73bf91:	push   %r15
  73bf93:	push   %r14
  73bf95:	push   %r13
  73bf97:	push   %r12
  73bf99:	push   %rbx
  73bf9a:	sub    $0x78,%rsp
  73bf9e:	mov    %r8,%r12
  73bfa1:	mov    %rsi,%rbx
  73bfa4:	cmp    %rsi,%r8
  73bfa7:	jae    73c2f1 <gpui::runtime::query::contains_point+0x361>
  73bfad:	mov    %ecx,%ebp
  73bfaf:	mov    %rdx,%r13
  73bfb2:	mov    %rdi,%r14
  73bfb5:	shl    $0x6,%r12
  73bfb9:	add    %r12,%rdi
  73bfbc:	add    $0x10,%rdi
  73bfc0:	movss  %xmm0,0xc(%rsp)
  73bfc6:	movss  %xmm1,0x10(%rsp)
  73bfcc:	call   *0x306b0e(%rip)        # a42ae0 <_DYNAMIC+0x548>
  73bfd2:	test   %al,%al
  73bfd4:	je     73c014 <gpui::runtime::query::contains_point+0x84>
  73bfd6:	mov    0x8(%r13),%rdx
  73bfda:	mov    0x10(%r13),%r15
  73bfde:	cmp    %r15,%rdx
  73bfe1:	jb     73c2cf <gpui::runtime::query::contains_point+0x33f>
  73bfe7:	mov    %ebp,0x14(%rsp)
  73bfeb:	add    %r14,%r12
  73bfee:	mov    0x0(%r13),%rbp
  73bff2:	mov    0x30(%r12),%rcx
  73bff7:	movsd  (%r12),%xmm1
  73bffd:	mov    %rcx,%rdi
  73c000:	shr    $0x20,%rdi
  73c004:	cmp    $0x7fc00001,%ecx
  73c00a:	je     73c029 <gpui::runtime::query::contains_point+0x99>
  73c00c:	cmp    $0x7fc00002,%ecx
  73c012:	jne    73c046 <gpui::runtime::query::contains_point+0xb6>
  73c014:	xor    %r13d,%r13d
  73c017:	mov    %r13d,%eax
  73c01a:	add    $0x78,%rsp
  73c01e:	pop    %rbx
  73c01f:	pop    %r12
  73c021:	pop    %r13
  73c023:	pop    %r14
  73c025:	pop    %r15
  73c027:	pop    %rbp
  73c028:	ret
  73c029:	cmp    %r15,%rdi
  73c02c:	jae    73c304 <gpui::runtime::query::contains_point+0x374>
  73c032:	shl    $0x4,%rdi
  73c036:	mov    0x0(%rbp,%rdi,1),%ecx
  73c03a:	movq   0x4(%rbp,%rdi,1),%xmm2
  73c040:	mov    0xc(%rbp,%rdi,1),%edi
  73c044:	jmp    73c04a <gpui::runtime::query::contains_point+0xba>
  73c046:	pxor   %xmm2,%xmm2
  73c04a:	mov    %ecx,0x18(%rsp)
  73c04e:	movq   %xmm2,0x1c(%rsp)
  73c054:	mov    %edi,0x24(%rsp)
  73c058:	movlps %xmm1,0x28(%rsp)
  73c05d:	sub    %r15,%rdx
  73c060:	je     73c0d6 <gpui::runtime::query::contains_point+0x146>
  73c062:	mov    0x20(%r12),%r8
  73c067:	mov    %r15,%rsi
  73c06a:	shl    $0x4,%rsi
  73c06e:	add    %rbp,%rsi
  73c071:	xor    %eax,%eax
  73c073:	cmp    $0x1,%rdx
  73c077:	je     73c0a5 <gpui::runtime::query::contains_point+0x115>
  73c079:	mov    %rdx,%r9
  73c07c:	nopl   0x0(%rax)
  73c080:	mov    %rax,%r10
  73c083:	mov    %r9,%r11
  73c086:	shr    $1,%r11
  73c089:	add    %r11,%rax
  73c08c:	mov    %rax,%r13
  73c08f:	shl    $0x4,%r13
  73c093:	cmp    %r8,0x8(%rsi,%r13,1)
  73c098:	cmova  %r10,%rax
  73c09c:	sub    %r11,%r9
  73c09f:	cmp    $0x1,%r9
  73c0a3:	ja     73c080 <gpui::runtime::query::contains_point+0xf0>
  73c0a5:	mov    %rax,%r9
  73c0a8:	shl    $0x4,%r9
  73c0ac:	cmp    %r8,0x8(%rsi,%r9,1)
  73c0b1:	jne    73c0d6 <gpui::runtime::query::contains_point+0x146>
  73c0b3:	cmp    %rdx,%rax
  73c0b6:	jae    73c314 <gpui::runtime::query::contains_point+0x384>
  73c0bc:	add    %r9,%rsi
  73c0bf:	movss  0x4(%rsi),%xmm0
  73c0c4:	xorps  %xmm3,%xmm3
  73c0c7:	ucomiss %xmm3,%xmm0
  73c0ca:	jne    73c270 <gpui::runtime::query::contains_point+0x2e0>
  73c0d0:	jp     73c270 <gpui::runtime::query::contains_point+0x2e0>
  73c0d6:	movd   %edi,%xmm0
  73c0da:	movd   %ecx,%xmm3
  73c0de:	punpckldq %xmm2,%xmm3
  73c0e2:	cvtps2pd %xmm3,%xmm3
  73c0e5:	shufps $0xd4,%xmm2,%xmm0
  73c0e9:	shufps $0x52,%xmm2,%xmm0
  73c0ed:	cvtps2pd %xmm0,%xmm0
  73c0f0:	cvtps2pd %xmm1,%xmm1
  73c0f3:	movaps %xmm3,0x30(%rsp)
  73c0f8:	movaps %xmm0,0x40(%rsp)
  73c0fd:	movaps %xmm1,0x50(%rsp)
  73c102:	movb   $0x0,0x60(%rsp)
  73c107:	movq   $0x0,0x68(%rsp)
  73c110:	movsd  0x8(%r12),%xmm0
  73c117:	movsd  %xmm0,0x70(%rsp)
  73c11d:	lea    0x30(%rsp),%rdi
  73c122:	lea    0x68(%rsp),%rsi
  73c127:	movss  0xc(%rsp),%xmm0
  73c12d:	movss  0x10(%rsp),%xmm1
  73c133:	call   *0x306f4f(%rip)        # a43088 <_DYNAMIC+0xaf0>
  73c139:	mov    %eax,%r13d
  73c13c:	test   %al,0x14(%rsp)
  73c140:	je     73c017 <gpui::runtime::query::contains_point+0x87>
  73c146:	mov    $0x1ffff,%ecx
  73c14b:	mov    0x38(%r12),%eax
  73c150:	and    %ecx,%eax
  73c152:	mov    $0x1,%r13b
  73c155:	jmp    73c1e9 <gpui::runtime::query::contains_point+0x259>
  73c15a:	nopw   0x0(%rax,%rax,1)
  73c160:	cmp    $0x7fc00002,%eax
  73c165:	je     73c014 <gpui::runtime::query::contains_point+0x84>
  73c16b:	xorps  %xmm2,%xmm2
  73c16e:	movd   %eax,%xmm3
  73c172:	cvtss2sd %xmm3,%xmm3
  73c176:	cvtss2sd %xmm1,%xmm1
  73c17a:	movsd  %xmm3,0x30(%rsp)
  73c180:	movups %xmm2,0x38(%rsp)
  73c185:	movd   %edi,%xmm2
  73c189:	movlhps %xmm2,%xmm0
  73c18c:	shufps $0xe2,%xmm2,%xmm0
  73c190:	cvtps2pd %xmm0,%xmm0
  73c193:	movups %xmm0,0x48(%rsp)
  73c198:	movsd  %xmm1,0x58(%rsp)
  73c19e:	movb   $0x0,0x60(%rsp)
  73c1a3:	movq   $0x0,0x18(%rsp)
  73c1ac:	movsd  0x8(%r12),%xmm0
  73c1b3:	movsd  %xmm0,0x20(%rsp)
  73c1b9:	lea    0x30(%rsp),%rdi
  73c1be:	lea    0x18(%rsp),%rsi
  73c1c3:	movss  0xc(%rsp),%xmm0
  73c1c9:	movss  0x10(%rsp),%xmm1
  73c1cf:	call   *0x306eb3(%rip)        # a43088 <_DYNAMIC+0xaf0>
  73c1d5:	test   %al,%al
  73c1d7:	je     73c014 <gpui::runtime::query::contains_point+0x84>
  73c1dd:	mov    0x38(%r12),%eax
  73c1e2:	mov    $0x1ffff,%ecx
  73c1e7:	and    %ecx,%eax
  73c1e9:	cmp    $0x1ffff,%eax
  73c1ee:	je     73c017 <gpui::runtime::query::contains_point+0x87>
  73c1f4:	mov    %eax,%edi
  73c1f6:	cmp    %rdi,%rbx
  73c1f9:	jbe    73c2e1 <gpui::runtime::query::contains_point+0x351>
  73c1ff:	shl    $0x6,%rdi
  73c203:	lea    (%r14,%rdi,1),%r12
  73c207:	movzbl 0x3d(%r14,%rdi,1),%eax
  73c20d:	sub    $0x2,%al
  73c20f:	movzbl %al,%eax
  73c212:	mov    $0x8,%ecx
  73c217:	cmovb  %ecx,%eax
  73c21a:	cmp    $0x7,%al
  73c21c:	ja     73c1dd <gpui::runtime::query::contains_point+0x24d>
  73c21e:	movzbl %al,%eax
  73c221:	mov    $0xb0,%ecx
  73c226:	bt     %eax,%ecx
  73c229:	jae    73c1dd <gpui::runtime::query::contains_point+0x24d>
  73c22b:	mov    0x30(%r12),%rax
  73c230:	movss  (%r12),%xmm0
  73c236:	movss  0x4(%r12),%xmm1
  73c23d:	mov    %rax,%rdi
  73c240:	shr    $0x20,%rdi
  73c244:	cmp    $0x7fc00001,%eax
  73c249:	jne    73c160 <gpui::runtime::query::contains_point+0x1d0>
  73c24f:	cmp    %r15,%rdi
  73c252:	jae    73c304 <gpui::runtime::query::contains_point+0x374>
  73c258:	shl    $0x4,%rdi
  73c25c:	mov    0x0(%rbp,%rdi,1),%eax
  73c260:	cvtps2pd 0x4(%rbp,%rdi,1),%xmm2
  73c265:	mov    0xc(%rbp,%rdi,1),%ecx
  73c269:	mov    %ecx,%edi
  73c26b:	jmp    73c16e <gpui::runtime::query::contains_point+0x1de>
  73c270:	movq   $0x0,0x30(%rsp)
  73c279:	movsd  0x8(%r12),%xmm1
  73c280:	movsd  %xmm1,0x38(%rsp)
  73c286:	lea    0x30(%rsp),%rdi
  73c28b:	lea    0x18(%rsp),%rsi
  73c290:	movss  0xc(%rsp),%xmm1
  73c296:	movss  0x10(%rsp),%xmm2
  73c29c:	call   *0x306dee(%rip)        # a43090 <_DYNAMIC+0xaf8>
  73c2a2:	movabs $0x1ffffffff,%rcx
  73c2ac:	and    %rcx,%rax
  73c2af:	cmp    %rcx,%rax
  73c2b2:	sete   %r13b
  73c2b6:	cmpb   $0x0,0x14(%rsp)
  73c2bb:	je     73c017 <gpui::runtime::query::contains_point+0x87>
  73c2c1:	cmp    %rcx,%rax
  73c2c4:	je     73c146 <gpui::runtime::query::contains_point+0x1b6>
  73c2ca:	jmp    73c017 <gpui::runtime::query::contains_point+0x87>
  73c2cf:	lea    0x2e8caa(%rip),%rcx        # a24f80 <__frame_dummy_init_array_entry+0x2f90>
  73c2d6:	xor    %edi,%edi
  73c2d8:	mov    %r15,%rsi
  73c2db:	call   *0x3066df(%rip)        # a429c0 <_DYNAMIC+0x428>
  73c2e1:	lea    0x2e9228(%rip),%rdx        # a25510 <gpui::property::WRAP_DECL+0xb0>
  73c2e8:	mov    %rbx,%rsi
  73c2eb:	call   *0x30653f(%rip)        # a42830 <_DYNAMIC+0x298>
  73c2f1:	lea    0x2e9200(%rip),%rdx        # a254f8 <gpui::property::WRAP_DECL+0x98>
  73c2f8:	mov    %r12,%rdi
  73c2fb:	mov    %rbx,%rsi
  73c2fe:	call   *0x30652c(%rip)        # a42830 <_DYNAMIC+0x298>
  73c304:	lea    0x2e8b55(%rip),%rdx        # a24e60 <__frame_dummy_init_array_entry+0x2e70>
  73c30b:	mov    %r15,%rsi
  73c30e:	call   *0x30651c(%rip)        # a42830 <_DYNAMIC+0x298>
  73c314:	lea    0x2e881d(%rip),%rcx        # a24b38 <__frame_dummy_init_array_entry+0x2b48>
  73c31b:	mov    %rax,%rdi
  73c31e:	mov    %rdx,%rsi
  73c321:	mov    %rcx,%rdx
  73c324:	call   *0x306506(%rip)        # a42830 <_DYNAMIC+0x298>
