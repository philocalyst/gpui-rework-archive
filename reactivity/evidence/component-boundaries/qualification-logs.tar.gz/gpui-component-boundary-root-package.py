from pathlib import Path
import gzip
import hashlib
import json
import tarfile

out = Path('/tmp/gpui-component-boundary-root-handoff')
out.mkdir(exist_ok=False)
digest = lambda data: hashlib.sha256(data).hexdigest()
load = lambda path: json.loads(Path(path).read_text())
source = '88e68054ba637e1a840d1311b56bfa53fa74544f'
gates = {}
for suffix in ['build', 'execute-guard', 'strict', 'docs', 'scalar', 'wire-guard',
               'probe-guard', 'hummingbird-build', 'hummingbird-execute']:
    report = load('/tmp/gpui-component-boundary-root-' + suffix + '/result.json')
    assert report['source'] == source and report['exit'] == 0 and report['guards_match']
    gates[suffix] = report
functional = load('/tmp/gpui-component-boundary-root-artifacts/result.json')
assert functional['all_exit_zero'] and functional['passed'] == 700 and functional['harnesses'] == 68
port = load('/tmp/gpui-component-boundary-root-hummingbird-artifacts/result.json')
assert port['all_exit_zero'] and port['passed'] == 70 and port['harnesses'] == 18
native = load('/tmp/gpui-component-boundary-root-wire/native-execute/result.json')
assert native['all_exit_zero'] and native['passed'] == 2
allocation = load('/tmp/gpui-component-boundary-root-probe/result.json')
assert allocation['exact_public_artifacts'] == 120
mutant = load('/tmp/gpui-component-outer-mutant-root/result.json')
assert mutant['expected_semantic_failure'] and mutant['one_test_entered']
shader = load('/tmp/gpui-component-boundary-root-shader-audit/result.json')
assert shader['source'] == source and len(shader['spirv']) == 8 and len(shader['elfs']) == 1
core = load('/tmp/gpui-component-boundary-root-core-lines.json')
assert core['source_commit'] == source and core['core_non_test_code_lines'] == 34697
summary = {'source': source, 'gates': gates, 'gpui': {k:v for k,v in functional.items() if k != 'results'},
           'hummingbird': {k:v for k,v in port.items() if k != 'results'}, 'native': native,
           'exact_public_artifacts': 120, 'semantic_mutant': mutant,
           'shipping_non_test_non_comment_code_lines': 34697,
           'delta_vs_previous_main': 17,
           'scope': 'Functional, identity and allocation qualification. Overlapping counts are not summed; no timing, RSS, startup or hardware-GPU improvement is claimed.'}
(out / 'qualification.json').write_text(json.dumps(summary, indent=2) + '\n')
(out / 'allocations.json').write_text(json.dumps(allocation, indent=2) + '\n')
(out / 'core-lines.json.gz').write_bytes(gzip.compress(json.dumps(core, indent=2).encode(), mtime=0))
roots = []
for prefix in ['gpui-component-scope-root', 'gpui-component-boundary-root']:
    roots += [Path('/tmp') / (prefix + '-' + suffix) for suffix in
              ['clean', 'build', 'execute-guard', 'artifacts', 'strict', 'docs', 'scalar', 'probe', 'probe-guard']]
roots += [Path('/tmp/gpui-component-boundary-root-' + suffix) for suffix in
          ['wire', 'wire-guard', 'shader-audit', 'hummingbird-clean', 'hummingbird-build',
           'hummingbird-execute', 'hummingbird-artifacts']]
roots += [Path('/tmp/gpui-component-outer-mutant-root'), Path('/tmp/gpui-boundary-phase-layout-root')]
paths = []
for root in roots:
    assert root.is_dir(), root
    for path in root.rglob('*'):
        if path.is_file() and path.suffix in ['.json', '.txt', '.log', '.wgsl', '.spv', '.patch', '.hits', '.rgba', '.rs']:
            paths.append(path)
for name in ['gpui-component-scope-root-gates.sh', 'gpui-component-boundary-root-gates.sh',
             'gpui-component-scope-root-probe.py', 'gpui-component-boundary-root-probe.py',
             'gpui-component-boundary-root-native-wire.py', 'gpui-component-boundary-root-shader-audit.py',
             'gpui-component-boundary-root-hummingbird.sh', 'gpui-component-outer-mutant-root-run.py',
             'gpui-component-boundary-root-package.py',
             'gpui-component-routing-luna-20261024.md', 'gpui-component-scope-root-core-lines.json',
             'gpui-component-boundary-root-core-lines.json']:
    path = Path('/tmp') / name
    assert path.is_file(), path
    paths.append(path)
manifest = {}
archive = out / 'qualification-logs.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
    for path in sorted(set(paths)):
        name = str(path.relative_to('/tmp'))
        data = path.read_bytes()
        manifest[name] = {'bytes': len(data), 'sha256': digest(data)}
        tar.add(path, arcname=name, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    for member in tar:
        assert digest(tar.extractfile(member).read()) == manifest[member.name]['sha256']
(out / 'archive-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(out / 'archive-receipt.json').write_text(json.dumps({'sha256': digest(archive.read_bytes()),
    'bytes': archive.stat().st_size, 'members': len(manifest), 'all_payload_hashes_reverified': True,
    'scope': 'Commands, guards, logs, executable identities, shaders and public outputs; no executable payloads. Frozen ELFs remain at recorded external paths.'}, indent=2) + '\n')
print(json.dumps({'members': len(manifest), 'archive_bytes': archive.stat().st_size}), flush=True)
