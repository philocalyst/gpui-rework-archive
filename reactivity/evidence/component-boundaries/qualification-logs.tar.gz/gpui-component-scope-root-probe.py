from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

out = Path('/tmp/gpui-component-scope-root-probe')
out.mkdir(exist_ok=False)
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
results = []
for label, artifacts, source in [
    ('baseline', Path('/tmp/gpui-frontier-text-final-root-artifacts'),
     '22dae0afcc65071909ddbfcce0d2d8bc00dcbfa1'),
    ('candidate', Path('/tmp/gpui-component-scope-root-artifacts'),
     '82be9d71138cf8fc8f69f964361c85629de2acc5'),
]:
    directory = out / label
    directory.mkdir()
    matches = list(artifacts.glob('*-frontier'))
    assert len(matches) == 1, matches
    frozen = matches[0]
    identity = json.loads((frozen / 'binary.json').read_text())
    binary = frozen / 'test'
    assert digest(binary) == identity['sha256']
    assert not identity['fresh']
    evidence = directory / 'public-artifacts'
    env = os.environ | {'GPUI_FRONTIER_EVIDENCE': str(evidence)}
    command = [str(binary), '--nocapture', '--test-threads=1']
    with (directory / 'stdout.log').open('w') as stdout, (directory / 'stderr.log').open('w') as stderr:
        run = subprocess.run(command, stdout=stdout, stderr=stderr, env=env, timeout=300)
    assert digest(binary) == identity['sha256']
    (directory / 'binary.json').write_text(json.dumps(identity | {'source': source, 'command': command,
        'exit': run.returncode, 'sha256_after_matches': True}, indent=2) + '\n')
    assert run.returncode == 0, directory
    text = (directory / 'stdout.log').read_text()
    counts = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed;', text)
    assert counts == [('4', '0')], counts
    rows = {}
    for match in re.finditer(r'FRONTIER_ALLOC (\S+) logical=(\d+) cold=([\d,-]+) warm=([\d,-]+)', text):
        rows[match[1]] = {'logical': int(match[2]), 'cold': list(map(int, match[3].split(','))),
                         'warm': list(map(int, match[4].split(',')))}
    assert len(rows) == 18, rows
    files = {str(path.relative_to(evidence)): digest(path) for path in evidence.iterdir() if path.is_file()}
    assert len(files) == 120, len(files)
    results.append({'label': label, 'source': source, 'binary': str(binary),
                    'elf_sha256': identity['sha256'], 'rows': rows, 'artifacts': files})
assert results[0]['artifacts'] == results[1]['artifacts']
assert results[0]['elf_sha256'] != results[1]['elf_sha256']
deltas = {}
for key, baseline in results[0]['rows'].items():
    candidate = results[1]['rows'][key]
    assert baseline['logical'] == candidate['logical']
    delta = {region: [a-b for a, b in zip(baseline[region], candidate[region], strict=True)]
             for region in ['cold', 'warm']}
    fixture_nodes = int(key.split('-')[1])
    # The virtual-list description admits the full requested-height source,
    # including ListItem wrappers, before publication clips it to visible rows.
    described_nodes = (1 + 3 * ((fixture_nodes - 1) // 3) if fixture_nodes > 4096
                       else 1 + 2 * fixture_nodes) if key.startswith('List-') else fixture_nodes
    assert delta['cold'][:2] == [1, 4 * described_nodes], (key, delta)
    if key.startswith('List-'):
        assert delta['warm'][:2] == [2, 8 * described_nodes], (key, delta)
    else:
        assert delta['warm'] == [0, 0, 0, 0], (key, delta)
    deltas[key] = delta
report = {'baseline': results[0], 'candidate': results[1], 'exact_public_artifacts': 120,
          'baseline_minus_candidate_deltas': deltas,
          'counter_order': ['requested_allocations', 'requested_bytes', 'current_bytes', 'peak_bytes'],
          'scope': 'Actual allocation requests and exact public semantic/hit/RGBA artifacts. No timing or RSS inference.'}
(out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'exact_public_artifacts': 120, 'deltas': deltas}), flush=True)
