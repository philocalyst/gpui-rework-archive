#![allow(dead_code)]
use std::mem::size_of;
trait Route {}
struct Handler(Box<dyn Route>);
enum State { Check(Handler), Scope(u32) }
struct Boundary { state: State, next: Option<Box<Boundary>> }
struct OldBoundary { check: Option<Handler>, next: Option<Box<OldBoundary>> }
fn main() { println!("State={} Boundary={} OldBoundary={} Boundaries={}",size_of::<State>(),size_of::<Boundary>(),size_of::<OldBoundary>(),size_of::<Option<Box<Boundary>>>()); assert_eq!(size_of::<Boundary>(),size_of::<OldBoundary>()); }
