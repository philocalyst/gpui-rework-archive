from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

w = Path('/tmp/gpui-component-scope-root')
out = Path('/tmp/gpui-component-outer-mutant-root')
pin = json.loads((out / 'source.json').read_text())['mutant']
good = '88e68054ba637e1a840d1311b56bfa53fa74544f'
git = ['git', '-c', f'safe.directory={w}', '-C', str(w)]
gate = [sys.executable, '/root/gpui-ce3/reactivity/evidence/clipping-gradients-integration/gpui-run-frozen-gate-root.py',
        '--source', str(w), '--pin', pin, '--timeout', '900']
for scope in ['.cargo', 'clippy.toml', 'reactivity/Cargo.toml', 'reactivity/Cargo.lock',
              'reactivity/rust-toolchain.toml', 'reactivity/crates', 'reactivity/vendor']:
    gate += ['--scope', scope]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
try:
    subprocess.run(gate + ['--out', str(out / 'clean'), '--', 'cargo', 'clean', '--manifest-path',
                          'reactivity/Cargo.toml', '--locked', '--offline', '-p', 'gpui'], check=True)
    subprocess.run(gate + ['--out', str(out / 'build'), '--', 'cargo', 'test', '--manifest-path',
                          'reactivity/Cargo.toml', '--locked', '--offline', '-p', 'gpui', '--test',
                          'components', '--features', 'gpui/x11,gpui_gpu/offline-shader,gpui_canvas/parallel',
                          '--no-run', '--message-format=json'], check=True)
    rows = [json.loads(line) for line in (out / 'build/stdout.log').read_text().splitlines()]
    rows = [r for r in rows if r.get('reason') == 'compiler-artifact' and r.get('executable')
            and r['target']['name'] == 'components']
    assert len(rows) == 1 and not rows[0]['fresh'], rows
    row = rows[0]
    binary = out / 'actual-test.elf'
    source = Path(row['executable'])
    assert source.stat().st_nlink == 1 and source.stat().st_dev == out.stat().st_dev
    source.rename(binary)
    binary.chmod(0o555)
    identity = {'source': pin, 'cargo': row, 'path': str(binary), 'sha256': sha(binary),
                'bytes': binary.stat().st_size, 'freeze_method': 'atomic rename of uniquely linked ELF'}
    (out / 'binary.json').write_text(json.dumps(identity, indent=2) + '\n')
    result = subprocess.run(gate + ['--out', str(out / 'execute'), '--', str(binary),
        'changing_the_inner_owner_of_a_shared_visual_root_revokes_both_subtrees',
        '--exact', '--nocapture', '--test-threads=1'])
    assert sha(binary) == identity['sha256']
    report = json.loads((out / 'execute/result.json').read_text())
    assert result.returncode == 101 and report['failed'] == 1 and report['passed'] == 0
    assert report['harnesses'] == 1
    text = (out / 'execute/stdout.log').read_text()
    assert 'running 1 test' in text
    (out / 'result.json').write_text(json.dumps({'source': pin, 'expected_semantic_failure': True,
        'one_test_entered': True, 'failed': 1, 'elf_sha256': identity['sha256'],
        'sha256_after_matches': True, 'source_guard': report}, indent=2) + '\n')
finally:
    assert not subprocess.check_output(git + ['status', '--porcelain'], text=True)
    assert subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip() == pin
    subprocess.run(git + ['checkout', '--detach', '--quiet', good], check=True)
    guard = json.loads(Path('/tmp/gpui-component-boundary-root-build/before.json').read_text())
    for name, expected in guard.items():
        assert sha(w / name) == expected, name
    (out / 'restored.json').write_text(json.dumps({'source': good, 'guarded_files': len(guard),
        'all_hashes_match': True}, indent=2) + '\n')
