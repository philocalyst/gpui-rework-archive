# Sparse component routing: source-pinned design review

Research snapshot: `/root/gpui-ce3` at `72dbaa6001673fe518a66d967611c919150e7497`. This report is read-only research; no builds or source edits were made. The repository has no configured remote in this checkout, so code references below are local, commit-pinned file links rather than guessed GitHub URLs.

## Finding

Removing the repeated `ComponentRoute` wrappers and `map_handlers` walks is feasible without changing the public `View::view(&self) -> El<'_>` API or adding `Rc`, `Cell`, `RefCell`, stored model pointers, or user boilerplate. The dispatch key can be the existing scoped `u32` owner ordinal: `Sources` already assigns each registered component a disjoint scope interval and retains the typed projection declaration needed to walk that path. At activation, the runtime can ask the current root `Sources` tree to borrow the owner identified by the node’s lexical scope, then call the original route against that `&dyn Any` owner and its matching `Sources`.

The important constraint is that a component’s lexical region is the subtree present when `Component::view` runs, not every node later placed below the returned element. A naive flatten-time “inherit from visual parent” scheme is wrong. `Component::view` calls `map_handlers` before returning its `El`; subsequently attached children are not mapped. For example, `LEFT.view(pair).child(parent_button)` leaves `parent_button` parent-owned even though it is visually below LEFT. Likewise `LEFT.view(pair).child(RIGHT.view(pair))` has two lexical owner regions under one visual root. A correct replacement needs sparse enter/exit or child-edge region metadata and must classify deferred projection/list output as inside the region that created it.

## Current source behavior

`Component::view` obtains the child view, calls `map_handlers` with `handler.in_component(self)`, then prepends a component boundary. The map is iterative over current `El.children`, wraps each click handler and each boundary check, and composes itself into list row and projection callbacks so elements generated later receive the same wrapper. See [`component.rs:67–82`](</root/gpui-ce3/reactivity/crates/gpui/src/component.rs:67>) and [`element.rs:791–837`](</root/gpui-ce3/reactivity/crates/gpui/src/element.rs:791>).

`ComponentRoute<P,C>` stores the `Component<P,C>` projection plus the inner `Handler`. Its admission path downcasts the parent and `Sources<P>`, checks the registered component entry and read-projection identity, then recursively admits the child handler. Invocation projects mutably and calls the child handler. The property path separately projects proposal/reply access to the child. This is the per-handler adapter to remove; it is not the boundary itself. See [`element.rs:258–322`](</root/gpui-ce3/reactivity/crates/gpui/src/element.rs:258>) and [`component.rs:83–122`](</root/gpui-ce3/reactivity/crates/gpui/src/component.rs:83>).

The schema already has enough structural information to route by ordinal. A `ComponentEntry` holds its typed `Component<M,C>`, child `Sources<C>`, and a half-open `[start,end)` scope interval. Sibling entries get disjoint intervals as `Sources::register_component` advances `next_scope` by the child schema’s `next_scope`. `FieldId` stores local ID plus scope in a `u64`; nested scope qualification is addition along that schema path. See [`source.rs:611–641`](</root/gpui-ce3/reactivity/crates/gpui/src/source.rs:611>) and [`source.rs:728–850`](</root/gpui-ce3/reactivity/crates/gpui/src/source.rs:728>).

The current `Node.component_scope` is **not used for dispatch**. In this checkout it is read only in the previous-node reuse filter at [`runtime.rs:2299–2301`](</root/gpui-ce3/reactivity/crates/gpui/src/runtime.rs:2299>), written at [`runtime.rs:2351`](</root/gpui-ce3/reactivity/crates/gpui/src/runtime.rs:2351>), and initialized to zero at [`runtime.rs:376`](</root/gpui-ce3/reactivity/crates/gpui/src/runtime.rs:376>). Current description computes it densely by inheriting the visual parent’s scope and overwriting it for each boundary at [`runtime.rs:2078–2092`](</root/gpui-ce3/reactivity/crates/gpui/src/runtime.rs:2078>). The already-isolated parent change that phase-types the boundary check and removes the dense `component_scopes` vector is complementary; this report does not propose repeating it.

Activation performs `handler.admit` before computing the next source epoch and invoking the callback; a failed admission cannot mutate the model or consume an epoch. Property actions have their own two-phase proposal/edit/reply path. See [`runtime/turn.rs:330–377`](</root/gpui-ce3/reactivity/crates/gpui/src/runtime/turn.rs:330>) and [`element.rs:195–256`](</root/gpui-ce3/reactivity/crates/gpui/src/element.rs:195>). Those sequencing guarantees must remain explicit in any change.

Existing component tests establish several essential cases: same child type at LEFT and RIGHT, nested component roots reusing local IDs, visual nesting that does not infer model ownership, candidate/registered projection mismatch, and a failed component check before any epoch or mutation. See [`tests/components.rs:116–206`](</root/gpui-ce3/reactivity/crates/gpui/tests/components.rs:116>) and [`tests/components.rs:257–352`](</root/gpui-ce3/reactivity/crates/gpui/tests/components.rs:257>).

## Replacement design

### 1. Owner-context lookup in `Sources`

Add internal borrowed owner lookup to `Sources`/`ComponentSchema`. At the root, scope zero returns `(&M, &Sources<M>)`. Otherwise find the unique `ComponentEntry` whose scope range contains the requested ordinal, borrow its child through the registered projector, subtract `start`, and recurse into its child schema. The returned context contains:

```text
OwnerContext<'a> {
    receiver: &'a dyn Any,
    sources: &'a dyn Any,
    scope_base: u32,
}
```

The typed traversal is structurally analogous to existing `ComponentEntry` methods. It does not select a model by `TypeId` (same child types are common), by address (ZST fields can share addresses and models move), or by visual parent. It selects a schema path: distinct sibling component declarations receive distinct ordinal intervals, and nested components compose by subtraction/addition through those intervals. The model itself is always borrowed from the current root at admission/invocation time; no address survives the call.

For a nested `Counter` direct action, the scope context yields `&Counter` and `&Sources<Counter>`. The raw `MethodRoute<Counter, _>` can downcast and admit against that receiver. A raw `FieldAction<Counter,...>` returns its child-local `FieldId`; the runtime qualifies it by `scope_base` before source patch filtering. Root-owned projected actions already encode a `ProjectedSource` path and resolve to their fully scoped field at scope zero, so they must not be qualified twice.

Use the same borrowed scope lookup for all four route operations that can observe/mutate the model:

* `admit`: pass scoped receiver and scoped sources to the raw route, qualify its exact local field once, and reject a `Window` action whenever scope is nonzero. That preserves current `ComponentRoute.admit` behavior, which refuses to turn a child-owned callback into a window action.
* `invoke`: resolve the mutable owner only after admission succeeds; project through the registered typed schema path, validate each registered read/write projector while the root is exclusively borrowed, then invoke the raw route against that owner.
* property proposal/reply: resolve the same owner context in each phase. Keep proposal read-only, keep the current property transaction boundary, and restore the owned route before reconciliation as `activate_property` currently does.
* component boundary check: retain one check per boundary and validate the candidate component projection against the registered schema before accepting the description. The scope result should be returned with that validation so the caller does not repeat the projection walk.

Changing these APIs is internal: `Route`, `Handler`, `Sources`, `ComponentBoundary`, `Runtime::Node` and `activate_with_editing` are crate-private. Public `Component::view` and `View::view` remain untouched. The registry’s projector is canonical for later dispatch; candidate projectors are checked at description time while the model is borrowed, before the new handler is installed. Since one runtime turn exclusively borrows the model and no callback occurs between description admission and installing that description, an accepted node cannot switch candidate projection between that check and its callback. Activation still validates the registered path’s read/write agreement before invoking.

### 2. Sparse lexical regions, not visual inheritance

Delete the `map_handlers` call from `Component::view`; keep per-component boundary metadata. A component boundary must describe the region established at the instant `Component::view` is called. The metadata needs to cover (a) the root route, (b) the original child elements then present, and (c) deferred projection and list-row output generated from nodes in that region. Elements appended to the returned root later must keep the incoming/parent lexical owner, even if visual parentage puts them below the component root.

One concrete representation is an internal lexical-region marker plus a cutoff for ordinary children on the boundary root. During iterative flattening, schedule children with an explicit edge kind: original child-prefix, later appended child, projected child, or list-generated row. Original children up to the captured cutoff and deferred children created by a scoped node inherit the component context; later appended ordinary children inherit the pre-boundary context. Nested markers override the active path. The flattener can emit sparse enter/exit events in preorder (one per component boundary plus an event for a child-edge exception), then runtime description validates boundary events and associates each interactive node with the resolved lexical scope. Do not wrap list/projection callbacks in new closures; the existing flatten step already materializes their output and can pass the active lexical context to that output.

There are implementation alternatives for carrying the region endpoint, but all must satisfy the behavioral contract above. A transparent “fragment wrapper” is only safe if it does not introduce a visual node, alter flex/layout inheritance, hit testing, semantic parentage, target ordinals, or `El`/`DraftNode` lifetimes. Reordering dynamic projected children ahead of ordinary children to make a scope interval contiguous is also unsafe because it changes child order. A per-handler owner stamp would preserve correctness but gives up part of the intended structural simplification; treat it as a fallback if sparse region events cannot be made robust.

The current node scope can be repurposed to store only what is needed: boundary roots need the checked component scope for identity qualification, and interactive nodes need the lexical owner scope for dispatch. Ordinary non-handler nodes need no inherited scope if the identity argument below holds. This uses the existing `u32` Node slot rather than adding a per-node word. It still requires preserving a node’s lexical owner when a visual child is attached under a different lexical region; the flatten metadata, not the visual parent, decides that value.

## Cost model and expected payoff

Let `H` be the number of handlers, `B(h)` the number of enclosing component projections for handler `h`, `N_c` the size of each component subtree at its `Component::view` call, and `D` the maximum nested component schema depth.

Current `map_handlers` work is approximately `O(sum_c N_c)`, with a route wrapper count `W = sum_h B(h)` (boundary-check routes are also wrapped by outer components). For each additional parent component, every handler already in that subtree gets another boxed `ComponentRoute`; nested event admit/invoke/property dispatch recursively traverses those wrappers. A component route’s concrete requested payload is 56 bytes on the current x86_64 ledger (`Component` plus inner `Handler`), and it requires a non-ZST route box; the existing proof ledger is in [`docs/route-storage-frontier-luna.md`](</root/gpui-ce3/reactivity/docs/route-storage-frontier-luna.md:17>). Per-handler savings are therefore approximately `56 * (B(h)-1)` requested bytes if a raw nonzero route allocation remains, with allocator usable-size and component-boundary checks excluded. For a ZST method route the original `Box::new` has no heap allocation, but every non-ZST `ComponentRoute` wrapper does. The source code itself does not state a real application’s wrapper-depth distribution, so there is no justified aggregate memory claim yet.

The replacement keeps one original handler allocation/representation per handler, the existing sparse component boundary checks, the existing boundary marker storage, the existing `u32` Node slot, and schema allocations. It removes the `W` wrapper boxes and the repeated component subtree walks. Flatten still must visit every emitted node once, as it already does. Owner lookup costs a schema walk proportional to `D` plus per-level linear component-entry lookup; the same work currently appears through nested wrappers and `Sources::component_entry` scans. No global component hash map or retained owner pointer is required. No new O(H) route table is required. Any added region-event storage should be O(B + deferred-edge exceptions), be short-lived during description, and be reported separately from retained `El`, `DraftNode`, `Node`, and allocator bytes.

Do not claim `O(1)` dispatch: resolving a deep scope needs up to `D` typed projection steps. Do not count the already-isolated removal of dense `component_scopes: Vec<u32>` as a win for this change. Do not claim the new method is faster until a release-mode, route-heavy component benchmark is run; the robust current claim is structural elimination of O(sum subtree sizes) mapping and O(W) wrapper objects, traded for O(D) path lookup at actual activation.

## `component_scope` identity audit

The parent’s hypothesis that scope inheritance on all ordinary nodes is redundant appears sound for current reconciliation, with one condition: a component boundary root whose owner scope changes must itself fail identity reuse. Current code enforces exactly that at the `previous.filter(node.component_scope == new_scope)` step. That root then receives a new monotonic identity. Every ordinary child’s unkeyed matching, keyed-row matching, and keyed-list matching is qualified by the **new parent identity**: old keyed maps are built with `(parent_identity, key/id, site_kind)` at [`runtime.rs:2208–2234`](</root/gpui-ce3/reactivity/crates/gpui/src/runtime.rs:2208>), and new matching uses the current parent identity at [`runtime.rs:2250–2300`](</root/gpui-ce3/reactivity/crates/gpui/src/runtime.rs:2250>). Once the boundary root is reminted, descendants cannot be matched under its old identity, even if their local component scope ordinal is equal. Sibling layout runs also use the current parent identity and cannot cross that edge.

The same argument covers same-type LEFT/RIGHT instances and nested schemas with reused local IDs: their absolute `FieldId` scope ordinals differ at the boundary root; repeated list-row component scope ordinals are qualified by the row/list parent identity. Moving the entire model preserves schema ordinals but the runtime’s target namespace is reminted independently on restore; the existing movement test checks this at [`tests/components.rs:147–166`](</root/gpui-ce3/reactivity/crates/gpui/tests/components.rs:147>).

Failed description does not create a hole: admission fails before reconciliation swaps old nodes, and the runtime marks logical state invalid; the next accepted full description must validate again. It cannot accidentally reuse a child below an unvalidated new scope. This reasoning depends on the current parent-identity-qualified old maps, monotonic new node identities, and failed-description transaction boundary. It would need a new proof if reconciliation ever globally keyed descendants without parent identity or reused a boundary node identity after its boundary scope changed.

The existing root isolate conservatively keeps inherited scope. Removing that inheritance is a useful follow-on micro-delta, but is not required to remove handler wrappers. It should be isolated and tested against a changed component boundary with static, unkeyed, keyed-row, and keyed-list descendants, plus failed logical description followed by recovery. Existing same-root and cross-component cases should also assert target reminting, not only callback correctness.

## Exactness limits and failure cases

The ordinal identifies a **declaration path**, not a runtime object identity. That is exactly what is needed to distinguish `Pair::LEFT` and `Pair::RIGHT` when both point to `Counter`, and it continues to work if a `Pair` or child value moves. The current borrowed typed projector returns the current model object on the stack; no pointer is kept. A `TypeId`-only scheme fails for same-type siblings; a model-address key fails for moved models and can collapse ZST/aliased references; a visual-parent walk fails for nested visual components. The proposed lookup uses none of those as identity.

The boundary checker today compares the candidate component’s read pointer with the registered component’s read pointer while the same parent is borrowed, then checks read/write agreement. That check’s documented projection contract is semantic and stable-child; it is not a type-system proof of purity. A scope-key dispatcher must keep the existing check and must not claim it proves arbitrary projector purity. In particular, if distinct ZST fields produce equal addresses, the current pointer-equality check cannot distinguish those candidate projections; this is an existing limitation, not something a new owner path should use to choose an instance. The path choice remains the registered scope declaration. See [`component.rs:28–42`](</root/gpui-ce3/reactivity/crates/gpui/src/component.rs:28>) and [`source.rs:52–62`](</root/gpui-ce3/reactivity/crates/gpui/src/source.rs:52>).

The explicit reject tests below target easy-to-miss errors:

* `LEFT.view(pair).child(RIGHT.view(pair))`: the right marker must override LEFT even though RIGHT is visually nested beneath it.
* `LEFT.view(pair).child(pair_owned_button)`: the button was appended after the call, so it remains parent-owned despite visual nesting.
* `LEFT.view(pair).child(projected_child)` or a list row produced under LEFT: deferred children created by the scoped node must inherit LEFT; later ordinary children must not.
* Two same-type component instances mounted at the same visual root: equal `TypeId` and equal local field IDs must still route to distinct fully qualified source scopes.
* Same component returned from a keyed list: rows may share a scope ordinal, but current row model selection must follow the row’s current parent/key schema path, never a remembered pointer.
* A candidate boundary using a bad writer or bad reader: fail in description before handler admission, callback, source epoch, focus/paint publication, or model mutation.
* A child `WindowAction`: reject at admission exactly as `ComponentRoute` currently does.
* A child property action: proposal and logical reply must receive the same projected child as the normal route, and stale/rejected property requests must preserve existing epoch/reply behavior.
* A parent-owned `ProjectedSource` action below a visual component node: qualify its field once from its typed `ProjectedSource` and do not reinterpret its owner from the visual parent.
* A ZST child and a moved root model: scope lookup still selects the declaration path; no address cache is involved.

## Verification plan (no builds run here)

Use independent tests, not just successful examples. Add a mount-level route probe that confirms the produced raw handler’s receiver `TypeId`, scoped `Sources` schema, exact `FieldId`, and projection error match the wrapper implementation for root, one-level, and multi-level routes. Then test each callback phase separately: model method, exact `FieldAction`, property proposal/reply, and rejected window action. Assert bad candidate projections leave model values, source epoch, focus, targets and published scene unchanged.

Add the post-`view` child and deferred list/projection tests above. Assert LEFT and RIGHT values separately so a mistaken route cannot pass by updating a shared counter. Assert `Target` identity behavior across scope changes in each descendant matching mode. Include reused local IDs at multiple nesting levels, a moved model, ZST model fields, non-ZST same-type siblings, and a projected source action authored by the parent.

For the performance proof, count `map_handlers` visits and concrete `ComponentRoute` instances for a synthetic depth-1/depth-4 component with 1, 100, and 10,000 handlers; expected current wrapper count is proportional to `sum_h B(h)`, while the sparse route has one raw handler and one boundary check per boundary. Separately report requested route bytes and allocator usable bytes, cold peak while old/draft descriptions overlap, retained description bytes, and release dispatch timing. This confirms eliminated work and allocations without folding in the earlier dense scope-vector change.

## Relevant primary prior art

The [Rustonomicon’s “Splitting Borrows” chapter](https://doc.rust-lang.org/nomicon/borrow-splitting.html) explains the safe core used here: borrow distinct fields from a composite owner through a sequence of short-lived typed projections. It supports the reborrow design but does not provide a dynamic scope resolver; the `Sources` schema supplies that missing typed path.

Bevy ECS’s [`World::get_entity_mut` source](https://docs.rs/bevy_ecs/latest/src/bevy_ecs/world/mod.rs.html) resolves an explicit entity key to a borrow from the current world, rather than retaining an entity’s address as identity. That is a useful analogue for “stable key plus fresh borrow,” though GPUI’s owner key must be a schema-relative component path and its safe field projector is not Bevy’s erased storage. Bevy’s `EntityMut::reborrow` also documents the short-lived reborrow pattern in [its source](https://docs.rs/bevy_ecs/latest/src/bevy_ecs/world/entity_access/entity_mut.rs.html); this proposal does not need Bevy’s unsafe world-cell machinery.

The [egui `Ui::scope_id` documentation/source](https://docs.rs/egui/latest/src/egui/ui.rs.html) is a useful caution: widget/UI scope and visual-parent scope are identity namespaces, not proof of model ownership. A GPUI lexical scope must carry the explicit `Component` projection path even when the visual tree is rearranged.

## Recommendation

Take this as a frozen design candidate, not as evidence that implementation or speedup is already proven. The strongest shape is: (1) scope lookup through existing `Sources` component intervals; (2) one candidate-check metadata entry per component boundary; (3) sparse lexical region events that preserve the exact “elements present at `Component::view` time” semantics and deferred output; (4) dispatch raw routes against fresh borrowed owners; and (5) store scope only at boundary roots and interactive sites, with parent-identity-qualified reconciliation doing the rest for ordinary nodes.

The main implementation risk is lexical region bookkeeping in `El::child` and `flatten_lists`, especially the difference between later ordinary children and deferred projected/list children. The highest-value falsification test is the post-return child case; a solution that cannot preserve that behavior is not equivalent, regardless of its allocation savings. No hosted source URL is asserted for the private checkout revision.
