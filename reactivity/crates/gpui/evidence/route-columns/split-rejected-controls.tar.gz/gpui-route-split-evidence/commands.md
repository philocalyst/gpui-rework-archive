# Commands and capture stamps

Base: `89aeabd53942c3a4643bcb6fd978e6a24703f6d2`. Shipping implementation control: `6694e899b2`. Test-only max-owner control: `8d7ce59e96` (missing initial P acknowledgement, failed harness). Corrected test-only selected source: `6403f62a918fb7c9ba50ecdd9ac5f4f52e75c266`.

From the isolated candidate's reactivity directory:

```sh
source /tmp/gpui-native-env.sh
unset RUSTFLAGS CARGO_ENCODED_RUSTFLAGS
cargo clean -p gpui
CARGO_BUILD_JOBS=2 cargo test --offline --locked -p gpui --no-default-features --lib --test routes --test components --test inspector --test lists --test property_actions --test property_selection --no-run --jobs 2 --message-format=json
CARGO_BUILD_JOBS=2 cargo build --offline --locked -p gpui --no-default-features --release --example route_columns_cost --jobs 2 --message-format=json
CARGO_BUILD_JOBS=2 cargo test --offline --locked -p gpui --no-default-features --test images --test checkbox --test queries --no-run --jobs 2 --message-format=json
```

Selected executable artifacts must be unique, match the target and report fresh=false before copying. The frozen executables are run directly with `--test-threads=1`. The four split-field tests, six parent tests, full no-default library suite and each public integration suite are separately logged. The allocator oracle runs explicitly with `runtime::route_ledger::complete_owner_route_requests --exact --ignored --nocapture --test-threads=1`.

The two test-only successors each rebuild the no-default library with the max-owner filter and `--no-run`, then run the frozen executable explicitly with `runtime::route_slot::tests::max_admitted_owner_dispatches_routes_across_both_high_bits --exact --ignored --nocapture --test-threads=1`. Both test-only successors also rebuild the same release example, require fresh=false, freeze it and compare bytes with 669. The final example is byte-identical.

Six check-mode configurations run only output oracles: activate 1000/1000, activate 1000/500, activate 16384/164, equal 16384/0, resize 16384/164 and snapshot 16384/164. The repetitions argument is one and check mode prints unchecked_timing. No check-mode elapsed value is used as a timing observation.

`core_lines.py --ref 6403f62a91` uses the prebuilt inventory-rust helper and tokei paths/checksums recorded in its JSON. Actual assembly comes from native environment nm, size and objdump. Compiler fingerprints were copied before any source switch; actual compiler/profile/flag/configuration matching is recorded in release-6403-fingerprint-proof.json.

Root GO: **2026-10-23 01:37:31 UTC**. Both other workers explicitly held; root before-process audit is preserved. Exactly one command ran:

```sh
timeout --signal=KILL 300s /nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3 /tmp/gpui-route-split-evidence/run_split_pairs.py --cpu 0 --output /tmp/gpui-route-split-evidence/quiet-attempt-1
```

The capture exits zero after 16.7 seconds and retains every one of 180 observations. The root after-process audit is preserved. Root END: **2026-10-23 01:38:38 UTC**. No resampling, replacement, threshold change, additional timing or broad qualification follows the losing result.
