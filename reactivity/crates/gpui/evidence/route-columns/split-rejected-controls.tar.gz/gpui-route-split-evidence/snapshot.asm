
/tmp/gpui-route-split-evidence/bin/split-cost:     file format elf64-x86-64


Disassembly of section .text:

00000000006eff00 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets>:
  6eff00:	55                   	push   %rbp
  6eff01:	41 57                	push   %r15
  6eff03:	41 56                	push   %r14
  6eff05:	41 55                	push   %r13
  6eff07:	41 54                	push   %r12
  6eff09:	53                   	push   %rbx
  6eff0a:	48 81 ec 78 01 00 00 	sub    $0x178,%rsp
  6eff11:	89 54 24 34          	mov    %edx,0x34(%rsp)
  6eff15:	48 8b 2e             	mov    (%rsi),%rbp
  6eff18:	48 85 ed             	test   %rbp,%rbp
  6eff1b:	74 35                	je     6eff52 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x52>
  6eff1d:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
  6eff22:	4c 8b bd 80 05 00 00 	mov    0x580(%rbp),%r15
  6eff29:	4c 89 f8             	mov    %r15,%rax
  6eff2c:	48 c1 e0 07          	shl    $0x7,%rax
  6eff30:	4a 8d 1c f8          	lea    (%rax,%r15,8),%rbx
  6eff34:	48 b8 f0 f0 f0 f0 f0 	movabs $0xf0f0f0f0f0f0f0,%rax
  6eff3b:	f0 f0 00 
  6eff3e:	49 39 c7             	cmp    %rax,%r15
  6eff41:	76 23                	jbe    6eff66 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x66>
  6eff43:	45 31 f6             	xor    %r14d,%r14d
  6eff46:	4c 89 f7             	mov    %r14,%rdi
  6eff49:	48 89 de             	mov    %rbx,%rsi
  6eff4c:	ff 15 1e b8 39 00    	call   *0x39b81e(%rip)        # a8b770 <_DYNAMIC+0x318>
  6eff52:	48 c7 47 08 0d 00 00 	movq   $0xd,0x8(%rdi)
  6eff59:	00 
  6eff5a:	48 c7 07 02 00 00 00 	movq   $0x2,(%rdi)
  6eff61:	e9 1b 06 00 00       	jmp    6f0581 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x681>
  6eff66:	48 85 db             	test   %rbx,%rbx
  6eff69:	74 21                	je     6eff8c <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x8c>
  6eff6b:	ff 15 27 b7 39 00    	call   *0x39b727(%rip)        # a8b698 <_DYNAMIC+0x240>
  6eff71:	41 be 08 00 00 00    	mov    $0x8,%r14d
  6eff77:	be 08 00 00 00       	mov    $0x8,%esi
  6eff7c:	48 89 df             	mov    %rbx,%rdi
  6eff7f:	ff 15 1b b7 39 00    	call   *0x39b71b(%rip)        # a8b6a0 <_DYNAMIC+0x248>
  6eff85:	48 85 c0             	test   %rax,%rax
  6eff88:	75 0a                	jne    6eff94 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x94>
  6eff8a:	eb ba                	jmp    6eff46 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x46>
  6eff8c:	b8 08 00 00 00       	mov    $0x8,%eax
  6eff91:	45 31 ff             	xor    %r15d,%r15d
  6eff94:	4c 89 7c 24 38       	mov    %r15,0x38(%rsp)
  6eff99:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6eff9e:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
  6effa5:	00 00 
  6effa7:	48 8b 85 40 06 00 00 	mov    0x640(%rbp),%rax
  6effae:	48 85 c0             	test   %rax,%rax
  6effb1:	74 33                	je     6effe6 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0xe6>
  6effb3:	48 8b b0 00 01 00 00 	mov    0x100(%rax),%rsi
  6effba:	48 85 f6             	test   %rsi,%rsi
  6effbd:	74 27                	je     6effe6 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0xe6>
  6effbf:	48 8d bc 24 38 01 00 	lea    0x138(%rsp),%rdi
  6effc6:	00 
  6effc7:	ff 15 93 b9 39 00    	call   *0x39b993(%rip)        # a8b960 <_DYNAMIC+0x508>
  6effcd:	48 8b 85 80 05 00 00 	mov    0x580(%rbp),%rax
  6effd4:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  6effdb:	00 
  6effdc:	48 85 c0             	test   %rax,%rax
  6effdf:	75 34                	jne    6f0015 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x115>
  6effe1:	e9 11 05 00 00       	jmp    6f04f7 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5f7>
  6effe6:	48 c7 84 24 38 01 00 	movq   $0x4,0x138(%rsp)
  6effed:	00 04 00 00 00 
  6efff2:	0f 57 c0             	xorps  %xmm0,%xmm0
  6efff5:	0f 11 84 24 40 01 00 	movups %xmm0,0x140(%rsp)
  6efffc:	00 
  6efffd:	48 8b 85 80 05 00 00 	mov    0x580(%rbp),%rax
  6f0004:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  6f000b:	00 
  6f000c:	48 85 c0             	test   %rax,%rax
  6f000f:	0f 84 e2 04 00 00    	je     6f04f7 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5f7>
  6f0015:	48 8d 85 c0 05 00 00 	lea    0x5c0(%rbp),%rax
  6f001c:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  6f0021:	45 31 e4             	xor    %r12d,%r12d
  6f0024:	48 8d 05 4d 2e 37 00 	lea    0x372e4d(%rip),%rax        # a62e78 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa78>
  6f002b:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6f0030:	48 89 6c 24 78       	mov    %rbp,0x78(%rsp)
  6f0035:	eb 52                	jmp    6f0089 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x189>
  6f0037:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f003e:	00 00 
  6f0040:	4c 8b a4 24 98 00 00 	mov    0x98(%rsp),%r12
  6f0047:	00 
  6f0048:	49 ff c4             	inc    %r12
  6f004b:	48 89 d8             	mov    %rbx,%rax
  6f004e:	48 c1 e0 07          	shl    $0x7,%rax
  6f0052:	48 8d 3c d8          	lea    (%rax,%rbx,8),%rdi
  6f0056:	48 03 7c 24 40       	add    0x40(%rsp),%rdi
  6f005b:	ba 88 00 00 00       	mov    $0x88,%edx
  6f0060:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
  6f0067:	00 
  6f0068:	ff 15 4a b6 39 00    	call   *0x39b64a(%rip)        # a8b6b8 <memcpy@GLIBC_2.14>
  6f006e:	48 ff c3             	inc    %rbx
  6f0071:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
  6f0076:	4c 3b a4 24 88 00 00 	cmp    0x88(%rsp),%r12
  6f007d:	00 
  6f007e:	48 8b 6c 24 78       	mov    0x78(%rsp),%rbp
  6f0083:	0f 84 6e 04 00 00    	je     6f04f7 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5f7>
  6f0089:	48 8b b5 80 05 00 00 	mov    0x580(%rbp),%rsi
  6f0090:	49 39 f4             	cmp    %rsi,%r12
  6f0093:	0f 83 18 05 00 00    	jae    6f05b1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6b1>
  6f0099:	48 8b 9d 78 05 00 00 	mov    0x578(%rbp),%rbx
  6f00a0:	4c 89 a4 24 98 00 00 	mov    %r12,0x98(%rsp)
  6f00a7:	00 
  6f00a8:	49 c1 e4 06          	shl    $0x6,%r12
  6f00ac:	4e 8b 44 23 20       	mov    0x20(%rbx,%r12,1),%r8
  6f00b1:	80 bd 4a 07 00 00 00 	cmpb   $0x0,0x74a(%rbp)
  6f00b8:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
  6f00bd:	4c 89 44 24 68       	mov    %r8,0x68(%rsp)
  6f00c2:	74 0d                	je     6f00d1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f00c4:	80 bd 4e 07 00 00 00 	cmpb   $0x0,0x74e(%rbp)
  6f00cb:	0f 84 0f 01 00 00    	je     6f01e0 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x2e0>
  6f00d1:	45 31 ff             	xor    %r15d,%r15d
  6f00d4:	4c 01 e3             	add    %r12,%rbx
  6f00d7:	44 8b 63 38          	mov    0x38(%rbx),%r12d
  6f00db:	41 81 e4 ff ff 01 00 	and    $0x1ffff,%r12d
  6f00e2:	45 31 ed             	xor    %r13d,%r13d
  6f00e5:	49 81 fc ff ff 01 00 	cmp    $0x1ffff,%r12
  6f00ec:	0f 95 44 24 0e       	setne  0xe(%rsp)
  6f00f1:	0f b6 43 3d          	movzbl 0x3d(%rbx),%eax
  6f00f5:	2c 02                	sub    $0x2,%al
  6f00f7:	0f b6 c0             	movzbl %al,%eax
  6f00fa:	b9 08 00 00 00       	mov    $0x8,%ecx
  6f00ff:	0f 42 c1             	cmovb  %ecx,%eax
  6f0102:	88 44 24 0f          	mov    %al,0xf(%rsp)
  6f0106:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
  6f010b:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6f0112:	00 
  6f0113:	48 8d 05 96 09 01 00 	lea    0x10996(%rip),%rax        # 700ab0 <<gpui::element::Role as core::fmt::Debug>::fmt>
  6f011a:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  6f0121:	00 
  6f0122:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  6f0129:	00 
  6f012a:	48 8d 35 9a e8 95 ff 	lea    -0x6a1766(%rip),%rsi        # 4e9cb <anon.5558d0fc2e5366f92fec9016dadbf867.4.llvm.9438347653228867760>
  6f0131:	48 8d 94 24 a0 00 00 	lea    0xa0(%rsp),%rdx
  6f0138:	00 
  6f0139:	ff 15 29 b8 39 00    	call   *0x39b829(%rip)        # a8b968 <_DYNAMIC+0x510>
  6f013f:	4c 8b b4 24 b0 00 00 	mov    0xb0(%rsp),%r14
  6f0146:	00 
  6f0147:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  6f014e:	00 
  6f014f:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f0154:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  6f015b:	00 
  6f015c:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6f0163:	00 
  6f0164:	48 8b 6b 28          	mov    0x28(%rbx),%rbp
  6f0168:	48 85 ed             	test   %rbp,%rbp
  6f016b:	74 63                	je     6f01d0 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x2d0>
  6f016d:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
  6f0172:	4c 8b 75 00          	mov    0x0(%rbp),%r14
  6f0176:	49 d1 ee             	shr    $1,%r14
  6f0179:	0f 84 11 01 00 00    	je     6f0290 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x390>
  6f017f:	ff 15 13 b5 39 00    	call   *0x39b513(%rip)        # a8b698 <_DYNAMIC+0x240>
  6f0185:	be 01 00 00 00       	mov    $0x1,%esi
  6f018a:	4c 89 f7             	mov    %r14,%rdi
  6f018d:	ff 15 0d b5 39 00    	call   *0x39b50d(%rip)        # a8b6a0 <_DYNAMIC+0x248>
  6f0193:	48 85 c0             	test   %rax,%rax
  6f0196:	0f 84 25 04 00 00    	je     6f05c1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6c1>
  6f019c:	48 83 c5 10          	add    $0x10,%rbp
  6f01a0:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6f01a5:	48 89 c7             	mov    %rax,%rdi
  6f01a8:	48 89 ee             	mov    %rbp,%rsi
  6f01ab:	4c 89 f2             	mov    %r14,%rdx
  6f01ae:	ff 15 04 b5 39 00    	call   *0x39b504(%rip)        # a8b6b8 <memcpy@GLIBC_2.14>
  6f01b4:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
  6f01b9:	4c 89 f5             	mov    %r14,%rbp
  6f01bc:	e9 e4 00 00 00       	jmp    6f02a5 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x3a5>
  6f01c1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f01c8:	0f 1f 84 00 00 00 00 
  6f01cf:	00 
  6f01d0:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
  6f01d7:	e9 ce 00 00 00       	jmp    6f02aa <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x3aa>
  6f01dc:	0f 1f 40 00          	nopl   0x0(%rax)
  6f01e0:	48 8b 85 e8 01 00 00 	mov    0x1e8(%rbp),%rax
  6f01e7:	48 85 c0             	test   %rax,%rax
  6f01ea:	0f 84 f8 01 00 00    	je     6f03e8 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x4e8>
  6f01f0:	83 f8 01             	cmp    $0x1,%eax
  6f01f3:	0f 85 1c 02 00 00    	jne    6f0415 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x515>
  6f01f9:	4c 8b bd f8 01 00 00 	mov    0x1f8(%rbp),%r15
  6f0200:	4d 85 ff             	test   %r15,%r15
  6f0203:	0f 84 3d 02 00 00    	je     6f0446 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x546>
  6f0209:	48 8b 85 f0 01 00 00 	mov    0x1f0(%rbp),%rax
  6f0210:	31 c9                	xor    %ecx,%ecx
  6f0212:	49 83 ff 01          	cmp    $0x1,%r15
  6f0216:	74 2c                	je     6f0244 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x344>
  6f0218:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6f021f:	00 
  6f0220:	48 89 ca             	mov    %rcx,%rdx
  6f0223:	4c 89 fe             	mov    %r15,%rsi
  6f0226:	48 d1 ee             	shr    $1,%rsi
  6f0229:	48 01 f1             	add    %rsi,%rcx
  6f022c:	48 89 cf             	mov    %rcx,%rdi
  6f022f:	48 c1 e7 04          	shl    $0x4,%rdi
  6f0233:	4c 39 04 38          	cmp    %r8,(%rax,%rdi,1)
  6f0237:	48 0f 47 ca          	cmova  %rdx,%rcx
  6f023b:	49 29 f7             	sub    %rsi,%r15
  6f023e:	49 83 ff 01          	cmp    $0x1,%r15
  6f0242:	77 dc                	ja     6f0220 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x320>
  6f0244:	48 89 ce             	mov    %rcx,%rsi
  6f0247:	48 c1 e6 04          	shl    $0x4,%rsi
  6f024b:	31 d2                	xor    %edx,%edx
  6f024d:	4c 39 04 30          	cmp    %r8,(%rax,%rsi,1)
  6f0251:	0f 96 c2             	setbe  %dl
  6f0254:	48 01 ca             	add    %rcx,%rdx
  6f0257:	0f 84 74 fe ff ff    	je     6f00d1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f025d:	48 c1 e2 04          	shl    $0x4,%rdx
  6f0261:	4c 89 c1             	mov    %r8,%rcx
  6f0264:	48 2b 4c 10 f0       	sub    -0x10(%rax,%rdx,1),%rcx
  6f0269:	8b 74 10 fc          	mov    -0x4(%rax,%rdx,1),%esi
  6f026d:	48 39 f1             	cmp    %rsi,%rcx
  6f0270:	0f 83 5b fe ff ff    	jae    6f00d1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f0276:	48 01 d0             	add    %rdx,%rax
  6f0279:	8b 40 f8             	mov    -0x8(%rax),%eax
  6f027c:	48 01 c1             	add    %rax,%rcx
  6f027f:	80 7c 24 34 00       	cmpb   $0x0,0x34(%rsp)
  6f0284:	0f 84 03 02 00 00    	je     6f048d <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x58d>
  6f028a:	e9 4a 02 00 00       	jmp    6f04d9 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5d9>
  6f028f:	90                   	nop
  6f0290:	b8 01 00 00 00       	mov    $0x1,%eax
  6f0295:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6f029a:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
  6f02a1:	00 00 
  6f02a3:	31 ed                	xor    %ebp,%ebp
  6f02a5:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
  6f02aa:	0f 10 43 10          	movups 0x10(%rbx),%xmm0
  6f02ae:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  6f02b3:	48 8d bc 24 38 01 00 	lea    0x138(%rsp),%rdi
  6f02ba:	00 
  6f02bb:	ff 15 af b6 39 00    	call   *0x39b6af(%rip)        # a8b970 <_DYNAMIC+0x518>
  6f02c1:	48 89 d1             	mov    %rdx,%rcx
  6f02c4:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  6f02cb:	00 
  6f02cc:	48 89 de             	mov    %rbx,%rsi
  6f02cf:	48 89 c2             	mov    %rax,%rdx
  6f02d2:	ff 15 a0 b6 39 00    	call   *0x39b6a0(%rip)        # a8b978 <_DYNAMIC+0x520>
  6f02d8:	8b 84 24 b0 00 00 00 	mov    0xb0(%rsp),%eax
  6f02df:	85 c0                	test   %eax,%eax
  6f02e1:	75 1d                	jne    6f0300 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x400>
  6f02e3:	0f 28 84 24 60 01 00 	movaps 0x160(%rsp),%xmm0
  6f02ea:	00 
  6f02eb:	0f 28 8c 24 50 01 00 	movaps 0x150(%rsp),%xmm1
  6f02f2:	00 
  6f02f3:	eb 1c                	jmp    6f0311 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x411>
  6f02f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6f02fc:	00 00 00 00 
  6f0300:	0f 10 84 24 b4 00 00 	movups 0xb4(%rsp),%xmm0
  6f0307:	00 
  6f0308:	f2 0f 10 8c 24 c4 00 	movsd  0xc4(%rsp),%xmm1
  6f030f:	00 00 
  6f0311:	0f b6 4c 24 0e       	movzbl 0xe(%rsp),%ecx
  6f0316:	41 88 cd             	mov    %cl,%r13b
  6f0319:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  6f031e:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
  6f0325:	00 
  6f0326:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
  6f032d:	00 
  6f032e:	4c 89 a4 24 b8 00 00 	mov    %r12,0xb8(%rsp)
  6f0335:	00 
  6f0336:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
  6f033d:	00 
  6f033e:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  6f0343:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
  6f034a:	00 
  6f034b:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  6f0352:	00 
  6f0353:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
  6f035a:	00 
  6f035b:	48 89 ac 24 d8 00 00 	mov    %rbp,0xd8(%rsp)
  6f0362:	00 
  6f0363:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  6f0368:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
  6f036f:	00 
  6f0370:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
  6f0375:	4c 89 b4 24 e8 00 00 	mov    %r14,0xe8(%rsp)
  6f037c:	00 
  6f037d:	0f 28 54 24 10       	movaps 0x10(%rsp),%xmm2
  6f0382:	0f 11 94 24 f8 00 00 	movups %xmm2,0xf8(%rsp)
  6f0389:	00 
  6f038a:	89 84 24 18 01 00 00 	mov    %eax,0x118(%rsp)
  6f0391:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  6f0398:	00 
  6f0399:	0f 11 84 24 1c 01 00 	movups %xmm0,0x11c(%rsp)
  6f03a0:	00 
  6f03a1:	0f 29 8c 24 50 01 00 	movaps %xmm1,0x150(%rsp)
  6f03a8:	00 
  6f03a9:	0f 13 8c 24 2c 01 00 	movlps %xmm1,0x12c(%rsp)
  6f03b0:	00 
  6f03b1:	4c 89 bc 24 08 01 00 	mov    %r15,0x108(%rsp)
  6f03b8:	00 
  6f03b9:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  6f03c0:	00 
  6f03c1:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
  6f03c8:	00 
  6f03c9:	48 8b 5c 24 48       	mov    0x48(%rsp),%rbx
  6f03ce:	48 3b 5c 24 38       	cmp    0x38(%rsp),%rbx
  6f03d3:	0f 85 67 fc ff ff    	jne    6f0040 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x140>
  6f03d9:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  6f03de:	e8 6d 0a 03 00       	call   720e50 <<alloc::raw_vec::RawVec<gpui::runtime::SnapshotNode>>::grow_one>
  6f03e3:	e9 58 fc ff ff       	jmp    6f0040 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x140>
  6f03e8:	4c 89 c1             	mov    %r8,%rcx
  6f03eb:	48 2b 8d f0 01 00 00 	sub    0x1f0(%rbp),%rcx
  6f03f2:	0f 82 d9 fc ff ff    	jb     6f00d1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f03f8:	48 3b 8d f8 01 00 00 	cmp    0x1f8(%rbp),%rcx
  6f03ff:	0f 83 cc fc ff ff    	jae    6f00d1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f0405:	80 7c 24 34 00       	cmpb   $0x0,0x34(%rsp)
  6f040a:	0f 84 7d 00 00 00    	je     6f048d <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x58d>
  6f0410:	e9 c4 00 00 00       	jmp    6f04d9 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5d9>
  6f0415:	4c 8b bd f8 01 00 00 	mov    0x1f8(%rbp),%r15
  6f041c:	4d 85 ff             	test   %r15,%r15
  6f041f:	74 25                	je     6f0446 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x546>
  6f0421:	48 8b 85 f0 01 00 00 	mov    0x1f0(%rbp),%rax
  6f0428:	49 83 ff 01          	cmp    $0x1,%r15
  6f042c:	75 1d                	jne    6f044b <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x54b>
  6f042e:	4c 39 00             	cmp    %r8,(%rax)
  6f0431:	0f 85 9a fc ff ff    	jne    6f00d1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f0437:	8b 48 08             	mov    0x8(%rax),%ecx
  6f043a:	80 7c 24 34 00       	cmpb   $0x0,0x34(%rsp)
  6f043f:	74 4c                	je     6f048d <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x58d>
  6f0441:	e9 93 00 00 00       	jmp    6f04d9 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5d9>
  6f0446:	e9 89 fc ff ff       	jmp    6f00d4 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d4>
  6f044b:	31 c9                	xor    %ecx,%ecx
  6f044d:	0f 1f 00             	nopl   (%rax)
  6f0450:	48 89 ca             	mov    %rcx,%rdx
  6f0453:	4c 89 fe             	mov    %r15,%rsi
  6f0456:	48 d1 ee             	shr    $1,%rsi
  6f0459:	48 01 f1             	add    %rsi,%rcx
  6f045c:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
  6f0460:	4c 39 04 b8          	cmp    %r8,(%rax,%rdi,4)
  6f0464:	48 0f 47 ca          	cmova  %rdx,%rcx
  6f0468:	49 29 f7             	sub    %rsi,%r15
  6f046b:	49 83 ff 01          	cmp    $0x1,%r15
  6f046f:	77 df                	ja     6f0450 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x550>
  6f0471:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  6f0475:	4c 39 04 88          	cmp    %r8,(%rax,%rcx,4)
  6f0479:	0f 85 52 fc ff ff    	jne    6f00d1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f047f:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
  6f0483:	8b 48 08             	mov    0x8(%rax),%ecx
  6f0486:	80 7c 24 34 00       	cmpb   $0x0,0x34(%rsp)
  6f048b:	75 4c                	jne    6f04d9 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5d9>
  6f048d:	48 8b b5 a0 02 00 00 	mov    0x2a0(%rbp),%rsi
  6f0494:	48 39 f1             	cmp    %rsi,%rcx
  6f0497:	0f 83 34 01 00 00    	jae    6f05d1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6d1>
  6f049d:	48 8b 85 98 02 00 00 	mov    0x298(%rbp),%rax
  6f04a4:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  6f04a8:	8b 44 c8 10          	mov    0x10(%rax,%rcx,8),%eax
  6f04ac:	85 c0                	test   %eax,%eax
  6f04ae:	78 29                	js     6f04d9 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5d9>
  6f04b0:	83 e0 0f             	and    $0xf,%eax
  6f04b3:	8d 48 fd             	lea    -0x3(%rax),%ecx
  6f04b6:	83 f9 07             	cmp    $0x7,%ecx
  6f04b9:	0f 82 12 fc ff ff    	jb     6f00d1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f04bf:	41 bf 00 00 00 00    	mov    $0x0,%r15d
  6f04c5:	83 f8 02             	cmp    $0x2,%eax
  6f04c8:	0f 82 06 fc ff ff    	jb     6f00d4 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d4>
  6f04ce:	4c 8b 44 24 68       	mov    0x68(%rsp),%r8
  6f04d3:	0f 85 bd 00 00 00    	jne    6f0596 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x696>
  6f04d9:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
  6f04de:	4c 89 c6             	mov    %r8,%rsi
  6f04e1:	ff 15 e9 b2 39 00    	call   *0x39b2e9(%rip)        # a8b7d0 <_DYNAMIC+0x378>
  6f04e7:	48 89 94 24 80 00 00 	mov    %rdx,0x80(%rsp)
  6f04ee:	00 
  6f04ef:	49 89 c7             	mov    %rax,%r15
  6f04f2:	e9 dd fb ff ff       	jmp    6f00d4 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d4>
  6f04f7:	0f 10 85 90 06 00 00 	movups 0x690(%rbp),%xmm0
  6f04fe:	0f b6 85 4c 07 00 00 	movzbl 0x74c(%rbp),%eax
  6f0505:	48 83 bd b0 06 00 00 	cmpq   $0x0,0x6b0(%rbp)
  6f050c:	00 
  6f050d:	74 21                	je     6f0530 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x630>
  6f050f:	84 c0                	test   %al,%al
  6f0511:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  6f0516:	74 0a                	je     6f0522 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x622>
  6f0518:	48 83 bd 88 05 00 00 	cmpq   $0xffffffffffffffff,0x588(%rbp)
  6f051f:	ff 
  6f0520:	74 17                	je     6f0539 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x639>
  6f0522:	48 8b 95 c0 06 00 00 	mov    0x6c0(%rbp),%rdx
  6f0529:	b9 01 00 00 00       	mov    $0x1,%ecx
  6f052e:	eb 0b                	jmp    6f053b <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x63b>
  6f0530:	31 c9                	xor    %ecx,%ecx
  6f0532:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  6f0537:	eb 02                	jmp    6f053b <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x63b>
  6f0539:	31 c9                	xor    %ecx,%ecx
  6f053b:	0f b6 b5 4e 07 00 00 	movzbl 0x74e(%rbp),%esi
  6f0542:	4c 8b 44 24 48       	mov    0x48(%rsp),%r8
  6f0547:	4c 89 47 20          	mov    %r8,0x20(%rdi)
  6f054b:	0f 10 4c 24 38       	movups 0x38(%rsp),%xmm1
  6f0550:	0f 11 4f 10          	movups %xmm1,0x10(%rdi)
  6f0554:	48 89 0f             	mov    %rcx,(%rdi)
  6f0557:	48 89 57 08          	mov    %rdx,0x8(%rdi)
  6f055b:	0f 11 47 28          	movups %xmm0,0x28(%rdi)
  6f055f:	0f 10 85 a0 06 00 00 	movups 0x6a0(%rbp),%xmm0
  6f0566:	0f 11 47 38          	movups %xmm0,0x38(%rdi)
  6f056a:	f2 0f 10 85 40 07 00 	movsd  0x740(%rbp),%xmm0
  6f0571:	00 
  6f0572:	0f c6 c0 e1          	shufps $0xe1,%xmm0,%xmm0
  6f0576:	0f 13 47 48          	movlps %xmm0,0x48(%rdi)
  6f057a:	88 47 50             	mov    %al,0x50(%rdi)
  6f057d:	40 88 77 51          	mov    %sil,0x51(%rdi)
  6f0581:	48 89 f8             	mov    %rdi,%rax
  6f0584:	48 81 c4 78 01 00 00 	add    $0x178,%rsp
  6f058b:	5b                   	pop    %rbx
  6f058c:	41 5c                	pop    %r12
  6f058e:	41 5d                	pop    %r13
  6f0590:	41 5e                	pop    %r14
  6f0592:	41 5f                	pop    %r15
  6f0594:	5d                   	pop    %rbp
  6f0595:	c3                   	ret
  6f0596:	48 8d 3d c1 a4 96 ff 	lea    -0x695b3f(%rip),%rdi        # 5aa5e <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2db6>
  6f059d:	48 8d 15 bc 28 37 00 	lea    0x3728bc(%rip),%rdx        # a62e60 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa60>
  6f05a4:	be 83 00 00 00       	mov    $0x83,%esi
  6f05a9:	ff 15 39 b1 39 00    	call   *0x39b139(%rip)        # a8b6e8 <_DYNAMIC+0x290>
  6f05af:	eb 1e                	jmp    6f05cf <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6cf>
  6f05b1:	4c 89 e7             	mov    %r12,%rdi
  6f05b4:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  6f05b9:	ff 15 01 b2 39 00    	call   *0x39b201(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6f05bf:	eb 0e                	jmp    6f05cf <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6cf>
  6f05c1:	bf 01 00 00 00       	mov    $0x1,%edi
  6f05c6:	4c 89 f6             	mov    %r14,%rsi
  6f05c9:	ff 15 a1 b1 39 00    	call   *0x39b1a1(%rip)        # a8b770 <_DYNAMIC+0x318>
  6f05cf:	0f 0b                	ud2
  6f05d1:	48 89 cf             	mov    %rcx,%rdi
  6f05d4:	48 8d 05 b5 28 37 00 	lea    0x3728b5(%rip),%rax        # a62e90 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa90>
  6f05db:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6f05e0:	eb d2                	jmp    6f05b4 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6b4>
  6f05e2:	48 89 c3             	mov    %rax,%rbx
  6f05e5:	eb 44                	jmp    6f062b <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x72b>
  6f05e7:	48 89 c3             	mov    %rax,%rbx
  6f05ea:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  6f05f1:	00 
  6f05f2:	e8 79 4b ff ff       	call   6e5170 <core::ptr::drop_glue::<gpui::runtime::SnapshotNode>>
  6f05f7:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  6f05fc:	e8 8f 38 ff ff       	call   6e3e90 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::SnapshotNode>>>
  6f0601:	48 89 df             	mov    %rbx,%rdi
  6f0604:	e8 c7 09 37 00       	call   a60fd0 <_Unwind_Resume@plt>
  6f0609:	eb 4f                	jmp    6f065a <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x75a>
  6f060b:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
  6f0610:	48 89 c3             	mov    %rax,%rbx
  6f0613:	48 85 ed             	test   %rbp,%rbp
  6f0616:	7e 13                	jle    6f062b <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x72b>
  6f0618:	ba 01 00 00 00       	mov    $0x1,%edx
  6f061d:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6f0622:	48 89 ee             	mov    %rbp,%rsi
  6f0625:	ff 15 7d b0 39 00    	call   *0x39b07d(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f062b:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
  6f0631:	74 2a                	je     6f065d <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x75d>
  6f0633:	ba 01 00 00 00       	mov    $0x1,%edx
  6f0638:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
  6f063d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  6f0642:	ff 15 60 b0 39 00    	call   *0x39b060(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f0648:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  6f064d:	e8 3e 38 ff ff       	call   6e3e90 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::SnapshotNode>>>
  6f0652:	48 89 df             	mov    %rbx,%rdi
  6f0655:	e8 76 09 37 00       	call   a60fd0 <_Unwind_Resume@plt>
  6f065a:	48 89 c3             	mov    %rax,%rbx
  6f065d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  6f0662:	e8 29 38 ff ff       	call   6e3e90 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::SnapshotNode>>>
  6f0667:	48 89 df             	mov    %rbx,%rdi
  6f066a:	e8 61 09 37 00       	call   a60fd0 <_Unwind_Resume@plt>
