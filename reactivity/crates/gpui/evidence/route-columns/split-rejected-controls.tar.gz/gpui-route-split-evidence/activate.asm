
/tmp/gpui-route-split-evidence/bin/split-cost:     file format elf64-x86-64


Disassembly of section .text:

00000000006f0950 <<gpui::runtime::Win<route_columns_cost::Page>>::activate>:
  6f0950:	55                   	push   %rbp
  6f0951:	41 57                	push   %r15
  6f0953:	41 56                	push   %r14
  6f0955:	41 55                	push   %r13
  6f0957:	41 54                	push   %r12
  6f0959:	53                   	push   %rbx
  6f095a:	48 81 ec 98 00 00 00 	sub    $0x98,%rsp
  6f0961:	48 89 fb             	mov    %rdi,%rbx
  6f0964:	4c 8b 36             	mov    (%rsi),%r14
  6f0967:	4d 85 f6             	test   %r14,%r14
  6f096a:	74 2d                	je     6f0999 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x49>
  6f096c:	48 83 c6 08          	add    $0x8,%rsi
  6f0970:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
  6f0975:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
  6f097a:	48 c7 44 24 78 00 00 	movq   $0x0,0x78(%rsp)
  6f0981:	00 00 
  6f0983:	41 80 be 4e 07 00 00 	cmpb   $0x1,0x74e(%r14)
  6f098a:	01 
  6f098b:	75 20                	jne    6f09ad <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x5d>
  6f098d:	48 c7 03 0e 00 00 00 	movq   $0xe,(%rbx)
  6f0994:	e9 98 00 00 00       	jmp    6f0a31 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0xe1>
  6f0999:	48 c7 03 0d 00 00 00 	movq   $0xd,(%rbx)
  6f09a0:	48 c7 43 08 00 00 00 	movq   $0x0,0x8(%rbx)
  6f09a7:	00 
  6f09a8:	e9 84 00 00 00       	jmp    6f0a31 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0xe1>
  6f09ad:	49 89 f4             	mov    %rsi,%r12
  6f09b0:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  6f09b5:	4c 89 f6             	mov    %r14,%rsi
  6f09b8:	e8 93 63 00 00       	call   6f6d50 <<gpui::runtime::Runtime<route_columns_cost::Page>>::resolve_index>
  6f09bd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6f09c2:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6f09c7:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6f09cb:	75 42                	jne    6f0a0f <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0xbf>
  6f09cd:	49 8b b6 a0 02 00 00 	mov    0x2a0(%r14),%rsi
  6f09d4:	49 39 f7             	cmp    %rsi,%r15
  6f09d7:	0f 83 bb 02 00 00    	jae    6f0c98 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x348>
  6f09dd:	49 8b 86 98 02 00 00 	mov    0x298(%r14),%rax
  6f09e4:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
  6f09e8:	8b 7c c8 10          	mov    0x10(%rax,%rcx,8),%edi
  6f09ec:	89 fa                	mov    %edi,%edx
  6f09ee:	83 e2 0f             	and    $0xf,%edx
  6f09f1:	8d 72 fd             	lea    -0x3(%rdx),%esi
  6f09f4:	83 fe 07             	cmp    $0x7,%esi
  6f09f7:	72 09                	jb     6f0a02 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0xb2>
  6f09f9:	83 fa 02             	cmp    $0x2,%edx
  6f09fc:	0f 83 13 01 00 00    	jae    6f0b15 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1c5>
  6f0a02:	85 ff                	test   %edi,%edi
  6f0a04:	78 40                	js     6f0a46 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0xf6>
  6f0a06:	48 c7 03 16 00 00 00 	movq   $0x16,(%rbx)
  6f0a0d:	eb 22                	jmp    6f0a31 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0xe1>
  6f0a0f:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  6f0a14:	48 89 4b 30          	mov    %rcx,0x30(%rbx)
  6f0a18:	0f 10 44 24 30       	movups 0x30(%rsp),%xmm0
  6f0a1d:	0f 10 4c 24 40       	movups 0x40(%rsp),%xmm1
  6f0a22:	0f 11 4b 20          	movups %xmm1,0x20(%rbx)
  6f0a26:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
  6f0a2a:	48 89 03             	mov    %rax,(%rbx)
  6f0a2d:	4c 89 7b 08          	mov    %r15,0x8(%rbx)
  6f0a31:	48 89 d8             	mov    %rbx,%rax
  6f0a34:	48 81 c4 98 00 00 00 	add    $0x98,%rsp
  6f0a3b:	5b                   	pop    %rbx
  6f0a3c:	41 5c                	pop    %r12
  6f0a3e:	41 5d                	pop    %r13
  6f0a40:	41 5e                	pop    %r14
  6f0a42:	41 5f                	pop    %r15
  6f0a44:	5d                   	pop    %rbp
  6f0a45:	c3                   	ret
  6f0a46:	48 8d 04 c8          	lea    (%rax,%rcx,8),%rax
  6f0a4a:	8b 40 0c             	mov    0xc(%rax),%eax
  6f0a4d:	c1 e8 11             	shr    $0x11,%eax
  6f0a50:	c1 ef 0e             	shr    $0xe,%edi
  6f0a53:	81 e7 00 80 01 00    	and    $0x18000,%edi
  6f0a59:	09 c7                	or     %eax,%edi
  6f0a5b:	49 8b b6 b8 05 00 00 	mov    0x5b8(%r14),%rsi
  6f0a62:	48 39 fe             	cmp    %rdi,%rsi
  6f0a65:	0f 86 3d 02 00 00    	jbe    6f0ca8 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x358>
  6f0a6b:	49 8b ae b0 05 00 00 	mov    0x5b0(%r14),%rbp
  6f0a72:	c1 e7 04             	shl    $0x4,%edi
  6f0a75:	48 83 7c 3d 00 00    	cmpq   $0x0,0x0(%rbp,%rdi,1)
  6f0a7b:	74 89                	je     6f0a06 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0xb6>
  6f0a7d:	48 01 fd             	add    %rdi,%rbp
  6f0a80:	49 8d 96 d0 05 00 00 	lea    0x5d0(%r14),%rdx
  6f0a87:	4d 8d 86 28 02 00 00 	lea    0x228(%r14),%r8
  6f0a8e:	48 8d 0d 4b 1b 37 00 	lea    0x371b4b(%rip),%rcx        # a625e0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x1e0>
  6f0a95:	4c 8d 0d 64 1b 37 00 	lea    0x371b64(%rip),%r9        # a62600 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x200>
  6f0a9c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  6f0aa1:	48 89 ee             	mov    %rbp,%rsi
  6f0aa4:	ff 15 d6 ae 39 00    	call   *0x39aed6(%rip)        # a8b980 <_DYNAMIC+0x528>
  6f0aaa:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6f0aaf:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  6f0ab4:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  6f0ab9:	48 89 04 24          	mov    %rax,(%rsp)
  6f0abd:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
  6f0ac2:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  6f0ac7:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6f0acb:	0f 84 37 02 00 00    	je     6f0d08 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x3b8>
  6f0ad1:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f0ad5:	75 7b                	jne    6f0b52 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x202>
  6f0ad7:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  6f0adc:	48 89 e7             	mov    %rsp,%rdi
  6f0adf:	e8 ac 23 ff ff       	call   6e2e90 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6f0ae4:	66 45 85 ed          	test   %r13w,%r13w
  6f0ae8:	0f 84 ab 00 00 00    	je     6f0b99 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x249>
  6f0aee:	41 0f b7 c5          	movzwl %r13w,%eax
  6f0af2:	83 f8 01             	cmp    $0x1,%eax
  6f0af5:	0f 85 45 01 00 00    	jne    6f0c40 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x2f0>
  6f0afb:	49 c1 ed 10          	shr    $0x10,%r13
  6f0aff:	48 89 df             	mov    %rbx,%rdi
  6f0b02:	4c 89 f6             	mov    %r14,%rsi
  6f0b05:	4c 89 e2             	mov    %r12,%rdx
  6f0b08:	44 89 e9             	mov    %r13d,%ecx
  6f0b0b:	e8 90 d7 ff ff       	call   6ee2a0 <<gpui::runtime::RuntimeMut<route_columns_cost::Page, ()>>::window_action>
  6f0b10:	e9 1c ff ff ff       	jmp    6f0a31 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0xe1>
  6f0b15:	0f 85 58 01 00 00    	jne    6f0c73 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x323>
  6f0b1b:	49 c7 86 38 07 00 00 	movq   $0x0,0x738(%r14)
  6f0b22:	00 00 00 00 
  6f0b26:	41 0f 10 86 90 06 00 	movups 0x690(%r14),%xmm0
  6f0b2d:	00 
  6f0b2e:	41 0f b6 86 4c 07 00 	movzbl 0x74c(%r14),%eax
  6f0b35:	00 
  6f0b36:	49 83 be b0 06 00 00 	cmpq   $0x0,0x6b0(%r14)
  6f0b3d:	00 
  6f0b3e:	74 0e                	je     6f0b4e <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1fe>
  6f0b40:	84 c0                	test   %al,%al
  6f0b42:	74 26                	je     6f0b6a <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x21a>
  6f0b44:	49 83 be 88 05 00 00 	cmpq   $0xffffffffffffffff,0x588(%r14)
  6f0b4b:	ff 
  6f0b4c:	75 1c                	jne    6f0b6a <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x21a>
  6f0b4e:	31 c9                	xor    %ecx,%ecx
  6f0b50:	eb 24                	jmp    6f0b76 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x226>
  6f0b52:	48 c7 03 20 00 00 00 	movq   $0x20,(%rbx)
  6f0b59:	48 89 43 08          	mov    %rax,0x8(%rbx)
  6f0b5d:	4c 89 6b 10          	mov    %r13,0x10(%rbx)
  6f0b61:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
  6f0b65:	e9 c7 fe ff ff       	jmp    6f0a31 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0xe1>
  6f0b6a:	49 8b 96 c0 06 00 00 	mov    0x6c0(%r14),%rdx
  6f0b71:	b9 01 00 00 00       	mov    $0x1,%ecx
  6f0b76:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
  6f0b7a:	48 89 53 10          	mov    %rdx,0x10(%rbx)
  6f0b7e:	0f 11 43 18          	movups %xmm0,0x18(%rbx)
  6f0b82:	48 c7 43 28 00 00 00 	movq   $0x0,0x28(%rbx)
  6f0b89:	00 
  6f0b8a:	88 43 30             	mov    %al,0x30(%rbx)
  6f0b8d:	48 c7 03 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rbx)
  6f0b94:	e9 98 fe ff ff       	jmp    6f0a31 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0xe1>
  6f0b99:	4d 8b be 90 06 00 00 	mov    0x690(%r14),%r15
  6f0ba0:	49 ff c7             	inc    %r15
  6f0ba3:	0f 84 e3 00 00 00    	je     6f0c8c <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x33c>
  6f0ba9:	48 c7 44 24 20 1f 00 	movq   $0x1f,0x20(%rsp)
  6f0bb0:	00 00 
  6f0bb2:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  6f0bb7:	e8 f4 45 ff ff       	call   6e51b0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6f0bbc:	48 8d 0d 1d 1a 37 00 	lea    0x371a1d(%rip),%rcx        # a625e0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x1e0>
  6f0bc3:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  6f0bc8:	48 89 ee             	mov    %rbp,%rsi
  6f0bcb:	49 8d 96 d0 05 00 00 	lea    0x5d0(%r14),%rdx
  6f0bd2:	ff 15 b0 ad 39 00    	call   *0x39adb0(%rip)        # a8b988 <_DYNAMIC+0x530>
  6f0bd8:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6f0bdd:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  6f0be2:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
  6f0be7:	0f 29 04 24          	movaps %xmm0,(%rsp)
  6f0beb:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  6f0bf0:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6f0bf4:	0f 84 d6 00 00 00    	je     6f0cd0 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x380>
  6f0bfa:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f0bfe:	75 5a                	jne    6f0c5a <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x30a>
  6f0c00:	48 89 e7             	mov    %rsp,%rdi
  6f0c03:	e8 88 22 ff ff       	call   6e2e90 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6f0c08:	4d 89 be 90 06 00 00 	mov    %r15,0x690(%r14)
  6f0c0f:	49 ff 86 e0 06 00 00 	incq   0x6e0(%r14)
  6f0c16:	49 c7 86 38 07 00 00 	movq   $0x0,0x738(%r14)
  6f0c1d:	00 00 00 00 
  6f0c21:	48 8d 74 24 68       	lea    0x68(%rsp),%rsi
  6f0c26:	48 8d 4c 24 78       	lea    0x78(%rsp),%rcx
  6f0c2b:	48 89 df             	mov    %rbx,%rdi
  6f0c2e:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  6f0c33:	45 31 c0             	xor    %r8d,%r8d
  6f0c36:	e8 b5 82 ff ff       	call   6e8ef0 <<gpui::runtime::RuntimeMut<route_columns_cost::Page, ()>>::after_source_changed>
  6f0c3b:	e9 f1 fd ff ff       	jmp    6f0a31 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0xe1>
  6f0c40:	48 8d 74 24 68       	lea    0x68(%rsp),%rsi
  6f0c45:	48 8d 4c 24 78       	lea    0x78(%rsp),%rcx
  6f0c4a:	48 89 df             	mov    %rbx,%rdi
  6f0c4d:	4c 89 fa             	mov    %r15,%rdx
  6f0c50:	e8 5b 76 ff ff       	call   6e82b0 <<gpui::runtime::RuntimeMut<route_columns_cost::Page, ()>>::activate_property>
  6f0c55:	e9 d7 fd ff ff       	jmp    6f0a31 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0xe1>
  6f0c5a:	0f 10 44 24 08       	movups 0x8(%rsp),%xmm0
  6f0c5f:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
  6f0c63:	48 c7 03 20 00 00 00 	movq   $0x20,(%rbx)
  6f0c6a:	48 89 43 08          	mov    %rax,0x8(%rbx)
  6f0c6e:	e9 be fd ff ff       	jmp    6f0a31 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0xe1>
  6f0c73:	48 8d 3d e4 9d 96 ff 	lea    -0x69621c(%rip),%rdi        # 5aa5e <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2db6>
  6f0c7a:	48 8d 15 df 21 37 00 	lea    0x3721df(%rip),%rdx        # a62e60 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa60>
  6f0c81:	be 83 00 00 00       	mov    $0x83,%esi
  6f0c86:	ff 15 5c aa 39 00    	call   *0x39aa5c(%rip)        # a8b6e8 <_DYNAMIC+0x290>
  6f0c8c:	48 c7 03 1f 00 00 00 	movq   $0x1f,(%rbx)
  6f0c93:	e9 99 fd ff ff       	jmp    6f0a31 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0xe1>
  6f0c98:	48 8d 15 f9 1d 37 00 	lea    0x371df9(%rip),%rdx        # a62a98 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x698>
  6f0c9f:	4c 89 ff             	mov    %r15,%rdi
  6f0ca2:	ff 15 18 ab 39 00    	call   *0x39ab18(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6f0ca8:	48 8d 15 01 1e 37 00 	lea    0x371e01(%rip),%rdx        # a62ab0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x6b0>
  6f0caf:	ff 15 0b ab 39 00    	call   *0x39ab0b(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6f0cb5:	48 89 c7             	mov    %rax,%rdi
  6f0cb8:	ff 15 32 ab 39 00    	call   *0x39ab32(%rip)        # a8b7f0 <_DYNAMIC+0x398>
  6f0cbe:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6f0cc3:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  6f0cc8:	48 c7 04 24 fe ff ff 	movq   $0xfffffffffffffffe,(%rsp)
  6f0ccf:	ff 
  6f0cd0:	4c 89 f7             	mov    %r14,%rdi
  6f0cd3:	e8 48 e2 00 00       	call   6fef20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::poison>
  6f0cd8:	eb 36                	jmp    6f0d10 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x3c0>
  6f0cda:	ff 15 18 ab 39 00    	call   *0x39ab18(%rip)        # a8b7f8 <_DYNAMIC+0x3a0>
  6f0ce0:	48 89 c3             	mov    %rax,%rbx
  6f0ce3:	48 89 e7             	mov    %rsp,%rdi
  6f0ce6:	e8 a5 21 ff ff       	call   6e2e90 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6f0ceb:	eb 48                	jmp    6f0d35 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x3e5>
  6f0ced:	48 89 c7             	mov    %rax,%rdi
  6f0cf0:	ff 15 fa aa 39 00    	call   *0x39aafa(%rip)        # a8b7f0 <_DYNAMIC+0x398>
  6f0cf6:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6f0cfb:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  6f0d00:	48 c7 04 24 fe ff ff 	movq   $0xfffffffffffffffe,(%rsp)
  6f0d07:	ff 
  6f0d08:	4c 89 f7             	mov    %r14,%rdi
  6f0d0b:	e8 10 e2 00 00       	call   6fef20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::poison>
  6f0d10:	48 c7 03 0f 00 00 00 	movq   $0xf,(%rbx)
  6f0d17:	48 89 e7             	mov    %rsp,%rdi
  6f0d1a:	e8 71 21 ff ff       	call   6e2e90 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6f0d1f:	e9 0d fd ff ff       	jmp    6f0a31 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0xe1>
  6f0d24:	ff 15 ce aa 39 00    	call   *0x39aace(%rip)        # a8b7f8 <_DYNAMIC+0x3a0>
  6f0d2a:	48 89 c3             	mov    %rax,%rbx
  6f0d2d:	48 89 e7             	mov    %rsp,%rdi
  6f0d30:	e8 5b 21 ff ff       	call   6e2e90 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6f0d35:	48 89 df             	mov    %rbx,%rdi
  6f0d38:	e8 93 02 37 00       	call   a60fd0 <_Unwind_Resume@plt>
  6f0d3d:	ff 15 9d a9 39 00    	call   *0x39a99d(%rip)        # a8b6e0 <_DYNAMIC+0x288>
