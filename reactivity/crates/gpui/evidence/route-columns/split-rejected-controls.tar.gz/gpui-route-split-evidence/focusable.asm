
/tmp/gpui-route-split-evidence/bin/split-cost:     file format elf64-x86-64


Disassembly of section .text:

0000000000732440 <<gpui::runtime::Node>::focusable>:
  732440:	8b 47 10             	mov    0x10(%rdi),%eax
  732443:	89 c1                	mov    %eax,%ecx
  732445:	83 e1 0f             	and    $0xf,%ecx
  732448:	83 f9 0a             	cmp    $0xa,%ecx
  73244b:	73 11                	jae    73245e <<gpui::runtime::Node>::focusable+0x1e>
  73244d:	ba 0c 00 00 00       	mov    $0xc,%edx
  732452:	d3 ea                	shr    %cl,%edx
  732454:	85 c0                	test   %eax,%eax
  732456:	0f 98 c0             	sets   %al
  732459:	08 d0                	or     %dl,%al
  73245b:	24 01                	and    $0x1,%al
  73245d:	c3                   	ret
  73245e:	50                   	push   %rax
  73245f:	48 8d 3d c8 a1 92 ff 	lea    -0x6d5e38(%rip),%rdi        # 5c62e <anon.b9946fe4defe8b854d134b4bf5265d75.25.llvm.10307981152027530048+0x1ea>
  732466:	48 8d 15 db 28 33 00 	lea    0x3328db(%rip),%rdx        # a64d48 <anon.b9946fe4defe8b854d134b4bf5265d75.26.llvm.10307981152027530048+0x70>
  73246d:	be 83 00 00 00       	mov    $0x83,%esi
  732472:	ff 15 70 92 35 00    	call   *0x359270(%rip)        # a8b6e8 <_DYNAMIC+0x290>
