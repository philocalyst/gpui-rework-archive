
/tmp/gpui-route-split-evidence/bin/split-cost:     file format elf64-x86-64


Disassembly of section .text:

00000000006f7010 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner>:
  6f7010:	55                   	push   %rbp
  6f7011:	41 57                	push   %r15
  6f7013:	41 56                	push   %r14
  6f7015:	41 55                	push   %r13
  6f7017:	41 54                	push   %r12
  6f7019:	53                   	push   %rbx
  6f701a:	48 81 ec d8 08 00 00 	sub    $0x8d8,%rsp
  6f7021:	4d 89 c4             	mov    %r8,%r12
  6f7024:	48 89 cb             	mov    %rcx,%rbx
  6f7027:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
  6f702c:	0f b6 86 4a 07 00 00 	movzbl 0x74a(%rsi),%eax
  6f7033:	88 84 24 50 03 00 00 	mov    %al,0x350(%rsp)
  6f703a:	48 ff 86 d8 06 00 00 	incq   0x6d8(%rsi)
  6f7041:	85 d2                	test   %edx,%edx
  6f7043:	75 07                	jne    6f704c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3c>
  6f7045:	48 ff 86 d0 06 00 00 	incq   0x6d0(%rsi)
  6f704c:	48 c7 84 24 80 08 00 	movq   $0x0,0x880(%rsp)
  6f7053:	00 00 00 00 00 
  6f7058:	48 c7 84 24 90 08 00 	movq   $0x0,0x890(%rsp)
  6f705f:	00 00 00 00 00 
  6f7064:	48 8d 86 d0 05 00 00 	lea    0x5d0(%rsi),%rax
  6f706b:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6f7070:	48 89 34 24          	mov    %rsi,(%rsp)
  6f7074:	48 8b 86 40 06 00 00 	mov    0x640(%rsi),%rax
  6f707b:	48 85 c0             	test   %rax,%rax
  6f707e:	74 09                	je     6f7089 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x79>
  6f7080:	48 8b 90 d8 00 00 00 	mov    0xd8(%rax),%rdx
  6f7087:	eb 02                	jmp    6f708b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b>
  6f7089:	31 d2                	xor    %edx,%edx
  6f708b:	4c 8b 34 24          	mov    (%rsp),%r14
  6f708f:	49 8b 8e a8 06 00 00 	mov    0x6a8(%r14),%rcx
  6f7096:	66 41 0f 6e 86 40 07 	movd   0x740(%r14),%xmm0
  6f709d:	00 00 
  6f709f:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f70a6:	00 
  6f70a7:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  6f70ac:	e8 5f 93 02 00       	call   720410 <gpui::runtime::inspector::description::<route_columns_cost::Page>>
  6f70b1:	4d 8d be 28 06 00 00 	lea    0x628(%r14),%r15
  6f70b8:	49 8d 8e 48 06 00 00 	lea    0x648(%r14),%rcx
  6f70bf:	48 8d 84 24 80 08 00 	lea    0x880(%rsp),%rax
  6f70c6:	00 
  6f70c7:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  6f70ce:	00 
  6f70cf:	4c 89 bc 24 c8 02 00 	mov    %r15,0x2c8(%rsp)
  6f70d6:	00 
  6f70d7:	48 89 8c 24 38 02 00 	mov    %rcx,0x238(%rsp)
  6f70de:	00 
  6f70df:	48 89 8c 24 d0 02 00 	mov    %rcx,0x2d0(%rsp)
  6f70e6:	00 
  6f70e7:	48 c7 84 24 d8 02 00 	movq   $0x8,0x2d8(%rsp)
  6f70ee:	00 08 00 00 00 
  6f70f3:	48 c7 84 24 e0 02 00 	movq   $0x0,0x2e0(%rsp)
  6f70fa:	00 00 00 00 00 
  6f70ff:	4c 8d 05 1a b5 36 00 	lea    0x36b51a(%rip),%r8        # a62620 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x220>
  6f7106:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f710d:	00 
  6f710e:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f7115:	00 
  6f7116:	4c 8d 8c 24 c0 02 00 	lea    0x2c0(%rsp),%r9
  6f711d:	00 
  6f711e:	ba a0 86 01 00       	mov    $0x186a0,%edx
  6f7123:	48 89 d9             	mov    %rbx,%rcx
  6f7126:	e8 85 65 01 00       	call   70d6b0 <<gpui::element::El>::flatten_lists::<<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#1}>>
  6f712b:	48 8b 94 24 10 07 00 	mov    0x710(%rsp),%rdx
  6f7132:	00 
  6f7133:	48 8b 8c 24 18 07 00 	mov    0x718(%rsp),%rcx
  6f713a:	00 
  6f713b:	4c 8b 84 24 20 07 00 	mov    0x720(%rsp),%r8
  6f7142:	00 
  6f7143:	48 8b bc 24 28 07 00 	mov    0x728(%rsp),%rdi
  6f714a:	00 
  6f714b:	48 8b b4 24 30 07 00 	mov    0x730(%rsp),%rsi
  6f7152:	00 
  6f7153:	4c 8b 8c 24 38 07 00 	mov    0x738(%rsp),%r9
  6f715a:	00 
  6f715b:	48 8d 84 24 40 07 00 	lea    0x740(%rsp),%rax
  6f7162:	00 
  6f7163:	48 89 94 24 48 01 00 	mov    %rdx,0x148(%rsp)
  6f716a:	00 
  6f716b:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
  6f716f:	0f 84 dd 01 00 00    	je     6f7352 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x342>
  6f7175:	4c 89 4c 24 70       	mov    %r9,0x70(%rsp)
  6f717a:	4c 89 64 24 50       	mov    %r12,0x50(%rsp)
  6f717f:	4c 89 84 24 f8 01 00 	mov    %r8,0x1f8(%rsp)
  6f7186:	00 
  6f7187:	4c 89 bc 24 00 04 00 	mov    %r15,0x400(%rsp)
  6f718e:	00 
  6f718f:	48 89 bc 24 08 02 00 	mov    %rdi,0x208(%rsp)
  6f7196:	00 
  6f7197:	48 89 b4 24 30 02 00 	mov    %rsi,0x230(%rsp)
  6f719e:	00 
  6f719f:	48 89 8c 24 58 01 00 	mov    %rcx,0x158(%rsp)
  6f71a6:	00 
  6f71a7:	48 8b 48 10          	mov    0x10(%rax),%rcx
  6f71ab:	48 89 8c 24 f0 07 00 	mov    %rcx,0x7f0(%rsp)
  6f71b2:	00 
  6f71b3:	f3 0f 6f 00          	movdqu (%rax),%xmm0
  6f71b7:	66 0f 7f 84 24 e0 07 	movdqa %xmm0,0x7e0(%rsp)
  6f71be:	00 00 
  6f71c0:	48 8b 84 24 58 07 00 	mov    0x758(%rsp),%rax
  6f71c7:	00 
  6f71c8:	48 69 94 24 68 07 00 	imul   $0xa8,0x768(%rsp),%rdx
  6f71cf:	00 a8 00 00 00 
  6f71d4:	48 8b b4 24 60 07 00 	mov    0x760(%rsp),%rsi
  6f71db:	00 
  6f71dc:	48 8b bc 24 80 07 00 	mov    0x780(%rsp),%rdi
  6f71e3:	00 
  6f71e4:	48 89 bc 24 d0 04 00 	mov    %rdi,0x4d0(%rsp)
  6f71eb:	00 
  6f71ec:	f3 0f 6f 8c 24 70 07 	movdqu 0x770(%rsp),%xmm1
  6f71f3:	00 00 
  6f71f5:	66 0f 7f 8c 24 c0 04 	movdqa %xmm1,0x4c0(%rsp)
  6f71fc:	00 00 
  6f71fe:	48 8b bc 24 88 07 00 	mov    0x788(%rsp),%rdi
  6f7205:	00 
  6f7206:	48 89 bc 24 08 04 00 	mov    %rdi,0x408(%rsp)
  6f720d:	00 
  6f720e:	48 8b bc 24 90 07 00 	mov    0x790(%rsp),%rdi
  6f7215:	00 
  6f7216:	48 89 bc 24 18 05 00 	mov    %rdi,0x518(%rsp)
  6f721d:	00 
  6f721e:	4c 8b ac 24 98 07 00 	mov    0x798(%rsp),%r13
  6f7225:	00 
  6f7226:	48 89 8c 24 20 04 00 	mov    %rcx,0x420(%rsp)
  6f722d:	00 
  6f722e:	66 0f 7f 84 24 10 04 	movdqa %xmm0,0x410(%rsp)
  6f7235:	00 00 
  6f7237:	48 c7 84 24 38 05 00 	movq   $0x0,0x538(%rsp)
  6f723e:	00 00 00 00 00 
  6f7243:	48 c7 84 24 40 05 00 	movq   $0x8,0x540(%rsp)
  6f724a:	00 08 00 00 00 
  6f724f:	48 c7 84 24 48 05 00 	movq   $0x0,0x548(%rsp)
  6f7256:	00 00 00 00 00 
  6f725b:	48 01 f2             	add    %rsi,%rdx
  6f725e:	48 89 b4 24 90 00 00 	mov    %rsi,0x90(%rsp)
  6f7265:	00 
  6f7266:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
  6f726d:	00 
  6f726e:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6f7275:	00 
  6f7276:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
  6f727d:	00 
  6f727e:	48 8d 84 24 38 05 00 	lea    0x538(%rsp),%rax
  6f7285:	00 
  6f7286:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  6f728d:	00 
  6f728e:	48 8d bc 24 e0 05 00 	lea    0x5e0(%rsp),%rdi
  6f7295:	00 
  6f7296:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f729d:	00 
  6f729e:	e8 4d 75 02 00       	call   71e7f0 <alloc::vec::in_place_collect::from_iter_in_place::<core::iter::adapters::filter_map::FilterMap<alloc::vec::into_iter::IntoIter<gpui::list::ViewportDraft>, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#2}>, gpui::list::ListDraft>>
  6f72a3:	48 8b 9c 24 e8 05 00 	mov    0x5e8(%rsp),%rbx
  6f72aa:	00 
  6f72ab:	4c 69 b4 24 f0 05 00 	imul   $0xa8,0x5f0(%rsp),%r14
  6f72b2:	00 a8 00 00 00 
  6f72b7:	49 01 de             	add    %rbx,%r14
  6f72ba:	41 b4 01             	mov    $0x1,%r12b
  6f72bd:	48 8d bc 24 50 08 00 	lea    0x850(%rsp),%rdi
  6f72c4:	00 
  6f72c5:	b0 01                	mov    $0x1,%al
  6f72c7:	89 44 24 10          	mov    %eax,0x10(%rsp)
  6f72cb:	40 b5 01             	mov    $0x1,%bpl
  6f72ce:	41 b7 01             	mov    $0x1,%r15b
  6f72d1:	48 89 de             	mov    %rbx,%rsi
  6f72d4:	4c 89 f2             	mov    %r14,%rdx
  6f72d7:	e8 64 1a 01 00       	call   708d40 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::iter::traits::collect::FromIterator<(usize, gpui::list::ListId)>>::from_iter::<core::iter::adapters::map::Map<core::slice::iter::Iter<gpui::list::ListDraft>, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#3}>>>
  6f72dc:	48 89 9c 24 90 00 00 	mov    %rbx,0x90(%rsp)
  6f72e3:	00 
  6f72e4:	4c 89 b4 24 98 00 00 	mov    %r14,0x98(%rsp)
  6f72eb:	00 
  6f72ec:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
  6f72f3:	00 00 00 00 00 
  6f72f8:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  6f72ff:	00 00 00 00 00 
  6f7304:	b3 01                	mov    $0x1,%bl
  6f7306:	48 8d bc 24 68 08 00 	lea    0x868(%rsp),%rdi
  6f730d:	00 
  6f730e:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f7315:	00 
  6f7316:	b0 01                	mov    $0x1,%al
  6f7318:	89 44 24 10          	mov    %eax,0x10(%rsp)
  6f731c:	40 b5 01             	mov    $0x1,%bpl
  6f731f:	41 b7 01             	mov    $0x1,%r15b
  6f7322:	e8 79 1c 01 00       	call   708fa0 <<alloc::collections::btree::map::BTreeMap<usize, (gpui::list::ListId, &gpui::list::RowDraft)> as core::iter::traits::collect::FromIterator<(usize, (gpui::list::ListId, &gpui::list::RowDraft))>>::from_iter::<core::iter::adapters::flatten::FlatMap<core::slice::iter::Iter<gpui::list::ListDraft>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui::list::RowDraft>, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#4}::{closure#0}>, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#4}>>>
  6f7327:	4c 8b b4 24 20 04 00 	mov    0x420(%rsp),%r14
  6f732e:	00 
  6f732f:	49 81 fe a0 86 01 00 	cmp    $0x186a0,%r14
  6f7336:	76 50                	jbe    6f7388 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x378>
  6f7338:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f733d:	48 c7 00 1e 00 00 00 	movq   $0x1e,(%rax)
  6f7344:	b0 01                	mov    $0x1,%al
  6f7346:	89 44 24 10          	mov    %eax,0x10(%rsp)
  6f734a:	40 b5 01             	mov    $0x1,%bpl
  6f734d:	e9 c4 60 00 00       	jmp    6fd416 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6406>
  6f7352:	0f 10 00             	movups (%rax),%xmm0
  6f7355:	0f 29 84 24 e0 07 00 	movaps %xmm0,0x7e0(%rsp)
  6f735c:	00 
  6f735d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f7362:	48 89 08             	mov    %rcx,(%rax)
  6f7365:	4c 89 40 08          	mov    %r8,0x8(%rax)
  6f7369:	48 89 78 10          	mov    %rdi,0x10(%rax)
  6f736d:	48 89 70 18          	mov    %rsi,0x18(%rax)
  6f7371:	4c 89 48 20          	mov    %r9,0x20(%rax)
  6f7375:	66 0f 6f 84 24 e0 07 	movdqa 0x7e0(%rsp),%xmm0
  6f737c:	00 00 
  6f737e:	f3 0f 7f 40 28       	movdqu %xmm0,0x28(%rax)
  6f7383:	e9 d4 62 00 00       	jmp    6fd65c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x664c>
  6f7388:	48 8b 04 24          	mov    (%rsp),%rax
  6f738c:	48 8b 80 10 06 00 00 	mov    0x610(%rax),%rax
  6f7393:	4c 01 f0             	add    %r14,%rax
  6f7396:	0f 82 8d 63 00 00    	jb     6fd729 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6719>
  6f739c:	48 8b 84 24 08 04 00 	mov    0x408(%rsp),%rax
  6f73a3:	00 
  6f73a4:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  6f73ab:	00 
  6f73ac:	48 8b 84 24 18 05 00 	mov    0x518(%rsp),%rax
  6f73b3:	00 
  6f73b4:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
  6f73bb:	00 
  6f73bc:	4c 89 ac 24 d0 02 00 	mov    %r13,0x2d0(%rsp)
  6f73c3:	00 
  6f73c4:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f73cb:	00 
  6f73cc:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
  6f73d3:	00 
  6f73d4:	ff 15 f6 46 39 00    	call   *0x3946f6(%rip)        # a8bad0 <_DYNAMIC+0x678>
  6f73da:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f73e1:	00 
  6f73e2:	0f 10 84 24 98 00 00 	movups 0x98(%rsp),%xmm0
  6f73e9:	00 
  6f73ea:	0f 29 84 24 10 07 00 	movaps %xmm0,0x710(%rsp)
  6f73f1:	00 
  6f73f2:	0f 10 84 24 a8 00 00 	movups 0xa8(%rsp),%xmm0
  6f73f9:	00 
  6f73fa:	0f 29 84 24 20 07 00 	movaps %xmm0,0x720(%rsp)
  6f7401:	00 
  6f7402:	0f 10 84 24 b8 00 00 	movups 0xb8(%rsp),%xmm0
  6f7409:	00 
  6f740a:	0f 29 84 24 30 07 00 	movaps %xmm0,0x730(%rsp)
  6f7411:	00 
  6f7412:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6f7416:	0f 85 fd 00 00 00    	jne    6f7519 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x509>
  6f741c:	48 8b 84 24 20 07 00 	mov    0x720(%rsp),%rax
  6f7423:	00 
  6f7424:	48 89 84 24 a0 04 00 	mov    %rax,0x4a0(%rsp)
  6f742b:	00 
  6f742c:	0f 28 84 24 10 07 00 	movaps 0x710(%rsp),%xmm0
  6f7433:	00 
  6f7434:	0f 29 84 24 90 04 00 	movaps %xmm0,0x490(%rsp)
  6f743b:	00 
  6f743c:	48 8b 84 24 38 07 00 	mov    0x738(%rsp),%rax
  6f7443:	00 
  6f7444:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
  6f744b:	00 
  6f744c:	f3 0f 6f 84 24 28 07 	movdqu 0x728(%rsp),%xmm0
  6f7453:	00 00 
  6f7455:	66 0f 7f 84 24 b0 07 	movdqa %xmm0,0x7b0(%rsp)
  6f745c:	00 00 
  6f745e:	4d 85 f6             	test   %r14,%r14
  6f7461:	0f 84 f1 00 00 00    	je     6f7558 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x548>
  6f7467:	4a 8d 1c f5 00 00 00 	lea    0x0(,%r14,8),%rbx
  6f746e:	00 
  6f746f:	ff 15 23 42 39 00    	call   *0x394223(%rip)        # a8b698 <_DYNAMIC+0x240>
  6f7475:	be 08 00 00 00       	mov    $0x8,%esi
  6f747a:	48 89 df             	mov    %rbx,%rdi
  6f747d:	ff 15 1d 42 39 00    	call   *0x39421d(%rip)        # a8b6a0 <_DYNAMIC+0x248>
  6f7483:	48 85 c0             	test   %rax,%rax
  6f7486:	0f 84 f8 65 00 00    	je     6fda84 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a74>
  6f748c:	4c 89 b4 24 a8 02 00 	mov    %r14,0x2a8(%rsp)
  6f7493:	00 
  6f7494:	48 89 84 24 b0 02 00 	mov    %rax,0x2b0(%rsp)
  6f749b:	00 
  6f749c:	48 c7 84 24 b8 02 00 	movq   $0x0,0x2b8(%rsp)
  6f74a3:	00 00 00 00 00 
  6f74a8:	ff 15 ea 41 39 00    	call   *0x3941ea(%rip)        # a8b698 <_DYNAMIC+0x240>
  6f74ae:	be 08 00 00 00       	mov    $0x8,%esi
  6f74b3:	48 89 df             	mov    %rbx,%rdi
  6f74b6:	ff 15 e4 41 39 00    	call   *0x3941e4(%rip)        # a8b6a0 <_DYNAMIC+0x248>
  6f74bc:	48 85 c0             	test   %rax,%rax
  6f74bf:	0f 84 d2 65 00 00    	je     6fda97 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a87>
  6f74c5:	4c 89 b4 24 40 02 00 	mov    %r14,0x240(%rsp)
  6f74cc:	00 
  6f74cd:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
  6f74d4:	00 
  6f74d5:	48 c7 84 24 50 02 00 	movq   $0x0,0x250(%rsp)
  6f74dc:	00 00 00 00 00 
  6f74e1:	4a 8d 1c b5 00 00 00 	lea    0x0(,%r14,4),%rbx
  6f74e8:	00 
  6f74e9:	ff 15 a9 41 39 00    	call   *0x3941a9(%rip)        # a8b698 <_DYNAMIC+0x240>
  6f74ef:	be 04 00 00 00       	mov    $0x4,%esi
  6f74f4:	48 89 df             	mov    %rbx,%rdi
  6f74f7:	ff 15 a3 41 39 00    	call   *0x3941a3(%rip)        # a8b6a0 <_DYNAMIC+0x248>
  6f74fd:	48 85 c0             	test   %rax,%rax
  6f7500:	0f 85 9f 00 00 00    	jne    6f75a5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x595>
  6f7506:	bf 04 00 00 00       	mov    $0x4,%edi
  6f750b:	48 89 de             	mov    %rbx,%rsi
  6f750e:	ff 15 5c 42 39 00    	call   *0x39425c(%rip)        # a8b770 <_DYNAMIC+0x318>
  6f7514:	e9 4e 68 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6f7519:	66 0f 6f 84 24 10 07 	movdqa 0x710(%rsp),%xmm0
  6f7520:	00 00 
  6f7522:	66 0f 6f 8c 24 20 07 	movdqa 0x720(%rsp),%xmm1
  6f7529:	00 00 
  6f752b:	66 0f 6f 94 24 30 07 	movdqa 0x730(%rsp),%xmm2
  6f7532:	00 00 
  6f7534:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f7539:	f3 0f 7f 51 28       	movdqu %xmm2,0x28(%rcx)
  6f753e:	f3 0f 7f 49 18       	movdqu %xmm1,0x18(%rcx)
  6f7543:	f3 0f 7f 41 08       	movdqu %xmm0,0x8(%rcx)
  6f7548:	48 89 01             	mov    %rax,(%rcx)
  6f754b:	b0 01                	mov    $0x1,%al
  6f754d:	89 44 24 10          	mov    %eax,0x10(%rsp)
  6f7551:	31 ed                	xor    %ebp,%ebp
  6f7553:	e9 be 5e 00 00       	jmp    6fd416 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6406>
  6f7558:	48 c7 84 24 a8 02 00 	movq   $0x0,0x2a8(%rsp)
  6f755f:	00 00 00 00 00 
  6f7564:	48 c7 84 24 b0 02 00 	movq   $0x8,0x2b0(%rsp)
  6f756b:	00 08 00 00 00 
  6f7570:	48 c7 84 24 b8 02 00 	movq   $0x0,0x2b8(%rsp)
  6f7577:	00 00 00 00 00 
  6f757c:	48 c7 84 24 40 02 00 	movq   $0x0,0x240(%rsp)
  6f7583:	00 00 00 00 00 
  6f7588:	48 c7 84 24 48 02 00 	movq   $0x8,0x248(%rsp)
  6f758f:	00 08 00 00 00 
  6f7594:	48 c7 84 24 50 02 00 	movq   $0x0,0x250(%rsp)
  6f759b:	00 00 00 00 00 
  6f75a0:	b8 04 00 00 00       	mov    $0x4,%eax
  6f75a5:	4c 89 b4 24 58 02 00 	mov    %r14,0x258(%rsp)
  6f75ac:	00 
  6f75ad:	48 89 84 24 60 02 00 	mov    %rax,0x260(%rsp)
  6f75b4:	00 
  6f75b5:	48 c7 84 24 68 02 00 	movq   $0x0,0x268(%rsp)
  6f75bc:	00 00 00 00 00 
  6f75c1:	4a 8d 1c f5 08 00 00 	lea    0x8(,%r14,8),%rbx
  6f75c8:	00 
  6f75c9:	ff 15 c9 40 39 00    	call   *0x3940c9(%rip)        # a8b698 <_DYNAMIC+0x240>
  6f75cf:	be 08 00 00 00       	mov    $0x8,%esi
  6f75d4:	48 89 9c 24 f8 03 00 	mov    %rbx,0x3f8(%rsp)
  6f75db:	00 
  6f75dc:	48 89 df             	mov    %rbx,%rdi
  6f75df:	ff 15 f3 44 39 00    	call   *0x3944f3(%rip)        # a8bad8 <_DYNAMIC+0x680>
  6f75e5:	48 89 84 24 a0 02 00 	mov    %rax,0x2a0(%rsp)
  6f75ec:	00 
  6f75ed:	48 85 c0             	test   %rax,%rax
  6f75f0:	0f 84 0c 64 00 00    	je     6fda02 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x69f2>
  6f75f6:	49 8d 46 01          	lea    0x1(%r14),%rax
  6f75fa:	48 89 84 24 e0 03 00 	mov    %rax,0x3e0(%rsp)
  6f7601:	00 
  6f7602:	4c 8b bc 24 18 04 00 	mov    0x418(%rsp),%r15
  6f7609:	00 
  6f760a:	48 c7 84 24 60 01 00 	movq   $0x0,0x160(%rsp)
  6f7611:	00 00 00 00 00 
  6f7616:	48 c7 84 24 70 01 00 	movq   $0x0,0x170(%rsp)
  6f761d:	00 00 00 00 00 
  6f7622:	4d 85 f6             	test   %r14,%r14
  6f7625:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
  6f762a:	0f 84 d2 04 00 00    	je     6f7b02 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xaf2>
  6f7630:	49 69 c6 98 00 00 00 	imul   $0x98,%r14,%rax
  6f7637:	4c 01 f8             	add    %r15,%rax
  6f763a:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6f7641:	00 
  6f7642:	48 8b 04 24          	mov    (%rsp),%rax
  6f7646:	48 05 28 02 00 00    	add    $0x228,%rax
  6f764c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6f7651:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  6f7658:	00 00 
  6f765a:	48 8d 05 37 b2 36 00 	lea    0x36b237(%rip),%rax        # a62898 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x498>
  6f7661:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6f7666:	48 b8 01 00 00 00 00 	movabs $0x8000000000000001,%rax
  6f766d:	00 00 80 
  6f7670:	48 ff c0             	inc    %rax
  6f7673:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  6f7678:	48 c7 84 24 00 02 00 	movq   $0x0,0x200(%rsp)
  6f767f:	00 00 00 00 00 
  6f7684:	41 0f b6 5f 18       	movzbl 0x18(%r15),%ebx
  6f7689:	41 8b 6f 1c          	mov    0x1c(%r15),%ebp
  6f768d:	48 8d 45 01          	lea    0x1(%rbp),%rax
  6f7691:	84 db                	test   %bl,%bl
  6f7693:	b9 00 00 00 00       	mov    $0x0,%ecx
  6f7698:	48 0f 45 c8          	cmovne %rax,%rcx
  6f769c:	48 3b 4c 24 68       	cmp    0x68(%rsp),%rcx
  6f76a1:	0f 87 44 63 00 00    	ja     6fd9eb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x69db>
  6f76a7:	48 8b 84 24 a0 02 00 	mov    0x2a0(%rsp),%rax
  6f76ae:	00 
  6f76af:	48 ff 04 c8          	incq   (%rax,%rcx,8)
  6f76b3:	48 8b 84 24 b0 02 00 	mov    0x2b0(%rsp),%rax
  6f76ba:	00 
  6f76bb:	4c 8b a4 24 b8 02 00 	mov    0x2b8(%rsp),%r12
  6f76c2:	00 
  6f76c3:	84 db                	test   %bl,%bl
  6f76c5:	74 29                	je     6f76f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6e0>
  6f76c7:	49 39 ec             	cmp    %rbp,%r12
  6f76ca:	0f 86 e6 63 00 00    	jbe    6fdab6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6aa6>
  6f76d0:	4c 8b 34 e8          	mov    (%rax,%rbp,8),%r14
  6f76d4:	49 ff c6             	inc    %r14
  6f76d7:	49 81 fe 80 00 00 00 	cmp    $0x80,%r14
  6f76de:	0f 87 90 39 00 00    	ja     6fb074 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4064>
  6f76e4:	4c 3b a4 24 a8 02 00 	cmp    0x2a8(%rsp),%r12
  6f76eb:	00 
  6f76ec:	74 0f                	je     6f76fd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6ed>
  6f76ee:	eb 23                	jmp    6f7713 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x703>
  6f76f0:	45 31 f6             	xor    %r14d,%r14d
  6f76f3:	4c 3b a4 24 a8 02 00 	cmp    0x2a8(%rsp),%r12
  6f76fa:	00 
  6f76fb:	75 16                	jne    6f7713 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x703>
  6f76fd:	48 8d bc 24 a8 02 00 	lea    0x2a8(%rsp),%rdi
  6f7704:	00 
  6f7705:	ff 15 d5 43 39 00    	call   *0x3943d5(%rip)        # a8bae0 <_DYNAMIC+0x688>
  6f770b:	48 8b 84 24 b0 02 00 	mov    0x2b0(%rsp),%rax
  6f7712:	00 
  6f7713:	4e 89 34 e0          	mov    %r14,(%rax,%r12,8)
  6f7717:	49 ff c4             	inc    %r12
  6f771a:	4c 89 a4 24 b8 02 00 	mov    %r12,0x2b8(%rsp)
  6f7721:	00 
  6f7722:	45 31 f6             	xor    %r14d,%r14d
  6f7725:	84 db                	test   %bl,%bl
  6f7727:	74 1d                	je     6f7746 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x736>
  6f7729:	4c 8b a4 24 68 02 00 	mov    0x268(%rsp),%r12
  6f7730:	00 
  6f7731:	49 39 ec             	cmp    %rbp,%r12
  6f7734:	0f 86 70 63 00 00    	jbe    6fdaaa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a9a>
  6f773a:	48 8b 84 24 60 02 00 	mov    0x260(%rsp),%rax
  6f7741:	00 
  6f7742:	44 8b 34 a8          	mov    (%rax,%rbp,4),%r14d
  6f7746:	4d 8b a7 88 00 00 00 	mov    0x88(%r15),%r12
  6f774d:	4d 85 e4             	test   %r12,%r12
  6f7750:	0f 84 a4 00 00 00    	je     6f77fa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ea>
  6f7756:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6f775d:	00 00 00 
  6f7760:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
  6f7765:	0f 84 7a 5f 00 00    	je     6fd6e5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x66d5>
  6f776b:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
  6f7770:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f7777:	00 
  6f7778:	4c 89 e6             	mov    %r12,%rsi
  6f777b:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f7780:	48 8d 0d 59 ae 36 00 	lea    0x36ae59(%rip),%rcx        # a625e0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x1e0>
  6f7787:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  6f778c:	4c 8d 0d 6d ae 36 00 	lea    0x36ae6d(%rip),%r9        # a62600 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x200>
  6f7793:	ff 15 4f 43 39 00    	call   *0x39434f(%rip)        # a8bae8 <_DYNAMIC+0x690>
  6f7799:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f77a0:	00 
  6f77a1:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f77a5:	0f 85 ee 06 00 00    	jne    6f7e99 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xe89>
  6f77ab:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f77b2:	00 
  6f77b3:	4c 89 e6             	mov    %r12,%rsi
  6f77b6:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f77bb:	48 8d 0d 1e ae 36 00 	lea    0x36ae1e(%rip),%rcx        # a625e0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x1e0>
  6f77c2:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  6f77c7:	4c 8d 0d 32 ae 36 00 	lea    0x36ae32(%rip),%r9        # a62600 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x200>
  6f77ce:	ff 15 1c 43 39 00    	call   *0x39431c(%rip)        # a8baf0 <_DYNAMIC+0x698>
  6f77d4:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f77db:	00 
  6f77dc:	44 8b b4 24 98 00 00 	mov    0x98(%rsp),%r14d
  6f77e3:	00 
  6f77e4:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f77e8:	0f 85 cc 06 00 00    	jne    6f7eba <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xeaa>
  6f77ee:	49 89 dc             	mov    %rbx,%r12
  6f77f1:	48 85 db             	test   %rbx,%rbx
  6f77f4:	0f 85 66 ff ff ff    	jne    6f7760 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x750>
  6f77fa:	48 8b 9c 24 68 02 00 	mov    0x268(%rsp),%rbx
  6f7801:	00 
  6f7802:	48 3b 9c 24 58 02 00 	cmp    0x258(%rsp),%rbx
  6f7809:	00 
  6f780a:	75 0e                	jne    6f781a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x80a>
  6f780c:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  6f7813:	00 
  6f7814:	ff 15 de 42 39 00    	call   *0x3942de(%rip)        # a8baf8 <_DYNAMIC+0x6a0>
  6f781a:	48 8b 84 24 60 02 00 	mov    0x260(%rsp),%rax
  6f7821:	00 
  6f7822:	44 89 34 98          	mov    %r14d,(%rax,%rbx,4)
  6f7826:	48 ff c3             	inc    %rbx
  6f7829:	48 89 9c 24 68 02 00 	mov    %rbx,0x268(%rsp)
  6f7830:	00 
  6f7831:	49 83 7f 78 00       	cmpq   $0x0,0x78(%r15)
  6f7836:	74 54                	je     6f788c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x87c>
  6f7838:	49 8d 77 78          	lea    0x78(%r15),%rsi
  6f783c:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f7843:	00 
  6f7844:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f7849:	48 8d 0d 90 ad 36 00 	lea    0x36ad90(%rip),%rcx        # a625e0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x1e0>
  6f7850:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  6f7855:	4c 8d 0d a4 ad 36 00 	lea    0x36ada4(%rip),%r9        # a62600 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x200>
  6f785c:	ff 15 1e 41 39 00    	call   *0x39411e(%rip)        # a8b980 <_DYNAMIC+0x528>
  6f7862:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f7869:	00 
  6f786a:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f786e:	0f 85 11 38 00 00    	jne    6fb085 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4075>
  6f7874:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6f7879:	48 ff c0             	inc    %rax
  6f787c:	4d 8b 27             	mov    (%r15),%r12
  6f787f:	49 83 fc ff          	cmp    $0xffffffffffffffff,%r12
  6f7883:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6f7888:	75 15                	jne    6f789f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x88f>
  6f788a:	eb 67                	jmp    6f78f3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x8e3>
  6f788c:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6f7891:	4d 8b 27             	mov    (%r15),%r12
  6f7894:	49 83 fc ff          	cmp    $0xffffffffffffffff,%r12
  6f7898:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6f789d:	74 54                	je     6f78f3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x8e3>
  6f789f:	4c 3b 64 24 48       	cmp    0x48(%rsp),%r12
  6f78a4:	75 4d                	jne    6f78f3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x8e3>
  6f78a6:	49 8b 4f 08          	mov    0x8(%r15),%rcx
  6f78aa:	4d 8b 47 10          	mov    0x10(%r15),%r8
  6f78ae:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f78b5:	00 
  6f78b6:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  6f78bb:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f78c0:	e8 5b 9a 02 00       	call   721320 <<gpui::source::Sources<route_columns_cost::Page>>::resolve>
  6f78c5:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f78cc:	00 
  6f78cd:	48 8b 9c 24 98 00 00 	mov    0x98(%rsp),%rbx
  6f78d4:	00 
  6f78d5:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f78d9:	0f 85 e1 5d 00 00    	jne    6fd6c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x66b0>
  6f78df:	41 80 bf 90 00 00 00 	cmpb   $0x4,0x90(%r15)
  6f78e6:	04 
  6f78e7:	75 16                	jne    6f78ff <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x8ef>
  6f78e9:	48 85 db             	test   %rbx,%rbx
  6f78ec:	75 1a                	jne    6f7908 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x8f8>
  6f78ee:	e9 ef 58 00 00       	jmp    6fd1e2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61d2>
  6f78f3:	31 db                	xor    %ebx,%ebx
  6f78f5:	41 80 bf 90 00 00 00 	cmpb   $0x4,0x90(%r15)
  6f78fc:	04 
  6f78fd:	74 ea                	je     6f78e9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x8d9>
  6f78ff:	48 85 db             	test   %rbx,%rbx
  6f7902:	0f 84 7d 01 00 00    	je     6f7a85 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xa75>
  6f7908:	49 83 fc ff          	cmp    $0xffffffffffffffff,%r12
  6f790c:	0f 84 39 19 00 00    	je     6f924b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x223b>
  6f7912:	4c 89 ff             	mov    %r15,%rdi
  6f7915:	ff 15 e5 41 39 00    	call   *0x3941e5(%rip)        # a8bb00 <_DYNAMIC+0x6a8>
  6f791b:	48 85 c0             	test   %rax,%rax
  6f791e:	0f 84 27 19 00 00    	je     6f924b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x223b>
  6f7924:	48 8b 8c 24 60 01 00 	mov    0x160(%rsp),%rcx
  6f792b:	00 
  6f792c:	48 85 c9             	test   %rcx,%rcx
  6f792f:	0f 84 7d 00 00 00    	je     6f79b2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x9a2>
  6f7935:	48 8b 94 24 68 01 00 	mov    0x168(%rsp),%rdx
  6f793c:	00 
  6f793d:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6f7944:	89 f7                	mov    %esi,%edi
  6f7946:	c1 e7 03             	shl    $0x3,%edi
  6f7949:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
  6f7950:	48 85 ff             	test   %rdi,%rdi
  6f7953:	74 27                	je     6f797c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x96c>
  6f7955:	4a 3b 9c e9 70 01 00 	cmp    0x170(%rcx,%r13,8),%rbx
  6f795c:	00 
  6f795d:	41 0f 97 c0          	seta   %r8b
  6f7961:	41 80 d8 00          	sbb    $0x0,%r8b
  6f7965:	49 ff c5             	inc    %r13
  6f7968:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  6f796c:	41 80 f8 01          	cmp    $0x1,%r8b
  6f7970:	74 de                	je     6f7950 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x940>
  6f7972:	41 0f b6 f0          	movzbl %r8b,%esi
  6f7976:	85 f6                	test   %esi,%esi
  6f7978:	75 05                	jne    6f797f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x96f>
  6f797a:	eb 17                	jmp    6f7993 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x983>
  6f797c:	49 89 f5             	mov    %rsi,%r13
  6f797f:	48 83 ea 01          	sub    $0x1,%rdx
  6f7983:	0f 82 51 01 00 00    	jb     6f7ada <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xaca>
  6f7989:	4a 8b 8c e9 c8 01 00 	mov    0x1c8(%rcx,%r13,8),%rcx
  6f7990:	00 
  6f7991:	eb aa                	jmp    6f793d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x92d>
  6f7993:	4c 89 ee             	mov    %r13,%rsi
  6f7996:	4c 8d ac 24 60 01 00 	lea    0x160(%rsp),%r13
  6f799d:	00 
  6f799e:	48 89 f7             	mov    %rsi,%rdi
  6f79a1:	48 c1 e7 05          	shl    $0x5,%rdi
  6f79a5:	48 01 cf             	add    %rcx,%rdi
  6f79a8:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
  6f79ad:	e9 94 00 00 00       	jmp    6f7a46 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xa36>
  6f79b2:	31 d2                	xor    %edx,%edx
  6f79b4:	48 89 9c 24 90 00 00 	mov    %rbx,0x90(%rsp)
  6f79bb:	00 
  6f79bc:	48 8d 8c 24 60 01 00 	lea    0x160(%rsp),%rcx
  6f79c3:	00 
  6f79c4:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  6f79cb:	00 
  6f79cc:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
  6f79d3:	00 
  6f79d4:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  6f79d9:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
  6f79e0:	00 
  6f79e1:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
  6f79e8:	00 
  6f79e9:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
  6f79f0:	00 
  6f79f1:	48 c7 84 24 c0 02 00 	movq   $0x0,0x2c0(%rsp)
  6f79f8:	00 00 00 00 00 
  6f79fd:	48 c7 84 24 c8 02 00 	movq   $0x4,0x2c8(%rsp)
  6f7a04:	00 04 00 00 00 
  6f7a09:	48 c7 84 24 d0 02 00 	movq   $0x0,0x2d0(%rsp)
  6f7a10:	00 00 00 00 00 
  6f7a15:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f7a1c:	00 
  6f7a1d:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f7a24:	00 
  6f7a25:	48 8d 94 24 c0 02 00 	lea    0x2c0(%rsp),%rdx
  6f7a2c:	00 
  6f7a2d:	e8 de 9d 01 00       	call   711810 <<alloc::collections::btree::map::entry::VacantEntry<gpui::source::FieldId, gpui::runtime::Fanout>>::insert_entry>
  6f7a32:	48 8b bc 24 20 07 00 	mov    0x720(%rsp),%rdi
  6f7a39:	00 
  6f7a3a:	48 c1 e7 05          	shl    $0x5,%rdi
  6f7a3e:	48 03 bc 24 10 07 00 	add    0x710(%rsp),%rdi
  6f7a45:	00 
  6f7a46:	ff 15 bc 40 39 00    	call   *0x3940bc(%rip)        # a8bb08 <_DYNAMIC+0x6b0>
  6f7a4c:	49 89 c4             	mov    %rax,%r12
  6f7a4f:	48 8b bc 24 00 02 00 	mov    0x200(%rsp),%rdi
  6f7a56:	00 
  6f7a57:	31 f6                	xor    %esi,%esi
  6f7a59:	ff 15 b1 40 39 00    	call   *0x3940b1(%rip)        # a8bb10 <_DYNAMIC+0x6b8>
  6f7a5f:	89 c5                	mov    %eax,%ebp
  6f7a61:	4d 8b 74 24 10       	mov    0x10(%r12),%r14
  6f7a66:	4d 3b 34 24          	cmp    (%r12),%r14
  6f7a6a:	75 08                	jne    6f7a74 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xa64>
  6f7a6c:	4c 89 e7             	mov    %r12,%rdi
  6f7a6f:	e8 4c 94 02 00       	call   720ec0 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  6f7a74:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  6f7a79:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
  6f7a7d:	49 ff c6             	inc    %r14
  6f7a80:	4d 89 74 24 10       	mov    %r14,0x10(%r12)
  6f7a85:	4c 8b b4 24 50 02 00 	mov    0x250(%rsp),%r14
  6f7a8c:	00 
  6f7a8d:	4c 3b b4 24 40 02 00 	cmp    0x240(%rsp),%r14
  6f7a94:	00 
  6f7a95:	75 0d                	jne    6f7aa4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xa94>
  6f7a97:	48 8d bc 24 40 02 00 	lea    0x240(%rsp),%rdi
  6f7a9e:	00 
  6f7a9f:	e8 2c 90 02 00       	call   720ad0 <<alloc::raw_vec::RawVec<core::option::Option<gpui::source::FieldId>>>::grow_one>
  6f7aa4:	49 81 c7 98 00 00 00 	add    $0x98,%r15
  6f7aab:	48 ff 84 24 00 02 00 	incq   0x200(%rsp)
  6f7ab2:	00 
  6f7ab3:	48 8b 84 24 48 02 00 	mov    0x248(%rsp),%rax
  6f7aba:	00 
  6f7abb:	4a 89 1c f0          	mov    %rbx,(%rax,%r14,8)
  6f7abf:	49 ff c6             	inc    %r14
  6f7ac2:	4c 89 b4 24 50 02 00 	mov    %r14,0x250(%rsp)
  6f7ac9:	00 
  6f7aca:	4c 3b bc 24 80 00 00 	cmp    0x80(%rsp),%r15
  6f7ad1:	00 
  6f7ad2:	0f 85 ac fb ff ff    	jne    6f7684 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x674>
  6f7ad8:	eb 31                	jmp    6f7b0b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xafb>
  6f7ada:	48 89 ca             	mov    %rcx,%rdx
  6f7add:	48 8d 8c 24 60 01 00 	lea    0x160(%rsp),%rcx
  6f7ae4:	00 
  6f7ae5:	be 00 00 00 00       	mov    $0x0,%esi
  6f7aea:	bf 00 00 00 00       	mov    $0x0,%edi
  6f7aef:	48 89 7c 24 60       	mov    %rdi,0x60(%rsp)
  6f7af4:	48 85 db             	test   %rbx,%rbx
  6f7af7:	0f 85 b7 fe ff ff    	jne    6f79b4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x9a4>
  6f7afd:	e9 9c fe ff ff       	jmp    6f799e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x98e>
  6f7b02:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  6f7b09:	00 00 
  6f7b0b:	48 8b 8c 24 f8 01 00 	mov    0x1f8(%rsp),%rcx
  6f7b12:	00 
  6f7b13:	48 89 ca             	mov    %rcx,%rdx
  6f7b16:	48 c1 e2 04          	shl    $0x4,%rdx
  6f7b1a:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  6f7b21:	00 
  6f7b22:	48 89 94 24 40 08 00 	mov    %rdx,0x840(%rsp)
  6f7b29:	00 
  6f7b2a:	48 01 d0             	add    %rdx,%rax
  6f7b2d:	48 89 84 24 00 02 00 	mov    %rax,0x200(%rsp)
  6f7b34:	00 
  6f7b35:	48 85 c9             	test   %rcx,%rcx
  6f7b38:	74 57                	je     6f7b91 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xb81>
  6f7b3a:	4c 8b 3d 1f 3d 39 00 	mov    0x393d1f(%rip),%r15        # a8b860 <_DYNAMIC+0x408>
  6f7b41:	48 8d 9c 24 90 00 00 	lea    0x90(%rsp),%rbx
  6f7b48:	00 
  6f7b49:	4c 8b a4 24 58 01 00 	mov    0x158(%rsp),%r12
  6f7b50:	00 
  6f7b51:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f7b58:	0f 1f 84 00 00 00 00 
  6f7b5f:	00 
  6f7b60:	4d 8b 34 24          	mov    (%r12),%r14
  6f7b64:	66 41 0f 6e 44 24 08 	movd   0x8(%r12),%xmm0
  6f7b6b:	66 0f 7e 84 24 90 00 	movd   %xmm0,0x90(%rsp)
  6f7b72:	00 00 
  6f7b74:	48 89 df             	mov    %rbx,%rdi
  6f7b77:	41 ff 57 10          	call   *0x10(%r15)
  6f7b7b:	3c ff                	cmp    $0xff,%al
  6f7b7d:	0f 85 90 08 00 00    	jne    6f8413 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1403>
  6f7b83:	49 83 c4 10          	add    $0x10,%r12
  6f7b87:	4c 3b a4 24 00 02 00 	cmp    0x200(%rsp),%r12
  6f7b8e:	00 
  6f7b8f:	75 cf                	jne    6f7b60 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xb50>
  6f7b91:	48 c7 84 24 e0 07 00 	movq   $0x0,0x7e0(%rsp)
  6f7b98:	00 00 00 00 00 
  6f7b9d:	48 c7 84 24 e8 07 00 	movq   $0x8,0x7e8(%rsp)
  6f7ba4:	00 08 00 00 00 
  6f7ba9:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6f7bad:	f3 0f 7f 84 24 f0 07 	movdqu %xmm0,0x7f0(%rsp)
  6f7bb4:	00 00 
  6f7bb6:	48 c7 84 24 00 08 00 	movq   $0x4,0x800(%rsp)
  6f7bbd:	00 04 00 00 00 
  6f7bc2:	48 c7 84 24 38 08 00 	movq   $0x0,0x838(%rsp)
  6f7bc9:	00 00 00 00 00 
  6f7bce:	f3 0f 7f 84 24 08 08 	movdqu %xmm0,0x808(%rsp)
  6f7bd5:	00 00 
  6f7bd7:	48 c7 84 24 18 08 00 	movq   $0x4,0x818(%rsp)
  6f7bde:	00 04 00 00 00 
  6f7be3:	f3 0f 7f 84 24 20 08 	movdqu %xmm0,0x820(%rsp)
  6f7bea:	00 00 
  6f7bec:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  6f7bf1:	48 85 c0             	test   %rax,%rax
  6f7bf4:	0f 84 ef 02 00 00    	je     6f7ee9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xed9>
  6f7bfa:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  6f7bfe:	4c 8b ac 24 30 02 00 	mov    0x230(%rsp),%r13
  6f7c05:	00 
  6f7c06:	48 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%rax
  6f7c0d:	00 
  6f7c0e:	4c 01 e8             	add    %r13,%rax
  6f7c11:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6f7c18:	00 
  6f7c19:	48 8b 04 24          	mov    (%rsp),%rax
  6f7c1d:	48 05 28 02 00 00    	add    $0x228,%rax
  6f7c23:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  6f7c28:	48 8b 84 24 18 04 00 	mov    0x418(%rsp),%rax
  6f7c2f:	00 
  6f7c30:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6f7c35:	48 8b 84 24 20 04 00 	mov    0x420(%rsp),%rax
  6f7c3c:	00 
  6f7c3d:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f7c42:	eb 21                	jmp    6f7c65 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xc55>
  6f7c44:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6f7c48:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
  6f7c4c:	49 ff c6             	inc    %r14
  6f7c4f:	4c 89 73 10          	mov    %r14,0x10(%rbx)
  6f7c53:	49 83 c5 18          	add    $0x18,%r13
  6f7c57:	4c 3b ac 24 80 00 00 	cmp    0x80(%rsp),%r13
  6f7c5e:	00 
  6f7c5f:	0f 84 84 02 00 00    	je     6f7ee9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xed9>
  6f7c65:	41 0f b7 6d 14       	movzwl 0x14(%r13),%ebp
  6f7c6a:	66 85 ed             	test   %bp,%bp
  6f7c6d:	0f 84 76 02 00 00    	je     6f7ee9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xed9>
  6f7c73:	49 8b 5d 00          	mov    0x0(%r13),%rbx
  6f7c77:	4d 8b 75 08          	mov    0x8(%r13),%r14
  6f7c7b:	41 8b 45 10          	mov    0x10(%r13),%eax
  6f7c7f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6f7c84:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f7c8b:	00 
  6f7c8c:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
  6f7c91:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f7c96:	48 89 d9             	mov    %rbx,%rcx
  6f7c99:	4d 89 f0             	mov    %r14,%r8
  6f7c9c:	e8 7f 96 02 00       	call   721320 <<gpui::source::Sources<route_columns_cost::Page>>::resolve>
  6f7ca1:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f7ca8:	00 
  6f7ca9:	4c 8b bc 24 98 00 00 	mov    0x98(%rsp),%r15
  6f7cb0:	00 
  6f7cb1:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f7cb5:	0f 85 b0 13 00 00    	jne    6f906b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x205b>
  6f7cbb:	4d 85 ff             	test   %r15,%r15
  6f7cbe:	74 93                	je     6f7c53 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xc43>
  6f7cc0:	89 e8                	mov    %ebp,%eax
  6f7cc2:	25 fe ff 00 00       	and    $0xfffe,%eax
  6f7cc7:	66 83 f8 06          	cmp    $0x6,%ax
  6f7ccb:	75 5d                	jne    6f7d2a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd1a>
  6f7ccd:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  6f7cd2:	48 39 7c 24 60       	cmp    %rdi,0x60(%rsp)
  6f7cd7:	0f 86 f1 5d 00 00    	jbe    6fdace <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6abe>
  6f7cdd:	48 69 c7 98 00 00 00 	imul   $0x98,%rdi,%rax
  6f7ce4:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  6f7ce9:	f3 0f 6f 44 01 3c    	movdqu 0x3c(%rcx,%rax,1),%xmm0
  6f7cef:	66 0f 7f 84 24 b0 08 	movdqa %xmm0,0x8b0(%rsp)
  6f7cf6:	00 00 
  6f7cf8:	66 83 fd 06          	cmp    $0x6,%bp
  6f7cfc:	74 13                	je     6f7d11 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd01>
  6f7cfe:	48 03 44 24 40       	add    0x40(%rsp),%rax
  6f7d03:	f3 0f 6f 40 4c       	movdqu 0x4c(%rax),%xmm0
  6f7d08:	66 0f 7f 84 24 b0 08 	movdqa %xmm0,0x8b0(%rsp)
  6f7d0f:	00 00 
  6f7d11:	48 8d bc 24 e0 07 00 	lea    0x7e0(%rsp),%rdi
  6f7d18:	00 
  6f7d19:	4c 89 fe             	mov    %r15,%rsi
  6f7d1c:	48 8d 94 24 b0 08 00 	lea    0x8b0(%rsp),%rdx
  6f7d23:	00 
  6f7d24:	ff 15 ee 3d 39 00    	call   *0x393dee(%rip)        # a8bb18 <_DYNAMIC+0x6c0>
  6f7d2a:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
  6f7d31:	00 
  6f7d32:	48 85 ff             	test   %rdi,%rdi
  6f7d35:	0f 84 84 00 00 00    	je     6f7dbf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xdaf>
  6f7d3b:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  6f7d42:	00 
  6f7d43:	0f b7 8f c2 01 00 00 	movzwl 0x1c2(%rdi),%ecx
  6f7d4a:	89 ce                	mov    %ecx,%esi
  6f7d4c:	c1 e6 05             	shl    $0x5,%esi
  6f7d4f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
  6f7d56:	31 d2                	xor    %edx,%edx
  6f7d58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6f7d5f:	00 
  6f7d60:	49 89 f0             	mov    %rsi,%r8
  6f7d63:	49 01 d0             	add    %rdx,%r8
  6f7d66:	74 27                	je     6f7d8f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd7f>
  6f7d68:	4e 3b bc e7 70 01 00 	cmp    0x170(%rdi,%r12,8),%r15
  6f7d6f:	00 
  6f7d70:	41 0f 97 c0          	seta   %r8b
  6f7d74:	41 80 d8 00          	sbb    $0x0,%r8b
  6f7d78:	48 83 c2 e0          	add    $0xffffffffffffffe0,%rdx
  6f7d7c:	49 ff c4             	inc    %r12
  6f7d7f:	41 80 f8 01          	cmp    $0x1,%r8b
  6f7d83:	74 db                	je     6f7d60 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd50>
  6f7d85:	41 0f b6 c8          	movzbl %r8b,%ecx
  6f7d89:	85 c9                	test   %ecx,%ecx
  6f7d8b:	75 05                	jne    6f7d92 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd82>
  6f7d8d:	eb 17                	jmp    6f7da6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd96>
  6f7d8f:	49 89 cc             	mov    %rcx,%r12
  6f7d92:	48 83 e8 01          	sub    $0x1,%rax
  6f7d96:	0f 82 f0 00 00 00    	jb     6f7e8c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xe7c>
  6f7d9c:	4a 8b bc e7 c8 01 00 	mov    0x1c8(%rdi,%r12,8),%rdi
  6f7da3:	00 
  6f7da4:	eb 9d                	jmp    6f7d43 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd33>
  6f7da6:	48 29 d7             	sub    %rdx,%rdi
  6f7da9:	48 83 c7 e0          	add    $0xffffffffffffffe0,%rdi
  6f7dad:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
  6f7db4:	00 
  6f7db5:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  6f7dba:	e9 9b 00 00 00       	jmp    6f7e5a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xe4a>
  6f7dbf:	31 ff                	xor    %edi,%edi
  6f7dc1:	4c 89 bc 24 90 00 00 	mov    %r15,0x90(%rsp)
  6f7dc8:	00 
  6f7dc9:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
  6f7dd0:	00 
  6f7dd1:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
  6f7dd8:	00 
  6f7dd9:	48 89 bc 24 a0 00 00 	mov    %rdi,0xa0(%rsp)
  6f7de0:	00 
  6f7de1:	4c 89 a4 24 a8 00 00 	mov    %r12,0xa8(%rsp)
  6f7de8:	00 
  6f7de9:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  6f7dee:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  6f7df5:	00 
  6f7df6:	48 89 df             	mov    %rbx,%rdi
  6f7df9:	41 ff 56 30          	call   *0x30(%r14)
  6f7dfd:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
  6f7e04:	00 
  6f7e05:	48 c7 84 24 c0 02 00 	movq   $0x0,0x2c0(%rsp)
  6f7e0c:	00 00 00 00 00 
  6f7e11:	48 c7 84 24 c8 02 00 	movq   $0x4,0x2c8(%rsp)
  6f7e18:	00 04 00 00 00 
  6f7e1d:	48 c7 84 24 d0 02 00 	movq   $0x0,0x2d0(%rsp)
  6f7e24:	00 00 00 00 00 
  6f7e29:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f7e30:	00 
  6f7e31:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f7e38:	00 
  6f7e39:	48 8d 94 24 c0 02 00 	lea    0x2c0(%rsp),%rdx
  6f7e40:	00 
  6f7e41:	e8 ca 99 01 00       	call   711810 <<alloc::collections::btree::map::entry::VacantEntry<gpui::source::FieldId, gpui::runtime::Fanout>>::insert_entry>
  6f7e46:	48 8b bc 24 20 07 00 	mov    0x720(%rsp),%rdi
  6f7e4d:	00 
  6f7e4e:	48 c1 e7 05          	shl    $0x5,%rdi
  6f7e52:	48 03 bc 24 10 07 00 	add    0x710(%rsp),%rdi
  6f7e59:	00 
  6f7e5a:	ff 15 a8 3c 39 00    	call   *0x393ca8(%rip)        # a8bb08 <_DYNAMIC+0x6b0>
  6f7e60:	48 89 c3             	mov    %rax,%rbx
  6f7e63:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  6f7e68:	89 ee                	mov    %ebp,%esi
  6f7e6a:	ff 15 b0 3c 39 00    	call   *0x393cb0(%rip)        # a8bb20 <_DYNAMIC+0x6c8>
  6f7e70:	89 c5                	mov    %eax,%ebp
  6f7e72:	4c 8b 73 10          	mov    0x10(%rbx),%r14
  6f7e76:	4c 3b 33             	cmp    (%rbx),%r14
  6f7e79:	0f 85 c5 fd ff ff    	jne    6f7c44 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xc34>
  6f7e7f:	48 89 df             	mov    %rbx,%rdi
  6f7e82:	e8 39 90 02 00       	call   720ec0 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  6f7e87:	e9 b8 fd ff ff       	jmp    6f7c44 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xc34>
  6f7e8c:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
  6f7e91:	45 31 e4             	xor    %r12d,%r12d
  6f7e94:	e9 28 ff ff ff       	jmp    6f7dc1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xdb1>
  6f7e99:	0f 10 84 24 98 00 00 	movups 0x98(%rsp),%xmm0
  6f7ea0:	00 
  6f7ea1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f7ea6:	48 c7 01 20 00 00 00 	movq   $0x20,(%rcx)
  6f7ead:	48 89 41 08          	mov    %rax,0x8(%rcx)
  6f7eb1:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
  6f7eb5:	e9 40 53 00 00       	jmp    6fd1fa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61ea>
  6f7eba:	8b 8c 24 a4 00 00 00 	mov    0xa4(%rsp),%ecx
  6f7ec1:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6f7ec6:	89 4a 1c             	mov    %ecx,0x1c(%rdx)
  6f7ec9:	48 8b 8c 24 9c 00 00 	mov    0x9c(%rsp),%rcx
  6f7ed0:	00 
  6f7ed1:	48 89 4a 14          	mov    %rcx,0x14(%rdx)
  6f7ed5:	48 c7 02 20 00 00 00 	movq   $0x20,(%rdx)
  6f7edc:	48 89 42 08          	mov    %rax,0x8(%rdx)
  6f7ee0:	44 89 72 10          	mov    %r14d,0x10(%rdx)
  6f7ee4:	e9 11 53 00 00       	jmp    6fd1fa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61ea>
  6f7ee9:	48 8b 84 24 08 02 00 	mov    0x208(%rsp),%rax
  6f7ef0:	00 
  6f7ef1:	48 85 c0             	test   %rax,%rax
  6f7ef4:	74 1f                	je     6f7f15 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xf05>
  6f7ef6:	48 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%rax
  6f7efd:	00 
  6f7efe:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6f7f02:	ba 08 00 00 00       	mov    $0x8,%edx
  6f7f07:	48 8b bc 24 30 02 00 	mov    0x230(%rsp),%rdi
  6f7f0e:	00 
  6f7f0f:	ff 15 93 37 39 00    	call   *0x393793(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f7f15:	4c 8b bc 24 d0 04 00 	mov    0x4d0(%rsp),%r15
  6f7f1c:	00 
  6f7f1d:	4d 85 ff             	test   %r15,%r15
  6f7f20:	0f 84 1f 05 00 00    	je     6f8445 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1435>
  6f7f26:	4c 89 fb             	mov    %r15,%rbx
  6f7f29:	48 c1 e3 04          	shl    $0x4,%rbx
  6f7f2d:	ff 15 65 37 39 00    	call   *0x393765(%rip)        # a8b698 <_DYNAMIC+0x240>
  6f7f33:	be 08 00 00 00       	mov    $0x8,%esi
  6f7f38:	48 89 df             	mov    %rbx,%rdi
  6f7f3b:	ff 15 5f 37 39 00    	call   *0x39375f(%rip)        # a8b6a0 <_DYNAMIC+0x248>
  6f7f41:	48 85 c0             	test   %rax,%rax
  6f7f44:	0f 84 91 5c 00 00    	je     6fdbdb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6bcb>
  6f7f4a:	4c 89 bc 24 70 02 00 	mov    %r15,0x270(%rsp)
  6f7f51:	00 
  6f7f52:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
  6f7f59:	00 
  6f7f5a:	48 c7 84 24 80 02 00 	movq   $0x0,0x280(%rsp)
  6f7f61:	00 00 00 00 00 
  6f7f66:	4c 8b b4 24 c8 04 00 	mov    0x4c8(%rsp),%r14
  6f7f6d:	00 
  6f7f6e:	49 6b c7 38          	imul   $0x38,%r15,%rax
  6f7f72:	4c 01 f0             	add    %r14,%rax
  6f7f75:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6f7f7c:	00 
  6f7f7d:	48 8b 04 24          	mov    (%rsp),%rax
  6f7f81:	48 05 28 02 00 00    	add    $0x228,%rax
  6f7f87:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  6f7f8c:	48 b8 01 00 00 00 00 	movabs $0x8000000000000001,%rax
  6f7f93:	00 00 80 
  6f7f96:	48 ff c0             	inc    %rax
  6f7f99:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  6f7f9e:	eb 47                	jmp    6f7fe7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xfd7>
  6f7fa0:	48 8d bc 24 70 02 00 	lea    0x270(%rsp),%rdi
  6f7fa7:	00 
  6f7fa8:	e8 43 8a 02 00       	call   7209f0 <<alloc::raw_vec::RawVec<[core::option::Option<gpui::source::FieldId>; 2]>>::grow_one>
  6f7fad:	49 83 c6 38          	add    $0x38,%r14
  6f7fb1:	48 8b 84 24 78 02 00 	mov    0x278(%rsp),%rax
  6f7fb8:	00 
  6f7fb9:	48 89 d9             	mov    %rbx,%rcx
  6f7fbc:	48 c1 e1 04          	shl    $0x4,%rcx
  6f7fc0:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  6f7fc5:	48 89 14 08          	mov    %rdx,(%rax,%rcx,1)
  6f7fc9:	4c 89 64 08 08       	mov    %r12,0x8(%rax,%rcx,1)
  6f7fce:	48 ff c3             	inc    %rbx
  6f7fd1:	48 89 9c 24 80 02 00 	mov    %rbx,0x280(%rsp)
  6f7fd8:	00 
  6f7fd9:	4c 3b b4 24 80 00 00 	cmp    0x80(%rsp),%r14
  6f7fe0:	00 
  6f7fe1:	0f 84 82 04 00 00    	je     6f8469 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1459>
  6f7fe7:	49 8b 06             	mov    (%r14),%rax
  6f7fea:	4d 8b 7e 18          	mov    0x18(%r14),%r15
  6f7fee:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f7ff2:	0f 84 e8 00 00 00    	je     6f80e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x10d0>
  6f7ff8:	48 3b 44 24 70       	cmp    0x70(%rsp),%rax
  6f7ffd:	0f 85 dd 00 00 00    	jne    6f80e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x10d0>
  6f8003:	49 8b 4e 08          	mov    0x8(%r14),%rcx
  6f8007:	4d 8b 46 10          	mov    0x10(%r14),%r8
  6f800b:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f8012:	00 
  6f8013:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  6f8018:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f801d:	e8 fe 92 02 00       	call   721320 <<gpui::source::Sources<route_columns_cost::Page>>::resolve>
  6f8022:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f8029:	00 
  6f802a:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f802e:	0f 85 f4 11 00 00    	jne    6f9228 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2218>
  6f8034:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  6f803b:	00 
  6f803c:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  6f8041:	48 85 c9             	test   %rcx,%rcx
  6f8044:	0f 84 96 00 00 00    	je     6f80e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x10d0>
  6f804a:	4c 89 f7             	mov    %r14,%rdi
  6f804d:	ff 15 ad 3a 39 00    	call   *0x393aad(%rip)        # a8bb00 <_DYNAMIC+0x6a8>
  6f8053:	48 85 c0             	test   %rax,%rax
  6f8056:	0f 84 de 3c 00 00    	je     6fbd3a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d2a>
  6f805c:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
  6f8063:	00 
  6f8064:	48 85 ff             	test   %rdi,%rdi
  6f8067:	0f 84 9b 01 00 00    	je     6f8208 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x11f8>
  6f806d:	48 8b 8c 24 68 01 00 	mov    0x168(%rsp),%rcx
  6f8074:	00 
  6f8075:	0f b7 97 c2 01 00 00 	movzwl 0x1c2(%rdi),%edx
  6f807c:	41 89 d0             	mov    %edx,%r8d
  6f807f:	41 c1 e0 05          	shl    $0x5,%r8d
  6f8083:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
  6f808a:	31 f6                	xor    %esi,%esi
  6f808c:	0f 1f 40 00          	nopl   0x0(%rax)
  6f8090:	4d 89 c1             	mov    %r8,%r9
  6f8093:	49 01 f1             	add    %rsi,%r9
  6f8096:	74 2f                	je     6f80c7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x10b7>
  6f8098:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
  6f809d:	4e 3b 8c ef 70 01 00 	cmp    0x170(%rdi,%r13,8),%r9
  6f80a4:	00 
  6f80a5:	41 0f 97 c1          	seta   %r9b
  6f80a9:	41 80 d9 00          	sbb    $0x0,%r9b
  6f80ad:	48 83 c6 e0          	add    $0xffffffffffffffe0,%rsi
  6f80b1:	49 ff c5             	inc    %r13
  6f80b4:	41 80 f9 01          	cmp    $0x1,%r9b
  6f80b8:	74 d6                	je     6f8090 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1080>
  6f80ba:	41 0f b6 d1          	movzbl %r9b,%edx
  6f80be:	85 d2                	test   %edx,%edx
  6f80c0:	75 08                	jne    6f80ca <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x10ba>
  6f80c2:	e9 0f 01 00 00       	jmp    6f81d6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x11c6>
  6f80c7:	49 89 d5             	mov    %rdx,%r13
  6f80ca:	48 83 e9 01          	sub    $0x1,%rcx
  6f80ce:	0f 82 23 03 00 00    	jb     6f83f7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x13e7>
  6f80d4:	4a 8b bc ef c8 01 00 	mov    0x1c8(%rdi,%r13,8),%rdi
  6f80db:	00 
  6f80dc:	eb 97                	jmp    6f8075 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1065>
  6f80de:	66 90                	xchg   %ax,%ax
  6f80e0:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  6f80e7:	00 00 
  6f80e9:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
  6f80ed:	0f 84 fd 01 00 00    	je     6f82f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x12e0>
  6f80f3:	49 8d 5e 18          	lea    0x18(%r14),%rbx
  6f80f7:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  6f80fc:	48 39 03             	cmp    %rax,(%rbx)
  6f80ff:	0f 85 eb 01 00 00    	jne    6f82f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x12e0>
  6f8105:	49 8b 4e 20          	mov    0x20(%r14),%rcx
  6f8109:	4d 8b 46 28          	mov    0x28(%r14),%r8
  6f810d:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f8114:	00 
  6f8115:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  6f811a:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f811f:	e8 fc 91 02 00       	call   721320 <<gpui::source::Sources<route_columns_cost::Page>>::resolve>
  6f8124:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f812b:	00 
  6f812c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f8130:	0f 85 f2 10 00 00    	jne    6f9228 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2218>
  6f8136:	4c 8b a4 24 98 00 00 	mov    0x98(%rsp),%r12
  6f813d:	00 
  6f813e:	4d 85 e4             	test   %r12,%r12
  6f8141:	0f 84 a9 01 00 00    	je     6f82f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x12e0>
  6f8147:	48 89 df             	mov    %rbx,%rdi
  6f814a:	ff 15 b0 39 39 00    	call   *0x3939b0(%rip)        # a8bb00 <_DYNAMIC+0x6a8>
  6f8150:	48 85 c0             	test   %rax,%rax
  6f8153:	0f 84 e6 3b 00 00    	je     6fbd3f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d2f>
  6f8159:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
  6f8160:	00 
  6f8161:	48 85 ff             	test   %rdi,%rdi
  6f8164:	0f 84 a4 01 00 00    	je     6f830e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x12fe>
  6f816a:	48 8b 8c 24 68 01 00 	mov    0x168(%rsp),%rcx
  6f8171:	00 
  6f8172:	0f b7 97 c2 01 00 00 	movzwl 0x1c2(%rdi),%edx
  6f8179:	41 89 d0             	mov    %edx,%r8d
  6f817c:	41 c1 e0 05          	shl    $0x5,%r8d
  6f8180:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
  6f8187:	31 f6                	xor    %esi,%esi
  6f8189:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6f8190:	4d 89 c1             	mov    %r8,%r9
  6f8193:	49 01 f1             	add    %rsi,%r9
  6f8196:	74 27                	je     6f81bf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x11af>
  6f8198:	4e 3b a4 ef 70 01 00 	cmp    0x170(%rdi,%r13,8),%r12
  6f819f:	00 
  6f81a0:	41 0f 97 c1          	seta   %r9b
  6f81a4:	41 80 d9 00          	sbb    $0x0,%r9b
  6f81a8:	48 83 c6 e0          	add    $0xffffffffffffffe0,%rsi
  6f81ac:	49 ff c5             	inc    %r13
  6f81af:	41 80 f9 01          	cmp    $0x1,%r9b
  6f81b3:	74 db                	je     6f8190 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1180>
  6f81b5:	41 0f b6 d1          	movzbl %r9b,%edx
  6f81b9:	85 d2                	test   %edx,%edx
  6f81bb:	75 05                	jne    6f81c2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x11b2>
  6f81bd:	eb 30                	jmp    6f81ef <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x11df>
  6f81bf:	49 89 d5             	mov    %rdx,%r13
  6f81c2:	48 83 e9 01          	sub    $0x1,%rcx
  6f81c6:	0f 82 39 02 00 00    	jb     6f8405 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x13f5>
  6f81cc:	4a 8b bc ef c8 01 00 	mov    0x1c8(%rdi,%r13,8),%rdi
  6f81d3:	00 
  6f81d4:	eb 9c                	jmp    6f8172 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1162>
  6f81d6:	48 29 f7             	sub    %rsi,%rdi
  6f81d9:	48 83 c7 e0          	add    $0xffffffffffffffe0,%rdi
  6f81dd:	4c 89 6c 24 40       	mov    %r13,0x40(%rsp)
  6f81e2:	4c 8d ac 24 60 01 00 	lea    0x160(%rsp),%r13
  6f81e9:	00 
  6f81ea:	e9 b2 00 00 00       	jmp    6f82a1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1291>
  6f81ef:	48 29 f7             	sub    %rsi,%rdi
  6f81f2:	48 83 c7 e0          	add    $0xffffffffffffffe0,%rdi
  6f81f6:	4c 89 6c 24 40       	mov    %r13,0x40(%rsp)
  6f81fb:	4c 8d ac 24 60 01 00 	lea    0x160(%rsp),%r13
  6f8202:	00 
  6f8203:	e9 9a 01 00 00       	jmp    6f83a2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1392>
  6f8208:	31 ff                	xor    %edi,%edi
  6f820a:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6f820f:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  6f8216:	00 
  6f8217:	48 8d 8c 24 60 01 00 	lea    0x160(%rsp),%rcx
  6f821e:	00 
  6f821f:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  6f8226:	00 
  6f8227:	48 89 bc 24 a0 00 00 	mov    %rdi,0xa0(%rsp)
  6f822e:	00 
  6f822f:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  6f8234:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
  6f823b:	00 
  6f823c:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
  6f8243:	00 
  6f8244:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
  6f824b:	00 
  6f824c:	48 c7 84 24 c0 02 00 	movq   $0x0,0x2c0(%rsp)
  6f8253:	00 00 00 00 00 
  6f8258:	48 c7 84 24 c8 02 00 	movq   $0x4,0x2c8(%rsp)
  6f825f:	00 04 00 00 00 
  6f8264:	48 c7 84 24 d0 02 00 	movq   $0x0,0x2d0(%rsp)
  6f826b:	00 00 00 00 00 
  6f8270:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f8277:	00 
  6f8278:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f827f:	00 
  6f8280:	48 8d 94 24 c0 02 00 	lea    0x2c0(%rsp),%rdx
  6f8287:	00 
  6f8288:	e8 83 95 01 00       	call   711810 <<alloc::collections::btree::map::entry::VacantEntry<gpui::source::FieldId, gpui::runtime::Fanout>>::insert_entry>
  6f828d:	48 8b bc 24 20 07 00 	mov    0x720(%rsp),%rdi
  6f8294:	00 
  6f8295:	48 c1 e7 05          	shl    $0x5,%rdi
  6f8299:	48 03 bc 24 10 07 00 	add    0x710(%rsp),%rdi
  6f82a0:	00 
  6f82a1:	ff 15 61 38 39 00    	call   *0x393861(%rip)        # a8bb08 <_DYNAMIC+0x6b0>
  6f82a7:	48 89 c3             	mov    %rax,%rbx
  6f82aa:	41 8b 7e 30          	mov    0x30(%r14),%edi
  6f82ae:	be 01 00 00 00       	mov    $0x1,%esi
  6f82b3:	ff 15 57 38 39 00    	call   *0x393857(%rip)        # a8bb10 <_DYNAMIC+0x6b8>
  6f82b9:	89 c5                	mov    %eax,%ebp
  6f82bb:	4c 8b 63 10          	mov    0x10(%rbx),%r12
  6f82bf:	4c 3b 23             	cmp    (%rbx),%r12
  6f82c2:	75 08                	jne    6f82cc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x12bc>
  6f82c4:	48 89 df             	mov    %rbx,%rdi
  6f82c7:	e8 f4 8b 02 00       	call   720ec0 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  6f82cc:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6f82d0:	42 89 2c a0          	mov    %ebp,(%rax,%r12,4)
  6f82d4:	49 ff c4             	inc    %r12
  6f82d7:	4c 89 63 10          	mov    %r12,0x10(%rbx)
  6f82db:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
  6f82df:	0f 85 0e fe ff ff    	jne    6f80f3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x10e3>
  6f82e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6f82ec:	00 00 00 00 
  6f82f0:	45 31 e4             	xor    %r12d,%r12d
  6f82f3:	48 8b 9c 24 80 02 00 	mov    0x280(%rsp),%rbx
  6f82fa:	00 
  6f82fb:	48 3b 9c 24 70 02 00 	cmp    0x270(%rsp),%rbx
  6f8302:	00 
  6f8303:	0f 85 a4 fc ff ff    	jne    6f7fad <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xf9d>
  6f8309:	e9 92 fc ff ff       	jmp    6f7fa0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xf90>
  6f830e:	31 ff                	xor    %edi,%edi
  6f8310:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
  6f8317:	00 
  6f8318:	48 8d 8c 24 60 01 00 	lea    0x160(%rsp),%rcx
  6f831f:	00 
  6f8320:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  6f8327:	00 
  6f8328:	48 89 bc 24 a0 00 00 	mov    %rdi,0xa0(%rsp)
  6f832f:	00 
  6f8330:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  6f8335:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
  6f833c:	00 
  6f833d:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
  6f8344:	00 
  6f8345:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
  6f834c:	00 
  6f834d:	48 c7 84 24 c0 02 00 	movq   $0x0,0x2c0(%rsp)
  6f8354:	00 00 00 00 00 
  6f8359:	48 c7 84 24 c8 02 00 	movq   $0x4,0x2c8(%rsp)
  6f8360:	00 04 00 00 00 
  6f8365:	48 c7 84 24 d0 02 00 	movq   $0x0,0x2d0(%rsp)
  6f836c:	00 00 00 00 00 
  6f8371:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f8378:	00 
  6f8379:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f8380:	00 
  6f8381:	48 8d 94 24 c0 02 00 	lea    0x2c0(%rsp),%rdx
  6f8388:	00 
  6f8389:	e8 82 94 01 00       	call   711810 <<alloc::collections::btree::map::entry::VacantEntry<gpui::source::FieldId, gpui::runtime::Fanout>>::insert_entry>
  6f838e:	48 8b bc 24 20 07 00 	mov    0x720(%rsp),%rdi
  6f8395:	00 
  6f8396:	48 c1 e7 05          	shl    $0x5,%rdi
  6f839a:	48 03 bc 24 10 07 00 	add    0x710(%rsp),%rdi
  6f83a1:	00 
  6f83a2:	ff 15 60 37 39 00    	call   *0x393760(%rip)        # a8bb08 <_DYNAMIC+0x6b0>
  6f83a8:	48 89 c3             	mov    %rax,%rbx
  6f83ab:	41 8b 7e 30          	mov    0x30(%r14),%edi
  6f83af:	be 02 00 00 00       	mov    $0x2,%esi
  6f83b4:	ff 15 56 37 39 00    	call   *0x393756(%rip)        # a8bb10 <_DYNAMIC+0x6b8>
  6f83ba:	89 c5                	mov    %eax,%ebp
  6f83bc:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
  6f83c0:	4c 3b 3b             	cmp    (%rbx),%r15
  6f83c3:	75 08                	jne    6f83cd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x13bd>
  6f83c5:	48 89 df             	mov    %rbx,%rdi
  6f83c8:	e8 f3 8a 02 00       	call   720ec0 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  6f83cd:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6f83d1:	42 89 2c b8          	mov    %ebp,(%rax,%r15,4)
  6f83d5:	49 ff c7             	inc    %r15
  6f83d8:	4c 89 7b 10          	mov    %r15,0x10(%rbx)
  6f83dc:	48 8b 9c 24 80 02 00 	mov    0x280(%rsp),%rbx
  6f83e3:	00 
  6f83e4:	48 3b 9c 24 70 02 00 	cmp    0x270(%rsp),%rbx
  6f83eb:	00 
  6f83ec:	0f 85 bb fb ff ff    	jne    6f7fad <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xf9d>
  6f83f2:	e9 a9 fb ff ff       	jmp    6f7fa0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xf90>
  6f83f7:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  6f83fe:	00 00 
  6f8400:	e9 05 fe ff ff       	jmp    6f820a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x11fa>
  6f8405:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  6f840c:	00 00 
  6f840e:	e9 fd fe ff ff       	jmp    6f8310 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1300>
  6f8413:	41 0f b7 4f 30       	movzwl 0x30(%r15),%ecx
  6f8418:	25 ff ff ff 00       	and    $0xffffff,%eax
  6f841d:	89 c2                	mov    %eax,%edx
  6f841f:	c1 ea 10             	shr    $0x10,%edx
  6f8422:	48 c1 e0 10          	shl    $0x10,%rax
  6f8426:	48 09 c8             	or     %rcx,%rax
  6f8429:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f842e:	48 c7 01 25 00 00 00 	movq   $0x25,(%rcx)
  6f8435:	4c 89 71 08          	mov    %r14,0x8(%rcx)
  6f8439:	66 89 51 14          	mov    %dx,0x14(%rcx)
  6f843d:	89 41 10             	mov    %eax,0x10(%rcx)
  6f8440:	e9 b5 4d 00 00       	jmp    6fd1fa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61ea>
  6f8445:	48 c7 84 24 70 02 00 	movq   $0x0,0x270(%rsp)
  6f844c:	00 00 00 00 00 
  6f8451:	48 c7 84 24 78 02 00 	movq   $0x8,0x278(%rsp)
  6f8458:	00 08 00 00 00 
  6f845d:	48 c7 84 24 80 02 00 	movq   $0x0,0x280(%rsp)
  6f8464:	00 00 00 00 00 
  6f8469:	48 c7 84 24 28 04 00 	movq   $0x0,0x428(%rsp)
  6f8470:	00 00 00 00 00 
  6f8475:	48 c7 84 24 38 04 00 	movq   $0x0,0x438(%rsp)
  6f847c:	00 00 00 00 00 
  6f8481:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
  6f8488:	00 
  6f8489:	4c 8b b4 24 70 01 00 	mov    0x170(%rsp),%r14
  6f8490:	00 
  6f8491:	48 85 c0             	test   %rax,%rax
  6f8494:	0f 95 c1             	setne  %cl
  6f8497:	4d 85 f6             	test   %r14,%r14
  6f849a:	0f 95 c2             	setne  %dl
  6f849d:	20 ca                	and    %cl,%dl
  6f849f:	80 fa 01             	cmp    $0x1,%dl
  6f84a2:	0f 85 4f 02 00 00    	jne    6f86f7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x16e7>
  6f84a8:	48 8b ac 24 68 01 00 	mov    0x168(%rsp),%rbp
  6f84af:	00 
  6f84b0:	45 31 ed             	xor    %r13d,%r13d
  6f84b3:	4c 8b 3d 4e 36 39 00 	mov    0x39364e(%rip),%r15        # a8bb08 <_DYNAMIC+0x6b0>
  6f84ba:	4c 8d 64 24 5f       	lea    0x5f(%rsp),%r12
  6f84bf:	48 8d 9c 24 90 00 00 	lea    0x90(%rsp),%rbx
  6f84c6:	00 
  6f84c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f84ce:	00 00 
  6f84d0:	4d 85 ed             	test   %r13,%r13
  6f84d3:	74 1c                	je     6f84f1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x14e1>
  6f84d5:	41 0f b7 8d c2 01 00 	movzwl 0x1c2(%r13),%ecx
  6f84dc:	00 
  6f84dd:	48 39 cd             	cmp    %rcx,%rbp
  6f84e0:	0f 83 ba 00 00 00    	jae    6f85a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1590>
  6f84e6:	4c 89 ef             	mov    %r13,%rdi
  6f84e9:	48 89 e9             	mov    %rbp,%rcx
  6f84ec:	e9 d6 00 00 00       	jmp    6f85c7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x15b7>
  6f84f1:	48 85 ed             	test   %rbp,%rbp
  6f84f4:	74 37                	je     6f852d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x151d>
  6f84f6:	48 89 e9             	mov    %rbp,%rcx
  6f84f9:	49 89 c5             	mov    %rax,%r13
  6f84fc:	48 83 e1 07          	and    $0x7,%rcx
  6f8500:	74 30                	je     6f8532 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1522>
  6f8502:	31 d2                	xor    %edx,%edx
  6f8504:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f850b:	00 00 00 00 00 
  6f8510:	4d 8b ad c8 01 00 00 	mov    0x1c8(%r13),%r13
  6f8517:	48 ff c2             	inc    %rdx
  6f851a:	48 39 d1             	cmp    %rdx,%rcx
  6f851d:	75 f1                	jne    6f8510 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1500>
  6f851f:	48 89 e8             	mov    %rbp,%rax
  6f8522:	48 29 d0             	sub    %rdx,%rax
  6f8525:	48 83 fd 08          	cmp    $0x8,%rbp
  6f8529:	73 15                	jae    6f8540 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1530>
  6f852b:	eb 51                	jmp    6f857e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x156e>
  6f852d:	49 89 c5             	mov    %rax,%r13
  6f8530:	eb 4c                	jmp    6f857e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x156e>
  6f8532:	48 89 e8             	mov    %rbp,%rax
  6f8535:	48 83 fd 08          	cmp    $0x8,%rbp
  6f8539:	72 43                	jb     6f857e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x156e>
  6f853b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6f8540:	49 8b 8d c8 01 00 00 	mov    0x1c8(%r13),%rcx
  6f8547:	48 8b 89 c8 01 00 00 	mov    0x1c8(%rcx),%rcx
  6f854e:	48 8b 89 c8 01 00 00 	mov    0x1c8(%rcx),%rcx
  6f8555:	48 8b 89 c8 01 00 00 	mov    0x1c8(%rcx),%rcx
  6f855c:	48 8b 89 c8 01 00 00 	mov    0x1c8(%rcx),%rcx
  6f8563:	48 8b 89 c8 01 00 00 	mov    0x1c8(%rcx),%rcx
  6f856a:	48 8b 89 c8 01 00 00 	mov    0x1c8(%rcx),%rcx
  6f8571:	4c 8b a9 c8 01 00 00 	mov    0x1c8(%rcx),%r13
  6f8578:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  6f857c:	75 c2                	jne    6f8540 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1530>
  6f857e:	31 c0                	xor    %eax,%eax
  6f8580:	31 ed                	xor    %ebp,%ebp
  6f8582:	41 0f b7 8d c2 01 00 	movzwl 0x1c2(%r13),%ecx
  6f8589:	00 
  6f858a:	48 39 cd             	cmp    %rcx,%rbp
  6f858d:	0f 82 53 ff ff ff    	jb     6f84e6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x14d6>
  6f8593:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f859a:	84 00 00 00 00 00 
  6f85a0:	49 8b bd 60 01 00 00 	mov    0x160(%r13),%rdi
  6f85a7:	48 85 ff             	test   %rdi,%rdi
  6f85aa:	0f 84 ea 52 00 00    	je     6fd89a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x688a>
  6f85b0:	48 ff c0             	inc    %rax
  6f85b3:	41 0f b7 8d c0 01 00 	movzwl 0x1c0(%r13),%ecx
  6f85ba:	00 
  6f85bb:	49 89 fd             	mov    %rdi,%r13
  6f85be:	66 3b 8f c2 01 00 00 	cmp    0x1c2(%rdi),%cx
  6f85c5:	73 d9                	jae    6f85a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1590>
  6f85c7:	48 85 c0             	test   %rax,%rax
  6f85ca:	0f 84 85 00 00 00    	je     6f8655 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1645>
  6f85d0:	48 8d 14 cf          	lea    (%rdi,%rcx,8),%rdx
  6f85d4:	48 81 c2 d0 01 00 00 	add    $0x1d0,%rdx
  6f85db:	48 89 c6             	mov    %rax,%rsi
  6f85de:	48 83 e6 07          	and    $0x7,%rsi
  6f85e2:	0f 84 a4 00 00 00    	je     6f868c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x167c>
  6f85e8:	45 31 c0             	xor    %r8d,%r8d
  6f85eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6f85f0:	4c 8b 2a             	mov    (%rdx),%r13
  6f85f3:	49 8d 95 c8 01 00 00 	lea    0x1c8(%r13),%rdx
  6f85fa:	49 ff c0             	inc    %r8
  6f85fd:	4c 39 c6             	cmp    %r8,%rsi
  6f8600:	75 ee                	jne    6f85f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x15e0>
  6f8602:	48 89 c6             	mov    %rax,%rsi
  6f8605:	4c 29 c6             	sub    %r8,%rsi
  6f8608:	48 83 f8 08          	cmp    $0x8,%rax
  6f860c:	72 43                	jb     6f8651 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1641>
  6f860e:	66 90                	xchg   %ax,%ax
  6f8610:	48 8b 02             	mov    (%rdx),%rax
  6f8613:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f861a:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f8621:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f8628:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f862f:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f8636:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f863d:	4c 8b a8 c8 01 00 00 	mov    0x1c8(%rax),%r13
  6f8644:	49 8d 95 c8 01 00 00 	lea    0x1c8(%r13),%rdx
  6f864b:	48 83 c6 f8          	add    $0xfffffffffffffff8,%rsi
  6f864f:	75 bf                	jne    6f8610 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1600>
  6f8651:	31 ed                	xor    %ebp,%ebp
  6f8653:	eb 07                	jmp    6f865c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x164c>
  6f8655:	48 8d 69 01          	lea    0x1(%rcx),%rbp
  6f8659:	49 89 fd             	mov    %rdi,%r13
  6f865c:	48 c1 e1 05          	shl    $0x5,%rcx
  6f8660:	48 01 cf             	add    %rcx,%rdi
  6f8663:	41 ff d7             	call   *%r15
  6f8666:	48 8b 78 08          	mov    0x8(%rax),%rdi
  6f866a:	48 8b 70 10          	mov    0x10(%rax),%rsi
  6f866e:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
  6f8675:	00 
  6f8676:	48 83 fe 02          	cmp    $0x2,%rsi
  6f867a:	73 1e                	jae    6f869a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x168a>
  6f867c:	b8 00 00 00 00       	mov    $0x0,%eax
  6f8681:	49 ff ce             	dec    %r14
  6f8684:	0f 85 46 fe ff ff    	jne    6f84d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x14c0>
  6f868a:	eb 6b                	jmp    6f86f7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x16e7>
  6f868c:	48 89 c6             	mov    %rax,%rsi
  6f868f:	48 83 f8 08          	cmp    $0x8,%rax
  6f8693:	72 bc                	jb     6f8651 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1641>
  6f8695:	e9 76 ff ff ff       	jmp    6f8610 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1600>
  6f869a:	48 83 fe 15          	cmp    $0x15,%rsi
  6f869e:	73 4d                	jae    6f86ed <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x16dd>
  6f86a0:	48 8d 04 b7          	lea    (%rdi,%rsi,4),%rax
  6f86a4:	48 8d 4f 04          	lea    0x4(%rdi),%rcx
  6f86a8:	ba 04 00 00 00       	mov    $0x4,%edx
  6f86ad:	eb 13                	jmp    6f86c2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x16b2>
  6f86af:	49 89 f8             	mov    %rdi,%r8
  6f86b2:	41 89 30             	mov    %esi,(%r8)
  6f86b5:	48 83 c1 04          	add    $0x4,%rcx
  6f86b9:	48 83 c2 04          	add    $0x4,%rdx
  6f86bd:	48 39 c1             	cmp    %rax,%rcx
  6f86c0:	74 ba                	je     6f867c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x166c>
  6f86c2:	44 8b 49 fc          	mov    -0x4(%rcx),%r9d
  6f86c6:	8b 31                	mov    (%rcx),%esi
  6f86c8:	44 39 ce             	cmp    %r9d,%esi
  6f86cb:	73 e8                	jae    6f86b5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x16a5>
  6f86cd:	49 89 d0             	mov    %rdx,%r8
  6f86d0:	46 89 0c 07          	mov    %r9d,(%rdi,%r8,1)
  6f86d4:	49 83 f8 04          	cmp    $0x4,%r8
  6f86d8:	74 d5                	je     6f86af <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x169f>
  6f86da:	46 8b 4c 07 f8       	mov    -0x8(%rdi,%r8,1),%r9d
  6f86df:	49 83 c0 fc          	add    $0xfffffffffffffffc,%r8
  6f86e3:	44 39 ce             	cmp    %r9d,%esi
  6f86e6:	72 e8                	jb     6f86d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x16c0>
  6f86e8:	49 01 f8             	add    %rdi,%r8
  6f86eb:	eb c5                	jmp    6f86b2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x16a2>
  6f86ed:	48 89 da             	mov    %rbx,%rdx
  6f86f0:	e8 5b 9e 01 00       	call   712550 <core::slice::sort::unstable::ipnsort::<gpui::runtime::metadata::Destination, <[gpui::runtime::metadata::Destination]>::sort_unstable_by_key<u32, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#14}>::{closure#0}>>
  6f86f5:	eb 85                	jmp    6f867c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x166c>
  6f86f7:	48 8d bc 24 e0 07 00 	lea    0x7e0(%rsp),%rdi
  6f86fe:	00 
  6f86ff:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
  6f8706:	00 
  6f8707:	ff 15 1b 34 39 00    	call   *0x39341b(%rip)        # a8bb28 <_DYNAMIC+0x6d0>
  6f870d:	48 8b 84 24 28 08 00 	mov    0x828(%rsp),%rax
  6f8714:	00 
  6f8715:	48 8b 9c 24 38 08 00 	mov    0x838(%rsp),%rbx
  6f871c:	00 
  6f871d:	48 85 c0             	test   %rax,%rax
  6f8720:	0f 95 c1             	setne  %cl
  6f8723:	48 85 db             	test   %rbx,%rbx
  6f8726:	0f 95 c2             	setne  %dl
  6f8729:	20 ca                	and    %cl,%dl
  6f872b:	80 fa 01             	cmp    $0x1,%dl
  6f872e:	0f 85 a5 02 00 00    	jne    6f89d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x19c9>
  6f8734:	4c 8b a4 24 30 08 00 	mov    0x830(%rsp),%r12
  6f873b:	00 
  6f873c:	45 31 ff             	xor    %r15d,%r15d
  6f873f:	eb 2d                	jmp    6f876e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x175e>
  6f8741:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f8748:	0f 1f 84 00 00 00 00 
  6f874f:	00 
  6f8750:	4b c7 44 35 e0 ff ff 	movq   $0xffffffffffffffff,-0x20(%r13,%r14,1)
  6f8757:	ff ff 
  6f8759:	43 89 6c 35 e8       	mov    %ebp,-0x18(%r13,%r14,1)
  6f875e:	b1 01                	mov    $0x1,%cl
  6f8760:	b8 00 00 00 00       	mov    $0x0,%eax
  6f8765:	48 85 db             	test   %rbx,%rbx
  6f8768:	0f 84 6b 02 00 00    	je     6f89d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x19c9>
  6f876e:	f6 c1 01             	test   $0x1,%cl
  6f8771:	0f 84 1c 52 00 00    	je     6fd993 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6983>
  6f8777:	4d 85 ff             	test   %r15,%r15
  6f877a:	74 1c                	je     6f8798 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1788>
  6f877c:	41 0f b7 8f 8e 00 00 	movzwl 0x8e(%r15),%ecx
  6f8783:	00 
  6f8784:	49 39 cc             	cmp    %rcx,%r12
  6f8787:	0f 83 b3 00 00 00    	jae    6f8840 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1830>
  6f878d:	4c 89 f9             	mov    %r15,%rcx
  6f8790:	4c 89 e2             	mov    %r12,%rdx
  6f8793:	e9 cb 00 00 00       	jmp    6f8863 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1853>
  6f8798:	4d 85 e4             	test   %r12,%r12
  6f879b:	74 30                	je     6f87cd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x17bd>
  6f879d:	4c 89 e1             	mov    %r12,%rcx
  6f87a0:	49 89 c7             	mov    %rax,%r15
  6f87a3:	48 83 e1 07          	and    $0x7,%rcx
  6f87a7:	74 29                	je     6f87d2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x17c2>
  6f87a9:	31 d2                	xor    %edx,%edx
  6f87ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6f87b0:	4d 8b bf 90 00 00 00 	mov    0x90(%r15),%r15
  6f87b7:	48 ff c2             	inc    %rdx
  6f87ba:	48 39 d1             	cmp    %rdx,%rcx
  6f87bd:	75 f1                	jne    6f87b0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x17a0>
  6f87bf:	4c 89 e0             	mov    %r12,%rax
  6f87c2:	48 29 d0             	sub    %rdx,%rax
  6f87c5:	49 83 fc 08          	cmp    $0x8,%r12
  6f87c9:	73 15                	jae    6f87e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x17d0>
  6f87cb:	eb 51                	jmp    6f881e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x180e>
  6f87cd:	49 89 c7             	mov    %rax,%r15
  6f87d0:	eb 4c                	jmp    6f881e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x180e>
  6f87d2:	4c 89 e0             	mov    %r12,%rax
  6f87d5:	49 83 fc 08          	cmp    $0x8,%r12
  6f87d9:	72 43                	jb     6f881e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x180e>
  6f87db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6f87e0:	49 8b 8f 90 00 00 00 	mov    0x90(%r15),%rcx
  6f87e7:	48 8b 89 90 00 00 00 	mov    0x90(%rcx),%rcx
  6f87ee:	48 8b 89 90 00 00 00 	mov    0x90(%rcx),%rcx
  6f87f5:	48 8b 89 90 00 00 00 	mov    0x90(%rcx),%rcx
  6f87fc:	48 8b 89 90 00 00 00 	mov    0x90(%rcx),%rcx
  6f8803:	48 8b 89 90 00 00 00 	mov    0x90(%rcx),%rcx
  6f880a:	48 8b 89 90 00 00 00 	mov    0x90(%rcx),%rcx
  6f8811:	4c 8b b9 90 00 00 00 	mov    0x90(%rcx),%r15
  6f8818:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  6f881c:	75 c2                	jne    6f87e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x17d0>
  6f881e:	31 c0                	xor    %eax,%eax
  6f8820:	45 31 e4             	xor    %r12d,%r12d
  6f8823:	41 0f b7 8f 8e 00 00 	movzwl 0x8e(%r15),%ecx
  6f882a:	00 
  6f882b:	49 39 cc             	cmp    %rcx,%r12
  6f882e:	0f 82 59 ff ff ff    	jb     6f878d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x177d>
  6f8834:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f883b:	00 00 00 00 00 
  6f8840:	49 8b 0f             	mov    (%r15),%rcx
  6f8843:	48 85 c9             	test   %rcx,%rcx
  6f8846:	0f 84 60 50 00 00    	je     6fd8ac <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x689c>
  6f884c:	48 ff c0             	inc    %rax
  6f884f:	41 0f b7 97 8c 00 00 	movzwl 0x8c(%r15),%edx
  6f8856:	00 
  6f8857:	49 89 cf             	mov    %rcx,%r15
  6f885a:	66 3b 91 8e 00 00 00 	cmp    0x8e(%rcx),%dx
  6f8861:	73 dd                	jae    6f8840 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1830>
  6f8863:	48 85 c0             	test   %rax,%rax
  6f8866:	0f 84 9a 00 00 00    	je     6f8906 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x18f6>
  6f886c:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
  6f8870:	48 81 c6 98 00 00 00 	add    $0x98,%rsi
  6f8877:	48 89 c7             	mov    %rax,%rdi
  6f887a:	48 83 e7 07          	and    $0x7,%rdi
  6f887e:	0f 84 43 01 00 00    	je     6f89c7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x19b7>
  6f8884:	45 31 c0             	xor    %r8d,%r8d
  6f8887:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f888e:	00 00 
  6f8890:	4c 8b 3e             	mov    (%rsi),%r15
  6f8893:	49 8d b7 90 00 00 00 	lea    0x90(%r15),%rsi
  6f889a:	49 ff c0             	inc    %r8
  6f889d:	4c 39 c7             	cmp    %r8,%rdi
  6f88a0:	75 ee                	jne    6f8890 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1880>
  6f88a2:	48 89 c7             	mov    %rax,%rdi
  6f88a5:	4c 29 c7             	sub    %r8,%rdi
  6f88a8:	48 83 f8 08          	cmp    $0x8,%rax
  6f88ac:	72 43                	jb     6f88f1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x18e1>
  6f88ae:	66 90                	xchg   %ax,%ax
  6f88b0:	48 8b 06             	mov    (%rsi),%rax
  6f88b3:	48 8b 80 90 00 00 00 	mov    0x90(%rax),%rax
  6f88ba:	48 8b 80 90 00 00 00 	mov    0x90(%rax),%rax
  6f88c1:	48 8b 80 90 00 00 00 	mov    0x90(%rax),%rax
  6f88c8:	48 8b 80 90 00 00 00 	mov    0x90(%rax),%rax
  6f88cf:	48 8b 80 90 00 00 00 	mov    0x90(%rax),%rax
  6f88d6:	48 8b 80 90 00 00 00 	mov    0x90(%rax),%rax
  6f88dd:	4c 8b b8 90 00 00 00 	mov    0x90(%rax),%r15
  6f88e4:	49 8d b7 90 00 00 00 	lea    0x90(%r15),%rsi
  6f88eb:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  6f88ef:	75 bf                	jne    6f88b0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x18a0>
  6f88f1:	45 31 e4             	xor    %r12d,%r12d
  6f88f4:	4c 8b ac 24 60 01 00 	mov    0x160(%rsp),%r13
  6f88fb:	00 
  6f88fc:	4d 85 ed             	test   %r13,%r13
  6f88ff:	75 1d                	jne    6f891e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x190e>
  6f8901:	e9 6f 50 00 00       	jmp    6fd975 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6965>
  6f8906:	4c 8d 62 01          	lea    0x1(%rdx),%r12
  6f890a:	49 89 cf             	mov    %rcx,%r15
  6f890d:	4c 8b ac 24 60 01 00 	mov    0x160(%rsp),%r13
  6f8914:	00 
  6f8915:	4d 85 ed             	test   %r13,%r13
  6f8918:	0f 84 57 50 00 00    	je     6fd975 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6965>
  6f891e:	48 ff cb             	dec    %rbx
  6f8921:	48 8b 44 d1 08       	mov    0x8(%rcx,%rdx,8),%rax
  6f8926:	8b 6c 91 60          	mov    0x60(%rcx,%rdx,4),%ebp
  6f892a:	48 8b 8c 24 68 01 00 	mov    0x168(%rsp),%rcx
  6f8931:	00 
  6f8932:	41 0f b7 b5 c2 01 00 	movzwl 0x1c2(%r13),%esi
  6f8939:	00 
  6f893a:	89 f7                	mov    %esi,%edi
  6f893c:	c1 e7 05             	shl    $0x5,%edi
  6f893f:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6f8946:	45 31 f6             	xor    %r14d,%r14d
  6f8949:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6f8950:	4c 39 f7             	cmp    %r14,%rdi
  6f8953:	74 2b                	je     6f8980 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1970>
  6f8955:	49 3b 84 d5 70 01 00 	cmp    0x170(%r13,%rdx,8),%rax
  6f895c:	00 
  6f895d:	41 0f 97 c0          	seta   %r8b
  6f8961:	41 80 d8 00          	sbb    $0x0,%r8b
  6f8965:	49 83 c6 20          	add    $0x20,%r14
  6f8969:	48 ff c2             	inc    %rdx
  6f896c:	41 80 f8 01          	cmp    $0x1,%r8b
  6f8970:	74 de                	je     6f8950 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1940>
  6f8972:	41 0f b6 f0          	movzbl %r8b,%esi
  6f8976:	85 f6                	test   %esi,%esi
  6f8978:	75 09                	jne    6f8983 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1973>
  6f897a:	eb 24                	jmp    6f89a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1990>
  6f897c:	0f 1f 40 00          	nopl   0x0(%rax)
  6f8980:	48 89 f2             	mov    %rsi,%rdx
  6f8983:	48 83 e9 01          	sub    $0x1,%rcx
  6f8987:	0f 82 e8 4f 00 00    	jb     6fd975 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6965>
  6f898d:	4d 8b ac d5 c8 01 00 	mov    0x1c8(%r13,%rdx,8),%r13
  6f8994:	00 
  6f8995:	eb 9b                	jmp    6f8932 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1922>
  6f8997:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f899e:	00 00 
  6f89a0:	4b 8b 74 35 e0       	mov    -0x20(%r13,%r14,1),%rsi
  6f89a5:	48 85 f6             	test   %rsi,%rsi
  6f89a8:	0f 8e a2 fd ff ff    	jle    6f8750 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1740>
  6f89ae:	4b 8b 7c 35 e8       	mov    -0x18(%r13,%r14,1),%rdi
  6f89b3:	48 c1 e6 02          	shl    $0x2,%rsi
  6f89b7:	ba 04 00 00 00       	mov    $0x4,%edx
  6f89bc:	ff 15 e6 2c 39 00    	call   *0x392ce6(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f89c2:	e9 89 fd ff ff       	jmp    6f8750 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1740>
  6f89c7:	48 89 c7             	mov    %rax,%rdi
  6f89ca:	48 83 f8 08          	cmp    $0x8,%rax
  6f89ce:	0f 82 1d ff ff ff    	jb     6f88f1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x18e1>
  6f89d4:	e9 d7 fe ff ff       	jmp    6f88b0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x18a0>
  6f89d9:	48 8b 1c 24          	mov    (%rsp),%rbx
  6f89dd:	48 8b 83 20 02 00 00 	mov    0x220(%rbx),%rax
  6f89e4:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
  6f89eb:	00 
  6f89ec:	f3 0f 6f 83 00 02 00 	movdqu 0x200(%rbx),%xmm0
  6f89f3:	00 
  6f89f4:	f3 0f 6f 8b 10 02 00 	movdqu 0x210(%rbx),%xmm1
  6f89fb:	00 
  6f89fc:	66 0f 7f 8c 24 b0 06 	movdqa %xmm1,0x6b0(%rsp)
  6f8a03:	00 00 
  6f8a05:	66 0f 7f 84 24 a0 06 	movdqa %xmm0,0x6a0(%rsp)
  6f8a0c:	00 00 
  6f8a0e:	48 c7 83 00 02 00 00 	movq   $0x0,0x200(%rbx)
  6f8a15:	00 00 00 00 
  6f8a19:	48 8b b3 98 02 00 00 	mov    0x298(%rbx),%rsi
  6f8a20:	48 8b 93 a0 02 00 00 	mov    0x2a0(%rbx),%rdx
  6f8a27:	48 8d bc 24 c8 07 00 	lea    0x7c8(%rsp),%rdi
  6f8a2e:	00 
  6f8a2f:	ff 15 fb 30 39 00    	call   *0x3930fb(%rip)        # a8bb30 <_DYNAMIC+0x6d8>
  6f8a35:	48 8b 83 b0 05 00 00 	mov    0x5b0(%rbx),%rax
  6f8a3c:	48 89 84 24 f0 04 00 	mov    %rax,0x4f0(%rsp)
  6f8a43:	00 
  6f8a44:	48 8b 83 b8 05 00 00 	mov    0x5b8(%rbx),%rax
  6f8a4b:	48 89 84 24 d0 03 00 	mov    %rax,0x3d0(%rsp)
  6f8a52:	00 
  6f8a53:	48 c7 83 b0 05 00 00 	movq   $0x8,0x5b0(%rbx)
  6f8a5a:	08 00 00 00 
  6f8a5e:	48 c7 83 b8 05 00 00 	movq   $0x0,0x5b8(%rbx)
  6f8a65:	00 00 00 00 
  6f8a69:	48 8b 83 90 02 00 00 	mov    0x290(%rbx),%rax
  6f8a70:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
  6f8a77:	00 
  6f8a78:	48 8b 83 98 02 00 00 	mov    0x298(%rbx),%rax
  6f8a7f:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  6f8a84:	4c 8b b3 a0 02 00 00 	mov    0x2a0(%rbx),%r14
  6f8a8b:	48 c7 83 90 02 00 00 	movq   $0x0,0x290(%rbx)
  6f8a92:	00 00 00 00 
  6f8a96:	48 c7 83 98 02 00 00 	movq   $0x8,0x298(%rbx)
  6f8a9d:	08 00 00 00 
  6f8aa1:	48 c7 83 a0 02 00 00 	movq   $0x0,0x2a0(%rbx)
  6f8aa8:	00 00 00 00 
  6f8aac:	48 c7 84 24 70 06 00 	movq   $0x0,0x670(%rsp)
  6f8ab3:	00 00 00 00 00 
  6f8ab8:	48 c7 84 24 80 06 00 	movq   $0x0,0x680(%rsp)
  6f8abf:	00 00 00 00 00 
  6f8ac4:	48 c7 84 24 88 06 00 	movq   $0x0,0x688(%rsp)
  6f8acb:	00 00 00 00 00 
  6f8ad0:	48 c7 84 24 98 06 00 	movq   $0x0,0x698(%rsp)
  6f8ad7:	00 00 00 00 00 
  6f8adc:	48 8b 83 48 06 00 00 	mov    0x648(%rbx),%rax
  6f8ae3:	48 8b 8b 50 06 00 00 	mov    0x650(%rbx),%rcx
  6f8aea:	31 d2                	xor    %edx,%edx
  6f8aec:	48 89 c6             	mov    %rax,%rsi
  6f8aef:	48 85 c0             	test   %rax,%rax
  6f8af2:	40 0f 95 c7          	setne  %dil
  6f8af6:	74 0b                	je     6f8b03 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1af3>
  6f8af8:	48 8b 34 24          	mov    (%rsp),%rsi
  6f8afc:	48 8b b6 58 06 00 00 	mov    0x658(%rsi),%rsi
  6f8b03:	40 88 fa             	mov    %dil,%dl
  6f8b06:	48 89 94 24 90 00 00 	mov    %rdx,0x90(%rsp)
  6f8b0d:	00 
  6f8b0e:	48 c7 84 24 98 00 00 	movq   $0x0,0x98(%rsp)
  6f8b15:	00 00 00 00 00 
  6f8b1a:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6f8b21:	00 
  6f8b22:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
  6f8b29:	00 
  6f8b2a:	48 89 94 24 b0 00 00 	mov    %rdx,0xb0(%rsp)
  6f8b31:	00 
  6f8b32:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  6f8b39:	00 00 00 00 00 
  6f8b3e:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  6f8b45:	00 
  6f8b46:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
  6f8b4d:	00 
  6f8b4e:	48 89 b4 24 d0 00 00 	mov    %rsi,0xd0(%rsp)
  6f8b55:	00 
  6f8b56:	41 b4 01             	mov    $0x1,%r12b
  6f8b59:	48 8d bc 24 98 08 00 	lea    0x898(%rsp),%rdi
  6f8b60:	00 
  6f8b61:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f8b68:	00 
  6f8b69:	41 b5 01             	mov    $0x1,%r13b
  6f8b6c:	e8 ef 05 01 00       	call   709160 <<alloc::collections::btree::map::BTreeMap<u64, gpui::list::ListId> as core::iter::traits::collect::FromIterator<(u64, gpui::list::ListId)>>::from_iter::<core::iter::adapters::filter_map::FilterMap<alloc::collections::btree::map::Iter<gpui::runtime::scroll::ViewportKey, gpui::runtime::scroll::ViewportState>, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#15}>>>
  6f8b71:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  6f8b76:	4d 85 f6             	test   %r14,%r14
  6f8b79:	4c 89 b4 24 80 00 00 	mov    %r14,0x80(%rsp)
  6f8b80:	00 
  6f8b81:	0f 84 39 05 00 00    	je     6f90c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x20b0>
  6f8b87:	4b 8d 04 76          	lea    (%r14,%r14,2),%rax
  6f8b8b:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
  6f8b90:	48 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%rax
  6f8b97:	00 
  6f8b98:	48 01 e8             	add    %rbp,%rax
  6f8b9b:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6f8ba0:	4c 8b a4 24 98 08 00 	mov    0x898(%rsp),%r12
  6f8ba7:	00 
  6f8ba8:	48 8b 84 24 a0 08 00 	mov    0x8a0(%rsp),%rax
  6f8baf:	00 
  6f8bb0:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6f8bb5:	31 db                	xor    %ebx,%ebx
  6f8bb7:	eb 29                	jmp    6f8be2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1bd2>
  6f8bb9:	48 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%rcx
  6f8bc0:	00 
  6f8bc1:	48 89 9c c8 68 01 00 	mov    %rbx,0x168(%rax,%rcx,8)
  6f8bc8:	00 
  6f8bc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6f8bd0:	48 83 c5 18          	add    $0x18,%rbp
  6f8bd4:	48 ff c3             	inc    %rbx
  6f8bd7:	48 3b 6c 24 20       	cmp    0x20(%rsp),%rbp
  6f8bdc:	0f 84 1e 04 00 00    	je     6f9000 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ff0>
  6f8be2:	48 8b 45 00          	mov    0x0(%rbp),%rax
  6f8be6:	48 85 c0             	test   %rax,%rax
  6f8be9:	0f 84 16 4b 00 00    	je     6fd705 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x66f5>
  6f8bef:	8b 7d 08             	mov    0x8(%rbp),%edi
  6f8bf2:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  6f8bf7:	48 39 cf             	cmp    %rcx,%rdi
  6f8bfa:	74 3f                	je     6f8c3b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1c2b>
  6f8bfc:	48 39 bc 24 80 00 00 	cmp    %rdi,0x80(%rsp)
  6f8c03:	00 
  6f8c04:	0f 86 b5 4d 00 00    	jbe    6fd9bf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x69af>
  6f8c0a:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  6f8c0e:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
  6f8c13:	4c 8b 34 ca          	mov    (%rdx,%rcx,8),%r14
  6f8c17:	41 bf 01 00 00 00    	mov    $0x1,%r15d
  6f8c1d:	4d 85 f6             	test   %r14,%r14
  6f8c20:	0f 84 b3 4b 00 00    	je     6fd7d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x67c9>
  6f8c26:	48 8b 14 24          	mov    (%rsp),%rdx
  6f8c2a:	48 8b 8a 60 06 00 00 	mov    0x660(%rdx),%rcx
  6f8c31:	48 85 c9             	test   %rcx,%rcx
  6f8c34:	75 1c                	jne    6f8c52 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1c42>
  6f8c36:	e9 f5 01 00 00       	jmp    6f8e30 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e20>
  6f8c3b:	45 31 ff             	xor    %r15d,%r15d
  6f8c3e:	48 8b 14 24          	mov    (%rsp),%rdx
  6f8c42:	48 8b 8a 60 06 00 00 	mov    0x660(%rdx),%rcx
  6f8c49:	48 85 c9             	test   %rcx,%rcx
  6f8c4c:	0f 84 de 01 00 00    	je     6f8e30 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e20>
  6f8c52:	48 8b b2 68 06 00 00 	mov    0x668(%rdx),%rsi
  6f8c59:	44 0f b7 81 c2 01 00 	movzwl 0x1c2(%rcx),%r8d
  6f8c60:	00 
  6f8c61:	45 89 c1             	mov    %r8d,%r9d
  6f8c64:	41 c1 e1 05          	shl    $0x5,%r9d
  6f8c68:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
  6f8c6f:	31 d2                	xor    %edx,%edx
  6f8c71:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f8c78:	0f 1f 84 00 00 00 00 
  6f8c7f:	00 
  6f8c80:	49 39 d1             	cmp    %rdx,%r9
  6f8c83:	74 2b                	je     6f8cb0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ca0>
  6f8c85:	48 3b 84 f9 70 01 00 	cmp    0x170(%rcx,%rdi,8),%rax
  6f8c8c:	00 
  6f8c8d:	41 0f 97 c2          	seta   %r10b
  6f8c91:	41 80 da 00          	sbb    $0x0,%r10b
  6f8c95:	48 83 c2 20          	add    $0x20,%rdx
  6f8c99:	48 ff c7             	inc    %rdi
  6f8c9c:	41 80 fa 01          	cmp    $0x1,%r10b
  6f8ca0:	74 de                	je     6f8c80 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1c70>
  6f8ca2:	45 0f b6 c2          	movzbl %r10b,%r8d
  6f8ca6:	45 85 c0             	test   %r8d,%r8d
  6f8ca9:	75 08                	jne    6f8cb3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ca3>
  6f8cab:	eb 23                	jmp    6f8cd0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1cc0>
  6f8cad:	0f 1f 00             	nopl   (%rax)
  6f8cb0:	4c 89 c7             	mov    %r8,%rdi
  6f8cb3:	48 83 ee 01          	sub    $0x1,%rsi
  6f8cb7:	0f 82 73 01 00 00    	jb     6f8e30 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e20>
  6f8cbd:	48 8b 8c f9 c8 01 00 	mov    0x1c8(%rcx,%rdi,8),%rcx
  6f8cc4:	00 
  6f8cc5:	eb 92                	jmp    6f8c59 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1c49>
  6f8cc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f8cce:	00 00 
  6f8cd0:	80 7c 11 fc 01       	cmpb   $0x1,-0x4(%rcx,%rdx,1)
  6f8cd5:	0f 85 55 01 00 00    	jne    6f8e30 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e20>
  6f8cdb:	8b 45 10             	mov    0x10(%rbp),%eax
  6f8cde:	83 e0 0f             	and    $0xf,%eax
  6f8ce1:	83 f8 09             	cmp    $0x9,%eax
  6f8ce4:	0f 87 72 4b 00 00    	ja     6fd85c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x684c>
  6f8cea:	48 8d 35 33 f0 95 ff 	lea    -0x6a0fcd(%rip),%rsi        # 57d24 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x7c>
  6f8cf1:	48 63 04 86          	movslq (%rsi,%rax,4),%rax
  6f8cf5:	48 01 f0             	add    %rsi,%rax
  6f8cf8:	ff e0                	jmp    *%rax
  6f8cfa:	31 c0                	xor    %eax,%eax
  6f8cfc:	eb 1e                	jmp    6f8d1c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1d0c>
  6f8cfe:	b0 06                	mov    $0x6,%al
  6f8d00:	eb 1a                	jmp    6f8d1c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1d0c>
  6f8d02:	b0 04                	mov    $0x4,%al
  6f8d04:	eb 16                	jmp    6f8d1c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1d0c>
  6f8d06:	b0 05                	mov    $0x5,%al
  6f8d08:	eb 12                	jmp    6f8d1c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1d0c>
  6f8d0a:	b0 09                	mov    $0x9,%al
  6f8d0c:	eb 0e                	jmp    6f8d1c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1d0c>
  6f8d0e:	b0 02                	mov    $0x2,%al
  6f8d10:	eb 0a                	jmp    6f8d1c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1d0c>
  6f8d12:	b0 03                	mov    $0x3,%al
  6f8d14:	eb 06                	jmp    6f8d1c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1d0c>
  6f8d16:	b0 07                	mov    $0x7,%al
  6f8d18:	eb 02                	jmp    6f8d1c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1d0c>
  6f8d1a:	b0 08                	mov    $0x8,%al
  6f8d1c:	4c 8b 6c 11 e8       	mov    -0x18(%rcx,%rdx,1),%r13
  6f8d21:	4c 89 bc 24 c0 02 00 	mov    %r15,0x2c0(%rsp)
  6f8d28:	00 
  6f8d29:	4c 89 b4 24 c8 02 00 	mov    %r14,0x2c8(%rsp)
  6f8d30:	00 
  6f8d31:	4c 89 ac 24 d0 02 00 	mov    %r13,0x2d0(%rsp)
  6f8d38:	00 
  6f8d39:	88 84 24 d8 02 00 00 	mov    %al,0x2d8(%rsp)
  6f8d40:	48 8b b4 24 70 06 00 	mov    0x670(%rsp),%rsi
  6f8d47:	00 
  6f8d48:	48 85 f6             	test   %rsi,%rsi
  6f8d4b:	74 5a                	je     6f8da7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1d97>
  6f8d4d:	48 8b 94 24 78 06 00 	mov    0x678(%rsp),%rdx
  6f8d54:	00 
  6f8d55:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f8d5c:	00 
  6f8d5d:	48 8d 8c 24 c0 02 00 	lea    0x2c0(%rsp),%rcx
  6f8d64:	00 
  6f8d65:	e8 56 6b fe ff       	call   6df8c0 <<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Mut, (core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize, alloc::collections::btree::node::marker::LeafOrInternal>>::search_tree::<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind)>>
  6f8d6a:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  6f8d71:	00 
  6f8d72:	80 bc 24 90 00 00 00 	cmpb   $0x0,0x90(%rsp)
  6f8d79:	00 
  6f8d7a:	0f 84 9c 00 00 00    	je     6f8e1c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e0c>
  6f8d80:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
  6f8d87:	00 
  6f8d88:	f3 0f 6f 06          	movdqu (%rsi),%xmm0
  6f8d8c:	66 0f 7f 84 24 a0 01 	movdqa %xmm0,0x1a0(%rsp)
  6f8d93:	00 00 
  6f8d95:	48 8b 94 24 c8 02 00 	mov    0x2c8(%rsp),%rdx
  6f8d9c:	00 
  6f8d9d:	48 8b 8c 24 d8 02 00 	mov    0x2d8(%rsp),%rcx
  6f8da4:	00 
  6f8da5:	eb 15                	jmp    6f8dbc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1dac>
  6f8da7:	48 8b 8c 24 d8 02 00 	mov    0x2d8(%rsp),%rcx
  6f8dae:	00 
  6f8daf:	4c 89 f2             	mov    %r14,%rdx
  6f8db2:	31 c0                	xor    %eax,%eax
  6f8db4:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
  6f8dbb:	00 
  6f8dbc:	4c 89 bc 24 90 00 00 	mov    %r15,0x90(%rsp)
  6f8dc3:	00 
  6f8dc4:	48 89 94 24 98 00 00 	mov    %rdx,0x98(%rsp)
  6f8dcb:	00 
  6f8dcc:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
  6f8dd3:	00 
  6f8dd4:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
  6f8ddb:	00 
  6f8ddc:	48 8d 8c 24 70 06 00 	lea    0x670(%rsp),%rcx
  6f8de3:	00 
  6f8de4:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
  6f8deb:	00 
  6f8dec:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  6f8df3:	00 
  6f8df4:	66 0f 6f 84 24 a0 01 	movdqa 0x1a0(%rsp),%xmm0
  6f8dfb:	00 00 
  6f8dfd:	f3 0f 7f 46 20       	movdqu %xmm0,0x20(%rsi)
  6f8e02:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f8e09:	00 
  6f8e0a:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f8e11:	00 
  6f8e12:	48 89 da             	mov    %rbx,%rdx
  6f8e15:	e8 26 8e 01 00       	call   711c40 <<alloc::collections::btree::map::entry::VacantEntry<(core::option::Option<u64>, gpui::list::ItemKey, gpui::element::NodeKind), usize>>::insert_entry>
  6f8e1a:	eb 10                	jmp    6f8e2c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e1c>
  6f8e1c:	48 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%rcx
  6f8e23:	00 
  6f8e24:	48 89 9c c8 68 01 00 	mov    %rbx,0x168(%rax,%rcx,8)
  6f8e2b:	00 
  6f8e2c:	48 8b 45 00          	mov    0x0(%rbp),%rax
  6f8e30:	4d 85 e4             	test   %r12,%r12
  6f8e33:	0f 84 97 fd ff ff    	je     6f8bd0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1bc0>
  6f8e39:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  6f8e3e:	4c 89 e1             	mov    %r12,%rcx
  6f8e41:	0f b7 b9 ba 00 00 00 	movzwl 0xba(%rcx),%edi
  6f8e48:	41 89 f8             	mov    %edi,%r8d
  6f8e4b:	41 c1 e0 03          	shl    $0x3,%r8d
  6f8e4f:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6f8e56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6f8e5d:	00 00 00 
  6f8e60:	4d 85 c0             	test   %r8,%r8
  6f8e63:	74 2b                	je     6f8e90 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e80>
  6f8e65:	48 3b 44 d1 10       	cmp    0x10(%rcx,%rdx,8),%rax
  6f8e6a:	41 0f 97 c1          	seta   %r9b
  6f8e6e:	41 80 d9 00          	sbb    $0x0,%r9b
  6f8e72:	48 ff c2             	inc    %rdx
  6f8e75:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  6f8e79:	41 80 f9 01          	cmp    $0x1,%r9b
  6f8e7d:	74 e1                	je     6f8e60 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e50>
  6f8e7f:	41 0f b6 f9          	movzbl %r9b,%edi
  6f8e83:	85 ff                	test   %edi,%edi
  6f8e85:	75 0c                	jne    6f8e93 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e83>
  6f8e87:	eb 27                	jmp    6f8eb0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ea0>
  6f8e89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6f8e90:	48 89 fa             	mov    %rdi,%rdx
  6f8e93:	48 83 ee 01          	sub    $0x1,%rsi
  6f8e97:	0f 82 33 fd ff ff    	jb     6f8bd0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1bc0>
  6f8e9d:	48 8b 8c d1 c0 00 00 	mov    0xc0(%rcx,%rdx,8),%rcx
  6f8ea4:	00 
  6f8ea5:	eb 9a                	jmp    6f8e41 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e31>
  6f8ea7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f8eae:	00 00 
  6f8eb0:	8b 45 10             	mov    0x10(%rbp),%eax
  6f8eb3:	83 e0 0f             	and    $0xf,%eax
  6f8eb6:	83 f8 09             	cmp    $0x9,%eax
  6f8eb9:	0f 87 9d 49 00 00    	ja     6fd85c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x684c>
  6f8ebf:	48 8d 35 86 ee 95 ff 	lea    -0x6a117a(%rip),%rsi        # 57d4c <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0xa4>
  6f8ec6:	48 63 04 86          	movslq (%rsi,%rax,4),%rax
  6f8eca:	48 01 f0             	add    %rsi,%rax
  6f8ecd:	ff e0                	jmp    *%rax
  6f8ecf:	31 c0                	xor    %eax,%eax
  6f8ed1:	eb 2d                	jmp    6f8f00 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ef0>
  6f8ed3:	b0 06                	mov    $0x6,%al
  6f8ed5:	eb 29                	jmp    6f8f00 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ef0>
  6f8ed7:	b0 04                	mov    $0x4,%al
  6f8ed9:	eb 25                	jmp    6f8f00 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ef0>
  6f8edb:	b0 05                	mov    $0x5,%al
  6f8edd:	eb 21                	jmp    6f8f00 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ef0>
  6f8edf:	b0 09                	mov    $0x9,%al
  6f8ee1:	eb 1d                	jmp    6f8f00 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ef0>
  6f8ee3:	b0 02                	mov    $0x2,%al
  6f8ee5:	eb 19                	jmp    6f8f00 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ef0>
  6f8ee7:	b0 03                	mov    $0x3,%al
  6f8ee9:	eb 15                	jmp    6f8f00 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ef0>
  6f8eeb:	b0 07                	mov    $0x7,%al
  6f8eed:	eb 11                	jmp    6f8f00 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ef0>
  6f8eef:	b0 08                	mov    $0x8,%al
  6f8ef1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f8ef8:	0f 1f 84 00 00 00 00 
  6f8eff:	00 
  6f8f00:	4c 8b 6c d1 60       	mov    0x60(%rcx,%rdx,8),%r13
  6f8f05:	4c 89 bc 24 c0 02 00 	mov    %r15,0x2c0(%rsp)
  6f8f0c:	00 
  6f8f0d:	4c 89 b4 24 c8 02 00 	mov    %r14,0x2c8(%rsp)
  6f8f14:	00 
  6f8f15:	4c 89 ac 24 d0 02 00 	mov    %r13,0x2d0(%rsp)
  6f8f1c:	00 
  6f8f1d:	88 84 24 d8 02 00 00 	mov    %al,0x2d8(%rsp)
  6f8f24:	48 8b b4 24 88 06 00 	mov    0x688(%rsp),%rsi
  6f8f2b:	00 
  6f8f2c:	48 85 f6             	test   %rsi,%rsi
  6f8f2f:	74 5a                	je     6f8f8b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1f7b>
  6f8f31:	48 8b 94 24 90 06 00 	mov    0x690(%rsp),%rdx
  6f8f38:	00 
  6f8f39:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f8f40:	00 
  6f8f41:	48 8d 8c 24 c0 02 00 	lea    0x2c0(%rsp),%rcx
  6f8f48:	00 
  6f8f49:	e8 72 69 fe ff       	call   6df8c0 <<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Mut, (core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize, alloc::collections::btree::node::marker::LeafOrInternal>>::search_tree::<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind)>>
  6f8f4e:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  6f8f55:	00 
  6f8f56:	80 bc 24 90 00 00 00 	cmpb   $0x0,0x90(%rsp)
  6f8f5d:	00 
  6f8f5e:	0f 84 55 fc ff ff    	je     6f8bb9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ba9>
  6f8f64:	48 8d 94 24 a0 00 00 	lea    0xa0(%rsp),%rdx
  6f8f6b:	00 
  6f8f6c:	f3 0f 6f 02          	movdqu (%rdx),%xmm0
  6f8f70:	66 0f 7f 84 24 a0 01 	movdqa %xmm0,0x1a0(%rsp)
  6f8f77:	00 00 
  6f8f79:	4c 8b b4 24 c8 02 00 	mov    0x2c8(%rsp),%r14
  6f8f80:	00 
  6f8f81:	48 8b 8c 24 d8 02 00 	mov    0x2d8(%rsp),%rcx
  6f8f88:	00 
  6f8f89:	eb 12                	jmp    6f8f9d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1f8d>
  6f8f8b:	48 8b 8c 24 d8 02 00 	mov    0x2d8(%rsp),%rcx
  6f8f92:	00 
  6f8f93:	31 c0                	xor    %eax,%eax
  6f8f95:	48 8d 94 24 a0 00 00 	lea    0xa0(%rsp),%rdx
  6f8f9c:	00 
  6f8f9d:	4c 89 bc 24 90 00 00 	mov    %r15,0x90(%rsp)
  6f8fa4:	00 
  6f8fa5:	4c 89 b4 24 98 00 00 	mov    %r14,0x98(%rsp)
  6f8fac:	00 
  6f8fad:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
  6f8fb4:	00 
  6f8fb5:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
  6f8fbc:	00 
  6f8fbd:	48 8d 8c 24 88 06 00 	lea    0x688(%rsp),%rcx
  6f8fc4:	00 
  6f8fc5:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
  6f8fcc:	00 
  6f8fcd:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  6f8fd4:	00 
  6f8fd5:	66 0f 6f 84 24 a0 01 	movdqa 0x1a0(%rsp),%xmm0
  6f8fdc:	00 00 
  6f8fde:	f3 0f 7f 42 20       	movdqu %xmm0,0x20(%rdx)
  6f8fe3:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f8fea:	00 
  6f8feb:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f8ff2:	00 
  6f8ff3:	48 89 da             	mov    %rbx,%rdx
  6f8ff6:	e8 45 8b 01 00       	call   711b40 <<alloc::collections::btree::map::entry::VacantEntry<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize>>::insert_entry>
  6f8ffb:	e9 d0 fb ff ff       	jmp    6f8bd0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1bc0>
  6f9000:	4c 8b b4 24 80 00 00 	mov    0x80(%rsp),%r14
  6f9007:	00 
  6f9008:	4a 8d 1c f5 00 00 00 	lea    0x0(,%r14,8),%rbx
  6f900f:	00 
  6f9010:	ff 15 82 26 39 00    	call   *0x392682(%rip)        # a8b698 <_DYNAMIC+0x240>
  6f9016:	be 08 00 00 00       	mov    $0x8,%esi
  6f901b:	48 89 df             	mov    %rbx,%rdi
  6f901e:	ff 15 7c 26 39 00    	call   *0x39267c(%rip)        # a8b6a0 <_DYNAMIC+0x248>
  6f9024:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  6f9029:	48 85 c0             	test   %rax,%rax
  6f902c:	0f 84 04 4c 00 00    	je     6fdc36 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c26>
  6f9032:	31 c0                	xor    %eax,%eax
  6f9034:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  6f9039:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
  6f903e:	66 90                	xchg   %ax,%ax
  6f9040:	48 8b 11             	mov    (%rcx),%rdx
  6f9043:	48 85 d2             	test   %rdx,%rdx
  6f9046:	0f 84 cb 46 00 00    	je     6fd717 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6707>
  6f904c:	48 89 14 c6          	mov    %rdx,(%rsi,%rax,8)
  6f9050:	48 ff c0             	inc    %rax
  6f9053:	48 83 c1 18          	add    $0x18,%rcx
  6f9057:	49 39 c6             	cmp    %rax,%r14
  6f905a:	75 e4                	jne    6f9040 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2030>
  6f905c:	4c 89 b4 24 90 02 00 	mov    %r14,0x290(%rsp)
  6f9063:	00 
  6f9064:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  6f9069:	eb 6b                	jmp    6f90d6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x20c6>
  6f906b:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  6f9072:	00 
  6f9073:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6f9078:	48 c7 02 20 00 00 00 	movq   $0x20,(%rdx)
  6f907f:	48 89 42 08          	mov    %rax,0x8(%rdx)
  6f9083:	4c 89 7a 10          	mov    %r15,0x10(%rdx)
  6f9087:	48 89 4a 18          	mov    %rcx,0x18(%rdx)
  6f908b:	48 83 bc 24 08 02 00 	cmpq   $0x0,0x208(%rsp)
  6f9092:	00 00 
  6f9094:	0f 84 e1 2c 00 00    	je     6fbd7b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d6b>
  6f909a:	48 8b 84 24 08 02 00 	mov    0x208(%rsp),%rax
  6f90a1:	00 
  6f90a2:	48 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%rax
  6f90a9:	00 
  6f90aa:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6f90ae:	ba 08 00 00 00       	mov    $0x8,%edx
  6f90b3:	48 8b bc 24 30 02 00 	mov    0x230(%rsp),%rdi
  6f90ba:	00 
  6f90bb:	e9 b5 2c 00 00       	jmp    6fbd75 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d65>
  6f90c0:	b8 08 00 00 00       	mov    $0x8,%eax
  6f90c5:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  6f90ca:	48 c7 84 24 90 02 00 	movq   $0x0,0x290(%rsp)
  6f90d1:	00 00 00 00 00 
  6f90d6:	4c 8b b4 24 20 04 00 	mov    0x420(%rsp),%r14
  6f90dd:	00 
  6f90de:	0f 10 84 24 30 08 00 	movups 0x830(%rsp),%xmm0
  6f90e5:	00 
  6f90e6:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
  6f90ed:	00 
  6f90ee:	0f 10 84 24 20 08 00 	movups 0x820(%rsp),%xmm0
  6f90f5:	00 
  6f90f6:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
  6f90fd:	00 
  6f90fe:	f3 0f 6f 84 24 e0 07 	movdqu 0x7e0(%rsp),%xmm0
  6f9105:	00 00 
  6f9107:	f3 0f 6f 8c 24 f0 07 	movdqu 0x7f0(%rsp),%xmm1
  6f910e:	00 00 
  6f9110:	f3 0f 6f 94 24 00 08 	movdqu 0x800(%rsp),%xmm2
  6f9117:	00 00 
  6f9119:	0f 10 9c 24 10 08 00 	movups 0x810(%rsp),%xmm3
  6f9120:	00 
  6f9121:	0f 29 9c 24 c0 00 00 	movaps %xmm3,0xc0(%rsp)
  6f9128:	00 
  6f9129:	66 0f 7f 94 24 b0 00 	movdqa %xmm2,0xb0(%rsp)
  6f9130:	00 00 
  6f9132:	66 0f 7f 8c 24 a0 00 	movdqa %xmm1,0xa0(%rsp)
  6f9139:	00 00 
  6f913b:	66 0f 7f 84 24 90 00 	movdqa %xmm0,0x90(%rsp)
  6f9142:	00 00 
  6f9144:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f914b:	00 
  6f914c:	48 8d 94 24 90 00 00 	lea    0x90(%rsp),%rdx
  6f9153:	00 
  6f9154:	4c 89 f6             	mov    %r14,%rsi
  6f9157:	ff 15 db 29 39 00    	call   *0x3929db(%rip)        # a8bb38 <_DYNAMIC+0x6e0>
  6f915d:	4d 85 f6             	test   %r14,%r14
  6f9160:	74 30                	je     6f9192 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2182>
  6f9162:	4a 8d 04 f5 00 00 00 	lea    0x0(,%r14,8),%rax
  6f9169:	00 
  6f916a:	48 8d 1c 40          	lea    (%rax,%rax,2),%rbx
  6f916e:	ff 15 24 25 39 00    	call   *0x392524(%rip)        # a8b698 <_DYNAMIC+0x240>
  6f9174:	be 08 00 00 00       	mov    $0x8,%esi
  6f9179:	48 89 df             	mov    %rbx,%rdi
  6f917c:	ff 15 1e 25 39 00    	call   *0x39251e(%rip)        # a8b6a0 <_DYNAMIC+0x248>
  6f9182:	48 85 c0             	test   %rax,%rax
  6f9185:	0f 84 98 4a 00 00    	je     6fdc23 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c13>
  6f918b:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  6f9190:	eb 05                	jmp    6f9197 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2187>
  6f9192:	b8 08 00 00 00       	mov    $0x8,%eax
  6f9197:	4c 89 b4 24 00 05 00 	mov    %r14,0x500(%rsp)
  6f919e:	00 
  6f919f:	4c 89 b4 24 88 01 00 	mov    %r14,0x188(%rsp)
  6f91a6:	00 
  6f91a7:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  6f91ae:	00 
  6f91af:	48 c7 84 24 98 01 00 	movq   $0x0,0x198(%rsp)
  6f91b6:	00 00 00 00 00 
  6f91bb:	49 89 de             	mov    %rbx,%r14
  6f91be:	49 c1 e6 04          	shl    $0x4,%r14
  6f91c2:	48 89 d8             	mov    %rbx,%rax
  6f91c5:	48 c1 e8 3c          	shr    $0x3c,%rax
  6f91c9:	0f 95 c0             	setne  %al
  6f91cc:	48 b9 01 00 00 00 00 	movabs $0x8000000000000001,%rcx
  6f91d3:	00 00 80 
  6f91d6:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
  6f91da:	49 39 ce             	cmp    %rcx,%r14
  6f91dd:	0f 97 c1             	seta   %cl
  6f91e0:	08 c1                	or     %al,%cl
  6f91e2:	74 14                	je     6f91f8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x21e8>
  6f91e4:	45 31 ff             	xor    %r15d,%r15d
  6f91e7:	4c 89 ff             	mov    %r15,%rdi
  6f91ea:	4c 89 f6             	mov    %r14,%rsi
  6f91ed:	ff 15 7d 25 39 00    	call   *0x39257d(%rip)        # a8b770 <_DYNAMIC+0x318>
  6f91f3:	e9 6f 4b 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6f91f8:	bb 08 00 00 00       	mov    $0x8,%ebx
  6f91fd:	4d 85 f6             	test   %r14,%r14
  6f9200:	74 66                	je     6f9268 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2258>
  6f9202:	ff 15 90 24 39 00    	call   *0x392490(%rip)        # a8b698 <_DYNAMIC+0x240>
  6f9208:	41 bf 08 00 00 00    	mov    $0x8,%r15d
  6f920e:	be 08 00 00 00       	mov    $0x8,%esi
  6f9213:	4c 89 f7             	mov    %r14,%rdi
  6f9216:	ff 15 84 24 39 00    	call   *0x392484(%rip)        # a8b6a0 <_DYNAMIC+0x248>
  6f921c:	48 85 c0             	test   %rax,%rax
  6f921f:	74 c6                	je     6f91e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x21d7>
  6f9221:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  6f9226:	eb 47                	jmp    6f926f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x225f>
  6f9228:	f3 0f 6f 84 24 98 00 	movdqu 0x98(%rsp),%xmm0
  6f922f:	00 00 
  6f9231:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f9236:	48 c7 01 20 00 00 00 	movq   $0x20,(%rcx)
  6f923d:	48 89 41 08          	mov    %rax,0x8(%rcx)
  6f9241:	f3 0f 7f 41 10       	movdqu %xmm0,0x10(%rcx)
  6f9246:	e9 0c 2b 00 00       	jmp    6fbd57 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d47>
  6f924b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f9250:	48 89 58 10          	mov    %rbx,0x10(%rax)
  6f9254:	48 c7 00 20 00 00 00 	movq   $0x20,(%rax)
  6f925b:	48 c7 40 08 0c 00 00 	movq   $0xc,0x8(%rax)
  6f9262:	00 
  6f9263:	e9 92 3f 00 00       	jmp    6fd1fa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61ea>
  6f9268:	31 c9                	xor    %ecx,%ecx
  6f926a:	b8 08 00 00 00       	mov    $0x8,%eax
  6f926f:	48 89 8c 24 50 05 00 	mov    %rcx,0x550(%rsp)
  6f9276:	00 
  6f9277:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
  6f927e:	00 
  6f927f:	48 c7 84 24 60 05 00 	movq   $0x0,0x560(%rsp)
  6f9286:	00 00 00 00 00 
  6f928b:	48 8b 84 24 18 04 00 	mov    0x418(%rsp),%rax
  6f9292:	00 
  6f9293:	4c 8b b4 24 00 05 00 	mov    0x500(%rsp),%r14
  6f929a:	00 
  6f929b:	4d 85 f6             	test   %r14,%r14
  6f929e:	74 13                	je     6f92b3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x22a3>
  6f92a0:	44 89 f1             	mov    %r14d,%ecx
  6f92a3:	83 e1 03             	and    $0x3,%ecx
  6f92a6:	49 83 fe 04          	cmp    $0x4,%r14
  6f92aa:	73 0f                	jae    6f92bb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x22ab>
  6f92ac:	31 d2                	xor    %edx,%edx
  6f92ae:	45 31 ff             	xor    %r15d,%r15d
  6f92b1:	eb 76                	jmp    6f9329 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2319>
  6f92b3:	49 89 c4             	mov    %rax,%r12
  6f92b6:	e9 d8 00 00 00       	jmp    6f9393 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2383>
  6f92bb:	48 be fc ff ff ff ff 	movabs $0xfffffffffffffc,%rsi
  6f92c2:	ff ff 00 
  6f92c5:	4c 21 f6             	and    %r14,%rsi
  6f92c8:	31 d2                	xor    %edx,%edx
  6f92ca:	48 89 c7             	mov    %rax,%rdi
  6f92cd:	45 31 ff             	xor    %r15d,%r15d
  6f92d0:	45 31 c0             	xor    %r8d,%r8d
  6f92d3:	48 83 3f ff          	cmpq   $0xffffffffffffffff,(%rdi)
  6f92d7:	41 0f 95 c0          	setne  %r8b
  6f92db:	4d 01 f8             	add    %r15,%r8
  6f92de:	45 31 c9             	xor    %r9d,%r9d
  6f92e1:	48 83 bf 98 00 00 00 	cmpq   $0xffffffffffffffff,0x98(%rdi)
  6f92e8:	ff 
  6f92e9:	41 0f 95 c1          	setne  %r9b
  6f92ed:	45 31 d2             	xor    %r10d,%r10d
  6f92f0:	48 83 bf 30 01 00 00 	cmpq   $0xffffffffffffffff,0x130(%rdi)
  6f92f7:	ff 
  6f92f8:	41 0f 95 c2          	setne  %r10b
  6f92fc:	4d 01 ca             	add    %r9,%r10
  6f92ff:	4d 01 c2             	add    %r8,%r10
  6f9302:	45 31 ff             	xor    %r15d,%r15d
  6f9305:	48 83 bf c8 01 00 00 	cmpq   $0xffffffffffffffff,0x1c8(%rdi)
  6f930c:	ff 
  6f930d:	41 0f 95 c7          	setne  %r15b
  6f9311:	4d 01 d7             	add    %r10,%r15
  6f9314:	48 83 c2 04          	add    $0x4,%rdx
  6f9318:	48 81 c7 60 02 00 00 	add    $0x260,%rdi
  6f931f:	48 39 d6             	cmp    %rdx,%rsi
  6f9322:	75 ac                	jne    6f92d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x22c0>
  6f9324:	48 85 c9             	test   %rcx,%rcx
  6f9327:	74 2d                	je     6f9356 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2346>
  6f9329:	48 69 d2 98 00 00 00 	imul   $0x98,%rdx,%rdx
  6f9330:	48 01 c2             	add    %rax,%rdx
  6f9333:	48 69 c9 98 00 00 00 	imul   $0x98,%rcx,%rcx
  6f933a:	31 f6                	xor    %esi,%esi
  6f933c:	31 ff                	xor    %edi,%edi
  6f933e:	48 83 3c 32 ff       	cmpq   $0xffffffffffffffff,(%rdx,%rsi,1)
  6f9343:	40 0f 95 c7          	setne  %dil
  6f9347:	49 01 ff             	add    %rdi,%r15
  6f934a:	48 81 c6 98 00 00 00 	add    $0x98,%rsi
  6f9351:	48 39 f1             	cmp    %rsi,%rcx
  6f9354:	75 e6                	jne    6f933c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x232c>
  6f9356:	49 89 c4             	mov    %rax,%r12
  6f9359:	4d 85 ff             	test   %r15,%r15
  6f935c:	74 35                	je     6f9393 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2383>
  6f935e:	4c 89 f8             	mov    %r15,%rax
  6f9361:	48 c1 e0 04          	shl    $0x4,%rax
  6f9365:	4c 8d 34 80          	lea    (%rax,%rax,4),%r14
  6f9369:	ff 15 29 23 39 00    	call   *0x392329(%rip)        # a8b698 <_DYNAMIC+0x240>
  6f936f:	be 08 00 00 00       	mov    $0x8,%esi
  6f9374:	4c 89 f7             	mov    %r14,%rdi
  6f9377:	ff 15 23 23 39 00    	call   *0x392323(%rip)        # a8b6a0 <_DYNAMIC+0x248>
  6f937d:	48 85 c0             	test   %rax,%rax
  6f9380:	0f 84 36 49 00 00    	je     6fdcbc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cac>
  6f9386:	48 89 c3             	mov    %rax,%rbx
  6f9389:	4c 8b b4 24 00 05 00 	mov    0x500(%rsp),%r14
  6f9390:	00 
  6f9391:	eb 03                	jmp    6f9396 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2386>
  6f9393:	45 31 ff             	xor    %r15d,%r15d
  6f9396:	4c 89 bc 24 68 05 00 	mov    %r15,0x568(%rsp)
  6f939d:	00 
  6f939e:	48 89 9c 24 70 05 00 	mov    %rbx,0x570(%rsp)
  6f93a5:	00 
  6f93a6:	48 c7 84 24 78 05 00 	movq   $0x0,0x578(%rsp)
  6f93ad:	00 00 00 00 00 
  6f93b2:	4a 8d 1c b5 04 00 00 	lea    0x4(,%r14,4),%rbx
  6f93b9:	00 
  6f93ba:	ff 15 d8 22 39 00    	call   *0x3922d8(%rip)        # a8b698 <_DYNAMIC+0x240>
  6f93c0:	be 04 00 00 00       	mov    $0x4,%esi
  6f93c5:	48 89 df             	mov    %rbx,%rdi
  6f93c8:	ff 15 0a 27 39 00    	call   *0x39270a(%rip)        # a8bad8 <_DYNAMIC+0x680>
  6f93ce:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  6f93d5:	00 
  6f93d6:	48 85 c0             	test   %rax,%rax
  6f93d9:	0f 84 80 48 00 00    	je     6fdc5f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c4f>
  6f93df:	48 89 9c 24 88 02 00 	mov    %rbx,0x288(%rsp)
  6f93e6:	00 
  6f93e7:	49 69 ce 98 00 00 00 	imul   $0x98,%r14,%rcx
  6f93ee:	4c 01 e1             	add    %r12,%rcx
  6f93f1:	48 8b 84 24 10 04 00 	mov    0x410(%rsp),%rax
  6f93f8:	00 
  6f93f9:	4c 89 a4 24 d0 06 00 	mov    %r12,0x6d0(%rsp)
  6f9400:	00 
  6f9401:	4c 89 a4 24 d8 06 00 	mov    %r12,0x6d8(%rsp)
  6f9408:	00 
  6f9409:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
  6f9410:	00 
  6f9411:	48 89 8c 24 48 08 00 	mov    %rcx,0x848(%rsp)
  6f9418:	00 
  6f9419:	48 89 8c 24 e8 06 00 	mov    %rcx,0x6e8(%rsp)
  6f9420:	00 
  6f9421:	48 c7 84 24 f0 06 00 	movq   $0x0,0x6f0(%rsp)
  6f9428:	00 00 00 00 00 
  6f942d:	4d 85 f6             	test   %r14,%r14
  6f9430:	0f 84 c1 1a 00 00    	je     6faef7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3ee7>
  6f9436:	4c 89 e6             	mov    %r12,%rsi
  6f9439:	49 8d 46 01          	lea    0x1(%r14),%rax
  6f943d:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
  6f9444:	00 
  6f9445:	48 8b 04 24          	mov    (%rsp),%rax
  6f9449:	48 05 78 06 00 00    	add    $0x678,%rax
  6f944f:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6f9454:	48 8d 05 6d 9c 36 00 	lea    0x369c6d(%rip),%rax        # a630c8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xcc8>
  6f945b:	48 89 84 24 c0 03 00 	mov    %rax,0x3c0(%rsp)
  6f9462:	00 
  6f9463:	48 8d 05 a6 94 36 00 	lea    0x3694a6(%rip),%rax        # a62910 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x510>
  6f946a:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
  6f9471:	00 
  6f9472:	48 8d 05 97 9c 36 00 	lea    0x369c97(%rip),%rax        # a63110 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xd10>
  6f9479:	48 89 84 24 58 06 00 	mov    %rax,0x658(%rsp)
  6f9480:	00 
  6f9481:	48 8d 05 d0 94 36 00 	lea    0x3694d0(%rip),%rax        # a62958 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x558>
  6f9488:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
  6f948f:	00 
  6f9490:	45 31 f6             	xor    %r14d,%r14d
  6f9493:	45 31 ed             	xor    %r13d,%r13d
  6f9496:	4c 8b a4 24 80 00 00 	mov    0x80(%rsp),%r12
  6f949d:	00 
  6f949e:	48 8d 86 98 00 00 00 	lea    0x98(%rsi),%rax
  6f94a5:	48 89 84 24 d8 06 00 	mov    %rax,0x6d8(%rsp)
  6f94ac:	00 
  6f94ad:	48 8b 1e             	mov    (%rsi),%rbx
  6f94b0:	48 83 fb fe          	cmp    $0xfffffffffffffffe,%rbx
  6f94b4:	0f 84 48 1a 00 00    	je     6faf02 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3ef2>
  6f94ba:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
  6f94c1:	00 
  6f94c2:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
  6f94c9:	00 
  6f94ca:	48 83 c6 08          	add    $0x8,%rsi
  6f94ce:	ba 90 00 00 00       	mov    $0x90,%edx
  6f94d3:	4c 8d bc 24 c0 02 00 	lea    0x2c0(%rsp),%r15
  6f94da:	00 
  6f94db:	4c 89 ff             	mov    %r15,%rdi
  6f94de:	4c 8b 2d d3 21 39 00 	mov    0x3921d3(%rip),%r13        # a8b6b8 <memcpy@GLIBC_2.14>
  6f94e5:	41 ff d5             	call   *%r13
  6f94e8:	49 8d 46 01          	lea    0x1(%r14),%rax
  6f94ec:	48 89 84 24 f0 03 00 	mov    %rax,0x3f0(%rsp)
  6f94f3:	00 
  6f94f4:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
  6f94fb:	00 
  6f94fc:	48 89 9c 24 90 00 00 	mov    %rbx,0x90(%rsp)
  6f9503:	00 
  6f9504:	ba 90 00 00 00       	mov    $0x90,%edx
  6f9509:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
  6f9510:	00 
  6f9511:	4c 89 fe             	mov    %r15,%rsi
  6f9514:	41 ff d5             	call   *%r13
  6f9517:	8b 94 24 a8 00 00 00 	mov    0xa8(%rsp),%edx
  6f951e:	8b 84 24 ac 00 00 00 	mov    0xac(%rsp),%eax
  6f9525:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f952a:	4c 8d 68 01          	lea    0x1(%rax),%r13
  6f952e:	48 85 d2             	test   %rdx,%rdx
  6f9531:	4c 89 eb             	mov    %r13,%rbx
  6f9534:	48 0f 44 da          	cmove  %rdx,%rbx
  6f9538:	48 3b 9c 24 00 05 00 	cmp    0x500(%rsp),%rbx
  6f953f:	00 
  6f9540:	0f 87 bf 46 00 00    	ja     6fdc05 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6bf5>
  6f9546:	48 8b 8c 24 10 02 00 	mov    0x210(%rsp),%rcx
  6f954d:	00 
  6f954e:	8b 04 99             	mov    (%rcx,%rbx,4),%eax
  6f9551:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
  6f9558:	00 
  6f9559:	ff c0                	inc    %eax
  6f955b:	89 04 99             	mov    %eax,(%rcx,%rbx,4)
  6f955e:	48 89 94 24 98 02 00 	mov    %rdx,0x298(%rsp)
  6f9565:	00 
  6f9566:	84 d2                	test   %dl,%dl
  6f9568:	0f 84 cf 00 00 00    	je     6f963d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x262d>
  6f956e:	48 8b 84 24 98 01 00 	mov    0x198(%rsp),%rax
  6f9575:	00 
  6f9576:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  6f957b:	48 39 c8             	cmp    %rcx,%rax
  6f957e:	0f 86 b6 45 00 00    	jbe    6fdb3a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b2a>
  6f9584:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  6f958b:	00 
  6f958c:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  6f9590:	48 8b 2c c8          	mov    (%rax,%rcx,8),%rbp
  6f9594:	48 8b 04 24          	mov    (%rsp),%rax
  6f9598:	48 8b 80 e8 01 00 00 	mov    0x1e8(%rax),%rax
  6f959f:	48 85 c0             	test   %rax,%rax
  6f95a2:	0f 84 da 00 00 00    	je     6f9682 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2672>
  6f95a8:	83 f8 01             	cmp    $0x1,%eax
  6f95ab:	0f 85 f5 00 00 00    	jne    6f96a6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2696>
  6f95b1:	48 8b 0c 24          	mov    (%rsp),%rcx
  6f95b5:	48 8b 91 f8 01 00 00 	mov    0x1f8(%rcx),%rdx
  6f95bc:	b8 04 00 00 00       	mov    $0x4,%eax
  6f95c1:	48 85 d2             	test   %rdx,%rdx
  6f95c4:	0f 84 58 01 00 00    	je     6f9722 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2712>
  6f95ca:	48 8b 89 f0 01 00 00 	mov    0x1f0(%rcx),%rcx
  6f95d1:	31 f6                	xor    %esi,%esi
  6f95d3:	48 83 fa 01          	cmp    $0x1,%rdx
  6f95d7:	74 24                	je     6f95fd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x25ed>
  6f95d9:	48 89 f7             	mov    %rsi,%rdi
  6f95dc:	49 89 d0             	mov    %rdx,%r8
  6f95df:	49 d1 e8             	shr    $1,%r8
  6f95e2:	4c 01 c6             	add    %r8,%rsi
  6f95e5:	49 89 f1             	mov    %rsi,%r9
  6f95e8:	49 c1 e1 04          	shl    $0x4,%r9
  6f95ec:	4a 39 2c 09          	cmp    %rbp,(%rcx,%r9,1)
  6f95f0:	48 0f 47 f7          	cmova  %rdi,%rsi
  6f95f4:	4c 29 c2             	sub    %r8,%rdx
  6f95f7:	48 83 fa 01          	cmp    $0x1,%rdx
  6f95fb:	77 dc                	ja     6f95d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x25c9>
  6f95fd:	48 89 f7             	mov    %rsi,%rdi
  6f9600:	48 c1 e7 04          	shl    $0x4,%rdi
  6f9604:	31 d2                	xor    %edx,%edx
  6f9606:	48 39 2c 39          	cmp    %rbp,(%rcx,%rdi,1)
  6f960a:	0f 96 c2             	setbe  %dl
  6f960d:	48 01 f2             	add    %rsi,%rdx
  6f9610:	0f 84 0a 01 00 00    	je     6f9720 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2710>
  6f9616:	48 c1 e2 04          	shl    $0x4,%rdx
  6f961a:	48 89 ee             	mov    %rbp,%rsi
  6f961d:	48 2b 74 11 f0       	sub    -0x10(%rcx,%rdx,1),%rsi
  6f9622:	8b 7c 11 fc          	mov    -0x4(%rcx,%rdx,1),%edi
  6f9626:	48 39 fe             	cmp    %rdi,%rsi
  6f9629:	0f 83 f1 00 00 00    	jae    6f9720 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2710>
  6f962f:	48 01 d1             	add    %rdx,%rcx
  6f9632:	8b 41 f8             	mov    -0x8(%rcx),%eax
  6f9635:	48 01 c6             	add    %rax,%rsi
  6f9638:	e9 c6 00 00 00       	jmp    6f9703 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x26f3>
  6f963d:	31 ff                	xor    %edi,%edi
  6f963f:	ff 15 4b 24 39 00    	call   *0x39244b(%rip)        # a8ba90 <_DYNAMIC+0x638>
  6f9645:	48 8d bc 24 c8 07 00 	lea    0x7c8(%rsp),%rdi
  6f964c:	00 
  6f964d:	89 c6                	mov    %eax,%esi
  6f964f:	ff 15 eb 24 39 00    	call   *0x3924eb(%rip)        # a8bb40 <_DYNAMIC+0x6e8>
  6f9655:	31 c9                	xor    %ecx,%ecx
  6f9657:	80 bc 24 50 03 00 00 	cmpb   $0x0,0x350(%rsp)
  6f965e:	00 
  6f965f:	0f 85 d0 00 00 00    	jne    6f9735 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2725>
  6f9665:	31 f6                	xor    %esi,%esi
  6f9667:	48 8b bc 24 68 08 00 	mov    0x868(%rsp),%rdi
  6f966e:	00 
  6f966f:	48 85 ff             	test   %rdi,%rdi
  6f9672:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  6f9677:	0f 85 e9 00 00 00    	jne    6f9766 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2756>
  6f967d:	e9 d7 01 00 00       	jmp    6f9859 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2849>
  6f9682:	b8 04 00 00 00       	mov    $0x4,%eax
  6f9687:	48 89 ee             	mov    %rbp,%rsi
  6f968a:	48 8b 0c 24          	mov    (%rsp),%rcx
  6f968e:	48 2b b1 f0 01 00 00 	sub    0x1f0(%rcx),%rsi
  6f9695:	0f 82 85 00 00 00    	jb     6f9720 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2710>
  6f969b:	48 3b b1 f8 01 00 00 	cmp    0x1f8(%rcx),%rsi
  6f96a2:	73 7c                	jae    6f9720 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2710>
  6f96a4:	eb 5d                	jmp    6f9703 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x26f3>
  6f96a6:	48 8b 0c 24          	mov    (%rsp),%rcx
  6f96aa:	48 8b 91 f8 01 00 00 	mov    0x1f8(%rcx),%rdx
  6f96b1:	b8 04 00 00 00       	mov    $0x4,%eax
  6f96b6:	48 85 d2             	test   %rdx,%rdx
  6f96b9:	74 67                	je     6f9722 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2712>
  6f96bb:	48 8b 89 f0 01 00 00 	mov    0x1f0(%rcx),%rcx
  6f96c2:	48 83 fa 01          	cmp    $0x1,%rdx
  6f96c6:	75 07                	jne    6f96cf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x26bf>
  6f96c8:	48 39 29             	cmp    %rbp,(%rcx)
  6f96cb:	74 33                	je     6f9700 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x26f0>
  6f96cd:	eb 51                	jmp    6f9720 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2710>
  6f96cf:	31 f6                	xor    %esi,%esi
  6f96d1:	48 89 f7             	mov    %rsi,%rdi
  6f96d4:	49 89 d0             	mov    %rdx,%r8
  6f96d7:	49 d1 e8             	shr    $1,%r8
  6f96da:	4c 01 c6             	add    %r8,%rsi
  6f96dd:	4c 8d 0c 76          	lea    (%rsi,%rsi,2),%r9
  6f96e1:	4a 39 2c 89          	cmp    %rbp,(%rcx,%r9,4)
  6f96e5:	48 0f 47 f7          	cmova  %rdi,%rsi
  6f96e9:	4c 29 c2             	sub    %r8,%rdx
  6f96ec:	48 83 fa 01          	cmp    $0x1,%rdx
  6f96f0:	77 df                	ja     6f96d1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x26c1>
  6f96f2:	48 8d 14 76          	lea    (%rsi,%rsi,2),%rdx
  6f96f6:	48 39 2c 91          	cmp    %rbp,(%rcx,%rdx,4)
  6f96fa:	75 24                	jne    6f9720 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2710>
  6f96fc:	48 8d 0c 91          	lea    (%rcx,%rdx,4),%rcx
  6f9700:	8b 71 08             	mov    0x8(%rcx),%esi
  6f9703:	bf 01 00 00 00       	mov    $0x1,%edi
  6f9708:	ff 15 82 23 39 00    	call   *0x392382(%rip)        # a8ba90 <_DYNAMIC+0x638>
  6f970e:	48 8d bc 24 c8 07 00 	lea    0x7c8(%rsp),%rdi
  6f9715:	00 
  6f9716:	89 c6                	mov    %eax,%esi
  6f9718:	ff 15 22 24 39 00    	call   *0x392422(%rip)        # a8bb40 <_DYNAMIC+0x6e8>
  6f971e:	eb 02                	jmp    6f9722 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2712>
  6f9720:	31 d2                	xor    %edx,%edx
  6f9722:	b9 01 00 00 00       	mov    $0x1,%ecx
  6f9727:	80 bc 24 50 03 00 00 	cmpb   $0x0,0x350(%rsp)
  6f972e:	00 
  6f972f:	0f 84 30 ff ff ff    	je     6f9665 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2655>
  6f9735:	48 3b 5c 24 68       	cmp    0x68(%rsp),%rbx
  6f973a:	0f 87 11 44 00 00    	ja     6fdb51 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b41>
  6f9740:	48 8b b4 24 a0 02 00 	mov    0x2a0(%rsp),%rsi
  6f9747:	00 
  6f9748:	48 3b 14 de          	cmp    (%rsi,%rbx,8),%rdx
  6f974c:	40 0f 94 c6          	sete   %sil
  6f9750:	48 8b bc 24 68 08 00 	mov    0x868(%rsp),%rdi
  6f9757:	00 
  6f9758:	48 85 ff             	test   %rdi,%rdi
  6f975b:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  6f9760:	0f 84 f3 00 00 00    	je     6f9859 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2849>
  6f9766:	4c 8b 84 24 70 08 00 	mov    0x870(%rsp),%r8
  6f976d:	00 
  6f976e:	44 0f b7 97 12 01 00 	movzwl 0x112(%rdi),%r10d
  6f9775:	00 
  6f9776:	44 89 d3             	mov    %r10d,%ebx
  6f9779:	c1 e3 04             	shl    $0x4,%ebx
  6f977c:	49 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%r9
  6f9783:	45 31 db             	xor    %r11d,%r11d
  6f9786:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6f978d:	00 00 00 
  6f9790:	4c 39 db             	cmp    %r11,%rbx
  6f9793:	74 28                	je     6f97bd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x27ad>
  6f9795:	4e 3b b4 cf c0 00 00 	cmp    0xc0(%rdi,%r9,8),%r14
  6f979c:	00 
  6f979d:	40 0f 97 c5          	seta   %bpl
  6f97a1:	40 80 dd 00          	sbb    $0x0,%bpl
  6f97a5:	49 83 c3 10          	add    $0x10,%r11
  6f97a9:	49 ff c1             	inc    %r9
  6f97ac:	40 80 fd 01          	cmp    $0x1,%bpl
  6f97b0:	74 de                	je     6f9790 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2780>
  6f97b2:	44 0f b6 d5          	movzbl %bpl,%r10d
  6f97b6:	45 85 d2             	test   %r10d,%r10d
  6f97b9:	75 05                	jne    6f97c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x27b0>
  6f97bb:	eb 1c                	jmp    6f97d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x27c9>
  6f97bd:	4d 89 d1             	mov    %r10,%r9
  6f97c0:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
  6f97c5:	49 83 e8 01          	sub    $0x1,%r8
  6f97c9:	0f 82 8a 00 00 00    	jb     6f9859 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2849>
  6f97cf:	4a 8b bc cf 18 01 00 	mov    0x118(%rdi,%r9,8),%rdi
  6f97d6:	00 
  6f97d7:	eb 95                	jmp    6f976e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x275e>
  6f97d9:	80 bc 24 50 03 00 00 	cmpb   $0x0,0x350(%rsp)
  6f97e0:	00 
  6f97e1:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  6f97e6:	0f 84 9c 04 00 00    	je     6f9c88 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c78>
  6f97ec:	4a 8b 44 1f f8       	mov    -0x8(%rdi,%r11,1),%rax
  6f97f1:	48 8b 40 08          	mov    0x8(%rax),%rax
  6f97f5:	8b 94 24 20 01 00 00 	mov    0x120(%rsp),%edx
  6f97fc:	80 fa 02             	cmp    $0x2,%dl
  6f97ff:	be 00 00 00 00       	mov    $0x0,%esi
  6f9804:	0f 42 d6             	cmovb  %esi,%edx
  6f9807:	48 89 8c 24 60 03 00 	mov    %rcx,0x360(%rsp)
  6f980e:	00 
  6f980f:	4c 89 84 24 68 03 00 	mov    %r8,0x368(%rsp)
  6f9816:	00 
  6f9817:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
  6f981e:	00 
  6f981f:	88 94 24 78 03 00 00 	mov    %dl,0x378(%rsp)
  6f9826:	48 8b b4 24 70 06 00 	mov    0x670(%rsp),%rsi
  6f982d:	00 
  6f982e:	48 85 f6             	test   %rsi,%rsi
  6f9831:	0f 84 51 04 00 00    	je     6f9c88 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c78>
  6f9837:	48 8b 94 24 78 06 00 	mov    0x678(%rsp),%rdx
  6f983e:	00 
  6f983f:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6f9846:	00 
  6f9847:	48 8d 8c 24 60 03 00 	lea    0x360(%rsp),%rcx
  6f984e:	00 
  6f984f:	e8 6c 60 fe ff       	call   6df8c0 <<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Mut, (core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize, alloc::collections::btree::node::marker::LeafOrInternal>>::search_tree::<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind)>>
  6f9854:	e9 e7 00 00 00       	jmp    6f9940 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2930>
  6f9859:	48 8b bc 24 50 08 00 	mov    0x850(%rsp),%rdi
  6f9860:	00 
  6f9861:	48 85 ff             	test   %rdi,%rdi
  6f9864:	0f 84 4e 01 00 00    	je     6f99b8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x29a8>
  6f986a:	4c 8b 84 24 58 08 00 	mov    0x858(%rsp),%r8
  6f9871:	00 
  6f9872:	44 0f b7 97 ba 00 00 	movzwl 0xba(%rdi),%r10d
  6f9879:	00 
  6f987a:	45 89 d3             	mov    %r10d,%r11d
  6f987d:	41 c1 e3 03          	shl    $0x3,%r11d
  6f9881:	49 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%r9
  6f9888:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6f988f:	00 
  6f9890:	4d 85 db             	test   %r11,%r11
  6f9893:	74 22                	je     6f98b7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x28a7>
  6f9895:	4e 3b 74 cf 10       	cmp    0x10(%rdi,%r9,8),%r14
  6f989a:	0f 97 c3             	seta   %bl
  6f989d:	80 db 00             	sbb    $0x0,%bl
  6f98a0:	49 ff c1             	inc    %r9
  6f98a3:	49 83 c3 f8          	add    $0xfffffffffffffff8,%r11
  6f98a7:	80 fb 01             	cmp    $0x1,%bl
  6f98aa:	74 e4                	je     6f9890 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2880>
  6f98ac:	44 0f b6 d3          	movzbl %bl,%r10d
  6f98b0:	45 85 d2             	test   %r10d,%r10d
  6f98b3:	75 05                	jne    6f98ba <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x28aa>
  6f98b5:	eb 17                	jmp    6f98ce <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x28be>
  6f98b7:	4d 89 d1             	mov    %r10,%r9
  6f98ba:	49 83 e8 01          	sub    $0x1,%r8
  6f98be:	0f 82 f4 00 00 00    	jb     6f99b8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x29a8>
  6f98c4:	4a 8b bc cf c0 00 00 	mov    0xc0(%rdi,%r9,8),%rdi
  6f98cb:	00 
  6f98cc:	eb a4                	jmp    6f9872 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2862>
  6f98ce:	80 bc 24 50 03 00 00 	cmpb   $0x0,0x350(%rsp)
  6f98d5:	00 
  6f98d6:	0f 84 ac 03 00 00    	je     6f9c88 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c78>
  6f98dc:	4a 8b 44 cf 60       	mov    0x60(%rdi,%r9,8),%rax
  6f98e1:	8b 94 24 20 01 00 00 	mov    0x120(%rsp),%edx
  6f98e8:	80 fa 02             	cmp    $0x2,%dl
  6f98eb:	be 00 00 00 00       	mov    $0x0,%esi
  6f98f0:	0f 42 d6             	cmovb  %esi,%edx
  6f98f3:	48 89 8c 24 60 03 00 	mov    %rcx,0x360(%rsp)
  6f98fa:	00 
  6f98fb:	48 89 ac 24 68 03 00 	mov    %rbp,0x368(%rsp)
  6f9902:	00 
  6f9903:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
  6f990a:	00 
  6f990b:	88 94 24 78 03 00 00 	mov    %dl,0x378(%rsp)
  6f9912:	48 8b b4 24 88 06 00 	mov    0x688(%rsp),%rsi
  6f9919:	00 
  6f991a:	48 85 f6             	test   %rsi,%rsi
  6f991d:	0f 84 65 03 00 00    	je     6f9c88 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c78>
  6f9923:	48 8b 94 24 90 06 00 	mov    0x690(%rsp),%rdx
  6f992a:	00 
  6f992b:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6f9932:	00 
  6f9933:	48 8d 8c 24 60 03 00 	lea    0x360(%rsp),%rcx
  6f993a:	00 
  6f993b:	e8 80 5f fe ff       	call   6df8c0 <<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Mut, (core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize, alloc::collections::btree::node::marker::LeafOrInternal>>::search_tree::<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind)>>
  6f9940:	83 bc 24 a0 01 00 00 	cmpl   $0x1,0x1a0(%rsp)
  6f9947:	01 
  6f9948:	0f 84 3a 03 00 00    	je     6f9c88 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c78>
  6f994e:	48 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%rax
  6f9955:	00 
  6f9956:	48 8b 8c 24 b8 01 00 	mov    0x1b8(%rsp),%rcx
  6f995d:	00 
  6f995e:	4c 8b ac c8 68 01 00 	mov    0x168(%rax,%rcx,8),%r13
  6f9965:	00 
  6f9966:	4d 39 e5             	cmp    %r12,%r13
  6f9969:	0f 83 7f 42 00 00    	jae    6fdbee <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6bde>
  6f996f:	4a 8d 0c 6d 00 00 00 	lea    0x0(,%r13,2),%rcx
  6f9976:	00 
  6f9977:	4c 01 e9             	add    %r13,%rcx
  6f997a:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
  6f997f:	4c 8b 24 ca          	mov    (%rdx,%rcx,8),%r12
  6f9983:	8b 44 ca 0c          	mov    0xc(%rdx,%rcx,8),%eax
  6f9987:	44 8b 7c ca 10       	mov    0x10(%rdx,%rcx,8),%r15d
  6f998c:	8b 6c ca 14          	mov    0x14(%rdx,%rcx,8),%ebp
  6f9990:	48 c7 04 ca 00 00 00 	movq   $0x0,(%rdx,%rcx,8)
  6f9997:	00 
  6f9998:	4d 85 e4             	test   %r12,%r12
  6f999b:	0f 84 e7 02 00 00    	je     6f9c88 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c78>
  6f99a1:	45 85 ff             	test   %r15d,%r15d
  6f99a4:	0f 88 a8 00 00 00    	js     6f9a52 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2a42>
  6f99aa:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
  6f99b1:	00 00 
  6f99b3:	e9 df 00 00 00       	jmp    6f9a97 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2a87>
  6f99b8:	40 84 f6             	test   %sil,%sil
  6f99bb:	0f 84 c7 02 00 00    	je     6f9c88 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c78>
  6f99c1:	48 8b 8c 24 28 02 00 	mov    0x228(%rsp),%rcx
  6f99c8:	00 
  6f99c9:	48 39 ca             	cmp    %rcx,%rdx
  6f99cc:	0f 86 b6 02 00 00    	jbe    6f9c88 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c78>
  6f99d2:	44 8b 2c 88          	mov    (%rax,%rcx,4),%r13d
  6f99d6:	4d 39 ec             	cmp    %r13,%r12
  6f99d9:	0f 86 12 43 00 00    	jbe    6fdcf1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6ce1>
  6f99df:	4a 8d 04 6d 00 00 00 	lea    0x0(,%r13,2),%rax
  6f99e6:	00 
  6f99e7:	4c 01 e8             	add    %r13,%rax
  6f99ea:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  6f99ef:	48 83 3c c1 00       	cmpq   $0x0,(%rcx,%rax,8)
  6f99f4:	0f 84 8e 02 00 00    	je     6f9c88 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c78>
  6f99fa:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
  6f99fe:	8b 48 10             	mov    0x10(%rax),%ecx
  6f9a01:	83 e1 0f             	and    $0xf,%ecx
  6f9a04:	83 f9 09             	cmp    $0x9,%ecx
  6f9a07:	0f 87 0d 40 00 00    	ja     6fda1a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a0a>
  6f9a0d:	0f b6 84 24 20 01 00 	movzbl 0x120(%rsp),%eax
  6f9a14:	00 
  6f9a15:	48 8d 15 58 e3 95 ff 	lea    -0x6a1ca8(%rip),%rdx        # 57d74 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0xcc>
  6f9a1c:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
  6f9a20:	48 01 d1             	add    %rdx,%rcx
  6f9a23:	ff e1                	jmp    *%rcx
  6f9a25:	83 f8 0a             	cmp    $0xa,%eax
  6f9a28:	0f 87 5a 02 00 00    	ja     6f9c88 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c78>
  6f9a2e:	b9 03 04 00 00       	mov    $0x403,%ecx
  6f9a33:	0f a3 c1             	bt     %eax,%ecx
  6f9a36:	0f 83 4c 02 00 00    	jae    6f9c88 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c78>
  6f9a3c:	3c 02                	cmp    $0x2,%al
  6f9a3e:	0f 92 c1             	setb   %cl
  6f9a41:	f6 d0                	not    %al
  6f9a43:	08 c8                	or     %cl,%al
  6f9a45:	a8 01                	test   $0x1,%al
  6f9a47:	0f 85 19 ff ff ff    	jne    6f9966 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2956>
  6f9a4d:	e9 36 02 00 00       	jmp    6f9c88 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c78>
  6f9a52:	c1 e8 11             	shr    $0x11,%eax
  6f9a55:	44 89 f9             	mov    %r15d,%ecx
  6f9a58:	c1 e9 0e             	shr    $0xe,%ecx
  6f9a5b:	81 e1 00 80 01 00    	and    $0x18000,%ecx
  6f9a61:	09 c1                	or     %eax,%ecx
  6f9a63:	48 39 8c 24 d0 03 00 	cmp    %rcx,0x3d0(%rsp)
  6f9a6a:	00 
  6f9a6b:	0f 86 5e 42 00 00    	jbe    6fdccf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cbf>
  6f9a71:	c1 e1 04             	shl    $0x4,%ecx
  6f9a74:	48 8b 84 24 f0 04 00 	mov    0x4f0(%rsp),%rax
  6f9a7b:	00 
  6f9a7c:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
  6f9a80:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
  6f9a85:	48 8b 54 08 08       	mov    0x8(%rax,%rcx,1),%rdx
  6f9a8a:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
  6f9a8f:	48 c7 04 08 00 00 00 	movq   $0x0,(%rax,%rcx,1)
  6f9a96:	00 
  6f9a97:	48 8b b4 24 68 02 00 	mov    0x268(%rsp),%rsi
  6f9a9e:	00 
  6f9a9f:	49 39 f6             	cmp    %rsi,%r14
  6f9aa2:	0f 83 ae 42 00 00    	jae    6fdd56 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d46>
  6f9aa8:	48 8b 84 24 60 02 00 	mov    0x260(%rsp),%rax
  6f9aaf:	00 
  6f9ab0:	42 3b 2c b0          	cmp    (%rax,%r14,4),%ebp
  6f9ab4:	75 41                	jne    6f9af7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2ae7>
  6f9ab6:	48 8b 84 24 a0 06 00 	mov    0x6a0(%rsp),%rax
  6f9abd:	00 
  6f9abe:	48 8d 15 d7 e2 95 ff 	lea    -0x6a1d29(%rip),%rdx        # 57d9c <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0xf4>
  6f9ac5:	48 63 0c 82          	movslq (%rdx,%rax,4),%rcx
  6f9ac9:	48 01 d1             	add    %rdx,%rcx
  6f9acc:	48 8d 05 4d e4 95 ff 	lea    -0x6a1bb3(%rip),%rax        # 57f20 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x278>
  6f9ad3:	ff e1                	jmp    *%rcx
  6f9ad5:	48 8b b4 24 b8 06 00 	mov    0x6b8(%rsp),%rsi
  6f9adc:	00 
  6f9add:	49 39 f5             	cmp    %rsi,%r13
  6f9ae0:	0f 83 46 42 00 00    	jae    6fdd2c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d1c>
  6f9ae6:	49 6b c5 58          	imul   $0x58,%r13,%rax
  6f9aea:	48 03 84 24 b0 06 00 	add    0x6b0(%rsp),%rax
  6f9af1:	00 
  6f9af2:	e9 81 00 00 00       	jmp    6f9b78 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2b68>
  6f9af7:	48 83 7c 24 38 00    	cmpq   $0x0,0x38(%rsp)
  6f9afd:	0f 84 85 01 00 00    	je     6f9c88 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c78>
  6f9b03:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  6f9b08:	48 8b 00             	mov    (%rax),%rax
  6f9b0b:	48 85 c0             	test   %rax,%rax
  6f9b0e:	74 07                	je     6f9b17 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2b07>
  6f9b10:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  6f9b15:	ff d0                	call   *%rax
  6f9b17:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  6f9b1c:	48 8b 70 08          	mov    0x8(%rax),%rsi
  6f9b20:	48 85 f6             	test   %rsi,%rsi
  6f9b23:	0f 84 5f 01 00 00    	je     6f9c88 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c78>
  6f9b29:	48 8b 50 10          	mov    0x10(%rax),%rdx
  6f9b2d:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  6f9b32:	ff 15 70 1b 39 00    	call   *0x391b70(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f9b38:	e9 4b 01 00 00       	jmp    6f9c88 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c78>
  6f9b3d:	48 8b b4 24 c0 06 00 	mov    0x6c0(%rsp),%rsi
  6f9b44:	00 
  6f9b45:	49 39 f5             	cmp    %rsi,%r13
  6f9b48:	0f 83 ea 41 00 00    	jae    6fdd38 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d28>
  6f9b4e:	48 8b b4 24 b0 06 00 	mov    0x6b0(%rsp),%rsi
  6f9b55:	00 
  6f9b56:	48 8b 84 24 b8 06 00 	mov    0x6b8(%rsp),%rax
  6f9b5d:	00 
  6f9b5e:	42 0f b6 04 28       	movzbl (%rax,%r13,1),%eax
  6f9b63:	48 39 c6             	cmp    %rax,%rsi
  6f9b66:	0f 86 d8 41 00 00    	jbe    6fdd44 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d34>
  6f9b6c:	48 6b c0 58          	imul   $0x58,%rax,%rax
  6f9b70:	48 03 84 24 a8 06 00 	add    0x6a8(%rsp),%rax
  6f9b77:	00 
  6f9b78:	48 8b 48 50          	mov    0x50(%rax),%rcx
  6f9b7c:	48 89 8c 24 d0 05 00 	mov    %rcx,0x5d0(%rsp)
  6f9b83:	00 
  6f9b84:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  6f9b88:	0f 29 84 24 c0 05 00 	movaps %xmm0,0x5c0(%rsp)
  6f9b8f:	00 
  6f9b90:	f3 0f 6f 00          	movdqu (%rax),%xmm0
  6f9b94:	f3 0f 6f 48 10       	movdqu 0x10(%rax),%xmm1
  6f9b99:	f3 0f 6f 50 20       	movdqu 0x20(%rax),%xmm2
  6f9b9e:	0f 10 58 30          	movups 0x30(%rax),%xmm3
  6f9ba2:	0f 29 9c 24 b0 05 00 	movaps %xmm3,0x5b0(%rsp)
  6f9ba9:	00 
  6f9baa:	66 0f 7f 94 24 a0 05 	movdqa %xmm2,0x5a0(%rsp)
  6f9bb1:	00 00 
  6f9bb3:	66 0f 7f 8c 24 90 05 	movdqa %xmm1,0x590(%rsp)
  6f9bba:	00 00 
  6f9bbc:	66 0f 7f 84 24 80 05 	movdqa %xmm0,0x580(%rsp)
  6f9bc3:	00 00 
  6f9bc5:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
  6f9bca:	eb 1e                	jmp    6f9bea <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2bda>
  6f9bcc:	48 8b b4 24 a8 06 00 	mov    0x6a8(%rsp),%rsi
  6f9bd3:	00 
  6f9bd4:	48 8d bc 24 80 05 00 	lea    0x580(%rsp),%rdi
  6f9bdb:	00 
  6f9bdc:	4c 89 ea             	mov    %r13,%rdx
  6f9bdf:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
  6f9be4:	ff 15 b6 1b 39 00    	call   *0x391bb6(%rip)        # a8b7a0 <_DYNAMIC+0x348>
  6f9bea:	48 8d bc 24 60 03 00 	lea    0x360(%rsp),%rdi
  6f9bf1:	00 
  6f9bf2:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
  6f9bf9:	00 
  6f9bfa:	4c 89 ea             	mov    %r13,%rdx
  6f9bfd:	ff 15 45 1f 39 00    	call   *0x391f45(%rip)        # a8bb48 <_DYNAMIC+0x6f0>
  6f9c03:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6f9c0a:	00 
  6f9c0b:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
  6f9c12:	00 
  6f9c13:	4c 89 f2             	mov    %r14,%rdx
  6f9c16:	ff 15 34 1f 39 00    	call   *0x391f34(%rip)        # a8bb50 <_DYNAMIC+0x6f8>
  6f9c1c:	48 8b 84 24 a0 01 00 	mov    0x1a0(%rsp),%rax
  6f9c23:	00 
  6f9c24:	48 3b 84 24 60 03 00 	cmp    0x360(%rsp),%rax
  6f9c2b:	00 
  6f9c2c:	75 12                	jne    6f9c40 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c30>
  6f9c2e:	48 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%rax
  6f9c35:	00 
  6f9c36:	48 3b 84 24 68 03 00 	cmp    0x368(%rsp),%rax
  6f9c3d:	00 
  6f9c3e:	74 0b                	je     6f9c4b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c3b>
  6f9c40:	48 8b 04 24          	mov    (%rsp),%rax
  6f9c44:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6f9c4b:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
  6f9c52:	00 
  6f9c53:	e9 4f 01 00 00       	jmp    6f9da7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d97>
  6f9c58:	b1 04                	mov    $0x4,%cl
  6f9c5a:	eb 1a                	jmp    6f9c76 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c66>
  6f9c5c:	b1 02                	mov    $0x2,%cl
  6f9c5e:	eb 16                	jmp    6f9c76 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c66>
  6f9c60:	b1 03                	mov    $0x3,%cl
  6f9c62:	eb 12                	jmp    6f9c76 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c66>
  6f9c64:	b1 07                	mov    $0x7,%cl
  6f9c66:	eb 0e                	jmp    6f9c76 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c66>
  6f9c68:	31 c9                	xor    %ecx,%ecx
  6f9c6a:	eb 0a                	jmp    6f9c76 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c66>
  6f9c6c:	b1 01                	mov    $0x1,%cl
  6f9c6e:	eb 06                	jmp    6f9c76 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c66>
  6f9c70:	b1 05                	mov    $0x5,%cl
  6f9c72:	eb 02                	jmp    6f9c76 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c66>
  6f9c74:	b1 06                	mov    $0x6,%cl
  6f9c76:	2c 02                	sub    $0x2,%al
  6f9c78:	0f 93 c2             	setae  %dl
  6f9c7b:	38 c8                	cmp    %cl,%al
  6f9c7d:	0f 94 c0             	sete   %al
  6f9c80:	84 c2                	test   %al,%dl
  6f9c82:	0f 85 de fc ff ff    	jne    6f9966 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2956>
  6f9c88:	48 8d 8c 24 98 00 00 	lea    0x98(%rsp),%rcx
  6f9c8f:	00 
  6f9c90:	48 8b 41 68          	mov    0x68(%rcx),%rax
  6f9c94:	48 89 84 24 d0 05 00 	mov    %rax,0x5d0(%rsp)
  6f9c9b:	00 
  6f9c9c:	0f 10 41 58          	movups 0x58(%rcx),%xmm0
  6f9ca0:	0f 29 84 24 c0 05 00 	movaps %xmm0,0x5c0(%rsp)
  6f9ca7:	00 
  6f9ca8:	f3 0f 6f 41 18       	movdqu 0x18(%rcx),%xmm0
  6f9cad:	f3 0f 6f 49 28       	movdqu 0x28(%rcx),%xmm1
  6f9cb2:	f3 0f 6f 51 38       	movdqu 0x38(%rcx),%xmm2
  6f9cb7:	0f 10 59 48          	movups 0x48(%rcx),%xmm3
  6f9cbb:	0f 29 9c 24 b0 05 00 	movaps %xmm3,0x5b0(%rsp)
  6f9cc2:	00 
  6f9cc3:	66 0f 7f 94 24 a0 05 	movdqa %xmm2,0x5a0(%rsp)
  6f9cca:	00 00 
  6f9ccc:	66 0f 7f 8c 24 90 05 	movdqa %xmm1,0x590(%rsp)
  6f9cd3:	00 00 
  6f9cd5:	66 0f 7f 84 24 80 05 	movdqa %xmm0,0x580(%rsp)
  6f9cdc:	00 00 
  6f9cde:	48 8b 0c 24          	mov    (%rsp),%rcx
  6f9ce2:	4c 8b a1 10 06 00 00 	mov    0x610(%rcx),%r12
  6f9ce9:	49 8d 44 24 01       	lea    0x1(%r12),%rax
  6f9cee:	48 89 81 10 06 00 00 	mov    %rax,0x610(%rcx)
  6f9cf5:	31 db                	xor    %ebx,%ebx
  6f9cf7:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  6f9cfc:	4c 89 e6             	mov    %r12,%rsi
  6f9cff:	e8 5c f8 00 00       	call   709560 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6f9d04:	4d 85 e4             	test   %r12,%r12
  6f9d07:	0f 84 16 3b 00 00    	je     6fd823 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6813>
  6f9d0d:	0f b6 84 24 20 01 00 	movzbl 0x120(%rsp),%eax
  6f9d14:	00 
  6f9d15:	8d 48 fe             	lea    -0x2(%rax),%ecx
  6f9d18:	83 f8 02             	cmp    $0x2,%eax
  6f9d1b:	0f b6 c9             	movzbl %cl,%ecx
  6f9d1e:	ba 08 00 00 00       	mov    $0x8,%edx
  6f9d23:	0f 42 ca             	cmovb  %edx,%ecx
  6f9d26:	44 0f b6 f9          	movzbl %cl,%r15d
  6f9d2a:	48 8d 15 7b e0 95 ff 	lea    -0x6a1f85(%rip),%rdx        # 57dac <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x104>
  6f9d31:	4a 63 0c ba          	movslq (%rdx,%r15,4),%rcx
  6f9d35:	48 01 d1             	add    %rdx,%rcx
  6f9d38:	ff e1                	jmp    *%rcx
  6f9d3a:	41 bf 01 00 00 00    	mov    $0x1,%r15d
  6f9d40:	eb 39                	jmp    6f9d7b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d6b>
  6f9d42:	41 bf 04 00 00 00    	mov    $0x4,%r15d
  6f9d48:	eb 31                	jmp    6f9d7b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d6b>
  6f9d4a:	41 bf 02 00 00 00    	mov    $0x2,%r15d
  6f9d50:	eb 29                	jmp    6f9d7b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d6b>
  6f9d52:	41 bf 03 00 00 00    	mov    $0x3,%r15d
  6f9d58:	eb 21                	jmp    6f9d7b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d6b>
  6f9d5a:	41 bf 07 00 00 00    	mov    $0x7,%r15d
  6f9d60:	eb 19                	jmp    6f9d7b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d6b>
  6f9d62:	41 bf 05 00 00 00    	mov    $0x5,%r15d
  6f9d68:	eb 11                	jmp    6f9d7b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d6b>
  6f9d6a:	41 bf 06 00 00 00    	mov    $0x6,%r15d
  6f9d70:	eb 09                	jmp    6f9d7b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d6b>
  6f9d72:	83 e0 01             	and    $0x1,%eax
  6f9d75:	83 c8 08             	or     $0x8,%eax
  6f9d78:	41 89 c7             	mov    %eax,%r15d
  6f9d7b:	48 8b b4 24 68 02 00 	mov    0x268(%rsp),%rsi
  6f9d82:	00 
  6f9d83:	49 39 f6             	cmp    %rsi,%r14
  6f9d86:	0f 83 ea 3c 00 00    	jae    6fda76 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a66>
  6f9d8c:	48 8b 84 24 60 02 00 	mov    0x260(%rsp),%rax
  6f9d93:	00 
  6f9d94:	42 8b 2c b0          	mov    (%rax,%r14,4),%ebp
  6f9d98:	b0 01                	mov    $0x1,%al
  6f9d9a:	89 44 24 10          	mov    %eax,0x10(%rsp)
  6f9d9e:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
  6f9da5:	00 00 
  6f9da7:	44 89 fb             	mov    %r15d,%ebx
  6f9daa:	83 e3 0f             	and    $0xf,%ebx
  6f9dad:	83 fb 09             	cmp    $0x9,%ebx
  6f9db0:	0f 87 08 3b 00 00    	ja     6fd8be <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x68ae>
  6f9db6:	83 fb 06             	cmp    $0x6,%ebx
  6f9db9:	0f 84 82 00 00 00    	je     6f9e41 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2e31>
  6f9dbf:	44 89 f8             	mov    %r15d,%eax
  6f9dc2:	c1 e8 04             	shr    $0x4,%eax
  6f9dc5:	25 ff ff ff 01       	and    $0x1ffffff,%eax
  6f9dca:	74 75                	je     6f9e41 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2e31>
  6f9dcc:	48 8b 0c 24          	mov    (%rsp),%rcx
  6f9dd0:	48 8b b1 b8 02 00 00 	mov    0x2b8(%rcx),%rsi
  6f9dd7:	ff c8                	dec    %eax
  6f9dd9:	48 39 c6             	cmp    %rax,%rsi
  6f9ddc:	0f 86 30 3d 00 00    	jbe    6fdb12 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b02>
  6f9de2:	48 8b 89 b0 02 00 00 	mov    0x2b0(%rcx),%rcx
  6f9de9:	48 8d 04 80          	lea    (%rax,%rax,4),%rax
  6f9ded:	48 c1 e0 04          	shl    $0x4,%rax
  6f9df1:	0f 10 44 01 40       	movups 0x40(%rcx,%rax,1),%xmm0
  6f9df6:	0f 29 84 24 80 04 00 	movaps %xmm0,0x480(%rsp)
  6f9dfd:	00 
  6f9dfe:	f3 0f 6f 04 01       	movdqu (%rcx,%rax,1),%xmm0
  6f9e03:	f3 0f 6f 4c 01 10    	movdqu 0x10(%rcx,%rax,1),%xmm1
  6f9e09:	f3 0f 6f 54 01 20    	movdqu 0x20(%rcx,%rax,1),%xmm2
  6f9e0f:	0f 10 5c 01 30       	movups 0x30(%rcx,%rax,1),%xmm3
  6f9e14:	0f 29 9c 24 70 04 00 	movaps %xmm3,0x470(%rsp)
  6f9e1b:	00 
  6f9e1c:	66 0f 7f 94 24 60 04 	movdqa %xmm2,0x460(%rsp)
  6f9e23:	00 00 
  6f9e25:	66 0f 7f 8c 24 50 04 	movdqa %xmm1,0x450(%rsp)
  6f9e2c:	00 00 
  6f9e2e:	66 0f 7f 84 24 40 04 	movdqa %xmm0,0x440(%rsp)
  6f9e35:	00 00 
  6f9e37:	48 c7 04 01 fe ff ff 	movq   $0xfffffffffffffffe,(%rcx,%rax,1)
  6f9e3e:	ff 
  6f9e3f:	eb 0c                	jmp    6f9e4d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2e3d>
  6f9e41:	48 c7 84 24 40 04 00 	movq   $0xfffffffffffffffe,0x440(%rsp)
  6f9e48:	00 fe ff ff ff 
  6f9e4d:	44 89 ff             	mov    %r15d,%edi
  6f9e50:	ff 15 42 19 39 00    	call   *0x391942(%rip)        # a8b798 <_DYNAMIC+0x340>
  6f9e56:	b1 02                	mov    $0x2,%cl
  6f9e58:	80 fa 02             	cmp    $0x2,%dl
  6f9e5b:	74 34                	je     6f9e91 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2e81>
  6f9e5d:	48 8b 0c 24          	mov    (%rsp),%rcx
  6f9e61:	48 8b 89 f0 05 00 00 	mov    0x5f0(%rcx),%rcx
  6f9e68:	48 85 c9             	test   %rcx,%rcx
  6f9e6b:	0f 84 d9 39 00 00    	je     6fd84a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x683a>
  6f9e71:	89 c7                	mov    %eax,%edi
  6f9e73:	48 8b 71 10          	mov    0x10(%rcx),%rsi
  6f9e77:	48 39 fe             	cmp    %rdi,%rsi
  6f9e7a:	0f 86 ed 3c 00 00    	jbe    6fdb6d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b5d>
  6f9e80:	48 8b 41 08          	mov    0x8(%rcx),%rax
  6f9e84:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
  6f9e88:	48 8b 78 28          	mov    0x28(%rax),%rdi
  6f9e8c:	80 e2 01             	and    $0x1,%dl
  6f9e8f:	89 d1                	mov    %edx,%ecx
  6f9e91:	48 8b 84 24 b0 07 00 	mov    0x7b0(%rsp),%rax
  6f9e98:	00 
  6f9e99:	48 85 c0             	test   %rax,%rax
  6f9e9c:	0f 84 bd 00 00 00    	je     6f9f5f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f4f>
  6f9ea2:	48 8b 94 24 b8 07 00 	mov    0x7b8(%rsp),%rdx
  6f9ea9:	00 
  6f9eaa:	0f b7 b0 ba 00 00 00 	movzwl 0xba(%rax),%esi
  6f9eb1:	41 89 f1             	mov    %esi,%r9d
  6f9eb4:	41 c1 e1 03          	shl    $0x3,%r9d
  6f9eb8:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
  6f9ebf:	90                   	nop
  6f9ec0:	4d 85 c9             	test   %r9,%r9
  6f9ec3:	74 24                	je     6f9ee9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2ed9>
  6f9ec5:	4e 3b 74 c0 10       	cmp    0x10(%rax,%r8,8),%r14
  6f9eca:	41 0f 97 c2          	seta   %r10b
  6f9ece:	41 80 da 00          	sbb    $0x0,%r10b
  6f9ed2:	49 ff c0             	inc    %r8
  6f9ed5:	49 83 c1 f8          	add    $0xfffffffffffffff8,%r9
  6f9ed9:	41 80 fa 01          	cmp    $0x1,%r10b
  6f9edd:	74 e1                	je     6f9ec0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2eb0>
  6f9edf:	41 0f b6 f2          	movzbl %r10b,%esi
  6f9ee3:	85 f6                	test   %esi,%esi
  6f9ee5:	75 05                	jne    6f9eec <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2edc>
  6f9ee7:	eb 13                	jmp    6f9efc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2eec>
  6f9ee9:	49 89 f0             	mov    %rsi,%r8
  6f9eec:	48 83 ea 01          	sub    $0x1,%rdx
  6f9ef0:	72 6d                	jb     6f9f5f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f4f>
  6f9ef2:	4a 8b 84 c0 c0 00 00 	mov    0xc0(%rax,%r8,8),%rax
  6f9ef9:	00 
  6f9efa:	eb ae                	jmp    6f9eaa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2e9a>
  6f9efc:	46 8b 4c c0 60       	mov    0x60(%rax,%r8,8),%r9d
  6f9f01:	48 8b b4 24 a0 04 00 	mov    0x4a0(%rsp),%rsi
  6f9f08:	00 
  6f9f09:	4c 89 8c 24 78 01 00 	mov    %r9,0x178(%rsp)
  6f9f10:	00 
  6f9f11:	4c 39 ce             	cmp    %r9,%rsi
  6f9f14:	0f 86 de 3b 00 00    	jbe    6fdaf8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6ae8>
  6f9f1a:	42 0f b6 44 c0 64    	movzbl 0x64(%rax,%r8,8),%eax
  6f9f20:	88 84 24 18 02 00 00 	mov    %al,0x218(%rsp)
  6f9f27:	c7 84 24 20 02 00 00 	movl   $0x0,0x220(%rsp)
  6f9f2e:	00 00 00 00 
  6f9f32:	80 f9 02             	cmp    $0x2,%cl
  6f9f35:	74 46                	je     6f9f7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f6d>
  6f9f37:	48 8b 84 24 98 04 00 	mov    0x498(%rsp),%rax
  6f9f3e:	00 
  6f9f3f:	48 8b 94 24 78 01 00 	mov    0x178(%rsp),%rdx
  6f9f46:	00 
  6f9f47:	48 8b 04 d0          	mov    (%rax,%rdx,8),%rax
  6f9f4b:	48 3b 78 28          	cmp    0x28(%rax),%rdi
  6f9f4f:	75 2c                	jne    6f9f7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f6d>
  6f9f51:	32 8c 24 18 02 00 00 	xor    0x218(%rsp),%cl
  6f9f58:	f6 c1 01             	test   $0x1,%cl
  6f9f5b:	74 3e                	je     6f9f9b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f8b>
  6f9f5d:	eb 1e                	jmp    6f9f7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f6d>
  6f9f5f:	c6 84 24 18 02 00 00 	movb   $0x2,0x218(%rsp)
  6f9f66:	02 
  6f9f67:	b0 01                	mov    $0x1,%al
  6f9f69:	89 84 24 20 02 00 00 	mov    %eax,0x220(%rsp)
  6f9f70:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
  6f9f77:	00 
  6f9f78:	80 f9 02             	cmp    $0x2,%cl
  6f9f7b:	74 1e                	je     6f9f9b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f8b>
  6f9f7d:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  6f9f82:	4c 89 e6             	mov    %r12,%rsi
  6f9f85:	e8 d6 f5 00 00       	call   709560 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6f9f8a:	48 8b 04 24          	mov    (%rsp),%rax
  6f9f8e:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6f9f95:	b0 01                	mov    $0x1,%al
  6f9f97:	89 44 24 10          	mov    %eax,0x10(%rsp)
  6f9f9b:	83 fb 09             	cmp    $0x9,%ebx
  6f9f9e:	0f 87 38 39 00 00    	ja     6fd8dc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x68cc>
  6f9fa4:	89 d8                	mov    %ebx,%eax
  6f9fa6:	48 8d 0d 23 de 95 ff 	lea    -0x6a21dd(%rip),%rcx        # 57dd0 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x128>
  6f9fad:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
  6f9fb1:	48 01 c8             	add    %rcx,%rax
  6f9fb4:	ff e0                	jmp    *%rax
  6f9fb6:	b0 02                	mov    $0x2,%al
  6f9fb8:	eb 21                	jmp    6f9fdb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fcb>
  6f9fba:	b0 06                	mov    $0x6,%al
  6f9fbc:	eb 1d                	jmp    6f9fdb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fcb>
  6f9fbe:	b0 01                	mov    $0x1,%al
  6f9fc0:	e9 8e 03 00 00       	jmp    6fa353 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3343>
  6f9fc5:	b0 04                	mov    $0x4,%al
  6f9fc7:	eb 12                	jmp    6f9fdb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fcb>
  6f9fc9:	b0 05                	mov    $0x5,%al
  6f9fcb:	eb 0e                	jmp    6f9fdb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fcb>
  6f9fcd:	b0 09                	mov    $0x9,%al
  6f9fcf:	eb 0a                	jmp    6f9fdb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fcb>
  6f9fd1:	b0 03                	mov    $0x3,%al
  6f9fd3:	eb 06                	jmp    6f9fdb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fcb>
  6f9fd5:	b0 07                	mov    $0x7,%al
  6f9fd7:	eb 02                	jmp    6f9fdb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fcb>
  6f9fd9:	b0 08                	mov    $0x8,%al
  6f9fdb:	0f b6 8c 24 20 01 00 	movzbl 0x120(%rsp),%ecx
  6f9fe2:	00 
  6f9fe3:	8d 50 fe             	lea    -0x2(%rax),%edx
  6f9fe6:	89 ce                	mov    %ecx,%esi
  6f9fe8:	40 80 ee 02          	sub    $0x2,%sil
  6f9fec:	40 0f b6 f6          	movzbl %sil,%esi
  6f9ff0:	bf 08 00 00 00       	mov    $0x8,%edi
  6f9ff5:	0f 42 f7             	cmovb  %edi,%esi
  6f9ff8:	40 38 f2             	cmp    %sil,%dl
  6f9ffb:	75 0f                	jne    6fa00c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2ffc>
  6f9ffd:	80 fa 08             	cmp    $0x8,%dl
  6fa000:	0f 95 c2             	setne  %dl
  6fa003:	38 c8                	cmp    %cl,%al
  6fa005:	0f 94 c0             	sete   %al
  6fa008:	08 d0                	or     %dl,%al
  6fa00a:	75 11                	jne    6fa01d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x300d>
  6fa00c:	48 8b 04 24          	mov    (%rsp),%rax
  6fa010:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6fa017:	b0 01                	mov    $0x1,%al
  6fa019:	89 44 24 10          	mov    %eax,0x10(%rsp)
  6fa01d:	48 83 bc 24 90 00 00 	cmpq   $0xffffffffffffffff,0x90(%rsp)
  6fa024:	00 ff 
  6fa026:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
  6fa02b:	4c 89 bc 24 50 01 00 	mov    %r15,0x150(%rsp)
  6fa032:	00 
  6fa033:	89 ac 24 e8 03 00 00 	mov    %ebp,0x3e8(%rsp)
  6fa03a:	74 62                	je     6fa09e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x308e>
  6fa03c:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6fa043:	00 
  6fa044:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6fa04b:	00 
  6fa04c:	ff 15 06 1b 39 00    	call   *0x391b06(%rip)        # a8bb58 <_DYNAMIC+0x700>
  6fa052:	48 8b 8c 24 a0 01 00 	mov    0x1a0(%rsp),%rcx
  6fa059:	00 
  6fa05a:	48 8b 04 24          	mov    (%rsp),%rax
  6fa05e:	48 ff 80 f0 06 00 00 	incq   0x6f0(%rax)
  6fa065:	48 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%rax
  6fa06c:	00 
  6fa06d:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
  6fa074:	00 
  6fa075:	4c 8b ac 24 b0 01 00 	mov    0x1b0(%rsp),%r13
  6fa07c:	00 
  6fa07d:	48 8b 9c 24 40 04 00 	mov    0x440(%rsp),%rbx
  6fa084:	00 
  6fa085:	48 83 fb fe          	cmp    $0xfffffffffffffffe,%rbx
  6fa089:	48 89 8c 24 80 01 00 	mov    %rcx,0x180(%rsp)
  6fa090:	00 
  6fa091:	75 32                	jne    6fa0c5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x30b5>
  6fa093:	48 83 f9 fe          	cmp    $0xfffffffffffffffe,%rcx
  6fa097:	74 1b                	je     6fa0b4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x30a4>
  6fa099:	e9 80 00 00 00       	jmp    6fa11e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x310e>
  6fa09e:	48 8b 04 24          	mov    (%rsp),%rax
  6fa0a2:	48 ff 80 f0 06 00 00 	incq   0x6f0(%rax)
  6fa0a9:	48 83 bc 24 40 04 00 	cmpq   $0xfffffffffffffffe,0x440(%rsp)
  6fa0b0:	00 fe 
  6fa0b2:	75 1b                	jne    6fa0cf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x30bf>
  6fa0b4:	48 c7 84 24 80 01 00 	movq   $0xfffffffffffffffe,0x180(%rsp)
  6fa0bb:	00 fe ff ff ff 
  6fa0c0:	e9 b6 03 00 00       	jmp    6fa47b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x346b>
  6fa0c5:	48 83 f9 fe          	cmp    $0xfffffffffffffffe,%rcx
  6fa0c9:	75 23                	jne    6fa0ee <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x30de>
  6fa0cb:	48 8b 04 24          	mov    (%rsp),%rax
  6fa0cf:	c6 80 48 07 00 00 01 	movb   $0x1,0x748(%rax)
  6fa0d6:	48 c7 c3 fe ff ff ff 	mov    $0xfffffffffffffffe,%rbx
  6fa0dd:	48 c7 84 24 80 01 00 	movq   $0xfffffffffffffffe,0x180(%rsp)
  6fa0e4:	00 fe ff ff ff 
  6fa0e9:	e9 0e 03 00 00       	jmp    6fa3fc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33ec>
  6fa0ee:	48 8b bc 24 80 04 00 	mov    0x480(%rsp),%rdi
  6fa0f5:	00 
  6fa0f6:	48 8b 07             	mov    (%rdi),%rax
  6fa0f9:	48 d1 e8             	shr    $1,%rax
  6fa0fc:	4c 39 e8             	cmp    %r13,%rax
  6fa0ff:	75 1d                	jne    6fa11e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x310e>
  6fa101:	48 83 c7 10          	add    $0x10,%rdi
  6fa105:	48 8b b4 24 d8 03 00 	mov    0x3d8(%rsp),%rsi
  6fa10c:	00 
  6fa10d:	4c 89 ea             	mov    %r13,%rdx
  6fa110:	ff 15 72 17 39 00    	call   *0x391772(%rip)        # a8b888 <bcmp@GLIBC_2.2.5>
  6fa116:	85 c0                	test   %eax,%eax
  6fa118:	0f 84 5d 03 00 00    	je     6fa47b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x346b>
  6fa11e:	48 83 fb fe          	cmp    $0xfffffffffffffffe,%rbx
  6fa122:	0f 94 c0             	sete   %al
  6fa125:	48 8b 0c 24          	mov    (%rsp),%rcx
  6fa129:	08 81 48 07 00 00    	or     %al,0x748(%rcx)
  6fa12f:	48 8b b4 24 50 02 00 	mov    0x250(%rsp),%rsi
  6fa136:	00 
  6fa137:	49 39 f6             	cmp    %rsi,%r14
  6fa13a:	0f 83 66 3a 00 00    	jae    6fdba6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b96>
  6fa140:	4c 8b bc 24 48 02 00 	mov    0x248(%rsp),%r15
  6fa147:	00 
  6fa148:	4b 8b 04 f7          	mov    (%r15,%r14,8),%rax
  6fa14c:	48 85 c0             	test   %rax,%rax
  6fa14f:	74 6e                	je     6fa1bf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x31af>
  6fa151:	48 8b 8c 24 28 04 00 	mov    0x428(%rsp),%rcx
  6fa158:	00 
  6fa159:	48 85 c9             	test   %rcx,%rcx
  6fa15c:	74 61                	je     6fa1bf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x31af>
  6fa15e:	48 8b 94 24 30 04 00 	mov    0x430(%rsp),%rdx
  6fa165:	00 
  6fa166:	0f b7 b9 ba 00 00 00 	movzwl 0xba(%rcx),%edi
  6fa16d:	41 89 f8             	mov    %edi,%r8d
  6fa170:	41 c1 e0 03          	shl    $0x3,%r8d
  6fa174:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
  6fa17b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6fa180:	4d 85 c0             	test   %r8,%r8
  6fa183:	74 27                	je     6fa1ac <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x319c>
  6fa185:	48 3b 44 f1 10       	cmp    0x10(%rcx,%rsi,8),%rax
  6fa18a:	41 0f 97 c1          	seta   %r9b
  6fa18e:	41 80 d9 00          	sbb    $0x0,%r9b
  6fa192:	48 ff c6             	inc    %rsi
  6fa195:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  6fa199:	41 80 f9 01          	cmp    $0x1,%r9b
  6fa19d:	74 e1                	je     6fa180 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3170>
  6fa19f:	41 0f b6 f9          	movzbl %r9b,%edi
  6fa1a3:	85 ff                	test   %edi,%edi
  6fa1a5:	75 08                	jne    6fa1af <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x319f>
  6fa1a7:	e9 54 01 00 00       	jmp    6fa300 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x32f0>
  6fa1ac:	48 89 fe             	mov    %rdi,%rsi
  6fa1af:	48 83 ea 01          	sub    $0x1,%rdx
  6fa1b3:	72 0a                	jb     6fa1bf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x31af>
  6fa1b5:	48 8b 8c f1 c0 00 00 	mov    0xc0(%rcx,%rsi,8),%rcx
  6fa1bc:	00 
  6fa1bd:	eb a7                	jmp    6fa166 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3156>
  6fa1bf:	48 8b 04 24          	mov    (%rsp),%rax
  6fa1c3:	f3 0f 6f 80 f8 06 00 	movdqu 0x6f8(%rax),%xmm0
  6fa1ca:	00 
  6fa1cb:	66 49 0f 6e cd       	movq   %r13,%xmm1
  6fa1d0:	66 0f 6f 15 68 cd 95 	movdqa -0x6a3298(%rip),%xmm2        # 56f40 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x920>
  6fa1d7:	ff 
  6fa1d8:	66 0f 6c d1          	punpcklqdq %xmm1,%xmm2
  6fa1dc:	66 0f d4 d0          	paddq  %xmm0,%xmm2
  6fa1e0:	f3 0f 7f 90 f8 06 00 	movdqu %xmm2,0x6f8(%rax)
  6fa1e7:	00 
  6fa1e8:	48 8d 1d 11 d5 95 ff 	lea    -0x6a2aef(%rip),%rbx        # 57700 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x10e0>
  6fa1ef:	4d 85 ed             	test   %r13,%r13
  6fa1f2:	74 4a                	je     6fa23e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x322e>
  6fa1f4:	41 b4 01             	mov    $0x1,%r12b
  6fa1f7:	40 b5 01             	mov    $0x1,%bpl
  6fa1fa:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6fa201:	00 
  6fa202:	4c 89 ee             	mov    %r13,%rsi
  6fa205:	31 d2                	xor    %edx,%edx
  6fa207:	31 c9                	xor    %ecx,%ecx
  6fa209:	ff 15 81 16 39 00    	call   *0x391681(%rip)        # a8b890 <_DYNAMIC+0x438>
  6fa20f:	48 8b bc 24 a0 01 00 	mov    0x1a0(%rsp),%rdi
  6fa216:	00 
  6fa217:	48 83 ff ff          	cmp    $0xffffffffffffffff,%rdi
  6fa21b:	0f 85 28 3a 00 00    	jne    6fdc49 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c39>
  6fa221:	48 8b 9c 24 a8 01 00 	mov    0x1a8(%rsp),%rbx
  6fa228:	00 
  6fa229:	48 8d 7b 10          	lea    0x10(%rbx),%rdi
  6fa22d:	48 8b b4 24 d8 03 00 	mov    0x3d8(%rsp),%rsi
  6fa234:	00 
  6fa235:	4c 89 ea             	mov    %r13,%rdx
  6fa238:	ff 15 7a 14 39 00    	call   *0x39147a(%rip)        # a8b6b8 <memcpy@GLIBC_2.14>
  6fa23e:	4b 8b 04 f7          	mov    (%r15,%r14,8),%rax
  6fa242:	48 85 c0             	test   %rax,%rax
  6fa245:	48 89 9c 24 f8 04 00 	mov    %rbx,0x4f8(%rsp)
  6fa24c:	00 
  6fa24d:	0f 84 8b 01 00 00    	je     6fa3de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33ce>
  6fa253:	f6 03 01             	testb  $0x1,(%rbx)
  6fa256:	75 2f                	jne    6fa287 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3277>
  6fa258:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
  6fa25c:	f6 c1 01             	test   $0x1,%cl
  6fa25f:	75 26                	jne    6fa287 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3277>
  6fa261:	b9 02 00 00 00       	mov    $0x2,%ecx
  6fa266:	f0 48 0f c1 4b 08    	lock xadd %rcx,0x8(%rbx)
  6fa26c:	48 ba 01 00 00 00 00 	movabs $0x8000000000000001,%rdx
  6fa273:	00 00 80 
  6fa276:	48 21 d1             	and    %rdx,%rcx
  6fa279:	48 ff ca             	dec    %rdx
  6fa27c:	48 39 d1             	cmp    %rdx,%rcx
  6fa27f:	75 06                	jne    6fa287 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3277>
  6fa281:	f0 48 83 4b 08 01    	lock orq $0x1,0x8(%rbx)
  6fa287:	48 8b 8c 24 28 04 00 	mov    0x428(%rsp),%rcx
  6fa28e:	00 
  6fa28f:	48 85 c9             	test   %rcx,%rcx
  6fa292:	0f 84 f8 00 00 00    	je     6fa390 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3380>
  6fa298:	48 8b 94 24 30 04 00 	mov    0x430(%rsp),%rdx
  6fa29f:	00 
  6fa2a0:	0f b7 b9 ba 00 00 00 	movzwl 0xba(%rcx),%edi
  6fa2a7:	41 89 f8             	mov    %edi,%r8d
  6fa2aa:	41 c1 e0 03          	shl    $0x3,%r8d
  6fa2ae:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
  6fa2b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6fa2bc:	00 00 00 00 
  6fa2c0:	4d 85 c0             	test   %r8,%r8
  6fa2c3:	74 24                	je     6fa2e9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x32d9>
  6fa2c5:	48 3b 44 f1 10       	cmp    0x10(%rcx,%rsi,8),%rax
  6fa2ca:	41 0f 97 c1          	seta   %r9b
  6fa2ce:	41 80 d9 00          	sbb    $0x0,%r9b
  6fa2d2:	48 ff c6             	inc    %rsi
  6fa2d5:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  6fa2d9:	41 80 f9 01          	cmp    $0x1,%r9b
  6fa2dd:	74 e1                	je     6fa2c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x32b0>
  6fa2df:	41 0f b6 f9          	movzbl %r9b,%edi
  6fa2e3:	85 ff                	test   %edi,%edi
  6fa2e5:	75 05                	jne    6fa2ec <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x32dc>
  6fa2e7:	eb 79                	jmp    6fa362 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3352>
  6fa2e9:	48 89 fe             	mov    %rdi,%rsi
  6fa2ec:	48 83 ea 01          	sub    $0x1,%rdx
  6fa2f0:	0f 82 9c 00 00 00    	jb     6fa392 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3382>
  6fa2f6:	48 8b 8c f1 c0 00 00 	mov    0xc0(%rcx,%rsi,8),%rcx
  6fa2fd:	00 
  6fa2fe:	eb a0                	jmp    6fa2a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3290>
  6fa300:	48 8b 54 f1 60       	mov    0x60(%rcx,%rsi,8),%rdx
  6fa305:	f6 02 01             	testb  $0x1,(%rdx)
  6fa308:	48 89 94 24 f8 04 00 	mov    %rdx,0x4f8(%rsp)
  6fa30f:	00 
  6fa310:	0f 85 c8 00 00 00    	jne    6fa3de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33ce>
  6fa316:	48 8b 42 08          	mov    0x8(%rdx),%rax
  6fa31a:	a8 01                	test   $0x1,%al
  6fa31c:	0f 85 bc 00 00 00    	jne    6fa3de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33ce>
  6fa322:	b8 02 00 00 00       	mov    $0x2,%eax
  6fa327:	f0 48 0f c1 42 08    	lock xadd %rax,0x8(%rdx)
  6fa32d:	48 b9 01 00 00 00 00 	movabs $0x8000000000000001,%rcx
  6fa334:	00 00 80 
  6fa337:	48 21 c8             	and    %rcx,%rax
  6fa33a:	48 ff c9             	dec    %rcx
  6fa33d:	48 39 c8             	cmp    %rcx,%rax
  6fa340:	0f 85 98 00 00 00    	jne    6fa3de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33ce>
  6fa346:	f0 48 83 4a 08 01    	lock orq $0x1,0x8(%rdx)
  6fa34c:	e9 8d 00 00 00       	jmp    6fa3de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33ce>
  6fa351:	31 c0                	xor    %eax,%eax
  6fa353:	b2 08                	mov    $0x8,%dl
  6fa355:	0f b6 8c 24 20 01 00 	movzbl 0x120(%rsp),%ecx
  6fa35c:	00 
  6fa35d:	e9 84 fc ff ff       	jmp    6f9fe6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fd6>
  6fa362:	48 8b 7c f1 60       	mov    0x60(%rcx,%rsi,8),%rdi
  6fa367:	48 89 5c f1 60       	mov    %rbx,0x60(%rcx,%rsi,8)
  6fa36c:	f6 07 01             	testb  $0x1,(%rdi)
  6fa36f:	75 6d                	jne    6fa3de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33ce>
  6fa371:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fa375:	a8 01                	test   $0x1,%al
  6fa377:	75 65                	jne    6fa3de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33ce>
  6fa379:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6fa37d:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6fa382:	75 5a                	jne    6fa3de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33ce>
  6fa384:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fa388:	ff 15 62 13 39 00    	call   *0x391362(%rip)        # a8b6f0 <_DYNAMIC+0x298>
  6fa38e:	eb 4e                	jmp    6fa3de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33ce>
  6fa390:	31 c9                	xor    %ecx,%ecx
  6fa392:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
  6fa399:	00 
  6fa39a:	48 8d 84 24 28 04 00 	lea    0x428(%rsp),%rax
  6fa3a1:	00 
  6fa3a2:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
  6fa3a9:	00 
  6fa3aa:	48 89 8c 24 b0 01 00 	mov    %rcx,0x1b0(%rsp)
  6fa3b1:	00 
  6fa3b2:	48 c7 84 24 b8 01 00 	movq   $0x0,0x1b8(%rsp)
  6fa3b9:	00 00 00 00 00 
  6fa3be:	48 89 b4 24 c0 01 00 	mov    %rsi,0x1c0(%rsp)
  6fa3c5:	00 
  6fa3c6:	48 8d bc 24 60 03 00 	lea    0x360(%rsp),%rdi
  6fa3cd:	00 
  6fa3ce:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
  6fa3d5:	00 
  6fa3d6:	48 89 da             	mov    %rbx,%rdx
  6fa3d9:	e8 32 73 01 00       	call   711710 <<alloc::collections::btree::map::entry::VacantEntry<gpui::source::FieldId, gpui::shared_text::SharedText>>::insert_entry>
  6fa3de:	4b 8b 04 f7          	mov    (%r15,%r14,8),%rax
  6fa3e2:	48 89 84 24 68 06 00 	mov    %rax,0x668(%rsp)
  6fa3e9:	00 
  6fa3ea:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
  6fa3f1:	48 83 bc 24 40 04 00 	cmpq   $0xfffffffffffffffe,0x440(%rsp)
  6fa3f8:	00 fe 
  6fa3fa:	74 31                	je     6fa42d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x341d>
  6fa3fc:	48 8b bc 24 80 04 00 	mov    0x480(%rsp),%rdi
  6fa403:	00 
  6fa404:	f6 07 01             	testb  $0x1,(%rdi)
  6fa407:	75 17                	jne    6fa420 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3410>
  6fa409:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fa40d:	a8 01                	test   $0x1,%al
  6fa40f:	75 0f                	jne    6fa420 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3410>
  6fa411:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6fa415:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6fa41a:	0f 84 c8 0a 00 00    	je     6faee8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3ed8>
  6fa420:	48 8d bc 24 40 04 00 	lea    0x440(%rsp),%rdi
  6fa427:	00 
  6fa428:	e8 e3 81 fe ff       	call   6e2610 <core::ptr::drop_glue::<core::option::Option<gpui::runtime::Shaped>>>
  6fa42d:	48 89 9c 24 40 04 00 	mov    %rbx,0x440(%rsp)
  6fa434:	00 
  6fa435:	48 8b 84 24 f8 04 00 	mov    0x4f8(%rsp),%rax
  6fa43c:	00 
  6fa43d:	48 89 84 24 80 04 00 	mov    %rax,0x480(%rsp)
  6fa444:	00 
  6fa445:	48 8b 84 24 68 06 00 	mov    0x668(%rsp),%rax
  6fa44c:	00 
  6fa44d:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
  6fa454:	00 
  6fa455:	41 b4 01             	mov    $0x1,%r12b
  6fa458:	40 b5 01             	mov    $0x1,%bpl
  6fa45b:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  6fa460:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  6fa465:	e8 f6 f0 00 00       	call   709560 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6fa46a:	48 8b 04 24          	mov    (%rsp),%rax
  6fa46e:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6fa475:	b0 01                	mov    $0x1,%al
  6fa477:	89 44 24 10          	mov    %eax,0x10(%rsp)
  6fa47b:	48 8d 8c 24 98 00 00 	lea    0x98(%rsp),%rcx
  6fa482:	00 
  6fa483:	48 8b 41 68          	mov    0x68(%rcx),%rax
  6fa487:	48 89 84 24 b0 03 00 	mov    %rax,0x3b0(%rsp)
  6fa48e:	00 
  6fa48f:	0f 10 41 58          	movups 0x58(%rcx),%xmm0
  6fa493:	0f 29 84 24 a0 03 00 	movaps %xmm0,0x3a0(%rsp)
  6fa49a:	00 
  6fa49b:	f3 0f 6f 41 18       	movdqu 0x18(%rcx),%xmm0
  6fa4a0:	f3 0f 6f 49 28       	movdqu 0x28(%rcx),%xmm1
  6fa4a5:	f3 0f 6f 51 38       	movdqu 0x38(%rcx),%xmm2
  6fa4aa:	0f 10 59 48          	movups 0x48(%rcx),%xmm3
  6fa4ae:	0f 29 9c 24 90 03 00 	movaps %xmm3,0x390(%rsp)
  6fa4b5:	00 
  6fa4b6:	66 0f 7f 94 24 80 03 	movdqa %xmm2,0x380(%rsp)
  6fa4bd:	00 00 
  6fa4bf:	66 0f 7f 8c 24 70 03 	movdqa %xmm1,0x370(%rsp)
  6fa4c6:	00 00 
  6fa4c8:	66 0f 7f 84 24 60 03 	movdqa %xmm0,0x360(%rsp)
  6fa4cf:	00 00 
  6fa4d1:	48 8b 84 24 00 04 00 	mov    0x400(%rsp),%rax
  6fa4d8:	00 
  6fa4d9:	48 8b 18             	mov    (%rax),%rbx
  6fa4dc:	48 8d 84 24 f8 05 00 	lea    0x5f8(%rsp),%rax
  6fa4e3:	00 
  6fa4e4:	48 85 db             	test   %rbx,%rbx
  6fa4e7:	0f 84 fa 00 00 00    	je     6fa5e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x35d7>
  6fa4ed:	48 8b 04 24          	mov    (%rsp),%rax
  6fa4f1:	48 8b 80 30 06 00 00 	mov    0x630(%rax),%rax
  6fa4f8:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  6fa4fd:	0f b7 93 32 05 00 00 	movzwl 0x532(%rbx),%edx
  6fa504:	48 6b fa 70          	imul   $0x70,%rdx,%rdi
  6fa508:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
  6fa50f:	31 f6                	xor    %esi,%esi
  6fa511:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fa518:	0f 1f 84 00 00 00 00 
  6fa51f:	00 
  6fa520:	49 89 f8             	mov    %rdi,%r8
  6fa523:	49 01 f0             	add    %rsi,%r8
  6fa526:	74 27                	je     6fa54f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x353f>
  6fa528:	4c 3b 8c cb e0 04 00 	cmp    0x4e0(%rbx,%rcx,8),%r9
  6fa52f:	00 
  6fa530:	41 0f 97 c0          	seta   %r8b
  6fa534:	41 80 d8 00          	sbb    $0x0,%r8b
  6fa538:	48 83 c6 90          	add    $0xffffffffffffff90,%rsi
  6fa53c:	48 ff c1             	inc    %rcx
  6fa53f:	41 80 f8 01          	cmp    $0x1,%r8b
  6fa543:	74 db                	je     6fa520 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3510>
  6fa545:	41 0f b6 d0          	movzbl %r8b,%edx
  6fa549:	85 d2                	test   %edx,%edx
  6fa54b:	75 05                	jne    6fa552 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3542>
  6fa54d:	eb 17                	jmp    6fa566 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3556>
  6fa54f:	48 89 d1             	mov    %rdx,%rcx
  6fa552:	48 83 e8 01          	sub    $0x1,%rax
  6fa556:	0f 82 7f 09 00 00    	jb     6faedb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3ecb>
  6fa55c:	48 8b 9c cb 38 05 00 	mov    0x538(%rbx,%rcx,8),%rbx
  6fa563:	00 
  6fa564:	eb 97                	jmp    6fa4fd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x34ed>
  6fa566:	48 29 f3             	sub    %rsi,%rbx
  6fa569:	48 8d 53 e8          	lea    -0x18(%rbx),%rdx
  6fa56d:	48 8d 8c 24 98 00 00 	lea    0x98(%rsp),%rcx
  6fa574:	00 
  6fa575:	48 8b 41 68          	mov    0x68(%rcx),%rax
  6fa579:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
  6fa580:	00 
  6fa581:	0f 10 41 58          	movups 0x58(%rcx),%xmm0
  6fa585:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
  6fa58c:	00 
  6fa58d:	f3 0f 6f 41 18       	movdqu 0x18(%rcx),%xmm0
  6fa592:	f3 0f 6f 49 28       	movdqu 0x28(%rcx),%xmm1
  6fa597:	f3 0f 6f 51 38       	movdqu 0x38(%rcx),%xmm2
  6fa59c:	0f 10 59 48          	movups 0x48(%rcx),%xmm3
  6fa5a0:	0f 29 9c 24 d0 01 00 	movaps %xmm3,0x1d0(%rsp)
  6fa5a7:	00 
  6fa5a8:	66 0f 7f 94 24 c0 01 	movdqa %xmm2,0x1c0(%rsp)
  6fa5af:	00 00 
  6fa5b1:	66 0f 7f 8c 24 b0 01 	movdqa %xmm1,0x1b0(%rsp)
  6fa5b8:	00 00 
  6fa5ba:	66 0f 7f 84 24 a0 01 	movdqa %xmm0,0x1a0(%rsp)
  6fa5c1:	00 00 
  6fa5c3:	41 b4 01             	mov    $0x1,%r12b
  6fa5c6:	40 b5 01             	mov    $0x1,%bpl
  6fa5c9:	48 8d bc 24 f8 05 00 	lea    0x5f8(%rsp),%rdi
  6fa5d0:	00 
  6fa5d1:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
  6fa5d8:	00 
  6fa5d9:	31 c9                	xor    %ecx,%ecx
  6fa5db:	e8 d0 0c 02 00       	call   71b2b0 <gpui::property::apply_except::<gpui::style::Style>>
  6fa5e0:	48 83 c3 90          	add    $0xffffffffffffff90,%rbx
  6fa5e4:	48 89 d8             	mov    %rbx,%rax
  6fa5e7:	48 8b 8c 24 b0 03 00 	mov    0x3b0(%rsp),%rcx
  6fa5ee:	00 
  6fa5ef:	48 89 48 50          	mov    %rcx,0x50(%rax)
  6fa5f3:	0f 28 84 24 a0 03 00 	movaps 0x3a0(%rsp),%xmm0
  6fa5fa:	00 
  6fa5fb:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  6fa5ff:	66 0f 6f 84 24 60 03 	movdqa 0x360(%rsp),%xmm0
  6fa606:	00 00 
  6fa608:	66 0f 6f 8c 24 70 03 	movdqa 0x370(%rsp),%xmm1
  6fa60f:	00 00 
  6fa611:	66 0f 6f 94 24 80 03 	movdqa 0x380(%rsp),%xmm2
  6fa618:	00 00 
  6fa61a:	0f 28 9c 24 90 03 00 	movaps 0x390(%rsp),%xmm3
  6fa621:	00 
  6fa622:	0f 11 58 30          	movups %xmm3,0x30(%rax)
  6fa626:	f3 0f 7f 50 20       	movdqu %xmm2,0x20(%rax)
  6fa62b:	f3 0f 7f 48 10       	movdqu %xmm1,0x10(%rax)
  6fa630:	f3 0f 7f 00          	movdqu %xmm0,(%rax)
  6fa634:	8b ac 24 80 05 00 00 	mov    0x580(%rsp),%ebp
  6fa63b:	0f b6 9c 24 f8 05 00 	movzbl 0x5f8(%rsp),%ebx
  6fa642:	00 
  6fa643:	83 fd 01             	cmp    $0x1,%ebp
  6fa646:	75 22                	jne    6fa66a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x365a>
  6fa648:	8b 84 24 fc 05 00 00 	mov    0x5fc(%rsp),%eax
  6fa64f:	39 84 24 84 05 00 00 	cmp    %eax,0x584(%rsp)
  6fa656:	0f 94 c0             	sete   %al
  6fa659:	84 c3                	test   %al,%bl
  6fa65b:	4c 8b bc 24 50 01 00 	mov    0x150(%rsp),%r15
  6fa662:	00 
  6fa663:	75 16                	jne    6fa67b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x366b>
  6fa665:	e9 24 01 00 00       	jmp    6fa78e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x377e>
  6fa66a:	f6 c3 01             	test   $0x1,%bl
  6fa66d:	4c 8b bc 24 50 01 00 	mov    0x150(%rsp),%r15
  6fa674:	00 
  6fa675:	0f 85 13 01 00 00    	jne    6fa78e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x377e>
  6fa67b:	0f b6 84 24 00 06 00 	movzbl 0x600(%rsp),%eax
  6fa682:	00 
  6fa683:	83 bc 24 88 05 00 00 	cmpl   $0x1,0x588(%rsp)
  6fa68a:	01 
  6fa68b:	75 1a                	jne    6fa6a7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3697>
  6fa68d:	8b 8c 24 04 06 00 00 	mov    0x604(%rsp),%ecx
  6fa694:	39 8c 24 8c 05 00 00 	cmp    %ecx,0x58c(%rsp)
  6fa69b:	0f 94 c1             	sete   %cl
  6fa69e:	84 c8                	test   %cl,%al
  6fa6a0:	75 0d                	jne    6fa6af <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x369f>
  6fa6a2:	e9 e7 00 00 00       	jmp    6fa78e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x377e>
  6fa6a7:	a8 01                	test   $0x1,%al
  6fa6a9:	0f 85 df 00 00 00    	jne    6fa78e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x377e>
  6fa6af:	8b 84 24 90 05 00 00 	mov    0x590(%rsp),%eax
  6fa6b6:	3b 84 24 08 06 00 00 	cmp    0x608(%rsp),%eax
  6fa6bd:	0f 85 cb 00 00 00    	jne    6fa78e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x377e>
  6fa6c3:	8b 84 24 94 05 00 00 	mov    0x594(%rsp),%eax
  6fa6ca:	3b 84 24 0c 06 00 00 	cmp    0x60c(%rsp),%eax
  6fa6d1:	0f 85 b7 00 00 00    	jne    6fa78e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x377e>
  6fa6d7:	8b 84 24 98 05 00 00 	mov    0x598(%rsp),%eax
  6fa6de:	3b 84 24 10 06 00 00 	cmp    0x610(%rsp),%eax
  6fa6e5:	0f 85 a3 00 00 00    	jne    6fa78e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x377e>
  6fa6eb:	0f b6 84 24 d4 05 00 	movzbl 0x5d4(%rsp),%eax
  6fa6f2:	00 
  6fa6f3:	3a 84 24 4c 06 00 00 	cmp    0x64c(%rsp),%al
  6fa6fa:	0f 85 8e 00 00 00    	jne    6fa78e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x377e>
  6fa700:	0f b6 84 24 d6 05 00 	movzbl 0x5d6(%rsp),%eax
  6fa707:	00 
  6fa708:	3a 84 24 4e 06 00 00 	cmp    0x64e(%rsp),%al
  6fa70f:	75 7d                	jne    6fa78e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x377e>
  6fa711:	0f b6 84 24 d7 05 00 	movzbl 0x5d7(%rsp),%eax
  6fa718:	00 
  6fa719:	3a 84 24 4f 06 00 00 	cmp    0x64f(%rsp),%al
  6fa720:	75 6c                	jne    6fa78e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x377e>
  6fa722:	0f b6 84 24 d5 05 00 	movzbl 0x5d5(%rsp),%eax
  6fa729:	00 
  6fa72a:	3a 84 24 4d 06 00 00 	cmp    0x64d(%rsp),%al
  6fa731:	75 5b                	jne    6fa78e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x377e>
  6fa733:	48 8d bc 24 bc 05 00 	lea    0x5bc(%rsp),%rdi
  6fa73a:	00 
  6fa73b:	48 8d b4 24 34 06 00 	lea    0x634(%rsp),%rsi
  6fa742:	00 
  6fa743:	e8 18 63 00 00       	call   700a60 <<gpui_reactivity_core::geometry::Affine as gpui::property::ExactValue>::same>
  6fa748:	84 c0                	test   %al,%al
  6fa74a:	74 42                	je     6fa78e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x377e>
  6fa74c:	f3 0f 6f 84 24 9c 05 	movdqu 0x59c(%rsp),%xmm0
  6fa753:	00 00 
  6fa755:	f3 0f 6f 8c 24 14 06 	movdqu 0x614(%rsp),%xmm1
  6fa75c:	00 00 
  6fa75e:	66 0f 74 c8          	pcmpeqb %xmm0,%xmm1
  6fa762:	66 0f d7 c1          	pmovmskb %xmm1,%eax
  6fa766:	3d ff ff 00 00       	cmp    $0xffff,%eax
  6fa76b:	75 21                	jne    6fa78e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x377e>
  6fa76d:	f3 0f 6f 84 24 ac 05 	movdqu 0x5ac(%rsp),%xmm0
  6fa774:	00 00 
  6fa776:	f3 0f 6f 8c 24 24 06 	movdqu 0x624(%rsp),%xmm1
  6fa77d:	00 00 
  6fa77f:	66 0f 74 c8          	pcmpeqb %xmm0,%xmm1
  6fa783:	66 0f d7 c1          	pmovmskb %xmm1,%eax
  6fa787:	3d ff ff 00 00       	cmp    $0xffff,%eax
  6fa78c:	74 11                	je     6fa79f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x378f>
  6fa78e:	48 8b 04 24          	mov    (%rsp),%rax
  6fa792:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6fa799:	b0 01                	mov    $0x1,%al
  6fa79b:	89 44 24 10          	mov    %eax,0x10(%rsp)
  6fa79f:	40 f6 c5 01          	test   $0x1,%bpl
  6fa7a3:	74 28                	je     6fa7cd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x37bd>
  6fa7a5:	f6 c3 01             	test   $0x1,%bl
  6fa7a8:	0f 84 f0 00 00 00    	je     6fa89e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x388e>
  6fa7ae:	f3 0f 10 84 24 84 05 	movss  0x584(%rsp),%xmm0
  6fa7b5:	00 00 
  6fa7b7:	0f 2e 84 24 fc 05 00 	ucomiss 0x5fc(%rsp),%xmm0
  6fa7be:	00 
  6fa7bf:	0f 85 d9 00 00 00    	jne    6fa89e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x388e>
  6fa7c5:	0f 8a d3 00 00 00    	jp     6fa89e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x388e>
  6fa7cb:	eb 09                	jmp    6fa7d6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x37c6>
  6fa7cd:	f6 c3 01             	test   $0x1,%bl
  6fa7d0:	0f 85 c8 00 00 00    	jne    6fa89e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x388e>
  6fa7d6:	0f b6 84 24 00 06 00 	movzbl 0x600(%rsp),%eax
  6fa7dd:	00 
  6fa7de:	83 bc 24 88 05 00 00 	cmpl   $0x1,0x588(%rsp)
  6fa7e5:	01 
  6fa7e6:	75 27                	jne    6fa80f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x37ff>
  6fa7e8:	84 c0                	test   %al,%al
  6fa7ea:	0f 84 ae 00 00 00    	je     6fa89e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x388e>
  6fa7f0:	f3 0f 10 84 24 8c 05 	movss  0x58c(%rsp),%xmm0
  6fa7f7:	00 00 
  6fa7f9:	0f 2e 84 24 04 06 00 	ucomiss 0x604(%rsp),%xmm0
  6fa800:	00 
  6fa801:	0f 85 97 00 00 00    	jne    6fa89e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x388e>
  6fa807:	0f 8a 91 00 00 00    	jp     6fa89e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x388e>
  6fa80d:	eb 08                	jmp    6fa817 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3807>
  6fa80f:	84 c0                	test   %al,%al
  6fa811:	0f 85 87 00 00 00    	jne    6fa89e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x388e>
  6fa817:	f3 0f 10 84 24 90 05 	movss  0x590(%rsp),%xmm0
  6fa81e:	00 00 
  6fa820:	0f 2e 84 24 08 06 00 	ucomiss 0x608(%rsp),%xmm0
  6fa827:	00 
  6fa828:	75 74                	jne    6fa89e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x388e>
  6fa82a:	7a 72                	jp     6fa89e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x388e>
  6fa82c:	f3 0f 10 84 24 94 05 	movss  0x594(%rsp),%xmm0
  6fa833:	00 00 
  6fa835:	0f 2e 84 24 0c 06 00 	ucomiss 0x60c(%rsp),%xmm0
  6fa83c:	00 
  6fa83d:	75 5f                	jne    6fa89e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x388e>
  6fa83f:	7a 5d                	jp     6fa89e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x388e>
  6fa841:	f3 0f 10 84 24 98 05 	movss  0x598(%rsp),%xmm0
  6fa848:	00 00 
  6fa84a:	f3 0f 10 8c 24 10 06 	movss  0x610(%rsp),%xmm1
  6fa851:	00 00 
  6fa853:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6fa856:	75 46                	jne    6fa89e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x388e>
  6fa858:	7a 44                	jp     6fa89e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x388e>
  6fa85a:	0f b6 84 24 d4 05 00 	movzbl 0x5d4(%rsp),%eax
  6fa861:	00 
  6fa862:	3a 84 24 4c 06 00 00 	cmp    0x64c(%rsp),%al
  6fa869:	75 33                	jne    6fa89e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x388e>
  6fa86b:	0f b6 84 24 d6 05 00 	movzbl 0x5d6(%rsp),%eax
  6fa872:	00 
  6fa873:	3a 84 24 4e 06 00 00 	cmp    0x64e(%rsp),%al
  6fa87a:	75 22                	jne    6fa89e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x388e>
  6fa87c:	0f b6 84 24 d7 05 00 	movzbl 0x5d7(%rsp),%eax
  6fa883:	00 
  6fa884:	3a 84 24 4f 06 00 00 	cmp    0x64f(%rsp),%al
  6fa88b:	75 11                	jne    6fa89e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x388e>
  6fa88d:	0f b6 84 24 d5 05 00 	movzbl 0x5d5(%rsp),%eax
  6fa894:	00 
  6fa895:	3a 84 24 4d 06 00 00 	cmp    0x64d(%rsp),%al
  6fa89c:	74 2f                	je     6fa8cd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38bd>
  6fa89e:	41 b4 01             	mov    $0x1,%r12b
  6fa8a1:	40 b5 01             	mov    $0x1,%bpl
  6fa8a4:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  6fa8a9:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  6fa8ae:	e8 ad ec 00 00       	call   709560 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6fa8b3:	f3 0f 10 84 24 98 05 	movss  0x598(%rsp),%xmm0
  6fa8ba:	00 00 
  6fa8bc:	f3 0f 10 8c 24 10 06 	movss  0x610(%rsp),%xmm1
  6fa8c3:	00 00 
  6fa8c5:	4c 8b bc 24 50 01 00 	mov    0x150(%rsp),%r15
  6fa8cc:	00 
  6fa8cd:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6fa8d0:	75 02                	jne    6fa8d4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38c4>
  6fa8d2:	7b 24                	jnp    6fa8f8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38e8>
  6fa8d4:	48 83 bc 24 40 04 00 	cmpq   $0xfffffffffffffffe,0x440(%rsp)
  6fa8db:	00 fe 
  6fa8dd:	74 19                	je     6fa8f8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38e8>
  6fa8df:	48 8d bc 24 40 04 00 	lea    0x440(%rsp),%rdi
  6fa8e6:	00 
  6fa8e7:	e8 24 7d fe ff       	call   6e2610 <core::ptr::drop_glue::<core::option::Option<gpui::runtime::Shaped>>>
  6fa8ec:	48 c7 84 24 40 04 00 	movq   $0xffffffffffffffff,0x440(%rsp)
  6fa8f3:	00 ff ff ff ff 
  6fa8f8:	45 85 ff             	test   %r15d,%r15d
  6fa8fb:	0f 98 c0             	sets   %al
  6fa8fe:	48 83 bc 24 08 01 00 	cmpq   $0x0,0x108(%rsp)
  6fa905:	00 00 
  6fa907:	0f 95 c1             	setne  %cl
  6fa90a:	38 c8                	cmp    %cl,%al
  6fa90c:	74 11                	je     6fa91f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x390f>
  6fa90e:	48 8b 04 24          	mov    (%rsp),%rax
  6fa912:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6fa919:	b0 01                	mov    $0x1,%al
  6fa91b:	89 44 24 10          	mov    %eax,0x10(%rsp)
  6fa91f:	41 b4 01             	mov    $0x1,%r12b
  6fa922:	40 b5 01             	mov    $0x1,%bpl
  6fa925:	48 8d bc 24 60 03 00 	lea    0x360(%rsp),%rdi
  6fa92c:	00 
  6fa92d:	48 8b b4 24 00 04 00 	mov    0x400(%rsp),%rsi
  6fa934:	00 
  6fa935:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6fa93a:	48 8b 0d e7 0e 39 00 	mov    0x390ee7(%rip),%rcx        # a8b828 <_DYNAMIC+0x3d0>
  6fa941:	e8 9a 02 02 00       	call   71abe0 <<gpui::property::Overrides>::get::<gpui_canvas::color::Color>>
  6fa946:	8b 9c 24 60 03 00 00 	mov    0x360(%rsp),%ebx
  6fa94d:	41 b4 01             	mov    $0x1,%r12b
  6fa950:	40 b5 01             	mov    $0x1,%bpl
  6fa953:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6fa95a:	00 
  6fa95b:	48 8b b4 24 00 04 00 	mov    0x400(%rsp),%rsi
  6fa962:	00 
  6fa963:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6fa968:	48 8b 0d c1 0e 39 00 	mov    0x390ec1(%rip),%rcx        # a8b830 <_DYNAMIC+0x3d8>
  6fa96f:	e8 6c 02 02 00       	call   71abe0 <<gpui::property::Overrides>::get::<gpui_canvas::color::Color>>
  6fa974:	0f b6 84 24 a0 01 00 	movzbl 0x1a0(%rsp),%eax
  6fa97b:	00 
  6fa97c:	00 c0                	add    %al,%al
  6fa97e:	08 d8                	or     %bl,%al
  6fa980:	48 8d 94 24 98 00 00 	lea    0x98(%rsp),%rdx
  6fa987:	00 
  6fa988:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
  6fa98c:	48 89 8c 24 b0 03 00 	mov    %rcx,0x3b0(%rsp)
  6fa993:	00 
  6fa994:	0f 10 42 58          	movups 0x58(%rdx),%xmm0
  6fa998:	0f 29 84 24 a0 03 00 	movaps %xmm0,0x3a0(%rsp)
  6fa99f:	00 
  6fa9a0:	0f 10 42 18          	movups 0x18(%rdx),%xmm0
  6fa9a4:	0f 10 4a 28          	movups 0x28(%rdx),%xmm1
  6fa9a8:	0f 10 52 38          	movups 0x38(%rdx),%xmm2
  6fa9ac:	0f 10 5a 48          	movups 0x48(%rdx),%xmm3
  6fa9b0:	0f 29 9c 24 90 03 00 	movaps %xmm3,0x390(%rsp)
  6fa9b7:	00 
  6fa9b8:	0f 29 94 24 80 03 00 	movaps %xmm2,0x380(%rsp)
  6fa9bf:	00 
  6fa9c0:	0f 29 8c 24 70 03 00 	movaps %xmm1,0x370(%rsp)
  6fa9c7:	00 
  6fa9c8:	0f 29 84 24 60 03 00 	movaps %xmm0,0x360(%rsp)
  6fa9cf:	00 
  6fa9d0:	48 8b 8c 24 48 06 00 	mov    0x648(%rsp),%rcx
  6fa9d7:	00 
  6fa9d8:	48 89 8c 24 f0 01 00 	mov    %rcx,0x1f0(%rsp)
  6fa9df:	00 
  6fa9e0:	0f 10 84 24 38 06 00 	movups 0x638(%rsp),%xmm0
  6fa9e7:	00 
  6fa9e8:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
  6fa9ef:	00 
  6fa9f0:	f3 0f 6f 84 24 f8 05 	movdqu 0x5f8(%rsp),%xmm0
  6fa9f7:	00 00 
  6fa9f9:	f3 0f 6f 8c 24 08 06 	movdqu 0x608(%rsp),%xmm1
  6faa00:	00 00 
  6faa02:	f3 0f 6f 94 24 18 06 	movdqu 0x618(%rsp),%xmm2
  6faa09:	00 00 
  6faa0b:	0f 10 9c 24 28 06 00 	movups 0x628(%rsp),%xmm3
  6faa12:	00 
  6faa13:	0f 29 9c 24 d0 01 00 	movaps %xmm3,0x1d0(%rsp)
  6faa1a:	00 
  6faa1b:	66 0f 7f 94 24 c0 01 	movdqa %xmm2,0x1c0(%rsp)
  6faa22:	00 00 
  6faa24:	66 0f 7f 8c 24 b0 01 	movdqa %xmm1,0x1b0(%rsp)
  6faa2b:	00 00 
  6faa2d:	66 0f 7f 84 24 a0 01 	movdqa %xmm0,0x1a0(%rsp)
  6faa34:	00 00 
  6faa36:	41 b4 01             	mov    $0x1,%r12b
  6faa39:	44 0f b6 c0          	movzbl %al,%r8d
  6faa3d:	40 b5 01             	mov    $0x1,%bpl
  6faa40:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6faa47:	00 
  6faa48:	4c 89 f6             	mov    %r14,%rsi
  6faa4b:	48 8d 94 24 60 03 00 	lea    0x360(%rsp),%rdx
  6faa52:	00 
  6faa53:	48 8d 8c 24 a0 01 00 	lea    0x1a0(%rsp),%rcx
  6faa5a:	00 
  6faa5b:	ff 15 ff 10 39 00    	call   *0x3910ff(%rip)        # a8bb60 <_DYNAMIC+0x708>
  6faa61:	48 83 7c 24 38 00    	cmpq   $0x0,0x38(%rsp)
  6faa67:	4c 8b 6c 24 60       	mov    0x60(%rsp),%r13
  6faa6c:	74 36                	je     6faaa4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3a94>
  6faa6e:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  6faa73:	48 8b 00             	mov    (%rax),%rax
  6faa76:	48 85 c0             	test   %rax,%rax
  6faa79:	74 07                	je     6faa82 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3a72>
  6faa7b:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  6faa80:	ff d0                	call   *%rax
  6faa82:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  6faa87:	48 8b 70 08          	mov    0x8(%rax),%rsi
  6faa8b:	48 85 f6             	test   %rsi,%rsi
  6faa8e:	74 14                	je     6faaa4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3a94>
  6faa90:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  6faa95:	48 8b 50 10          	mov    0x10(%rax),%rdx
  6faa99:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  6faa9e:	ff 15 04 0c 39 00    	call   *0x390c04(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6faaa4:	4c 8b bc 24 08 01 00 	mov    0x108(%rsp),%r15
  6faaab:	00 
  6faaac:	4d 85 ff             	test   %r15,%r15
  6faaaf:	74 5f                	je     6fab10 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3b00>
  6faab1:	4c 8b ac 24 10 01 00 	mov    0x110(%rsp),%r13
  6faab8:	00 
  6faab9:	48 8b 9c 24 60 05 00 	mov    0x560(%rsp),%rbx
  6faac0:	00 
  6faac1:	48 3b 9c 24 50 05 00 	cmp    0x550(%rsp),%rbx
  6faac8:	00 
  6faac9:	75 0d                	jne    6faad8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3ac8>
  6faacb:	48 8d bc 24 50 05 00 	lea    0x550(%rsp),%rdi
  6faad2:	00 
  6faad3:	e8 18 5f 02 00       	call   7209f0 <<alloc::raw_vec::RawVec<[core::option::Option<gpui::source::FieldId>; 2]>>::grow_one>
  6faad8:	48 8b 84 24 58 05 00 	mov    0x558(%rsp),%rax
  6faadf:	00 
  6faae0:	48 89 d9             	mov    %rbx,%rcx
  6faae3:	48 c1 e1 04          	shl    $0x4,%rcx
  6faae7:	4c 89 3c 08          	mov    %r15,(%rax,%rcx,1)
  6faaeb:	4c 89 6c 08 08       	mov    %r13,0x8(%rax,%rcx,1)
  6faaf0:	48 8d 43 01          	lea    0x1(%rbx),%rax
  6faaf4:	48 89 84 24 60 05 00 	mov    %rax,0x560(%rsp)
  6faafb:	00 
  6faafc:	b8 01 00 00 00       	mov    $0x1,%eax
  6fab01:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  6fab08:	00 
  6fab09:	4c 8b 6c 24 60       	mov    0x60(%rsp),%r13
  6fab0e:	eb 0c                	jmp    6fab1c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3b0c>
  6fab10:	48 c7 84 24 50 01 00 	movq   $0x0,0x150(%rsp)
  6fab17:	00 00 00 00 00 
  6fab1c:	41 b4 01             	mov    $0x1,%r12b
  6fab1f:	31 ed                	xor    %ebp,%ebp
  6fab21:	48 8b bc 24 98 02 00 	mov    0x298(%rsp),%rdi
  6fab28:	00 
  6fab29:	4c 89 ee             	mov    %r13,%rsi
  6fab2c:	ff 15 5e 0f 39 00    	call   *0x390f5e(%rip)        # a8ba90 <_DYNAMIC+0x638>
  6fab32:	89 44 24 60          	mov    %eax,0x60(%rsp)
  6fab36:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  6fab3d:	00 
  6fab3e:	48 85 c0             	test   %rax,%rax
  6fab41:	48 0f 44 d8          	cmove  %rax,%rbx
  6fab45:	81 bc 24 28 02 00 00 	cmpl   $0x186a0,0x228(%rsp)
  6fab4c:	a0 86 01 00 
  6fab50:	0f 83 95 2c 00 00    	jae    6fd7eb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x67db>
  6fab56:	48 81 fb 9f 86 01 00 	cmp    $0x1869f,%rbx
  6fab5d:	0f 87 9d 2c 00 00    	ja     6fd800 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x67f0>
  6fab63:	48 83 bc 24 40 04 00 	cmpq   $0xfffffffffffffffe,0x440(%rsp)
  6fab6a:	00 fe 
  6fab6c:	41 0f 94 c4          	sete   %r12b
  6fab70:	bd ff ff ff ff       	mov    $0xffffffff,%ebp
  6fab75:	0f 84 69 01 00 00    	je     6face4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3cd4>
  6fab7b:	0f 28 84 24 80 04 00 	movaps 0x480(%rsp),%xmm0
  6fab82:	00 
  6fab83:	0f 29 84 24 a0 03 00 	movaps %xmm0,0x3a0(%rsp)
  6fab8a:	00 
  6fab8b:	66 0f 6f 84 24 40 04 	movdqa 0x440(%rsp),%xmm0
  6fab92:	00 00 
  6fab94:	66 0f 6f 8c 24 50 04 	movdqa 0x450(%rsp),%xmm1
  6fab9b:	00 00 
  6fab9d:	66 0f 6f 94 24 60 04 	movdqa 0x460(%rsp),%xmm2
  6faba4:	00 00 
  6faba6:	0f 28 9c 24 70 04 00 	movaps 0x470(%rsp),%xmm3
  6fabad:	00 
  6fabae:	0f 29 9c 24 90 03 00 	movaps %xmm3,0x390(%rsp)
  6fabb5:	00 
  6fabb6:	66 0f 7f 94 24 80 03 	movdqa %xmm2,0x380(%rsp)
  6fabbd:	00 00 
  6fabbf:	66 0f 7f 8c 24 70 03 	movdqa %xmm1,0x370(%rsp)
  6fabc6:	00 00 
  6fabc8:	66 0f 7f 84 24 60 03 	movdqa %xmm0,0x360(%rsp)
  6fabcf:	00 00 
  6fabd1:	48 8b b4 24 50 02 00 	mov    0x250(%rsp),%rsi
  6fabd8:	00 
  6fabd9:	49 39 f6             	cmp    %rsi,%r14
  6fabdc:	0f 83 9d 2f 00 00    	jae    6fdb7f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b6f>
  6fabe2:	48 8b 84 24 48 02 00 	mov    0x248(%rsp),%rax
  6fabe9:	00 
  6fabea:	4a 8b 04 f0          	mov    (%rax,%r14,8),%rax
  6fabee:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
  6fabf5:	00 
  6fabf6:	48 8b ac 24 78 05 00 	mov    0x578(%rsp),%rbp
  6fabfd:	00 
  6fabfe:	48 8b 84 24 a0 03 00 	mov    0x3a0(%rsp),%rax
  6fac05:	00 
  6fac06:	48 89 84 24 e0 01 00 	mov    %rax,0x1e0(%rsp)
  6fac0d:	00 
  6fac0e:	48 8b 84 24 a8 03 00 	mov    0x3a8(%rsp),%rax
  6fac15:	00 
  6fac16:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
  6fac1d:	00 
  6fac1e:	66 0f 6f 84 24 60 03 	movdqa 0x360(%rsp),%xmm0
  6fac25:	00 00 
  6fac27:	66 0f 6f 8c 24 70 03 	movdqa 0x370(%rsp),%xmm1
  6fac2e:	00 00 
  6fac30:	66 0f 6f 94 24 80 03 	movdqa 0x380(%rsp),%xmm2
  6fac37:	00 00 
  6fac39:	0f 28 9c 24 90 03 00 	movaps 0x390(%rsp),%xmm3
  6fac40:	00 
  6fac41:	0f 29 9c 24 d0 01 00 	movaps %xmm3,0x1d0(%rsp)
  6fac48:	00 
  6fac49:	66 0f 7f 94 24 c0 01 	movdqa %xmm2,0x1c0(%rsp)
  6fac50:	00 00 
  6fac52:	66 0f 7f 8c 24 b0 01 	movdqa %xmm1,0x1b0(%rsp)
  6fac59:	00 00 
  6fac5b:	66 0f 7f 84 24 a0 01 	movdqa %xmm0,0x1a0(%rsp)
  6fac62:	00 00 
  6fac64:	48 3b ac 24 68 05 00 	cmp    0x568(%rsp),%rbp
  6fac6b:	00 
  6fac6c:	75 0d                	jne    6fac7b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3c6b>
  6fac6e:	48 8d bc 24 68 05 00 	lea    0x568(%rsp),%rdi
  6fac75:	00 
  6fac76:	e8 c5 5e 02 00       	call   720b40 <<alloc::raw_vec::RawVec<core::option::Option<gpui::runtime::TextSite>>>::grow_one>
  6fac7b:	48 8b 84 24 70 05 00 	mov    0x570(%rsp),%rax
  6fac82:	00 
  6fac83:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
  6fac8a:	00 
  6fac8b:	48 01 e9             	add    %rbp,%rcx
  6fac8e:	48 c1 e1 04          	shl    $0x4,%rcx
  6fac92:	0f 28 84 24 e0 01 00 	movaps 0x1e0(%rsp),%xmm0
  6fac99:	00 
  6fac9a:	0f 11 44 08 40       	movups %xmm0,0x40(%rax,%rcx,1)
  6fac9f:	66 0f 6f 84 24 a0 01 	movdqa 0x1a0(%rsp),%xmm0
  6faca6:	00 00 
  6faca8:	66 0f 6f 8c 24 b0 01 	movdqa 0x1b0(%rsp),%xmm1
  6facaf:	00 00 
  6facb1:	66 0f 6f 94 24 c0 01 	movdqa 0x1c0(%rsp),%xmm2
  6facb8:	00 00 
  6facba:	0f 28 9c 24 d0 01 00 	movaps 0x1d0(%rsp),%xmm3
  6facc1:	00 
  6facc2:	0f 11 5c 08 30       	movups %xmm3,0x30(%rax,%rcx,1)
  6facc7:	f3 0f 7f 54 08 20    	movdqu %xmm2,0x20(%rax,%rcx,1)
  6faccd:	f3 0f 7f 4c 08 10    	movdqu %xmm1,0x10(%rax,%rcx,1)
  6facd3:	f3 0f 7f 04 08       	movdqu %xmm0,(%rax,%rcx,1)
  6facd8:	48 8d 45 01          	lea    0x1(%rbp),%rax
  6facdc:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
  6face3:	00 
  6face4:	80 bc 24 20 02 00 00 	cmpb   $0x0,0x220(%rsp)
  6faceb:	00 
  6facec:	74 35                	je     6fad23 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d13>
  6facee:	0f b6 84 24 20 01 00 	movzbl 0x120(%rsp),%eax
  6facf5:	00 
  6facf6:	8d 48 fe             	lea    -0x2(%rax),%ecx
  6facf9:	83 f8 02             	cmp    $0x2,%eax
  6facfc:	0f b6 c9             	movzbl %cl,%ecx
  6facff:	ba 08 00 00 00       	mov    $0x8,%edx
  6fad04:	0f 42 ca             	cmovb  %edx,%ecx
  6fad07:	44 0f b6 f1          	movzbl %cl,%r14d
  6fad0b:	48 8d 15 e6 d0 95 ff 	lea    -0x6a2f1a(%rip),%rdx        # 57df8 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x150>
  6fad12:	4a 63 0c b2          	movslq (%rdx,%r14,4),%rcx
  6fad16:	48 01 d1             	add    %rdx,%rcx
  6fad19:	ff e1                	jmp    *%rcx
  6fad1b:	41 be 01 00 00 00    	mov    $0x1,%r14d
  6fad21:	eb 56                	jmp    6fad79 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d69>
  6fad23:	31 ed                	xor    %ebp,%ebp
  6fad25:	0f b6 b4 24 18 02 00 	movzbl 0x218(%rsp),%esi
  6fad2c:	00 
  6fad2d:	48 8b bc 24 78 01 00 	mov    0x178(%rsp),%rdi
  6fad34:	00 
  6fad35:	ff 15 2d 0e 39 00    	call   *0x390e2d(%rip)        # a8bb68 <_DYNAMIC+0x710>
  6fad3b:	41 89 c6             	mov    %eax,%r14d
  6fad3e:	eb 53                	jmp    6fad93 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d83>
  6fad40:	41 be 04 00 00 00    	mov    $0x4,%r14d
  6fad46:	eb 31                	jmp    6fad79 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d69>
  6fad48:	41 be 02 00 00 00    	mov    $0x2,%r14d
  6fad4e:	eb 29                	jmp    6fad79 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d69>
  6fad50:	41 be 03 00 00 00    	mov    $0x3,%r14d
  6fad56:	eb 21                	jmp    6fad79 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d69>
  6fad58:	41 be 07 00 00 00    	mov    $0x7,%r14d
  6fad5e:	eb 19                	jmp    6fad79 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d69>
  6fad60:	41 be 05 00 00 00    	mov    $0x5,%r14d
  6fad66:	eb 11                	jmp    6fad79 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d69>
  6fad68:	41 be 06 00 00 00    	mov    $0x6,%r14d
  6fad6e:	eb 09                	jmp    6fad79 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d69>
  6fad70:	83 e0 01             	and    $0x1,%eax
  6fad73:	83 c8 08             	or     $0x8,%eax
  6fad76:	41 89 c6             	mov    %eax,%r14d
  6fad79:	83 fd ff             	cmp    $0xffffffff,%ebp
  6fad7c:	74 15                	je     6fad93 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d83>
  6fad7e:	81 fd a0 86 01 00    	cmp    $0x186a0,%ebp
  6fad84:	0f 83 f0 2a 00 00    	jae    6fd87a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x686a>
  6fad8a:	c1 e5 04             	shl    $0x4,%ebp
  6fad8d:	83 c5 10             	add    $0x10,%ebp
  6fad90:	41 09 ee             	or     %ebp,%r14d
  6fad93:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  6fad98:	48 3b 44 24 20       	cmp    0x20(%rsp),%rax
  6fad9d:	b9 00 00 00 00       	mov    $0x0,%ecx
  6fada2:	48 0f 44 c1          	cmove  %rcx,%rax
  6fada6:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6fadab:	41 0f 94 c7          	sete   %r15b
  6fadaf:	4c 8b ac 24 98 01 00 	mov    0x198(%rsp),%r13
  6fadb6:	00 
  6fadb7:	4c 3b ac 24 88 01 00 	cmp    0x188(%rsp),%r13
  6fadbe:	00 
  6fadbf:	75 0f                	jne    6fadd0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3dc0>
  6fadc1:	31 ed                	xor    %ebp,%ebp
  6fadc3:	48 8d bc 24 88 01 00 	lea    0x188(%rsp),%rdi
  6fadca:	00 
  6fadcb:	e8 c0 5e 02 00       	call   720c90 <<alloc::raw_vec::RawVec<gpui::style_port::Draft>>::grow_one>
  6fadd0:	89 d8                	mov    %ebx,%eax
  6fadd2:	c1 e0 11             	shl    $0x11,%eax
  6fadd5:	0b 84 24 28 02 00 00 	or     0x228(%rsp),%eax
  6faddc:	c1 e3 0e             	shl    $0xe,%ebx
  6faddf:	81 e3 00 00 00 60    	and    $0x60000000,%ebx
  6fade5:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
  6fadec:	00 
  6faded:	c1 e1 1f             	shl    $0x1f,%ecx
  6fadf0:	09 d9                	or     %ebx,%ecx
  6fadf2:	41 81 e6 ff ff ff 1f 	and    $0x1fffffff,%r14d
  6fadf9:	41 09 ce             	or     %ecx,%r14d
  6fadfc:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
  6fae03:	00 
  6fae04:	4a 8d 14 6d 00 00 00 	lea    0x0(,%r13,2),%rdx
  6fae0b:	00 
  6fae0c:	4c 01 ea             	add    %r13,%rdx
  6fae0f:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  6fae14:	48 89 34 d1          	mov    %rsi,(%rcx,%rdx,8)
  6fae18:	8b 74 24 60          	mov    0x60(%rsp),%esi
  6fae1c:	89 74 d1 08          	mov    %esi,0x8(%rcx,%rdx,8)
  6fae20:	89 44 d1 0c          	mov    %eax,0xc(%rcx,%rdx,8)
  6fae24:	44 89 74 d1 10       	mov    %r14d,0x10(%rcx,%rdx,8)
  6fae29:	8b 84 24 e8 03 00 00 	mov    0x3e8(%rsp),%eax
  6fae30:	89 44 d1 14          	mov    %eax,0x14(%rcx,%rdx,8)
  6fae34:	49 ff c5             	inc    %r13
  6fae37:	4c 89 ac 24 98 01 00 	mov    %r13,0x198(%rsp)
  6fae3e:	00 
  6fae3f:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
  6fae46:	00 
  6fae47:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
  6fae4b:	48 83 f8 fc          	cmp    $0xfffffffffffffffc,%rax
  6fae4f:	77 13                	ja     6fae64 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3e54>
  6fae51:	ba 01 00 00 00       	mov    $0x1,%edx
  6fae56:	48 8b bc 24 d8 03 00 	mov    0x3d8(%rsp),%rdi
  6fae5d:	00 
  6fae5e:	ff 15 44 08 39 00    	call   *0x390844(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fae64:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
  6fae6b:	00 
  6fae6c:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fae70:	4c 8b a4 24 80 00 00 	mov    0x80(%rsp),%r12
  6fae77:	00 
  6fae78:	4c 8b ac 24 10 05 00 	mov    0x510(%rsp),%r13
  6fae7f:	00 
  6fae80:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
  6fae85:	74 18                	je     6fae9f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3e8f>
  6fae87:	48 85 f6             	test   %rsi,%rsi
  6fae8a:	7e 13                	jle    6fae9f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3e8f>
  6fae8c:	48 8b bc 24 98 00 00 	mov    0x98(%rsp),%rdi
  6fae93:	00 
  6fae94:	ba 01 00 00 00       	mov    $0x1,%edx
  6fae99:	ff 15 09 08 39 00    	call   *0x390809(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fae9f:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  6faea6:	00 
  6faea7:	e8 d4 a1 fe ff       	call   6e5080 <core::ptr::drop_glue::<gpui::element::ComponentBoundaries>>
  6faeac:	44 0a 7c 24 10       	or     0x10(%rsp),%r15b
  6faeb1:	41 0f b6 c7          	movzbl %r15b,%eax
  6faeb5:	49 01 c5             	add    %rax,%r13
  6faeb8:	4c 8b b4 24 f0 03 00 	mov    0x3f0(%rsp),%r14
  6faebf:	00 
  6faec0:	48 8b 84 24 08 05 00 	mov    0x508(%rsp),%rax
  6faec7:	00 
  6faec8:	48 89 c6             	mov    %rax,%rsi
  6faecb:	48 3b 84 24 48 08 00 	cmp    0x848(%rsp),%rax
  6faed2:	00 
  6faed3:	0f 85 c5 e5 ff ff    	jne    6f949e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x248e>
  6faed9:	eb 27                	jmp    6faf02 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3ef2>
  6faedb:	48 8d 84 24 f8 05 00 	lea    0x5f8(%rsp),%rax
  6faee2:	00 
  6faee3:	e9 ff f6 ff ff       	jmp    6fa5e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x35d7>
  6faee8:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6faeec:	ff 15 fe 07 39 00    	call   *0x3907fe(%rip)        # a8b6f0 <_DYNAMIC+0x298>
  6faef2:	e9 29 f5 ff ff       	jmp    6fa420 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3410>
  6faef7:	45 31 ed             	xor    %r13d,%r13d
  6faefa:	4c 8b a4 24 80 00 00 	mov    0x80(%rsp),%r12
  6faf01:	00 
  6faf02:	b3 01                	mov    $0x1,%bl
  6faf04:	48 8d bc 24 d0 06 00 	lea    0x6d0(%rsp),%rdi
  6faf0b:	00 
  6faf0c:	40 b5 01             	mov    $0x1,%bpl
  6faf0f:	e8 4c 44 02 00       	call   71f360 <<alloc::vec::into_iter::IntoIter<gpui::element::DraftNode> as core::ops::drop::Drop>::drop>
  6faf14:	48 8b 04 24          	mov    (%rsp),%rax
  6faf18:	48 8d b8 f0 05 00 00 	lea    0x5f0(%rax),%rdi
  6faf1f:	48 8b 84 24 a0 04 00 	mov    0x4a0(%rsp),%rax
  6faf26:	00 
  6faf27:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6faf2e:	00 
  6faf2f:	66 0f 6f 84 24 90 04 	movdqa 0x490(%rsp),%xmm0
  6faf36:	00 00 
  6faf38:	66 0f 7f 84 24 90 00 	movdqa %xmm0,0x90(%rsp)
  6faf3f:	00 00 
  6faf41:	31 ed                	xor    %ebp,%ebp
  6faf43:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6faf4a:	00 
  6faf4b:	ff 15 1f 0c 39 00    	call   *0x390c1f(%rip)        # a8bb70 <_DYNAMIC+0x718>
  6faf51:	4d 85 e4             	test   %r12,%r12
  6faf54:	74 18                	je     6faf6e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3f5e>
  6faf56:	44 89 e0             	mov    %r12d,%eax
  6faf59:	83 e0 03             	and    $0x3,%eax
  6faf5c:	49 83 fc 04          	cmp    $0x4,%r12
  6faf60:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
  6faf65:	73 11                	jae    6faf78 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3f68>
  6faf67:	31 c9                	xor    %ecx,%ecx
  6faf69:	45 31 f6             	xor    %r14d,%r14d
  6faf6c:	eb 5a                	jmp    6fafc8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3fb8>
  6faf6e:	45 31 f6             	xor    %r14d,%r14d
  6faf71:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
  6faf76:	eb 78                	jmp    6faff0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3fe0>
  6faf78:	48 ba 00 00 00 00 00 	movabs $0x800000000000000,%rdx
  6faf7f:	00 00 08 
  6faf82:	48 83 c2 fc          	add    $0xfffffffffffffffc,%rdx
  6faf86:	4c 21 e2             	and    %r12,%rdx
  6faf89:	31 c9                	xor    %ecx,%ecx
  6faf8b:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  6faf90:	45 31 f6             	xor    %r14d,%r14d
  6faf93:	48 83 3e 01          	cmpq   $0x1,(%rsi)
  6faf97:	49 83 de ff          	sbb    $0xffffffffffffffff,%r14
  6faf9b:	48 83 7e 18 01       	cmpq   $0x1,0x18(%rsi)
  6fafa0:	49 83 de ff          	sbb    $0xffffffffffffffff,%r14
  6fafa4:	48 83 7e 30 01       	cmpq   $0x1,0x30(%rsi)
  6fafa9:	49 83 de ff          	sbb    $0xffffffffffffffff,%r14
  6fafad:	48 83 7e 48 01       	cmpq   $0x1,0x48(%rsi)
  6fafb2:	49 83 de ff          	sbb    $0xffffffffffffffff,%r14
  6fafb6:	48 83 c1 04          	add    $0x4,%rcx
  6fafba:	48 83 c6 60          	add    $0x60,%rsi
  6fafbe:	48 39 ca             	cmp    %rcx,%rdx
  6fafc1:	75 d0                	jne    6faf93 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3f83>
  6fafc3:	48 85 c0             	test   %rax,%rax
  6fafc6:	74 28                	je     6faff0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3fe0>
  6fafc8:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  6fafcc:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
  6fafd1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
  6fafd5:	c1 e0 03             	shl    $0x3,%eax
  6fafd8:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  6fafdc:	31 d2                	xor    %edx,%edx
  6fafde:	48 83 3c 11 01       	cmpq   $0x1,(%rcx,%rdx,1)
  6fafe3:	49 83 de ff          	sbb    $0xffffffffffffffff,%r14
  6fafe7:	48 83 c2 18          	add    $0x18,%rdx
  6fafeb:	48 39 d0             	cmp    %rdx,%rax
  6fafee:	75 ee                	jne    6fafde <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3fce>
  6faff0:	4d 01 ee             	add    %r13,%r14
  6faff3:	4d 85 c0             	test   %r8,%r8
  6faff6:	74 30                	je     6fb028 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4018>
  6faff8:	48 8b 04 24          	mov    (%rsp),%rax
  6faffc:	48 8d b8 e8 01 00 00 	lea    0x1e8(%rax),%rdi
  6fb003:	4c 89 c6             	mov    %r8,%rsi
  6fb006:	31 ed                	xor    %ebp,%ebp
  6fb008:	e8 53 42 ff ff       	call   6ef260 <<gpui::runtime::identity_index::IdentityIndex>::required>
  6fb00d:	4c 39 e0             	cmp    %r12,%rax
  6fb010:	0f 83 5c 2c 00 00    	jae    6fdc72 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c62>
  6fb016:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  6fb01a:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  6fb01f:	48 83 3c c1 01       	cmpq   $0x1,(%rcx,%rax,8)
  6fb024:	49 83 d6 00          	adc    $0x0,%r14
  6fb028:	b0 01                	mov    $0x1,%al
  6fb02a:	48 8b 8c 24 90 02 00 	mov    0x290(%rsp),%rcx
  6fb031:	00 
  6fb032:	48 3b 8c 24 98 01 00 	cmp    0x198(%rsp),%rcx
  6fb039:	00 
  6fb03a:	75 6f                	jne    6fb0ab <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x409b>
  6fb03c:	48 83 bc 24 90 02 00 	cmpq   $0x0,0x290(%rsp)
  6fb043:	00 00 
  6fb045:	74 62                	je     6fb0a9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4099>
  6fb047:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
  6fb04e:	00 
  6fb04f:	49 ff cc             	dec    %r12
  6fb052:	31 d2                	xor    %edx,%edx
  6fb054:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  6fb059:	48 8b 04 d0          	mov    (%rax,%rdx,8),%rax
  6fb05d:	48 3b 01             	cmp    (%rcx),%rax
  6fb060:	0f 95 c0             	setne  %al
  6fb063:	75 46                	jne    6fb0ab <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x409b>
  6fb065:	48 83 c1 18          	add    $0x18,%rcx
  6fb069:	49 39 d4             	cmp    %rdx,%r12
  6fb06c:	48 8d 52 01          	lea    0x1(%rdx),%rdx
  6fb070:	75 e2                	jne    6fb054 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4044>
  6fb072:	eb 37                	jmp    6fb0ab <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x409b>
  6fb074:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fb079:	48 c7 00 1d 00 00 00 	movq   $0x1d,(%rax)
  6fb080:	e9 69 21 00 00       	jmp    6fd1ee <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61de>
  6fb085:	48 8d 8c 24 98 00 00 	lea    0x98(%rsp),%rcx
  6fb08c:	00 
  6fb08d:	0f 10 01             	movups (%rcx),%xmm0
  6fb090:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6fb095:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
  6fb099:	48 c7 01 20 00 00 00 	movq   $0x20,(%rcx)
  6fb0a0:	48 89 41 08          	mov    %rax,0x8(%rcx)
  6fb0a4:	e9 51 21 00 00       	jmp    6fd1fa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61ea>
  6fb0a9:	31 c0                	xor    %eax,%eax
  6fb0ab:	48 8b 0c 24          	mov    (%rsp),%rcx
  6fb0af:	08 81 49 07 00 00    	or     %al,0x749(%rcx)
  6fb0b5:	08 81 4b 07 00 00    	or     %al,0x74b(%rcx)
  6fb0bb:	48 c7 84 24 20 05 00 	movq   $0x0,0x520(%rsp)
  6fb0c2:	00 00 00 00 00 
  6fb0c7:	48 c7 84 24 30 05 00 	movq   $0x0,0x530(%rsp)
  6fb0ce:	00 00 00 00 00 
  6fb0d3:	48 c7 84 24 f8 06 00 	movq   $0x0,0x6f8(%rsp)
  6fb0da:	00 00 00 00 00 
  6fb0df:	48 c7 84 24 08 07 00 	movq   $0x0,0x708(%rsp)
  6fb0e6:	00 00 00 00 00 
  6fb0eb:	48 8b 94 24 e0 05 00 	mov    0x5e0(%rsp),%rdx
  6fb0f2:	00 
  6fb0f3:	4c 8b a4 24 e8 05 00 	mov    0x5e8(%rsp),%r12
  6fb0fa:	00 
  6fb0fb:	48 8b 84 24 f0 05 00 	mov    0x5f0(%rsp),%rax
  6fb102:	00 
  6fb103:	48 69 f0 a8 00 00 00 	imul   $0xa8,%rax,%rsi
  6fb10a:	4c 01 e6             	add    %r12,%rsi
  6fb10d:	4c 89 a4 24 60 03 00 	mov    %r12,0x360(%rsp)
  6fb114:	00 
  6fb115:	4c 89 a4 24 68 03 00 	mov    %r12,0x368(%rsp)
  6fb11c:	00 
  6fb11d:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
  6fb122:	48 89 94 24 70 03 00 	mov    %rdx,0x370(%rsp)
  6fb129:	00 
  6fb12a:	48 89 b4 24 20 02 00 	mov    %rsi,0x220(%rsp)
  6fb131:	00 
  6fb132:	48 89 b4 24 78 03 00 	mov    %rsi,0x378(%rsp)
  6fb139:	00 
  6fb13a:	4c 89 a4 24 18 02 00 	mov    %r12,0x218(%rsp)
  6fb141:	00 
  6fb142:	48 85 c0             	test   %rax,%rax
  6fb145:	4c 89 b4 24 e0 03 00 	mov    %r14,0x3e0(%rsp)
  6fb14c:	00 
  6fb14d:	0f 84 83 07 00 00    	je     6fb8d6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x48c6>
  6fb153:	48 8b 04 24          	mov    (%rsp),%rax
  6fb157:	48 05 78 06 00 00    	add    $0x678,%rax
  6fb15d:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fb162:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
  6fb169:	00 
  6fb16a:	48 8b 8c 24 38 02 00 	mov    0x238(%rsp),%rcx
  6fb171:	00 
  6fb172:	eb 11                	jmp    6fb185 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4175>
  6fb174:	4c 89 f0             	mov    %r14,%rax
  6fb177:	4c 3b b4 24 20 02 00 	cmp    0x220(%rsp),%r14
  6fb17e:	00 
  6fb17f:	0f 84 41 07 00 00    	je     6fb8c6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x48b6>
  6fb185:	4c 8d a0 a8 00 00 00 	lea    0xa8(%rax),%r12
  6fb18c:	48 8b 10             	mov    (%rax),%rdx
  6fb18f:	48 83 fa 02          	cmp    $0x2,%rdx
  6fb193:	0f 84 35 07 00 00    	je     6fb8ce <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x48be>
  6fb199:	48 89 94 24 10 05 00 	mov    %rdx,0x510(%rsp)
  6fb1a0:	00 
  6fb1a1:	48 8b 50 18          	mov    0x18(%rax),%rdx
  6fb1a5:	48 89 94 24 78 01 00 	mov    %rdx,0x178(%rsp)
  6fb1ac:	00 
  6fb1ad:	48 8b 50 20          	mov    0x20(%rax),%rdx
  6fb1b1:	48 8b 70 30          	mov    0x30(%rax),%rsi
  6fb1b5:	48 89 74 24 68       	mov    %rsi,0x68(%rsp)
  6fb1ba:	48 8b 70 38          	mov    0x38(%rax),%rsi
  6fb1be:	48 89 74 24 40       	mov    %rsi,0x40(%rsp)
  6fb1c3:	48 8b 70 40          	mov    0x40(%rax),%rsi
  6fb1c7:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
  6fb1cc:	48 8b 70 48          	mov    0x48(%rax),%rsi
  6fb1d0:	48 89 b4 24 28 02 00 	mov    %rsi,0x228(%rsp)
  6fb1d7:	00 
  6fb1d8:	48 8b 70 50          	mov    0x50(%rax),%rsi
  6fb1dc:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
  6fb1e1:	0f 10 40 58          	movups 0x58(%rax),%xmm0
  6fb1e5:	0f 29 84 24 50 03 00 	movaps %xmm0,0x350(%rsp)
  6fb1ec:	00 
  6fb1ed:	0f 10 40 68          	movups 0x68(%rax),%xmm0
  6fb1f1:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  6fb1f8:	00 
  6fb1f9:	48 8b 70 78          	mov    0x78(%rax),%rsi
  6fb1fd:	48 89 b4 24 50 01 00 	mov    %rsi,0x150(%rsp)
  6fb204:	00 
  6fb205:	4c 8b a8 80 00 00 00 	mov    0x80(%rax),%r13
  6fb20c:	48 8b b0 88 00 00 00 	mov    0x88(%rax),%rsi
  6fb213:	48 89 74 24 50       	mov    %rsi,0x50(%rsp)
  6fb218:	4c 8b b8 90 00 00 00 	mov    0x90(%rax),%r15
  6fb21f:	48 8b b0 98 00 00 00 	mov    0x98(%rax),%rsi
  6fb226:	48 8b 98 a0 00 00 00 	mov    0xa0(%rax),%rbx
  6fb22d:	66 0f 10 40 08       	movupd 0x8(%rax),%xmm0
  6fb232:	66 0f 29 84 24 40 04 	movapd %xmm0,0x440(%rsp)
  6fb239:	00 00 
  6fb23b:	48 8b bc 24 98 01 00 	mov    0x198(%rsp),%rdi
  6fb242:	00 
  6fb243:	48 89 b4 24 80 01 00 	mov    %rsi,0x180(%rsp)
  6fb24a:	00 
  6fb24b:	48 89 bc 24 e8 03 00 	mov    %rdi,0x3e8(%rsp)
  6fb252:	00 
  6fb253:	48 39 fe             	cmp    %rdi,%rsi
  6fb256:	48 89 94 24 f0 03 00 	mov    %rdx,0x3f0(%rsp)
  6fb25d:	00 
  6fb25e:	4c 89 6c 24 38       	mov    %r13,0x38(%rsp)
  6fb263:	0f 83 e3 27 00 00    	jae    6fda4c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a3c>
  6fb269:	48 8b 09             	mov    (%rcx),%rcx
  6fb26c:	b0 01                	mov    $0x1,%al
  6fb26e:	48 85 c9             	test   %rcx,%rcx
  6fb271:	4c 89 a4 24 98 02 00 	mov    %r12,0x298(%rsp)
  6fb278:	00 
  6fb279:	0f 84 54 01 00 00    	je     6fb3d3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43c3>
  6fb27f:	48 8b 14 24          	mov    (%rsp),%rdx
  6fb283:	48 8b b2 50 06 00 00 	mov    0x650(%rdx),%rsi
  6fb28a:	0f b7 b9 8a 05 00 00 	movzwl 0x58a(%rcx),%edi
  6fb291:	4c 6b c7 70          	imul   $0x70,%rdi,%r8
  6fb295:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
  6fb29c:	31 d2                	xor    %edx,%edx
  6fb29e:	45 31 d2             	xor    %r10d,%r10d
  6fb2a1:	49 89 cb             	mov    %rcx,%r11
  6fb2a4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fb2ab:	00 00 00 00 00 
  6fb2b0:	49 39 d0             	cmp    %rdx,%r8
  6fb2b3:	74 3c                	je     6fb2f1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x42e1>
  6fb2b5:	41 80 3b 00          	cmpb   $0x0,(%r11)
  6fb2b9:	75 33                	jne    6fb2ee <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x42de>
  6fb2bb:	4d 89 f1             	mov    %r14,%r9
  6fb2be:	49 ff c2             	inc    %r10
  6fb2c1:	49 3b 5b 08          	cmp    0x8(%r11),%rbx
  6fb2c5:	4d 8d 5b 10          	lea    0x10(%r11),%r11
  6fb2c9:	40 0f 97 c5          	seta   %bpl
  6fb2cd:	40 80 dd 00          	sbb    $0x0,%bpl
  6fb2d1:	48 83 c2 70          	add    $0x70,%rdx
  6fb2d5:	49 ff c6             	inc    %r14
  6fb2d8:	40 80 fd 01          	cmp    $0x1,%bpl
  6fb2dc:	74 d2                	je     6fb2b0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x42a0>
  6fb2de:	40 0f b6 fd          	movzbl %bpl,%edi
  6fb2e2:	85 ff                	test   %edi,%edi
  6fb2e4:	74 1f                	je     6fb305 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x42f5>
  6fb2e6:	49 ff c1             	inc    %r9
  6fb2e9:	4c 89 cf             	mov    %r9,%rdi
  6fb2ec:	eb 03                	jmp    6fb2f1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x42e1>
  6fb2ee:	4c 89 d7             	mov    %r10,%rdi
  6fb2f1:	48 83 ee 01          	sub    $0x1,%rsi
  6fb2f5:	0f 82 d8 00 00 00    	jb     6fb3d3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43c3>
  6fb2fb:	48 8b 8c f9 90 05 00 	mov    0x590(%rcx,%rdi,8),%rcx
  6fb302:	00 
  6fb303:	eb 85                	jmp    6fb28a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x427a>
  6fb305:	83 7c 11 40 02       	cmpl   $0x2,0x40(%rcx,%rdx,1)
  6fb30a:	0f 84 c3 00 00 00    	je     6fb3d3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43c3>
  6fb310:	f2 0f 10 84 11 88 00 	movsd  0x88(%rcx,%rdx,1),%xmm0
  6fb317:	00 00 
  6fb319:	66 0f 28 8c 24 50 03 	movapd 0x350(%rsp),%xmm1
  6fb320:	00 00 
  6fb322:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
  6fb326:	0f 85 a7 00 00 00    	jne    6fb3d3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43c3>
  6fb32c:	0f 8a a1 00 00 00    	jp     6fb3d3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43c3>
  6fb332:	f2 0f 10 84 11 90 00 	movsd  0x90(%rcx,%rdx,1),%xmm0
  6fb339:	00 00 
  6fb33b:	66 0f 15 c9          	unpckhpd %xmm1,%xmm1
  6fb33f:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
  6fb343:	0f 85 8a 00 00 00    	jne    6fb3d3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43c3>
  6fb349:	0f 8a 84 00 00 00    	jp     6fb3d3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43c3>
  6fb34f:	f2 0f 10 84 11 98 00 	movsd  0x98(%rcx,%rdx,1),%xmm0
  6fb356:	00 00 
  6fb358:	66 0f 28 8c 24 80 00 	movapd 0x80(%rsp),%xmm1
  6fb35f:	00 00 
  6fb361:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
  6fb365:	75 6c                	jne    6fb3d3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43c3>
  6fb367:	7a 6a                	jp     6fb3d3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43c3>
  6fb369:	f2 0f 10 84 11 a0 00 	movsd  0xa0(%rcx,%rdx,1),%xmm0
  6fb370:	00 00 
  6fb372:	66 0f 15 c9          	unpckhpd %xmm1,%xmm1
  6fb376:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
  6fb37a:	75 57                	jne    6fb3d3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43c3>
  6fb37c:	7a 55                	jp     6fb3d3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43c3>
  6fb37e:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  6fb383:	48 39 b4 11 80 00 00 	cmp    %rsi,0x80(%rcx,%rdx,1)
  6fb38a:	00 
  6fb38b:	75 46                	jne    6fb3d3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43c3>
  6fb38d:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  6fb392:	48 39 74 11 60       	cmp    %rsi,0x60(%rcx,%rdx,1)
  6fb397:	75 3a                	jne    6fb3d3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43c3>
  6fb399:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  6fb39e:	48 39 74 11 68       	cmp    %rsi,0x68(%rcx,%rdx,1)
  6fb3a3:	75 2e                	jne    6fb3d3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43c3>
  6fb3a5:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  6fb3aa:	48 39 74 11 70       	cmp    %rsi,0x70(%rcx,%rdx,1)
  6fb3af:	75 22                	jne    6fb3d3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43c3>
  6fb3b1:	48 8b b4 24 28 02 00 	mov    0x228(%rsp),%rsi
  6fb3b8:	00 
  6fb3b9:	48 39 74 11 78       	cmp    %rsi,0x78(%rcx,%rdx,1)
  6fb3be:	75 13                	jne    6fb3d3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43c3>
  6fb3c0:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  6fb3c7:	00 
  6fb3c8:	48 39 84 11 a8 00 00 	cmp    %rax,0xa8(%rcx,%rdx,1)
  6fb3cf:	00 
  6fb3d0:	0f 95 c0             	setne  %al
  6fb3d3:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
  6fb3da:	00 
  6fb3db:	48 8b 94 24 80 01 00 	mov    0x180(%rsp),%rdx
  6fb3e2:	00 
  6fb3e3:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  6fb3e7:	48 8b 0c d1          	mov    (%rcx,%rdx,8),%rcx
  6fb3eb:	48 89 8c 24 08 05 00 	mov    %rcx,0x508(%rsp)
  6fb3f2:	00 
  6fb3f3:	48 8b 0c 24          	mov    (%rsp),%rcx
  6fb3f7:	08 81 4b 07 00 00    	or     %al,0x74b(%rcx)
  6fb3fd:	4d 85 ff             	test   %r15,%r15
  6fb400:	0f 84 72 02 00 00    	je     6fb678 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4668>
  6fb406:	49 c1 e7 05          	shl    $0x5,%r15
  6fb40a:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
  6fb40f:	4d 01 ef             	add    %r13,%r15
  6fb412:	eb 33                	jmp    6fb447 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4437>
  6fb414:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fb41b:	00 00 00 00 00 
  6fb420:	0f 10 84 24 a0 01 00 	movups 0x1a0(%rsp),%xmm0
  6fb427:	00 
  6fb428:	0f 10 8c 24 b0 01 00 	movups 0x1b0(%rsp),%xmm1
  6fb42f:	00 
  6fb430:	0f 11 4c 38 f0       	movups %xmm1,-0x10(%rax,%rdi,1)
  6fb435:	0f 11 44 38 e0       	movups %xmm0,-0x20(%rax,%rdi,1)
  6fb43a:	49 83 c5 20          	add    $0x20,%r13
  6fb43e:	4d 39 fd             	cmp    %r15,%r13
  6fb441:	0f 84 31 02 00 00    	je     6fb678 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4668>
  6fb447:	49 8b 7d 00          	mov    0x0(%r13),%rdi
  6fb44b:	48 8b b4 24 98 01 00 	mov    0x198(%rsp),%rsi
  6fb452:	00 
  6fb453:	48 39 f7             	cmp    %rsi,%rdi
  6fb456:	0f 83 f7 24 00 00    	jae    6fd953 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6943>
  6fb45c:	4d 8b 65 08          	mov    0x8(%r13),%r12
  6fb460:	41 8b 6d 10          	mov    0x10(%r13),%ebp
  6fb464:	f2 41 0f 10 45 14    	movsd  0x14(%r13),%xmm0
  6fb46a:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  6fb46f:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  6fb476:	00 
  6fb477:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  6fb47b:	4c 8b 34 c8          	mov    (%rax,%rcx,8),%r14
  6fb47f:	48 8b 04 24          	mov    (%rsp),%rax
  6fb483:	48 8b 80 60 06 00 00 	mov    0x660(%rax),%rax
  6fb48a:	48 85 c0             	test   %rax,%rax
  6fb48d:	0f 84 b2 00 00 00    	je     6fb545 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4535>
  6fb493:	48 8b 0c 24          	mov    (%rsp),%rcx
  6fb497:	48 8b 89 68 06 00 00 	mov    0x668(%rcx),%rcx
  6fb49e:	0f b7 b8 c2 01 00 00 	movzwl 0x1c2(%rax),%edi
  6fb4a5:	41 89 f8             	mov    %edi,%r8d
  6fb4a8:	41 c1 e0 05          	shl    $0x5,%r8d
  6fb4ac:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6fb4b3:	31 f6                	xor    %esi,%esi
  6fb4b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6fb4bc:	00 00 00 00 
  6fb4c0:	49 39 f0             	cmp    %rsi,%r8
  6fb4c3:	74 3b                	je     6fb500 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x44f0>
  6fb4c5:	4c 3b b4 d0 70 01 00 	cmp    0x170(%rax,%rdx,8),%r14
  6fb4cc:	00 
  6fb4cd:	41 0f 97 c1          	seta   %r9b
  6fb4d1:	41 80 d9 00          	sbb    $0x0,%r9b
  6fb4d5:	48 83 c6 20          	add    $0x20,%rsi
  6fb4d9:	48 ff c2             	inc    %rdx
  6fb4dc:	41 80 f9 01          	cmp    $0x1,%r9b
  6fb4e0:	74 de                	je     6fb4c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x44b0>
  6fb4e2:	41 0f b6 f9          	movzbl %r9b,%edi
  6fb4e6:	85 ff                	test   %edi,%edi
  6fb4e8:	74 36                	je     6fb520 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4510>
  6fb4ea:	48 83 e9 01          	sub    $0x1,%rcx
  6fb4ee:	73 19                	jae    6fb509 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x44f9>
  6fb4f0:	eb 53                	jmp    6fb545 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4535>
  6fb4f2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fb4f9:	1f 84 00 00 00 00 00 
  6fb500:	48 89 fa             	mov    %rdi,%rdx
  6fb503:	48 83 e9 01          	sub    $0x1,%rcx
  6fb507:	72 3c                	jb     6fb545 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4535>
  6fb509:	48 8b 84 d0 c8 01 00 	mov    0x1c8(%rax,%rdx,8),%rax
  6fb510:	00 
  6fb511:	eb 8b                	jmp    6fb49e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x448e>
  6fb513:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fb51a:	84 00 00 00 00 00 
  6fb520:	f3 0f 10 44 30 f4    	movss  -0xc(%rax,%rsi,1),%xmm0
  6fb526:	0f 2e 44 24 20       	ucomiss 0x20(%rsp),%xmm0
  6fb52b:	75 18                	jne    6fb545 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4535>
  6fb52d:	7a 16                	jp     6fb545 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4535>
  6fb52f:	f3 0f 10 44 30 f8    	movss  -0x8(%rax,%rsi,1),%xmm0
  6fb535:	0f 28 4c 24 20       	movaps 0x20(%rsp),%xmm1
  6fb53a:	0f c6 c9 55          	shufps $0x55,%xmm1,%xmm1
  6fb53e:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6fb541:	75 02                	jne    6fb545 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4535>
  6fb543:	7b 18                	jnp    6fb55d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x454d>
  6fb545:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  6fb54a:	4c 89 f6             	mov    %r14,%rsi
  6fb54d:	e8 0e e0 00 00       	call   709560 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6fb552:	48 8b 04 24          	mov    (%rsp),%rax
  6fb556:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6fb55d:	48 89 9c 24 a0 01 00 	mov    %rbx,0x1a0(%rsp)
  6fb564:	00 
  6fb565:	4c 89 a4 24 a8 01 00 	mov    %r12,0x1a8(%rsp)
  6fb56c:	00 
  6fb56d:	89 ac 24 b0 01 00 00 	mov    %ebp,0x1b0(%rsp)
  6fb574:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
  6fb579:	0f 13 84 24 b4 01 00 	movlps %xmm0,0x1b4(%rsp)
  6fb580:	00 
  6fb581:	c6 84 24 bc 01 00 00 	movb   $0x1,0x1bc(%rsp)
  6fb588:	01 
  6fb589:	48 8b 84 24 f8 06 00 	mov    0x6f8(%rsp),%rax
  6fb590:	00 
  6fb591:	48 85 c0             	test   %rax,%rax
  6fb594:	0f 84 86 00 00 00    	je     6fb620 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4610>
  6fb59a:	48 8b 8c 24 00 07 00 	mov    0x700(%rsp),%rcx
  6fb5a1:	00 
  6fb5a2:	0f b7 b0 c2 01 00 00 	movzwl 0x1c2(%rax),%esi
  6fb5a9:	41 89 f0             	mov    %esi,%r8d
  6fb5ac:	41 c1 e0 05          	shl    $0x5,%r8d
  6fb5b0:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6fb5b7:	31 ff                	xor    %edi,%edi
  6fb5b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6fb5c0:	49 39 f8             	cmp    %rdi,%r8
  6fb5c3:	74 3b                	je     6fb600 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x45f0>
  6fb5c5:	4c 3b b4 d0 70 01 00 	cmp    0x170(%rax,%rdx,8),%r14
  6fb5cc:	00 
  6fb5cd:	41 0f 97 c1          	seta   %r9b
  6fb5d1:	41 80 d9 00          	sbb    $0x0,%r9b
  6fb5d5:	48 83 c7 20          	add    $0x20,%rdi
  6fb5d9:	48 ff c2             	inc    %rdx
  6fb5dc:	41 80 f9 01          	cmp    $0x1,%r9b
  6fb5e0:	74 de                	je     6fb5c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x45b0>
  6fb5e2:	41 0f b6 f1          	movzbl %r9b,%esi
  6fb5e6:	85 f6                	test   %esi,%esi
  6fb5e8:	0f 84 32 fe ff ff    	je     6fb420 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4410>
  6fb5ee:	48 83 e9 01          	sub    $0x1,%rcx
  6fb5f2:	73 15                	jae    6fb609 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x45f9>
  6fb5f4:	eb 2c                	jmp    6fb622 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4612>
  6fb5f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6fb5fd:	00 00 00 
  6fb600:	48 89 f2             	mov    %rsi,%rdx
  6fb603:	48 83 e9 01          	sub    $0x1,%rcx
  6fb607:	72 19                	jb     6fb622 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4612>
  6fb609:	48 8b 84 d0 c8 01 00 	mov    0x1c8(%rax,%rdx,8),%rax
  6fb610:	00 
  6fb611:	eb 8f                	jmp    6fb5a2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4592>
  6fb613:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fb61a:	84 00 00 00 00 00 
  6fb620:	31 c0                	xor    %eax,%eax
  6fb622:	48 8d 8c 24 f8 06 00 	lea    0x6f8(%rsp),%rcx
  6fb629:	00 
  6fb62a:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  6fb631:	00 
  6fb632:	4c 89 b4 24 98 00 00 	mov    %r14,0x98(%rsp)
  6fb639:	00 
  6fb63a:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6fb641:	00 
  6fb642:	48 c7 84 24 a8 00 00 	movq   $0x0,0xa8(%rsp)
  6fb649:	00 00 00 00 00 
  6fb64e:	48 89 94 24 b0 00 00 	mov    %rdx,0xb0(%rsp)
  6fb655:	00 
  6fb656:	48 8d bc 24 c0 02 00 	lea    0x2c0(%rsp),%rdi
  6fb65d:	00 
  6fb65e:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6fb665:	00 
  6fb666:	48 8d 94 24 a0 01 00 	lea    0x1a0(%rsp),%rdx
  6fb66d:	00 
  6fb66e:	e8 cd 66 01 00       	call   711d40 <<alloc::collections::btree::map::entry::VacantEntry<u64, gpui::runtime::list::ListRow>>::insert_entry>
  6fb673:	e9 c2 fd ff ff       	jmp    6fb43a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x442a>
  6fb678:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  6fb67d:	48 85 f6             	test   %rsi,%rsi
  6fb680:	74 14                	je     6fb696 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4686>
  6fb682:	48 c1 e6 05          	shl    $0x5,%rsi
  6fb686:	ba 08 00 00 00       	mov    $0x8,%edx
  6fb68b:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  6fb690:	ff 15 12 00 39 00    	call   *0x390012(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fb696:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  6fb69b:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  6fb6a2:	00 
  6fb6a3:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  6fb6a8:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  6fb6af:	00 
  6fb6b0:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  6fb6b5:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  6fb6bc:	00 
  6fb6bd:	48 8b 84 24 28 02 00 	mov    0x228(%rsp),%rax
  6fb6c4:	00 
  6fb6c5:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  6fb6cc:	00 
  6fb6cd:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fb6d2:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  6fb6d9:	00 
  6fb6da:	0f 28 84 24 50 03 00 	movaps 0x350(%rsp),%xmm0
  6fb6e1:	00 
  6fb6e2:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
  6fb6e9:	00 
  6fb6ea:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  6fb6f1:	00 
  6fb6f2:	0f 11 84 24 e8 00 00 	movups %xmm0,0xe8(%rsp)
  6fb6f9:	00 
  6fb6fa:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  6fb701:	00 
  6fb702:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
  6fb709:	00 
  6fb70a:	48 8b 84 24 10 05 00 	mov    0x510(%rsp),%rax
  6fb711:	00 
  6fb712:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6fb719:	00 
  6fb71a:	66 0f 28 84 24 40 04 	movapd 0x440(%rsp),%xmm0
  6fb721:	00 00 
  6fb723:	48 8d 84 24 98 00 00 	lea    0x98(%rsp),%rax
  6fb72a:	00 
  6fb72b:	66 0f 11 00          	movupd %xmm0,(%rax)
  6fb72f:	48 8b 84 24 08 05 00 	mov    0x508(%rsp),%rax
  6fb736:	00 
  6fb737:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  6fb73e:	00 
  6fb73f:	48 8b 84 24 20 05 00 	mov    0x520(%rsp),%rax
  6fb746:	00 
  6fb747:	48 85 c0             	test   %rax,%rax
  6fb74a:	4c 8b b4 24 98 02 00 	mov    0x298(%rsp),%r14
  6fb751:	00 
  6fb752:	0f 84 d2 00 00 00    	je     6fb82a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x481a>
  6fb758:	48 8b 8c 24 28 05 00 	mov    0x528(%rsp),%rcx
  6fb75f:	00 
  6fb760:	0f b7 b8 8a 05 00 00 	movzwl 0x58a(%rax),%edi
  6fb767:	48 8d 70 40          	lea    0x40(%rax),%rsi
  6fb76b:	41 89 f8             	mov    %edi,%r8d
  6fb76e:	41 c1 e0 04          	shl    $0x4,%r8d
  6fb772:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6fb779:	45 31 c9             	xor    %r9d,%r9d
  6fb77c:	eb 16                	jmp    6fb794 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4784>
  6fb77e:	66 90                	xchg   %ax,%ax
  6fb780:	41 f6 da             	neg    %r10b
  6fb783:	48 83 c6 70          	add    $0x70,%rsi
  6fb787:	48 ff c2             	inc    %rdx
  6fb78a:	49 83 c1 10          	add    $0x10,%r9
  6fb78e:	41 80 fa 01          	cmp    $0x1,%r10b
  6fb792:	75 1e                	jne    6fb7b2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x47a2>
  6fb794:	4d 39 c8             	cmp    %r9,%r8
  6fb797:	74 23                	je     6fb7bc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x47ac>
  6fb799:	46 0f b6 14 08       	movzbl (%rax,%r9,1),%r10d
  6fb79e:	45 84 d2             	test   %r10b,%r10b
  6fb7a1:	75 dd                	jne    6fb780 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4770>
  6fb7a3:	4a 3b 5c 08 08       	cmp    0x8(%rax,%r9,1),%rbx
  6fb7a8:	41 0f 97 c2          	seta   %r10b
  6fb7ac:	41 80 da 00          	sbb    $0x0,%r10b
  6fb7b0:	eb d1                	jmp    6fb783 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4773>
  6fb7b2:	41 0f b6 fa          	movzbl %r10b,%edi
  6fb7b6:	85 ff                	test   %edi,%edi
  6fb7b8:	75 05                	jne    6fb7bf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x47af>
  6fb7ba:	eb 13                	jmp    6fb7cf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x47bf>
  6fb7bc:	48 89 fa             	mov    %rdi,%rdx
  6fb7bf:	48 83 e9 01          	sub    $0x1,%rcx
  6fb7c3:	72 67                	jb     6fb82c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x481c>
  6fb7c5:	48 8b 84 d0 90 05 00 	mov    0x590(%rax,%rdx,8),%rax
  6fb7cc:	00 
  6fb7cd:	eb 91                	jmp    6fb760 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4750>
  6fb7cf:	0f 10 84 24 f0 00 00 	movups 0xf0(%rsp),%xmm0
  6fb7d6:	00 
  6fb7d7:	0f 11 46 60          	movups %xmm0,0x60(%rsi)
  6fb7db:	0f 10 84 24 e0 00 00 	movups 0xe0(%rsp),%xmm0
  6fb7e2:	00 
  6fb7e3:	0f 11 46 50          	movups %xmm0,0x50(%rsi)
  6fb7e7:	0f 10 84 24 d0 00 00 	movups 0xd0(%rsp),%xmm0
  6fb7ee:	00 
  6fb7ef:	0f 11 46 40          	movups %xmm0,0x40(%rsi)
  6fb7f3:	66 0f 10 84 24 90 00 	movupd 0x90(%rsp),%xmm0
  6fb7fa:	00 00 
  6fb7fc:	66 0f 10 8c 24 a0 00 	movupd 0xa0(%rsp),%xmm1
  6fb803:	00 00 
  6fb805:	f3 0f 6f 94 24 b0 00 	movdqu 0xb0(%rsp),%xmm2
  6fb80c:	00 00 
  6fb80e:	0f 10 9c 24 c0 00 00 	movups 0xc0(%rsp),%xmm3
  6fb815:	00 
  6fb816:	0f 11 5e 30          	movups %xmm3,0x30(%rsi)
  6fb81a:	f3 0f 7f 56 20       	movdqu %xmm2,0x20(%rsi)
  6fb81f:	66 0f 11 4e 10       	movupd %xmm1,0x10(%rsi)
  6fb824:	66 0f 11 06          	movupd %xmm0,(%rsi)
  6fb828:	eb 5f                	jmp    6fb889 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4879>
  6fb82a:	31 c0                	xor    %eax,%eax
  6fb82c:	48 c7 84 24 c0 02 00 	movq   $0x0,0x2c0(%rsp)
  6fb833:	00 00 00 00 00 
  6fb838:	48 89 9c 24 c8 02 00 	mov    %rbx,0x2c8(%rsp)
  6fb83f:	00 
  6fb840:	48 8d 8c 24 20 05 00 	lea    0x520(%rsp),%rcx
  6fb847:	00 
  6fb848:	48 89 8c 24 d0 02 00 	mov    %rcx,0x2d0(%rsp)
  6fb84f:	00 
  6fb850:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
  6fb857:	00 
  6fb858:	48 c7 84 24 e0 02 00 	movq   $0x0,0x2e0(%rsp)
  6fb85f:	00 00 00 00 00 
  6fb864:	48 89 94 24 e8 02 00 	mov    %rdx,0x2e8(%rsp)
  6fb86b:	00 
  6fb86c:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6fb873:	00 
  6fb874:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
  6fb87b:	00 
  6fb87c:	48 8d 94 24 90 00 00 	lea    0x90(%rsp),%rdx
  6fb883:	00 
  6fb884:	e8 77 61 01 00       	call   711a00 <<alloc::collections::btree::map::entry::VacantEntry<gpui::runtime::scroll::ViewportKey, gpui::runtime::scroll::ViewportState>>::insert_entry>
  6fb889:	48 8b 8c 24 38 02 00 	mov    0x238(%rsp),%rcx
  6fb890:	00 
  6fb891:	48 8b b4 24 78 01 00 	mov    0x178(%rsp),%rsi
  6fb898:	00 
  6fb899:	48 85 f6             	test   %rsi,%rsi
  6fb89c:	0f 84 d2 f8 ff ff    	je     6fb174 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4164>
  6fb8a2:	48 c1 e6 03          	shl    $0x3,%rsi
  6fb8a6:	ba 08 00 00 00       	mov    $0x8,%edx
  6fb8ab:	48 8b bc 24 f0 03 00 	mov    0x3f0(%rsp),%rdi
  6fb8b2:	00 
  6fb8b3:	ff 15 ef fd 38 00    	call   *0x38fdef(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fb8b9:	48 8b 8c 24 38 02 00 	mov    0x238(%rsp),%rcx
  6fb8c0:	00 
  6fb8c1:	e9 ae f8 ff ff       	jmp    6fb174 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4164>
  6fb8c6:	4c 8b a4 24 20 02 00 	mov    0x220(%rsp),%r12
  6fb8cd:	00 
  6fb8ce:	4c 89 a4 24 68 03 00 	mov    %r12,0x368(%rsp)
  6fb8d5:	00 
  6fb8d6:	48 8b b4 24 20 02 00 	mov    0x220(%rsp),%rsi
  6fb8dd:	00 
  6fb8de:	48 89 f0             	mov    %rsi,%rax
  6fb8e1:	4c 29 e0             	sub    %r12,%rax
  6fb8e4:	48 c1 e8 03          	shr    $0x3,%rax
  6fb8e8:	48 b9 31 0c c3 30 0c 	movabs $0xc30c30c30c30c31,%rcx
  6fb8ef:	c3 30 0c 
  6fb8f2:	48 f7 e1             	mul    %rcx
  6fb8f5:	4c 39 e6             	cmp    %r12,%rsi
  6fb8f8:	74 59                	je     6fb953 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4943>
  6fb8fa:	48 89 d3             	mov    %rdx,%rbx
  6fb8fd:	49 81 c4 88 00 00 00 	add    $0x88,%r12
  6fb904:	4c 8b 35 9d fd 38 00 	mov    0x38fd9d(%rip),%r14        # a8b6a8 <_DYNAMIC+0x250>
  6fb90b:	eb 0f                	jmp    6fb91c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x490c>
  6fb90d:	0f 1f 00             	nopl   (%rax)
  6fb910:	49 81 c4 a8 00 00 00 	add    $0xa8,%r12
  6fb917:	48 ff cb             	dec    %rbx
  6fb91a:	74 37                	je     6fb953 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4943>
  6fb91c:	49 8b 74 24 90       	mov    -0x70(%r12),%rsi
  6fb921:	48 85 f6             	test   %rsi,%rsi
  6fb924:	74 11                	je     6fb937 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4927>
  6fb926:	49 8b 7c 24 98       	mov    -0x68(%r12),%rdi
  6fb92b:	48 c1 e6 03          	shl    $0x3,%rsi
  6fb92f:	ba 08 00 00 00       	mov    $0x8,%edx
  6fb934:	41 ff d6             	call   *%r14
  6fb937:	49 8b 74 24 f8       	mov    -0x8(%r12),%rsi
  6fb93c:	48 85 f6             	test   %rsi,%rsi
  6fb93f:	74 cf                	je     6fb910 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4900>
  6fb941:	49 8b 3c 24          	mov    (%r12),%rdi
  6fb945:	48 c1 e6 05          	shl    $0x5,%rsi
  6fb949:	ba 08 00 00 00       	mov    $0x8,%edx
  6fb94e:	41 ff d6             	call   *%r14
  6fb951:	eb bd                	jmp    6fb910 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4900>
  6fb953:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  6fb958:	48 85 c0             	test   %rax,%rax
  6fb95b:	74 1a                	je     6fb977 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4967>
  6fb95d:	48 69 f0 a8 00 00 00 	imul   $0xa8,%rax,%rsi
  6fb964:	ba 08 00 00 00       	mov    $0x8,%edx
  6fb969:	48 8b bc 24 18 02 00 	mov    0x218(%rsp),%rdi
  6fb970:	00 
  6fb971:	ff 15 31 fd 38 00    	call   *0x38fd31(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fb977:	48 8b 84 24 38 05 00 	mov    0x538(%rsp),%rax
  6fb97e:	00 
  6fb97f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fb984:	48 8b 84 24 40 05 00 	mov    0x540(%rsp),%rax
  6fb98b:	00 
  6fb98c:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6fb991:	48 8b ac 24 48 05 00 	mov    0x548(%rsp),%rbp
  6fb998:	00 
  6fb999:	48 85 ed             	test   %rbp,%rbp
  6fb99c:	0f 84 f7 02 00 00    	je     6fbc99 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c89>
  6fb9a2:	48 c1 e5 04          	shl    $0x4,%rbp
  6fb9a6:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
  6fb9ab:	48 01 dd             	add    %rbx,%rbp
  6fb9ae:	4c 8d ac 24 90 00 00 	lea    0x90(%rsp),%r13
  6fb9b5:	00 
  6fb9b6:	eb 66                	jmp    6fba1e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4a0e>
  6fb9b8:	0f 10 84 24 f0 00 00 	movups 0xf0(%rsp),%xmm0
  6fb9bf:	00 
  6fb9c0:	0f 11 47 60          	movups %xmm0,0x60(%rdi)
  6fb9c4:	0f 10 84 24 e0 00 00 	movups 0xe0(%rsp),%xmm0
  6fb9cb:	00 
  6fb9cc:	0f 11 47 50          	movups %xmm0,0x50(%rdi)
  6fb9d0:	0f 10 84 24 d0 00 00 	movups 0xd0(%rsp),%xmm0
  6fb9d7:	00 
  6fb9d8:	0f 11 47 40          	movups %xmm0,0x40(%rdi)
  6fb9dc:	f3 0f 6f 84 24 90 00 	movdqu 0x90(%rsp),%xmm0
  6fb9e3:	00 00 
  6fb9e5:	f3 0f 6f 8c 24 a0 00 	movdqu 0xa0(%rsp),%xmm1
  6fb9ec:	00 00 
  6fb9ee:	f3 0f 6f 94 24 b0 00 	movdqu 0xb0(%rsp),%xmm2
  6fb9f5:	00 00 
  6fb9f7:	0f 10 9c 24 c0 00 00 	movups 0xc0(%rsp),%xmm3
  6fb9fe:	00 
  6fb9ff:	0f 11 5f 30          	movups %xmm3,0x30(%rdi)
  6fba03:	f3 0f 7f 57 20       	movdqu %xmm2,0x20(%rdi)
  6fba08:	f3 0f 7f 4f 10       	movdqu %xmm1,0x10(%rdi)
  6fba0d:	f3 0f 7f 07          	movdqu %xmm0,(%rdi)
  6fba11:	48 83 c3 10          	add    $0x10,%rbx
  6fba15:	48 39 eb             	cmp    %rbp,%rbx
  6fba18:	0f 84 7b 02 00 00    	je     6fbc99 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c89>
  6fba1e:	48 8b 3b             	mov    (%rbx),%rdi
  6fba21:	48 8b b4 24 98 01 00 	mov    0x198(%rsp),%rsi
  6fba28:	00 
  6fba29:	48 39 f7             	cmp    %rsi,%rdi
  6fba2c:	0f 83 a7 1f 00 00    	jae    6fd9d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x69c9>
  6fba32:	0f b6 4b 08          	movzbl 0x8(%rbx),%ecx
  6fba36:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  6fba3d:	00 
  6fba3e:	48 8d 14 7f          	lea    (%rdi,%rdi,2),%rdx
  6fba42:	48 8b 04 d0          	mov    (%rax,%rdx,8),%rax
  6fba46:	48 8b 94 24 38 02 00 	mov    0x238(%rsp),%rdx
  6fba4d:	00 
  6fba4e:	48 8b 12             	mov    (%rdx),%rdx
  6fba51:	48 85 d2             	test   %rdx,%rdx
  6fba54:	0f 84 22 01 00 00    	je     6fbb7c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b6c>
  6fba5a:	48 8b 34 24          	mov    (%rsp),%rsi
  6fba5e:	48 8b b6 50 06 00 00 	mov    0x650(%rsi),%rsi
  6fba65:	48 89 f7             	mov    %rsi,%rdi
  6fba68:	49 89 d0             	mov    %rdx,%r8
  6fba6b:	45 0f b7 b0 8a 05 00 	movzwl 0x58a(%r8),%r14d
  6fba72:	00 
  6fba73:	4d 8d 48 48          	lea    0x48(%r8),%r9
  6fba77:	45 89 f3             	mov    %r14d,%r11d
  6fba7a:	41 c1 e3 04          	shl    $0x4,%r11d
  6fba7e:	49 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%r10
  6fba85:	45 31 ff             	xor    %r15d,%r15d
  6fba88:	eb 24                	jmp    6fbaae <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4a9e>
  6fba8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  6fba90:	4b 3b 44 38 08       	cmp    0x8(%r8,%r15,1),%rax
  6fba95:	41 0f 97 c4          	seta   %r12b
  6fba99:	41 80 dc 00          	sbb    $0x0,%r12b
  6fba9d:	49 83 c1 70          	add    $0x70,%r9
  6fbaa1:	49 ff c2             	inc    %r10
  6fbaa4:	49 83 c7 10          	add    $0x10,%r15
  6fbaa8:	41 80 fc 01          	cmp    $0x1,%r12b
  6fbaac:	75 12                	jne    6fbac0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4ab0>
  6fbaae:	4d 39 fb             	cmp    %r15,%r11
  6fbab1:	74 18                	je     6fbacb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4abb>
  6fbab3:	4b 83 3c 38 00       	cmpq   $0x0,(%r8,%r15,1)
  6fbab8:	75 d6                	jne    6fba90 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4a80>
  6fbaba:	41 b4 01             	mov    $0x1,%r12b
  6fbabd:	eb de                	jmp    6fba9d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4a8d>
  6fbabf:	90                   	nop
  6fbac0:	45 0f b6 dc          	movzbl %r12b,%r11d
  6fbac4:	45 85 db             	test   %r11d,%r11d
  6fbac7:	75 05                	jne    6fbace <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4abe>
  6fbac9:	eb 17                	jmp    6fbae2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4ad2>
  6fbacb:	4d 89 f2             	mov    %r14,%r10
  6fbace:	48 83 ef 01          	sub    $0x1,%rdi
  6fbad2:	0f 82 b8 01 00 00    	jb     6fbc90 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c80>
  6fbad8:	4f 8b 84 d0 90 05 00 	mov    0x590(%r8,%r10,8),%r8
  6fbadf:	00 
  6fbae0:	eb 89                	jmp    6fba6b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4a5b>
  6fbae2:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fbae6:	41 83 79 f8 02       	cmpl   $0x2,-0x8(%r9)
  6fbaeb:	75 13                	jne    6fbb00 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4af0>
  6fbaed:	f3 41 0f 6f 01       	movdqu (%r9),%xmm0
  6fbaf2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fbaf9:	1f 84 00 00 00 00 00 
  6fbb00:	44 0f b7 8a 8a 05 00 	movzwl 0x58a(%rdx),%r9d
  6fbb07:	00 
  6fbb08:	4c 8d 42 40          	lea    0x40(%rdx),%r8
  6fbb0c:	45 89 ca             	mov    %r9d,%r10d
  6fbb0f:	41 c1 e2 04          	shl    $0x4,%r10d
  6fbb13:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
  6fbb1a:	45 31 db             	xor    %r11d,%r11d
  6fbb1d:	eb 1f                	jmp    6fbb3e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b2e>
  6fbb1f:	90                   	nop
  6fbb20:	4a 3b 44 1a 08       	cmp    0x8(%rdx,%r11,1),%rax
  6fbb25:	41 0f 97 c6          	seta   %r14b
  6fbb29:	41 80 de 00          	sbb    $0x0,%r14b
  6fbb2d:	49 83 c0 70          	add    $0x70,%r8
  6fbb31:	48 ff c7             	inc    %rdi
  6fbb34:	49 83 c3 10          	add    $0x10,%r11
  6fbb38:	41 80 fe 01          	cmp    $0x1,%r14b
  6fbb3c:	75 12                	jne    6fbb50 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b40>
  6fbb3e:	4d 39 da             	cmp    %r11,%r10
  6fbb41:	74 18                	je     6fbb5b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b4b>
  6fbb43:	4a 83 3c 1a 00       	cmpq   $0x0,(%rdx,%r11,1)
  6fbb48:	75 d6                	jne    6fbb20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b10>
  6fbb4a:	41 b6 01             	mov    $0x1,%r14b
  6fbb4d:	eb de                	jmp    6fbb2d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b1d>
  6fbb4f:	90                   	nop
  6fbb50:	45 0f b6 ce          	movzbl %r14b,%r9d
  6fbb54:	45 85 c9             	test   %r9d,%r9d
  6fbb57:	75 05                	jne    6fbb5e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b4e>
  6fbb59:	eb 13                	jmp    6fbb6e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b5e>
  6fbb5b:	4c 89 cf             	mov    %r9,%rdi
  6fbb5e:	48 83 ee 01          	sub    $0x1,%rsi
  6fbb62:	72 1c                	jb     6fbb80 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b70>
  6fbb64:	48 8b 94 fa 90 05 00 	mov    0x590(%rdx,%rdi,8),%rdx
  6fbb6b:	00 
  6fbb6c:	eb 92                	jmp    6fbb00 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4af0>
  6fbb6e:	41 83 38 02          	cmpl   $0x2,(%r8)
  6fbb72:	75 0c                	jne    6fbb80 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b70>
  6fbb74:	41 38 48 18          	cmp    %cl,0x18(%r8)
  6fbb78:	75 06                	jne    6fbb80 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b70>
  6fbb7a:	eb 0f                	jmp    6fbb8b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b7b>
  6fbb7c:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fbb80:	48 8b 14 24          	mov    (%rsp),%rdx
  6fbb84:	c6 82 4b 07 00 00 01 	movb   $0x1,0x74b(%rdx)
  6fbb8b:	f3 0f 7f 84 24 98 00 	movdqu %xmm0,0x98(%rsp)
  6fbb92:	00 00 
  6fbb94:	88 8c 24 a8 00 00 00 	mov    %cl,0xa8(%rsp)
  6fbb9b:	48 c7 84 24 90 00 00 	movq   $0x2,0x90(%rsp)
  6fbba2:	00 02 00 00 00 
  6fbba7:	48 8b 8c 24 20 05 00 	mov    0x520(%rsp),%rcx
  6fbbae:	00 
  6fbbaf:	48 85 c9             	test   %rcx,%rcx
  6fbbb2:	74 7d                	je     6fbc31 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c21>
  6fbbb4:	48 8b 94 24 28 05 00 	mov    0x528(%rsp),%rdx
  6fbbbb:	00 
  6fbbbc:	44 0f b7 81 8a 05 00 	movzwl 0x58a(%rcx),%r8d
  6fbbc3:	00 
  6fbbc4:	48 8d 79 40          	lea    0x40(%rcx),%rdi
  6fbbc8:	45 89 c1             	mov    %r8d,%r9d
  6fbbcb:	41 c1 e1 04          	shl    $0x4,%r9d
  6fbbcf:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
  6fbbd6:	45 31 d2             	xor    %r10d,%r10d
  6fbbd9:	eb 23                	jmp    6fbbfe <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4bee>
  6fbbdb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6fbbe0:	4a 3b 44 11 08       	cmp    0x8(%rcx,%r10,1),%rax
  6fbbe5:	41 0f 97 c3          	seta   %r11b
  6fbbe9:	41 80 db 00          	sbb    $0x0,%r11b
  6fbbed:	48 83 c7 70          	add    $0x70,%rdi
  6fbbf1:	48 ff c6             	inc    %rsi
  6fbbf4:	49 83 c2 10          	add    $0x10,%r10
  6fbbf8:	41 80 fb 01          	cmp    $0x1,%r11b
  6fbbfc:	75 12                	jne    6fbc10 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c00>
  6fbbfe:	4d 39 d1             	cmp    %r10,%r9
  6fbc01:	74 1b                	je     6fbc1e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c0e>
  6fbc03:	4a 83 3c 11 00       	cmpq   $0x0,(%rcx,%r10,1)
  6fbc08:	75 d6                	jne    6fbbe0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4bd0>
  6fbc0a:	41 b3 01             	mov    $0x1,%r11b
  6fbc0d:	eb de                	jmp    6fbbed <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4bdd>
  6fbc0f:	90                   	nop
  6fbc10:	45 0f b6 c3          	movzbl %r11b,%r8d
  6fbc14:	45 85 c0             	test   %r8d,%r8d
  6fbc17:	75 08                	jne    6fbc21 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c11>
  6fbc19:	e9 9a fd ff ff       	jmp    6fb9b8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x49a8>
  6fbc1e:	4c 89 c6             	mov    %r8,%rsi
  6fbc21:	48 83 ea 01          	sub    $0x1,%rdx
  6fbc25:	72 0c                	jb     6fbc33 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c23>
  6fbc27:	48 8b 8c f1 90 05 00 	mov    0x590(%rcx,%rsi,8),%rcx
  6fbc2e:	00 
  6fbc2f:	eb 8b                	jmp    6fbbbc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4bac>
  6fbc31:	31 c9                	xor    %ecx,%ecx
  6fbc33:	48 c7 84 24 c0 02 00 	movq   $0x1,0x2c0(%rsp)
  6fbc3a:	00 01 00 00 00 
  6fbc3f:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
  6fbc46:	00 
  6fbc47:	48 8d 84 24 20 05 00 	lea    0x520(%rsp),%rax
  6fbc4e:	00 
  6fbc4f:	48 89 84 24 d0 02 00 	mov    %rax,0x2d0(%rsp)
  6fbc56:	00 
  6fbc57:	48 89 8c 24 d8 02 00 	mov    %rcx,0x2d8(%rsp)
  6fbc5e:	00 
  6fbc5f:	48 c7 84 24 e0 02 00 	movq   $0x0,0x2e0(%rsp)
  6fbc66:	00 00 00 00 00 
  6fbc6b:	48 89 b4 24 e8 02 00 	mov    %rsi,0x2e8(%rsp)
  6fbc72:	00 
  6fbc73:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6fbc7a:	00 
  6fbc7b:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
  6fbc82:	00 
  6fbc83:	4c 89 ea             	mov    %r13,%rdx
  6fbc86:	e8 75 5d 01 00       	call   711a00 <<alloc::collections::btree::map::entry::VacantEntry<gpui::runtime::scroll::ViewportKey, gpui::runtime::scroll::ViewportState>>::insert_entry>
  6fbc8b:	e9 81 fd ff ff       	jmp    6fba11 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4a01>
  6fbc90:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fbc94:	e9 67 fe ff ff       	jmp    6fbb00 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4af0>
  6fbc99:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  6fbc9e:	48 85 f6             	test   %rsi,%rsi
  6fbca1:	74 14                	je     6fbcb7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4ca7>
  6fbca3:	48 c1 e6 04          	shl    $0x4,%rsi
  6fbca7:	ba 08 00 00 00       	mov    $0x8,%edx
  6fbcac:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6fbcb1:	ff 15 f1 f9 38 00    	call   *0x38f9f1(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fbcb7:	48 8b 04 24          	mov    (%rsp),%rax
  6fbcbb:	4c 8d b0 40 06 00 00 	lea    0x640(%rax),%r14
  6fbcc2:	48 8b 9c 24 d0 04 00 	mov    0x4d0(%rsp),%rbx
  6fbcc9:	00 
  6fbcca:	48 85 db             	test   %rbx,%rbx
  6fbccd:	4c 89 b4 24 80 00 00 	mov    %r14,0x80(%rsp)
  6fbcd4:	00 
  6fbcd5:	75 38                	jne    6fbd0f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4cff>
  6fbcd7:	48 83 bc 24 30 05 00 	cmpq   $0x0,0x530(%rsp)
  6fbcde:	00 00 
  6fbce0:	75 2d                	jne    6fbd0f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4cff>
  6fbce2:	49 83 3e 00          	cmpq   $0x0,(%r14)
  6fbce6:	75 27                	jne    6fbd0f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4cff>
  6fbce8:	40 b5 01             	mov    $0x1,%bpl
  6fbceb:	48 83 bc 24 f8 01 00 	cmpq   $0x0,0x1f8(%rsp)
  6fbcf2:	00 00 
  6fbcf4:	0f 84 c3 0d 00 00    	je     6fcabd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5aad>
  6fbcfa:	4c 8b b4 24 90 01 00 	mov    0x190(%rsp),%r14
  6fbd01:	00 
  6fbd02:	4c 8b bc 24 98 01 00 	mov    0x198(%rsp),%r15
  6fbd09:	00 
  6fbd0a:	e9 7a 02 00 00       	jmp    6fbf89 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4f79>
  6fbd0f:	4c 89 f7             	mov    %r14,%rdi
  6fbd12:	e8 d9 58 fe ff       	call   6e15f0 <<core::option::Option<alloc::boxed::Box<gpui::runtime::metadata::Metadata>>>::get_or_insert_with::<<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#44}>>
  6fbd17:	4c 8b ac 24 c8 04 00 	mov    0x4c8(%rsp),%r13
  6fbd1e:	00 
  6fbd1f:	48 85 db             	test   %rbx,%rbx
  6fbd22:	74 0f                	je     6fbd33 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d23>
  6fbd24:	48 83 fb 01          	cmp    $0x1,%rbx
  6fbd28:	75 68                	jne    6fbd92 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d82>
  6fbd2a:	31 c0                	xor    %eax,%eax
  6fbd2c:	31 f6                	xor    %esi,%esi
  6fbd2e:	e9 af 00 00 00       	jmp    6fbde2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4dd2>
  6fbd33:	31 f6                	xor    %esi,%esi
  6fbd35:	e9 c6 00 00 00       	jmp    6fbe00 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4df0>
  6fbd3a:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
  6fbd3f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fbd44:	4c 89 60 10          	mov    %r12,0x10(%rax)
  6fbd48:	48 c7 00 20 00 00 00 	movq   $0x20,(%rax)
  6fbd4f:	48 c7 40 08 0c 00 00 	movq   $0xc,0x8(%rax)
  6fbd56:	00 
  6fbd57:	48 8b b4 24 70 02 00 	mov    0x270(%rsp),%rsi
  6fbd5e:	00 
  6fbd5f:	48 85 f6             	test   %rsi,%rsi
  6fbd62:	74 17                	je     6fbd7b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d6b>
  6fbd64:	48 8b bc 24 78 02 00 	mov    0x278(%rsp),%rdi
  6fbd6b:	00 
  6fbd6c:	48 c1 e6 04          	shl    $0x4,%rsi
  6fbd70:	ba 08 00 00 00       	mov    $0x8,%edx
  6fbd75:	ff 15 2d f9 38 00    	call   *0x38f92d(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fbd7b:	31 db                	xor    %ebx,%ebx
  6fbd7d:	48 8d bc 24 e0 07 00 	lea    0x7e0(%rsp),%rdi
  6fbd84:	00 
  6fbd85:	e8 96 b5 fe ff       	call   6e7320 <core::ptr::drop_glue::<gpui::runtime::styles::colours::Discovery>>
  6fbd8a:	45 31 ed             	xor    %r13d,%r13d
  6fbd8d:	e9 6b 14 00 00       	jmp    6fd1fd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61ed>
  6fbd92:	48 b9 fe ff ff ff ff 	movabs $0x3fffffffffffffe,%rcx
  6fbd99:	ff ff 03 
  6fbd9c:	48 21 d9             	and    %rbx,%rcx
  6fbd9f:	31 c0                	xor    %eax,%eax
  6fbda1:	4c 89 ea             	mov    %r13,%rdx
  6fbda4:	31 f6                	xor    %esi,%esi
  6fbda6:	48 8b 7a 18          	mov    0x18(%rdx),%rdi
  6fbdaa:	4c 8b 42 50          	mov    0x50(%rdx),%r8
  6fbdae:	48 23 3a             	and    (%rdx),%rdi
  6fbdb1:	45 31 c9             	xor    %r9d,%r9d
  6fbdb4:	48 83 ff ff          	cmp    $0xffffffffffffffff,%rdi
  6fbdb8:	41 0f 95 c1          	setne  %r9b
  6fbdbc:	4c 23 42 38          	and    0x38(%rdx),%r8
  6fbdc0:	49 01 f1             	add    %rsi,%r9
  6fbdc3:	31 f6                	xor    %esi,%esi
  6fbdc5:	49 83 f8 ff          	cmp    $0xffffffffffffffff,%r8
  6fbdc9:	40 0f 95 c6          	setne  %sil
  6fbdcd:	4c 01 ce             	add    %r9,%rsi
  6fbdd0:	48 83 c0 02          	add    $0x2,%rax
  6fbdd4:	48 83 c2 70          	add    $0x70,%rdx
  6fbdd8:	48 39 c1             	cmp    %rax,%rcx
  6fbddb:	75 c9                	jne    6fbda6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d96>
  6fbddd:	f6 c3 01             	test   $0x1,%bl
  6fbde0:	74 1e                	je     6fbe00 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4df0>
  6fbde2:	48 89 f1             	mov    %rsi,%rcx
  6fbde5:	48 6b c0 38          	imul   $0x38,%rax,%rax
  6fbde9:	49 8b 54 05 18       	mov    0x18(%r13,%rax,1),%rdx
  6fbdee:	49 23 54 05 00       	and    0x0(%r13,%rax,1),%rdx
  6fbdf3:	31 f6                	xor    %esi,%esi
  6fbdf5:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
  6fbdf9:	40 0f 95 c6          	setne  %sil
  6fbdfd:	48 01 ce             	add    %rcx,%rsi
  6fbe00:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6fbe07:	00 
  6fbe08:	b9 08 00 00 00       	mov    $0x8,%ecx
  6fbe0d:	41 b8 18 00 00 00    	mov    $0x18,%r8d
  6fbe13:	31 d2                	xor    %edx,%edx
  6fbe15:	e8 16 53 02 00       	call   721130 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6fbe1a:	48 8b bc 24 98 00 00 	mov    0x98(%rsp),%rdi
  6fbe21:	00 
  6fbe22:	83 bc 24 90 00 00 00 	cmpl   $0x1,0x90(%rsp)
  6fbe29:	01 
  6fbe2a:	0f 84 10 1b 00 00    	je     6fd940 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6930>
  6fbe30:	48 6b f3 38          	imul   $0x38,%rbx,%rsi
  6fbe34:	4c 01 ee             	add    %r13,%rsi
  6fbe37:	48 8b 8c 24 70 02 00 	mov    0x270(%rsp),%rcx
  6fbe3e:	00 
  6fbe3f:	48 8b 84 24 78 02 00 	mov    0x278(%rsp),%rax
  6fbe46:	00 
  6fbe47:	4c 8b 84 24 80 02 00 	mov    0x280(%rsp),%r8
  6fbe4e:	00 
  6fbe4f:	49 c1 e0 04          	shl    $0x4,%r8
  6fbe53:	49 01 c0             	add    %rax,%r8
  6fbe56:	48 89 bc 24 a8 04 00 	mov    %rdi,0x4a8(%rsp)
  6fbe5d:	00 
  6fbe5e:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
  6fbe65:	00 
  6fbe66:	48 89 94 24 b0 04 00 	mov    %rdx,0x4b0(%rsp)
  6fbe6d:	00 
  6fbe6e:	48 c7 84 24 b8 04 00 	movq   $0x0,0x4b8(%rsp)
  6fbe75:	00 00 00 00 00 
  6fbe7a:	48 8b 94 24 c0 04 00 	mov    0x4c0(%rsp),%rdx
  6fbe81:	00 
  6fbe82:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fbe86:	f3 0f 7f 84 24 d0 00 	movdqu %xmm0,0xd0(%rsp)
  6fbe8d:	00 00 
  6fbe8f:	4c 89 ac 24 90 00 00 	mov    %r13,0x90(%rsp)
  6fbe96:	00 
  6fbe97:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
  6fbe9e:	00 
  6fbe9f:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
  6fbea6:	00 
  6fbea7:	48 89 74 24 68       	mov    %rsi,0x68(%rsp)
  6fbeac:	48 89 b4 24 a8 00 00 	mov    %rsi,0xa8(%rsp)
  6fbeb3:	00 
  6fbeb4:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  6fbebb:	00 
  6fbebc:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  6fbec3:	00 
  6fbec4:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
  6fbecb:	00 
  6fbecc:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  6fbed1:	4c 89 84 24 c8 00 00 	mov    %r8,0xc8(%rsp)
  6fbed8:	00 
  6fbed9:	48 85 db             	test   %rbx,%rbx
  6fbedc:	0f 85 6d 02 00 00    	jne    6fc14f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x513f>
  6fbee2:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6fbee9:	00 
  6fbeea:	e8 71 8c fe ff       	call   6e4b60 <core::ptr::drop_glue::<core::iter::adapters::zip::Zip<alloc::vec::into_iter::IntoIter<gpui::semantic::AnnotationDraft>, alloc::vec::into_iter::IntoIter<[core::option::Option<gpui::source::FieldId>; 2]>>>>
  6fbeef:	48 8b bc 24 b0 04 00 	mov    0x4b0(%rsp),%rdi
  6fbef6:	00 
  6fbef7:	48 8b b4 24 b8 04 00 	mov    0x4b8(%rsp),%rsi
  6fbefe:	00 
  6fbeff:	e8 9c 55 fe ff       	call   6e14a0 <<[gpui::runtime::metadata::Declared]>::sort_unstable_by_key::<u64, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#48}>>
  6fbf04:	48 8b 84 24 b8 04 00 	mov    0x4b8(%rsp),%rax
  6fbf0b:	00 
  6fbf0c:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6fbf13:	00 
  6fbf14:	0f 10 84 24 a8 04 00 	movups 0x4a8(%rsp),%xmm0
  6fbf1b:	00 
  6fbf1c:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
  6fbf23:	00 
  6fbf24:	bf c0 00 00 00       	mov    $0xc0,%edi
  6fbf29:	48 8b 9c 24 80 00 00 	mov    0x80(%rsp),%rbx
  6fbf30:	00 
  6fbf31:	48 03 3b             	add    (%rbx),%rdi
  6fbf34:	e8 f7 83 fe ff       	call   6e4330 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::metadata::Declared>>>
  6fbf39:	48 8b 03             	mov    (%rbx),%rax
  6fbf3c:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  6fbf43:	00 
  6fbf44:	48 89 88 d0 00 00 00 	mov    %rcx,0xd0(%rax)
  6fbf4b:	66 0f 6f 84 24 90 00 	movdqa 0x90(%rsp),%xmm0
  6fbf52:	00 00 
  6fbf54:	f3 0f 7f 80 c0 00 00 	movdqu %xmm0,0xc0(%rax)
  6fbf5b:	00 
  6fbf5c:	48 8b 1b             	mov    (%rbx),%rbx
  6fbf5f:	4c 8b b4 24 90 01 00 	mov    0x190(%rsp),%r14
  6fbf66:	00 
  6fbf67:	4c 8b bc 24 98 01 00 	mov    0x198(%rsp),%r15
  6fbf6e:	00 
  6fbf6f:	48 83 bc 24 f8 01 00 	cmpq   $0x0,0x1f8(%rsp)
  6fbf76:	00 00 
  6fbf78:	0f 84 46 12 00 00    	je     6fd1c4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61b4>
  6fbf7e:	31 ed                	xor    %ebp,%ebp
  6fbf80:	48 85 db             	test   %rbx,%rbx
  6fbf83:	0f 85 b6 00 00 00    	jne    6fc03f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x502f>
  6fbf89:	ff 15 09 f7 38 00    	call   *0x38f709(%rip)        # a8b698 <_DYNAMIC+0x240>
  6fbf8f:	bb 08 01 00 00       	mov    $0x108,%ebx
  6fbf94:	bf 08 01 00 00       	mov    $0x108,%edi
  6fbf99:	be 08 00 00 00       	mov    $0x8,%esi
  6fbf9e:	ff 15 fc f6 38 00    	call   *0x38f6fc(%rip)        # a8b6a0 <_DYNAMIC+0x248>
  6fbfa4:	48 85 c0             	test   %rax,%rax
  6fbfa7:	0f 84 7c 19 00 00    	je     6fd929 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6919>
  6fbfad:	48 89 c1             	mov    %rax,%rcx
  6fbfb0:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fbfb4:	f3 0f 7f 80 d8 00 00 	movdqu %xmm0,0xd8(%rax)
  6fbfbb:	00 
  6fbfbc:	f3 0f 7f 40 28       	movdqu %xmm0,0x28(%rax)
  6fbfc1:	f3 0f 7f 40 40       	movdqu %xmm0,0x40(%rax)
  6fbfc6:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  6fbfcd:	48 c7 40 18 00 00 00 	movq   $0x0,0x18(%rax)
  6fbfd4:	00 
  6fbfd5:	48 c7 40 20 08 00 00 	movq   $0x8,0x20(%rax)
  6fbfdc:	00 
  6fbfdd:	48 c7 40 38 08 00 00 	movq   $0x8,0x38(%rax)
  6fbfe4:	00 
  6fbfe5:	48 c7 40 50 08 00 00 	movq   $0x8,0x50(%rax)
  6fbfec:	00 
  6fbfed:	48 c7 40 58 00 00 00 	movq   $0x0,0x58(%rax)
  6fbff4:	00 
  6fbff5:	48 c7 40 60 ff ff ff 	movq   $0xffffffffffffffff,0x60(%rax)
  6fbffc:	ff 
  6fbffd:	48 c7 80 c0 00 00 00 	movq   $0x0,0xc0(%rax)
  6fc004:	00 00 00 00 
  6fc008:	48 c7 80 c8 00 00 00 	movq   $0x8,0xc8(%rax)
  6fc00f:	08 00 00 00 
  6fc013:	48 c7 80 d0 00 00 00 	movq   $0x0,0xd0(%rax)
  6fc01a:	00 00 00 00 
  6fc01e:	48 c7 80 e8 00 00 00 	movq   $0x0,0xe8(%rax)
  6fc025:	00 00 00 00 
  6fc029:	f3 0f 7f 80 f8 00 00 	movdqu %xmm0,0xf8(%rax)
  6fc030:	00 
  6fc031:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  6fc038:	00 
  6fc039:	48 89 08             	mov    %rcx,(%rax)
  6fc03c:	48 89 cb             	mov    %rcx,%rbx
  6fc03f:	4c 8b a3 00 01 00 00 	mov    0x100(%rbx),%r12
  6fc046:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
  6fc04d:	00 00 00 00 
  6fc051:	4d 85 e4             	test   %r12,%r12
  6fc054:	48 89 5c 24 68       	mov    %rbx,0x68(%rsp)
  6fc059:	75 6c                	jne    6fc0c7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x50b7>
  6fc05b:	ff 15 37 f6 38 00    	call   *0x38f637(%rip)        # a8b698 <_DYNAMIC+0x240>
  6fc061:	bb 60 00 00 00       	mov    $0x60,%ebx
  6fc066:	bf 60 00 00 00       	mov    $0x60,%edi
  6fc06b:	be 08 00 00 00       	mov    $0x8,%esi
  6fc070:	ff 15 2a f6 38 00    	call   *0x38f62a(%rip)        # a8b6a0 <_DYNAMIC+0x248>
  6fc076:	48 85 c0             	test   %rax,%rax
  6fc079:	0f 84 aa 18 00 00    	je     6fd929 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6919>
  6fc07f:	49 89 c4             	mov    %rax,%r12
  6fc082:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fc086:	f3 0f 7f 40 10       	movdqu %xmm0,0x10(%rax)
  6fc08b:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  6fc092:	48 c7 40 08 08 00 00 	movq   $0x8,0x8(%rax)
  6fc099:	00 
  6fc09a:	48 c7 40 20 04 00 00 	movq   $0x4,0x20(%rax)
  6fc0a1:	00 
  6fc0a2:	48 c7 40 28 00 00 00 	movq   $0x0,0x28(%rax)
  6fc0a9:	00 
  6fc0aa:	48 c7 40 30 ff ff ff 	movq   $0xffffffffffffffff,0x30(%rax)
  6fc0b1:	ff 
  6fc0b2:	48 c7 40 48 00 00 00 	movq   $0x0,0x48(%rax)
  6fc0b9:	00 
  6fc0ba:	48 c7 40 58 00 00 00 	movq   $0x0,0x58(%rax)
  6fc0c1:	00 
  6fc0c2:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
  6fc0c7:	48 83 bc 24 f8 01 00 	cmpq   $0x0,0x1f8(%rsp)
  6fc0ce:	00 00 
  6fc0d0:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
  6fc0d5:	0f 84 df 06 00 00    	je     6fc7ba <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x57aa>
  6fc0db:	ff 15 b7 f5 38 00    	call   *0x38f5b7(%rip)        # a8b698 <_DYNAMIC+0x240>
  6fc0e1:	be 08 00 00 00       	mov    $0x8,%esi
  6fc0e6:	48 8b 9c 24 40 08 00 	mov    0x840(%rsp),%rbx
  6fc0ed:	00 
  6fc0ee:	48 89 df             	mov    %rbx,%rdi
  6fc0f1:	ff 15 a9 f5 38 00    	call   *0x38f5a9(%rip)        # a8b6a0 <_DYNAMIC+0x248>
  6fc0f7:	48 85 c0             	test   %rax,%rax
  6fc0fa:	0f 84 a5 1b 00 00    	je     6fdca5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c95>
  6fc100:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
  6fc105:	e9 b5 06 00 00       	jmp    6fc7bf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x57af>
  6fc10a:	48 8b 84 24 b0 04 00 	mov    0x4b0(%rsp),%rax
  6fc111:	00 
  6fc112:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
  6fc116:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  6fc11b:	48 89 14 c8          	mov    %rdx,(%rax,%rcx,8)
  6fc11f:	4c 89 74 c8 08       	mov    %r14,0x8(%rax,%rcx,8)
  6fc124:	48 89 5c c8 10       	mov    %rbx,0x10(%rax,%rcx,8)
  6fc129:	49 ff c7             	inc    %r15
  6fc12c:	4c 89 bc 24 b8 04 00 	mov    %r15,0x4b8(%rsp)
  6fc133:	00 
  6fc134:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6fc139:	49 89 cd             	mov    %rcx,%r13
  6fc13c:	48 8b 84 24 50 03 00 	mov    0x350(%rsp),%rax
  6fc143:	00 
  6fc144:	48 3b 4c 24 68       	cmp    0x68(%rsp),%rcx
  6fc149:	0f 84 93 fd ff ff    	je     6fbee2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4ed2>
  6fc14f:	49 8d 4d 38          	lea    0x38(%r13),%rcx
  6fc153:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  6fc15a:	00 
  6fc15b:	4d 8b 65 00          	mov    0x0(%r13),%r12
  6fc15f:	49 83 fc fe          	cmp    $0xfffffffffffffffe,%r12
  6fc163:	0f 84 79 fd ff ff    	je     6fbee2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4ed2>
  6fc169:	4d 8b 7d 08          	mov    0x8(%r13),%r15
  6fc16d:	49 8b 5d 18          	mov    0x18(%r13),%rbx
  6fc171:	4d 8b 75 20          	mov    0x20(%r13),%r14
  6fc175:	48 3b 44 24 18       	cmp    0x18(%rsp),%rax
  6fc17a:	0f 84 fb 14 00 00    	je     6fd67b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x666b>
  6fc180:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  6fc185:	49 8b 6d 10          	mov    0x10(%r13),%rbp
  6fc189:	48 8d 48 10          	lea    0x10(%rax),%rcx
  6fc18d:	48 89 8c 24 50 03 00 	mov    %rcx,0x350(%rsp)
  6fc194:	00 
  6fc195:	48 89 8c 24 b8 00 00 	mov    %rcx,0xb8(%rsp)
  6fc19c:	00 
  6fc19d:	f3 0f 6f 00          	movdqu (%rax),%xmm0
  6fc1a1:	66 0f 7f 84 24 c0 08 	movdqa %xmm0,0x8c0(%rsp)
  6fc1a8:	00 00 
  6fc1aa:	41 8b 7d 30          	mov    0x30(%r13),%edi
  6fc1ae:	48 8b b4 24 98 01 00 	mov    0x198(%rsp),%rsi
  6fc1b5:	00 
  6fc1b6:	48 39 fe             	cmp    %rdi,%rsi
  6fc1b9:	0f 86 d5 19 00 00    	jbe    6fdb94 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b84>
  6fc1bf:	4d 8b 6d 28          	mov    0x28(%r13),%r13
  6fc1c3:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  6fc1ca:	00 
  6fc1cb:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  6fc1cf:	48 8b 34 c8          	mov    (%rax,%rcx,8),%rsi
  6fc1d3:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  6fc1da:	00 
  6fc1db:	48 8b 38             	mov    (%rax),%rdi
  6fc1de:	48 89 74 24 50       	mov    %rsi,0x50(%rsp)
  6fc1e3:	ff 15 97 f6 38 00    	call   *0x38f697(%rip)        # a8b880 <_DYNAMIC+0x428>
  6fc1e9:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6fc1ee:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fc1f2:	66 0f 7f 84 24 e0 04 	movdqa %xmm0,0x4e0(%rsp)
  6fc1f9:	00 00 
  6fc1fb:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
  6fc202:	00 
  6fc203:	4c 89 bc 24 d8 02 00 	mov    %r15,0x2d8(%rsp)
  6fc20a:	00 
  6fc20b:	48 89 ac 24 e0 02 00 	mov    %rbp,0x2e0(%rsp)
  6fc212:	00 
  6fc213:	48 89 9c 24 e8 02 00 	mov    %rbx,0x2e8(%rsp)
  6fc21a:	00 
  6fc21b:	4c 89 b4 24 f0 02 00 	mov    %r14,0x2f0(%rsp)
  6fc222:	00 
  6fc223:	4c 89 ac 24 f8 02 00 	mov    %r13,0x2f8(%rsp)
  6fc22a:	00 
  6fc22b:	48 c7 84 24 c8 02 00 	movq   $0x2,0x2c8(%rsp)
  6fc232:	00 02 00 00 00 
  6fc237:	48 c7 84 24 00 03 00 	movq   $0x0,0x300(%rsp)
  6fc23e:	00 00 00 00 00 
  6fc243:	41 be 02 00 00 00    	mov    $0x2,%r14d
  6fc249:	31 c9                	xor    %ecx,%ecx
  6fc24b:	eb 1f                	jmp    6fc26c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x525c>
  6fc24d:	0f 1f 00             	nopl   (%rax)
  6fc250:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
  6fc257:	00 
  6fc258:	4c 8b b4 24 c8 02 00 	mov    0x2c8(%rsp),%r14
  6fc25f:	00 
  6fc260:	48 89 c1             	mov    %rax,%rcx
  6fc263:	49 39 c6             	cmp    %rax,%r14
  6fc266:	0f 84 cd 04 00 00    	je     6fc739 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5729>
  6fc26c:	48 8d 41 01          	lea    0x1(%rcx),%rax
  6fc270:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  6fc277:	00 
  6fc278:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  6fc27c:	48 8d 94 24 d0 02 00 	lea    0x2d0(%rsp),%rdx
  6fc283:	00 
  6fc284:	48 8b 1c ca          	mov    (%rdx,%rcx,8),%rbx
  6fc288:	48 83 fb fe          	cmp    $0xfffffffffffffffe,%rbx
  6fc28c:	0f 84 a2 04 00 00    	je     6fc734 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5724>
  6fc292:	4c 8b a4 24 00 03 00 	mov    0x300(%rsp),%r12
  6fc299:	00 
  6fc29a:	49 8d 54 24 01       	lea    0x1(%r12),%rdx
  6fc29f:	48 89 94 24 00 03 00 	mov    %rdx,0x300(%rsp)
  6fc2a6:	00 
  6fc2a7:	48 83 fb ff          	cmp    $0xffffffffffffffff,%rbx
  6fc2ab:	74 b3                	je     6fc260 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5250>
  6fc2ad:	48 8d 84 24 d0 02 00 	lea    0x2d0(%rsp),%rax
  6fc2b4:	00 
  6fc2b5:	48 8d 04 c8          	lea    (%rax,%rcx,8),%rax
  6fc2b9:	48 89 9c 24 d0 06 00 	mov    %rbx,0x6d0(%rsp)
  6fc2c0:	00 
  6fc2c1:	f3 0f 6f 40 08       	movdqu 0x8(%rax),%xmm0
  6fc2c6:	48 8d 84 24 d8 06 00 	lea    0x6d8(%rsp),%rax
  6fc2cd:	00 
  6fc2ce:	f3 0f 7f 00          	movdqu %xmm0,(%rax)
  6fc2d2:	48 8d bc 24 40 04 00 	lea    0x440(%rsp),%rdi
  6fc2d9:	00 
  6fc2da:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
  6fc2e1:	00 
  6fc2e2:	ff 15 70 f8 38 00    	call   *0x38f870(%rip)        # a8bb58 <_DYNAMIC+0x700>
  6fc2e8:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  6fc2ed:	48 85 f6             	test   %rsi,%rsi
  6fc2f0:	0f 84 9a 00 00 00    	je     6fc390 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5380>
  6fc2f6:	31 c0                	xor    %eax,%eax
  6fc2f8:	4d 85 e4             	test   %r12,%r12
  6fc2fb:	0f 95 c0             	setne  %al
  6fc2fe:	48 83 7c c6 08 00    	cmpq   $0x0,0x8(%rsi,%rax,8)
  6fc304:	0f 84 86 00 00 00    	je     6fc390 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5380>
  6fc30a:	48 8b 0c 24          	mov    (%rsp),%rcx
  6fc30e:	48 ff 81 f0 06 00 00 	incq   0x6f0(%rcx)
  6fc315:	48 8d 04 c5 08 00 00 	lea    0x8(,%rax,8),%rax
  6fc31c:	00 
  6fc31d:	48 8b 94 24 50 04 00 	mov    0x450(%rsp),%rdx
  6fc324:	00 
  6fc325:	4c 8b 34 06          	mov    (%rsi,%rax,1),%r14
  6fc329:	4d 8b 3e             	mov    (%r14),%r15
  6fc32c:	4c 89 f8             	mov    %r15,%rax
  6fc32f:	48 d1 e8             	shr    $1,%rax
  6fc332:	48 39 d0             	cmp    %rdx,%rax
  6fc335:	75 64                	jne    6fc39b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x538b>
  6fc337:	48 8b b4 24 48 04 00 	mov    0x448(%rsp),%rsi
  6fc33e:	00 
  6fc33f:	49 8d 7e 10          	lea    0x10(%r14),%rdi
  6fc343:	ff 15 3f f5 38 00    	call   *0x38f53f(%rip)        # a8b888 <bcmp@GLIBC_2.2.5>
  6fc349:	85 c0                	test   %eax,%eax
  6fc34b:	75 4e                	jne    6fc39b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x538b>
  6fc34d:	41 f6 c7 01          	test   $0x1,%r15b
  6fc351:	75 2e                	jne    6fc381 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5371>
  6fc353:	49 8b 46 08          	mov    0x8(%r14),%rax
  6fc357:	a8 01                	test   $0x1,%al
  6fc359:	75 26                	jne    6fc381 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5371>
  6fc35b:	b8 02 00 00 00       	mov    $0x2,%eax
  6fc360:	f0 49 0f c1 46 08    	lock xadd %rax,0x8(%r14)
  6fc366:	48 b9 01 00 00 00 00 	movabs $0x8000000000000001,%rcx
  6fc36d:	00 00 80 
  6fc370:	48 21 c8             	and    %rcx,%rax
  6fc373:	48 ff c9             	dec    %rcx
  6fc376:	48 39 c8             	cmp    %rcx,%rax
  6fc379:	75 06                	jne    6fc381 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5371>
  6fc37b:	f0 49 83 4e 08 01    	lock orq $0x1,0x8(%r14)
  6fc381:	49 83 fc 01          	cmp    $0x1,%r12
  6fc385:	0f 86 15 03 00 00    	jbe    6fc6a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5690>
  6fc38b:	e9 31 18 00 00       	jmp    6fdbc1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6bb1>
  6fc390:	48 8b 04 24          	mov    (%rsp),%rax
  6fc394:	48 ff 80 f0 06 00 00 	incq   0x6f0(%rax)
  6fc39b:	49 83 fc 02          	cmp    $0x2,%r12
  6fc39f:	0f 83 00 16 00 00    	jae    6fd9a5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6995>
  6fc3a5:	4e 8b ac e4 c0 08 00 	mov    0x8c0(%rsp,%r12,8),%r13
  6fc3ac:	00 
  6fc3ad:	4d 85 ed             	test   %r13,%r13
  6fc3b0:	74 71                	je     6fc423 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5413>
  6fc3b2:	48 8b 84 24 28 04 00 	mov    0x428(%rsp),%rax
  6fc3b9:	00 
  6fc3ba:	48 85 c0             	test   %rax,%rax
  6fc3bd:	0f 84 37 01 00 00    	je     6fc4fa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x54ea>
  6fc3c3:	48 8b 8c 24 30 04 00 	mov    0x430(%rsp),%rcx
  6fc3ca:	00 
  6fc3cb:	0f b7 b0 ba 00 00 00 	movzwl 0xba(%rax),%esi
  6fc3d2:	89 f7                	mov    %esi,%edi
  6fc3d4:	c1 e7 03             	shl    $0x3,%edi
  6fc3d7:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6fc3de:	66 90                	xchg   %ax,%ax
  6fc3e0:	48 85 ff             	test   %rdi,%rdi
  6fc3e3:	74 27                	je     6fc40c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x53fc>
  6fc3e5:	4c 3b 6c d0 10       	cmp    0x10(%rax,%rdx,8),%r13
  6fc3ea:	41 0f 97 c0          	seta   %r8b
  6fc3ee:	41 80 d8 00          	sbb    $0x0,%r8b
  6fc3f2:	48 ff c2             	inc    %rdx
  6fc3f5:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  6fc3f9:	41 80 f8 01          	cmp    $0x1,%r8b
  6fc3fd:	74 e1                	je     6fc3e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x53d0>
  6fc3ff:	41 0f b6 f0          	movzbl %r8b,%esi
  6fc403:	85 f6                	test   %esi,%esi
  6fc405:	75 08                	jne    6fc40f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x53ff>
  6fc407:	e9 a4 00 00 00       	jmp    6fc4b0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x54a0>
  6fc40c:	48 89 f2             	mov    %rsi,%rdx
  6fc40f:	48 83 e9 01          	sub    $0x1,%rcx
  6fc413:	0f 82 e1 00 00 00    	jb     6fc4fa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x54ea>
  6fc419:	48 8b 84 d0 c0 00 00 	mov    0xc0(%rax,%rdx,8),%rax
  6fc420:	00 
  6fc421:	eb a8                	jmp    6fc3cb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x53bb>
  6fc423:	4c 8b bc 24 50 04 00 	mov    0x450(%rsp),%r15
  6fc42a:	00 
  6fc42b:	48 8b 04 24          	mov    (%rsp),%rax
  6fc42f:	f3 0f 6f 80 f8 06 00 	movdqu 0x6f8(%rax),%xmm0
  6fc436:	00 
  6fc437:	66 49 0f 6e cf       	movq   %r15,%xmm1
  6fc43c:	66 0f 6f 15 fc aa 95 	movdqa -0x6a5504(%rip),%xmm2        # 56f40 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x920>
  6fc443:	ff 
  6fc444:	66 0f 6c d1          	punpcklqdq %xmm1,%xmm2
  6fc448:	66 0f d4 d0          	paddq  %xmm0,%xmm2
  6fc44c:	f3 0f 7f 90 f8 06 00 	movdqu %xmm2,0x6f8(%rax)
  6fc453:	00 
  6fc454:	4c 8d 35 a5 b2 95 ff 	lea    -0x6a4d5b(%rip),%r14        # 57700 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x10e0>
  6fc45b:	4d 85 ff             	test   %r15,%r15
  6fc45e:	0f 84 3c 02 00 00    	je     6fc6a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5690>
  6fc464:	48 8b ac 24 48 04 00 	mov    0x448(%rsp),%rbp
  6fc46b:	00 
  6fc46c:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6fc473:	00 
  6fc474:	4c 89 fe             	mov    %r15,%rsi
  6fc477:	31 d2                	xor    %edx,%edx
  6fc479:	31 c9                	xor    %ecx,%ecx
  6fc47b:	ff 15 0f f4 38 00    	call   *0x38f40f(%rip)        # a8b890 <_DYNAMIC+0x438>
  6fc481:	48 8b bc 24 a0 01 00 	mov    0x1a0(%rsp),%rdi
  6fc488:	00 
  6fc489:	48 83 ff ff          	cmp    $0xffffffffffffffff,%rdi
  6fc48d:	0f 85 a5 15 00 00    	jne    6fda38 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a28>
  6fc493:	4c 8b b4 24 a8 01 00 	mov    0x1a8(%rsp),%r14
  6fc49a:	00 
  6fc49b:	49 8d 7e 10          	lea    0x10(%r14),%rdi
  6fc49f:	48 89 ee             	mov    %rbp,%rsi
  6fc4a2:	4c 89 fa             	mov    %r15,%rdx
  6fc4a5:	ff 15 0d f2 38 00    	call   *0x38f20d(%rip)        # a8b6b8 <memcpy@GLIBC_2.14>
  6fc4ab:	e9 f0 01 00 00       	jmp    6fc6a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5690>
  6fc4b0:	4c 8b 74 d0 60       	mov    0x60(%rax,%rdx,8),%r14
  6fc4b5:	41 f6 06 01          	testb  $0x1,(%r14)
  6fc4b9:	0f 85 e1 01 00 00    	jne    6fc6a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5690>
  6fc4bf:	49 8b 46 08          	mov    0x8(%r14),%rax
  6fc4c3:	a8 01                	test   $0x1,%al
  6fc4c5:	0f 85 d5 01 00 00    	jne    6fc6a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5690>
  6fc4cb:	b8 02 00 00 00       	mov    $0x2,%eax
  6fc4d0:	f0 49 0f c1 46 08    	lock xadd %rax,0x8(%r14)
  6fc4d6:	48 b9 01 00 00 00 00 	movabs $0x8000000000000001,%rcx
  6fc4dd:	00 00 80 
  6fc4e0:	48 21 c8             	and    %rcx,%rax
  6fc4e3:	48 ff c9             	dec    %rcx
  6fc4e6:	48 39 c8             	cmp    %rcx,%rax
  6fc4e9:	0f 85 b1 01 00 00    	jne    6fc6a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5690>
  6fc4ef:	f0 49 83 4e 08 01    	lock orq $0x1,0x8(%r14)
  6fc4f5:	e9 a6 01 00 00       	jmp    6fc6a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5690>
  6fc4fa:	4c 8b bc 24 50 04 00 	mov    0x450(%rsp),%r15
  6fc501:	00 
  6fc502:	48 8b 04 24          	mov    (%rsp),%rax
  6fc506:	f3 0f 6f 80 f8 06 00 	movdqu 0x6f8(%rax),%xmm0
  6fc50d:	00 
  6fc50e:	66 49 0f 6e cf       	movq   %r15,%xmm1
  6fc513:	66 0f 6f 15 25 aa 95 	movdqa -0x6a55db(%rip),%xmm2        # 56f40 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x920>
  6fc51a:	ff 
  6fc51b:	66 0f 6c d1          	punpcklqdq %xmm1,%xmm2
  6fc51f:	66 0f d4 d0          	paddq  %xmm0,%xmm2
  6fc523:	f3 0f 7f 90 f8 06 00 	movdqu %xmm2,0x6f8(%rax)
  6fc52a:	00 
  6fc52b:	4c 8d 35 ce b1 95 ff 	lea    -0x6a4e32(%rip),%r14        # 57700 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x10e0>
  6fc532:	4d 85 ff             	test   %r15,%r15
  6fc535:	74 47                	je     6fc57e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x556e>
  6fc537:	48 8b ac 24 48 04 00 	mov    0x448(%rsp),%rbp
  6fc53e:	00 
  6fc53f:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6fc546:	00 
  6fc547:	4c 89 fe             	mov    %r15,%rsi
  6fc54a:	31 d2                	xor    %edx,%edx
  6fc54c:	31 c9                	xor    %ecx,%ecx
  6fc54e:	ff 15 3c f3 38 00    	call   *0x38f33c(%rip)        # a8b890 <_DYNAMIC+0x438>
  6fc554:	48 8b bc 24 a0 01 00 	mov    0x1a0(%rsp),%rdi
  6fc55b:	00 
  6fc55c:	48 83 ff ff          	cmp    $0xffffffffffffffff,%rdi
  6fc560:	0f 85 d2 14 00 00    	jne    6fda38 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a28>
  6fc566:	4c 8b b4 24 a8 01 00 	mov    0x1a8(%rsp),%r14
  6fc56d:	00 
  6fc56e:	49 8d 7e 10          	lea    0x10(%r14),%rdi
  6fc572:	48 89 ee             	mov    %rbp,%rsi
  6fc575:	4c 89 fa             	mov    %r15,%rdx
  6fc578:	ff 15 3a f1 38 00    	call   *0x38f13a(%rip)        # a8b6b8 <memcpy@GLIBC_2.14>
  6fc57e:	41 f6 06 01          	testb  $0x1,(%r14)
  6fc582:	75 2e                	jne    6fc5b2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x55a2>
  6fc584:	49 8b 46 08          	mov    0x8(%r14),%rax
  6fc588:	a8 01                	test   $0x1,%al
  6fc58a:	75 26                	jne    6fc5b2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x55a2>
  6fc58c:	b8 02 00 00 00       	mov    $0x2,%eax
  6fc591:	f0 49 0f c1 46 08    	lock xadd %rax,0x8(%r14)
  6fc597:	48 b9 01 00 00 00 00 	movabs $0x8000000000000001,%rcx
  6fc59e:	00 00 80 
  6fc5a1:	48 21 c8             	and    %rcx,%rax
  6fc5a4:	48 ff c9             	dec    %rcx
  6fc5a7:	48 39 c8             	cmp    %rcx,%rax
  6fc5aa:	75 06                	jne    6fc5b2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x55a2>
  6fc5ac:	f0 49 83 4e 08 01    	lock orq $0x1,0x8(%r14)
  6fc5b2:	48 8b 84 24 28 04 00 	mov    0x428(%rsp),%rax
  6fc5b9:	00 
  6fc5ba:	48 85 c0             	test   %rax,%rax
  6fc5bd:	0f 84 87 00 00 00    	je     6fc64a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x563a>
  6fc5c3:	48 8b 8c 24 30 04 00 	mov    0x430(%rsp),%rcx
  6fc5ca:	00 
  6fc5cb:	0f b7 b0 ba 00 00 00 	movzwl 0xba(%rax),%esi
  6fc5d2:	89 f7                	mov    %esi,%edi
  6fc5d4:	c1 e7 03             	shl    $0x3,%edi
  6fc5d7:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6fc5de:	66 90                	xchg   %ax,%ax
  6fc5e0:	48 85 ff             	test   %rdi,%rdi
  6fc5e3:	74 24                	je     6fc609 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x55f9>
  6fc5e5:	4c 3b 6c d0 10       	cmp    0x10(%rax,%rdx,8),%r13
  6fc5ea:	41 0f 97 c0          	seta   %r8b
  6fc5ee:	41 80 d8 00          	sbb    $0x0,%r8b
  6fc5f2:	48 ff c2             	inc    %rdx
  6fc5f5:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  6fc5f9:	41 80 f8 01          	cmp    $0x1,%r8b
  6fc5fd:	74 e1                	je     6fc5e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x55d0>
  6fc5ff:	41 0f b6 f0          	movzbl %r8b,%esi
  6fc603:	85 f6                	test   %esi,%esi
  6fc605:	75 05                	jne    6fc60c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x55fc>
  6fc607:	eb 13                	jmp    6fc61c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x560c>
  6fc609:	48 89 f2             	mov    %rsi,%rdx
  6fc60c:	48 83 e9 01          	sub    $0x1,%rcx
  6fc610:	72 3a                	jb     6fc64c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x563c>
  6fc612:	48 8b 84 d0 c0 00 00 	mov    0xc0(%rax,%rdx,8),%rax
  6fc619:	00 
  6fc61a:	eb af                	jmp    6fc5cb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x55bb>
  6fc61c:	48 8b 7c d0 60       	mov    0x60(%rax,%rdx,8),%rdi
  6fc621:	4c 89 74 d0 60       	mov    %r14,0x60(%rax,%rdx,8)
  6fc626:	f6 07 01             	testb  $0x1,(%rdi)
  6fc629:	75 75                	jne    6fc6a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5690>
  6fc62b:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fc62f:	a8 01                	test   $0x1,%al
  6fc631:	75 6d                	jne    6fc6a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5690>
  6fc633:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6fc637:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6fc63c:	75 62                	jne    6fc6a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5690>
  6fc63e:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fc642:	ff 15 a8 f0 38 00    	call   *0x38f0a8(%rip)        # a8b6f0 <_DYNAMIC+0x298>
  6fc648:	eb 56                	jmp    6fc6a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5690>
  6fc64a:	31 c0                	xor    %eax,%eax
  6fc64c:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
  6fc653:	00 
  6fc654:	48 8d 8c 24 28 04 00 	lea    0x428(%rsp),%rcx
  6fc65b:	00 
  6fc65c:	48 89 8c 24 a8 01 00 	mov    %rcx,0x1a8(%rsp)
  6fc663:	00 
  6fc664:	48 89 84 24 b0 01 00 	mov    %rax,0x1b0(%rsp)
  6fc66b:	00 
  6fc66c:	48 c7 84 24 b8 01 00 	movq   $0x0,0x1b8(%rsp)
  6fc673:	00 00 00 00 00 
  6fc678:	48 89 94 24 c0 01 00 	mov    %rdx,0x1c0(%rsp)
  6fc67f:	00 
  6fc680:	48 8d bc 24 60 03 00 	lea    0x360(%rsp),%rdi
  6fc687:	00 
  6fc688:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
  6fc68f:	00 
  6fc690:	4c 89 f2             	mov    %r14,%rdx
  6fc693:	e8 78 50 01 00       	call   711710 <<alloc::collections::btree::map::entry::VacantEntry<gpui::source::FieldId, gpui::shared_text::SharedText>>::insert_entry>
  6fc698:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6fc69f:	00 
  6fc6a0:	4a 8b bc e4 e0 04 00 	mov    0x4e0(%rsp,%r12,8),%rdi
  6fc6a7:	00 
  6fc6a8:	48 85 ff             	test   %rdi,%rdi
  6fc6ab:	74 23                	je     6fc6d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56c0>
  6fc6ad:	f6 07 01             	testb  $0x1,(%rdi)
  6fc6b0:	75 1e                	jne    6fc6d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56c0>
  6fc6b2:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fc6b6:	a8 01                	test   $0x1,%al
  6fc6b8:	75 16                	jne    6fc6d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56c0>
  6fc6ba:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6fc6be:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6fc6c3:	74 63                	je     6fc728 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5718>
  6fc6c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6fc6cc:	00 00 00 00 
  6fc6d0:	4e 89 b4 e4 e0 04 00 	mov    %r14,0x4e0(%rsp,%r12,8)
  6fc6d7:	00 
  6fc6d8:	48 8b b4 24 40 04 00 	mov    0x440(%rsp),%rsi
  6fc6df:	00 
  6fc6e0:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fc6e4:	74 18                	je     6fc6fe <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56ee>
  6fc6e6:	48 85 f6             	test   %rsi,%rsi
  6fc6e9:	74 13                	je     6fc6fe <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56ee>
  6fc6eb:	48 8b bc 24 48 04 00 	mov    0x448(%rsp),%rdi
  6fc6f2:	00 
  6fc6f3:	ba 01 00 00 00       	mov    $0x1,%edx
  6fc6f8:	ff 15 aa ef 38 00    	call   *0x38efaa(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fc6fe:	48 85 db             	test   %rbx,%rbx
  6fc701:	0f 88 49 fb ff ff    	js     6fc250 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5240>
  6fc707:	0f 84 43 fb ff ff    	je     6fc250 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5240>
  6fc70d:	48 8b bc 24 d8 06 00 	mov    0x6d8(%rsp),%rdi
  6fc714:	00 
  6fc715:	ba 01 00 00 00       	mov    $0x1,%edx
  6fc71a:	48 89 de             	mov    %rbx,%rsi
  6fc71d:	ff 15 85 ef 38 00    	call   *0x38ef85(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fc723:	e9 28 fb ff ff       	jmp    6fc250 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5240>
  6fc728:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fc72c:	ff 15 be ef 38 00    	call   *0x38efbe(%rip)        # a8b6f0 <_DYNAMIC+0x298>
  6fc732:	eb 9c                	jmp    6fc6d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56c0>
  6fc734:	49 29 c6             	sub    %rax,%r14
  6fc737:	75 44                	jne    6fc77d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x576d>
  6fc739:	4c 8b b4 24 e0 04 00 	mov    0x4e0(%rsp),%r14
  6fc740:	00 
  6fc741:	48 8b 9c 24 e8 04 00 	mov    0x4e8(%rsp),%rbx
  6fc748:	00 
  6fc749:	4c 89 f0             	mov    %r14,%rax
  6fc74c:	48 09 d8             	or     %rbx,%rax
  6fc74f:	0f 84 df f9 ff ff    	je     6fc134 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5124>
  6fc755:	4c 8b bc 24 b8 04 00 	mov    0x4b8(%rsp),%r15
  6fc75c:	00 
  6fc75d:	4c 3b bc 24 a8 04 00 	cmp    0x4a8(%rsp),%r15
  6fc764:	00 
  6fc765:	0f 85 9f f9 ff ff    	jne    6fc10a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x50fa>
  6fc76b:	48 8d bc 24 a8 04 00 	lea    0x4a8(%rsp),%rdi
  6fc772:	00 
  6fc773:	e8 18 45 02 00       	call   720c90 <<alloc::raw_vec::RawVec<gpui::style_port::Draft>>::grow_one>
  6fc778:	e9 8d f9 ff ff       	jmp    6fc10a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x50fa>
  6fc77d:	48 8d 84 24 d0 02 00 	lea    0x2d0(%rsp),%rax
  6fc784:	00 
  6fc785:	48 8d 1c c8          	lea    (%rax,%rcx,8),%rbx
  6fc789:	48 83 c3 20          	add    $0x20,%rbx
  6fc78d:	eb 0a                	jmp    6fc799 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5789>
  6fc78f:	90                   	nop
  6fc790:	48 83 c3 18          	add    $0x18,%rbx
  6fc794:	49 ff ce             	dec    %r14
  6fc797:	74 a0                	je     6fc739 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5729>
  6fc799:	48 8b 73 f8          	mov    -0x8(%rbx),%rsi
  6fc79d:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fc7a1:	74 ed                	je     6fc790 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5780>
  6fc7a3:	48 85 f6             	test   %rsi,%rsi
  6fc7a6:	78 e8                	js     6fc790 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5780>
  6fc7a8:	74 e6                	je     6fc790 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5780>
  6fc7aa:	48 8b 3b             	mov    (%rbx),%rdi
  6fc7ad:	ba 01 00 00 00       	mov    $0x1,%edx
  6fc7b2:	ff 15 f0 ee 38 00    	call   *0x38eef0(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fc7b8:	eb d6                	jmp    6fc790 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5780>
  6fc7ba:	b8 08 00 00 00       	mov    $0x8,%eax
  6fc7bf:	48 8b 8c 24 f8 01 00 	mov    0x1f8(%rsp),%rcx
  6fc7c6:	00 
  6fc7c7:	48 89 8c 24 c0 02 00 	mov    %rcx,0x2c0(%rsp)
  6fc7ce:	00 
  6fc7cf:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
  6fc7d6:	00 
  6fc7d7:	48 c7 84 24 d0 02 00 	movq   $0x0,0x2d0(%rsp)
  6fc7de:	00 00 00 00 00 
  6fc7e3:	4d 85 ff             	test   %r15,%r15
  6fc7e6:	0f 84 41 02 00 00    	je     6fca2d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5a1d>
  6fc7ec:	89 6c 24 18          	mov    %ebp,0x18(%rsp)
  6fc7f0:	4b 8d 04 7f          	lea    (%r15,%r15,2),%rax
  6fc7f4:	49 8d 04 c6          	lea    (%r14,%rax,8),%rax
  6fc7f8:	48 89 84 24 50 03 00 	mov    %rax,0x350(%rsp)
  6fc7ff:	00 
  6fc800:	bb 02 00 00 00       	mov    $0x2,%ebx
  6fc805:	45 31 e4             	xor    %r12d,%r12d
  6fc808:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  6fc80f:	00 
  6fc810:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6fc815:	eb 3f                	jmp    6fc856 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5846>
  6fc817:	48 8b 84 24 c8 02 00 	mov    0x2c8(%rsp),%rax
  6fc81e:	00 
  6fc81f:	48 89 e9             	mov    %rbp,%rcx
  6fc822:	48 c1 e1 04          	shl    $0x4,%rcx
  6fc826:	4c 89 2c 08          	mov    %r13,(%rax,%rcx,1)
  6fc82a:	66 0f 6e 44 24 20    	movd   0x20(%rsp),%xmm0
  6fc830:	66 0f 7e 44 08 08    	movd   %xmm0,0x8(%rax,%rcx,1)
  6fc836:	48 ff c5             	inc    %rbp
  6fc839:	48 89 ac 24 d0 02 00 	mov    %rbp,0x2d0(%rsp)
  6fc840:	00 
  6fc841:	49 83 c6 18          	add    $0x18,%r14
  6fc845:	49 ff c4             	inc    %r12
  6fc848:	4c 3b b4 24 50 03 00 	cmp    0x350(%rsp),%r14
  6fc84f:	00 
  6fc850:	0f 84 a2 01 00 00    	je     6fc9f8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x59e8>
  6fc856:	48 83 fb 02          	cmp    $0x2,%rbx
  6fc85a:	74 1e                	je     6fc87a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x586a>
  6fc85c:	48 83 fb 01          	cmp    $0x1,%rbx
  6fc860:	75 53                	jne    6fc8b5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x58a5>
  6fc862:	4d 39 e7             	cmp    %r12,%r15
  6fc865:	75 4e                	jne    6fc8b5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x58a5>
  6fc867:	bb 02 00 00 00       	mov    $0x2,%ebx
  6fc86c:	4d 89 e7             	mov    %r12,%r15
  6fc86f:	66 0f 6e 84 24 f8 01 	movd   0x1f8(%rsp),%xmm0
  6fc876:	00 00 
  6fc878:	eb 3f                	jmp    6fc8b9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x58a9>
  6fc87a:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
  6fc881:	00 
  6fc882:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  6fc887:	48 39 c1             	cmp    %rax,%rcx
  6fc88a:	0f 84 53 01 00 00    	je     6fc9e3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x59d3>
  6fc890:	4c 8b 39             	mov    (%rcx),%r15
  6fc893:	66 0f 6e 41 08       	movd   0x8(%rcx),%xmm0
  6fc898:	66 0f 7e 84 24 f8 01 	movd   %xmm0,0x1f8(%rsp)
  6fc89f:	00 00 
  6fc8a1:	48 8d 41 10          	lea    0x10(%rcx),%rax
  6fc8a5:	bb 01 00 00 00       	mov    $0x1,%ebx
  6fc8aa:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6fc8af:	48 83 fb 01          	cmp    $0x1,%rbx
  6fc8b3:	74 ad                	je     6fc862 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5852>
  6fc8b5:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fc8b9:	66 0f 7e 44 24 20    	movd   %xmm0,0x20(%rsp)
  6fc8bf:	4d 8b 2e             	mov    (%r14),%r13
  6fc8c2:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  6fc8c7:	4c 89 ee             	mov    %r13,%rsi
  6fc8ca:	ff 15 40 f1 38 00    	call   *0x38f140(%rip)        # a8ba10 <_DYNAMIC+0x5b8>
  6fc8d0:	66 0f 7e 84 24 a0 01 	movd   %xmm0,0x1a0(%rsp)
  6fc8d7:	00 00 
  6fc8d9:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6fc8de:	48 8b 41 48          	mov    0x48(%rcx),%rax
  6fc8e2:	48 85 c0             	test   %rax,%rax
  6fc8e5:	0f 84 7f 00 00 00    	je     6fc96a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x595a>
  6fc8eb:	48 8b 49 50          	mov    0x50(%rcx),%rcx
  6fc8ef:	66 0f 6e 44 24 20    	movd   0x20(%rsp),%xmm0
  6fc8f5:	0f b7 b0 c2 01 00 00 	movzwl 0x1c2(%rax),%esi
  6fc8fc:	48 8d 68 e0          	lea    -0x20(%rax),%rbp
  6fc900:	89 f7                	mov    %esi,%edi
  6fc902:	c1 e7 03             	shl    $0x3,%edi
  6fc905:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6fc90c:	0f 1f 40 00          	nopl   0x0(%rax)
  6fc910:	48 85 ff             	test   %rdi,%rdi
  6fc913:	74 2b                	je     6fc940 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5930>
  6fc915:	4c 3b ac d0 70 01 00 	cmp    0x170(%rax,%rdx,8),%r13
  6fc91c:	00 
  6fc91d:	41 0f 97 c0          	seta   %r8b
  6fc921:	41 80 d8 00          	sbb    $0x0,%r8b
  6fc925:	48 83 c5 20          	add    $0x20,%rbp
  6fc929:	48 ff c2             	inc    %rdx
  6fc92c:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  6fc930:	41 80 f8 01          	cmp    $0x1,%r8b
  6fc934:	74 da                	je     6fc910 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5900>
  6fc936:	41 0f b6 f0          	movzbl %r8b,%esi
  6fc93a:	85 f6                	test   %esi,%esi
  6fc93c:	75 05                	jne    6fc943 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5933>
  6fc93e:	eb 13                	jmp    6fc953 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5943>
  6fc940:	48 89 f2             	mov    %rsi,%rdx
  6fc943:	48 83 e9 01          	sub    $0x1,%rcx
  6fc947:	72 27                	jb     6fc970 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5960>
  6fc949:	48 8b 84 d0 c8 01 00 	mov    0x1c8(%rax,%rdx,8),%rax
  6fc950:	00 
  6fc951:	eb a2                	jmp    6fc8f5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x58e5>
  6fc953:	48 89 ef             	mov    %rbp,%rdi
  6fc956:	31 f6                	xor    %esi,%esi
  6fc958:	e8 63 e6 01 00       	call   71afc0 <gpui::property::apply_except::<gpui::property::GeometryStyle>>
  6fc95d:	66 0f 6e 4c 24 20    	movd   0x20(%rsp),%xmm1
  6fc963:	66 0f 7e 4d 18       	movd   %xmm1,0x18(%rbp)
  6fc968:	eb 06                	jmp    6fc970 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5960>
  6fc96a:	66 0f 6e 44 24 20    	movd   0x20(%rsp),%xmm0
  6fc970:	66 0f 7e 44 24 20    	movd   %xmm0,0x20(%rsp)
  6fc976:	66 0f 7e 84 24 90 00 	movd   %xmm0,0x90(%rsp)
  6fc97d:	00 00 
  6fc97f:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6fc986:	00 
  6fc987:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6fc98e:	00 
  6fc98f:	48 8b 05 ca ee 38 00 	mov    0x38eeca(%rip),%rax        # a8b860 <_DYNAMIC+0x408>
  6fc996:	ff 50 18             	call   *0x18(%rax)
  6fc999:	84 c0                	test   %al,%al
  6fc99b:	75 0b                	jne    6fc9a8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5998>
  6fc99d:	48 8b 04 24          	mov    (%rsp),%rax
  6fc9a1:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6fc9a8:	66 0f 6e 44 24 20    	movd   0x20(%rsp),%xmm0
  6fc9ae:	66 0f 7e c0          	movd   %xmm0,%eax
  6fc9b2:	85 c0                	test   %eax,%eax
  6fc9b4:	0f 84 87 fe ff ff    	je     6fc841 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5831>
  6fc9ba:	48 8b ac 24 d0 02 00 	mov    0x2d0(%rsp),%rbp
  6fc9c1:	00 
  6fc9c2:	48 3b ac 24 c0 02 00 	cmp    0x2c0(%rsp),%rbp
  6fc9c9:	00 
  6fc9ca:	0f 85 47 fe ff ff    	jne    6fc817 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5807>
  6fc9d0:	48 8d bc 24 c0 02 00 	lea    0x2c0(%rsp),%rdi
  6fc9d7:	00 
  6fc9d8:	ff 15 9a f1 38 00    	call   *0x38f19a(%rip)        # a8bb78 <_DYNAMIC+0x720>
  6fc9de:	e9 34 fe ff ff       	jmp    6fc817 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5807>
  6fc9e3:	0f 57 c0             	xorps  %xmm0,%xmm0
  6fc9e6:	f3 0f 11 44 24 20    	movss  %xmm0,0x20(%rsp)
  6fc9ec:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6fc9f1:	31 db                	xor    %ebx,%ebx
  6fc9f3:	e9 c7 fe ff ff       	jmp    6fc8bf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x58af>
  6fc9f8:	48 8b bc 24 c8 02 00 	mov    0x2c8(%rsp),%rdi
  6fc9ff:	00 
  6fca00:	48 8b b4 24 d0 02 00 	mov    0x2d0(%rsp),%rsi
  6fca07:	00 
  6fca08:	48 8d 44 24 5f       	lea    0x5f(%rsp),%rax
  6fca0d:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6fca14:	00 
  6fca15:	48 83 fe 02          	cmp    $0x2,%rsi
  6fca19:	8b 6c 24 18          	mov    0x18(%rsp),%ebp
  6fca1d:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
  6fca22:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
  6fca27:	0f 83 cd 0e 00 00    	jae    6fd8fa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x68ea>
  6fca2d:	48 8b 84 24 d0 02 00 	mov    0x2d0(%rsp),%rax
  6fca34:	00 
  6fca35:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6fca3c:	00 
  6fca3d:	0f 10 84 24 c0 02 00 	movups 0x2c0(%rsp),%xmm0
  6fca44:	00 
  6fca45:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
  6fca4c:	00 
  6fca4d:	49 8b 34 24          	mov    (%r12),%rsi
  6fca51:	48 85 f6             	test   %rsi,%rsi
  6fca54:	74 14                	je     6fca6a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5a5a>
  6fca56:	49 8b 7c 24 08       	mov    0x8(%r12),%rdi
  6fca5b:	48 c1 e6 04          	shl    $0x4,%rsi
  6fca5f:	ba 08 00 00 00       	mov    $0x8,%edx
  6fca64:	ff 15 3e ec 38 00    	call   *0x38ec3e(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fca6a:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  6fca71:	00 
  6fca72:	49 89 44 24 10       	mov    %rax,0x10(%r12)
  6fca77:	66 0f 6f 84 24 90 00 	movdqa 0x90(%rsp),%xmm0
  6fca7e:	00 00 
  6fca80:	f3 41 0f 7f 04 24    	movdqu %xmm0,(%r12)
  6fca86:	49 83 7c 24 10 00    	cmpq   $0x0,0x10(%r12)
  6fca8c:	75 1c                	jne    6fcaaa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5a9a>
  6fca8e:	49 83 7c 24 58 00    	cmpq   $0x0,0x58(%r12)
  6fca94:	75 14                	jne    6fcaaa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5a9a>
  6fca96:	49 83 7c 24 28 00    	cmpq   $0x0,0x28(%r12)
  6fca9c:	75 0c                	jne    6fcaaa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5a9a>
  6fca9e:	49 83 7c 24 30 ff    	cmpq   $0xffffffffffffffff,0x30(%r12)
  6fcaa4:	0f 84 90 0c 00 00    	je     6fd73a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x672a>
  6fcaaa:	48 8b bb 00 01 00 00 	mov    0x100(%rbx),%rdi
  6fcab1:	e8 1a 59 fe ff       	call   6e23d0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::geometry::Geometry>>>>
  6fcab6:	4c 89 a3 00 01 00 00 	mov    %r12,0x100(%rbx)
  6fcabd:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
  6fcac4:	00 
  6fcac5:	48 85 f6             	test   %rsi,%rsi
  6fcac8:	74 17                	je     6fcae1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5ad1>
  6fcaca:	48 c1 e6 04          	shl    $0x4,%rsi
  6fcace:	ba 08 00 00 00       	mov    $0x8,%edx
  6fcad3:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  6fcada:	00 
  6fcadb:	ff 15 c7 eb 38 00    	call   *0x38ebc7(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fcae1:	89 6c 24 18          	mov    %ebp,0x18(%rsp)
  6fcae5:	48 8b 84 24 30 05 00 	mov    0x530(%rsp),%rax
  6fcaec:	00 
  6fcaed:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6fcaf4:	00 
  6fcaf5:	0f 10 84 24 20 05 00 	movups 0x520(%rsp),%xmm0
  6fcafc:	00 
  6fcafd:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
  6fcb04:	00 
  6fcb05:	48 8b 9c 24 38 02 00 	mov    0x238(%rsp),%rbx
  6fcb0c:	00 
  6fcb0d:	48 89 df             	mov    %rbx,%rdi
  6fcb10:	e8 2b f6 00 00       	call   70c140 <<alloc::collections::btree::map::BTreeMap<gpui::runtime::scroll::ViewportKey, gpui::runtime::scroll::ViewportState> as core::ops::drop::Drop>::drop>
  6fcb15:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  6fcb1c:	00 
  6fcb1d:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fcb21:	0f 28 84 24 90 00 00 	movaps 0x90(%rsp),%xmm0
  6fcb28:	00 
  6fcb29:	0f 11 03             	movups %xmm0,(%rbx)
  6fcb2c:	48 8b 84 24 08 07 00 	mov    0x708(%rsp),%rax
  6fcb33:	00 
  6fcb34:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6fcb3b:	00 
  6fcb3c:	0f 10 84 24 f8 06 00 	movups 0x6f8(%rsp),%xmm0
  6fcb43:	00 
  6fcb44:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
  6fcb4b:	00 
  6fcb4c:	4c 8b 3c 24          	mov    (%rsp),%r15
  6fcb50:	49 8d 9f 60 06 00 00 	lea    0x660(%r15),%rbx
  6fcb57:	48 89 df             	mov    %rbx,%rdi
  6fcb5a:	e8 51 f9 00 00       	call   70c4b0 <<alloc::collections::btree::map::BTreeMap<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize> as core::ops::drop::Drop>::drop>
  6fcb5f:	4d 8d b7 90 02 00 00 	lea    0x290(%r15),%r14
  6fcb66:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  6fcb6d:	00 
  6fcb6e:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fcb72:	0f 28 84 24 90 00 00 	movaps 0x90(%rsp),%xmm0
  6fcb79:	00 
  6fcb7a:	0f 11 03             	movups %xmm0,(%rbx)
  6fcb7d:	48 8b 84 24 98 01 00 	mov    0x198(%rsp),%rax
  6fcb84:	00 
  6fcb85:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6fcb8c:	00 
  6fcb8d:	0f 10 84 24 88 01 00 	movups 0x188(%rsp),%xmm0
  6fcb94:	00 
  6fcb95:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
  6fcb9c:	00 
  6fcb9d:	49 8b 06             	mov    (%r14),%rax
  6fcba0:	48 85 c0             	test   %rax,%rax
  6fcba3:	74 1a                	je     6fcbbf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5baf>
  6fcba5:	49 8b bf 98 02 00 00 	mov    0x298(%r15),%rdi
  6fcbac:	48 c1 e0 03          	shl    $0x3,%rax
  6fcbb0:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6fcbb4:	ba 08 00 00 00       	mov    $0x8,%edx
  6fcbb9:	ff 15 e9 ea 38 00    	call   *0x38eae9(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fcbbf:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  6fcbc6:	00 
  6fcbc7:	49 89 46 10          	mov    %rax,0x10(%r14)
  6fcbcb:	0f 28 84 24 90 00 00 	movaps 0x90(%rsp),%xmm0
  6fcbd2:	00 
  6fcbd3:	41 0f 11 06          	movups %xmm0,(%r14)
  6fcbd7:	48 8b 84 24 60 05 00 	mov    0x560(%rsp),%rax
  6fcbde:	00 
  6fcbdf:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6fcbe6:	00 
  6fcbe7:	f3 0f 6f 84 24 50 05 	movdqu 0x550(%rsp),%xmm0
  6fcbee:	00 00 
  6fcbf0:	66 0f 7f 84 24 90 00 	movdqa %xmm0,0x90(%rsp)
  6fcbf7:	00 00 
  6fcbf9:	41 b4 01             	mov    $0x1,%r12b
  6fcbfc:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6fcc03:	00 
  6fcc04:	e8 77 63 00 00       	call   702f80 <<alloc::vec::Vec<core::option::Option<gpui::element::Handler>>>::into_boxed_slice>
  6fcc09:	49 89 c6             	mov    %rax,%r14
  6fcc0c:	48 89 d3             	mov    %rdx,%rbx
  6fcc0f:	49 8b bf b0 05 00 00 	mov    0x5b0(%r15),%rdi
  6fcc16:	49 8b b7 b8 05 00 00 	mov    0x5b8(%r15),%rsi
  6fcc1d:	e8 2e 7a fe ff       	call   6e4650 <core::ptr::drop_glue::<alloc::boxed::Box<[core::option::Option<gpui::element::Handler>]>>>
  6fcc22:	4d 89 b7 b0 05 00 00 	mov    %r14,0x5b0(%r15)
  6fcc29:	49 89 9f b8 05 00 00 	mov    %rbx,0x5b8(%r15)
  6fcc30:	48 8d 9c 24 90 00 00 	lea    0x90(%rsp),%rbx
  6fcc37:	00 
  6fcc38:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
  6fcc3f:	00 
  6fcc40:	ba a0 00 00 00       	mov    $0xa0,%edx
  6fcc45:	48 89 df             	mov    %rbx,%rdi
  6fcc48:	ff 15 6a ea 38 00    	call   *0x38ea6a(%rip)        # a8b6b8 <memcpy@GLIBC_2.14>
  6fcc4e:	45 31 e4             	xor    %r12d,%r12d
  6fcc51:	48 8d bc 24 c0 02 00 	lea    0x2c0(%rsp),%rdi
  6fcc58:	00 
  6fcc59:	48 89 de             	mov    %rbx,%rsi
  6fcc5c:	ff 15 1e ef 38 00    	call   *0x38ef1e(%rip)        # a8bb80 <_DYNAMIC+0x728>
  6fcc62:	49 8d 9f 00 02 00 00 	lea    0x200(%r15),%rbx
  6fcc69:	48 89 df             	mov    %rbx,%rdi
  6fcc6c:	e8 2f 97 fe ff       	call   6e63a0 <core::ptr::drop_glue::<gpui::runtime::styles::Styles>>
  6fcc71:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
  6fcc78:	00 
  6fcc79:	48 89 43 20          	mov    %rax,0x20(%rbx)
  6fcc7d:	0f 10 84 24 c0 02 00 	movups 0x2c0(%rsp),%xmm0
  6fcc84:	00 
  6fcc85:	f3 0f 6f 8c 24 d0 02 	movdqu 0x2d0(%rsp),%xmm1
  6fcc8c:	00 00 
  6fcc8e:	f3 0f 7f 4b 10       	movdqu %xmm1,0x10(%rbx)
  6fcc93:	0f 11 03             	movups %xmm0,(%rbx)
  6fcc96:	41 83 bf 00 02 00 00 	cmpl   $0x3,0x200(%r15)
  6fcc9d:	03 
  6fcc9e:	0f 94 c0             	sete   %al
  6fcca1:	41 08 87 4b 07 00 00 	or     %al,0x74b(%r15)
  6fcca8:	48 8b 84 24 78 05 00 	mov    0x578(%rsp),%rax
  6fccaf:	00 
  6fccb0:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6fccb7:	00 
  6fccb8:	0f 10 84 24 68 05 00 	movups 0x568(%rsp),%xmm0
  6fccbf:	00 
  6fccc0:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
  6fccc7:	00 
  6fccc8:	49 8d 9f a8 02 00 00 	lea    0x2a8(%r15),%rbx
  6fcccf:	48 89 df             	mov    %rbx,%rdi
  6fccd2:	e8 b9 72 00 00       	call   703f90 <<alloc::vec::Vec<core::option::Option<gpui::runtime::TextSite>> as core::ops::drop::Drop>::drop>
  6fccd7:	48 8b 03             	mov    (%rbx),%rax
  6fccda:	48 85 c0             	test   %rax,%rax
  6fccdd:	4c 8b 34 24          	mov    (%rsp),%r14
  6fcce1:	74 1a                	je     6fccfd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5ced>
  6fcce3:	49 8b be b0 02 00 00 	mov    0x2b0(%r14),%rdi
  6fccea:	48 c1 e0 04          	shl    $0x4,%rax
  6fccee:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
  6fccf2:	ba 08 00 00 00       	mov    $0x8,%edx
  6fccf7:	ff 15 ab e9 38 00    	call   *0x38e9ab(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fccfd:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  6fcd04:	00 
  6fcd05:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fcd09:	0f 28 84 24 90 00 00 	movaps 0x90(%rsp),%xmm0
  6fcd10:	00 
  6fcd11:	0f 11 03             	movups %xmm0,(%rbx)
  6fcd14:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  6fcd1b:	00 
  6fcd1c:	48 89 84 24 b0 01 00 	mov    %rax,0x1b0(%rsp)
  6fcd23:	00 
  6fcd24:	f3 0f 6f 84 24 60 01 	movdqu 0x160(%rsp),%xmm0
  6fcd2b:	00 00 
  6fcd2d:	66 0f 7f 84 24 a0 01 	movdqa %xmm0,0x1a0(%rsp)
  6fcd34:	00 00 
  6fcd36:	49 8b 8e f8 05 00 00 	mov    0x5f8(%r14),%rcx
  6fcd3d:	48 85 c9             	test   %rcx,%rcx
  6fcd40:	74 4d                	je     6fcd8f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5d7f>
  6fcd42:	49 8b 96 00 06 00 00 	mov    0x600(%r14),%rdx
  6fcd49:	49 8b 86 08 06 00 00 	mov    0x608(%r14),%rax
  6fcd50:	48 c7 84 24 98 00 00 	movq   $0x0,0x98(%rsp)
  6fcd57:	00 00 00 00 00 
  6fcd5c:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
  6fcd63:	00 
  6fcd64:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
  6fcd6b:	00 
  6fcd6c:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  6fcd73:	00 00 00 00 00 
  6fcd78:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
  6fcd7f:	00 
  6fcd80:	48 89 94 24 c8 00 00 	mov    %rdx,0xc8(%rsp)
  6fcd87:	00 
  6fcd88:	b9 01 00 00 00       	mov    $0x1,%ecx
  6fcd8d:	eb 04                	jmp    6fcd93 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5d83>
  6fcd8f:	31 c9                	xor    %ecx,%ecx
  6fcd91:	31 c0                	xor    %eax,%eax
  6fcd93:	4d 8d be f8 05 00 00 	lea    0x5f8(%r14),%r15
  6fcd9a:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  6fcda1:	00 
  6fcda2:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
  6fcda9:	00 
  6fcdaa:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  6fcdb1:	00 
  6fcdb2:	48 8d bc 24 c0 02 00 	lea    0x2c0(%rsp),%rdi
  6fcdb9:	00 
  6fcdba:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6fcdc1:	00 
  6fcdc2:	e8 29 d4 00 00       	call   70a1f0 <<alloc::collections::btree::map::IntoIter<gpui::source::FieldId, gpui::runtime::Fanout>>::dying_next>
  6fcdc7:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
  6fcdce:	00 
  6fcdcf:	48 85 c0             	test   %rax,%rax
  6fcdd2:	74 62                	je     6fce36 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5e26>
  6fcdd4:	48 8d 9c 24 c0 02 00 	lea    0x2c0(%rsp),%rbx
  6fcddb:	00 
  6fcddc:	4c 8d b4 24 90 00 00 	lea    0x90(%rsp),%r14
  6fcde3:	00 
  6fcde4:	4c 8b 25 bd e8 38 00 	mov    0x38e8bd(%rip),%r12        # a8b6a8 <_DYNAMIC+0x250>
  6fcdeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6fcdf0:	48 8b 8c 24 d0 02 00 	mov    0x2d0(%rsp),%rcx
  6fcdf7:	00 
  6fcdf8:	48 c1 e1 05          	shl    $0x5,%rcx
  6fcdfc:	48 8b 34 08          	mov    (%rax,%rcx,1),%rsi
  6fce00:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fce04:	74 18                	je     6fce1e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5e0e>
  6fce06:	48 85 f6             	test   %rsi,%rsi
  6fce09:	74 13                	je     6fce1e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5e0e>
  6fce0b:	48 01 c8             	add    %rcx,%rax
  6fce0e:	48 8b 78 08          	mov    0x8(%rax),%rdi
  6fce12:	48 c1 e6 02          	shl    $0x2,%rsi
  6fce16:	ba 04 00 00 00       	mov    $0x4,%edx
  6fce1b:	41 ff d4             	call   *%r12
  6fce1e:	48 89 df             	mov    %rbx,%rdi
  6fce21:	4c 89 f6             	mov    %r14,%rsi
  6fce24:	e8 c7 d3 00 00       	call   70a1f0 <<alloc::collections::btree::map::IntoIter<gpui::source::FieldId, gpui::runtime::Fanout>>::dying_next>
  6fce29:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
  6fce30:	00 
  6fce31:	48 85 c0             	test   %rax,%rax
  6fce34:	75 ba                	jne    6fcdf0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5de0>
  6fce36:	48 8b 84 24 b0 01 00 	mov    0x1b0(%rsp),%rax
  6fce3d:	00 
  6fce3e:	49 89 47 10          	mov    %rax,0x10(%r15)
  6fce42:	66 0f 6f 84 24 a0 01 	movdqa 0x1a0(%rsp),%xmm0
  6fce49:	00 00 
  6fce4b:	f3 41 0f 7f 07       	movdqu %xmm0,(%r15)
  6fce50:	48 8b 04 24          	mov    (%rsp),%rax
  6fce54:	48 8b b0 98 02 00 00 	mov    0x298(%rax),%rsi
  6fce5b:	48 8b 80 a0 02 00 00 	mov    0x2a0(%rax),%rax
  6fce62:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  6fce66:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
  6fce6a:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6fce71:	00 
  6fce72:	44 8b 64 24 18       	mov    0x18(%rsp),%r12d
  6fce77:	e8 34 9f 01 00       	call   716db0 <<gpui::runtime::identity_index::IdentityIndex>::from_ids::<core::iter::adapters::map::Map<core::slice::iter::Iter<gpui::runtime::Node>, <gpui::runtime::Node>::identity>>>
  6fce7c:	4c 8b bc 24 e0 03 00 	mov    0x3e0(%rsp),%r15
  6fce83:	00 
  6fce84:	48 8b 04 24          	mov    (%rsp),%rax
  6fce88:	48 8d 98 e8 01 00 00 	lea    0x1e8(%rax),%rbx
  6fce8f:	48 8b 80 e8 01 00 00 	mov    0x1e8(%rax),%rax
  6fce96:	48 85 c0             	test   %rax,%rax
  6fce99:	4c 8b b4 24 00 04 00 	mov    0x400(%rsp),%r14
  6fcea0:	00 
  6fcea1:	74 59                	je     6fcefc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5eec>
  6fcea3:	83 f8 01             	cmp    $0x1,%eax
  6fcea6:	75 26                	jne    6fcece <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5ebe>
  6fcea8:	48 8b 04 24          	mov    (%rsp),%rax
  6fceac:	48 8b b0 f8 01 00 00 	mov    0x1f8(%rax),%rsi
  6fceb3:	48 85 f6             	test   %rsi,%rsi
  6fceb6:	74 44                	je     6fcefc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5eec>
  6fceb8:	48 8b 04 24          	mov    (%rsp),%rax
  6fcebc:	48 8b b8 f0 01 00 00 	mov    0x1f0(%rax),%rdi
  6fcec3:	48 c1 e6 04          	shl    $0x4,%rsi
  6fcec7:	ba 08 00 00 00       	mov    $0x8,%edx
  6fcecc:	eb 28                	jmp    6fcef6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5ee6>
  6fcece:	48 8b 04 24          	mov    (%rsp),%rax
  6fced2:	48 8b 80 f8 01 00 00 	mov    0x1f8(%rax),%rax
  6fced9:	48 85 c0             	test   %rax,%rax
  6fcedc:	74 1e                	je     6fcefc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5eec>
  6fcede:	48 8b 0c 24          	mov    (%rsp),%rcx
  6fcee2:	48 8b b9 f0 01 00 00 	mov    0x1f0(%rcx),%rdi
  6fcee9:	48 c1 e0 02          	shl    $0x2,%rax
  6fceed:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6fcef1:	ba 04 00 00 00       	mov    $0x4,%edx
  6fcef6:	ff 15 ac e7 38 00    	call   *0x38e7ac(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fcefc:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  6fcf03:	00 
  6fcf04:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fcf08:	f3 0f 6f 84 24 90 00 	movdqu 0x90(%rsp),%xmm0
  6fcf0f:	00 00 
  6fcf11:	f3 0f 7f 03          	movdqu %xmm0,(%rbx)
  6fcf15:	4c 89 f7             	mov    %r14,%rdi
  6fcf18:	48 89 de             	mov    %rbx,%rsi
  6fcf1b:	e8 90 de 01 00       	call   71adb0 <<gpui::property::Overrides>::retain::<<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#49}>>
  6fcf20:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  6fcf27:	00 
  6fcf28:	48 8b 38             	mov    (%rax),%rdi
  6fcf2b:	48 85 ff             	test   %rdi,%rdi
  6fcf2e:	74 76                	je     6fcfa6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5f96>
  6fcf30:	48 81 c7 e8 00 00 00 	add    $0xe8,%rdi
  6fcf37:	48 89 de             	mov    %rbx,%rsi
  6fcf3a:	e8 91 48 fe ff       	call   6e17d0 <<alloc::collections::btree::map::BTreeMap<u64, [gpui::property::Contribution<core::option::Option<gpui::shared_text::SharedText>>; 2]>>::retain::<<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#50}>>
  6fcf3f:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  6fcf46:	00 
  6fcf47:	4c 8b 30             	mov    (%rax),%r14
  6fcf4a:	49 8b be 00 01 00 00 	mov    0x100(%r14),%rdi
  6fcf51:	48 85 ff             	test   %rdi,%rdi
  6fcf54:	74 50                	je     6fcfa6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5f96>
  6fcf56:	48 83 c7 48          	add    $0x48,%rdi
  6fcf5a:	48 89 de             	mov    %rbx,%rsi
  6fcf5d:	e8 de da 01 00       	call   71aa40 <<gpui::property::Overrides<gpui::property::GeometryStyle>>::retain::<<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#51}>>
  6fcf62:	49 8b 86 00 01 00 00 	mov    0x100(%r14),%rax
  6fcf69:	48 8b 48 58          	mov    0x58(%rax),%rcx
  6fcf6d:	48 0b 48 10          	or     0x10(%rax),%rcx
  6fcf71:	75 33                	jne    6fcfa6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5f96>
  6fcf73:	48 83 78 28 00       	cmpq   $0x0,0x28(%rax)
  6fcf78:	75 2c                	jne    6fcfa6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5f96>
  6fcf7a:	48 83 78 30 ff       	cmpq   $0xffffffffffffffff,0x30(%rax)
  6fcf7f:	75 25                	jne    6fcfa6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5f96>
  6fcf81:	48 8b 9c 24 80 00 00 	mov    0x80(%rsp),%rbx
  6fcf88:	00 
  6fcf89:	48 8b 03             	mov    (%rbx),%rax
  6fcf8c:	48 8b b8 00 01 00 00 	mov    0x100(%rax),%rdi
  6fcf93:	e8 38 54 fe ff       	call   6e23d0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::geometry::Geometry>>>>
  6fcf98:	48 8b 03             	mov    (%rbx),%rax
  6fcf9b:	48 c7 80 00 01 00 00 	movq   $0x0,0x100(%rax)
  6fcfa2:	00 00 00 00 
  6fcfa6:	48 8b 3c 24          	mov    (%rsp),%rdi
  6fcfaa:	c6 87 4a 07 00 00 01 	movb   $0x1,0x74a(%rdi)
  6fcfb1:	e8 ba e4 fe ff       	call   6eb470 <<gpui::runtime::Runtime<route_columns_cost::Page>>::prune_focus>
  6fcfb6:	48 8b 04 24          	mov    (%rsp),%rax
  6fcfba:	4c 89 b8 38 07 00 00 	mov    %r15,0x738(%rax)
  6fcfc1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fcfc6:	48 c7 00 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rax)
  6fcfcd:	ba 04 00 00 00       	mov    $0x4,%edx
  6fcfd2:	48 8b bc 24 10 02 00 	mov    0x210(%rsp),%rdi
  6fcfd9:	00 
  6fcfda:	48 8b b4 24 88 02 00 	mov    0x288(%rsp),%rsi
  6fcfe1:	00 
  6fcfe2:	ff 15 c0 e6 38 00    	call   *0x38e6c0(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fcfe8:	48 8b b4 24 90 02 00 	mov    0x290(%rsp),%rsi
  6fcfef:	00 
  6fcff0:	48 85 f6             	test   %rsi,%rsi
  6fcff3:	74 14                	je     6fd009 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5ff9>
  6fcff5:	48 c1 e6 03          	shl    $0x3,%rsi
  6fcff9:	ba 08 00 00 00       	mov    $0x8,%edx
  6fcffe:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
  6fd003:	ff 15 9f e6 38 00    	call   *0x38e69f(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd009:	45 31 ed             	xor    %r13d,%r13d
  6fd00c:	48 8d bc 24 98 08 00 	lea    0x898(%rsp),%rdi
  6fd013:	00 
  6fd014:	e8 07 f8 00 00       	call   70c820 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fd019:	48 8d bc 24 88 06 00 	lea    0x688(%rsp),%rdi
  6fd020:	00 
  6fd021:	e8 8a f4 00 00       	call   70c4b0 <<alloc::collections::btree::map::BTreeMap<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize> as core::ops::drop::Drop>::drop>
  6fd026:	48 8d bc 24 70 06 00 	lea    0x670(%rsp),%rdi
  6fd02d:	00 
  6fd02e:	e8 7d f4 00 00       	call   70c4b0 <<alloc::collections::btree::map::BTreeMap<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize> as core::ops::drop::Drop>::drop>
  6fd033:	48 8b 84 24 60 06 00 	mov    0x660(%rsp),%rax
  6fd03a:	00 
  6fd03b:	48 85 c0             	test   %rax,%rax
  6fd03e:	74 18                	je     6fd058 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6048>
  6fd040:	48 c1 e0 03          	shl    $0x3,%rax
  6fd044:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6fd048:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd04d:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  6fd052:	ff 15 50 e6 38 00    	call   *0x38e650(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd058:	48 8b bc 24 f0 04 00 	mov    0x4f0(%rsp),%rdi
  6fd05f:	00 
  6fd060:	48 8b b4 24 d0 03 00 	mov    0x3d0(%rsp),%rsi
  6fd067:	00 
  6fd068:	e8 e3 75 fe ff       	call   6e4650 <core::ptr::drop_glue::<alloc::boxed::Box<[core::option::Option<gpui::element::Handler>]>>>
  6fd06d:	48 8b b4 24 c8 07 00 	mov    0x7c8(%rsp),%rsi
  6fd074:	00 
  6fd075:	48 85 f6             	test   %rsi,%rsi
  6fd078:	74 17                	je     6fd091 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6081>
  6fd07a:	48 8b bc 24 d0 07 00 	mov    0x7d0(%rsp),%rdi
  6fd081:	00 
  6fd082:	48 c1 e6 02          	shl    $0x2,%rsi
  6fd086:	ba 04 00 00 00       	mov    $0x4,%edx
  6fd08b:	ff 15 17 e6 38 00    	call   *0x38e617(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd091:	48 8d bc 24 a0 06 00 	lea    0x6a0(%rsp),%rdi
  6fd098:	00 
  6fd099:	e8 02 93 fe ff       	call   6e63a0 <core::ptr::drop_glue::<gpui::runtime::styles::Styles>>
  6fd09e:	48 8d bc 24 28 04 00 	lea    0x428(%rsp),%rdi
  6fd0a5:	00 
  6fd0a6:	e8 15 e8 00 00       	call   70b8c0 <<alloc::collections::btree::map::BTreeMap<gpui::source::FieldId, gpui::shared_text::SharedText> as core::ops::drop::Drop>::drop>
  6fd0ab:	45 84 e4             	test   %r12b,%r12b
  6fd0ae:	74 24                	je     6fd0d4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x60c4>
  6fd0b0:	48 8b b4 24 70 02 00 	mov    0x270(%rsp),%rsi
  6fd0b7:	00 
  6fd0b8:	48 85 f6             	test   %rsi,%rsi
  6fd0bb:	74 17                	je     6fd0d4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x60c4>
  6fd0bd:	48 8b bc 24 78 02 00 	mov    0x278(%rsp),%rdi
  6fd0c4:	00 
  6fd0c5:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd0c9:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd0ce:	ff 15 d4 e5 38 00    	call   *0x38e5d4(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd0d4:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd0d9:	48 8b bc 24 a0 02 00 	mov    0x2a0(%rsp),%rdi
  6fd0e0:	00 
  6fd0e1:	48 8b b4 24 f8 03 00 	mov    0x3f8(%rsp),%rsi
  6fd0e8:	00 
  6fd0e9:	ff 15 b9 e5 38 00    	call   *0x38e5b9(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd0ef:	48 8b b4 24 58 02 00 	mov    0x258(%rsp),%rsi
  6fd0f6:	00 
  6fd0f7:	48 85 f6             	test   %rsi,%rsi
  6fd0fa:	74 17                	je     6fd113 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6103>
  6fd0fc:	48 8b bc 24 60 02 00 	mov    0x260(%rsp),%rdi
  6fd103:	00 
  6fd104:	48 c1 e6 02          	shl    $0x2,%rsi
  6fd108:	ba 04 00 00 00       	mov    $0x4,%edx
  6fd10d:	ff 15 95 e5 38 00    	call   *0x38e595(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd113:	48 8b b4 24 40 02 00 	mov    0x240(%rsp),%rsi
  6fd11a:	00 
  6fd11b:	48 85 f6             	test   %rsi,%rsi
  6fd11e:	74 17                	je     6fd137 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6127>
  6fd120:	48 8b bc 24 48 02 00 	mov    0x248(%rsp),%rdi
  6fd127:	00 
  6fd128:	48 c1 e6 03          	shl    $0x3,%rsi
  6fd12c:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd131:	ff 15 71 e5 38 00    	call   *0x38e571(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd137:	48 8b b4 24 a8 02 00 	mov    0x2a8(%rsp),%rsi
  6fd13e:	00 
  6fd13f:	48 85 f6             	test   %rsi,%rsi
  6fd142:	74 17                	je     6fd15b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x614b>
  6fd144:	48 8b bc 24 b0 02 00 	mov    0x2b0(%rsp),%rdi
  6fd14b:	00 
  6fd14c:	48 c1 e6 03          	shl    $0x3,%rsi
  6fd150:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd155:	ff 15 4d e5 38 00    	call   *0x38e54d(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd15b:	45 31 ed             	xor    %r13d,%r13d
  6fd15e:	48 8d bc 24 b0 07 00 	lea    0x7b0(%rsp),%rdi
  6fd165:	00 
  6fd166:	31 ed                	xor    %ebp,%ebp
  6fd168:	e8 b3 f6 00 00       	call   70c820 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fd16d:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
  6fd174:	00 
  6fd175:	48 8d bc 24 68 08 00 	lea    0x868(%rsp),%rdi
  6fd17c:	00 
  6fd17d:	44 89 e3             	mov    %r12d,%ebx
  6fd180:	31 ed                	xor    %ebp,%ebp
  6fd182:	45 31 ff             	xor    %r15d,%r15d
  6fd185:	e8 16 d9 00 00       	call   70aaa0 <<alloc::collections::btree::map::BTreeMap<gpui_reactivity_core::tree::NodeId, fn(cephal::tree::traits::MeasureInput) -> cephal::tree::traits::MeasureOutput> as core::ops::drop::Drop>::drop>
  6fd18a:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
  6fd191:	00 
  6fd192:	48 8d bc 24 50 08 00 	lea    0x850(%rsp),%rdi
  6fd199:	00 
  6fd19a:	31 ed                	xor    %ebp,%ebp
  6fd19c:	45 31 ff             	xor    %r15d,%r15d
  6fd19f:	44 8b 64 24 18       	mov    0x18(%rsp),%r12d
  6fd1a4:	e8 77 f6 00 00       	call   70c820 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fd1a9:	45 84 e4             	test   %r12b,%r12b
  6fd1ac:	0f 84 aa 04 00 00    	je     6fd65c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x664c>
  6fd1b2:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  6fd1b9:	00 
  6fd1ba:	e8 51 6e fe ff       	call   6e4010 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::semantic::AnnotationDraft>>>
  6fd1bf:	e9 98 04 00 00       	jmp    6fd65c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x664c>
  6fd1c4:	31 ed                	xor    %ebp,%ebp
  6fd1c6:	48 85 db             	test   %rbx,%rbx
  6fd1c9:	0f 84 ee f8 ff ff    	je     6fcabd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5aad>
  6fd1cf:	48 83 bb 00 01 00 00 	cmpq   $0x0,0x100(%rbx)
  6fd1d6:	00 
  6fd1d7:	0f 85 62 ee ff ff    	jne    6fc03f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x502f>
  6fd1dd:	e9 db f8 ff ff       	jmp    6fcabd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5aad>
  6fd1e2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fd1e7:	48 c7 00 1c 00 00 00 	movq   $0x1c,(%rax)
  6fd1ee:	48 8b 8c 24 00 02 00 	mov    0x200(%rsp),%rcx
  6fd1f5:	00 
  6fd1f6:	48 89 48 08          	mov    %rcx,0x8(%rax)
  6fd1fa:	41 b5 01             	mov    $0x1,%r13b
  6fd1fd:	48 8b 8c 24 60 01 00 	mov    0x160(%rsp),%rcx
  6fd204:	00 
  6fd205:	48 85 c9             	test   %rcx,%rcx
  6fd208:	74 4f                	je     6fd259 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6249>
  6fd20a:	48 8b 94 24 68 01 00 	mov    0x168(%rsp),%rdx
  6fd211:	00 
  6fd212:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  6fd219:	00 
  6fd21a:	48 c7 84 24 98 00 00 	movq   $0x0,0x98(%rsp)
  6fd221:	00 00 00 00 00 
  6fd226:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
  6fd22d:	00 
  6fd22e:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
  6fd235:	00 
  6fd236:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  6fd23d:	00 00 00 00 00 
  6fd242:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
  6fd249:	00 
  6fd24a:	48 89 94 24 c8 00 00 	mov    %rdx,0xc8(%rsp)
  6fd251:	00 
  6fd252:	b9 01 00 00 00       	mov    $0x1,%ecx
  6fd257:	eb 04                	jmp    6fd25d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x624d>
  6fd259:	31 c9                	xor    %ecx,%ecx
  6fd25b:	31 c0                	xor    %eax,%eax
  6fd25d:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  6fd264:	00 
  6fd265:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
  6fd26c:	00 
  6fd26d:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  6fd274:	00 
  6fd275:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6fd27c:	00 
  6fd27d:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6fd284:	00 
  6fd285:	44 89 6c 24 10       	mov    %r13d,0x10(%rsp)
  6fd28a:	e8 61 cf 00 00       	call   70a1f0 <<alloc::collections::btree::map::IntoIter<gpui::source::FieldId, gpui::runtime::Fanout>>::dying_next>
  6fd28f:	48 8b 84 24 10 07 00 	mov    0x710(%rsp),%rax
  6fd296:	00 
  6fd297:	48 85 c0             	test   %rax,%rax
  6fd29a:	74 6a                	je     6fd306 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x62f6>
  6fd29c:	48 8d 9c 24 10 07 00 	lea    0x710(%rsp),%rbx
  6fd2a3:	00 
  6fd2a4:	4c 8d b4 24 90 00 00 	lea    0x90(%rsp),%r14
  6fd2ab:	00 
  6fd2ac:	4c 8b 3d f5 e3 38 00 	mov    0x38e3f5(%rip),%r15        # a8b6a8 <_DYNAMIC+0x250>
  6fd2b3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fd2ba:	84 00 00 00 00 00 
  6fd2c0:	48 8b 8c 24 20 07 00 	mov    0x720(%rsp),%rcx
  6fd2c7:	00 
  6fd2c8:	48 c1 e1 05          	shl    $0x5,%rcx
  6fd2cc:	48 8b 34 08          	mov    (%rax,%rcx,1),%rsi
  6fd2d0:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fd2d4:	74 18                	je     6fd2ee <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x62de>
  6fd2d6:	48 85 f6             	test   %rsi,%rsi
  6fd2d9:	74 13                	je     6fd2ee <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x62de>
  6fd2db:	48 01 c8             	add    %rcx,%rax
  6fd2de:	48 8b 78 08          	mov    0x8(%rax),%rdi
  6fd2e2:	48 c1 e6 02          	shl    $0x2,%rsi
  6fd2e6:	ba 04 00 00 00       	mov    $0x4,%edx
  6fd2eb:	41 ff d7             	call   *%r15
  6fd2ee:	48 89 df             	mov    %rbx,%rdi
  6fd2f1:	4c 89 f6             	mov    %r14,%rsi
  6fd2f4:	e8 f7 ce 00 00       	call   70a1f0 <<alloc::collections::btree::map::IntoIter<gpui::source::FieldId, gpui::runtime::Fanout>>::dying_next>
  6fd2f9:	48 8b 84 24 10 07 00 	mov    0x710(%rsp),%rax
  6fd300:	00 
  6fd301:	48 85 c0             	test   %rax,%rax
  6fd304:	75 ba                	jne    6fd2c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x62b0>
  6fd306:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd30b:	48 8b bc 24 a0 02 00 	mov    0x2a0(%rsp),%rdi
  6fd312:	00 
  6fd313:	48 8b b4 24 f8 03 00 	mov    0x3f8(%rsp),%rsi
  6fd31a:	00 
  6fd31b:	ff 15 87 e3 38 00    	call   *0x38e387(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd321:	48 8b b4 24 58 02 00 	mov    0x258(%rsp),%rsi
  6fd328:	00 
  6fd329:	48 85 f6             	test   %rsi,%rsi
  6fd32c:	74 17                	je     6fd345 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6335>
  6fd32e:	48 8b bc 24 60 02 00 	mov    0x260(%rsp),%rdi
  6fd335:	00 
  6fd336:	48 c1 e6 02          	shl    $0x2,%rsi
  6fd33a:	ba 04 00 00 00       	mov    $0x4,%edx
  6fd33f:	ff 15 63 e3 38 00    	call   *0x38e363(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd345:	48 8b b4 24 40 02 00 	mov    0x240(%rsp),%rsi
  6fd34c:	00 
  6fd34d:	48 85 f6             	test   %rsi,%rsi
  6fd350:	74 17                	je     6fd369 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6359>
  6fd352:	48 8b bc 24 48 02 00 	mov    0x248(%rsp),%rdi
  6fd359:	00 
  6fd35a:	48 c1 e6 03          	shl    $0x3,%rsi
  6fd35e:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd363:	ff 15 3f e3 38 00    	call   *0x38e33f(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd369:	48 8b b4 24 a8 02 00 	mov    0x2a8(%rsp),%rsi
  6fd370:	00 
  6fd371:	48 85 f6             	test   %rsi,%rsi
  6fd374:	74 17                	je     6fd38d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x637d>
  6fd376:	48 8b bc 24 b0 02 00 	mov    0x2b0(%rsp),%rdi
  6fd37d:	00 
  6fd37e:	48 c1 e6 03          	shl    $0x3,%rsi
  6fd382:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd387:	ff 15 1b e3 38 00    	call   *0x38e31b(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd38d:	41 b4 01             	mov    $0x1,%r12b
  6fd390:	48 8d bc 24 b0 07 00 	lea    0x7b0(%rsp),%rdi
  6fd397:	00 
  6fd398:	40 b5 01             	mov    $0x1,%bpl
  6fd39b:	e8 80 f4 00 00       	call   70c820 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fd3a0:	48 8b 84 24 a0 04 00 	mov    0x4a0(%rsp),%rax
  6fd3a7:	00 
  6fd3a8:	48 85 c0             	test   %rax,%rax
  6fd3ab:	74 41                	je     6fd3ee <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x63de>
  6fd3ad:	48 8b 9c 24 98 04 00 	mov    0x498(%rsp),%rbx
  6fd3b4:	00 
  6fd3b5:	41 be 01 00 00 00    	mov    $0x1,%r14d
  6fd3bb:	49 29 c6             	sub    %rax,%r14
  6fd3be:	4c 8b 3d 4b e3 38 00 	mov    0x38e34b(%rip),%r15        # a8b710 <_DYNAMIC+0x2b8>
  6fd3c5:	eb 16                	jmp    6fd3dd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x63cd>
  6fd3c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6fd3ce:	00 00 
  6fd3d0:	48 83 c3 08          	add    $0x8,%rbx
  6fd3d4:	49 ff c6             	inc    %r14
  6fd3d7:	49 83 fe 01          	cmp    $0x1,%r14
  6fd3db:	74 11                	je     6fd3ee <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x63de>
  6fd3dd:	48 8b 03             	mov    (%rbx),%rax
  6fd3e0:	f0 48 ff 08          	lock decq (%rax)
  6fd3e4:	75 ea                	jne    6fd3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x63c0>
  6fd3e6:	48 89 df             	mov    %rbx,%rdi
  6fd3e9:	41 ff d7             	call   *%r15
  6fd3ec:	eb e2                	jmp    6fd3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x63c0>
  6fd3ee:	48 8b b4 24 90 04 00 	mov    0x490(%rsp),%rsi
  6fd3f5:	00 
  6fd3f6:	48 85 f6             	test   %rsi,%rsi
  6fd3f9:	74 17                	je     6fd412 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6402>
  6fd3fb:	48 8b bc 24 98 04 00 	mov    0x498(%rsp),%rdi
  6fd402:	00 
  6fd403:	48 c1 e6 03          	shl    $0x3,%rsi
  6fd407:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd40c:	ff 15 96 e2 38 00    	call   *0x38e296(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd412:	31 ed                	xor    %ebp,%ebp
  6fd414:	b3 01                	mov    $0x1,%bl
  6fd416:	48 8d bc 24 68 08 00 	lea    0x868(%rsp),%rdi
  6fd41d:	00 
  6fd41e:	41 b7 01             	mov    $0x1,%r15b
  6fd421:	e8 7a d6 00 00       	call   70aaa0 <<alloc::collections::btree::map::BTreeMap<gpui_reactivity_core::tree::NodeId, fn(cephal::tree::traits::MeasureInput) -> cephal::tree::traits::MeasureOutput> as core::ops::drop::Drop>::drop>
  6fd426:	41 b4 01             	mov    $0x1,%r12b
  6fd429:	48 8d bc 24 50 08 00 	lea    0x850(%rsp),%rdi
  6fd430:	00 
  6fd431:	41 b7 01             	mov    $0x1,%r15b
  6fd434:	e8 e7 f3 00 00       	call   70c820 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fd439:	48 8b 9c 24 e8 05 00 	mov    0x5e8(%rsp),%rbx
  6fd440:	00 
  6fd441:	4c 8b b4 24 f0 05 00 	mov    0x5f0(%rsp),%r14
  6fd448:	00 
  6fd449:	4d 85 f6             	test   %r14,%r14
  6fd44c:	44 8b 6c 24 10       	mov    0x10(%rsp),%r13d
  6fd451:	74 5c                	je     6fd4af <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x649f>
  6fd453:	4c 8d bb 88 00 00 00 	lea    0x88(%rbx),%r15
  6fd45a:	4c 8b 25 47 e2 38 00 	mov    0x38e247(%rip),%r12        # a8b6a8 <_DYNAMIC+0x250>
  6fd461:	eb 19                	jmp    6fd47c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x646c>
  6fd463:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fd46a:	84 00 00 00 00 00 
  6fd470:	49 81 c7 a8 00 00 00 	add    $0xa8,%r15
  6fd477:	49 ff ce             	dec    %r14
  6fd47a:	74 33                	je     6fd4af <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x649f>
  6fd47c:	49 8b 77 90          	mov    -0x70(%r15),%rsi
  6fd480:	48 85 f6             	test   %rsi,%rsi
  6fd483:	74 10                	je     6fd495 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6485>
  6fd485:	49 8b 7f 98          	mov    -0x68(%r15),%rdi
  6fd489:	48 c1 e6 03          	shl    $0x3,%rsi
  6fd48d:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd492:	41 ff d4             	call   *%r12
  6fd495:	49 8b 77 f8          	mov    -0x8(%r15),%rsi
  6fd499:	48 85 f6             	test   %rsi,%rsi
  6fd49c:	74 d2                	je     6fd470 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6460>
  6fd49e:	49 8b 3f             	mov    (%r15),%rdi
  6fd4a1:	48 c1 e6 05          	shl    $0x5,%rsi
  6fd4a5:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd4aa:	41 ff d4             	call   *%r12
  6fd4ad:	eb c1                	jmp    6fd470 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6460>
  6fd4af:	48 8b 84 24 e0 05 00 	mov    0x5e0(%rsp),%rax
  6fd4b6:	00 
  6fd4b7:	48 85 c0             	test   %rax,%rax
  6fd4ba:	74 15                	je     6fd4d1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x64c1>
  6fd4bc:	48 69 f0 a8 00 00 00 	imul   $0xa8,%rax,%rsi
  6fd4c3:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd4c8:	48 89 df             	mov    %rbx,%rdi
  6fd4cb:	ff 15 d7 e1 38 00    	call   *0x38e1d7(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd4d1:	48 8b b4 24 38 05 00 	mov    0x538(%rsp),%rsi
  6fd4d8:	00 
  6fd4d9:	48 85 f6             	test   %rsi,%rsi
  6fd4dc:	48 8b 9c 24 08 04 00 	mov    0x408(%rsp),%rbx
  6fd4e3:	00 
  6fd4e4:	74 17                	je     6fd4fd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x64ed>
  6fd4e6:	48 8b bc 24 40 05 00 	mov    0x540(%rsp),%rdi
  6fd4ed:	00 
  6fd4ee:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd4f2:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd4f7:	ff 15 ab e1 38 00    	call   *0x38e1ab(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd4fd:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
  6fd504:	00 
  6fd505:	48 85 c9             	test   %rcx,%rcx
  6fd508:	0f 95 c0             	setne  %al
  6fd50b:	41 84 c5             	test   %al,%r13b
  6fd50e:	74 1b                	je     6fd52b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x651b>
  6fd510:	48 c1 e1 03          	shl    $0x3,%rcx
  6fd514:	48 8d 34 49          	lea    (%rcx,%rcx,2),%rsi
  6fd518:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd51d:	48 8b bc 24 30 02 00 	mov    0x230(%rsp),%rdi
  6fd524:	00 
  6fd525:	ff 15 7d e1 38 00    	call   *0x38e17d(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd52b:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
  6fd532:	00 
  6fd533:	48 85 f6             	test   %rsi,%rsi
  6fd536:	74 17                	je     6fd54f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x653f>
  6fd538:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd53c:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd541:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  6fd548:	00 
  6fd549:	ff 15 59 e1 38 00    	call   *0x38e159(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd54f:	48 85 db             	test   %rbx,%rbx
  6fd552:	0f 95 c0             	setne  %al
  6fd555:	40 84 c5             	test   %al,%bpl
  6fd558:	74 1b                	je     6fd575 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6565>
  6fd55a:	48 c1 e3 03          	shl    $0x3,%rbx
  6fd55e:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
  6fd562:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd567:	48 8b bc 24 18 05 00 	mov    0x518(%rsp),%rdi
  6fd56e:	00 
  6fd56f:	ff 15 33 e1 38 00    	call   *0x38e133(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd575:	48 8b 9c 24 c8 04 00 	mov    0x4c8(%rsp),%rbx
  6fd57c:	00 
  6fd57d:	4c 8b b4 24 d0 04 00 	mov    0x4d0(%rsp),%r14
  6fd584:	00 
  6fd585:	4d 85 f6             	test   %r14,%r14
  6fd588:	74 5a                	je     6fd5e4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x65d4>
  6fd58a:	4c 8d 7b 20          	lea    0x20(%rbx),%r15
  6fd58e:	4c 8b 25 13 e1 38 00 	mov    0x38e113(%rip),%r12        # a8b6a8 <_DYNAMIC+0x250>
  6fd595:	eb 12                	jmp    6fd5a9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6599>
  6fd597:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6fd59e:	00 00 
  6fd5a0:	49 83 c7 38          	add    $0x38,%r15
  6fd5a4:	49 ff ce             	dec    %r14
  6fd5a7:	74 3b                	je     6fd5e4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x65d4>
  6fd5a9:	49 8b 77 e0          	mov    -0x20(%r15),%rsi
  6fd5ad:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fd5b1:	74 13                	je     6fd5c6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x65b6>
  6fd5b3:	48 85 f6             	test   %rsi,%rsi
  6fd5b6:	78 0e                	js     6fd5c6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x65b6>
  6fd5b8:	74 0c                	je     6fd5c6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x65b6>
  6fd5ba:	49 8b 7f e8          	mov    -0x18(%r15),%rdi
  6fd5be:	ba 01 00 00 00       	mov    $0x1,%edx
  6fd5c3:	41 ff d4             	call   *%r12
  6fd5c6:	49 8b 77 f8          	mov    -0x8(%r15),%rsi
  6fd5ca:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fd5ce:	74 d0                	je     6fd5a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6590>
  6fd5d0:	48 85 f6             	test   %rsi,%rsi
  6fd5d3:	78 cb                	js     6fd5a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6590>
  6fd5d5:	74 c9                	je     6fd5a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6590>
  6fd5d7:	49 8b 3f             	mov    (%r15),%rdi
  6fd5da:	ba 01 00 00 00       	mov    $0x1,%edx
  6fd5df:	41 ff d4             	call   *%r12
  6fd5e2:	eb bc                	jmp    6fd5a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6590>
  6fd5e4:	48 8b 84 24 c0 04 00 	mov    0x4c0(%rsp),%rax
  6fd5eb:	00 
  6fd5ec:	48 85 c0             	test   %rax,%rax
  6fd5ef:	74 12                	je     6fd603 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x65f3>
  6fd5f1:	48 6b f0 38          	imul   $0x38,%rax,%rsi
  6fd5f5:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd5fa:	48 89 df             	mov    %rbx,%rdi
  6fd5fd:	ff 15 a5 e0 38 00    	call   *0x38e0a5(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd603:	48 8b 9c 24 18 04 00 	mov    0x418(%rsp),%rbx
  6fd60a:	00 
  6fd60b:	4c 8b bc 24 20 04 00 	mov    0x420(%rsp),%r15
  6fd612:	00 
  6fd613:	49 ff c7             	inc    %r15
  6fd616:	48 89 df             	mov    %rbx,%rdi
  6fd619:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6fd620:	49 83 ff 01          	cmp    $0x1,%r15
  6fd624:	74 14                	je     6fd63a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x662a>
  6fd626:	4c 8d b7 98 00 00 00 	lea    0x98(%rdi),%r14
  6fd62d:	49 ff cf             	dec    %r15
  6fd630:	e8 eb 4c 00 00       	call   702320 <core::ptr::drop_glue::<gpui::element::DraftNode>>
  6fd635:	4c 89 f7             	mov    %r14,%rdi
  6fd638:	eb e6                	jmp    6fd620 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6610>
  6fd63a:	48 8b 84 24 10 04 00 	mov    0x410(%rsp),%rax
  6fd641:	00 
  6fd642:	48 85 c0             	test   %rax,%rax
  6fd645:	74 15                	je     6fd65c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x664c>
  6fd647:	48 69 f0 98 00 00 00 	imul   $0x98,%rax,%rsi
  6fd64e:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd653:	48 89 df             	mov    %rbx,%rdi
  6fd656:	ff 15 4c e0 38 00    	call   *0x38e04c(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd65c:	48 8d bc 24 80 08 00 	lea    0x880(%rsp),%rdi
  6fd663:	00 
  6fd664:	e8 57 df 00 00       	call   70b5c0 <<alloc::collections::btree::map::BTreeMap<gpui::list::ListId, alloc::collections::btree::set_val::SetValZST> as core::ops::drop::Drop>::drop>
  6fd669:	48 81 c4 d8 08 00 00 	add    $0x8d8,%rsp
  6fd670:	5b                   	pop    %rbx
  6fd671:	41 5c                	pop    %r12
  6fd673:	41 5d                	pop    %r13
  6fd675:	41 5e                	pop    %r14
  6fd677:	41 5f                	pop    %r15
  6fd679:	5d                   	pop    %rbp
  6fd67a:	c3                   	ret
  6fd67b:	49 83 fc ff          	cmp    $0xffffffffffffffff,%r12
  6fd67f:	74 16                	je     6fd697 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6687>
  6fd681:	4d 85 e4             	test   %r12,%r12
  6fd684:	7e 11                	jle    6fd697 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6687>
  6fd686:	ba 01 00 00 00       	mov    $0x1,%edx
  6fd68b:	4c 89 ff             	mov    %r15,%rdi
  6fd68e:	4c 89 e6             	mov    %r12,%rsi
  6fd691:	ff 15 11 e0 38 00    	call   *0x38e011(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd697:	48 83 fb ff          	cmp    $0xffffffffffffffff,%rbx
  6fd69b:	0f 84 41 e8 ff ff    	je     6fbee2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4ed2>
  6fd6a1:	48 85 db             	test   %rbx,%rbx
  6fd6a4:	0f 8e 38 e8 ff ff    	jle    6fbee2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4ed2>
  6fd6aa:	ba 01 00 00 00       	mov    $0x1,%edx
  6fd6af:	4c 89 f7             	mov    %r14,%rdi
  6fd6b2:	48 89 de             	mov    %rbx,%rsi
  6fd6b5:	ff 15 ed df 38 00    	call   *0x38dfed(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd6bb:	e9 22 e8 ff ff       	jmp    6fbee2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4ed2>
  6fd6c0:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  6fd6c7:	00 
  6fd6c8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6fd6cd:	48 c7 02 20 00 00 00 	movq   $0x20,(%rdx)
  6fd6d4:	48 89 42 08          	mov    %rax,0x8(%rdx)
  6fd6d8:	48 89 5a 10          	mov    %rbx,0x10(%rdx)
  6fd6dc:	48 89 4a 18          	mov    %rcx,0x18(%rdx)
  6fd6e0:	e9 15 fb ff ff       	jmp    6fd1fa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61ea>
  6fd6e5:	b3 01                	mov    $0x1,%bl
  6fd6e7:	48 8d 3d 1b d4 95 ff 	lea    -0x6a2be5(%rip),%rdi        # 5ab09 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2e61>
  6fd6ee:	48 8d 15 ab 5a 36 00 	lea    0x365aab(%rip),%rdx        # a631a0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xda0>
  6fd6f5:	be 1b 00 00 00       	mov    $0x1b,%esi
  6fd6fa:	ff 15 b0 e0 38 00    	call   *0x38e0b0(%rip)        # a8b7b0 <_DYNAMIC+0x358>
  6fd700:	e9 62 06 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd705:	48 8d 3d 34 5a 36 00 	lea    0x365a34(%rip),%rdi        # a63140 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xd40>
  6fd70c:	ff 15 be df 38 00    	call   *0x38dfbe(%rip)        # a8b6d0 <_DYNAMIC+0x278>
  6fd712:	e9 50 06 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd717:	48 8d 3d 22 65 36 00 	lea    0x366522(%rip),%rdi        # a63c40 <anon.1a4a1640ff2d1bf549336a1593f98f2a.1.llvm.522306547478690470>
  6fd71e:	ff 15 ac df 38 00    	call   *0x38dfac(%rip)        # a8b6d0 <_DYNAMIC+0x278>
  6fd724:	e9 3e 06 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd729:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fd72e:	48 c7 00 1f 00 00 00 	movq   $0x1f,(%rax)
  6fd735:	e9 0a 9c ff ff       	jmp    6f7344 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x334>
  6fd73a:	48 83 bc 24 48 01 00 	cmpq   $0x0,0x148(%rsp)
  6fd741:	00 00 
  6fd743:	74 1f                	je     6fd764 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6754>
  6fd745:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
  6fd74c:	00 
  6fd74d:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd751:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd756:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  6fd75d:	00 
  6fd75e:	ff 15 44 df 38 00    	call   *0x38df44(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd764:	49 8b 34 24          	mov    (%r12),%rsi
  6fd768:	48 85 f6             	test   %rsi,%rsi
  6fd76b:	74 14                	je     6fd781 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6771>
  6fd76d:	49 8b 7c 24 08       	mov    0x8(%r12),%rdi
  6fd772:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd776:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd77b:	ff 15 27 df 38 00    	call   *0x38df27(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd781:	49 8d 7c 24 48       	lea    0x48(%r12),%rdi
  6fd786:	e8 55 f5 00 00       	call   70cce0 <<alloc::collections::btree::map::BTreeMap<u64, gpui::property::Overlay<gpui::property::GeometryStyle>> as core::ops::drop::Drop>::drop>
  6fd78b:	49 8b 74 24 18       	mov    0x18(%r12),%rsi
  6fd790:	48 85 f6             	test   %rsi,%rsi
  6fd793:	74 14                	je     6fd7a9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6799>
  6fd795:	49 8b 7c 24 20       	mov    0x20(%r12),%rdi
  6fd79a:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd79e:	ba 04 00 00 00       	mov    $0x4,%edx
  6fd7a3:	ff 15 ff de 38 00    	call   *0x38deff(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd7a9:	49 8b 74 24 30       	mov    0x30(%r12),%rsi
  6fd7ae:	48 85 f6             	test   %rsi,%rsi
  6fd7b1:	7e 14                	jle    6fd7c7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x67b7>
  6fd7b3:	49 8b 7c 24 38       	mov    0x38(%r12),%rdi
  6fd7b8:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd7bc:	ba 04 00 00 00       	mov    $0x4,%edx
  6fd7c1:	ff 15 e1 de 38 00    	call   *0x38dee1(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fd7c7:	be 60 00 00 00       	mov    $0x60,%esi
  6fd7cc:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd7d1:	4c 89 e7             	mov    %r12,%rdi
  6fd7d4:	e9 02 f3 ff ff       	jmp    6fcadb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5acb>
  6fd7d9:	48 8d 3d 00 51 36 00 	lea    0x365100(%rip),%rdi        # a628e0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x4e0>
  6fd7e0:	ff 15 ea de 38 00    	call   *0x38deea(%rip)        # a8b6d0 <_DYNAMIC+0x278>
  6fd7e6:	e9 7c 05 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd7eb:	be 31 00 00 00       	mov    $0x31,%esi
  6fd7f0:	48 8d 15 f9 51 36 00 	lea    0x3651f9(%rip),%rdx        # a629f0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x5f0>
  6fd7f7:	48 8d 3d d6 a7 95 ff 	lea    -0x6a582a(%rip),%rdi        # 57fd4 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x32c>
  6fd7fe:	eb 13                	jmp    6fd813 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6803>
  6fd800:	be 27 00 00 00       	mov    $0x27,%esi
  6fd805:	48 8d 3d e0 a7 95 ff 	lea    -0x6a5820(%rip),%rdi        # 57fec <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x344>
  6fd80c:	48 8d 15 f5 51 36 00 	lea    0x3651f5(%rip),%rdx        # a62a08 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x608>
  6fd813:	41 b4 01             	mov    $0x1,%r12b
  6fd816:	31 ed                	xor    %ebp,%ebp
  6fd818:	ff 15 ca de 38 00    	call   *0x38deca(%rip)        # a8b6e8 <_DYNAMIC+0x290>
  6fd81e:	e9 44 05 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd823:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
  6fd82a:	00 00 
  6fd82c:	48 8d 3d a9 d2 95 ff 	lea    -0x6a2d57(%rip),%rdi        # 5aadc <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2e34>
  6fd833:	48 8d 15 be 58 36 00 	lea    0x3658be(%rip),%rdx        # a630f8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xcf8>
  6fd83a:	be 16 00 00 00       	mov    $0x16,%esi
  6fd83f:	ff 15 6b df 38 00    	call   *0x38df6b(%rip)        # a8b7b0 <_DYNAMIC+0x358>
  6fd845:	e9 1d 05 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd84a:	48 8d 3d 1f 51 36 00 	lea    0x36511f(%rip),%rdi        # a62970 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x570>
  6fd851:	ff 15 79 de 38 00    	call   *0x38de79(%rip)        # a8b6d0 <_DYNAMIC+0x278>
  6fd857:	e9 0b 05 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd85c:	48 8d 3d fb d1 95 ff 	lea    -0x6a2e05(%rip),%rdi        # 5aa5e <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2db6>
  6fd863:	48 8d 15 f6 55 36 00 	lea    0x3655f6(%rip),%rdx        # a62e60 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa60>
  6fd86a:	be 83 00 00 00       	mov    $0x83,%esi
  6fd86f:	ff 15 73 de 38 00    	call   *0x38de73(%rip)        # a8b6e8 <_DYNAMIC+0x290>
  6fd875:	e9 ed 04 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd87a:	31 ed                	xor    %ebp,%ebp
  6fd87c:	48 8d 3d b3 d1 95 ff 	lea    -0x6a2e4d(%rip),%rdi        # 5aa36 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2d8e>
  6fd883:	48 8d 15 be 55 36 00 	lea    0x3655be(%rip),%rdx        # a62e48 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa48>
  6fd88a:	be 51 00 00 00       	mov    $0x51,%esi
  6fd88f:	ff 15 53 de 38 00    	call   *0x38de53(%rip)        # a8b6e8 <_DYNAMIC+0x290>
  6fd895:	e9 cd 04 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd89a:	48 8d 3d 47 4e 36 00 	lea    0x364e47(%rip),%rdi        # a626e8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x2e8>
  6fd8a1:	ff 15 29 de 38 00    	call   *0x38de29(%rip)        # a8b6d0 <_DYNAMIC+0x278>
  6fd8a7:	e9 bb 04 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd8ac:	48 8d 3d bd 5d 36 00 	lea    0x365dbd(%rip),%rdi        # a63670 <anon.92a5b798a24d77726913e1a598e97bdf.3.llvm.13561988957598541395>
  6fd8b3:	ff 15 17 de 38 00    	call   *0x38de17(%rip)        # a8b6d0 <_DYNAMIC+0x278>
  6fd8b9:	e9 a9 04 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd8be:	48 8d 3d 99 d1 95 ff 	lea    -0x6a2e67(%rip),%rdi        # 5aa5e <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2db6>
  6fd8c5:	48 8d 15 94 55 36 00 	lea    0x365594(%rip),%rdx        # a62e60 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa60>
  6fd8cc:	be 83 00 00 00       	mov    $0x83,%esi
  6fd8d1:	ff 15 11 de 38 00    	call   *0x38de11(%rip)        # a8b6e8 <_DYNAMIC+0x290>
  6fd8d7:	e9 8b 04 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd8dc:	48 8d 3d 7b d1 95 ff 	lea    -0x6a2e85(%rip),%rdi        # 5aa5e <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2db6>
  6fd8e3:	48 8d 15 76 55 36 00 	lea    0x365576(%rip),%rdx        # a62e60 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa60>
  6fd8ea:	be 83 00 00 00       	mov    $0x83,%esi
  6fd8ef:	ff 15 f3 dd 38 00    	call   *0x38ddf3(%rip)        # a8b6e8 <_DYNAMIC+0x290>
  6fd8f5:	e9 6d 04 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd8fa:	48 83 fe 15          	cmp    $0x15,%rsi
  6fd8fe:	0f 83 08 04 00 00    	jae    6fdd0c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cfc>
  6fd904:	48 8d 8c 24 90 00 00 	lea    0x90(%rsp),%rcx
  6fd90b:	00 
  6fd90c:	ba 01 00 00 00       	mov    $0x1,%edx
  6fd911:	e8 8a a3 00 00       	call   707ca0 <core::slice::sort::shared::smallsort::insertion_sort_shift_left::<(u64, gpui::property::GeometryStyle), <[(u64, gpui::property::GeometryStyle)]>::sort_unstable_by_key<u64, <gpui::runtime::Runtime<route_columns_cost::Page>>::reconcile_geometry::{closure#2}>::{closure#0}>>
  6fd916:	8b 6c 24 18          	mov    0x18(%rsp),%ebp
  6fd91a:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
  6fd91f:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
  6fd924:	e9 04 f1 ff ff       	jmp    6fca2d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5a1d>
  6fd929:	89 6c 24 18          	mov    %ebp,0x18(%rsp)
  6fd92d:	bf 08 00 00 00       	mov    $0x8,%edi
  6fd932:	48 89 de             	mov    %rbx,%rsi
  6fd935:	ff 15 85 dd 38 00    	call   *0x38dd85(%rip)        # a8b6c0 <_DYNAMIC+0x268>
  6fd93b:	e9 27 04 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd940:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
  6fd947:	00 
  6fd948:	ff 15 22 de 38 00    	call   *0x38de22(%rip)        # a8b770 <_DYNAMIC+0x318>
  6fd94e:	e9 14 04 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd953:	48 8b 84 24 98 02 00 	mov    0x298(%rsp),%rax
  6fd95a:	00 
  6fd95b:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
  6fd962:	00 
  6fd963:	48 8d 15 46 57 36 00 	lea    0x365746(%rip),%rdx        # a630b0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xcb0>
  6fd96a:	ff 15 50 de 38 00    	call   *0x38de50(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6fd970:	e9 f2 03 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd975:	48 8d 3d 76 d1 95 ff 	lea    -0x6a2e8a(%rip),%rdi        # 5aaf2 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2e4a>
  6fd97c:	48 8d 15 d5 57 36 00 	lea    0x3657d5(%rip),%rdx        # a63158 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xd58>
  6fd983:	be 17 00 00 00       	mov    $0x17,%esi
  6fd988:	ff 15 22 de 38 00    	call   *0x38de22(%rip)        # a8b7b0 <_DYNAMIC+0x358>
  6fd98e:	e9 d4 03 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd993:	48 8d 3d ee 5c 36 00 	lea    0x365cee(%rip),%rdi        # a63688 <anon.92a5b798a24d77726913e1a598e97bdf.4.llvm.13561988957598541395>
  6fd99a:	ff 15 30 dd 38 00    	call   *0x38dd30(%rip)        # a8b6d0 <_DYNAMIC+0x278>
  6fd9a0:	e9 c2 03 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd9a5:	48 8d 15 a4 56 36 00 	lea    0x3656a4(%rip),%rdx        # a63050 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xc50>
  6fd9ac:	be 02 00 00 00       	mov    $0x2,%esi
  6fd9b1:	4c 89 e7             	mov    %r12,%rdi
  6fd9b4:	ff 15 06 de 38 00    	call   *0x38de06(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6fd9ba:	e9 a8 03 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd9bf:	48 8d 15 02 4f 36 00 	lea    0x364f02(%rip),%rdx        # a628c8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x4c8>
  6fd9c6:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  6fd9cd:	00 
  6fd9ce:	ff 15 ec dd 38 00    	call   *0x38ddec(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6fd9d4:	e9 8e 03 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd9d9:	48 8d 15 a0 56 36 00 	lea    0x3656a0(%rip),%rdx        # a63080 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xc80>
  6fd9e0:	ff 15 da dd 38 00    	call   *0x38ddda(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6fd9e6:	e9 7c 03 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fd9eb:	48 89 c5             	mov    %rax,%rbp
  6fd9ee:	4c 8b a4 24 e0 03 00 	mov    0x3e0(%rsp),%r12
  6fd9f5:	00 
  6fd9f6:	48 8d 05 8b 57 36 00 	lea    0x36578b(%rip),%rax        # a63188 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xd88>
  6fd9fd:	e9 af 00 00 00       	jmp    6fdab1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6aa1>
  6fda02:	bf 08 00 00 00       	mov    $0x8,%edi
  6fda07:	48 8b b4 24 f8 03 00 	mov    0x3f8(%rsp),%rsi
  6fda0e:	00 
  6fda0f:	ff 15 5b dd 38 00    	call   *0x38dd5b(%rip)        # a8b770 <_DYNAMIC+0x318>
  6fda15:	e9 4d 03 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fda1a:	48 8d 3d 3d d0 95 ff 	lea    -0x6a2fc3(%rip),%rdi        # 5aa5e <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2db6>
  6fda21:	48 8d 15 38 54 36 00 	lea    0x365438(%rip),%rdx        # a62e60 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa60>
  6fda28:	be 83 00 00 00       	mov    $0x83,%esi
  6fda2d:	ff 15 b5 dc 38 00    	call   *0x38dcb5(%rip)        # a8b6e8 <_DYNAMIC+0x290>
  6fda33:	e9 2f 03 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fda38:	48 85 ff             	test   %rdi,%rdi
  6fda3b:	0f 85 a4 00 00 00    	jne    6fdae5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6ad5>
  6fda41:	ff 15 69 de 38 00    	call   *0x38de69(%rip)        # a8b8b0 <_DYNAMIC+0x458>
  6fda47:	e9 1b 03 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fda4c:	4c 89 a4 24 68 03 00 	mov    %r12,0x368(%rsp)
  6fda53:	00 
  6fda54:	48 8d 15 3d 56 36 00 	lea    0x36563d(%rip),%rdx        # a63098 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xc98>
  6fda5b:	48 8b bc 24 80 01 00 	mov    0x180(%rsp),%rdi
  6fda62:	00 
  6fda63:	48 8b b4 24 e8 03 00 	mov    0x3e8(%rsp),%rsi
  6fda6a:	00 
  6fda6b:	ff 15 4f dd 38 00    	call   *0x38dd4f(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6fda71:	e9 f1 02 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fda76:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
  6fda7d:	00 00 
  6fda7f:	e9 a0 00 00 00       	jmp    6fdb24 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b14>
  6fda84:	bf 08 00 00 00       	mov    $0x8,%edi
  6fda89:	48 89 de             	mov    %rbx,%rsi
  6fda8c:	ff 15 de dc 38 00    	call   *0x38dcde(%rip)        # a8b770 <_DYNAMIC+0x318>
  6fda92:	e9 d0 02 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fda97:	bf 08 00 00 00       	mov    $0x8,%edi
  6fda9c:	48 89 de             	mov    %rbx,%rsi
  6fda9f:	ff 15 cb dc 38 00    	call   *0x38dccb(%rip)        # a8b770 <_DYNAMIC+0x318>
  6fdaa5:	e9 bd 02 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdaaa:	48 8d 05 ff 4d 36 00 	lea    0x364dff(%rip),%rax        # a628b0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x4b0>
  6fdab1:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6fdab6:	b3 01                	mov    $0x1,%bl
  6fdab8:	48 89 ef             	mov    %rbp,%rdi
  6fdabb:	4c 89 e6             	mov    %r12,%rsi
  6fdabe:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
  6fdac3:	ff 15 f7 dc 38 00    	call   *0x38dcf7(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6fdac9:	e9 99 02 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdace:	48 8d 15 9b 56 36 00 	lea    0x36569b(%rip),%rdx        # a63170 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xd70>
  6fdad5:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  6fdada:	ff 15 e0 dc 38 00    	call   *0x38dce0(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6fdae0:	e9 82 02 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdae5:	48 8b b4 24 a8 01 00 	mov    0x1a8(%rsp),%rsi
  6fdaec:	00 
  6fdaed:	ff 15 cd db 38 00    	call   *0x38dbcd(%rip)        # a8b6c0 <_DYNAMIC+0x268>
  6fdaf3:	e9 6f 02 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdaf8:	48 8d 15 89 4e 36 00 	lea    0x364e89(%rip),%rdx        # a62988 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x588>
  6fdaff:	48 8b bc 24 78 01 00 	mov    0x178(%rsp),%rdi
  6fdb06:	00 
  6fdb07:	ff 15 b3 dc 38 00    	call   *0x38dcb3(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6fdb0d:	e9 55 02 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdb12:	49 89 c6             	mov    %rax,%r14
  6fdb15:	48 8d 05 14 53 36 00 	lea    0x365314(%rip),%rax        # a62e30 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa30>
  6fdb1c:	48 89 84 24 58 06 00 	mov    %rax,0x658(%rsp)
  6fdb23:	00 
  6fdb24:	4c 89 f7             	mov    %r14,%rdi
  6fdb27:	48 8b 94 24 58 06 00 	mov    0x658(%rsp),%rdx
  6fdb2e:	00 
  6fdb2f:	ff 15 8b dc 38 00    	call   *0x38dc8b(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6fdb35:	e9 2d 02 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdb3a:	49 89 cd             	mov    %rcx,%r13
  6fdb3d:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
  6fdb44:	00 
  6fdb45:	48 8d 05 ac 4d 36 00 	lea    0x364dac(%rip),%rax        # a628f8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x4f8>
  6fdb4c:	e9 ac 00 00 00       	jmp    6fdbfd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6bed>
  6fdb51:	48 8b 84 24 e0 03 00 	mov    0x3e0(%rsp),%rax
  6fdb58:	00 
  6fdb59:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
  6fdb60:	00 
  6fdb61:	48 8d 05 78 55 36 00 	lea    0x365578(%rip),%rax        # a630e0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xce0>
  6fdb68:	e9 90 00 00 00       	jmp    6fdbfd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6bed>
  6fdb6d:	48 8d 15 04 4c 36 00 	lea    0x364c04(%rip),%rdx        # a62778 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x378>
  6fdb74:	ff 15 46 dc 38 00    	call   *0x38dc46(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6fdb7a:	e9 e8 01 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdb7f:	48 8d 15 a2 55 36 00 	lea    0x3655a2(%rip),%rdx        # a63128 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xd28>
  6fdb86:	4c 89 f7             	mov    %r14,%rdi
  6fdb89:	ff 15 31 dc 38 00    	call   *0x38dc31(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6fdb8f:	e9 d3 01 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdb94:	48 8d 15 9d 54 36 00 	lea    0x36549d(%rip),%rdx        # a63038 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xc38>
  6fdb9b:	ff 15 1f dc 38 00    	call   *0x38dc1f(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6fdba1:	e9 c1 01 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdba6:	41 b4 01             	mov    $0x1,%r12b
  6fdba9:	48 8d 15 f0 4d 36 00 	lea    0x364df0(%rip),%rdx        # a629a0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x5a0>
  6fdbb0:	40 b5 01             	mov    $0x1,%bpl
  6fdbb3:	4c 89 f7             	mov    %r14,%rdi
  6fdbb6:	ff 15 04 dc 38 00    	call   *0x38dc04(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6fdbbc:	e9 a6 01 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdbc1:	48 8d 15 a0 54 36 00 	lea    0x3654a0(%rip),%rdx        # a63068 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xc68>
  6fdbc8:	be 02 00 00 00       	mov    $0x2,%esi
  6fdbcd:	4c 89 e7             	mov    %r12,%rdi
  6fdbd0:	ff 15 ea db 38 00    	call   *0x38dbea(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6fdbd6:	e9 8c 01 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdbdb:	bf 08 00 00 00       	mov    $0x8,%edi
  6fdbe0:	48 89 de             	mov    %rbx,%rsi
  6fdbe3:	ff 15 87 db 38 00    	call   *0x38db87(%rip)        # a8b770 <_DYNAMIC+0x318>
  6fdbe9:	e9 79 01 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdbee:	4c 89 a4 24 c8 03 00 	mov    %r12,0x3c8(%rsp)
  6fdbf5:	00 
  6fdbf6:	48 8d 05 2b 4d 36 00 	lea    0x364d2b(%rip),%rax        # a62928 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x528>
  6fdbfd:	48 89 84 24 c0 03 00 	mov    %rax,0x3c0(%rsp)
  6fdc04:	00 
  6fdc05:	4c 89 ef             	mov    %r13,%rdi
  6fdc08:	48 8b b4 24 c8 03 00 	mov    0x3c8(%rsp),%rsi
  6fdc0f:	00 
  6fdc10:	48 8b 94 24 c0 03 00 	mov    0x3c0(%rsp),%rdx
  6fdc17:	00 
  6fdc18:	ff 15 a2 db 38 00    	call   *0x38dba2(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6fdc1e:	e9 44 01 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdc23:	bf 08 00 00 00       	mov    $0x8,%edi
  6fdc28:	48 89 de             	mov    %rbx,%rsi
  6fdc2b:	ff 15 3f db 38 00    	call   *0x38db3f(%rip)        # a8b770 <_DYNAMIC+0x318>
  6fdc31:	e9 31 01 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdc36:	bf 08 00 00 00       	mov    $0x8,%edi
  6fdc3b:	48 89 de             	mov    %rbx,%rsi
  6fdc3e:	ff 15 2c db 38 00    	call   *0x38db2c(%rip)        # a8b770 <_DYNAMIC+0x318>
  6fdc44:	e9 1e 01 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdc49:	48 85 ff             	test   %rdi,%rdi
  6fdc4c:	75 3e                	jne    6fdc8c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c7c>
  6fdc4e:	41 b4 01             	mov    $0x1,%r12b
  6fdc51:	40 b5 01             	mov    $0x1,%bpl
  6fdc54:	ff 15 56 dc 38 00    	call   *0x38dc56(%rip)        # a8b8b0 <_DYNAMIC+0x458>
  6fdc5a:	e9 08 01 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdc5f:	bf 04 00 00 00       	mov    $0x4,%edi
  6fdc64:	48 89 de             	mov    %rbx,%rsi
  6fdc67:	ff 15 03 db 38 00    	call   *0x38db03(%rip)        # a8b770 <_DYNAMIC+0x318>
  6fdc6d:	e9 f5 00 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdc72:	31 ed                	xor    %ebp,%ebp
  6fdc74:	48 8d 15 a5 53 36 00 	lea    0x3653a5(%rip),%rdx        # a63020 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xc20>
  6fdc7b:	48 89 c7             	mov    %rax,%rdi
  6fdc7e:	4c 89 e6             	mov    %r12,%rsi
  6fdc81:	ff 15 39 db 38 00    	call   *0x38db39(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6fdc87:	e9 db 00 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdc8c:	48 8b b4 24 a8 01 00 	mov    0x1a8(%rsp),%rsi
  6fdc93:	00 
  6fdc94:	41 b4 01             	mov    $0x1,%r12b
  6fdc97:	40 b5 01             	mov    $0x1,%bpl
  6fdc9a:	ff 15 20 da 38 00    	call   *0x38da20(%rip)        # a8b6c0 <_DYNAMIC+0x268>
  6fdca0:	e9 c2 00 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdca5:	89 6c 24 18          	mov    %ebp,0x18(%rsp)
  6fdca9:	bf 08 00 00 00       	mov    $0x8,%edi
  6fdcae:	48 89 de             	mov    %rbx,%rsi
  6fdcb1:	ff 15 b9 da 38 00    	call   *0x38dab9(%rip)        # a8b770 <_DYNAMIC+0x318>
  6fdcb7:	e9 ab 00 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdcbc:	bf 08 00 00 00       	mov    $0x8,%edi
  6fdcc1:	4c 89 f6             	mov    %r14,%rsi
  6fdcc4:	ff 15 a6 da 38 00    	call   *0x38daa6(%rip)        # a8b770 <_DYNAMIC+0x318>
  6fdcca:	e9 98 00 00 00       	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdccf:	49 89 cd             	mov    %rcx,%r13
  6fdcd2:	48 8b 84 24 d0 03 00 	mov    0x3d0(%rsp),%rax
  6fdcd9:	00 
  6fdcda:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6fdce1:	00 
  6fdce2:	48 8d 05 57 4c 36 00 	lea    0x364c57(%rip),%rax        # a62940 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x540>
  6fdce9:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
  6fdcf0:	00 
  6fdcf1:	4c 89 ef             	mov    %r13,%rdi
  6fdcf4:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  6fdcfb:	00 
  6fdcfc:	48 8b 94 24 50 06 00 	mov    0x650(%rsp),%rdx
  6fdd03:	00 
  6fdd04:	ff 15 b6 da 38 00    	call   *0x38dab6(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6fdd0a:	eb 5b                	jmp    6fdd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d57>
  6fdd0c:	48 8d 94 24 90 00 00 	lea    0x90(%rsp),%rdx
  6fdd13:	00 
  6fdd14:	8b 6c 24 18          	mov    0x18(%rsp),%ebp
  6fdd18:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
  6fdd1d:	e8 9e 4a 01 00       	call   7127c0 <core::slice::sort::unstable::ipnsort::<(u64, gpui::property::GeometryStyle), <[(u64, gpui::property::GeometryStyle)]>::sort_unstable_by_key<u64, <gpui::runtime::Runtime<route_columns_cost::Page>>::reconcile_geometry::{closure#2}>::{closure#0}>>
  6fdd22:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
  6fdd27:	e9 01 ed ff ff       	jmp    6fca2d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5a1d>
  6fdd2c:	4d 89 ee             	mov    %r13,%r14
  6fdd2f:	48 8d 05 aa 4d 36 00 	lea    0x364daa(%rip),%rax        # a62ae0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x6e0>
  6fdd36:	eb 16                	jmp    6fdd4e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d3e>
  6fdd38:	4d 89 ee             	mov    %r13,%r14
  6fdd3b:	48 8d 05 b6 4d 36 00 	lea    0x364db6(%rip),%rax        # a62af8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x6f8>
  6fdd42:	eb 0a                	jmp    6fdd4e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d3e>
  6fdd44:	49 89 c6             	mov    %rax,%r14
  6fdd47:	48 8d 05 c2 4d 36 00 	lea    0x364dc2(%rip),%rax        # a62b10 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x710>
  6fdd4e:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
  6fdd55:	00 
  6fdd56:	4c 89 f7             	mov    %r14,%rdi
  6fdd59:	48 8b 94 24 b8 03 00 	mov    0x3b8(%rsp),%rdx
  6fdd60:	00 
  6fdd61:	ff 15 59 da 38 00    	call   *0x38da59(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6fdd67:	0f 0b                	ud2
  6fdd69:	e9 27 08 00 00       	jmp    6fe595 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7585>
  6fdd6e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fdd73:	48 8d bc 24 40 04 00 	lea    0x440(%rsp),%rdi
  6fdd7a:	00 
  6fdd7b:	e8 90 48 fe ff       	call   6e2610 <core::ptr::drop_glue::<core::option::Option<gpui::runtime::Shaped>>>
  6fdd80:	e9 3b 05 00 00       	jmp    6fe2c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x72b0>
  6fdd85:	ff 15 55 d9 38 00    	call   *0x38d955(%rip)        # a8b6e0 <_DYNAMIC+0x288>
  6fdd8b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fdd90:	4e 89 b4 e4 e0 04 00 	mov    %r14,0x4e0(%rsp,%r12,8)
  6fdd97:	00 
  6fdd98:	e9 3e 07 00 00       	jmp    6fe4db <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x74cb>
  6fdd9d:	89 6c 24 18          	mov    %ebp,0x18(%rsp)
  6fdda1:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fdda6:	49 8b 74 24 18       	mov    0x18(%r12),%rsi
  6fddab:	48 85 f6             	test   %rsi,%rsi
  6fddae:	74 18                	je     6fddc8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6db8>
  6fddb0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6fddb5:	48 8b 78 20          	mov    0x20(%rax),%rdi
  6fddb9:	48 c1 e6 04          	shl    $0x4,%rsi
  6fddbd:	ba 04 00 00 00       	mov    $0x4,%edx
  6fddc2:	ff 15 e0 d8 38 00    	call   *0x38d8e0(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fddc8:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6fddcd:	48 8b 70 30          	mov    0x30(%rax),%rsi
  6fddd1:	48 85 f6             	test   %rsi,%rsi
  6fddd4:	7e 18                	jle    6fddee <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6dde>
  6fddd6:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6fdddb:	48 8b 78 38          	mov    0x38(%rax),%rdi
  6fdddf:	48 c1 e6 04          	shl    $0x4,%rsi
  6fdde3:	ba 04 00 00 00       	mov    $0x4,%edx
  6fdde8:	ff 15 ba d8 38 00    	call   *0x38d8ba(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fddee:	be 60 00 00 00       	mov    $0x60,%esi
  6fddf3:	ba 08 00 00 00       	mov    $0x8,%edx
  6fddf8:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  6fddfd:	ff 15 a5 d8 38 00    	call   *0x38d8a5(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fde03:	40 b5 01             	mov    $0x1,%bpl
  6fde06:	e9 84 0b 00 00       	jmp    6fe98f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x797f>
  6fde0b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fde10:	48 8b 03             	mov    (%rbx),%rax
  6fde13:	48 c7 80 00 01 00 00 	movq   $0x0,0x100(%rax)
  6fde1a:	00 00 00 00 
  6fde1e:	e9 27 06 00 00       	jmp    6fe44a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x743a>
  6fde23:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fde28:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  6fde2d:	48 8b 70 08          	mov    0x8(%rax),%rsi
  6fde31:	b3 01                	mov    $0x1,%bl
  6fde33:	48 85 f6             	test   %rsi,%rsi
  6fde36:	74 14                	je     6fde4c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6e3c>
  6fde38:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  6fde3d:	48 8b 50 10          	mov    0x10(%rax),%rdx
  6fde41:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  6fde46:	ff 15 5c d8 38 00    	call   *0x38d85c(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fde4c:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
  6fde53:	00 00 
  6fde55:	e9 36 0c 00 00       	jmp    6fea90 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a80>
  6fde5a:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fde5f:	41 b7 01             	mov    $0x1,%r15b
  6fde62:	b0 01                	mov    $0x1,%al
  6fde64:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fde68:	b0 01                	mov    $0x1,%al
  6fde6a:	89 04 24             	mov    %eax,(%rsp)
  6fde6d:	41 b6 01             	mov    $0x1,%r14b
  6fde70:	40 b5 01             	mov    $0x1,%bpl
  6fde73:	41 b4 01             	mov    $0x1,%r12b
  6fde76:	b0 01                	mov    $0x1,%al
  6fde78:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fde7c:	e9 c6 0c 00 00       	jmp    6feb47 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b37>
  6fde81:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fde86:	b3 01                	mov    $0x1,%bl
  6fde88:	e9 67 07 00 00       	jmp    6fe5f4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x75e4>
  6fde8d:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fde92:	48 89 df             	mov    %rbx,%rdi
  6fde95:	e8 b6 71 fe ff       	call   6e5050 <core::ptr::drop_glue::<gpui::shared_text::SharedText>>
  6fde9a:	e9 7a 04 00 00       	jmp    6fe319 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7309>
  6fde9f:	ff 15 3b d8 38 00    	call   *0x38d83b(%rip)        # a8b6e0 <_DYNAMIC+0x288>
  6fdea5:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fdeaa:	48 8b 03             	mov    (%rbx),%rax
  6fdead:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  6fdeb4:	00 
  6fdeb5:	48 89 88 d0 00 00 00 	mov    %rcx,0xd0(%rax)
  6fdebc:	66 0f 6f 84 24 90 00 	movdqa 0x90(%rsp),%xmm0
  6fdec3:	00 00 
  6fdec5:	f3 0f 7f 80 c0 00 00 	movdqu %xmm0,0xc0(%rax)
  6fdecc:	00 
  6fdecd:	e9 9c 06 00 00       	jmp    6fe56e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x755e>
  6fded2:	89 6c 24 18          	mov    %ebp,0x18(%rsp)
  6fded6:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fdedb:	4c 89 a3 00 01 00 00 	mov    %r12,0x100(%rbx)
  6fdee2:	31 db                	xor    %ebx,%ebx
  6fdee4:	e9 b3 06 00 00       	jmp    6fe59c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x758c>
  6fdee9:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fdeee:	4c 89 f7             	mov    %r14,%rdi
  6fdef1:	48 89 de             	mov    %rbx,%rsi
  6fdef4:	e8 37 87 fe ff       	call   6e6630 <core::ptr::drop_glue::<gpui::runtime::metadata::Names>>
  6fdef9:	e9 56 06 00 00       	jmp    6fe554 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7544>
  6fdefe:	ff 15 dc d7 38 00    	call   *0x38d7dc(%rip)        # a8b6e0 <_DYNAMIC+0x288>
  6fdf04:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fdf09:	45 31 ed             	xor    %r13d,%r13d
  6fdf0c:	31 db                	xor    %ebx,%ebx
  6fdf0e:	31 ed                	xor    %ebp,%ebp
  6fdf10:	45 31 f6             	xor    %r14d,%r14d
  6fdf13:	c7 04 24 00 00 00 00 	movl   $0x0,(%rsp)
  6fdf1a:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fdf21:	00 
  6fdf22:	45 31 ff             	xor    %r15d,%r15d
  6fdf25:	e9 bc 0d 00 00       	jmp    6fece6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7cd6>
  6fdf2a:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fdf2f:	45 31 ed             	xor    %r13d,%r13d
  6fdf32:	31 db                	xor    %ebx,%ebx
  6fdf34:	31 ed                	xor    %ebp,%ebp
  6fdf36:	45 31 f6             	xor    %r14d,%r14d
  6fdf39:	c7 04 24 00 00 00 00 	movl   $0x0,(%rsp)
  6fdf40:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fdf47:	00 
  6fdf48:	45 31 ff             	xor    %r15d,%r15d
  6fdf4b:	e9 58 0d 00 00       	jmp    6feca8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c98>
  6fdf50:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fdf55:	45 31 ed             	xor    %r13d,%r13d
  6fdf58:	31 db                	xor    %ebx,%ebx
  6fdf5a:	31 ed                	xor    %ebp,%ebp
  6fdf5c:	45 31 f6             	xor    %r14d,%r14d
  6fdf5f:	c7 04 24 00 00 00 00 	movl   $0x0,(%rsp)
  6fdf66:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fdf6d:	00 
  6fdf6e:	45 31 ff             	xor    %r15d,%r15d
  6fdf71:	e9 f8 0c 00 00       	jmp    6fec6e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c5e>
  6fdf76:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fdf7b:	45 31 ed             	xor    %r13d,%r13d
  6fdf7e:	31 db                	xor    %ebx,%ebx
  6fdf80:	31 ed                	xor    %ebp,%ebp
  6fdf82:	45 31 f6             	xor    %r14d,%r14d
  6fdf85:	c7 04 24 00 00 00 00 	movl   $0x0,(%rsp)
  6fdf8c:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fdf93:	00 
  6fdf94:	45 31 ff             	xor    %r15d,%r15d
  6fdf97:	e9 c5 0c 00 00       	jmp    6fec61 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c51>
  6fdf9c:	e9 8a 04 00 00       	jmp    6fe42b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x741b>
  6fdfa1:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fdfa6:	48 8b 03             	mov    (%rbx),%rax
  6fdfa9:	48 85 c0             	test   %rax,%rax
  6fdfac:	74 1e                	je     6fdfcc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6fbc>
  6fdfae:	48 8b 0c 24          	mov    (%rsp),%rcx
  6fdfb2:	48 8b b9 b0 02 00 00 	mov    0x2b0(%rcx),%rdi
  6fdfb9:	48 c1 e0 04          	shl    $0x4,%rax
  6fdfbd:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
  6fdfc1:	ba 08 00 00 00       	mov    $0x8,%edx
  6fdfc6:	ff 15 dc d6 38 00    	call   *0x38d6dc(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fdfcc:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  6fdfd3:	00 
  6fdfd4:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fdfd8:	66 0f 6f 84 24 90 00 	movdqa 0x90(%rsp),%xmm0
  6fdfdf:	00 00 
  6fdfe1:	f3 0f 7f 03          	movdqu %xmm0,(%rbx)
  6fdfe5:	b3 01                	mov    $0x1,%bl
  6fdfe7:	e9 60 04 00 00       	jmp    6fe44c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x743c>
  6fdfec:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fdff1:	4d 89 b7 b0 05 00 00 	mov    %r14,0x5b0(%r15)
  6fdff8:	49 89 9f b8 05 00 00 	mov    %rbx,0x5b8(%r15)
  6fdfff:	31 db                	xor    %ebx,%ebx
  6fe001:	eb 20                	jmp    6fe023 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7013>
  6fe003:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe008:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  6fe00f:	00 
  6fe010:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fe014:	66 0f 6f 84 24 90 00 	movdqa 0x90(%rsp),%xmm0
  6fe01b:	00 00 
  6fe01d:	f3 0f 7f 03          	movdqu %xmm0,(%rbx)
  6fe021:	b3 01                	mov    $0x1,%bl
  6fe023:	31 ed                	xor    %ebp,%ebp
  6fe025:	45 31 f6             	xor    %r14d,%r14d
  6fe028:	c7 04 24 00 00 00 00 	movl   $0x0,(%rsp)
  6fe02f:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fe036:	00 
  6fe037:	e9 d5 0a 00 00       	jmp    6feb11 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b01>
  6fe03c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe041:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  6fe048:	00 
  6fe049:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fe04d:	66 0f 28 84 24 90 00 	movapd 0x90(%rsp),%xmm0
  6fe054:	00 00 
  6fe056:	66 0f 11 03          	movupd %xmm0,(%rbx)
  6fe05a:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fe061:	00 
  6fe062:	c7 04 24 00 00 00 00 	movl   $0x0,(%rsp)
  6fe069:	31 ed                	xor    %ebp,%ebp
  6fe06b:	e9 2e 09 00 00       	jmp    6fe99e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x798e>
  6fe070:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe075:	e9 e7 04 00 00       	jmp    6fe561 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7551>
  6fe07a:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe07f:	41 b7 01             	mov    $0x1,%r15b
  6fe082:	b0 01                	mov    $0x1,%al
  6fe084:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe088:	b0 01                	mov    $0x1,%al
  6fe08a:	89 04 24             	mov    %eax,(%rsp)
  6fe08d:	41 b6 01             	mov    $0x1,%r14b
  6fe090:	40 b5 01             	mov    $0x1,%bpl
  6fe093:	41 b4 01             	mov    $0x1,%r12b
  6fe096:	b3 01                	mov    $0x1,%bl
  6fe098:	b0 01                	mov    $0x1,%al
  6fe09a:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fe09e:	e9 8f 0a 00 00       	jmp    6feb32 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b22>
  6fe0a3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe0a8:	41 b7 01             	mov    $0x1,%r15b
  6fe0ab:	b0 01                	mov    $0x1,%al
  6fe0ad:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe0b1:	b0 01                	mov    $0x1,%al
  6fe0b3:	89 04 24             	mov    %eax,(%rsp)
  6fe0b6:	41 b6 01             	mov    $0x1,%r14b
  6fe0b9:	40 b5 01             	mov    $0x1,%bpl
  6fe0bc:	b0 01                	mov    $0x1,%al
  6fe0be:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fe0c2:	e9 4d 0b 00 00       	jmp    6fec14 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c04>
  6fe0c7:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe0cc:	41 b7 01             	mov    $0x1,%r15b
  6fe0cf:	e9 5f 06 00 00       	jmp    6fe733 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7723>
  6fe0d4:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe0d9:	ba 04 00 00 00       	mov    $0x4,%edx
  6fe0de:	48 8b bc 24 10 02 00 	mov    0x210(%rsp),%rdi
  6fe0e5:	00 
  6fe0e6:	48 8b b4 24 88 02 00 	mov    0x288(%rsp),%rsi
  6fe0ed:	00 
  6fe0ee:	ff 15 b4 d5 38 00    	call   *0x38d5b4(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe0f4:	45 31 ff             	xor    %r15d,%r15d
  6fe0f7:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fe0fe:	00 
  6fe0ff:	c7 04 24 00 00 00 00 	movl   $0x0,(%rsp)
  6fe106:	45 31 f6             	xor    %r14d,%r14d
  6fe109:	31 ed                	xor    %ebp,%ebp
  6fe10b:	31 db                	xor    %ebx,%ebx
  6fe10d:	e9 20 0a 00 00       	jmp    6feb32 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b22>
  6fe112:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe117:	b0 01                	mov    $0x1,%al
  6fe119:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fe11d:	b3 01                	mov    $0x1,%bl
  6fe11f:	40 b5 01             	mov    $0x1,%bpl
  6fe122:	41 b6 01             	mov    $0x1,%r14b
  6fe125:	b0 01                	mov    $0x1,%al
  6fe127:	89 04 24             	mov    %eax,(%rsp)
  6fe12a:	b0 01                	mov    $0x1,%al
  6fe12c:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe130:	41 b7 01             	mov    $0x1,%r15b
  6fe133:	e9 eb 0a 00 00       	jmp    6fec23 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c13>
  6fe138:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe13d:	b0 01                	mov    $0x1,%al
  6fe13f:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fe143:	41 b5 01             	mov    $0x1,%r13b
  6fe146:	b3 01                	mov    $0x1,%bl
  6fe148:	40 b5 01             	mov    $0x1,%bpl
  6fe14b:	41 b6 01             	mov    $0x1,%r14b
  6fe14e:	b0 01                	mov    $0x1,%al
  6fe150:	89 04 24             	mov    %eax,(%rsp)
  6fe153:	b0 01                	mov    $0x1,%al
  6fe155:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe159:	41 b7 01             	mov    $0x1,%r15b
  6fe15c:	e9 6b 0b 00 00       	jmp    6feccc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7cbc>
  6fe161:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe166:	4c 89 f7             	mov    %r14,%rdi
  6fe169:	e8 12 44 fe ff       	call   6e2580 <core::ptr::drop_glue::<core::option::Option<gpui::shared_text::SharedText>>>
  6fe16e:	e9 68 03 00 00       	jmp    6fe4db <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x74cb>
  6fe173:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe178:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6fe17f:	00 
  6fe180:	e8 fb 45 fe ff       	call   6e2780 <core::ptr::drop_glue::<core::option::Option<gpui::runtime::TextSite>>>
  6fe185:	e9 72 01 00 00       	jmp    6fe2fc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x72ec>
  6fe18a:	ff 15 50 d5 38 00    	call   *0x38d550(%rip)        # a8b6e0 <_DYNAMIC+0x288>
  6fe190:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe195:	4c 89 ff             	mov    %r15,%rdi
  6fe198:	4c 89 ee             	mov    %r13,%rsi
  6fe19b:	e8 10 44 fe ff       	call   6e25b0 <core::ptr::drop_glue::<core::option::Option<gpui::element::Handler>>>
  6fe1a0:	41 b4 01             	mov    $0x1,%r12b
  6fe1a3:	e9 57 01 00 00       	jmp    6fe2ff <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x72ef>
  6fe1a8:	ff 15 32 d5 38 00    	call   *0x38d532(%rip)        # a8b6e0 <_DYNAMIC+0x288>
  6fe1ae:	44 89 64 24 18       	mov    %r12d,0x18(%rsp)
  6fe1b3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe1b8:	44 89 eb             	mov    %r13d,%ebx
  6fe1bb:	44 89 ed             	mov    %r13d,%ebp
  6fe1be:	45 89 ee             	mov    %r13d,%r14d
  6fe1c1:	44 89 e8             	mov    %r13d,%eax
  6fe1c4:	89 04 24             	mov    %eax,(%rsp)
  6fe1c7:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe1cb:	45 89 ef             	mov    %r13d,%r15d
  6fe1ce:	e9 81 0a 00 00       	jmp    6fec54 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c44>
  6fe1d3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe1d8:	4c 89 f7             	mov    %r14,%rdi
  6fe1db:	e8 70 6e fe ff       	call   6e5050 <core::ptr::drop_glue::<gpui::shared_text::SharedText>>
  6fe1e0:	e9 f6 02 00 00       	jmp    6fe4db <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x74cb>
  6fe1e5:	eb 00                	jmp    6fe1e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x71d7>
  6fe1e7:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe1ec:	49 83 fc ff          	cmp    $0xffffffffffffffff,%r12
  6fe1f0:	74 16                	je     6fe208 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x71f8>
  6fe1f2:	4d 85 e4             	test   %r12,%r12
  6fe1f5:	7e 11                	jle    6fe208 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x71f8>
  6fe1f7:	ba 01 00 00 00       	mov    $0x1,%edx
  6fe1fc:	4c 89 ff             	mov    %r15,%rdi
  6fe1ff:	4c 89 e6             	mov    %r12,%rsi
  6fe202:	ff 15 a0 d4 38 00    	call   *0x38d4a0(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe208:	48 83 fb ff          	cmp    $0xffffffffffffffff,%rbx
  6fe20c:	0f 84 42 03 00 00    	je     6fe554 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7544>
  6fe212:	48 85 db             	test   %rbx,%rbx
  6fe215:	0f 8e 39 03 00 00    	jle    6fe554 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7544>
  6fe21b:	ba 01 00 00 00       	mov    $0x1,%edx
  6fe220:	4c 89 f7             	mov    %r14,%rdi
  6fe223:	48 89 de             	mov    %rbx,%rsi
  6fe226:	ff 15 7c d4 38 00    	call   *0x38d47c(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe22c:	e9 23 03 00 00       	jmp    6fe554 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7544>
  6fe231:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe236:	b0 01                	mov    $0x1,%al
  6fe238:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fe23c:	41 b6 01             	mov    $0x1,%r14b
  6fe23f:	b0 01                	mov    $0x1,%al
  6fe241:	89 04 24             	mov    %eax,(%rsp)
  6fe244:	b0 01                	mov    $0x1,%al
  6fe246:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe24a:	e9 c2 08 00 00       	jmp    6feb11 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b01>
  6fe24f:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe254:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  6fe259:	48 8b 70 08          	mov    0x8(%rax),%rsi
  6fe25d:	48 85 f6             	test   %rsi,%rsi
  6fe260:	74 14                	je     6fe276 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7266>
  6fe262:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  6fe267:	48 8b 50 10          	mov    0x10(%rax),%rdx
  6fe26b:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  6fe270:	ff 15 32 d4 38 00    	call   *0x38d432(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe276:	41 b4 01             	mov    $0x1,%r12b
  6fe279:	31 ed                	xor    %ebp,%ebp
  6fe27b:	b3 01                	mov    $0x1,%bl
  6fe27d:	e9 c7 07 00 00       	jmp    6fea49 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a39>
  6fe282:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe287:	ba 04 00 00 00       	mov    $0x4,%edx
  6fe28c:	48 8b bc 24 10 02 00 	mov    0x210(%rsp),%rdi
  6fe293:	00 
  6fe294:	48 8b b4 24 88 02 00 	mov    0x288(%rsp),%rsi
  6fe29b:	00 
  6fe29c:	ff 15 06 d4 38 00    	call   *0x38d406(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe2a2:	31 db                	xor    %ebx,%ebx
  6fe2a4:	e9 be 01 00 00       	jmp    6fe467 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7457>
  6fe2a9:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe2ae:	4c 89 b4 24 68 03 00 	mov    %r14,0x368(%rsp)
  6fe2b5:	00 
  6fe2b6:	e9 b7 05 00 00       	jmp    6fe872 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7862>
  6fe2bb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe2c0:	48 89 9c 24 40 04 00 	mov    %rbx,0x440(%rsp)
  6fe2c7:	00 
  6fe2c8:	48 8b 84 24 f8 04 00 	mov    0x4f8(%rsp),%rax
  6fe2cf:	00 
  6fe2d0:	48 89 84 24 80 04 00 	mov    %rax,0x480(%rsp)
  6fe2d7:	00 
  6fe2d8:	48 8b 84 24 68 06 00 	mov    0x668(%rsp),%rax
  6fe2df:	00 
  6fe2e0:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
  6fe2e7:	00 
  6fe2e8:	eb 2f                	jmp    6fe319 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7309>
  6fe2ea:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe2ef:	48 8d bc 24 60 03 00 	lea    0x360(%rsp),%rdi
  6fe2f6:	00 
  6fe2f7:	e8 04 6f fe ff       	call   6e5200 <core::ptr::drop_glue::<gpui::runtime::TextSite>>
  6fe2fc:	45 31 e4             	xor    %r12d,%r12d
  6fe2ff:	31 ed                	xor    %ebp,%ebp
  6fe301:	31 db                	xor    %ebx,%ebx
  6fe303:	e9 41 07 00 00       	jmp    6fea49 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a39>
  6fe308:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe30d:	48 c7 84 24 40 04 00 	movq   $0xffffffffffffffff,0x440(%rsp)
  6fe314:	00 ff ff ff ff 
  6fe319:	41 b4 01             	mov    $0x1,%r12b
  6fe31c:	40 b5 01             	mov    $0x1,%bpl
  6fe31f:	b3 01                	mov    $0x1,%bl
  6fe321:	e9 23 07 00 00       	jmp    6fea49 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a39>
  6fe326:	e9 ff 06 00 00       	jmp    6fea2a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a1a>
  6fe32b:	e9 c9 03 00 00       	jmp    6fe6f9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x76e9>
  6fe330:	e9 4e 01 00 00       	jmp    6fe483 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7473>
  6fe335:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe33a:	41 b4 01             	mov    $0x1,%r12b
  6fe33d:	b0 01                	mov    $0x1,%al
  6fe33f:	89 44 24 10          	mov    %eax,0x10(%rsp)
  6fe343:	40 b5 01             	mov    $0x1,%bpl
  6fe346:	41 b6 01             	mov    $0x1,%r14b
  6fe349:	b0 01                	mov    $0x1,%al
  6fe34b:	89 04 24             	mov    %eax,(%rsp)
  6fe34e:	b0 01                	mov    $0x1,%al
  6fe350:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe354:	41 b7 01             	mov    $0x1,%r15b
  6fe357:	e9 27 0a 00 00       	jmp    6fed83 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d73>
  6fe35c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe361:	41 b4 01             	mov    $0x1,%r12b
  6fe364:	b0 01                	mov    $0x1,%al
  6fe366:	89 44 24 10          	mov    %eax,0x10(%rsp)
  6fe36a:	40 b5 01             	mov    $0x1,%bpl
  6fe36d:	41 b6 01             	mov    $0x1,%r14b
  6fe370:	b0 01                	mov    $0x1,%al
  6fe372:	89 04 24             	mov    %eax,(%rsp)
  6fe375:	b0 01                	mov    $0x1,%al
  6fe377:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe37b:	41 b7 01             	mov    $0x1,%r15b
  6fe37e:	e9 24 0a 00 00       	jmp    6feda7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d97>
  6fe383:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe388:	41 b4 01             	mov    $0x1,%r12b
  6fe38b:	b0 01                	mov    $0x1,%al
  6fe38d:	89 44 24 10          	mov    %eax,0x10(%rsp)
  6fe391:	40 b5 01             	mov    $0x1,%bpl
  6fe394:	41 b6 01             	mov    $0x1,%r14b
  6fe397:	b0 01                	mov    $0x1,%al
  6fe399:	89 04 24             	mov    %eax,(%rsp)
  6fe39c:	b0 01                	mov    $0x1,%al
  6fe39e:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe3a2:	41 b7 01             	mov    $0x1,%r15b
  6fe3a5:	e9 21 0a 00 00       	jmp    6fedcb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7dbb>
  6fe3aa:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe3af:	e9 37 07 00 00       	jmp    6feaeb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7adb>
  6fe3b4:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe3b9:	e9 b4 04 00 00       	jmp    6fe872 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7862>
  6fe3be:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
  6fe3c3:	e9 71 06 00 00       	jmp    6fea39 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a29>
  6fe3c8:	e9 09 01 00 00       	jmp    6fe4d6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x74c6>
  6fe3cd:	e9 04 01 00 00       	jmp    6fe4d6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x74c6>
  6fe3d2:	e9 48 05 00 00       	jmp    6fe91f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x790f>
  6fe3d7:	44 89 6c 24 10       	mov    %r13d,0x10(%rsp)
  6fe3dc:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe3e1:	41 89 ee             	mov    %ebp,%r14d
  6fe3e4:	89 e8                	mov    %ebp,%eax
  6fe3e6:	89 04 24             	mov    %eax,(%rsp)
  6fe3e9:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe3ed:	41 89 ef             	mov    %ebp,%r15d
  6fe3f0:	e9 e3 09 00 00       	jmp    6fedd8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7dc8>
  6fe3f5:	e9 bd 00 00 00       	jmp    6fe4b7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x74a7>
  6fe3fa:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe3ff:	41 b4 01             	mov    $0x1,%r12b
  6fe402:	b0 01                	mov    $0x1,%al
  6fe404:	89 44 24 10          	mov    %eax,0x10(%rsp)
  6fe408:	40 b5 01             	mov    $0x1,%bpl
  6fe40b:	41 b6 01             	mov    $0x1,%r14b
  6fe40e:	b0 01                	mov    $0x1,%al
  6fe410:	89 04 24             	mov    %eax,(%rsp)
  6fe413:	b0 01                	mov    $0x1,%al
  6fe415:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe419:	41 b7 01             	mov    $0x1,%r15b
  6fe41c:	e9 3e 09 00 00       	jmp    6fed5f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d4f>
  6fe421:	e9 91 00 00 00       	jmp    6fe4b7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x74a7>
  6fe426:	e9 a6 02 00 00       	jmp    6fe6d1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x76c1>
  6fe42b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe430:	48 8b 84 24 b0 01 00 	mov    0x1b0(%rsp),%rax
  6fe437:	00 
  6fe438:	49 89 47 10          	mov    %rax,0x10(%r15)
  6fe43c:	66 0f 6f 84 24 a0 01 	movdqa 0x1a0(%rsp),%xmm0
  6fe443:	00 00 
  6fe445:	f3 41 0f 7f 07       	movdqu %xmm0,(%r15)
  6fe44a:	31 db                	xor    %ebx,%ebx
  6fe44c:	ba 04 00 00 00       	mov    $0x4,%edx
  6fe451:	48 8b bc 24 10 02 00 	mov    0x210(%rsp),%rdi
  6fe458:	00 
  6fe459:	48 8b b4 24 88 02 00 	mov    0x288(%rsp),%rsi
  6fe460:	00 
  6fe461:	ff 15 41 d2 38 00    	call   *0x38d241(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe467:	31 ed                	xor    %ebp,%ebp
  6fe469:	45 31 f6             	xor    %r14d,%r14d
  6fe46c:	c7 04 24 00 00 00 00 	movl   $0x0,(%rsp)
  6fe473:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fe47a:	00 
  6fe47b:	45 31 ff             	xor    %r15d,%r15d
  6fe47e:	e9 a0 07 00 00       	jmp    6fec23 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c13>
  6fe483:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe488:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
  6fe48e:	0f 84 b1 04 00 00    	je     6fe945 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7935>
  6fe494:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  6fe499:	48 c1 e6 04          	shl    $0x4,%rsi
  6fe49d:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe4a2:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6fe4a7:	ff 15 fb d1 38 00    	call   *0x38d1fb(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe4ad:	e9 93 04 00 00       	jmp    6fe945 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7935>
  6fe4b2:	e9 73 05 00 00       	jmp    6fea2a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a1a>
  6fe4b7:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe4bc:	b3 01                	mov    $0x1,%bl
  6fe4be:	e9 dc 05 00 00       	jmp    6fea9f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a8f>
  6fe4c3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe4c8:	41 b4 01             	mov    $0x1,%r12b
  6fe4cb:	b0 01                	mov    $0x1,%al
  6fe4cd:	89 44 24 10          	mov    %eax,0x10(%rsp)
  6fe4d1:	e9 03 03 00 00       	jmp    6fe7d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x77c9>
  6fe4d6:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe4db:	48 8b b4 24 40 04 00 	mov    0x440(%rsp),%rsi
  6fe4e2:	00 
  6fe4e3:	48 85 f6             	test   %rsi,%rsi
  6fe4e6:	7e 1a                	jle    6fe502 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x74f2>
  6fe4e8:	48 8b bc 24 48 04 00 	mov    0x448(%rsp),%rdi
  6fe4ef:	00 
  6fe4f0:	ba 01 00 00 00       	mov    $0x1,%edx
  6fe4f5:	ff 15 ad d1 38 00    	call   *0x38d1ad(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe4fb:	eb 05                	jmp    6fe502 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x74f2>
  6fe4fd:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe502:	48 85 db             	test   %rbx,%rbx
  6fe505:	7e 16                	jle    6fe51d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x750d>
  6fe507:	48 8b bc 24 d8 06 00 	mov    0x6d8(%rsp),%rdi
  6fe50e:	00 
  6fe50f:	ba 01 00 00 00       	mov    $0x1,%edx
  6fe514:	48 89 de             	mov    %rbx,%rsi
  6fe517:	ff 15 8b d1 38 00    	call   *0x38d18b(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe51d:	48 8b b4 24 c0 02 00 	mov    0x2c0(%rsp),%rsi
  6fe524:	00 
  6fe525:	48 8b 94 24 c8 02 00 	mov    0x2c8(%rsp),%rdx
  6fe52c:	00 
  6fe52d:	48 8d bc 24 d0 02 00 	lea    0x2d0(%rsp),%rdi
  6fe534:	00 
  6fe535:	e8 26 0c 02 00       	call   71f160 <<[core::mem::maybe_uninit::MaybeUninit<core::option::Option<gpui::source::Text>>; 2] as core::array::iter::iter_inner::PartialDrop>::partial_drop>
  6fe53a:	48 8b bc 24 e8 04 00 	mov    0x4e8(%rsp),%rdi
  6fe541:	00 
  6fe542:	e8 39 40 fe ff       	call   6e2580 <core::ptr::drop_glue::<core::option::Option<gpui::shared_text::SharedText>>>
  6fe547:	48 8b bc 24 e0 04 00 	mov    0x4e0(%rsp),%rdi
  6fe54e:	00 
  6fe54f:	e8 2c 40 fe ff       	call   6e2580 <core::ptr::drop_glue::<core::option::Option<gpui::shared_text::SharedText>>>
  6fe554:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6fe55b:	00 
  6fe55c:	e8 ff 65 fe ff       	call   6e4b60 <core::ptr::drop_glue::<core::iter::adapters::zip::Zip<alloc::vec::into_iter::IntoIter<gpui::semantic::AnnotationDraft>, alloc::vec::into_iter::IntoIter<[core::option::Option<gpui::source::FieldId>; 2]>>>>
  6fe561:	48 8d bc 24 a8 04 00 	lea    0x4a8(%rsp),%rdi
  6fe568:	00 
  6fe569:	e8 c2 5d fe ff       	call   6e4330 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::metadata::Declared>>>
  6fe56e:	b0 01                	mov    $0x1,%al
  6fe570:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe574:	c7 04 24 00 00 00 00 	movl   $0x0,(%rsp)
  6fe57b:	40 b5 01             	mov    $0x1,%bpl
  6fe57e:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
  6fe585:	00 
  6fe586:	e9 13 04 00 00       	jmp    6fe99e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x798e>
  6fe58b:	e9 be 01 00 00       	jmp    6fe74e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x773e>
  6fe590:	e9 b9 01 00 00       	jmp    6fe74e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x773e>
  6fe595:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe59a:	b3 01                	mov    $0x1,%bl
  6fe59c:	48 83 bc 24 48 01 00 	cmpq   $0x0,0x148(%rsp)
  6fe5a3:	00 00 
  6fe5a5:	74 1f                	je     6fe5c6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x75b6>
  6fe5a7:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
  6fe5ae:	00 
  6fe5af:	48 c1 e6 04          	shl    $0x4,%rsi
  6fe5b3:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe5b8:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  6fe5bf:	00 
  6fe5c0:	ff 15 e2 d0 38 00    	call   *0x38d0e2(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe5c6:	84 db                	test   %bl,%bl
  6fe5c8:	0f 84 c2 00 00 00    	je     6fe690 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7680>
  6fe5ce:	48 8b b4 24 c0 02 00 	mov    0x2c0(%rsp),%rsi
  6fe5d5:	00 
  6fe5d6:	48 85 f6             	test   %rsi,%rsi
  6fe5d9:	74 17                	je     6fe5f2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x75e2>
  6fe5db:	48 8b bc 24 c8 02 00 	mov    0x2c8(%rsp),%rdi
  6fe5e2:	00 
  6fe5e3:	48 c1 e6 04          	shl    $0x4,%rsi
  6fe5e7:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe5ec:	ff 15 b6 d0 38 00    	call   *0x38d0b6(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe5f2:	31 db                	xor    %ebx,%ebx
  6fe5f4:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6fe5f9:	48 8b 30             	mov    (%rax),%rsi
  6fe5fc:	48 85 f6             	test   %rsi,%rsi
  6fe5ff:	74 18                	je     6fe619 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7609>
  6fe601:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6fe606:	48 8b 78 08          	mov    0x8(%rax),%rdi
  6fe60a:	48 c1 e6 04          	shl    $0x4,%rsi
  6fe60e:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe613:	ff 15 8f d0 38 00    	call   *0x38d08f(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe619:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6fe61e:	48 8d 78 48          	lea    0x48(%rax),%rdi
  6fe622:	e8 b9 e6 00 00       	call   70cce0 <<alloc::collections::btree::map::BTreeMap<u64, gpui::property::Overlay<gpui::property::GeometryStyle>> as core::ops::drop::Drop>::drop>
  6fe627:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6fe62c:	48 8b 70 18          	mov    0x18(%rax),%rsi
  6fe630:	48 85 f6             	test   %rsi,%rsi
  6fe633:	74 18                	je     6fe64d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x763d>
  6fe635:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6fe63a:	48 8b 78 20          	mov    0x20(%rax),%rdi
  6fe63e:	48 c1 e6 04          	shl    $0x4,%rsi
  6fe642:	ba 04 00 00 00       	mov    $0x4,%edx
  6fe647:	ff 15 5b d0 38 00    	call   *0x38d05b(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe64d:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6fe652:	48 8b 70 30          	mov    0x30(%rax),%rsi
  6fe656:	48 85 f6             	test   %rsi,%rsi
  6fe659:	7e 18                	jle    6fe673 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7663>
  6fe65b:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6fe660:	48 8b 78 38          	mov    0x38(%rax),%rdi
  6fe664:	48 c1 e6 04          	shl    $0x4,%rsi
  6fe668:	ba 04 00 00 00       	mov    $0x4,%edx
  6fe66d:	ff 15 35 d0 38 00    	call   *0x38d035(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe673:	be 60 00 00 00       	mov    $0x60,%esi
  6fe678:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe67d:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  6fe682:	ff 15 20 d0 38 00    	call   *0x38d020(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe688:	84 db                	test   %bl,%bl
  6fe68a:	0f 85 d2 02 00 00    	jne    6fe962 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7952>
  6fe690:	40 b5 01             	mov    $0x1,%bpl
  6fe693:	e9 f7 02 00 00       	jmp    6fe98f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x797f>
  6fe698:	ff 15 42 d0 38 00    	call   *0x38d042(%rip)        # a8b6e0 <_DYNAMIC+0x288>
  6fe69e:	e9 d2 04 00 00       	jmp    6feb75 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b65>
  6fe6a3:	e9 53 02 00 00       	jmp    6fe8fb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x78eb>
  6fe6a8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe6ad:	41 b7 01             	mov    $0x1,%r15b
  6fe6b0:	b0 01                	mov    $0x1,%al
  6fe6b2:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe6b6:	40 b5 01             	mov    $0x1,%bpl
  6fe6b9:	41 b6 01             	mov    $0x1,%r14b
  6fe6bc:	41 b4 01             	mov    $0x1,%r12b
  6fe6bf:	48 8b 9c 24 08 04 00 	mov    0x408(%rsp),%rbx
  6fe6c6:	00 
  6fe6c7:	e9 5f 07 00 00       	jmp    6fee2b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e1b>
  6fe6cc:	e9 2a 02 00 00       	jmp    6fe8fb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x78eb>
  6fe6d1:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe6d6:	41 b7 01             	mov    $0x1,%r15b
  6fe6d9:	b0 01                	mov    $0x1,%al
  6fe6db:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe6df:	b0 01                	mov    $0x1,%al
  6fe6e1:	89 04 24             	mov    %eax,(%rsp)
  6fe6e4:	41 b6 01             	mov    $0x1,%r14b
  6fe6e7:	40 b5 01             	mov    $0x1,%bpl
  6fe6ea:	b3 01                	mov    $0x1,%bl
  6fe6ec:	41 b5 01             	mov    $0x1,%r13b
  6fe6ef:	e9 f9 05 00 00       	jmp    6feced <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7cdd>
  6fe6f4:	e9 49 03 00 00       	jmp    6fea42 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a32>
  6fe6f9:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe6fe:	41 b7 01             	mov    $0x1,%r15b
  6fe701:	48 83 bc 24 08 02 00 	cmpq   $0x0,0x208(%rsp)
  6fe708:	00 00 
  6fe70a:	74 27                	je     6fe733 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7723>
  6fe70c:	48 8b 84 24 08 02 00 	mov    0x208(%rsp),%rax
  6fe713:	00 
  6fe714:	48 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%rax
  6fe71b:	00 
  6fe71c:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6fe720:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe725:	48 8b bc 24 30 02 00 	mov    0x230(%rsp),%rdi
  6fe72c:	00 
  6fe72d:	ff 15 75 cf 38 00    	call   *0x38cf75(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe733:	b0 01                	mov    $0x1,%al
  6fe735:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe739:	b0 01                	mov    $0x1,%al
  6fe73b:	89 04 24             	mov    %eax,(%rsp)
  6fe73e:	41 b6 01             	mov    $0x1,%r14b
  6fe741:	40 b5 01             	mov    $0x1,%bpl
  6fe744:	b3 01                	mov    $0x1,%bl
  6fe746:	41 b4 01             	mov    $0x1,%r12b
  6fe749:	e9 d0 05 00 00       	jmp    6fed1e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d0e>
  6fe74e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe753:	b0 01                	mov    $0x1,%al
  6fe755:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fe759:	41 b5 01             	mov    $0x1,%r13b
  6fe75c:	b3 01                	mov    $0x1,%bl
  6fe75e:	40 b5 01             	mov    $0x1,%bpl
  6fe761:	41 b6 01             	mov    $0x1,%r14b
  6fe764:	b0 01                	mov    $0x1,%al
  6fe766:	89 04 24             	mov    %eax,(%rsp)
  6fe769:	b0 01                	mov    $0x1,%al
  6fe76b:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe76f:	41 b7 01             	mov    $0x1,%r15b
  6fe772:	e9 62 05 00 00       	jmp    6fecd9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7cc9>
  6fe777:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe77c:	41 89 dc             	mov    %ebx,%r12d
  6fe77f:	44 89 f8             	mov    %r15d,%eax
  6fe782:	89 04 24             	mov    %eax,(%rsp)
  6fe785:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe789:	45 89 fe             	mov    %r15d,%r14d
  6fe78c:	e9 68 06 00 00       	jmp    6fedf9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7de9>
  6fe791:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe796:	44 89 f8             	mov    %r15d,%eax
  6fe799:	89 04 24             	mov    %eax,(%rsp)
  6fe79c:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe7a0:	45 89 fe             	mov    %r15d,%r14d
  6fe7a3:	e9 5e 06 00 00       	jmp    6fee06 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7df6>
  6fe7a8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe7ad:	4d 85 f6             	test   %r14,%r14
  6fe7b0:	75 3d                	jne    6fe7ef <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x77df>
  6fe7b2:	48 8b b4 24 90 04 00 	mov    0x490(%rsp),%rsi
  6fe7b9:	00 
  6fe7ba:	41 b4 01             	mov    $0x1,%r12b
  6fe7bd:	48 85 f6             	test   %rsi,%rsi
  6fe7c0:	74 17                	je     6fe7d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x77c9>
  6fe7c2:	48 8b bc 24 98 04 00 	mov    0x498(%rsp),%rdi
  6fe7c9:	00 
  6fe7ca:	48 c1 e6 03          	shl    $0x3,%rsi
  6fe7ce:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe7d3:	ff 15 cf ce 38 00    	call   *0x38cecf(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe7d9:	41 b6 01             	mov    $0x1,%r14b
  6fe7dc:	b0 01                	mov    $0x1,%al
  6fe7de:	89 04 24             	mov    %eax,(%rsp)
  6fe7e1:	b0 01                	mov    $0x1,%al
  6fe7e3:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe7e7:	41 b7 01             	mov    $0x1,%r15b
  6fe7ea:	e9 fb 05 00 00       	jmp    6fedea <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7dda>
  6fe7ef:	48 83 c3 08          	add    $0x8,%rbx
  6fe7f3:	49 f7 de             	neg    %r14
  6fe7f6:	eb 11                	jmp    6fe809 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x77f9>
  6fe7f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6fe7ff:	00 
  6fe800:	48 83 c3 08          	add    $0x8,%rbx
  6fe804:	49 ff ce             	dec    %r14
  6fe807:	74 a9                	je     6fe7b2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x77a2>
  6fe809:	48 8b 03             	mov    (%rbx),%rax
  6fe80c:	f0 48 ff 08          	lock decq (%rax)
  6fe810:	75 ee                	jne    6fe800 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x77f0>
  6fe812:	48 89 df             	mov    %rbx,%rdi
  6fe815:	41 ff d7             	call   *%r15
  6fe818:	eb e6                	jmp    6fe800 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x77f0>
  6fe81a:	ff 15 c0 ce 38 00    	call   *0x38cec0(%rip)        # a8b6e0 <_DYNAMIC+0x288>
  6fe820:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe825:	e9 ce 06 00 00       	jmp    6feef8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ee8>
  6fe82a:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe82f:	eb 15                	jmp    6fe846 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7836>
  6fe831:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe836:	48 8b 84 24 98 02 00 	mov    0x298(%rsp),%rax
  6fe83d:	00 
  6fe83e:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
  6fe845:	00 
  6fe846:	48 83 7c 24 38 00    	cmpq   $0x0,0x38(%rsp)
  6fe84c:	75 0b                	jne    6fe859 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7849>
  6fe84e:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
  6fe855:	00 00 
  6fe857:	eb 19                	jmp    6fe872 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7862>
  6fe859:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  6fe85e:	48 c1 e6 05          	shl    $0x5,%rsi
  6fe862:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe867:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  6fe86c:	ff 15 36 ce 38 00    	call   *0x38ce36(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe872:	48 83 bc 24 78 01 00 	cmpq   $0x0,0x178(%rsp)
  6fe879:	00 00 
  6fe87b:	74 1f                	je     6fe89c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x788c>
  6fe87d:	48 8b b4 24 78 01 00 	mov    0x178(%rsp),%rsi
  6fe884:	00 
  6fe885:	48 c1 e6 03          	shl    $0x3,%rsi
  6fe889:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe88e:	48 8b bc 24 f0 03 00 	mov    0x3f0(%rsp),%rdi
  6fe895:	00 
  6fe896:	ff 15 0c ce 38 00    	call   *0x38ce0c(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe89c:	48 8b 84 24 e8 03 00 	mov    0x3e8(%rsp),%rax
  6fe8a3:	00 
  6fe8a4:	48 39 84 24 80 01 00 	cmp    %rax,0x180(%rsp)
  6fe8ab:	00 
  6fe8ac:	0f 92 c0             	setb   %al
  6fe8af:	48 83 7c 24 38 00    	cmpq   $0x0,0x38(%rsp)
  6fe8b5:	0f 94 c1             	sete   %cl
  6fe8b8:	08 c1                	or     %al,%cl
  6fe8ba:	75 19                	jne    6fe8d5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x78c5>
  6fe8bc:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  6fe8c1:	48 c1 e6 05          	shl    $0x5,%rsi
  6fe8c5:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe8ca:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  6fe8cf:	ff 15 d3 cd 38 00    	call   *0x38cdd3(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe8d5:	b0 01                	mov    $0x1,%al
  6fe8d7:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe8db:	48 8d bc 24 60 03 00 	lea    0x360(%rsp),%rdi
  6fe8e2:	00 
  6fe8e3:	e8 d8 08 02 00       	call   71f1c0 <<alloc::vec::into_iter::IntoIter<gpui::list::ListDraft> as core::ops::drop::Drop>::drop>
  6fe8e8:	b0 01                	mov    $0x1,%al
  6fe8ea:	89 04 24             	mov    %eax,(%rsp)
  6fe8ed:	40 b5 01             	mov    $0x1,%bpl
  6fe8f0:	b0 01                	mov    $0x1,%al
  6fe8f2:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fe8f6:	e9 a3 00 00 00       	jmp    6fe99e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x798e>
  6fe8fb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe900:	41 b7 01             	mov    $0x1,%r15b
  6fe903:	b0 01                	mov    $0x1,%al
  6fe905:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe909:	b0 01                	mov    $0x1,%al
  6fe90b:	89 04 24             	mov    %eax,(%rsp)
  6fe90e:	41 b6 01             	mov    $0x1,%r14b
  6fe911:	40 b5 01             	mov    $0x1,%bpl
  6fe914:	b0 01                	mov    $0x1,%al
  6fe916:	89 44 24 10          	mov    %eax,0x10(%rsp)
  6fe91a:	e9 9c 02 00 00       	jmp    6febbb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7bab>
  6fe91f:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe924:	41 b7 01             	mov    $0x1,%r15b
  6fe927:	b0 01                	mov    $0x1,%al
  6fe929:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe92d:	b0 01                	mov    $0x1,%al
  6fe92f:	89 04 24             	mov    %eax,(%rsp)
  6fe932:	41 b6 01             	mov    $0x1,%r14b
  6fe935:	40 b5 01             	mov    $0x1,%bpl
  6fe938:	41 b4 01             	mov    $0x1,%r12b
  6fe93b:	e9 04 04 00 00       	jmp    6fed44 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d34>
  6fe940:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe945:	b0 01                	mov    $0x1,%al
  6fe947:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe94b:	c7 04 24 00 00 00 00 	movl   $0x0,(%rsp)
  6fe952:	40 b5 01             	mov    $0x1,%bpl
  6fe955:	b0 01                	mov    $0x1,%al
  6fe957:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fe95b:	eb 41                	jmp    6fe99e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x798e>
  6fe95d:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe962:	40 b5 01             	mov    $0x1,%bpl
  6fe965:	48 83 bc 24 48 01 00 	cmpq   $0x0,0x148(%rsp)
  6fe96c:	00 00 
  6fe96e:	74 1f                	je     6fe98f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x797f>
  6fe970:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
  6fe977:	00 
  6fe978:	48 c1 e6 04          	shl    $0x4,%rsi
  6fe97c:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe981:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  6fe988:	00 
  6fe989:	ff 15 19 cd 38 00    	call   *0x38cd19(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fe98f:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fe996:	00 
  6fe997:	c7 04 24 00 00 00 00 	movl   $0x0,(%rsp)
  6fe99e:	48 8d bc 24 f8 06 00 	lea    0x6f8(%rsp),%rdi
  6fe9a5:	00 
  6fe9a6:	e8 05 db 00 00       	call   70c4b0 <<alloc::collections::btree::map::BTreeMap<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize> as core::ops::drop::Drop>::drop>
  6fe9ab:	b3 01                	mov    $0x1,%bl
  6fe9ad:	40 84 ed             	test   %bpl,%bpl
  6fe9b0:	74 0d                	je     6fe9bf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x79af>
  6fe9b2:	48 8d bc 24 20 05 00 	lea    0x520(%rsp),%rdi
  6fe9b9:	00 
  6fe9ba:	e8 81 d7 00 00       	call   70c140 <<alloc::collections::btree::map::BTreeMap<gpui::runtime::scroll::ViewportKey, gpui::runtime::scroll::ViewportState> as core::ops::drop::Drop>::drop>
  6fe9bf:	31 ed                	xor    %ebp,%ebp
  6fe9c1:	45 31 f6             	xor    %r14d,%r14d
  6fe9c4:	e9 48 01 00 00       	jmp    6feb11 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b01>
  6fe9c9:	eb 6e                	jmp    6fea39 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a29>
  6fe9cb:	0f 0b                	ud2
  6fe9cd:	0f 0b                	ud2
  6fe9cf:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fe9d4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fe9db:	00 00 00 00 00 
  6fe9e0:	49 ff cf             	dec    %r15
  6fe9e3:	74 14                	je     6fe9f9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x79e9>
  6fe9e5:	4d 8d a6 98 00 00 00 	lea    0x98(%r14),%r12
  6fe9ec:	4c 89 f7             	mov    %r14,%rdi
  6fe9ef:	e8 2c 39 00 00       	call   702320 <core::ptr::drop_glue::<gpui::element::DraftNode>>
  6fe9f4:	4d 89 e6             	mov    %r12,%r14
  6fe9f7:	eb e7                	jmp    6fe9e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x79d0>
  6fe9f9:	48 8b 84 24 10 04 00 	mov    0x410(%rsp),%rax
  6fea00:	00 
  6fea01:	48 85 c0             	test   %rax,%rax
  6fea04:	0f 84 ee 04 00 00    	je     6feef8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ee8>
  6fea0a:	48 69 f0 98 00 00 00 	imul   $0x98,%rax,%rsi
  6fea11:	ba 08 00 00 00       	mov    $0x8,%edx
  6fea16:	48 89 df             	mov    %rbx,%rdi
  6fea19:	ff 15 89 cc 38 00    	call   *0x38cc89(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fea1f:	e9 d4 04 00 00       	jmp    6feef8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ee8>
  6fea24:	ff 15 b6 cc 38 00    	call   *0x38ccb6(%rip)        # a8b6e0 <_DYNAMIC+0x288>
  6fea2a:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fea2f:	41 b4 01             	mov    $0x1,%r12b
  6fea32:	40 b5 01             	mov    $0x1,%bpl
  6fea35:	b3 01                	mov    $0x1,%bl
  6fea37:	eb 35                	jmp    6fea6e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a5e>
  6fea39:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fea3e:	b3 01                	mov    $0x1,%bl
  6fea40:	eb 4e                	jmp    6fea90 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a80>
  6fea42:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6fea47:	89 eb                	mov    %ebp,%ebx
  6fea49:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
  6fea50:	00 
  6fea51:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
  6fea55:	48 83 f8 fc          	cmp    $0xfffffffffffffffc,%rax
  6fea59:	77 13                	ja     6fea6e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a5e>
  6fea5b:	ba 01 00 00 00       	mov    $0x1,%edx
  6fea60:	48 8b bc 24 d8 03 00 	mov    0x3d8(%rsp),%rdi
  6fea67:	00 
  6fea68:	ff 15 3a cc 38 00    	call   *0x38cc3a(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fea6e:	45 84 e4             	test   %r12b,%r12b
  6fea71:	74 18                	je     6fea8b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a7b>
  6fea73:	48 83 bc 24 40 04 00 	cmpq   $0xfffffffffffffffe,0x440(%rsp)
  6fea7a:	00 fe 
  6fea7c:	74 0d                	je     6fea8b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a7b>
  6fea7e:	48 8d bc 24 40 04 00 	lea    0x440(%rsp),%rdi
  6fea85:	00 
  6fea86:	e8 75 67 fe ff       	call   6e5200 <core::ptr::drop_glue::<gpui::runtime::TextSite>>
  6fea8b:	40 84 ed             	test   %bpl,%bpl
  6fea8e:	74 0f                	je     6fea9f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a8f>
  6fea90:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  6fea95:	48 8b 74 24 78       	mov    0x78(%rsp),%rsi
  6fea9a:	e8 11 3b fe ff       	call   6e25b0 <core::ptr::drop_glue::<core::option::Option<gpui::element::Handler>>>
  6fea9f:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
  6feaa6:	00 
  6feaa7:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6feaab:	74 18                	je     6feac5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ab5>
  6feaad:	48 85 f6             	test   %rsi,%rsi
  6feab0:	7e 13                	jle    6feac5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ab5>
  6feab2:	48 8b bc 24 98 00 00 	mov    0x98(%rsp),%rdi
  6feab9:	00 
  6feaba:	ba 01 00 00 00       	mov    $0x1,%edx
  6feabf:	ff 15 e3 cb 38 00    	call   *0x38cbe3(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6feac5:	84 db                	test   %bl,%bl
  6feac7:	74 15                	je     6feade <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ace>
  6feac9:	48 8b bc 24 08 01 00 	mov    0x108(%rsp),%rdi
  6fead0:	00 
  6fead1:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
  6fead8:	00 
  6fead9:	e8 d2 3a fe ff       	call   6e25b0 <core::ptr::drop_glue::<core::option::Option<gpui::element::Handler>>>
  6feade:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  6feae5:	00 
  6feae6:	e8 95 65 fe ff       	call   6e5080 <core::ptr::drop_glue::<gpui::element::ComponentBoundaries>>
  6feaeb:	b0 01                	mov    $0x1,%al
  6feaed:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6feaf1:	48 8d bc 24 d0 06 00 	lea    0x6d0(%rsp),%rdi
  6feaf8:	00 
  6feaf9:	e8 62 08 02 00       	call   71f360 <<alloc::vec::into_iter::IntoIter<gpui::element::DraftNode> as core::ops::drop::Drop>::drop>
  6feafe:	b3 01                	mov    $0x1,%bl
  6feb00:	40 b5 01             	mov    $0x1,%bpl
  6feb03:	41 b6 01             	mov    $0x1,%r14b
  6feb06:	b0 01                	mov    $0x1,%al
  6feb08:	89 04 24             	mov    %eax,(%rsp)
  6feb0b:	b0 01                	mov    $0x1,%al
  6feb0d:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6feb11:	ba 04 00 00 00       	mov    $0x4,%edx
  6feb16:	48 8b bc 24 10 02 00 	mov    0x210(%rsp),%rdi
  6feb1d:	00 
  6feb1e:	48 8b b4 24 88 02 00 	mov    0x288(%rsp),%rsi
  6feb25:	00 
  6feb26:	ff 15 7c cb 38 00    	call   *0x38cb7c(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6feb2c:	41 b4 01             	mov    $0x1,%r12b
  6feb2f:	45 31 ff             	xor    %r15d,%r15d
  6feb32:	48 8d bc 24 68 05 00 	lea    0x568(%rsp),%rdi
  6feb39:	00 
  6feb3a:	e8 71 50 fe ff       	call   6e3bb0 <core::ptr::drop_glue::<alloc::vec::Vec<core::option::Option<gpui::runtime::TextSite>>>>
  6feb3f:	84 db                	test   %bl,%bl
  6feb41:	0f 84 c6 00 00 00    	je     6fec0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7bfd>
  6feb47:	48 8d bc 24 50 05 00 	lea    0x550(%rsp),%rdi
  6feb4e:	00 
  6feb4f:	e8 fc 4f fe ff       	call   6e3b50 <core::ptr::drop_glue::<alloc::vec::Vec<core::option::Option<gpui::element::Handler>>>>
  6feb54:	e9 8c 00 00 00       	jmp    6febe5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7bd5>
  6feb59:	eb 1a                	jmp    6feb75 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b65>
  6feb5b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6feb60:	ba 08 00 00 00       	mov    $0x8,%edx
  6feb65:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
  6feb6a:	48 89 de             	mov    %rbx,%rsi
  6feb6d:	ff 15 35 cb 38 00    	call   *0x38cb35(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6feb73:	eb 05                	jmp    6feb7a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b6a>
  6feb75:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6feb7a:	b0 01                	mov    $0x1,%al
  6feb7c:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6feb80:	41 b5 01             	mov    $0x1,%r13b
  6feb83:	b3 01                	mov    $0x1,%bl
  6feb85:	40 b5 01             	mov    $0x1,%bpl
  6feb88:	41 b6 01             	mov    $0x1,%r14b
  6feb8b:	b0 01                	mov    $0x1,%al
  6feb8d:	89 04 24             	mov    %eax,(%rsp)
  6feb90:	b0 01                	mov    $0x1,%al
  6feb92:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6feb96:	41 b7 01             	mov    $0x1,%r15b
  6feb99:	e9 a9 00 00 00       	jmp    6fec47 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c37>
  6feb9e:	89 5c 24 10          	mov    %ebx,0x10(%rsp)
  6feba2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6feba7:	41 b7 01             	mov    $0x1,%r15b
  6febaa:	b0 01                	mov    $0x1,%al
  6febac:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6febb0:	b0 01                	mov    $0x1,%al
  6febb2:	89 04 24             	mov    %eax,(%rsp)
  6febb5:	41 b6 01             	mov    $0x1,%r14b
  6febb8:	40 b5 01             	mov    $0x1,%bpl
  6febbb:	41 b4 01             	mov    $0x1,%r12b
  6febbe:	e9 74 01 00 00       	jmp    6fed37 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d27>
  6febc3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6febc8:	41 b7 01             	mov    $0x1,%r15b
  6febcb:	b0 01                	mov    $0x1,%al
  6febcd:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6febd1:	b0 01                	mov    $0x1,%al
  6febd3:	89 04 24             	mov    %eax,(%rsp)
  6febd6:	41 b6 01             	mov    $0x1,%r14b
  6febd9:	40 b5 01             	mov    $0x1,%bpl
  6febdc:	41 b4 01             	mov    $0x1,%r12b
  6febdf:	b0 01                	mov    $0x1,%al
  6febe1:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6febe5:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  6febec:	00 
  6febed:	48 85 c0             	test   %rax,%rax
  6febf0:	74 1b                	je     6fec0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7bfd>
  6febf2:	48 8b bc 24 90 01 00 	mov    0x190(%rsp),%rdi
  6febf9:	00 
  6febfa:	48 c1 e0 03          	shl    $0x3,%rax
  6febfe:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6fec02:	ba 08 00 00 00       	mov    $0x8,%edx
  6fec07:	ff 15 9b ca 38 00    	call   *0x38ca9b(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fec0d:	b3 01                	mov    $0x1,%bl
  6fec0f:	45 84 e4             	test   %r12b,%r12b
  6fec12:	74 0f                	je     6fec23 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c13>
  6fec14:	b3 01                	mov    $0x1,%bl
  6fec16:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6fec1d:	00 
  6fec1e:	e8 ad 78 fe ff       	call   6e64d0 <core::ptr::drop_glue::<gpui::runtime::styles::Builder>>
  6fec23:	48 8b b4 24 90 02 00 	mov    0x290(%rsp),%rsi
  6fec2a:	00 
  6fec2b:	48 85 f6             	test   %rsi,%rsi
  6fec2e:	74 14                	je     6fec44 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c34>
  6fec30:	48 c1 e6 03          	shl    $0x3,%rsi
  6fec34:	ba 08 00 00 00       	mov    $0x8,%edx
  6fec39:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
  6fec3e:	ff 15 64 ca 38 00    	call   *0x38ca64(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fec44:	45 31 ed             	xor    %r13d,%r13d
  6fec47:	48 8d bc 24 98 08 00 	lea    0x898(%rsp),%rdi
  6fec4e:	00 
  6fec4f:	e8 cc db 00 00       	call   70c820 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fec54:	48 8d bc 24 88 06 00 	lea    0x688(%rsp),%rdi
  6fec5b:	00 
  6fec5c:	e8 4f d8 00 00       	call   70c4b0 <<alloc::collections::btree::map::BTreeMap<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize> as core::ops::drop::Drop>::drop>
  6fec61:	48 8d bc 24 70 06 00 	lea    0x670(%rsp),%rdi
  6fec68:	00 
  6fec69:	e8 42 d8 00 00       	call   70c4b0 <<alloc::collections::btree::map::BTreeMap<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize> as core::ops::drop::Drop>::drop>
  6fec6e:	48 8b 84 24 60 06 00 	mov    0x660(%rsp),%rax
  6fec75:	00 
  6fec76:	48 85 c0             	test   %rax,%rax
  6fec79:	74 18                	je     6fec93 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c83>
  6fec7b:	48 c1 e0 03          	shl    $0x3,%rax
  6fec7f:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6fec83:	ba 08 00 00 00       	mov    $0x8,%edx
  6fec88:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  6fec8d:	ff 15 15 ca 38 00    	call   *0x38ca15(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fec93:	48 8b bc 24 f0 04 00 	mov    0x4f0(%rsp),%rdi
  6fec9a:	00 
  6fec9b:	48 8b b4 24 d0 03 00 	mov    0x3d0(%rsp),%rsi
  6feca2:	00 
  6feca3:	e8 a8 59 fe ff       	call   6e4650 <core::ptr::drop_glue::<alloc::boxed::Box<[core::option::Option<gpui::element::Handler>]>>>
  6feca8:	48 8b b4 24 c8 07 00 	mov    0x7c8(%rsp),%rsi
  6fecaf:	00 
  6fecb0:	48 85 f6             	test   %rsi,%rsi
  6fecb3:	74 17                	je     6feccc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7cbc>
  6fecb5:	48 8b bc 24 d0 07 00 	mov    0x7d0(%rsp),%rdi
  6fecbc:	00 
  6fecbd:	48 c1 e6 02          	shl    $0x2,%rsi
  6fecc1:	ba 04 00 00 00       	mov    $0x4,%edx
  6fecc6:	ff 15 dc c9 38 00    	call   *0x38c9dc(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6feccc:	48 8d bc 24 a0 06 00 	lea    0x6a0(%rsp),%rdi
  6fecd3:	00 
  6fecd4:	e8 c7 76 fe ff       	call   6e63a0 <core::ptr::drop_glue::<gpui::runtime::styles::Styles>>
  6fecd9:	48 8d bc 24 28 04 00 	lea    0x428(%rsp),%rdi
  6fece0:	00 
  6fece1:	e8 da cb 00 00       	call   70b8c0 <<alloc::collections::btree::map::BTreeMap<gpui::source::FieldId, gpui::shared_text::SharedText> as core::ops::drop::Drop>::drop>
  6fece6:	80 7c 24 18 00       	cmpb   $0x0,0x18(%rsp)
  6feceb:	74 29                	je     6fed16 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d06>
  6feced:	48 8b b4 24 70 02 00 	mov    0x270(%rsp),%rsi
  6fecf4:	00 
  6fecf5:	41 b4 01             	mov    $0x1,%r12b
  6fecf8:	48 85 f6             	test   %rsi,%rsi
  6fecfb:	74 1c                	je     6fed19 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d09>
  6fecfd:	48 8b bc 24 78 02 00 	mov    0x278(%rsp),%rdi
  6fed04:	00 
  6fed05:	48 c1 e6 04          	shl    $0x4,%rsi
  6fed09:	ba 08 00 00 00       	mov    $0x8,%edx
  6fed0e:	ff 15 94 c9 38 00    	call   *0x38c994(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fed14:	eb 03                	jmp    6fed19 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d09>
  6fed16:	45 31 e4             	xor    %r12d,%r12d
  6fed19:	45 84 ed             	test   %r13b,%r13b
  6fed1c:	74 0d                	je     6fed2b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d1b>
  6fed1e:	48 8d bc 24 e0 07 00 	lea    0x7e0(%rsp),%rdi
  6fed25:	00 
  6fed26:	e8 f5 85 fe ff       	call   6e7320 <core::ptr::drop_glue::<gpui::runtime::styles::colours::Discovery>>
  6fed2b:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
  6fed32:	00 
  6fed33:	84 db                	test   %bl,%bl
  6fed35:	74 0d                	je     6fed44 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d34>
  6fed37:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  6fed3e:	00 
  6fed3f:	e8 6c cc 00 00       	call   70b9b0 <<alloc::collections::btree::map::BTreeMap<gpui::source::FieldId, gpui::runtime::Fanout> as core::ops::drop::Drop>::drop>
  6fed44:	ba 08 00 00 00       	mov    $0x8,%edx
  6fed49:	48 8b bc 24 a0 02 00 	mov    0x2a0(%rsp),%rdi
  6fed50:	00 
  6fed51:	48 8b b4 24 f8 03 00 	mov    0x3f8(%rsp),%rsi
  6fed58:	00 
  6fed59:	ff 15 49 c9 38 00    	call   *0x38c949(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fed5f:	48 8b b4 24 58 02 00 	mov    0x258(%rsp),%rsi
  6fed66:	00 
  6fed67:	48 85 f6             	test   %rsi,%rsi
  6fed6a:	74 17                	je     6fed83 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d73>
  6fed6c:	48 8b bc 24 60 02 00 	mov    0x260(%rsp),%rdi
  6fed73:	00 
  6fed74:	48 c1 e6 02          	shl    $0x2,%rsi
  6fed78:	ba 04 00 00 00       	mov    $0x4,%edx
  6fed7d:	ff 15 25 c9 38 00    	call   *0x38c925(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fed83:	48 8b b4 24 40 02 00 	mov    0x240(%rsp),%rsi
  6fed8a:	00 
  6fed8b:	48 85 f6             	test   %rsi,%rsi
  6fed8e:	74 17                	je     6feda7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d97>
  6fed90:	48 8b bc 24 48 02 00 	mov    0x248(%rsp),%rdi
  6fed97:	00 
  6fed98:	48 c1 e6 03          	shl    $0x3,%rsi
  6fed9c:	ba 08 00 00 00       	mov    $0x8,%edx
  6feda1:	ff 15 01 c9 38 00    	call   *0x38c901(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6feda7:	48 8b b4 24 a8 02 00 	mov    0x2a8(%rsp),%rsi
  6fedae:	00 
  6fedaf:	48 85 f6             	test   %rsi,%rsi
  6fedb2:	74 17                	je     6fedcb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7dbb>
  6fedb4:	48 8b bc 24 b0 02 00 	mov    0x2b0(%rsp),%rdi
  6fedbb:	00 
  6fedbc:	48 c1 e6 03          	shl    $0x3,%rsi
  6fedc0:	ba 08 00 00 00       	mov    $0x8,%edx
  6fedc5:	ff 15 dd c8 38 00    	call   *0x38c8dd(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fedcb:	48 8d bc 24 b0 07 00 	lea    0x7b0(%rsp),%rdi
  6fedd2:	00 
  6fedd3:	e8 48 da 00 00       	call   70c820 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fedd8:	40 84 ed             	test   %bpl,%bpl
  6feddb:	74 0d                	je     6fedea <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7dda>
  6feddd:	48 8d bc 24 90 04 00 	lea    0x490(%rsp),%rdi
  6fede4:	00 
  6fede5:	e8 d6 52 fe ff       	call   6e40c0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui_canvas::image::Image>>>
  6fedea:	48 8d bc 24 68 08 00 	lea    0x868(%rsp),%rdi
  6fedf1:	00 
  6fedf2:	e8 a9 bc 00 00       	call   70aaa0 <<alloc::collections::btree::map::BTreeMap<gpui_reactivity_core::tree::NodeId, fn(cephal::tree::traits::MeasureInput) -> cephal::tree::traits::MeasureOutput> as core::ops::drop::Drop>::drop>
  6fedf7:	31 ed                	xor    %ebp,%ebp
  6fedf9:	48 8d bc 24 50 08 00 	lea    0x850(%rsp),%rdi
  6fee00:	00 
  6fee01:	e8 1a da 00 00       	call   70c820 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fee06:	45 84 f6             	test   %r14b,%r14b
  6fee09:	48 8b 9c 24 08 04 00 	mov    0x408(%rsp),%rbx
  6fee10:	00 
  6fee11:	74 0d                	je     6fee20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e10>
  6fee13:	48 8d bc 24 e0 05 00 	lea    0x5e0(%rsp),%rdi
  6fee1a:	00 
  6fee1b:	e8 f0 4e fe ff       	call   6e3d10 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::list::ListDraft>>>
  6fee20:	80 3c 24 00          	cmpb   $0x0,(%rsp)
  6fee24:	44 8b 74 24 10       	mov    0x10(%rsp),%r14d
  6fee29:	74 24                	je     6fee4f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e3f>
  6fee2b:	48 8b b4 24 38 05 00 	mov    0x538(%rsp),%rsi
  6fee32:	00 
  6fee33:	48 85 f6             	test   %rsi,%rsi
  6fee36:	74 17                	je     6fee4f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e3f>
  6fee38:	48 8b bc 24 40 05 00 	mov    0x540(%rsp),%rdi
  6fee3f:	00 
  6fee40:	48 c1 e6 04          	shl    $0x4,%rsi
  6fee44:	ba 08 00 00 00       	mov    $0x8,%edx
  6fee49:	ff 15 59 c8 38 00    	call   *0x38c859(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fee4f:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
  6fee56:	00 
  6fee57:	48 85 c9             	test   %rcx,%rcx
  6fee5a:	0f 95 c0             	setne  %al
  6fee5d:	41 84 c6             	test   %al,%r14b
  6fee60:	74 1b                	je     6fee7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e6d>
  6fee62:	48 c1 e1 03          	shl    $0x3,%rcx
  6fee66:	48 8d 34 49          	lea    (%rcx,%rcx,2),%rsi
  6fee6a:	ba 08 00 00 00       	mov    $0x8,%edx
  6fee6f:	48 8b bc 24 30 02 00 	mov    0x230(%rsp),%rdi
  6fee76:	00 
  6fee77:	ff 15 2b c8 38 00    	call   *0x38c82b(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6fee7d:	48 83 bc 24 48 01 00 	cmpq   $0x0,0x148(%rsp)
  6fee84:	00 00 
  6fee86:	74 26                	je     6feeae <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e9e>
  6fee88:	80 7c 24 20 00       	cmpb   $0x0,0x20(%rsp)
  6fee8d:	74 1f                	je     6feeae <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e9e>
  6fee8f:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
  6fee96:	00 
  6fee97:	48 c1 e6 04          	shl    $0x4,%rsi
  6fee9b:	ba 08 00 00 00       	mov    $0x8,%edx
  6feea0:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  6feea7:	00 
  6feea8:	ff 15 fa c7 38 00    	call   *0x38c7fa(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6feeae:	48 85 db             	test   %rbx,%rbx
  6feeb1:	0f 95 c0             	setne  %al
  6feeb4:	40 84 c5             	test   %al,%bpl
  6feeb7:	74 1b                	je     6feed4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ec4>
  6feeb9:	48 c1 e3 03          	shl    $0x3,%rbx
  6feebd:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
  6feec1:	ba 08 00 00 00       	mov    $0x8,%edx
  6feec6:	48 8b bc 24 18 05 00 	mov    0x518(%rsp),%rdi
  6feecd:	00 
  6feece:	ff 15 d4 c7 38 00    	call   *0x38c7d4(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6feed4:	45 84 e4             	test   %r12b,%r12b
  6feed7:	74 0d                	je     6feee6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ed6>
  6feed9:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  6feee0:	00 
  6feee1:	e8 2a 51 fe ff       	call   6e4010 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::semantic::AnnotationDraft>>>
  6feee6:	45 84 ff             	test   %r15b,%r15b
  6feee9:	74 0d                	je     6feef8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ee8>
  6feeeb:	48 8d bc 24 10 04 00 	lea    0x410(%rsp),%rdi
  6feef2:	00 
  6feef3:	e8 c8 4e fe ff       	call   6e3dc0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::element::DraftNode>>>
  6feef8:	48 8d bc 24 80 08 00 	lea    0x880(%rsp),%rdi
  6feeff:	00 
  6fef00:	e8 bb c6 00 00       	call   70b5c0 <<alloc::collections::btree::map::BTreeMap<gpui::list::ListId, alloc::collections::btree::set_val::SetValZST> as core::ops::drop::Drop>::drop>
  6fef05:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  6fef0a:	e8 c1 20 36 00       	call   a60fd0 <_Unwind_Resume@plt>
  6fef0f:	ff 15 cb c7 38 00    	call   *0x38c7cb(%rip)        # a8b6e0 <_DYNAMIC+0x288>
