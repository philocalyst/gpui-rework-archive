
/tmp/gpui-route-split-evidence/bin/split-cost:     file format elf64-x86-64


Disassembly of section .text:

0000000000733560 <<gpui::runtime::siblings::Siblings>::new>:
  733560:	55                   	push   %rbp
  733561:	41 57                	push   %r15
  733563:	41 56                	push   %r14
  733565:	41 55                	push   %r13
  733567:	41 54                	push   %r12
  733569:	53                   	push   %rbx
  73356a:	50                   	push   %rax
  73356b:	49 89 ff             	mov    %rdi,%r15
  73356e:	48 85 d2             	test   %rdx,%rdx
  733571:	0f 84 64 01 00 00    	je     7336db <<gpui::runtime::siblings::Siblings>::new+0x17b>
  733577:	49 89 d6             	mov    %rdx,%r14
  73357a:	49 89 f4             	mov    %rsi,%r12
  73357d:	48 8d 04 12          	lea    (%rdx,%rdx,1),%rax
  733581:	48 8d 2c 85 08 00 00 	lea    0x8(,%rax,4),%rbp
  733588:	00 
  733589:	ff 15 09 81 35 00    	call   *0x358109(%rip)        # a8b698 <_DYNAMIC+0x240>
  73358f:	be 04 00 00 00       	mov    $0x4,%esi
  733594:	48 89 ef             	mov    %rbp,%rdi
  733597:	ff 15 3b 85 35 00    	call   *0x35853b(%rip)        # a8bad8 <_DYNAMIC+0x680>
  73359d:	48 85 c0             	test   %rax,%rax
  7335a0:	0f 84 7e 01 00 00    	je     733724 <<gpui::runtime::siblings::Siblings>::new+0x1c4>
  7335a6:	4a 8d 0c 75 02 00 00 	lea    0x2(,%r14,2),%rcx
  7335ad:	00 
  7335ae:	49 8d 76 02          	lea    0x2(%r14),%rsi
  7335b2:	4e 8d 04 b0          	lea    (%rax,%r14,4),%r8
  7335b6:	49 83 c0 08          	add    $0x8,%r8
  7335ba:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
  7335c1:	00 
  7335c2:	4c 8d 0c 52          	lea    (%rdx,%rdx,2),%r9
  7335c6:	45 31 d2             	xor    %r10d,%r10d
  7335c9:	41 bb ff ff ff ff    	mov    $0xffffffff,%r11d
  7335cf:	41 bd 01 00 00 00    	mov    $0x1,%r13d
  7335d5:	48 8d 15 e4 17 33 00 	lea    0x3317e4(%rip),%rdx        # a64dc0 <anon.b9946fe4defe8b854d134b4bf5265d75.26.llvm.10307981152027530048+0xe8>
  7335dc:	48 89 2c 24          	mov    %rbp,(%rsp)
  7335e0:	43 8b 5c 14 08       	mov    0x8(%r12,%r10,1),%ebx
  7335e5:	48 8d 7b 02          	lea    0x2(%rbx),%rdi
  7335e9:	4c 39 db             	cmp    %r11,%rbx
  7335ec:	48 89 fb             	mov    %rdi,%rbx
  7335ef:	49 0f 44 dd          	cmove  %r13,%rbx
  7335f3:	48 39 f3             	cmp    %rsi,%rbx
  7335f6:	0f 83 03 01 00 00    	jae    7336ff <<gpui::runtime::siblings::Siblings>::new+0x19f>
  7335fc:	ff 04 98             	incl   (%rax,%rbx,4)
  7335ff:	49 83 c2 18          	add    $0x18,%r10
  733603:	4d 39 d1             	cmp    %r10,%r9
  733606:	75 d8                	jne    7335e0 <<gpui::runtime::siblings::Siblings>::new+0x80>
  733608:	8b 10                	mov    (%rax),%edx
  73360a:	4d 8d 5e 01          	lea    0x1(%r14),%r11
  73360e:	44 89 df             	mov    %r11d,%edi
  733611:	83 e7 03             	and    $0x3,%edi
  733614:	41 ba 01 00 00 00    	mov    $0x1,%r10d
  73361a:	49 83 fe 03          	cmp    $0x3,%r14
  73361e:	72 49                	jb     733669 <<gpui::runtime::siblings::Siblings>::new+0x109>
  733620:	49 ba fc ff ff ff ff 	movabs $0xffffffffffffffc,%r10
  733627:	ff ff 0f 
  73362a:	4d 21 d3             	and    %r10,%r11
  73362d:	45 31 d2             	xor    %r10d,%r10d
  733630:	42 03 54 90 04       	add    0x4(%rax,%r10,4),%edx
  733635:	42 89 54 90 04       	mov    %edx,0x4(%rax,%r10,4)
  73363a:	42 03 54 90 08       	add    0x8(%rax,%r10,4),%edx
  73363f:	42 89 54 90 08       	mov    %edx,0x8(%rax,%r10,4)
  733644:	42 03 54 90 0c       	add    0xc(%rax,%r10,4),%edx
  733649:	42 89 54 90 0c       	mov    %edx,0xc(%rax,%r10,4)
  73364e:	42 03 54 90 10       	add    0x10(%rax,%r10,4),%edx
  733653:	42 89 54 90 10       	mov    %edx,0x10(%rax,%r10,4)
  733658:	49 83 c2 04          	add    $0x4,%r10
  73365c:	4d 39 d3             	cmp    %r10,%r11
  73365f:	75 cf                	jne    733630 <<gpui::runtime::siblings::Siblings>::new+0xd0>
  733661:	48 85 ff             	test   %rdi,%rdi
  733664:	74 1a                	je     733680 <<gpui::runtime::siblings::Siblings>::new+0x120>
  733666:	49 ff c2             	inc    %r10
  733669:	4e 8d 14 90          	lea    (%rax,%r10,4),%r10
  73366d:	45 31 db             	xor    %r11d,%r11d
  733670:	43 03 14 9a          	add    (%r10,%r11,4),%edx
  733674:	43 89 14 9a          	mov    %edx,(%r10,%r11,4)
  733678:	49 ff c3             	inc    %r11
  73367b:	4c 39 df             	cmp    %r11,%rdi
  73367e:	75 f0                	jne    733670 <<gpui::runtime::siblings::Siblings>::new+0x110>
  733680:	45 31 db             	xor    %r11d,%r11d
  733683:	41 bd ff ff ff ff    	mov    $0xffffffff,%r13d
  733689:	bd ff ff 01 00       	mov    $0x1ffff,%ebp
  73368e:	48 8d 15 5b 17 33 00 	lea    0x33175b(%rip),%rdx        # a64df0 <anon.b9946fe4defe8b854d134b4bf5265d75.26.llvm.10307981152027530048+0x118>
  733695:	45 31 d2             	xor    %r10d,%r10d
  733698:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  73369f:	00 
  7336a0:	43 8b 5c 14 08       	mov    0x8(%r12,%r10,1),%ebx
  7336a5:	48 8d 7b 01          	lea    0x1(%rbx),%rdi
  7336a9:	4c 39 eb             	cmp    %r13,%rbx
  7336ac:	bb 00 00 00 00       	mov    $0x0,%ebx
  7336b1:	48 0f 45 df          	cmovne %rdi,%rbx
  7336b5:	48 39 f3             	cmp    %rsi,%rbx
  7336b8:	73 52                	jae    73370c <<gpui::runtime::siblings::Siblings>::new+0x1ac>
  7336ba:	43 8b 7c 14 0c       	mov    0xc(%r12,%r10,1),%edi
  7336bf:	21 ef                	and    %ebp,%edi
  7336c1:	03 3c 98             	add    (%rax,%rbx,4),%edi
  7336c4:	49 39 fe             	cmp    %rdi,%r14
  7336c7:	76 3e                	jbe    733707 <<gpui::runtime::siblings::Siblings>::new+0x1a7>
  7336c9:	45 89 1c b8          	mov    %r11d,(%r8,%rdi,4)
  7336cd:	49 83 c2 18          	add    $0x18,%r10
  7336d1:	41 ff c3             	inc    %r11d
  7336d4:	4d 39 d1             	cmp    %r10,%r9
  7336d7:	75 c7                	jne    7336a0 <<gpui::runtime::siblings::Siblings>::new+0x140>
  7336d9:	eb 07                	jmp    7336e2 <<gpui::runtime::siblings::Siblings>::new+0x182>
  7336db:	b8 04 00 00 00       	mov    $0x4,%eax
  7336e0:	31 c9                	xor    %ecx,%ecx
  7336e2:	49 89 0f             	mov    %rcx,(%r15)
  7336e5:	49 89 47 08          	mov    %rax,0x8(%r15)
  7336e9:	49 89 4f 10          	mov    %rcx,0x10(%r15)
  7336ed:	4c 89 f8             	mov    %r15,%rax
  7336f0:	48 83 c4 08          	add    $0x8,%rsp
  7336f4:	5b                   	pop    %rbx
  7336f5:	41 5c                	pop    %r12
  7336f7:	41 5d                	pop    %r13
  7336f9:	41 5e                	pop    %r14
  7336fb:	41 5f                	pop    %r15
  7336fd:	5d                   	pop    %rbp
  7336fe:	c3                   	ret
  7336ff:	49 89 c7             	mov    %rax,%r15
  733702:	49 89 f6             	mov    %rsi,%r14
  733705:	eb 12                	jmp    733719 <<gpui::runtime::siblings::Siblings>::new+0x1b9>
  733707:	49 89 c7             	mov    %rax,%r15
  73370a:	eb 0d                	jmp    733719 <<gpui::runtime::siblings::Siblings>::new+0x1b9>
  73370c:	49 89 c7             	mov    %rax,%r15
  73370f:	49 89 f6             	mov    %rsi,%r14
  733712:	48 8d 15 bf 16 33 00 	lea    0x3316bf(%rip),%rdx        # a64dd8 <anon.b9946fe4defe8b854d134b4bf5265d75.26.llvm.10307981152027530048+0x100>
  733719:	4c 89 f6             	mov    %r14,%rsi
  73371c:	ff 15 9e 80 35 00    	call   *0x35809e(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  733722:	0f 0b                	ud2
  733724:	bf 04 00 00 00       	mov    $0x4,%edi
  733729:	48 89 ee             	mov    %rbp,%rsi
  73372c:	ff 15 3e 80 35 00    	call   *0x35803e(%rip)        # a8b770 <_DYNAMIC+0x318>
  733732:	49 89 c6             	mov    %rax,%r14
  733735:	ba 04 00 00 00       	mov    $0x4,%edx
  73373a:	4c 89 ff             	mov    %r15,%rdi
  73373d:	48 8b 34 24          	mov    (%rsp),%rsi
  733741:	ff 15 61 7f 35 00    	call   *0x357f61(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  733747:	4c 89 f7             	mov    %r14,%rdi
  73374a:	e8 81 d8 32 00       	call   a60fd0 <_Unwind_Resume@plt>
