
/tmp/gpui-route-split-evidence/bin/split-cost:     file format elf64-x86-64


Disassembly of section .text:

00000000006f1440 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner>:
  6f1440:	55                   	push   %rbp
  6f1441:	41 57                	push   %r15
  6f1443:	41 56                	push   %r14
  6f1445:	41 55                	push   %r13
  6f1447:	41 54                	push   %r12
  6f1449:	53                   	push   %rbx
  6f144a:	48 81 ec c8 0d 00 00 	sub    $0xdc8,%rsp
  6f1451:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
  6f1456:	4c 8b a6 c8 05 00 00 	mov    0x5c8(%rsi),%r12
  6f145d:	4c 89 e0             	mov    %r12,%rax
  6f1460:	48 ff c0             	inc    %rax
  6f1463:	0f 84 32 4a 00 00    	je     6f5e9b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4a5b>
  6f1469:	49 89 f5             	mov    %rsi,%r13
  6f146c:	48 89 84 24 b8 07 00 	mov    %rax,0x7b8(%rsp)
  6f1473:	00 
  6f1474:	48 8b 86 c0 05 00 00 	mov    0x5c0(%rsi),%rax
  6f147b:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
  6f1482:	00 
  6f1483:	48 8b b6 a8 06 00 00 	mov    0x6a8(%rsi),%rsi
  6f148a:	66 48 0f 6e c6       	movq   %rsi,%xmm0
  6f148f:	66 0f 7f 44 24 60    	movdqa %xmm0,0x60(%rsp)
  6f1495:	66 0f 70 c0 55       	pshufd $0x55,%xmm0,%xmm0
  6f149a:	66 41 0f 7e c7       	movd   %xmm0,%r15d
  6f149f:	f3 41 0f 10 85 40 07 	movss  0x740(%r13),%xmm0
  6f14a6:	00 00 
  6f14a8:	f3 0f 11 84 24 9c 00 	movss  %xmm0,0x9c(%rsp)
  6f14af:	00 00 
  6f14b1:	41 8b 85 a8 01 00 00 	mov    0x1a8(%r13),%eax
  6f14b8:	49 8b 8d b0 01 00 00 	mov    0x1b0(%r13),%rcx
  6f14bf:	48 c1 e1 20          	shl    $0x20,%rcx
  6f14c3:	48 09 c1             	or     %rax,%rcx
  6f14c6:	48 39 f1             	cmp    %rsi,%rcx
  6f14c9:	48 89 b4 24 00 03 00 	mov    %rsi,0x300(%rsp)
  6f14d0:	00 
  6f14d1:	75 27                	jne    6f14fa <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xba>
  6f14d3:	48 c7 84 24 e0 0b 00 	movq   $0x2,0xbe0(%rsp)
  6f14da:	00 02 00 00 00 
  6f14df:	bb 02 00 00 00       	mov    $0x2,%ebx
  6f14e4:	81 bc 24 00 03 00 00 	cmpl   $0xffff,0x300(%rsp)
  6f14eb:	ff ff 00 00 
  6f14ef:	0f 86 a2 00 00 00    	jbe    6f1597 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x157>
  6f14f5:	e9 a6 00 00 00       	jmp    6f15a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x160>
  6f14fa:	41 0f 10 85 38 01 00 	movups 0x138(%r13),%xmm0
  6f1501:	00 
  6f1502:	0f 29 84 24 30 09 00 	movaps %xmm0,0x930(%rsp)
  6f1509:	00 
  6f150a:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f1511:	00 
  6f1512:	48 8d 8c 24 30 09 00 	lea    0x930(%rsp),%rcx
  6f1519:	00 
  6f151a:	44 89 fa             	mov    %r15d,%edx
  6f151d:	ff 15 25 a4 39 00    	call   *0x39a425(%rip)        # a8b948 <_DYNAMIC+0x4f0>
  6f1523:	48 8b 9c 24 70 04 00 	mov    0x470(%rsp),%rbx
  6f152a:	00 
  6f152b:	44 8b b4 24 78 04 00 	mov    0x478(%rsp),%r14d
  6f1532:	00 
  6f1533:	8b ac 24 7c 04 00 00 	mov    0x47c(%rsp),%ebp
  6f153a:	48 83 fb 02          	cmp    $0x2,%rbx
  6f153e:	75 18                	jne    6f1558 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x118>
  6f1540:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6f1545:	48 c7 00 23 00 00 00 	movq   $0x23,(%rax)
  6f154c:	44 89 70 08          	mov    %r14d,0x8(%rax)
  6f1550:	89 68 0c             	mov    %ebp,0xc(%rax)
  6f1553:	e9 6b 1a 00 00       	jmp    6f2fc3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b83>
  6f1558:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
  6f155f:	00 
  6f1560:	48 8d bc 24 f0 0b 00 	lea    0xbf0(%rsp),%rdi
  6f1567:	00 
  6f1568:	ba d8 01 00 00       	mov    $0x1d8,%edx
  6f156d:	ff 15 45 a1 39 00    	call   *0x39a145(%rip)        # a8b6b8 <memcpy@GLIBC_2.14>
  6f1573:	48 89 9c 24 e0 0b 00 	mov    %rbx,0xbe0(%rsp)
  6f157a:	00 
  6f157b:	44 89 b4 24 e8 0b 00 	mov    %r14d,0xbe8(%rsp)
  6f1582:	00 
  6f1583:	89 ac 24 ec 0b 00 00 	mov    %ebp,0xbec(%rsp)
  6f158a:	81 bc 24 00 03 00 00 	cmpl   $0xffff,0x300(%rsp)
  6f1591:	ff ff 00 00 
  6f1595:	77 09                	ja     6f15a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x160>
  6f1597:	41 81 ff ff ff 00 00 	cmp    $0xffff,%r15d
  6f159e:	76 21                	jbe    6f15c1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x181>
  6f15a0:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6f15a5:	48 c7 00 23 00 00 00 	movq   $0x23,(%rax)
  6f15ac:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%rax)
  6f15b3:	83 fb 02             	cmp    $0x2,%ebx
  6f15b6:	0f 85 fa 19 00 00    	jne    6f2fb6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b76>
  6f15bc:	e9 02 1a 00 00       	jmp    6f2fc3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b83>
  6f15c1:	49 83 bd b8 02 00 00 	cmpq   $0x0,0x2b8(%r13)
  6f15c8:	00 
  6f15c9:	74 13                	je     6f15de <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x19e>
  6f15cb:	49 8b 85 c8 06 00 00 	mov    0x6c8(%r13),%rax
  6f15d2:	48 85 c0             	test   %rax,%rax
  6f15d5:	74 1c                	je     6f15f3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b3>
  6f15d7:	48 83 78 30 00       	cmpq   $0x0,0x30(%rax)
  6f15dc:	74 62                	je     6f1640 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x200>
  6f15de:	49 8b 85 c8 06 00 00 	mov    0x6c8(%r13),%rax
  6f15e5:	48 85 c0             	test   %rax,%rax
  6f15e8:	0f 85 27 01 00 00    	jne    6f1715 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2d5>
  6f15ee:	e9 90 01 00 00       	jmp    6f1783 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x343>
  6f15f3:	ff 15 9f a0 39 00    	call   *0x39a09f(%rip)        # a8b698 <_DYNAMIC+0x240>
  6f15f9:	bf 78 00 00 00       	mov    $0x78,%edi
  6f15fe:	be 08 00 00 00       	mov    $0x8,%esi
  6f1603:	ff 15 97 a0 39 00    	call   *0x39a097(%rip)        # a8b6a0 <_DYNAMIC+0x248>
  6f1609:	48 85 c0             	test   %rax,%rax
  6f160c:	0f 84 d6 4c 00 00    	je     6f62e8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4ea8>
  6f1612:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  6f1619:	48 c7 40 08 08 00 00 	movq   $0x8,0x8(%rax)
  6f1620:	00 
  6f1621:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
  6f1628:	00 
  6f1629:	48 c7 40 18 ff ff ff 	movq   $0xffffffffffffffff,0x18(%rax)
  6f1630:	ff 
  6f1631:	48 c7 40 30 00 00 00 	movq   $0x0,0x30(%rax)
  6f1638:	00 
  6f1639:	49 89 85 c8 06 00 00 	mov    %rax,0x6c8(%r13)
  6f1640:	44 89 fb             	mov    %r15d,%ebx
  6f1643:	40 b5 01             	mov    $0x1,%bpl
  6f1646:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f164d:	00 
  6f164e:	ff 15 54 a3 39 00    	call   *0x39a354(%rip)        # a8b9a8 <_DYNAMIC+0x550>
  6f1654:	4c 8b bc 24 70 04 00 	mov    0x470(%rsp),%r15
  6f165b:	00 
  6f165c:	44 8b b4 24 78 04 00 	mov    0x478(%rsp),%r14d
  6f1663:	00 
  6f1664:	8b ac 24 7c 04 00 00 	mov    0x47c(%rsp),%ebp
  6f166b:	4d 85 ff             	test   %r15,%r15
  6f166e:	0f 84 fd 17 00 00    	je     6f2e71 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1a31>
  6f1674:	48 8b 84 24 b0 04 00 	mov    0x4b0(%rsp),%rax
  6f167b:	00 
  6f167c:	48 89 84 24 60 09 00 	mov    %rax,0x960(%rsp)
  6f1683:	00 
  6f1684:	0f 10 84 24 80 04 00 	movups 0x480(%rsp),%xmm0
  6f168b:	00 
  6f168c:	0f 10 8c 24 90 04 00 	movups 0x490(%rsp),%xmm1
  6f1693:	00 
  6f1694:	0f 10 94 24 a0 04 00 	movups 0x4a0(%rsp),%xmm2
  6f169b:	00 
  6f169c:	0f 29 94 24 50 09 00 	movaps %xmm2,0x950(%rsp)
  6f16a3:	00 
  6f16a4:	0f 29 8c 24 40 09 00 	movaps %xmm1,0x940(%rsp)
  6f16ab:	00 
  6f16ac:	0f 29 84 24 30 09 00 	movaps %xmm0,0x930(%rsp)
  6f16b3:	00 
  6f16b4:	49 8b bd c8 06 00 00 	mov    0x6c8(%r13),%rdi
  6f16bb:	48 83 c7 30          	add    $0x30,%rdi
  6f16bf:	e8 9c 14 ff ff       	call   6e2b60 <core::ptr::drop_glue::<core::option::Option<gpui_canvas::text::TextSystem>>>
  6f16c4:	49 8b 85 c8 06 00 00 	mov    0x6c8(%r13),%rax
  6f16cb:	4c 89 78 30          	mov    %r15,0x30(%rax)
  6f16cf:	44 89 70 38          	mov    %r14d,0x38(%rax)
  6f16d3:	89 68 3c             	mov    %ebp,0x3c(%rax)
  6f16d6:	0f 28 84 24 30 09 00 	movaps 0x930(%rsp),%xmm0
  6f16dd:	00 
  6f16de:	0f 28 8c 24 40 09 00 	movaps 0x940(%rsp),%xmm1
  6f16e5:	00 
  6f16e6:	0f 28 94 24 50 09 00 	movaps 0x950(%rsp),%xmm2
  6f16ed:	00 
  6f16ee:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  6f16f2:	0f 11 48 50          	movups %xmm1,0x50(%rax)
  6f16f6:	0f 11 50 60          	movups %xmm2,0x60(%rax)
  6f16fa:	48 8b 8c 24 60 09 00 	mov    0x960(%rsp),%rcx
  6f1701:	00 
  6f1702:	48 89 48 70          	mov    %rcx,0x70(%rax)
  6f1706:	41 89 df             	mov    %ebx,%r15d
  6f1709:	49 8b 85 c8 06 00 00 	mov    0x6c8(%r13),%rax
  6f1710:	48 85 c0             	test   %rax,%rax
  6f1713:	74 6e                	je     6f1783 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x343>
  6f1715:	48 8b 40 30          	mov    0x30(%rax),%rax
  6f1719:	48 85 c0             	test   %rax,%rax
  6f171c:	74 65                	je     6f1783 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x343>
  6f171e:	f0 48 ff 00          	lock incq (%rax)
  6f1722:	0f 8e 0f 4f 00 00    	jle    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f1728:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  6f172f:	00 
  6f1730:	48 c7 84 24 e0 01 00 	movq   $0x0,0x1e0(%rsp)
  6f1737:	00 00 00 00 00 
  6f173c:	48 c7 84 24 e8 01 00 	movq   $0x8,0x1e8(%rsp)
  6f1743:	00 08 00 00 00 
  6f1748:	48 c7 84 24 f0 01 00 	movq   $0x0,0x1f0(%rsp)
  6f174f:	00 00 00 00 00 
  6f1754:	48 8d 84 24 30 01 00 	lea    0x130(%rsp),%rax
  6f175b:	00 
  6f175c:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
  6f1763:	00 
  6f1764:	48 c7 84 24 b0 01 00 	movq   $0x0,0x1b0(%rsp)
  6f176b:	00 00 00 00 00 
  6f1770:	49 8b 85 40 06 00 00 	mov    0x640(%r13),%rax
  6f1777:	c6 44 24 57 02       	movb   $0x2,0x57(%rsp)
  6f177c:	48 85 c0             	test   %rax,%rax
  6f177f:	75 4f                	jne    6f17d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x390>
  6f1781:	eb 63                	jmp    6f17e6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3a6>
  6f1783:	48 c7 84 24 30 01 00 	movq   $0x0,0x130(%rsp)
  6f178a:	00 00 00 00 00 
  6f178f:	48 c7 84 24 e0 01 00 	movq   $0x0,0x1e0(%rsp)
  6f1796:	00 00 00 00 00 
  6f179b:	48 c7 84 24 e8 01 00 	movq   $0x8,0x1e8(%rsp)
  6f17a2:	00 08 00 00 00 
  6f17a7:	48 c7 84 24 f0 01 00 	movq   $0x0,0x1f0(%rsp)
  6f17ae:	00 00 00 00 00 
  6f17b3:	48 c7 84 24 a8 01 00 	movq   $0x0,0x1a8(%rsp)
  6f17ba:	00 00 00 00 00 
  6f17bf:	49 8b 85 40 06 00 00 	mov    0x640(%r13),%rax
  6f17c6:	c6 44 24 57 02       	movb   $0x2,0x57(%rsp)
  6f17cb:	48 85 c0             	test   %rax,%rax
  6f17ce:	74 16                	je     6f17e6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3a6>
  6f17d0:	48 8b 80 e0 00 00 00 	mov    0xe0(%rax),%rax
  6f17d7:	48 85 c0             	test   %rax,%rax
  6f17da:	74 0a                	je     6f17e6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3a6>
  6f17dc:	80 78 24 02          	cmpb   $0x2,0x24(%rax)
  6f17e0:	0f 85 ac 10 00 00    	jne    6f2892 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1452>
  6f17e6:	c6 44 24 70 02       	movb   $0x2,0x70(%rsp)
  6f17eb:	49 8d 85 40 06 00 00 	lea    0x640(%r13),%rax
  6f17f2:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  6f17f9:	00 
  6f17fa:	48 8b 00             	mov    (%rax),%rax
  6f17fd:	48 85 c0             	test   %rax,%rax
  6f1800:	74 16                	je     6f1818 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3d8>
  6f1802:	48 8b 80 e0 00 00 00 	mov    0xe0(%rax),%rax
  6f1809:	48 85 c0             	test   %rax,%rax
  6f180c:	74 0a                	je     6f1818 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3d8>
  6f180e:	80 78 24 02          	cmpb   $0x2,0x24(%rax)
  6f1812:	0f 85 16 11 00 00    	jne    6f292e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x14ee>
  6f1818:	49 8d 85 c0 02 00 00 	lea    0x2c0(%r13),%rax
  6f181f:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  6f1824:	41 80 bd 48 07 00 00 	cmpb   $0x0,0x748(%r13)
  6f182b:	00 
  6f182c:	4c 89 6c 24 40       	mov    %r13,0x40(%rsp)
  6f1831:	4c 89 a4 24 98 02 00 	mov    %r12,0x298(%rsp)
  6f1838:	00 
  6f1839:	44 89 bc 24 dc 01 00 	mov    %r15d,0x1dc(%rsp)
  6f1840:	00 
  6f1841:	0f 85 8d 04 00 00    	jne    6f1cd4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x894>
  6f1847:	41 80 bd 49 07 00 00 	cmpb   $0x0,0x749(%r13)
  6f184e:	00 
  6f184f:	0f 85 7f 04 00 00    	jne    6f1cd4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x894>
  6f1855:	41 80 bd 50 05 00 00 	cmpb   $0x0,0x550(%r13)
  6f185c:	00 
  6f185d:	0f 85 71 04 00 00    	jne    6f1cd4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x894>
  6f1863:	49 8b 85 48 06 00 00 	mov    0x648(%r13),%rax
  6f186a:	4d 8b a5 58 06 00 00 	mov    0x658(%r13),%r12
  6f1871:	48 85 c0             	test   %rax,%rax
  6f1874:	0f 95 c1             	setne  %cl
  6f1877:	4d 85 e4             	test   %r12,%r12
  6f187a:	0f 95 c2             	setne  %dl
  6f187d:	20 ca                	and    %cl,%dl
  6f187f:	80 fa 01             	cmp    $0x1,%dl
  6f1882:	0f 85 03 09 00 00    	jne    6f218b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xd4b>
  6f1888:	4d 8d b5 78 06 00 00 	lea    0x678(%r13),%r14
  6f188f:	4d 8b bd 50 06 00 00 	mov    0x650(%r13),%r15
  6f1896:	31 ed                	xor    %ebp,%ebp
  6f1898:	48 8d 0d 49 15 37 00 	lea    0x371549(%rip),%rcx        # a62de8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x9e8>
  6f189f:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
  6f18a6:	00 
  6f18a7:	48 8d 0d 73 91 96 ff 	lea    -0x696e8d(%rip),%rcx        # 5aa21 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2d79>
  6f18ae:	48 89 8c 24 a0 02 00 	mov    %rcx,0x2a0(%rsp)
  6f18b5:	00 
  6f18b6:	48 8d 0d 33 16 37 00 	lea    0x371633(%rip),%rcx        # a62ef0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xaf0>
  6f18bd:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  6f18c2:	eb 2a                	jmp    6f18ee <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4ae>
  6f18c4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f18cb:	00 00 00 00 00 
  6f18d0:	4c 89 f7             	mov    %r14,%rdi
  6f18d3:	48 89 c6             	mov    %rax,%rsi
  6f18d6:	e8 85 7c 01 00       	call   709560 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6f18db:	b8 00 00 00 00       	mov    $0x0,%eax
  6f18e0:	49 ff cc             	dec    %r12
  6f18e3:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
  6f18e8:	0f 84 9d 08 00 00    	je     6f218b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xd4b>
  6f18ee:	48 85 ed             	test   %rbp,%rbp
  6f18f1:	74 1d                	je     6f1910 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4d0>
  6f18f3:	0f b7 8d 8a 05 00 00 	movzwl 0x58a(%rbp),%ecx
  6f18fa:	49 39 cf             	cmp    %rcx,%r15
  6f18fd:	0f 83 bd 00 00 00    	jae    6f19c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x580>
  6f1903:	48 89 e9             	mov    %rbp,%rcx
  6f1906:	4c 89 fa             	mov    %r15,%rdx
  6f1909:	e9 d8 00 00 00       	jmp    6f19e6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5a6>
  6f190e:	66 90                	xchg   %ax,%ax
  6f1910:	4d 85 ff             	test   %r15,%r15
  6f1913:	74 38                	je     6f194d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x50d>
  6f1915:	4c 89 f9             	mov    %r15,%rcx
  6f1918:	48 89 c5             	mov    %rax,%rbp
  6f191b:	48 83 e1 07          	and    $0x7,%rcx
  6f191f:	74 31                	je     6f1952 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x512>
  6f1921:	31 d2                	xor    %edx,%edx
  6f1923:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f192a:	84 00 00 00 00 00 
  6f1930:	48 8b ad 90 05 00 00 	mov    0x590(%rbp),%rbp
  6f1937:	48 ff c2             	inc    %rdx
  6f193a:	48 39 d1             	cmp    %rdx,%rcx
  6f193d:	75 f1                	jne    6f1930 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4f0>
  6f193f:	4c 89 f8             	mov    %r15,%rax
  6f1942:	48 29 d0             	sub    %rdx,%rax
  6f1945:	49 83 ff 08          	cmp    $0x8,%r15
  6f1949:	73 15                	jae    6f1960 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x520>
  6f194b:	eb 51                	jmp    6f199e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x55e>
  6f194d:	48 89 c5             	mov    %rax,%rbp
  6f1950:	eb 4c                	jmp    6f199e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x55e>
  6f1952:	4c 89 f8             	mov    %r15,%rax
  6f1955:	49 83 ff 08          	cmp    $0x8,%r15
  6f1959:	72 43                	jb     6f199e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x55e>
  6f195b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6f1960:	48 8b 8d 90 05 00 00 	mov    0x590(%rbp),%rcx
  6f1967:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  6f196e:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  6f1975:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  6f197c:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  6f1983:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  6f198a:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  6f1991:	48 8b a9 90 05 00 00 	mov    0x590(%rcx),%rbp
  6f1998:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  6f199c:	75 c2                	jne    6f1960 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x520>
  6f199e:	31 c0                	xor    %eax,%eax
  6f19a0:	45 31 ff             	xor    %r15d,%r15d
  6f19a3:	0f b7 8d 8a 05 00 00 	movzwl 0x58a(%rbp),%ecx
  6f19aa:	49 39 cf             	cmp    %rcx,%r15
  6f19ad:	0f 82 50 ff ff ff    	jb     6f1903 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4c3>
  6f19b3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f19ba:	84 00 00 00 00 00 
  6f19c0:	48 8b 8d 80 05 00 00 	mov    0x580(%rbp),%rcx
  6f19c7:	48 85 c9             	test   %rcx,%rcx
  6f19ca:	0f 84 30 49 00 00    	je     6f6300 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4ec0>
  6f19d0:	48 ff c0             	inc    %rax
  6f19d3:	0f b7 95 88 05 00 00 	movzwl 0x588(%rbp),%edx
  6f19da:	48 89 cd             	mov    %rcx,%rbp
  6f19dd:	66 3b 91 8a 05 00 00 	cmp    0x58a(%rcx),%dx
  6f19e4:	73 da                	jae    6f19c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x580>
  6f19e6:	48 85 c0             	test   %rax,%rax
  6f19e9:	0f 84 91 00 00 00    	je     6f1a80 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x640>
  6f19ef:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
  6f19f3:	48 81 c6 98 05 00 00 	add    $0x598,%rsi
  6f19fa:	48 89 c7             	mov    %rax,%rdi
  6f19fd:	48 83 e7 07          	and    $0x7,%rdi
  6f1a01:	0f 84 b9 01 00 00    	je     6f1bc0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x780>
  6f1a07:	45 31 c0             	xor    %r8d,%r8d
  6f1a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  6f1a10:	48 8b 2e             	mov    (%rsi),%rbp
  6f1a13:	48 8d b5 90 05 00 00 	lea    0x590(%rbp),%rsi
  6f1a1a:	49 ff c0             	inc    %r8
  6f1a1d:	4c 39 c7             	cmp    %r8,%rdi
  6f1a20:	75 ee                	jne    6f1a10 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5d0>
  6f1a22:	48 89 c7             	mov    %rax,%rdi
  6f1a25:	4c 29 c7             	sub    %r8,%rdi
  6f1a28:	48 83 f8 08          	cmp    $0x8,%rax
  6f1a2c:	72 43                	jb     6f1a71 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x631>
  6f1a2e:	66 90                	xchg   %ax,%ax
  6f1a30:	48 8b 06             	mov    (%rsi),%rax
  6f1a33:	48 8b 80 90 05 00 00 	mov    0x590(%rax),%rax
  6f1a3a:	48 8b 80 90 05 00 00 	mov    0x590(%rax),%rax
  6f1a41:	48 8b 80 90 05 00 00 	mov    0x590(%rax),%rax
  6f1a48:	48 8b 80 90 05 00 00 	mov    0x590(%rax),%rax
  6f1a4f:	48 8b 80 90 05 00 00 	mov    0x590(%rax),%rax
  6f1a56:	48 8b 80 90 05 00 00 	mov    0x590(%rax),%rax
  6f1a5d:	48 8b a8 90 05 00 00 	mov    0x590(%rax),%rbp
  6f1a64:	48 8d b5 90 05 00 00 	lea    0x590(%rbp),%rsi
  6f1a6b:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  6f1a6f:	75 bf                	jne    6f1a30 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5f0>
  6f1a71:	45 31 ff             	xor    %r15d,%r15d
  6f1a74:	eb 11                	jmp    6f1a87 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x647>
  6f1a76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6f1a7d:	00 00 00 
  6f1a80:	4c 8d 7a 01          	lea    0x1(%rdx),%r15
  6f1a84:	48 89 cd             	mov    %rcx,%rbp
  6f1a87:	48 6b c2 70          	imul   $0x70,%rdx,%rax
  6f1a8b:	48 c1 e2 04          	shl    $0x4,%rdx
  6f1a8f:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
  6f1a93:	48 81 c7 b0 00 00 00 	add    $0xb0,%rdi
  6f1a9a:	48 8b 34 11          	mov    (%rcx,%rdx,1),%rsi
  6f1a9e:	48 8b 54 11 08       	mov    0x8(%rcx,%rdx,1),%rdx
  6f1aa3:	ff 15 07 9f 39 00    	call   *0x399f07(%rip)        # a8b9b0 <_DYNAMIC+0x558>
  6f1aa9:	4c 8b 5c 24 40       	mov    0x40(%rsp),%r11
  6f1aae:	49 8b 8b e8 01 00 00 	mov    0x1e8(%r11),%rcx
  6f1ab5:	48 83 f9 02          	cmp    $0x2,%rcx
  6f1ab9:	74 65                	je     6f1b20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x6e0>
  6f1abb:	83 f9 01             	cmp    $0x1,%ecx
  6f1abe:	0f 85 cc 00 00 00    	jne    6f1b90 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x750>
  6f1ac4:	49 8b 8b f0 01 00 00 	mov    0x1f0(%r11),%rcx
  6f1acb:	49 8b 93 f8 01 00 00 	mov    0x1f8(%r11),%rdx
  6f1ad2:	be 15 00 00 00       	mov    $0x15,%esi
  6f1ad7:	48 83 fa 01          	cmp    $0x1,%rdx
  6f1adb:	0f 84 f1 00 00 00    	je     6f1bd2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x792>
  6f1ae1:	48 85 d2             	test   %rdx,%rdx
  6f1ae4:	0f 84 71 49 00 00    	je     6f645b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x501b>
  6f1aea:	31 ff                	xor    %edi,%edi
  6f1aec:	0f 1f 40 00          	nopl   0x0(%rax)
  6f1af0:	49 89 f8             	mov    %rdi,%r8
  6f1af3:	49 89 d1             	mov    %rdx,%r9
  6f1af6:	49 d1 e9             	shr    $1,%r9
  6f1af9:	4c 01 cf             	add    %r9,%rdi
  6f1afc:	49 89 fa             	mov    %rdi,%r10
  6f1aff:	49 c1 e2 04          	shl    $0x4,%r10
  6f1b03:	4a 39 04 11          	cmp    %rax,(%rcx,%r10,1)
  6f1b07:	49 0f 47 f8          	cmova  %r8,%rdi
  6f1b0b:	4c 29 ca             	sub    %r9,%rdx
  6f1b0e:	48 83 fa 01          	cmp    $0x1,%rdx
  6f1b12:	77 dc                	ja     6f1af0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x6b0>
  6f1b14:	e9 bb 00 00 00       	jmp    6f1bd4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x794>
  6f1b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6f1b20:	49 8b 8b f0 01 00 00 	mov    0x1f0(%r11),%rcx
  6f1b27:	49 8b 93 f8 01 00 00 	mov    0x1f8(%r11),%rdx
  6f1b2e:	be 15 00 00 00       	mov    $0x15,%esi
  6f1b33:	48 83 fa 01          	cmp    $0x1,%rdx
  6f1b37:	0f 84 d4 00 00 00    	je     6f1c11 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x7d1>
  6f1b3d:	48 85 d2             	test   %rdx,%rdx
  6f1b40:	0f 84 15 49 00 00    	je     6f645b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x501b>
  6f1b46:	31 ff                	xor    %edi,%edi
  6f1b48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6f1b4f:	00 
  6f1b50:	49 89 f8             	mov    %rdi,%r8
  6f1b53:	49 89 d1             	mov    %rdx,%r9
  6f1b56:	49 d1 e9             	shr    $1,%r9
  6f1b59:	4c 01 cf             	add    %r9,%rdi
  6f1b5c:	4c 8d 14 7f          	lea    (%rdi,%rdi,2),%r10
  6f1b60:	4a 39 04 91          	cmp    %rax,(%rcx,%r10,4)
  6f1b64:	49 0f 47 f8          	cmova  %r8,%rdi
  6f1b68:	4c 29 ca             	sub    %r9,%rdx
  6f1b6b:	48 83 fa 01          	cmp    $0x1,%rdx
  6f1b6f:	77 df                	ja     6f1b50 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x710>
  6f1b71:	48 8d 14 7f          	lea    (%rdi,%rdi,2),%rdx
  6f1b75:	48 39 04 91          	cmp    %rax,(%rcx,%rdx,4)
  6f1b79:	0f 85 dc 48 00 00    	jne    6f645b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x501b>
  6f1b7f:	48 8d 0c 91          	lea    (%rcx,%rdx,4),%rcx
  6f1b83:	e9 92 00 00 00       	jmp    6f1c1a <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x7da>
  6f1b88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6f1b8f:	00 
  6f1b90:	be 15 00 00 00       	mov    $0x15,%esi
  6f1b95:	48 89 c3             	mov    %rax,%rbx
  6f1b98:	49 2b 9b f0 01 00 00 	sub    0x1f0(%r11),%rbx
  6f1b9f:	0f 82 b6 48 00 00    	jb     6f645b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x501b>
  6f1ba5:	49 3b 9b f8 01 00 00 	cmp    0x1f8(%r11),%rbx
  6f1bac:	72 6f                	jb     6f1c1d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x7dd>
  6f1bae:	e9 a8 48 00 00       	jmp    6f645b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x501b>
  6f1bb3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f1bba:	84 00 00 00 00 00 
  6f1bc0:	48 89 c7             	mov    %rax,%rdi
  6f1bc3:	48 83 f8 08          	cmp    $0x8,%rax
  6f1bc7:	0f 83 63 fe ff ff    	jae    6f1a30 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5f0>
  6f1bcd:	e9 9f fe ff ff       	jmp    6f1a71 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x631>
  6f1bd2:	31 ff                	xor    %edi,%edi
  6f1bd4:	49 89 f8             	mov    %rdi,%r8
  6f1bd7:	49 c1 e0 04          	shl    $0x4,%r8
  6f1bdb:	31 d2                	xor    %edx,%edx
  6f1bdd:	4a 39 04 01          	cmp    %rax,(%rcx,%r8,1)
  6f1be1:	0f 96 c2             	setbe  %dl
  6f1be4:	48 01 fa             	add    %rdi,%rdx
  6f1be7:	0f 84 6e 48 00 00    	je     6f645b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x501b>
  6f1bed:	48 c1 e2 04          	shl    $0x4,%rdx
  6f1bf1:	48 89 c3             	mov    %rax,%rbx
  6f1bf4:	48 2b 5c 11 f0       	sub    -0x10(%rcx,%rdx,1),%rbx
  6f1bf9:	8b 7c 11 fc          	mov    -0x4(%rcx,%rdx,1),%edi
  6f1bfd:	48 39 fb             	cmp    %rdi,%rbx
  6f1c00:	0f 83 55 48 00 00    	jae    6f645b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x501b>
  6f1c06:	48 01 d1             	add    %rdx,%rcx
  6f1c09:	8b 49 f8             	mov    -0x8(%rcx),%ecx
  6f1c0c:	48 01 cb             	add    %rcx,%rbx
  6f1c0f:	eb 0c                	jmp    6f1c1d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x7dd>
  6f1c11:	48 39 01             	cmp    %rax,(%rcx)
  6f1c14:	0f 85 41 48 00 00    	jne    6f645b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x501b>
  6f1c1a:	8b 59 08             	mov    0x8(%rcx),%ebx
  6f1c1d:	4d 8b ab a0 02 00 00 	mov    0x2a0(%r11),%r13
  6f1c24:	4c 39 eb             	cmp    %r13,%rbx
  6f1c27:	0f 83 e7 48 00 00    	jae    6f6514 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x50d4>
  6f1c2d:	49 8b 93 98 02 00 00 	mov    0x298(%r11),%rdx
  6f1c34:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  6f1c38:	8b 5c ca 08          	mov    0x8(%rdx,%rcx,8),%ebx
  6f1c3c:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  6f1c41:	48 39 cb             	cmp    %rcx,%rbx
  6f1c44:	0f 84 91 fc ff ff    	je     6f18db <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x49b>
  6f1c4a:	49 39 dd             	cmp    %rbx,%r13
  6f1c4d:	0f 86 35 48 00 00    	jbe    6f6488 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5048>
  6f1c53:	49 8b 0e             	mov    (%r14),%rcx
  6f1c56:	48 85 c9             	test   %rcx,%rcx
  6f1c59:	0f 84 7c fc ff ff    	je     6f18db <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x49b>
  6f1c5f:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
  6f1c63:	48 8b 14 f2          	mov    (%rdx,%rsi,8),%rdx
  6f1c67:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  6f1c6c:	48 8b b6 80 06 00 00 	mov    0x680(%rsi),%rsi
  6f1c73:	44 0f b7 41 62       	movzwl 0x62(%rcx),%r8d
  6f1c78:	45 89 c1             	mov    %r8d,%r9d
  6f1c7b:	41 c1 e1 03          	shl    $0x3,%r9d
  6f1c7f:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
  6f1c86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6f1c8d:	00 00 00 
  6f1c90:	4d 85 c9             	test   %r9,%r9
  6f1c93:	74 2b                	je     6f1cc0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x880>
  6f1c95:	48 3b 54 f9 10       	cmp    0x10(%rcx,%rdi,8),%rdx
  6f1c9a:	41 0f 97 c2          	seta   %r10b
  6f1c9e:	41 80 da 00          	sbb    $0x0,%r10b
  6f1ca2:	48 ff c7             	inc    %rdi
  6f1ca5:	49 83 c1 f8          	add    $0xfffffffffffffff8,%r9
  6f1ca9:	41 80 fa 01          	cmp    $0x1,%r10b
  6f1cad:	74 e1                	je     6f1c90 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x850>
  6f1caf:	45 0f b6 c2          	movzbl %r10b,%r8d
  6f1cb3:	45 85 c0             	test   %r8d,%r8d
  6f1cb6:	0f 84 14 fc ff ff    	je     6f18d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x490>
  6f1cbc:	eb 05                	jmp    6f1cc3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x883>
  6f1cbe:	66 90                	xchg   %ax,%ax
  6f1cc0:	4c 89 c7             	mov    %r8,%rdi
  6f1cc3:	48 83 ee 01          	sub    $0x1,%rsi
  6f1cc7:	0f 82 0e fc ff ff    	jb     6f18db <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x49b>
  6f1ccd:	48 8b 4c f9 68       	mov    0x68(%rcx,%rdi,8),%rcx
  6f1cd2:	eb 9f                	jmp    6f1c73 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x833>
  6f1cd4:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f1cdb:	00 
  6f1cdc:	ff 15 76 9c 39 00    	call   *0x399c76(%rip)        # a8b958 <_DYNAMIC+0x500>
  6f1ce2:	4d 8d b5 c0 02 00 00 	lea    0x2c0(%r13),%r14
  6f1ce9:	4c 89 f7             	mov    %r14,%rdi
  6f1cec:	e8 cf 2e ff ff       	call   6e4bc0 <core::ptr::drop_glue::<gpui_reactivity_core::layout::LayoutTree>>
  6f1cf1:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
  6f1cf8:	00 
  6f1cf9:	ba 98 02 00 00       	mov    $0x298,%edx
  6f1cfe:	4c 89 f7             	mov    %r14,%rdi
  6f1d01:	ff 15 b1 99 39 00    	call   *0x3999b1(%rip)        # a8b6b8 <memcpy@GLIBC_2.14>
  6f1d07:	49 c7 85 68 05 00 00 	movq   $0x0,0x568(%r13)
  6f1d0e:	00 00 00 00 
  6f1d12:	49 8b 85 a0 02 00 00 	mov    0x2a0(%r13),%rax
  6f1d19:	48 85 c0             	test   %rax,%rax
  6f1d1c:	0f 84 a9 0c 00 00    	je     6f29cb <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x158b>
  6f1d22:	49 8d 8d 58 05 00 00 	lea    0x558(%r13),%rcx
  6f1d29:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  6f1d30:	00 
  6f1d31:	4d 8b bd 98 02 00 00 	mov    0x298(%r13),%r15
  6f1d38:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  6f1d3c:	49 8d 04 c7          	lea    (%r15,%rax,8),%rax
  6f1d40:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  6f1d45:	45 31 ed             	xor    %r13d,%r13d
  6f1d48:	4c 8d 35 a5 5f 96 ff 	lea    -0x69a05b(%rip),%r14        # 57cf4 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x4c>
  6f1d4f:	48 8d 05 aa 09 37 00 	lea    0x3709aa(%rip),%rax        # a62700 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x300>
  6f1d56:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  6f1d5b:	45 31 e4             	xor    %r12d,%r12d
  6f1d5e:	eb 3b                	jmp    6f1d9b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x95b>
  6f1d60:	49 83 c7 18          	add    $0x18,%r15
  6f1d64:	49 ff c4             	inc    %r12
  6f1d67:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
  6f1d6c:	48 8b 82 60 05 00 00 	mov    0x560(%rdx),%rax
  6f1d73:	4c 89 e9             	mov    %r13,%rcx
  6f1d76:	48 c1 e1 04          	shl    $0x4,%rcx
  6f1d7a:	0f 28 84 24 a0 08 00 	movaps 0x8a0(%rsp),%xmm0
  6f1d81:	00 
  6f1d82:	0f 11 04 08          	movups %xmm0,(%rax,%rcx,1)
  6f1d86:	49 ff c5             	inc    %r13
  6f1d89:	4c 89 aa 68 05 00 00 	mov    %r13,0x568(%rdx)
  6f1d90:	4c 3b 7c 24 58       	cmp    0x58(%rsp),%r15
  6f1d95:	0f 84 33 0c 00 00    	je     6f29ce <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x158e>
  6f1d9b:	41 8b 5f 08          	mov    0x8(%r15),%ebx
  6f1d9f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  6f1da4:	48 39 c3             	cmp    %rax,%rbx
  6f1da7:	74 37                	je     6f1de0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x9a0>
  6f1da9:	49 39 dd             	cmp    %rbx,%r13
  6f1dac:	0f 86 62 47 00 00    	jbe    6f6514 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x50d4>
  6f1db2:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  6f1db7:	48 8b 80 60 05 00 00 	mov    0x560(%rax),%rax
  6f1dbe:	48 c1 e3 04          	shl    $0x4,%rbx
  6f1dc2:	0f 10 04 18          	movups (%rax,%rbx,1),%xmm0
  6f1dc6:	48 8d 84 24 a8 0b 00 	lea    0xba8(%rsp),%rax
  6f1dcd:	00 
  6f1dce:	0f 11 00             	movups %xmm0,(%rax)
  6f1dd1:	b8 01 00 00 00       	mov    $0x1,%eax
  6f1dd6:	eb 0a                	jmp    6f1de2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x9a2>
  6f1dd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6f1ddf:	00 
  6f1de0:	31 c0                	xor    %eax,%eax
  6f1de2:	48 89 84 24 a0 0b 00 	mov    %rax,0xba0(%rsp)
  6f1de9:	00 
  6f1dea:	41 8b 47 10          	mov    0x10(%r15),%eax
  6f1dee:	83 e0 0f             	and    $0xf,%eax
  6f1df1:	83 f8 0a             	cmp    $0xa,%eax
  6f1df4:	0f 83 a4 44 00 00    	jae    6f629e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4e5e>
  6f1dfa:	48 8d 0d 29 8f 96 ff 	lea    -0x6970d7(%rip),%rcx        # 5ad2a <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x3082>
  6f1e01:	0f b6 2c 08          	movzbl (%rax,%rcx,1),%ebp
  6f1e05:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
  6f1e0a:	48 8b 82 00 02 00 00 	mov    0x200(%rdx),%rax
  6f1e11:	49 63 0c 86          	movslq (%r14,%rax,4),%rcx
  6f1e15:	4c 01 f1             	add    %r14,%rcx
  6f1e18:	48 8d 05 01 61 96 ff 	lea    -0x699eff(%rip),%rax        # 57f20 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x278>
  6f1e1f:	ff e1                	jmp    *%rcx
  6f1e21:	4c 8b aa 18 02 00 00 	mov    0x218(%rdx),%r13
  6f1e28:	4d 39 ec             	cmp    %r13,%r12
  6f1e2b:	0f 83 b4 46 00 00    	jae    6f64e5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x50a5>
  6f1e31:	49 6b c4 58          	imul   $0x58,%r12,%rax
  6f1e35:	48 03 82 10 02 00 00 	add    0x210(%rdx),%rax
  6f1e3c:	eb 3a                	jmp    6f1e78 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xa38>
  6f1e3e:	4c 8b aa 20 02 00 00 	mov    0x220(%rdx),%r13
  6f1e45:	4d 39 ec             	cmp    %r13,%r12
  6f1e48:	0f 83 8b 46 00 00    	jae    6f64d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5099>
  6f1e4e:	48 89 d1             	mov    %rdx,%rcx
  6f1e51:	4c 8b aa 10 02 00 00 	mov    0x210(%rdx),%r13
  6f1e58:	48 8b 82 18 02 00 00 	mov    0x218(%rdx),%rax
  6f1e5f:	42 0f b6 1c 20       	movzbl (%rax,%r12,1),%ebx
  6f1e64:	49 39 dd             	cmp    %rbx,%r13
  6f1e67:	0f 86 5a 46 00 00    	jbe    6f64c7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5087>
  6f1e6d:	48 6b c3 58          	imul   $0x58,%rbx,%rax
  6f1e71:	48 03 81 08 02 00 00 	add    0x208(%rcx),%rax
  6f1e78:	48 8b 48 50          	mov    0x50(%rax),%rcx
  6f1e7c:	48 89 8c 24 80 09 00 	mov    %rcx,0x980(%rsp)
  6f1e83:	00 
  6f1e84:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  6f1e88:	0f 29 84 24 70 09 00 	movaps %xmm0,0x970(%rsp)
  6f1e8f:	00 
  6f1e90:	0f 10 00             	movups (%rax),%xmm0
  6f1e93:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  6f1e97:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  6f1e9b:	66 0f 10 58 30       	movupd 0x30(%rax),%xmm3
  6f1ea0:	66 0f 29 9c 24 60 09 	movapd %xmm3,0x960(%rsp)
  6f1ea7:	00 00 
  6f1ea9:	0f 29 94 24 50 09 00 	movaps %xmm2,0x950(%rsp)
  6f1eb0:	00 
  6f1eb1:	0f 29 8c 24 40 09 00 	movaps %xmm1,0x940(%rsp)
  6f1eb8:	00 
  6f1eb9:	0f 29 84 24 30 09 00 	movaps %xmm0,0x930(%rsp)
  6f1ec0:	00 
  6f1ec1:	eb 18                	jmp    6f1edb <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xa9b>
  6f1ec3:	48 8b b2 08 02 00 00 	mov    0x208(%rdx),%rsi
  6f1eca:	48 8d bc 24 30 09 00 	lea    0x930(%rsp),%rdi
  6f1ed1:	00 
  6f1ed2:	4c 89 e2             	mov    %r12,%rdx
  6f1ed5:	ff 15 c5 98 39 00    	call   *0x3998c5(%rip)        # a8b7a0 <_DYNAMIC+0x348>
  6f1edb:	41 8b 5f 08          	mov    0x8(%r15),%ebx
  6f1edf:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  6f1ee4:	48 39 c3             	cmp    %rax,%rbx
  6f1ee7:	74 47                	je     6f1f30 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xaf0>
  6f1ee9:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
  6f1eee:	48 8b 82 00 02 00 00 	mov    0x200(%rdx),%rax
  6f1ef5:	48 8d 35 08 5e 96 ff 	lea    -0x69a1f8(%rip),%rsi        # 57d04 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x5c>
  6f1efc:	48 63 0c 86          	movslq (%rsi,%rax,4),%rcx
  6f1f00:	48 01 f1             	add    %rsi,%rcx
  6f1f03:	48 8d 05 16 60 96 ff 	lea    -0x699fea(%rip),%rax        # 57f20 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x278>
  6f1f0a:	ff e1                	jmp    *%rcx
  6f1f0c:	4c 8b aa 18 02 00 00 	mov    0x218(%rdx),%r13
  6f1f13:	49 39 dd             	cmp    %rbx,%r13
  6f1f16:	0f 86 ec 45 00 00    	jbe    6f6508 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x50c8>
  6f1f1c:	48 6b c3 58          	imul   $0x58,%rbx,%rax
  6f1f20:	48 03 82 10 02 00 00 	add    0x210(%rdx),%rax
  6f1f27:	eb 5c                	jmp    6f1f85 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xb45>
  6f1f29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6f1f30:	b0 02                	mov    $0x2,%al
  6f1f32:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
  6f1f37:	4c 8b 82 60 06 00 00 	mov    0x660(%rdx),%r8
  6f1f3e:	4d 85 c0             	test   %r8,%r8
  6f1f41:	0f 85 be 00 00 00    	jne    6f2005 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xbc5>
  6f1f47:	e9 44 01 00 00       	jmp    6f2090 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xc50>
  6f1f4c:	4c 8b aa 20 02 00 00 	mov    0x220(%rdx),%r13
  6f1f53:	49 39 dd             	cmp    %rbx,%r13
  6f1f56:	0f 86 74 45 00 00    	jbe    6f64d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5090>
  6f1f5c:	48 89 d1             	mov    %rdx,%rcx
  6f1f5f:	4c 8b aa 10 02 00 00 	mov    0x210(%rdx),%r13
  6f1f66:	48 8b 82 18 02 00 00 	mov    0x218(%rdx),%rax
  6f1f6d:	0f b6 1c 18          	movzbl (%rax,%rbx,1),%ebx
  6f1f71:	49 39 dd             	cmp    %rbx,%r13
  6f1f74:	0f 86 4d 45 00 00    	jbe    6f64c7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5087>
  6f1f7a:	48 6b c3 58          	imul   $0x58,%rbx,%rax
  6f1f7e:	48 03 81 08 02 00 00 	add    0x208(%rcx),%rax
  6f1f85:	48 8b 48 50          	mov    0x50(%rax),%rcx
  6f1f89:	48 89 8c 24 c0 04 00 	mov    %rcx,0x4c0(%rsp)
  6f1f90:	00 
  6f1f91:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  6f1f95:	0f 29 84 24 b0 04 00 	movaps %xmm0,0x4b0(%rsp)
  6f1f9c:	00 
  6f1f9d:	0f 10 00             	movups (%rax),%xmm0
  6f1fa0:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  6f1fa4:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  6f1fa8:	66 0f 10 58 30       	movupd 0x30(%rax),%xmm3
  6f1fad:	66 0f 29 9c 24 a0 04 	movapd %xmm3,0x4a0(%rsp)
  6f1fb4:	00 00 
  6f1fb6:	0f 29 94 24 90 04 00 	movaps %xmm2,0x490(%rsp)
  6f1fbd:	00 
  6f1fbe:	0f 29 8c 24 80 04 00 	movaps %xmm1,0x480(%rsp)
  6f1fc5:	00 
  6f1fc6:	0f 29 84 24 70 04 00 	movaps %xmm0,0x470(%rsp)
  6f1fcd:	00 
  6f1fce:	eb 18                	jmp    6f1fe8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xba8>
  6f1fd0:	48 8b b2 08 02 00 00 	mov    0x208(%rdx),%rsi
  6f1fd7:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f1fde:	00 
  6f1fdf:	48 89 da             	mov    %rbx,%rdx
  6f1fe2:	ff 15 b8 97 39 00    	call   *0x3997b8(%rip)        # a8b7a0 <_DYNAMIC+0x348>
  6f1fe8:	0f b6 84 24 c4 04 00 	movzbl 0x4c4(%rsp),%eax
  6f1fef:	00 
  6f1ff0:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
  6f1ff5:	4c 8b 82 60 06 00 00 	mov    0x660(%rdx),%r8
  6f1ffc:	4d 85 c0             	test   %r8,%r8
  6f1fff:	0f 84 8b 00 00 00    	je     6f2090 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xc50>
  6f2005:	49 8b 0f             	mov    (%r15),%rcx
  6f2008:	48 8b 92 68 06 00 00 	mov    0x668(%rdx),%rdx
  6f200f:	41 0f b7 b8 c2 01 00 	movzwl 0x1c2(%r8),%edi
  6f2016:	00 
  6f2017:	41 89 fa             	mov    %edi,%r10d
  6f201a:	41 c1 e2 05          	shl    $0x5,%r10d
  6f201e:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
  6f2025:	45 31 c9             	xor    %r9d,%r9d
  6f2028:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6f202f:	00 
  6f2030:	4d 89 d3             	mov    %r10,%r11
  6f2033:	4d 01 cb             	add    %r9,%r11
  6f2036:	74 28                	je     6f2060 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xc20>
  6f2038:	49 3b 8c f0 70 01 00 	cmp    0x170(%r8,%rsi,8),%rcx
  6f203f:	00 
  6f2040:	41 0f 97 c3          	seta   %r11b
  6f2044:	41 80 db 00          	sbb    $0x0,%r11b
  6f2048:	49 83 c1 e0          	add    $0xffffffffffffffe0,%r9
  6f204c:	48 ff c6             	inc    %rsi
  6f204f:	41 80 fb 01          	cmp    $0x1,%r11b
  6f2053:	74 db                	je     6f2030 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xbf0>
  6f2055:	41 0f b6 fb          	movzbl %r11b,%edi
  6f2059:	85 ff                	test   %edi,%edi
  6f205b:	75 06                	jne    6f2063 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xc23>
  6f205d:	eb 21                	jmp    6f2080 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xc40>
  6f205f:	90                   	nop
  6f2060:	48 89 fe             	mov    %rdi,%rsi
  6f2063:	48 83 ea 01          	sub    $0x1,%rdx
  6f2067:	72 27                	jb     6f2090 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xc50>
  6f2069:	4d 8b 84 f0 c8 01 00 	mov    0x1c8(%r8,%rsi,8),%r8
  6f2070:	00 
  6f2071:	eb 9c                	jmp    6f200f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xbcf>
  6f2073:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f207a:	84 00 00 00 00 00 
  6f2080:	4d 29 c8             	sub    %r9,%r8
  6f2083:	49 83 c0 e0          	add    $0xffffffffffffffe0,%r8
  6f2087:	eb 0a                	jmp    6f2093 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xc53>
  6f2089:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6f2090:	45 31 c0             	xor    %r8d,%r8d
  6f2093:	40 0f b6 f5          	movzbl %bpl,%esi
  6f2097:	0f b6 c8             	movzbl %al,%ecx
  6f209a:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f20a1:	00 
  6f20a2:	48 8d 94 24 30 09 00 	lea    0x930(%rsp),%rdx
  6f20a9:	00 
  6f20aa:	ff 15 08 99 39 00    	call   *0x399908(%rip)        # a8b9b8 <_DYNAMIC+0x560>
  6f20b0:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f20b7:	00 
  6f20b8:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  6f20bd:	48 8d 94 24 a0 0b 00 	lea    0xba0(%rsp),%rdx
  6f20c4:	00 
  6f20c5:	31 c9                	xor    %ecx,%ecx
  6f20c7:	4c 8d 84 24 70 04 00 	lea    0x470(%rsp),%r8
  6f20ce:	00 
  6f20cf:	ff 15 eb 98 39 00    	call   *0x3998eb(%rip)        # a8b9c0 <_DYNAMIC+0x568>
  6f20d5:	80 bc 24 10 07 00 00 	cmpb   $0x0,0x710(%rsp)
  6f20dc:	00 
  6f20dd:	0f 85 fe 0d 00 00    	jne    6f2ee1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1aa1>
  6f20e3:	48 8d 84 24 18 07 00 	lea    0x718(%rsp),%rax
  6f20ea:	00 
  6f20eb:	0f 10 00             	movups (%rax),%xmm0
  6f20ee:	48 8d 84 24 a6 00 00 	lea    0xa6(%rsp),%rax
  6f20f5:	00 
  6f20f6:	0f 11 00             	movups %xmm0,(%rax)
  6f20f9:	0f 10 00             	movups (%rax),%xmm0
  6f20fc:	0f 29 84 24 a0 08 00 	movaps %xmm0,0x8a0(%rsp)
  6f2103:	00 
  6f2104:	41 8b 4f 10          	mov    0x10(%r15),%ecx
  6f2108:	89 c8                	mov    %ecx,%eax
  6f210a:	83 e0 0f             	and    $0xf,%eax
  6f210d:	83 f8 09             	cmp    $0x9,%eax
  6f2110:	0f 87 88 41 00 00    	ja     6f629e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4e5e>
  6f2116:	83 f8 06             	cmp    $0x6,%eax
  6f2119:	74 13                	je     6f212e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xcee>
  6f211b:	f7 c1 f0 ff ff 1f    	test   $0x1ffffff0,%ecx
  6f2121:	0f 95 c1             	setne  %cl
  6f2124:	83 f8 06             	cmp    $0x6,%eax
  6f2127:	0f 94 c0             	sete   %al
  6f212a:	08 c8                	or     %cl,%al
  6f212c:	74 32                	je     6f2160 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xd20>
  6f212e:	0f 28 84 24 a0 08 00 	movaps 0x8a0(%rsp),%xmm0
  6f2135:	00 
  6f2136:	0f 29 84 24 70 04 00 	movaps %xmm0,0x470(%rsp)
  6f213d:	00 
  6f213e:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  6f2143:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
  6f214a:	00 
  6f214b:	48 8b 15 76 98 39 00 	mov    0x399876(%rip),%rdx        # a8b9c8 <_DYNAMIC+0x570>
  6f2152:	ff 15 78 98 39 00    	call   *0x399878(%rip)        # a8b9d0 <_DYNAMIC+0x578>
  6f2158:	a8 01                	test   $0x1,%al
  6f215a:	0f 85 70 0d 00 00    	jne    6f2ed0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1a90>
  6f2160:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  6f2165:	4c 8b a8 68 05 00 00 	mov    0x568(%rax),%r13
  6f216c:	4c 3b a8 58 05 00 00 	cmp    0x558(%rax),%r13
  6f2173:	0f 85 e7 fb ff ff    	jne    6f1d60 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x920>
  6f2179:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
  6f2180:	00 
  6f2181:	e8 6a e8 02 00       	call   7209f0 <<alloc::raw_vec::RawVec<[core::option::Option<gpui::source::FieldId>; 2]>>::grow_one>
  6f2186:	e9 d5 fb ff ff       	jmp    6f1d60 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x920>
  6f218b:	49 8b 85 78 06 00 00 	mov    0x678(%r13),%rax
  6f2192:	4d 8b 95 88 06 00 00 	mov    0x688(%r13),%r10
  6f2199:	48 85 c0             	test   %rax,%rax
  6f219c:	0f 95 c1             	setne  %cl
  6f219f:	4d 85 d2             	test   %r10,%r10
  6f21a2:	0f 95 c2             	setne  %dl
  6f21a5:	20 ca                	and    %cl,%dl
  6f21a7:	80 fa 01             	cmp    $0x1,%dl
  6f21aa:	0f 85 d6 06 00 00    	jne    6f2886 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1446>
  6f21b0:	4d 8b a5 80 06 00 00 	mov    0x680(%r13),%r12
  6f21b7:	45 31 ff             	xor    %r15d,%r15d
  6f21ba:	48 8d 0d 27 0c 37 00 	lea    0x370c27(%rip),%rcx        # a62de8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x9e8>
  6f21c1:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
  6f21c8:	00 
  6f21c9:	48 8d 0d 51 88 96 ff 	lea    -0x6977af(%rip),%rcx        # 5aa21 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2d79>
  6f21d0:	48 89 8c 24 a0 02 00 	mov    %rcx,0x2a0(%rsp)
  6f21d7:	00 
  6f21d8:	48 8d 0d c9 0c 37 00 	lea    0x370cc9(%rip),%rcx        # a62ea8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xaa8>
  6f21df:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  6f21e4:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
  6f21e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6f21f0:	4d 85 ff             	test   %r15,%r15
  6f21f3:	74 16                	je     6f220b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xdcb>
  6f21f5:	41 0f b7 4f 62       	movzwl 0x62(%r15),%ecx
  6f21fa:	49 39 cc             	cmp    %rcx,%r12
  6f21fd:	0f 83 8d 00 00 00    	jae    6f2290 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xe50>
  6f2203:	4c 89 fd             	mov    %r15,%rbp
  6f2206:	e9 a3 00 00 00       	jmp    6f22ae <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xe6e>
  6f220b:	4d 85 e4             	test   %r12,%r12
  6f220e:	74 2a                	je     6f223a <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xdfa>
  6f2210:	4c 89 e1             	mov    %r12,%rcx
  6f2213:	49 89 c7             	mov    %rax,%r15
  6f2216:	48 83 e1 07          	and    $0x7,%rcx
  6f221a:	74 23                	je     6f223f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xdff>
  6f221c:	31 d2                	xor    %edx,%edx
  6f221e:	66 90                	xchg   %ax,%ax
  6f2220:	4d 8b 7f 68          	mov    0x68(%r15),%r15
  6f2224:	48 ff c2             	inc    %rdx
  6f2227:	48 39 d1             	cmp    %rdx,%rcx
  6f222a:	75 f4                	jne    6f2220 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xde0>
  6f222c:	4c 89 e0             	mov    %r12,%rax
  6f222f:	48 29 d0             	sub    %rdx,%rax
  6f2232:	49 83 fc 08          	cmp    $0x8,%r12
  6f2236:	73 18                	jae    6f2250 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xe10>
  6f2238:	eb 3c                	jmp    6f2276 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xe36>
  6f223a:	49 89 c7             	mov    %rax,%r15
  6f223d:	eb 37                	jmp    6f2276 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xe36>
  6f223f:	4c 89 e0             	mov    %r12,%rax
  6f2242:	49 83 fc 08          	cmp    $0x8,%r12
  6f2246:	72 2e                	jb     6f2276 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xe36>
  6f2248:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6f224f:	00 
  6f2250:	49 8b 4f 68          	mov    0x68(%r15),%rcx
  6f2254:	48 8b 49 68          	mov    0x68(%rcx),%rcx
  6f2258:	48 8b 49 68          	mov    0x68(%rcx),%rcx
  6f225c:	48 8b 49 68          	mov    0x68(%rcx),%rcx
  6f2260:	48 8b 49 68          	mov    0x68(%rcx),%rcx
  6f2264:	48 8b 49 68          	mov    0x68(%rcx),%rcx
  6f2268:	48 8b 49 68          	mov    0x68(%rcx),%rcx
  6f226c:	4c 8b 79 68          	mov    0x68(%rcx),%r15
  6f2270:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  6f2274:	75 da                	jne    6f2250 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xe10>
  6f2276:	31 c0                	xor    %eax,%eax
  6f2278:	45 31 e4             	xor    %r12d,%r12d
  6f227b:	41 0f b7 4f 62       	movzwl 0x62(%r15),%ecx
  6f2280:	49 39 cc             	cmp    %rcx,%r12
  6f2283:	0f 82 7a ff ff ff    	jb     6f2203 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xdc3>
  6f2289:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6f2290:	49 8b 2f             	mov    (%r15),%rbp
  6f2293:	48 85 ed             	test   %rbp,%rbp
  6f2296:	0f 84 a0 40 00 00    	je     6f633c <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4efc>
  6f229c:	48 ff c0             	inc    %rax
  6f229f:	45 0f b7 67 60       	movzwl 0x60(%r15),%r12d
  6f22a4:	49 89 ef             	mov    %rbp,%r15
  6f22a7:	66 44 3b 65 62       	cmp    0x62(%rbp),%r12w
  6f22ac:	73 e2                	jae    6f2290 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xe50>
  6f22ae:	48 85 c0             	test   %rax,%rax
  6f22b1:	0f 84 e2 00 00 00    	je     6f2399 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xf59>
  6f22b7:	4a 8d 0c e5 70 00 00 	lea    0x70(,%r12,8),%rcx
  6f22be:	00 
  6f22bf:	48 01 e9             	add    %rbp,%rcx
  6f22c2:	48 89 c2             	mov    %rax,%rdx
  6f22c5:	48 83 e2 07          	and    $0x7,%rdx
  6f22c9:	0f 84 66 01 00 00    	je     6f2435 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xff5>
  6f22cf:	31 f6                	xor    %esi,%esi
  6f22d1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f22d8:	0f 1f 84 00 00 00 00 
  6f22df:	00 
  6f22e0:	4c 8b 39             	mov    (%rcx),%r15
  6f22e3:	49 8d 4f 68          	lea    0x68(%r15),%rcx
  6f22e7:	48 ff c6             	inc    %rsi
  6f22ea:	48 39 f2             	cmp    %rsi,%rdx
  6f22ed:	75 f1                	jne    6f22e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xea0>
  6f22ef:	48 89 c2             	mov    %rax,%rdx
  6f22f2:	48 29 f2             	sub    %rsi,%rdx
  6f22f5:	48 83 f8 08          	cmp    $0x8,%rax
  6f22f9:	72 2e                	jb     6f2329 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xee9>
  6f22fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6f2300:	48 8b 01             	mov    (%rcx),%rax
  6f2303:	48 8b 40 68          	mov    0x68(%rax),%rax
  6f2307:	48 8b 40 68          	mov    0x68(%rax),%rax
  6f230b:	48 8b 40 68          	mov    0x68(%rax),%rax
  6f230f:	48 8b 40 68          	mov    0x68(%rax),%rax
  6f2313:	48 8b 40 68          	mov    0x68(%rax),%rax
  6f2317:	48 8b 40 68          	mov    0x68(%rax),%rax
  6f231b:	4c 8b 78 68          	mov    0x68(%rax),%r15
  6f231f:	49 8d 4f 68          	lea    0x68(%r15),%rcx
  6f2323:	48 83 c2 f8          	add    $0xfffffffffffffff8,%rdx
  6f2327:	75 d7                	jne    6f2300 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xec0>
  6f2329:	45 31 db             	xor    %r11d,%r11d
  6f232c:	4a 8b 5c e5 08       	mov    0x8(%rbp,%r12,8),%rbx
  6f2331:	49 8b 85 e8 01 00 00 	mov    0x1e8(%r13),%rax
  6f2338:	48 83 f8 02          	cmp    $0x2,%rax
  6f233c:	74 75                	je     6f23b3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xf73>
  6f233e:	83 f8 01             	cmp    $0x1,%eax
  6f2341:	0f 85 ce 00 00 00    	jne    6f2415 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xfd5>
  6f2347:	49 8b 85 f0 01 00 00 	mov    0x1f0(%r13),%rax
  6f234e:	49 8b 8d f8 01 00 00 	mov    0x1f8(%r13),%rcx
  6f2355:	be 15 00 00 00       	mov    $0x15,%esi
  6f235a:	48 83 f9 01          	cmp    $0x1,%rcx
  6f235e:	0f 84 e3 00 00 00    	je     6f2447 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1007>
  6f2364:	48 85 c9             	test   %rcx,%rcx
  6f2367:	0f 84 ee 40 00 00    	je     6f645b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x501b>
  6f236d:	31 d2                	xor    %edx,%edx
  6f236f:	90                   	nop
  6f2370:	48 89 d7             	mov    %rdx,%rdi
  6f2373:	49 89 c8             	mov    %rcx,%r8
  6f2376:	49 d1 e8             	shr    $1,%r8
  6f2379:	4c 01 c2             	add    %r8,%rdx
  6f237c:	49 89 d1             	mov    %rdx,%r9
  6f237f:	49 c1 e1 04          	shl    $0x4,%r9
  6f2383:	4a 39 1c 08          	cmp    %rbx,(%rax,%r9,1)
  6f2387:	48 0f 47 d7          	cmova  %rdi,%rdx
  6f238b:	4c 29 c1             	sub    %r8,%rcx
  6f238e:	48 83 f9 01          	cmp    $0x1,%rcx
  6f2392:	77 dc                	ja     6f2370 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xf30>
  6f2394:	e9 b0 00 00 00       	jmp    6f2449 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1009>
  6f2399:	4d 8d 5c 24 01       	lea    0x1(%r12),%r11
  6f239e:	49 89 ef             	mov    %rbp,%r15
  6f23a1:	4a 8b 5c e5 08       	mov    0x8(%rbp,%r12,8),%rbx
  6f23a6:	49 8b 85 e8 01 00 00 	mov    0x1e8(%r13),%rax
  6f23ad:	48 83 f8 02          	cmp    $0x2,%rax
  6f23b1:	75 8b                	jne    6f233e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xefe>
  6f23b3:	49 8b 85 f0 01 00 00 	mov    0x1f0(%r13),%rax
  6f23ba:	49 8b 8d f8 01 00 00 	mov    0x1f8(%r13),%rcx
  6f23c1:	be 15 00 00 00       	mov    $0x15,%esi
  6f23c6:	48 83 f9 01          	cmp    $0x1,%rcx
  6f23ca:	0f 84 b3 00 00 00    	je     6f2483 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1043>
  6f23d0:	48 85 c9             	test   %rcx,%rcx
  6f23d3:	0f 84 82 40 00 00    	je     6f645b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x501b>
  6f23d9:	31 d2                	xor    %edx,%edx
  6f23db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6f23e0:	48 89 d7             	mov    %rdx,%rdi
  6f23e3:	49 89 c8             	mov    %rcx,%r8
  6f23e6:	49 d1 e8             	shr    $1,%r8
  6f23e9:	4c 01 c2             	add    %r8,%rdx
  6f23ec:	4c 8d 0c 52          	lea    (%rdx,%rdx,2),%r9
  6f23f0:	4a 39 1c 88          	cmp    %rbx,(%rax,%r9,4)
  6f23f4:	48 0f 47 d7          	cmova  %rdi,%rdx
  6f23f8:	4c 29 c1             	sub    %r8,%rcx
  6f23fb:	48 83 f9 01          	cmp    $0x1,%rcx
  6f23ff:	77 df                	ja     6f23e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xfa0>
  6f2401:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
  6f2405:	48 39 1c 88          	cmp    %rbx,(%rax,%rcx,4)
  6f2409:	0f 85 4c 40 00 00    	jne    6f645b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x501b>
  6f240f:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
  6f2413:	eb 77                	jmp    6f248c <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x104c>
  6f2415:	be 15 00 00 00       	mov    $0x15,%esi
  6f241a:	49 2b 9d f0 01 00 00 	sub    0x1f0(%r13),%rbx
  6f2421:	0f 82 34 40 00 00    	jb     6f645b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x501b>
  6f2427:	49 3b 9d f8 01 00 00 	cmp    0x1f8(%r13),%rbx
  6f242e:	72 5f                	jb     6f248f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x104f>
  6f2430:	e9 26 40 00 00       	jmp    6f645b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x501b>
  6f2435:	48 89 c2             	mov    %rax,%rdx
  6f2438:	48 83 f8 08          	cmp    $0x8,%rax
  6f243c:	0f 83 be fe ff ff    	jae    6f2300 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xec0>
  6f2442:	e9 e2 fe ff ff       	jmp    6f2329 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xee9>
  6f2447:	31 d2                	xor    %edx,%edx
  6f2449:	48 89 d7             	mov    %rdx,%rdi
  6f244c:	48 c1 e7 04          	shl    $0x4,%rdi
  6f2450:	31 c9                	xor    %ecx,%ecx
  6f2452:	48 39 1c 38          	cmp    %rbx,(%rax,%rdi,1)
  6f2456:	0f 96 c1             	setbe  %cl
  6f2459:	48 01 d1             	add    %rdx,%rcx
  6f245c:	0f 84 f9 3f 00 00    	je     6f645b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x501b>
  6f2462:	48 c1 e1 04          	shl    $0x4,%rcx
  6f2466:	48 2b 5c 08 f0       	sub    -0x10(%rax,%rcx,1),%rbx
  6f246b:	8b 54 08 fc          	mov    -0x4(%rax,%rcx,1),%edx
  6f246f:	48 39 d3             	cmp    %rdx,%rbx
  6f2472:	0f 83 e3 3f 00 00    	jae    6f645b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x501b>
  6f2478:	48 01 c8             	add    %rcx,%rax
  6f247b:	8b 40 f8             	mov    -0x8(%rax),%eax
  6f247e:	48 01 c3             	add    %rax,%rbx
  6f2481:	eb 0c                	jmp    6f248f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x104f>
  6f2483:	48 39 18             	cmp    %rbx,(%rax)
  6f2486:	0f 85 cf 3f 00 00    	jne    6f645b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x501b>
  6f248c:	8b 58 08             	mov    0x8(%rax),%ebx
  6f248f:	4c 89 ea             	mov    %r13,%rdx
  6f2492:	4d 8b ad 68 05 00 00 	mov    0x568(%r13),%r13
  6f2499:	4c 39 eb             	cmp    %r13,%rbx
  6f249c:	0f 83 72 40 00 00    	jae    6f6514 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x50d4>
  6f24a2:	48 8b 82 60 05 00 00 	mov    0x560(%rdx),%rax
  6f24a9:	48 89 d9             	mov    %rbx,%rcx
  6f24ac:	48 c1 e1 04          	shl    $0x4,%rcx
  6f24b0:	0f 10 04 08          	movups (%rax,%rcx,1),%xmm0
  6f24b4:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  6f24bb:	00 
  6f24bc:	4c 8b aa a0 02 00 00 	mov    0x2a0(%rdx),%r13
  6f24c3:	4c 39 eb             	cmp    %r13,%rbx
  6f24c6:	0f 83 e9 3f 00 00    	jae    6f64b5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5075>
  6f24cc:	4c 89 9c 24 a0 01 00 	mov    %r11,0x1a0(%rsp)
  6f24d3:	00 
  6f24d4:	4c 89 94 24 20 01 00 	mov    %r10,0x120(%rsp)
  6f24db:	00 
  6f24dc:	48 8b 82 98 02 00 00 	mov    0x298(%rdx),%rax
  6f24e3:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
  6f24e7:	8b 44 f0 10          	mov    0x10(%rax,%rsi,8),%eax
  6f24eb:	83 e0 0f             	and    $0xf,%eax
  6f24ee:	83 f8 0a             	cmp    $0xa,%eax
  6f24f1:	0f 83 a7 3d 00 00    	jae    6f629e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4e5e>
  6f24f7:	48 8d 0d 2c 88 96 ff 	lea    -0x6977d4(%rip),%rcx        # 5ad2a <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x3082>
  6f24fe:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
  6f2502:	88 44 24 58          	mov    %al,0x58(%rsp)
  6f2506:	49 8b 86 00 02 00 00 	mov    0x200(%r14),%rax
  6f250d:	48 8d 0d c0 57 96 ff 	lea    -0x69a840(%rip),%rcx        # 57cd4 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2c>
  6f2514:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
  6f2518:	48 01 c8             	add    %rcx,%rax
  6f251b:	ff e0                	jmp    *%rax
  6f251d:	0f 10 05 3c 5a 96 ff 	movups -0x69a5c4(%rip),%xmm0        # 57f60 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2b8>
  6f2524:	0f 29 84 24 70 09 00 	movaps %xmm0,0x970(%rsp)
  6f252b:	00 
  6f252c:	0f 10 05 1d 5a 96 ff 	movups -0x69a5e3(%rip),%xmm0        # 57f50 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2a8>
  6f2533:	0f 29 84 24 60 09 00 	movaps %xmm0,0x960(%rsp)
  6f253a:	00 
  6f253b:	0f 10 05 fe 59 96 ff 	movups -0x69a602(%rip),%xmm0        # 57f40 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x298>
  6f2542:	0f 29 84 24 50 09 00 	movaps %xmm0,0x950(%rsp)
  6f2549:	00 
  6f254a:	0f 10 05 df 59 96 ff 	movups -0x69a621(%rip),%xmm0        # 57f30 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x288>
  6f2551:	0f 29 84 24 40 09 00 	movaps %xmm0,0x940(%rsp)
  6f2558:	00 
  6f2559:	0f 10 05 c0 59 96 ff 	movups -0x69a640(%rip),%xmm0        # 57f20 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x278>
  6f2560:	0f 29 84 24 30 09 00 	movaps %xmm0,0x930(%rsp)
  6f2567:	00 
  6f2568:	48 b8 00 00 00 00 01 	movabs $0x3000100000000,%rax
  6f256f:	00 03 00 
  6f2572:	48 89 84 24 80 09 00 	mov    %rax,0x980(%rsp)
  6f2579:	00 
  6f257a:	e9 c7 00 00 00       	jmp    6f2646 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1206>
  6f257f:	49 8b 86 20 02 00 00 	mov    0x220(%r14),%rax
  6f2586:	48 39 c3             	cmp    %rax,%rbx
  6f2589:	0f 83 5b 3f 00 00    	jae    6f64ea <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x50aa>
  6f258f:	49 8b 86 10 02 00 00 	mov    0x210(%r14),%rax
  6f2596:	49 8b 8e 18 02 00 00 	mov    0x218(%r14),%rcx
  6f259d:	0f b6 0c 19          	movzbl (%rcx,%rbx,1),%ecx
  6f25a1:	48 39 c8             	cmp    %rcx,%rax
  6f25a4:	0f 86 4c 3f 00 00    	jbe    6f64f6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x50b6>
  6f25aa:	49 8b 86 08 02 00 00 	mov    0x208(%r14),%rax
  6f25b1:	48 6b c9 58          	imul   $0x58,%rcx,%rcx
  6f25b5:	eb 40                	jmp    6f25f7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x11b7>
  6f25b7:	49 8b b6 08 02 00 00 	mov    0x208(%r14),%rsi
  6f25be:	48 8d bc 24 30 09 00 	lea    0x930(%rsp),%rdi
  6f25c5:	00 
  6f25c6:	48 89 da             	mov    %rbx,%rdx
  6f25c9:	ff 15 d1 91 39 00    	call   *0x3991d1(%rip)        # a8b7a0 <_DYNAMIC+0x348>
  6f25cf:	4d 8b ae a0 02 00 00 	mov    0x2a0(%r14),%r13
  6f25d6:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
  6f25da:	eb 6a                	jmp    6f2646 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1206>
  6f25dc:	49 8b 86 18 02 00 00 	mov    0x218(%r14),%rax
  6f25e3:	48 39 c3             	cmp    %rax,%rbx
  6f25e6:	0f 83 19 3f 00 00    	jae    6f6505 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x50c5>
  6f25ec:	49 8b 86 10 02 00 00 	mov    0x210(%r14),%rax
  6f25f3:	48 6b cb 58          	imul   $0x58,%rbx,%rcx
  6f25f7:	48 8b 54 08 50       	mov    0x50(%rax,%rcx,1),%rdx
  6f25fc:	48 89 94 24 80 09 00 	mov    %rdx,0x980(%rsp)
  6f2603:	00 
  6f2604:	0f 10 44 08 40       	movups 0x40(%rax,%rcx,1),%xmm0
  6f2609:	0f 29 84 24 70 09 00 	movaps %xmm0,0x970(%rsp)
  6f2610:	00 
  6f2611:	0f 10 04 08          	movups (%rax,%rcx,1),%xmm0
  6f2615:	0f 10 4c 08 10       	movups 0x10(%rax,%rcx,1),%xmm1
  6f261a:	0f 10 54 08 20       	movups 0x20(%rax,%rcx,1),%xmm2
  6f261f:	66 0f 10 5c 08 30    	movupd 0x30(%rax,%rcx,1),%xmm3
  6f2625:	66 0f 29 9c 24 60 09 	movapd %xmm3,0x960(%rsp)
  6f262c:	00 00 
  6f262e:	0f 29 94 24 50 09 00 	movaps %xmm2,0x950(%rsp)
  6f2635:	00 
  6f2636:	0f 29 8c 24 40 09 00 	movaps %xmm1,0x940(%rsp)
  6f263d:	00 
  6f263e:	0f 29 84 24 30 09 00 	movaps %xmm0,0x930(%rsp)
  6f2645:	00 
  6f2646:	4c 39 eb             	cmp    %r13,%rbx
  6f2649:	0f 83 6f 3e 00 00    	jae    6f64be <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x507e>
  6f264f:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
  6f2654:	49 8b 85 98 02 00 00 	mov    0x298(%r13),%rax
  6f265b:	8b 5c f0 08          	mov    0x8(%rax,%rsi,8),%ebx
  6f265f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  6f2664:	48 39 c3             	cmp    %rax,%rbx
  6f2667:	74 3e                	je     6f26a7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1267>
  6f2669:	49 8b 85 00 02 00 00 	mov    0x200(%r13),%rax
  6f2670:	48 8d 15 6d 56 96 ff 	lea    -0x69a993(%rip),%rdx        # 57ce4 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x3c>
  6f2677:	48 63 0c 82          	movslq (%rdx,%rax,4),%rcx
  6f267b:	48 01 d1             	add    %rdx,%rcx
  6f267e:	48 8d 05 9b 58 96 ff 	lea    -0x69a765(%rip),%rax        # 57f20 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x278>
  6f2685:	ff e1                	jmp    *%rcx
  6f2687:	4c 89 e9             	mov    %r13,%rcx
  6f268a:	4d 8b ad 18 02 00 00 	mov    0x218(%r13),%r13
  6f2691:	49 39 dd             	cmp    %rbx,%r13
  6f2694:	0f 86 6e 3e 00 00    	jbe    6f6508 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x50c8>
  6f269a:	48 6b c3 58          	imul   $0x58,%rbx,%rax
  6f269e:	48 03 81 10 02 00 00 	add    0x210(%rcx),%rax
  6f26a5:	eb 50                	jmp    6f26f7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x12b7>
  6f26a7:	b0 02                	mov    $0x2,%al
  6f26a9:	4d 8b 85 60 06 00 00 	mov    0x660(%r13),%r8
  6f26b0:	4d 85 c0             	test   %r8,%r8
  6f26b3:	0f 85 bc 00 00 00    	jne    6f2775 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1335>
  6f26b9:	e9 3b 01 00 00       	jmp    6f27f9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x13b9>
  6f26be:	4c 89 e9             	mov    %r13,%rcx
  6f26c1:	4d 8b ad 20 02 00 00 	mov    0x220(%r13),%r13
  6f26c8:	49 39 dd             	cmp    %rbx,%r13
  6f26cb:	0f 86 ff 3d 00 00    	jbe    6f64d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5090>
  6f26d1:	4c 8b a9 10 02 00 00 	mov    0x210(%rcx),%r13
  6f26d8:	48 8b 81 18 02 00 00 	mov    0x218(%rcx),%rax
  6f26df:	0f b6 1c 18          	movzbl (%rax,%rbx,1),%ebx
  6f26e3:	49 39 dd             	cmp    %rbx,%r13
  6f26e6:	0f 86 db 3d 00 00    	jbe    6f64c7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5087>
  6f26ec:	48 6b c3 58          	imul   $0x58,%rbx,%rax
  6f26f0:	48 03 81 08 02 00 00 	add    0x208(%rcx),%rax
  6f26f7:	49 89 cd             	mov    %rcx,%r13
  6f26fa:	48 8b 48 50          	mov    0x50(%rax),%rcx
  6f26fe:	48 89 8c 24 c0 04 00 	mov    %rcx,0x4c0(%rsp)
  6f2705:	00 
  6f2706:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  6f270a:	0f 29 84 24 b0 04 00 	movaps %xmm0,0x4b0(%rsp)
  6f2711:	00 
  6f2712:	0f 10 00             	movups (%rax),%xmm0
  6f2715:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  6f2719:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  6f271d:	66 0f 10 58 30       	movupd 0x30(%rax),%xmm3
  6f2722:	66 0f 29 9c 24 a0 04 	movapd %xmm3,0x4a0(%rsp)
  6f2729:	00 00 
  6f272b:	0f 29 94 24 90 04 00 	movaps %xmm2,0x490(%rsp)
  6f2732:	00 
  6f2733:	0f 29 8c 24 80 04 00 	movaps %xmm1,0x480(%rsp)
  6f273a:	00 
  6f273b:	0f 29 84 24 70 04 00 	movaps %xmm0,0x470(%rsp)
  6f2742:	00 
  6f2743:	eb 18                	jmp    6f275d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x131d>
  6f2745:	49 8b b5 08 02 00 00 	mov    0x208(%r13),%rsi
  6f274c:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f2753:	00 
  6f2754:	48 89 da             	mov    %rbx,%rdx
  6f2757:	ff 15 43 90 39 00    	call   *0x399043(%rip)        # a8b7a0 <_DYNAMIC+0x348>
  6f275d:	0f b6 84 24 c4 04 00 	movzbl 0x4c4(%rsp),%eax
  6f2764:	00 
  6f2765:	4d 8b 85 60 06 00 00 	mov    0x660(%r13),%r8
  6f276c:	4d 85 c0             	test   %r8,%r8
  6f276f:	0f 84 84 00 00 00    	je     6f27f9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x13b9>
  6f2775:	49 8b 8d 68 06 00 00 	mov    0x668(%r13),%rcx
  6f277c:	4a 8b 54 e5 08       	mov    0x8(%rbp,%r12,8),%rdx
  6f2781:	41 0f b7 b8 c2 01 00 	movzwl 0x1c2(%r8),%edi
  6f2788:	00 
  6f2789:	41 89 fa             	mov    %edi,%r10d
  6f278c:	41 c1 e2 05          	shl    $0x5,%r10d
  6f2790:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
  6f2797:	45 31 c9             	xor    %r9d,%r9d
  6f279a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  6f27a0:	4d 89 d3             	mov    %r10,%r11
  6f27a3:	4d 01 cb             	add    %r9,%r11
  6f27a6:	74 28                	je     6f27d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1390>
  6f27a8:	49 3b 94 f0 70 01 00 	cmp    0x170(%r8,%rsi,8),%rdx
  6f27af:	00 
  6f27b0:	41 0f 97 c3          	seta   %r11b
  6f27b4:	41 80 db 00          	sbb    $0x0,%r11b
  6f27b8:	49 83 c1 e0          	add    $0xffffffffffffffe0,%r9
  6f27bc:	48 ff c6             	inc    %rsi
  6f27bf:	41 80 fb 01          	cmp    $0x1,%r11b
  6f27c3:	74 db                	je     6f27a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1360>
  6f27c5:	41 0f b6 fb          	movzbl %r11b,%edi
  6f27c9:	85 ff                	test   %edi,%edi
  6f27cb:	75 06                	jne    6f27d3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1393>
  6f27cd:	eb 21                	jmp    6f27f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x13b0>
  6f27cf:	90                   	nop
  6f27d0:	48 89 fe             	mov    %rdi,%rsi
  6f27d3:	48 83 e9 01          	sub    $0x1,%rcx
  6f27d7:	72 20                	jb     6f27f9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x13b9>
  6f27d9:	4d 8b 84 f0 c8 01 00 	mov    0x1c8(%r8,%rsi,8),%r8
  6f27e0:	00 
  6f27e1:	eb 9e                	jmp    6f2781 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1341>
  6f27e3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f27ea:	84 00 00 00 00 00 
  6f27f0:	4d 29 c8             	sub    %r9,%r8
  6f27f3:	49 83 c0 e0          	add    $0xffffffffffffffe0,%r8
  6f27f7:	eb 03                	jmp    6f27fc <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x13bc>
  6f27f9:	45 31 c0             	xor    %r8d,%r8d
  6f27fc:	0f b6 74 24 58       	movzbl 0x58(%rsp),%esi
  6f2801:	0f b6 c8             	movzbl %al,%ecx
  6f2804:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f280b:	00 
  6f280c:	48 8d 94 24 30 09 00 	lea    0x930(%rsp),%rdx
  6f2813:	00 
  6f2814:	ff 15 9e 91 39 00    	call   *0x39919e(%rip)        # a8b9b8 <_DYNAMIC+0x560>
  6f281a:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
  6f2821:	00 
  6f2822:	0f 29 84 24 10 07 00 	movaps %xmm0,0x710(%rsp)
  6f2829:	00 
  6f282a:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  6f282f:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
  6f2836:	00 
  6f2837:	48 8d 94 24 70 04 00 	lea    0x470(%rsp),%rdx
  6f283e:	00 
  6f283f:	ff 15 93 91 39 00    	call   *0x399193(%rip)        # a8b9d8 <_DYNAMIC+0x580>
  6f2845:	a8 01                	test   $0x1,%al
  6f2847:	0f 85 83 06 00 00    	jne    6f2ed0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1a90>
  6f284d:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  6f2852:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
  6f2859:	00 
  6f285a:	ff 15 98 90 39 00    	call   *0x399098(%rip)        # a8b8f8 <_DYNAMIC+0x4a0>
  6f2860:	3c ff                	cmp    $0xff,%al
  6f2862:	0f 85 81 06 00 00    	jne    6f2ee9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1aa9>
  6f2868:	b8 00 00 00 00       	mov    $0x0,%eax
  6f286d:	4c 8b 94 24 20 01 00 	mov    0x120(%rsp),%r10
  6f2874:	00 
  6f2875:	49 ff ca             	dec    %r10
  6f2878:	4c 8b a4 24 a0 01 00 	mov    0x1a0(%rsp),%r12
  6f287f:	00 
  6f2880:	0f 85 6a f9 ff ff    	jne    6f21f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0xdb0>
  6f2886:	4d 8b ad 68 05 00 00 	mov    0x568(%r13),%r13
  6f288d:	e9 3c 01 00 00       	jmp    6f29ce <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x158e>
  6f2892:	48 8b 30             	mov    (%rax),%rsi
  6f2895:	49 8b 85 e8 01 00 00 	mov    0x1e8(%r13),%rax
  6f289c:	48 85 c0             	test   %rax,%rax
  6f289f:	0f 84 91 07 00 00    	je     6f3036 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1bf6>
  6f28a5:	83 f8 01             	cmp    $0x1,%eax
  6f28a8:	0f 85 a7 07 00 00    	jne    6f3055 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1c15>
  6f28ae:	49 8b 95 f8 01 00 00 	mov    0x1f8(%r13),%rdx
  6f28b5:	48 85 d2             	test   %rdx,%rdx
  6f28b8:	0f 84 28 ef ff ff    	je     6f17e6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3a6>
  6f28be:	49 8b 85 f0 01 00 00 	mov    0x1f0(%r13),%rax
  6f28c5:	31 c9                	xor    %ecx,%ecx
  6f28c7:	48 83 fa 01          	cmp    $0x1,%rdx
  6f28cb:	74 24                	je     6f28f1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x14b1>
  6f28cd:	48 89 cf             	mov    %rcx,%rdi
  6f28d0:	49 89 d0             	mov    %rdx,%r8
  6f28d3:	49 d1 e8             	shr    $1,%r8
  6f28d6:	4c 01 c1             	add    %r8,%rcx
  6f28d9:	49 89 c9             	mov    %rcx,%r9
  6f28dc:	49 c1 e1 04          	shl    $0x4,%r9
  6f28e0:	4a 39 34 08          	cmp    %rsi,(%rax,%r9,1)
  6f28e4:	48 0f 47 cf          	cmova  %rdi,%rcx
  6f28e8:	4c 29 c2             	sub    %r8,%rdx
  6f28eb:	48 83 fa 01          	cmp    $0x1,%rdx
  6f28ef:	77 dc                	ja     6f28cd <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x148d>
  6f28f1:	48 89 cf             	mov    %rcx,%rdi
  6f28f4:	48 c1 e7 04          	shl    $0x4,%rdi
  6f28f8:	31 d2                	xor    %edx,%edx
  6f28fa:	48 39 34 38          	cmp    %rsi,(%rax,%rdi,1)
  6f28fe:	0f 96 c2             	setbe  %dl
  6f2901:	48 01 ca             	add    %rcx,%rdx
  6f2904:	0f 84 dc ee ff ff    	je     6f17e6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3a6>
  6f290a:	48 c1 e2 04          	shl    $0x4,%rdx
  6f290e:	48 2b 74 10 f0       	sub    -0x10(%rax,%rdx,1),%rsi
  6f2913:	8b 4c 10 fc          	mov    -0x4(%rax,%rdx,1),%ecx
  6f2917:	48 39 ce             	cmp    %rcx,%rsi
  6f291a:	0f 83 c6 ee ff ff    	jae    6f17e6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3a6>
  6f2920:	48 01 d0             	add    %rdx,%rax
  6f2923:	8b 40 f8             	mov    -0x8(%rax),%eax
  6f2926:	48 01 c6             	add    %rax,%rsi
  6f2929:	e9 98 26 00 00       	jmp    6f4fc6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3b86>
  6f292e:	48 8b 30             	mov    (%rax),%rsi
  6f2931:	49 8b 85 e8 01 00 00 	mov    0x1e8(%r13),%rax
  6f2938:	48 83 f8 02          	cmp    $0x2,%rax
  6f293c:	0f 84 42 07 00 00    	je     6f3084 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1c44>
  6f2942:	83 f8 01             	cmp    $0x1,%eax
  6f2945:	0f 85 68 07 00 00    	jne    6f30b3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1c73>
  6f294b:	49 8b 95 f8 01 00 00 	mov    0x1f8(%r13),%rdx
  6f2952:	48 85 d2             	test   %rdx,%rdx
  6f2955:	0f 84 bd ee ff ff    	je     6f1818 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3d8>
  6f295b:	49 8b 85 f0 01 00 00 	mov    0x1f0(%r13),%rax
  6f2962:	31 c9                	xor    %ecx,%ecx
  6f2964:	48 83 fa 01          	cmp    $0x1,%rdx
  6f2968:	74 24                	je     6f298e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x154e>
  6f296a:	48 89 cf             	mov    %rcx,%rdi
  6f296d:	49 89 d0             	mov    %rdx,%r8
  6f2970:	49 d1 e8             	shr    $1,%r8
  6f2973:	4c 01 c1             	add    %r8,%rcx
  6f2976:	49 89 c9             	mov    %rcx,%r9
  6f2979:	49 c1 e1 04          	shl    $0x4,%r9
  6f297d:	4a 39 34 08          	cmp    %rsi,(%rax,%r9,1)
  6f2981:	48 0f 47 cf          	cmova  %rdi,%rcx
  6f2985:	4c 29 c2             	sub    %r8,%rdx
  6f2988:	48 83 fa 01          	cmp    $0x1,%rdx
  6f298c:	77 dc                	ja     6f296a <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x152a>
  6f298e:	48 89 cf             	mov    %rcx,%rdi
  6f2991:	48 c1 e7 04          	shl    $0x4,%rdi
  6f2995:	31 d2                	xor    %edx,%edx
  6f2997:	48 39 34 38          	cmp    %rsi,(%rax,%rdi,1)
  6f299b:	0f 96 c2             	setbe  %dl
  6f299e:	48 01 ca             	add    %rcx,%rdx
  6f29a1:	0f 84 71 ee ff ff    	je     6f1818 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3d8>
  6f29a7:	48 c1 e2 04          	shl    $0x4,%rdx
  6f29ab:	48 2b 74 10 f0       	sub    -0x10(%rax,%rdx,1),%rsi
  6f29b0:	8b 4c 10 fc          	mov    -0x4(%rax,%rdx,1),%ecx
  6f29b4:	48 39 ce             	cmp    %rcx,%rsi
  6f29b7:	0f 83 5b ee ff ff    	jae    6f1818 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3d8>
  6f29bd:	48 01 d0             	add    %rdx,%rax
  6f29c0:	8b 40 f8             	mov    -0x8(%rax),%eax
  6f29c3:	48 01 c6             	add    %rax,%rsi
  6f29c6:	e9 a6 26 00 00       	jmp    6f5071 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3c31>
  6f29cb:	45 31 ed             	xor    %r13d,%r13d
  6f29ce:	4c 8b 7c 24 40       	mov    0x40(%rsp),%r15
  6f29d3:	49 8d 87 a8 02 00 00 	lea    0x2a8(%r15),%rax
  6f29da:	4d 8b b7 18 05 00 00 	mov    0x518(%r15),%r14
  6f29e1:	49 8b 9f 38 05 00 00 	mov    0x538(%r15),%rbx
  6f29e8:	49 8d 8f 58 05 00 00 	lea    0x558(%r15),%rcx
  6f29ef:	48 c7 84 24 d8 07 00 	movq   $0xfffffffffffffffe,0x7d8(%rsp)
  6f29f6:	00 fe ff ff ff 
  6f29fb:	49 8d 97 90 02 00 00 	lea    0x290(%r15),%rdx
  6f2a02:	49 8d bf 00 02 00 00 	lea    0x200(%r15),%rdi
  6f2a09:	49 8d b7 f0 05 00 00 	lea    0x5f0(%r15),%rsi
  6f2a10:	48 89 8c 24 28 0b 00 	mov    %rcx,0xb28(%rsp)
  6f2a17:	00 
  6f2a18:	48 89 94 24 30 0b 00 	mov    %rdx,0xb30(%rsp)
  6f2a1f:	00 
  6f2a20:	48 89 b4 24 a0 01 00 	mov    %rsi,0x1a0(%rsp)
  6f2a27:	00 
  6f2a28:	48 89 b4 24 38 0b 00 	mov    %rsi,0xb38(%rsp)
  6f2a2f:	00 
  6f2a30:	48 8d 8c 24 a8 01 00 	lea    0x1a8(%rsp),%rcx
  6f2a37:	00 
  6f2a38:	48 89 8c 24 40 0b 00 	mov    %rcx,0xb40(%rsp)
  6f2a3f:	00 
  6f2a40:	48 89 84 24 48 0b 00 	mov    %rax,0xb48(%rsp)
  6f2a47:	00 
  6f2a48:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
  6f2a4d:	48 89 bc 24 50 0b 00 	mov    %rdi,0xb50(%rsp)
  6f2a54:	00 
  6f2a55:	48 8d 84 24 d8 07 00 	lea    0x7d8(%rsp),%rax
  6f2a5c:	00 
  6f2a5d:	48 89 84 24 58 0b 00 	mov    %rax,0xb58(%rsp)
  6f2a64:	00 
  6f2a65:	4d 85 ed             	test   %r13,%r13
  6f2a68:	0f 84 bc 3a 00 00    	je     6f652a <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x50ea>
  6f2a6e:	49 8b 87 60 05 00 00 	mov    0x560(%r15),%rax
  6f2a75:	66 0f 10 00          	movupd (%rax),%xmm0
  6f2a79:	66 0f 29 84 24 30 09 	movapd %xmm0,0x930(%rsp)
  6f2a80:	00 00 
  6f2a82:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
  6f2a86:	66 0f 28 4c 24 60    	movapd 0x60(%rsp),%xmm1
  6f2a8c:	0f 14 c8             	unpcklps %xmm0,%xmm1
  6f2a8f:	66 0f 28 05 d9 47 96 	movapd -0x69b827(%rip),%xmm0        # 57270 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0xc50>
  6f2a96:	ff 
  6f2a97:	66 0f 56 c8          	orpd   %xmm0,%xmm1
  6f2a9b:	66 0f 5c c8          	subpd  %xmm0,%xmm1
  6f2a9f:	66 0f 5a c9          	cvtpd2ps %xmm1,%xmm1
  6f2aa3:	66 0f 28 c1          	movapd %xmm1,%xmm0
  6f2aa7:	0f c6 c1 55          	shufps $0x55,%xmm1,%xmm0
  6f2aab:	0f 29 8c 24 20 01 00 	movaps %xmm1,0x120(%rsp)
  6f2ab2:	00 
  6f2ab3:	f3 0f 10 94 24 9c 00 	movss  0x9c(%rsp),%xmm2
  6f2aba:	00 00 
  6f2abc:	f3 0f 5e ca          	divss  %xmm2,%xmm1
  6f2ac0:	f3 0f 5e c2          	divss  %xmm2,%xmm0
  6f2ac4:	c7 84 24 70 04 00 00 	movl   $0x0,0x470(%rsp)
  6f2acb:	00 00 00 00 
  6f2acf:	f3 0f 11 8c 24 74 04 	movss  %xmm1,0x474(%rsp)
  6f2ad6:	00 00 
  6f2ad8:	c7 84 24 78 04 00 00 	movl   $0x0,0x478(%rsp)
  6f2adf:	00 00 00 00 
  6f2ae3:	f3 0f 11 84 24 7c 04 	movss  %xmm0,0x47c(%rsp)
  6f2aea:	00 00 
  6f2aec:	41 b4 01             	mov    $0x1,%r12b
  6f2aef:	4c 8d 05 2a 04 37 00 	lea    0x37042a(%rip),%r8        # a62f20 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xb20>
  6f2af6:	48 8d b4 24 30 09 00 	lea    0x930(%rsp),%rsi
  6f2afd:	00 
  6f2afe:	48 8d 94 24 70 04 00 	lea    0x470(%rsp),%rdx
  6f2b05:	00 
  6f2b06:	48 8d 8c 24 28 0b 00 	lea    0xb28(%rsp),%rcx
  6f2b0d:	00 
  6f2b0e:	40 b5 01             	mov    $0x1,%bpl
  6f2b11:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  6f2b16:	ff 15 c4 8e 39 00    	call   *0x398ec4(%rip)        # a8b9e0 <_DYNAMIC+0x588>
  6f2b1c:	a8 01                	test   $0x1,%al
  6f2b1e:	74 55                	je     6f2b75 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1735>
  6f2b20:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6f2b25:	48 c7 00 22 00 00 00 	movq   $0x22,(%rax)
  6f2b2c:	88 50 08             	mov    %dl,0x8(%rax)
  6f2b2f:	48 8b 84 24 d8 07 00 	mov    0x7d8(%rsp),%rax
  6f2b36:	00 
  6f2b37:	41 b4 01             	mov    $0x1,%r12b
  6f2b3a:	40 b5 01             	mov    $0x1,%bpl
  6f2b3d:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6f2b41:	0f 84 b7 03 00 00    	je     6f2efe <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1abe>
  6f2b47:	48 83 e8 0d          	sub    $0xd,%rax
  6f2b4b:	b9 14 00 00 00       	mov    $0x14,%ecx
  6f2b50:	48 0f 4d c8          	cmovge %rax,%rcx
  6f2b54:	48 83 f9 19          	cmp    $0x19,%rcx
  6f2b58:	0f 84 b0 04 00 00    	je     6f300e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1bce>
  6f2b5e:	48 83 f9 14          	cmp    $0x14,%rcx
  6f2b62:	0f 85 96 03 00 00    	jne    6f2efe <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1abe>
  6f2b68:	48 8d 84 24 f0 07 00 	lea    0x7f0(%rsp),%rax
  6f2b6f:	00 
  6f2b70:	e9 a1 04 00 00       	jmp    6f3016 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1bd6>
  6f2b75:	4d 89 fd             	mov    %r15,%r13
  6f2b78:	49 8b 87 18 05 00 00 	mov    0x518(%r15),%rax
  6f2b7f:	4c 29 f0             	sub    %r14,%rax
  6f2b82:	49 8b 8f 38 05 00 00 	mov    0x538(%r15),%rcx
  6f2b89:	49 01 87 08 07 00 00 	add    %rax,0x708(%r15)
  6f2b90:	48 29 d9             	sub    %rbx,%rcx
  6f2b93:	49 01 8f 10 07 00 00 	add    %rcx,0x710(%r15)
  6f2b9a:	83 bc 24 d8 07 00 00 	cmpl   $0xfffffffe,0x7d8(%rsp)
  6f2ba1:	fe 
  6f2ba2:	0f 85 f2 02 00 00    	jne    6f2e9a <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1a5a>
  6f2ba8:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f2baf:	00 
  6f2bb0:	40 b5 01             	mov    $0x1,%bpl
  6f2bb3:	4c 89 ee             	mov    %r13,%rsi
  6f2bb6:	ba 01 00 00 00       	mov    $0x1,%edx
  6f2bbb:	e8 a0 a2 ff ff       	call   6ece60 <<gpui::runtime::Runtime<route_columns_cost::Page>>::refresh_inspector>
  6f2bc0:	83 bc 24 70 04 00 00 	cmpl   $0xfffffffe,0x470(%rsp)
  6f2bc7:	fe 
  6f2bc8:	0f 85 07 04 00 00    	jne    6f2fd5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b95>
  6f2bce:	49 8b b5 a0 02 00 00 	mov    0x2a0(%r13),%rsi
  6f2bd5:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f2bdc:	00 
  6f2bdd:	b9 08 00 00 00       	mov    $0x8,%ecx
  6f2be2:	41 b8 40 00 00 00    	mov    $0x40,%r8d
  6f2be8:	31 d2                	xor    %edx,%edx
  6f2bea:	e8 41 e5 02 00       	call   721130 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6f2bef:	48 8b bc 24 78 04 00 	mov    0x478(%rsp),%rdi
  6f2bf6:	00 
  6f2bf7:	83 bc 24 70 04 00 00 	cmpl   $0x1,0x470(%rsp)
  6f2bfe:	01 
  6f2bff:	0f 84 69 37 00 00    	je     6f636e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4f2e>
  6f2c05:	48 8b 84 24 80 04 00 	mov    0x480(%rsp),%rax
  6f2c0c:	00 
  6f2c0d:	48 89 bc 24 b8 01 00 	mov    %rdi,0x1b8(%rsp)
  6f2c14:	00 
  6f2c15:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
  6f2c1c:	00 
  6f2c1d:	48 c7 84 24 c8 01 00 	movq   $0x0,0x1c8(%rsp)
  6f2c24:	00 00 00 00 00 
  6f2c29:	48 c7 84 24 c8 02 00 	movq   $0x0,0x2c8(%rsp)
  6f2c30:	00 00 00 00 00 
  6f2c35:	48 c7 84 24 d0 02 00 	movq   $0x4,0x2d0(%rsp)
  6f2c3c:	00 04 00 00 00 
  6f2c41:	48 c7 84 24 d8 02 00 	movq   $0x0,0x2d8(%rsp)
  6f2c48:	00 00 00 00 00 
  6f2c4d:	49 8b b5 a0 02 00 00 	mov    0x2a0(%r13),%rsi
  6f2c54:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f2c5b:	00 
  6f2c5c:	b9 08 00 00 00       	mov    $0x8,%ecx
  6f2c61:	41 b8 38 00 00 00    	mov    $0x38,%r8d
  6f2c67:	31 d2                	xor    %edx,%edx
  6f2c69:	e8 c2 e4 02 00       	call   721130 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6f2c6e:	48 8b bc 24 78 04 00 	mov    0x478(%rsp),%rdi
  6f2c75:	00 
  6f2c76:	80 bc 24 70 04 00 00 	cmpb   $0x0,0x470(%rsp)
  6f2c7d:	00 
  6f2c7e:	0f 85 00 37 00 00    	jne    6f6384 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4f44>
  6f2c84:	48 8b 84 24 80 04 00 	mov    0x480(%rsp),%rax
  6f2c8b:	00 
  6f2c8c:	48 89 bc 24 f8 01 00 	mov    %rdi,0x1f8(%rsp)
  6f2c93:	00 
  6f2c94:	48 89 84 24 00 02 00 	mov    %rax,0x200(%rsp)
  6f2c9b:	00 
  6f2c9c:	48 c7 84 24 08 02 00 	movq   $0x0,0x208(%rsp)
  6f2ca3:	00 00 00 00 00 
  6f2ca8:	49 8b 9d 58 06 00 00 	mov    0x658(%r13),%rbx
  6f2caf:	48 85 db             	test   %rbx,%rbx
  6f2cb2:	0f 95 44 24 2f       	setne  0x2f(%rsp)
  6f2cb7:	74 07                	je     6f2cc0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1880>
  6f2cb9:	49 8b 9d a0 02 00 00 	mov    0x2a0(%r13),%rbx
  6f2cc0:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f2cc7:	00 
  6f2cc8:	b9 04 00 00 00       	mov    $0x4,%ecx
  6f2ccd:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  6f2cd3:	48 89 de             	mov    %rbx,%rsi
  6f2cd6:	31 d2                	xor    %edx,%edx
  6f2cd8:	e8 53 e4 02 00       	call   721130 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6f2cdd:	48 8b bc 24 78 04 00 	mov    0x478(%rsp),%rdi
  6f2ce4:	00 
  6f2ce5:	80 bc 24 70 04 00 00 	cmpb   $0x0,0x470(%rsp)
  6f2cec:	00 
  6f2ced:	0f 85 a4 36 00 00    	jne    6f6397 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4f57>
  6f2cf3:	48 8b 84 24 80 04 00 	mov    0x480(%rsp),%rax
  6f2cfa:	00 
  6f2cfb:	48 89 bc 24 20 02 00 	mov    %rdi,0x220(%rsp)
  6f2d02:	00 
  6f2d03:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
  6f2d0a:	00 
  6f2d0b:	48 c7 84 24 30 02 00 	movq   $0x0,0x230(%rsp)
  6f2d12:	00 00 00 00 00 
  6f2d17:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f2d1e:	00 
  6f2d1f:	b9 04 00 00 00       	mov    $0x4,%ecx
  6f2d24:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  6f2d2a:	48 89 de             	mov    %rbx,%rsi
  6f2d2d:	31 d2                	xor    %edx,%edx
  6f2d2f:	e8 fc e3 02 00       	call   721130 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6f2d34:	48 8b bc 24 78 04 00 	mov    0x478(%rsp),%rdi
  6f2d3b:	00 
  6f2d3c:	80 bc 24 70 04 00 00 	cmpb   $0x0,0x470(%rsp)
  6f2d43:	00 
  6f2d44:	0f 85 60 36 00 00    	jne    6f63aa <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4f6a>
  6f2d4a:	48 8b 84 24 80 04 00 	mov    0x480(%rsp),%rax
  6f2d51:	00 
  6f2d52:	48 89 bc 24 38 02 00 	mov    %rdi,0x238(%rsp)
  6f2d59:	00 
  6f2d5a:	48 89 84 24 40 02 00 	mov    %rax,0x240(%rsp)
  6f2d61:	00 
  6f2d62:	48 c7 84 24 48 02 00 	movq   $0x0,0x248(%rsp)
  6f2d69:	00 00 00 00 00 
  6f2d6e:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f2d75:	00 
  6f2d76:	b9 01 00 00 00       	mov    $0x1,%ecx
  6f2d7b:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  6f2d81:	48 89 de             	mov    %rbx,%rsi
  6f2d84:	31 d2                	xor    %edx,%edx
  6f2d86:	e8 a5 e3 02 00       	call   721130 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6f2d8b:	48 8b bc 24 78 04 00 	mov    0x478(%rsp),%rdi
  6f2d92:	00 
  6f2d93:	80 bc 24 70 04 00 00 	cmpb   $0x0,0x470(%rsp)
  6f2d9a:	00 
  6f2d9b:	0f 85 1c 36 00 00    	jne    6f63bd <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4f7d>
  6f2da1:	48 8b 84 24 80 04 00 	mov    0x480(%rsp),%rax
  6f2da8:	00 
  6f2da9:	48 89 bc 24 78 01 00 	mov    %rdi,0x178(%rsp)
  6f2db0:	00 
  6f2db1:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  6f2db8:	00 
  6f2db9:	48 c7 84 24 88 01 00 	movq   $0x0,0x188(%rsp)
  6f2dc0:	00 00 00 00 00 
  6f2dc5:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f2dcc:	00 
  6f2dcd:	b9 04 00 00 00       	mov    $0x4,%ecx
  6f2dd2:	41 b8 04 00 00 00    	mov    $0x4,%r8d
  6f2dd8:	48 89 de             	mov    %rbx,%rsi
  6f2ddb:	31 d2                	xor    %edx,%edx
  6f2ddd:	e8 4e e3 02 00       	call   721130 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6f2de2:	48 8b bc 24 78 04 00 	mov    0x478(%rsp),%rdi
  6f2de9:	00 
  6f2dea:	80 bc 24 70 04 00 00 	cmpb   $0x0,0x470(%rsp)
  6f2df1:	00 
  6f2df2:	0f 85 d8 35 00 00    	jne    6f63d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4f90>
  6f2df8:	48 8b 84 24 80 04 00 	mov    0x480(%rsp),%rax
  6f2dff:	00 
  6f2e00:	48 89 bc 24 58 01 00 	mov    %rdi,0x158(%rsp)
  6f2e07:	00 
  6f2e08:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  6f2e0f:	00 
  6f2e10:	48 c7 84 24 68 01 00 	movq   $0x0,0x168(%rsp)
  6f2e17:	00 00 00 00 00 
  6f2e1c:	48 c7 84 24 b8 03 00 	movq   $0x0,0x3b8(%rsp)
  6f2e23:	00 00 00 00 00 
  6f2e28:	48 c7 84 24 c8 03 00 	movq   $0x0,0x3c8(%rsp)
  6f2e2f:	00 00 00 00 00 
  6f2e34:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  6f2e3b:	00 
  6f2e3c:	48 8b 08             	mov    (%rax),%rcx
  6f2e3f:	48 85 c9             	test   %rcx,%rcx
  6f2e42:	0f 84 8a 02 00 00    	je     6f30d2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1c92>
  6f2e48:	49 8b b5 a0 02 00 00 	mov    0x2a0(%r13),%rsi
  6f2e4f:	49 8b 95 70 06 00 00 	mov    0x670(%r13),%rdx
  6f2e56:	41 b4 01             	mov    $0x1,%r12b
  6f2e59:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f2e60:	00 
  6f2e61:	41 b7 01             	mov    $0x1,%r15b
  6f2e64:	40 b5 01             	mov    $0x1,%bpl
  6f2e67:	e8 74 45 ff ff       	call   6e73e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::metadata_sheet::{closure#0}>
  6f2e6c:	e9 6d 02 00 00       	jmp    6f30de <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1c9e>
  6f2e71:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6f2e76:	48 c7 00 23 00 00 00 	movq   $0x23,(%rax)
  6f2e7d:	44 89 70 08          	mov    %r14d,0x8(%rax)
  6f2e81:	89 68 0c             	mov    %ebp,0xc(%rax)
  6f2e84:	48 8b 9c 24 e0 0b 00 	mov    0xbe0(%rsp),%rbx
  6f2e8b:	00 
  6f2e8c:	83 fb 02             	cmp    $0x2,%ebx
  6f2e8f:	0f 85 21 01 00 00    	jne    6f2fb6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b76>
  6f2e95:	e9 29 01 00 00       	jmp    6f2fc3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b83>
  6f2e9a:	48 8b 84 24 08 08 00 	mov    0x808(%rsp),%rax
  6f2ea1:	00 
  6f2ea2:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  6f2ea7:	48 89 41 30          	mov    %rax,0x30(%rcx)
  6f2eab:	0f 10 84 24 d8 07 00 	movups 0x7d8(%rsp),%xmm0
  6f2eb2:	00 
  6f2eb3:	0f 10 8c 24 e8 07 00 	movups 0x7e8(%rsp),%xmm1
  6f2eba:	00 
  6f2ebb:	0f 10 94 24 f8 07 00 	movups 0x7f8(%rsp),%xmm2
  6f2ec2:	00 
  6f2ec3:	0f 11 51 20          	movups %xmm2,0x20(%rcx)
  6f2ec7:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
  6f2ecb:	0f 11 01             	movups %xmm0,(%rcx)
  6f2ece:	eb 28                	jmp    6f2ef8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1ab8>
  6f2ed0:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6f2ed5:	48 c7 00 22 00 00 00 	movq   $0x22,(%rax)
  6f2edc:	88 50 08             	mov    %dl,0x8(%rax)
  6f2edf:	eb 17                	jmp    6f2ef8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1ab8>
  6f2ee1:	0f b6 84 24 11 07 00 	movzbl 0x711(%rsp),%eax
  6f2ee8:	00 
  6f2ee9:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  6f2eee:	48 c7 01 22 00 00 00 	movq   $0x22,(%rcx)
  6f2ef5:	88 41 08             	mov    %al,0x8(%rcx)
  6f2ef8:	41 b4 01             	mov    $0x1,%r12b
  6f2efb:	40 b5 01             	mov    $0x1,%bpl
  6f2efe:	48 8b bc 24 a8 01 00 	mov    0x1a8(%rsp),%rdi
  6f2f05:	00 
  6f2f06:	48 8b b4 24 b0 01 00 	mov    0x1b0(%rsp),%rsi
  6f2f0d:	00 
  6f2f0e:	e8 dd f8 fe ff       	call   6e27f0 <core::ptr::drop_glue::<core::option::Option<gpui_canvas::text::TextShaper>>>
  6f2f13:	45 84 e4             	test   %r12b,%r12b
  6f2f16:	74 6e                	je     6f2f86 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b46>
  6f2f18:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
  6f2f1f:	00 
  6f2f20:	48 85 c0             	test   %rax,%rax
  6f2f23:	74 39                	je     6f2f5e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b1e>
  6f2f25:	4c 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%r14
  6f2f2c:	00 
  6f2f2d:	41 bf 01 00 00 00    	mov    $0x1,%r15d
  6f2f33:	49 29 c7             	sub    %rax,%r15
  6f2f36:	4c 8b 25 cb 87 39 00 	mov    0x3987cb(%rip),%r12        # a8b708 <_DYNAMIC+0x2b0>
  6f2f3d:	eb 0e                	jmp    6f2f4d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b0d>
  6f2f3f:	90                   	nop
  6f2f40:	49 83 c6 18          	add    $0x18,%r14
  6f2f44:	49 ff c7             	inc    %r15
  6f2f47:	49 83 ff 01          	cmp    $0x1,%r15
  6f2f4b:	74 11                	je     6f2f5e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b1e>
  6f2f4d:	49 8b 06             	mov    (%r14),%rax
  6f2f50:	f0 48 ff 08          	lock decq (%rax)
  6f2f54:	75 ea                	jne    6f2f40 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b00>
  6f2f56:	4c 89 f7             	mov    %r14,%rdi
  6f2f59:	41 ff d4             	call   *%r12
  6f2f5c:	eb e2                	jmp    6f2f40 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b00>
  6f2f5e:	48 8b 84 24 e0 01 00 	mov    0x1e0(%rsp),%rax
  6f2f65:	00 
  6f2f66:	48 85 c0             	test   %rax,%rax
  6f2f69:	74 1b                	je     6f2f86 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b46>
  6f2f6b:	48 8b bc 24 e8 01 00 	mov    0x1e8(%rsp),%rdi
  6f2f72:	00 
  6f2f73:	48 c1 e0 03          	shl    $0x3,%rax
  6f2f77:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6f2f7b:	ba 08 00 00 00       	mov    $0x8,%edx
  6f2f80:	ff 15 22 87 39 00    	call   *0x398722(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f2f86:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
  6f2f8d:	00 
  6f2f8e:	48 85 c0             	test   %rax,%rax
  6f2f91:	74 14                	je     6f2fa7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b67>
  6f2f93:	f0 48 ff 08          	lock decq (%rax)
  6f2f97:	75 0e                	jne    6f2fa7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b67>
  6f2f99:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
  6f2fa0:	00 
  6f2fa1:	ff 15 59 87 39 00    	call   *0x398759(%rip)        # a8b700 <_DYNAMIC+0x2a8>
  6f2fa7:	83 bc 24 e0 0b 00 00 	cmpl   $0x2,0xbe0(%rsp)
  6f2fae:	02 
  6f2faf:	74 12                	je     6f2fc3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b83>
  6f2fb1:	40 84 ed             	test   %bpl,%bpl
  6f2fb4:	74 0d                	je     6f2fc3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b83>
  6f2fb6:	48 8d bc 24 e0 0b 00 	lea    0xbe0(%rsp),%rdi
  6f2fbd:	00 
  6f2fbe:	e8 3d 25 ff ff       	call   6e5500 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  6f2fc3:	48 81 c4 c8 0d 00 00 	add    $0xdc8,%rsp
  6f2fca:	5b                   	pop    %rbx
  6f2fcb:	41 5c                	pop    %r12
  6f2fcd:	41 5d                	pop    %r13
  6f2fcf:	41 5e                	pop    %r14
  6f2fd1:	41 5f                	pop    %r15
  6f2fd3:	5d                   	pop    %rbp
  6f2fd4:	c3                   	ret
  6f2fd5:	48 8b 84 24 a0 04 00 	mov    0x4a0(%rsp),%rax
  6f2fdc:	00 
  6f2fdd:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  6f2fe2:	48 89 41 30          	mov    %rax,0x30(%rcx)
  6f2fe6:	0f 10 84 24 70 04 00 	movups 0x470(%rsp),%xmm0
  6f2fed:	00 
  6f2fee:	0f 10 8c 24 80 04 00 	movups 0x480(%rsp),%xmm1
  6f2ff5:	00 
  6f2ff6:	0f 10 94 24 90 04 00 	movups 0x490(%rsp),%xmm2
  6f2ffd:	00 
  6f2ffe:	0f 11 51 20          	movups %xmm2,0x20(%rcx)
  6f3002:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
  6f3006:	0f 11 01             	movups %xmm0,(%rcx)
  6f3009:	e9 21 fb ff ff       	jmp    6f2b2f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x16ef>
  6f300e:	48 8d 84 24 e0 07 00 	lea    0x7e0(%rsp),%rax
  6f3015:	00 
  6f3016:	48 8b 30             	mov    (%rax),%rsi
  6f3019:	48 85 f6             	test   %rsi,%rsi
  6f301c:	0f 84 dc fe ff ff    	je     6f2efe <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1abe>
  6f3022:	48 8b 78 08          	mov    0x8(%rax),%rdi
  6f3026:	ba 01 00 00 00       	mov    $0x1,%edx
  6f302b:	ff 15 77 86 39 00    	call   *0x398677(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f3031:	e9 c8 fe ff ff       	jmp    6f2efe <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1abe>
  6f3036:	49 2b b5 f0 01 00 00 	sub    0x1f0(%r13),%rsi
  6f303d:	0f 82 a3 e7 ff ff    	jb     6f17e6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3a6>
  6f3043:	49 3b b5 f8 01 00 00 	cmp    0x1f8(%r13),%rsi
  6f304a:	0f 83 96 e7 ff ff    	jae    6f17e6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3a6>
  6f3050:	e9 71 1f 00 00       	jmp    6f4fc6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3b86>
  6f3055:	49 8b 8d f8 01 00 00 	mov    0x1f8(%r13),%rcx
  6f305c:	48 85 c9             	test   %rcx,%rcx
  6f305f:	0f 84 81 e7 ff ff    	je     6f17e6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3a6>
  6f3065:	49 8b 85 f0 01 00 00 	mov    0x1f0(%r13),%rax
  6f306c:	48 83 f9 01          	cmp    $0x1,%rcx
  6f3070:	0f 85 18 1f 00 00    	jne    6f4f8e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3b4e>
  6f3076:	48 39 30             	cmp    %rsi,(%rax)
  6f3079:	0f 85 67 e7 ff ff    	jne    6f17e6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3a6>
  6f307f:	e9 3f 1f 00 00       	jmp    6f4fc3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3b83>
  6f3084:	49 8b 8d f8 01 00 00 	mov    0x1f8(%r13),%rcx
  6f308b:	48 85 c9             	test   %rcx,%rcx
  6f308e:	0f 84 84 e7 ff ff    	je     6f1818 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3d8>
  6f3094:	49 8b 85 f0 01 00 00 	mov    0x1f0(%r13),%rax
  6f309b:	48 83 f9 01          	cmp    $0x1,%rcx
  6f309f:	0f 85 94 1f 00 00    	jne    6f5039 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3bf9>
  6f30a5:	48 39 30             	cmp    %rsi,(%rax)
  6f30a8:	0f 85 6a e7 ff ff    	jne    6f1818 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3d8>
  6f30ae:	e9 bb 1f 00 00       	jmp    6f506e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3c2e>
  6f30b3:	49 2b b5 f0 01 00 00 	sub    0x1f0(%r13),%rsi
  6f30ba:	0f 82 58 e7 ff ff    	jb     6f1818 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3d8>
  6f30c0:	49 3b b5 f8 01 00 00 	cmp    0x1f8(%r13),%rsi
  6f30c7:	0f 83 4b e7 ff ff    	jae    6f1818 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3d8>
  6f30cd:	e9 9f 1f 00 00       	jmp    6f5071 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3c31>
  6f30d2:	48 c7 84 24 10 07 00 	movq   $0xffffffffffffffff,0x710(%rsp)
  6f30d9:	00 ff ff ff ff 
  6f30de:	48 8b 84 24 a0 01 00 	mov    0x1a0(%rsp),%rax
  6f30e5:	00 
  6f30e6:	48 8b 30             	mov    (%rax),%rsi
  6f30e9:	48 85 f6             	test   %rsi,%rsi
  6f30ec:	74 73                	je     6f3161 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1d21>
  6f30ee:	41 b4 01             	mov    $0x1,%r12b
  6f30f1:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f30f8:	00 
  6f30f9:	41 b6 01             	mov    $0x1,%r14b
  6f30fc:	41 b5 01             	mov    $0x1,%r13b
  6f30ff:	40 b5 01             	mov    $0x1,%bpl
  6f3102:	ff 15 e0 88 39 00    	call   *0x3988e0(%rip)        # a8b9e8 <_DYNAMIC+0x590>
  6f3108:	48 8b 84 24 70 04 00 	mov    0x470(%rsp),%rax
  6f310f:	00 
  6f3110:	48 8b b4 24 78 04 00 	mov    0x478(%rsp),%rsi
  6f3117:	00 
  6f3118:	0f 10 84 24 80 04 00 	movups 0x480(%rsp),%xmm0
  6f311f:	00 
  6f3120:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  6f3127:	00 
  6f3128:	0f 10 8c 24 90 04 00 	movups 0x490(%rsp),%xmm1
  6f312f:	00 
  6f3130:	0f 29 8c 24 30 09 00 	movaps %xmm1,0x930(%rsp)
  6f3137:	00 
  6f3138:	48 8b 8c 24 a0 04 00 	mov    0x4a0(%rsp),%rcx
  6f313f:	00 
  6f3140:	48 89 8c 24 40 09 00 	mov    %rcx,0x940(%rsp)
  6f3147:	00 
  6f3148:	0f 29 84 24 70 03 00 	movaps %xmm0,0x370(%rsp)
  6f314f:	00 
  6f3150:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6f3154:	0f 85 e0 1d 00 00    	jne    6f4f3a <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3afa>
  6f315a:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
  6f315f:	eb 07                	jmp    6f3168 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1d28>
  6f3161:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
  6f3168:	0f 28 84 24 70 03 00 	movaps 0x370(%rsp),%xmm0
  6f316f:	00 
  6f3170:	0f 11 84 24 c8 07 00 	movups %xmm0,0x7c8(%rsp)
  6f3177:	00 
  6f3178:	48 89 b4 24 90 02 00 	mov    %rsi,0x290(%rsp)
  6f317f:	00 
  6f3180:	48 89 b4 24 c0 07 00 	mov    %rsi,0x7c0(%rsp)
  6f3187:	00 
  6f3188:	80 7c 24 2f 00       	cmpb   $0x0,0x2f(%rsp)
  6f318d:	0f 84 94 00 00 00    	je     6f3227 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1de7>
  6f3193:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f319a:	00 
  6f319b:	48 8d 94 24 f8 01 00 	lea    0x1f8(%rsp),%rdx
  6f31a2:	00 
  6f31a3:	48 8d 8c 24 58 01 00 	lea    0x158(%rsp),%rcx
  6f31aa:	00 
  6f31ab:	4c 89 ee             	mov    %r13,%rsi
  6f31ae:	e8 9d 41 02 00       	call   717350 <gpui::runtime::scroll::geometry::<route_columns_cost::Page>>
  6f31b3:	48 8b 84 24 70 04 00 	mov    0x470(%rsp),%rax
  6f31ba:	00 
  6f31bb:	0f 10 84 24 78 04 00 	movups 0x478(%rsp),%xmm0
  6f31c2:	00 
  6f31c3:	0f 29 84 24 30 09 00 	movaps %xmm0,0x930(%rsp)
  6f31ca:	00 
  6f31cb:	0f 10 84 24 88 04 00 	movups 0x488(%rsp),%xmm0
  6f31d2:	00 
  6f31d3:	0f 29 84 24 40 09 00 	movaps %xmm0,0x940(%rsp)
  6f31da:	00 
  6f31db:	0f 10 84 24 98 04 00 	movups 0x498(%rsp),%xmm0
  6f31e2:	00 
  6f31e3:	0f 29 84 24 50 09 00 	movaps %xmm0,0x950(%rsp)
  6f31ea:	00 
  6f31eb:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6f31ef:	0f 85 a5 1f 00 00    	jne    6f519a <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3d5a>
  6f31f5:	0f 28 84 24 30 09 00 	movaps 0x930(%rsp),%xmm0
  6f31fc:	00 
  6f31fd:	0f 28 8c 24 40 09 00 	movaps 0x940(%rsp),%xmm1
  6f3204:	00 
  6f3205:	0f 28 94 24 50 09 00 	movaps 0x950(%rsp),%xmm2
  6f320c:	00 
  6f320d:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
  6f3214:	00 
  6f3215:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
  6f321c:	00 
  6f321d:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
  6f3224:	00 
  6f3225:	eb 3b                	jmp    6f3262 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1e22>
  6f3227:	48 c7 84 24 40 03 00 	movq   $0x0,0x340(%rsp)
  6f322e:	00 00 00 00 00 
  6f3233:	48 c7 84 24 48 03 00 	movq   $0x8,0x348(%rsp)
  6f323a:	00 08 00 00 00 
  6f323f:	0f 57 c0             	xorps  %xmm0,%xmm0
  6f3242:	0f 11 84 24 50 03 00 	movups %xmm0,0x350(%rsp)
  6f3249:	00 
  6f324a:	48 c7 84 24 60 03 00 	movq   $0x8,0x360(%rsp)
  6f3251:	00 08 00 00 00 
  6f3256:	48 c7 84 24 68 03 00 	movq   $0x0,0x368(%rsp)
  6f325d:	00 00 00 00 00 
  6f3262:	48 8d bc 24 b8 0b 00 	lea    0xbb8(%rsp),%rdi
  6f3269:	00 
  6f326a:	4c 89 ee             	mov    %r13,%rsi
  6f326d:	e8 fe 99 ff ff       	call   6ecc70 <<gpui::runtime::Runtime<route_columns_cost::Page>>::inspector_display>
  6f3272:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  6f3277:	ff 15 73 87 39 00    	call   *0x398773(%rip)        # a8b9f0 <_DYNAMIC+0x598>
  6f327d:	0f b6 84 24 b8 0b 00 	movzbl 0xbb8(%rsp),%eax
  6f3284:	00 
  6f3285:	88 44 24 7f          	mov    %al,0x7f(%rsp)
  6f3289:	83 bc 24 e0 0b 00 00 	cmpl   $0x2,0xbe0(%rsp)
  6f3290:	02 
  6f3291:	48 8b 84 24 c0 0b 00 	mov    0xbc0(%rsp),%rax
  6f3298:	00 
  6f3299:	48 89 84 24 a8 07 00 	mov    %rax,0x7a8(%rsp)
  6f32a0:	00 
  6f32a1:	48 8d b4 24 e0 0b 00 	lea    0xbe0(%rsp),%rsi
  6f32a8:	00 
  6f32a9:	49 0f 44 f5          	cmove  %r13,%rsi
  6f32ad:	48 8d bc 24 30 09 00 	lea    0x930(%rsp),%rdi
  6f32b4:	00 
  6f32b5:	ff 15 3d 87 39 00    	call   *0x39873d(%rip)        # a8b9f8 <_DYNAMIC+0x5a0>
  6f32bb:	0f 10 05 3e 31 96 ff 	movups -0x69cec2(%rip),%xmm0        # 56400 <anon.079f5e587c394fcac2765eb4d0cf0bc2.360.llvm.6319143315422321905+0x50>
  6f32c2:	0f 29 84 24 70 04 00 	movaps %xmm0,0x470(%rsp)
  6f32c9:	00 
  6f32ca:	48 8d bc 24 30 09 00 	lea    0x930(%rsp),%rdi
  6f32d1:	00 
  6f32d2:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
  6f32d9:	00 
  6f32da:	ff 15 20 87 39 00    	call   *0x398720(%rip)        # a8ba00 <_DYNAMIC+0x5a8>
  6f32e0:	49 ff 85 20 07 00 00 	incq   0x720(%r13)
  6f32e7:	49 8b 85 a0 02 00 00 	mov    0x2a0(%r13),%rax
  6f32ee:	48 89 84 24 98 07 00 	mov    %rax,0x798(%rsp)
  6f32f5:	00 
  6f32f6:	48 85 c0             	test   %rax,%rax
  6f32f9:	0f 84 e0 1d 00 00    	je     6f50df <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3c9f>
  6f32ff:	f3 0f 10 84 24 9c 00 	movss  0x9c(%rsp),%xmm0
  6f3306:	00 00 
  6f3308:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  6f330c:	f2 0f 11 84 24 88 07 	movsd  %xmm0,0x788(%rsp)
  6f3313:	00 00 
  6f3315:	49 8d 85 60 06 00 00 	lea    0x660(%r13),%rax
  6f331c:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
  6f3323:	00 
  6f3324:	0f 57 c0             	xorps  %xmm0,%xmm0
  6f3327:	66 0f 14 84 24 20 01 	unpcklpd 0x120(%rsp),%xmm0
  6f332e:	00 00 
  6f3330:	0f 29 84 24 50 08 00 	movaps %xmm0,0x850(%rsp)
  6f3337:	00 
  6f3338:	31 c9                	xor    %ecx,%ecx
  6f333a:	48 b8 00 00 00 00 00 	movabs $0x8000000000000000,%rax
  6f3341:	00 00 80 
  6f3344:	48 ff c0             	inc    %rax
  6f3347:	48 89 84 24 78 07 00 	mov    %rax,0x778(%rsp)
  6f334e:	00 
  6f334f:	48 8d 05 0a fc 36 00 	lea    0x36fc0a(%rip),%rax        # a62f60 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xb60>
  6f3356:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
  6f335d:	00 
  6f335e:	48 8d 05 13 f4 36 00 	lea    0x36f413(%rip),%rax        # a62778 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x378>
  6f3365:	48 89 84 24 20 03 00 	mov    %rax,0x320(%rsp)
  6f336c:	00 
  6f336d:	48 8d 05 7c fc 36 00 	lea    0x36fc7c(%rip),%rax        # a62ff0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xbf0>
  6f3374:	48 89 84 24 80 02 00 	mov    %rax,0x280(%rsp)
  6f337b:	00 
  6f337c:	48 8d 05 3a 77 96 ff 	lea    -0x6988c6(%rip),%rax        # 5aabd <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2e15>
  6f3383:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
  6f338a:	00 
  6f338b:	eb 1b                	jmp    6f33a8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1f68>
  6f338d:	48 8b 8c 24 b0 07 00 	mov    0x7b0(%rsp),%rcx
  6f3394:	00 
  6f3395:	48 3b 8c 24 98 07 00 	cmp    0x798(%rsp),%rcx
  6f339c:	00 
  6f339d:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
  6f33a2:	0f 84 37 1d 00 00    	je     6f50df <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3c9f>
  6f33a8:	48 3b 8c 24 a8 07 00 	cmp    0x7a8(%rsp),%rcx
  6f33af:	00 
  6f33b0:	0f 94 c0             	sete   %al
  6f33b3:	84 44 24 7f          	test   %al,0x7f(%rsp)
  6f33b7:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  6f33bc:	74 71                	je     6f342f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1fef>
  6f33be:	48 8b 94 24 c0 01 00 	mov    0x1c0(%rsp),%rdx
  6f33c5:	00 
  6f33c6:	48 8b 8c 24 c8 01 00 	mov    0x1c8(%rsp),%rcx
  6f33cd:	00 
  6f33ce:	4c 8b 84 24 d0 02 00 	mov    0x2d0(%rsp),%r8
  6f33d5:	00 
  6f33d6:	4c 8b 8c 24 d8 02 00 	mov    0x2d8(%rsp),%r9
  6f33dd:	00 
  6f33de:	41 0f 10 85 b0 02 00 	movups 0x2b0(%r13),%xmm0
  6f33e5:	00 
  6f33e6:	41 0f 10 8d 60 05 00 	movups 0x560(%r13),%xmm1
  6f33ed:	00 
  6f33ee:	0f 11 4c 24 18       	movups %xmm1,0x18(%rsp)
  6f33f3:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  6f33f8:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6f33fd:	0f 11 04 24          	movups %xmm0,(%rsp)
  6f3401:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f3408:	00 
  6f3409:	48 8d b4 24 c0 0b 00 	lea    0xbc0(%rsp),%rsi
  6f3410:	00 
  6f3411:	ff 15 f1 85 39 00    	call   *0x3985f1(%rip)        # a8ba08 <_DYNAMIC+0x5b0>
  6f3417:	83 bc 24 70 04 00 00 	cmpl   $0xfffffffe,0x470(%rsp)
  6f341e:	fe 
  6f341f:	0f 85 d3 2a 00 00    	jne    6f5ef8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4ab8>
  6f3425:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
  6f342a:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  6f342f:	49 8b 85 68 05 00 00 	mov    0x568(%r13),%rax
  6f3436:	48 39 c1             	cmp    %rax,%rcx
  6f3439:	0f 83 e2 31 00 00    	jae    6f6621 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51e1>
  6f343f:	49 8b 85 60 05 00 00 	mov    0x560(%r13),%rax
  6f3446:	48 c1 e1 04          	shl    $0x4,%rcx
  6f344a:	0f 10 04 08          	movups (%rax,%rcx,1),%xmm0
  6f344e:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  6f3455:	00 
  6f3456:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f345d:	00 
  6f345e:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  6f3463:	48 8d 94 24 a0 00 00 	lea    0xa0(%rsp),%rdx
  6f346a:	00 
  6f346b:	ff 15 a7 84 39 00    	call   *0x3984a7(%rip)        # a8b918 <_DYNAMIC+0x4c0>
  6f3471:	80 bc 24 70 04 00 00 	cmpb   $0x0,0x470(%rsp)
  6f3478:	00 
  6f3479:	0f 85 00 2a 00 00    	jne    6f5e7f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4a3f>
  6f347f:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  6f3484:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
  6f3488:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
  6f348d:	49 8b b0 a0 02 00 00 	mov    0x2a0(%r8),%rsi
  6f3494:	48 39 f1             	cmp    %rsi,%rcx
  6f3497:	48 89 8c 24 b0 07 00 	mov    %rcx,0x7b0(%rsp)
  6f349e:	00 
  6f349f:	73 2b                	jae    6f34cc <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x208c>
  6f34a1:	49 8b 80 98 02 00 00 	mov    0x298(%r8),%rax
  6f34a8:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  6f34ac:	8b 44 c8 08          	mov    0x8(%rax,%rcx,8),%eax
  6f34b0:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  6f34b5:	48 39 c8             	cmp    %rcx,%rax
  6f34b8:	0f 95 c1             	setne  %cl
  6f34bb:	48 39 c2             	cmp    %rax,%rdx
  6f34be:	0f 94 c0             	sete   %al
  6f34c1:	20 c8                	and    %cl,%al
  6f34c3:	89 84 24 d8 01 00 00 	mov    %eax,0x1d8(%rsp)
  6f34ca:	eb 0b                	jmp    6f34d7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2097>
  6f34cc:	c7 84 24 d8 01 00 00 	movl   $0x0,0x1d8(%rsp)
  6f34d3:	00 00 00 00 
  6f34d7:	f2 0f 10 84 24 b4 04 	movsd  0x4b4(%rsp),%xmm0
  6f34de:	00 00 
  6f34e0:	0f 29 84 24 90 08 00 	movaps %xmm0,0x890(%rsp)
  6f34e7:	00 
  6f34e8:	0f 10 84 24 84 04 00 	movups 0x484(%rsp),%xmm0
  6f34ef:	00 
  6f34f0:	0f 29 84 24 80 08 00 	movaps %xmm0,0x880(%rsp)
  6f34f7:	00 
  6f34f8:	f3 0f 10 84 24 88 04 	movss  0x488(%rsp),%xmm0
  6f34ff:	00 00 
  6f3501:	f3 0f 11 84 24 1c 03 	movss  %xmm0,0x31c(%rsp)
  6f3508:	00 00 
  6f350a:	0f 10 84 24 94 04 00 	movups 0x494(%rsp),%xmm0
  6f3511:	00 
  6f3512:	0f 29 84 24 e0 03 00 	movaps %xmm0,0x3e0(%rsp)
  6f3519:	00 
  6f351a:	f3 0f 10 84 24 9c 04 	movss  0x49c(%rsp),%xmm0
  6f3521:	00 00 
  6f3523:	0f 29 84 24 60 08 00 	movaps %xmm0,0x860(%rsp)
  6f352a:	00 
  6f352b:	f3 0f 10 84 24 98 04 	movss  0x498(%rsp),%xmm0
  6f3532:	00 00 
  6f3534:	f3 0f 11 84 24 18 03 	movss  %xmm0,0x318(%rsp)
  6f353b:	00 00 
  6f353d:	f2 0f 10 84 24 bc 04 	movsd  0x4bc(%rsp),%xmm0
  6f3544:	00 00 
  6f3546:	0f 29 84 24 a0 02 00 	movaps %xmm0,0x2a0(%rsp)
  6f354d:	00 
  6f354e:	f2 0f 10 84 24 c4 04 	movsd  0x4c4(%rsp),%xmm0
  6f3555:	00 00 
  6f3557:	0f 29 84 24 70 08 00 	movaps %xmm0,0x870(%rsp)
  6f355e:	00 
  6f355f:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  6f3564:	48 8b 00             	mov    (%rax),%rax
  6f3567:	48 8d 0d a6 47 96 ff 	lea    -0x69b85a(%rip),%rcx        # 57d14 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x6c>
  6f356e:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
  6f3572:	48 01 c8             	add    %rcx,%rax
  6f3575:	ff e0                	jmp    *%rax
  6f3577:	0f 10 05 e2 49 96 ff 	movups -0x69b61e(%rip),%xmm0        # 57f60 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2b8>
  6f357e:	0f 29 84 24 b0 04 00 	movaps %xmm0,0x4b0(%rsp)
  6f3585:	00 
  6f3586:	0f 10 05 c3 49 96 ff 	movups -0x69b63d(%rip),%xmm0        # 57f50 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2a8>
  6f358d:	0f 29 84 24 a0 04 00 	movaps %xmm0,0x4a0(%rsp)
  6f3594:	00 
  6f3595:	0f 10 05 a4 49 96 ff 	movups -0x69b65c(%rip),%xmm0        # 57f40 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x298>
  6f359c:	0f 29 84 24 90 04 00 	movaps %xmm0,0x490(%rsp)
  6f35a3:	00 
  6f35a4:	0f 10 05 85 49 96 ff 	movups -0x69b67b(%rip),%xmm0        # 57f30 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x288>
  6f35ab:	0f 29 84 24 80 04 00 	movaps %xmm0,0x480(%rsp)
  6f35b2:	00 
  6f35b3:	0f 10 05 66 49 96 ff 	movups -0x69b69a(%rip),%xmm0        # 57f20 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x278>
  6f35ba:	0f 29 84 24 70 04 00 	movaps %xmm0,0x470(%rsp)
  6f35c1:	00 
  6f35c2:	48 b8 00 00 00 00 01 	movabs $0x3000100000000,%rax
  6f35c9:	00 03 00 
  6f35cc:	48 89 84 24 c0 04 00 	mov    %rax,0x4c0(%rsp)
  6f35d3:	00 
  6f35d4:	e9 ca 00 00 00       	jmp    6f36a3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2263>
  6f35d9:	49 8b 80 20 02 00 00 	mov    0x220(%r8),%rax
  6f35e0:	48 39 c2             	cmp    %rax,%rdx
  6f35e3:	0f 83 04 30 00 00    	jae    6f65ed <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51ad>
  6f35e9:	49 8b 80 10 02 00 00 	mov    0x210(%r8),%rax
  6f35f0:	49 8b 88 18 02 00 00 	mov    0x218(%r8),%rcx
  6f35f7:	0f b6 0c 11          	movzbl (%rcx,%rdx,1),%ecx
  6f35fb:	48 39 c8             	cmp    %rcx,%rax
  6f35fe:	0f 86 f2 2f 00 00    	jbe    6f65f6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51b6>
  6f3604:	49 8b 80 08 02 00 00 	mov    0x208(%r8),%rax
  6f360b:	48 6b c9 58          	imul   $0x58,%rcx,%rcx
  6f360f:	eb 43                	jmp    6f3654 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2214>
  6f3611:	49 8b b0 08 02 00 00 	mov    0x208(%r8),%rsi
  6f3618:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f361f:	00 
  6f3620:	ff 15 7a 81 39 00    	call   *0x39817a(%rip)        # a8b7a0 <_DYNAMIC+0x348>
  6f3626:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
  6f362b:	49 8b b0 a0 02 00 00 	mov    0x2a0(%r8),%rsi
  6f3632:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  6f3637:	eb 6a                	jmp    6f36a3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2263>
  6f3639:	49 8b 80 18 02 00 00 	mov    0x218(%r8),%rax
  6f3640:	48 39 c2             	cmp    %rax,%rdx
  6f3643:	0f 83 bb 2f 00 00    	jae    6f6604 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51c4>
  6f3649:	49 8b 80 10 02 00 00 	mov    0x210(%r8),%rax
  6f3650:	48 6b ca 58          	imul   $0x58,%rdx,%rcx
  6f3654:	48 8b 7c 08 50       	mov    0x50(%rax,%rcx,1),%rdi
  6f3659:	48 89 bc 24 c0 04 00 	mov    %rdi,0x4c0(%rsp)
  6f3660:	00 
  6f3661:	0f 10 44 08 40       	movups 0x40(%rax,%rcx,1),%xmm0
  6f3666:	0f 29 84 24 b0 04 00 	movaps %xmm0,0x4b0(%rsp)
  6f366d:	00 
  6f366e:	0f 10 04 08          	movups (%rax,%rcx,1),%xmm0
  6f3672:	0f 10 4c 08 10       	movups 0x10(%rax,%rcx,1),%xmm1
  6f3677:	0f 10 54 08 20       	movups 0x20(%rax,%rcx,1),%xmm2
  6f367c:	66 0f 10 5c 08 30    	movupd 0x30(%rax,%rcx,1),%xmm3
  6f3682:	66 0f 29 9c 24 a0 04 	movapd %xmm3,0x4a0(%rsp)
  6f3689:	00 00 
  6f368b:	0f 29 94 24 90 04 00 	movaps %xmm2,0x490(%rsp)
  6f3692:	00 
  6f3693:	0f 29 8c 24 80 04 00 	movaps %xmm1,0x480(%rsp)
  6f369a:	00 
  6f369b:	0f 29 84 24 70 04 00 	movaps %xmm0,0x470(%rsp)
  6f36a2:	00 
  6f36a3:	48 39 f2             	cmp    %rsi,%rdx
  6f36a6:	0f 83 a9 2e 00 00    	jae    6f6555 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5115>
  6f36ac:	49 8b b8 98 02 00 00 	mov    0x298(%r8),%rdi
  6f36b3:	4c 8d 3c 52          	lea    (%rdx,%rdx,2),%r15
  6f36b7:	42 8b 54 ff 08       	mov    0x8(%rdi,%r15,8),%edx
  6f36bc:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  6f36c1:	48 39 c2             	cmp    %rax,%rdx
  6f36c4:	74 1a                	je     6f36e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x22a0>
  6f36c6:	e8 d5 49 ff ff       	call   6e80a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner::{closure#13}>
  6f36cb:	89 84 24 1c 01 00 00 	mov    %eax,0x11c(%rsp)
  6f36d2:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
  6f36d7:	49 8b b0 a0 02 00 00 	mov    0x2a0(%r8),%rsi
  6f36de:	eb 0b                	jmp    6f36eb <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x22ab>
  6f36e0:	c7 84 24 1c 01 00 00 	movl   $0x0,0x11c(%rsp)
  6f36e7:	00 00 00 00 
  6f36eb:	48 39 74 24 30       	cmp    %rsi,0x30(%rsp)
  6f36f0:	48 8b 94 24 50 01 00 	mov    0x150(%rsp),%rdx
  6f36f7:	00 
  6f36f8:	0f 83 66 2e 00 00    	jae    6f6564 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5124>
  6f36fe:	49 8b 80 98 02 00 00 	mov    0x298(%r8),%rax
  6f3705:	42 8b 5c f8 08       	mov    0x8(%rax,%r15,8),%ebx
  6f370a:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  6f370f:	48 39 cb             	cmp    %rcx,%rbx
  6f3712:	74 19                	je     6f372d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x22ed>
  6f3714:	48 39 de             	cmp    %rbx,%rsi
  6f3717:	0f 86 56 2e 00 00    	jbe    6f6573 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5133>
  6f371d:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  6f3721:	48 8b 0c c8          	mov    (%rax,%rcx,8),%rcx
  6f3725:	48 89 8c 24 a0 07 00 	mov    %rcx,0x7a0(%rsp)
  6f372c:	00 
  6f372d:	48 8b 0a             	mov    (%rdx),%rcx
  6f3730:	0f 57 c0             	xorps  %xmm0,%xmm0
  6f3733:	f3 0f 11 84 24 e8 00 	movss  %xmm0,0xe8(%rsp)
  6f373a:	00 00 
  6f373c:	48 85 c9             	test   %rcx,%rcx
  6f373f:	74 2e                	je     6f376f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x232f>
  6f3741:	48 8b b9 00 01 00 00 	mov    0x100(%rcx),%rdi
  6f3748:	48 85 ff             	test   %rdi,%rdi
  6f374b:	74 22                	je     6f376f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x232f>
  6f374d:	4a 8d 04 f8          	lea    (%rax,%r15,8),%rax
  6f3751:	48 8b 30             	mov    (%rax),%rsi
  6f3754:	ff 15 b6 82 39 00    	call   *0x3982b6(%rip)        # a8ba10 <_DYNAMIC+0x5b8>
  6f375a:	f3 0f 11 84 24 e8 00 	movss  %xmm0,0xe8(%rsp)
  6f3761:	00 00 
  6f3763:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
  6f3768:	49 8b b0 a0 02 00 00 	mov    0x2a0(%r8),%rsi
  6f376f:	48 39 74 24 30       	cmp    %rsi,0x30(%rsp)
  6f3774:	0f 83 cc 2d 00 00    	jae    6f6546 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5106>
  6f377a:	4d 8b a0 98 02 00 00 	mov    0x298(%r8),%r12
  6f3781:	43 8b 4c fc 08       	mov    0x8(%r12,%r15,8),%ecx
  6f3786:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  6f378b:	48 39 c1             	cmp    %rax,%rcx
  6f378e:	0f 84 16 01 00 00    	je     6f38aa <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x246a>
  6f3794:	48 8b 84 24 08 02 00 	mov    0x208(%rsp),%rax
  6f379b:	00 
  6f379c:	48 39 c8             	cmp    %rcx,%rax
  6f379f:	0f 86 e2 2d 00 00    	jbe    6f6587 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5147>
  6f37a5:	48 6b c1 38          	imul   $0x38,%rcx,%rax
  6f37a9:	48 8b 8c 24 00 02 00 	mov    0x200(%rsp),%rcx
  6f37b0:	00 
  6f37b1:	0f 10 04 01          	movups (%rcx,%rax,1),%xmm0
  6f37b5:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  6f37ba:	0f 10 44 01 10       	movups 0x10(%rcx,%rax,1),%xmm0
  6f37bf:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
  6f37c6:	00 
  6f37c7:	0f 10 44 01 20       	movups 0x20(%rcx,%rax,1),%xmm0
  6f37cc:	0f 29 84 24 d0 03 00 	movaps %xmm0,0x3d0(%rsp)
  6f37d3:	00 
  6f37d4:	0f b6 6c 01 30       	movzbl 0x30(%rcx,%rax,1),%ebp
  6f37d9:	8b 54 01 31          	mov    0x31(%rcx,%rax,1),%edx
  6f37dd:	89 94 24 80 00 00 00 	mov    %edx,0x80(%rsp)
  6f37e4:	8b 44 01 34          	mov    0x34(%rcx,%rax,1),%eax
  6f37e8:	89 84 24 83 00 00 00 	mov    %eax,0x83(%rsp)
  6f37ef:	83 fb ff             	cmp    $0xffffffff,%ebx
  6f37f2:	0f 84 32 2b 00 00    	je     6f632a <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4eea>
  6f37f8:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
  6f37ff:	00 
  6f3800:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
  6f3807:	00 
  6f3808:	48 8b 94 24 a0 07 00 	mov    0x7a0(%rsp),%rdx
  6f380f:	00 
  6f3810:	ff 15 02 82 39 00    	call   *0x398202(%rip)        # a8ba18 <_DYNAMIC+0x5c0>
  6f3816:	80 bc 24 a0 00 00 00 	cmpb   $0x0,0xa0(%rsp)
  6f381d:	00 
  6f381e:	0f 84 ba 00 00 00    	je     6f38de <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x249e>
  6f3824:	f3 0f 7e 84 24 a8 00 	movq   0xa8(%rsp),%xmm0
  6f382b:	00 00 
  6f382d:	f3 0f 7e 8c 24 b0 00 	movq   0xb0(%rsp),%xmm1
  6f3834:	00 00 
  6f3836:	66 48 0f 7e c0       	movq   %xmm0,%rax
  6f383b:	66 48 0f 7e c9       	movq   %xmm1,%rcx
  6f3840:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
  6f3847:	ff ff 7f 
  6f384a:	48 21 d0             	and    %rdx,%rax
  6f384d:	48 be ff ff ff ff ff 	movabs $0x7fefffffffffffff,%rsi
  6f3854:	ff ef 7f 
  6f3857:	48 39 f0             	cmp    %rsi,%rax
  6f385a:	0f 9f c0             	setg   %al
  6f385d:	48 21 d1             	and    %rdx,%rcx
  6f3860:	48 39 f1             	cmp    %rsi,%rcx
  6f3863:	0f 9f c1             	setg   %cl
  6f3866:	08 c1                	or     %al,%cl
  6f3868:	40 08 e9             	or     %bpl,%cl
  6f386b:	80 e1 01             	and    $0x1,%cl
  6f386e:	66 0f 6c c9          	punpcklqdq %xmm1,%xmm1
  6f3872:	66 0f ef 0d f6 3c 96 	pxor   -0x69c30a(%rip),%xmm1        # 57570 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0xf50>
  6f3879:	ff 
  6f387a:	66 0f 28 9c 24 00 01 	movapd 0x100(%rsp),%xmm3
  6f3881:	00 00 
  6f3883:	66 0f 59 cb          	mulpd  %xmm3,%xmm1
  6f3887:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
  6f388b:	66 0f 28 54 24 60    	movapd 0x60(%rsp),%xmm2
  6f3891:	66 0f 59 c2          	mulpd  %xmm2,%xmm0
  6f3895:	66 0f 5c c8          	subpd  %xmm0,%xmm1
  6f3899:	66 0f 28 84 24 d0 03 	movapd 0x3d0(%rsp),%xmm0
  6f38a0:	00 00 
  6f38a2:	66 0f 58 c1          	addpd  %xmm1,%xmm0
  6f38a6:	89 cd                	mov    %ecx,%ebp
  6f38a8:	eb 67                	jmp    6f3911 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x24d1>
  6f38aa:	f2 0f 10 84 24 88 07 	movsd  0x788(%rsp),%xmm0
  6f38b1:	00 00 
  6f38b3:	f2 0f 11 84 24 70 03 	movsd  %xmm0,0x370(%rsp)
  6f38ba:	00 00 
  6f38bc:	48 8d 84 24 a1 03 00 	lea    0x3a1(%rsp),%rax
  6f38c3:	00 
  6f38c4:	0f 57 c9             	xorps  %xmm1,%xmm1
  6f38c7:	0f 11 48 d7          	movups %xmm1,-0x29(%rax)
  6f38cb:	f2 0f 11 84 24 88 03 	movsd  %xmm0,0x388(%rsp)
  6f38d2:	00 00 
  6f38d4:	0f 29 48 ef          	movaps %xmm1,-0x11(%rax)
  6f38d8:	c6 40 ff 00          	movb   $0x0,-0x1(%rax)
  6f38dc:	eb 56                	jmp    6f3934 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x24f4>
  6f38de:	8b 84 24 80 00 00 00 	mov    0x80(%rsp),%eax
  6f38e5:	8b 8c 24 83 00 00 00 	mov    0x83(%rsp),%ecx
  6f38ec:	48 8d 94 24 a1 03 00 	lea    0x3a1(%rsp),%rdx
  6f38f3:	00 
  6f38f4:	89 4a 03             	mov    %ecx,0x3(%rdx)
  6f38f7:	89 02                	mov    %eax,(%rdx)
  6f38f9:	66 0f 28 54 24 60    	movapd 0x60(%rsp),%xmm2
  6f38ff:	66 0f 28 9c 24 00 01 	movapd 0x100(%rsp),%xmm3
  6f3906:	00 00 
  6f3908:	66 0f 28 84 24 d0 03 	movapd 0x3d0(%rsp),%xmm0
  6f390f:	00 00 
  6f3911:	66 0f 29 94 24 70 03 	movapd %xmm2,0x370(%rsp)
  6f3918:	00 00 
  6f391a:	66 0f 29 9c 24 80 03 	movapd %xmm3,0x380(%rsp)
  6f3921:	00 00 
  6f3923:	66 0f 29 84 24 90 03 	movapd %xmm0,0x390(%rsp)
  6f392a:	00 00 
  6f392c:	40 88 ac 24 a0 03 00 	mov    %bpl,0x3a0(%rsp)
  6f3933:	00 
  6f3934:	0f 28 05 45 3f 96 ff 	movaps -0x69c0bb(%rip),%xmm0        # 57880 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x1260>
  6f393b:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  6f3942:	00 
  6f3943:	0f 28 84 24 90 08 00 	movaps 0x890(%rsp),%xmm0
  6f394a:	00 
  6f394b:	0f 13 84 24 90 00 00 	movlps %xmm0,0x90(%rsp)
  6f3952:	00 
  6f3953:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
  6f395a:	00 
  6f395b:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
  6f3962:	00 
  6f3963:	48 8d 94 24 80 00 00 	lea    0x80(%rsp),%rdx
  6f396a:	00 
  6f396b:	ff 15 af 80 39 00    	call   *0x3980af(%rip)        # a8ba20 <_DYNAMIC+0x5c8>
  6f3971:	48 8d bc 24 f8 08 00 	lea    0x8f8(%rsp),%rdi
  6f3978:	00 
  6f3979:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
  6f3980:	00 
  6f3981:	48 8d 94 24 ac 04 00 	lea    0x4ac(%rsp),%rdx
  6f3988:	00 
  6f3989:	ff 15 91 80 39 00    	call   *0x398091(%rip)        # a8ba20 <_DYNAMIC+0x5c8>
  6f398f:	48 8b 9c 24 08 02 00 	mov    0x208(%rsp),%rbx
  6f3996:	00 
  6f3997:	48 3b 9c 24 f8 01 00 	cmp    0x1f8(%rsp),%rbx
  6f399e:	00 
  6f399f:	75 0d                	jne    6f39ae <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x256e>
  6f39a1:	48 8d bc 24 f8 01 00 	lea    0x1f8(%rsp),%rdi
  6f39a8:	00 
  6f39a9:	e8 02 d2 02 00       	call   720bb0 <<alloc::raw_vec::RawVec<gpui_reactivity_core::geometry::CoordinateSpace>>::grow_one>
  6f39ae:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
  6f39b5:	00 
  6f39b6:	48 6b cb 38          	imul   $0x38,%rbx,%rcx
  6f39ba:	48 8b 94 24 28 09 00 	mov    0x928(%rsp),%rdx
  6f39c1:	00 
  6f39c2:	48 89 54 08 30       	mov    %rdx,0x30(%rax,%rcx,1)
  6f39c7:	0f 10 84 24 f8 08 00 	movups 0x8f8(%rsp),%xmm0
  6f39ce:	00 
  6f39cf:	0f 10 8c 24 08 09 00 	movups 0x908(%rsp),%xmm1
  6f39d6:	00 
  6f39d7:	0f 10 94 24 18 09 00 	movups 0x918(%rsp),%xmm2
  6f39de:	00 
  6f39df:	0f 11 54 08 20       	movups %xmm2,0x20(%rax,%rcx,1)
  6f39e4:	0f 11 4c 08 10       	movups %xmm1,0x10(%rax,%rcx,1)
  6f39e9:	0f 11 04 08          	movups %xmm0,(%rax,%rcx,1)
  6f39ed:	48 ff c3             	inc    %rbx
  6f39f0:	48 89 9c 24 08 02 00 	mov    %rbx,0x208(%rsp)
  6f39f7:	00 
  6f39f8:	0f 10 84 24 f8 08 00 	movups 0x8f8(%rsp),%xmm0
  6f39ff:	00 
  6f3a00:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
  6f3a07:	00 
  6f3a08:	0f 10 84 24 08 09 00 	movups 0x908(%rsp),%xmm0
  6f3a0f:	00 
  6f3a10:	0f 29 84 24 d0 03 00 	movaps %xmm0,0x3d0(%rsp)
  6f3a17:	00 
  6f3a18:	0f 10 84 24 18 09 00 	movups 0x918(%rsp),%xmm0
  6f3a1f:	00 
  6f3a20:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  6f3a25:	48 8d bc 24 f8 08 00 	lea    0x8f8(%rsp),%rdi
  6f3a2c:	00 
  6f3a2d:	ff 15 f5 7f 39 00    	call   *0x397ff5(%rip)        # a8ba28 <_DYNAMIC+0x5d0>
  6f3a33:	31 db                	xor    %ebx,%ebx
  6f3a35:	84 c0                	test   %al,%al
  6f3a37:	0f 84 19 01 00 00    	je     6f3b56 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2716>
  6f3a3d:	66 0f 5a 84 24 d0 03 	cvtpd2ps 0x3d0(%rsp),%xmm0
  6f3a44:	00 00 
  6f3a46:	66 0f 5a 8c 24 00 01 	cvtpd2ps 0x100(%rsp),%xmm1
  6f3a4d:	00 00 
  6f3a4f:	66 0f 5a 54 24 60    	cvtpd2ps 0x60(%rsp),%xmm2
  6f3a55:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  6f3a59:	66 0f 7e c8          	movd   %xmm1,%eax
  6f3a5d:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
  6f3a62:	66 0f 28 c1          	movapd %xmm1,%xmm0
  6f3a66:	0f c6 c1 55          	shufps $0x55,%xmm1,%xmm0
  6f3a6a:	66 0f 7e c1          	movd   %xmm0,%ecx
  6f3a6e:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
  6f3a74:	81 f9 00 00 80 7f    	cmp    $0x7f800000,%ecx
  6f3a7a:	0f 9d c1             	setge  %cl
  6f3a7d:	66 0f 6f c1          	movdqa %xmm1,%xmm0
  6f3a81:	66 0f 6d c1          	punpckhqdq %xmm1,%xmm0
  6f3a85:	66 0f 7e c2          	movd   %xmm0,%edx
  6f3a89:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
  6f3a8f:	81 fa 00 00 80 7f    	cmp    $0x7f800000,%edx
  6f3a95:	0f 9d c2             	setge  %dl
  6f3a98:	0f 28 c1             	movaps %xmm1,%xmm0
  6f3a9b:	0f c6 c1 ff          	shufps $0xff,%xmm1,%xmm0
  6f3a9f:	66 0f 7e c6          	movd   %xmm0,%esi
  6f3aa3:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
  6f3aa9:	81 fe 00 00 80 7f    	cmp    $0x7f800000,%esi
  6f3aaf:	40 0f 9d c6          	setge  %sil
  6f3ab3:	66 0f 7e d7          	movd   %xmm2,%edi
  6f3ab7:	81 e7 ff ff ff 7f    	and    $0x7fffffff,%edi
  6f3abd:	81 ff 00 00 80 7f    	cmp    $0x7f800000,%edi
  6f3ac3:	40 0f 9d c7          	setge  %dil
  6f3ac7:	66 0f 28 c2          	movapd %xmm2,%xmm0
  6f3acb:	0f c6 c2 55          	shufps $0x55,%xmm2,%xmm0
  6f3acf:	66 41 0f 7e c0       	movd   %xmm0,%r8d
  6f3ad4:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
  6f3adb:	41 81 f8 00 00 80 7f 	cmp    $0x7f800000,%r8d
  6f3ae2:	41 0f 9c c0          	setl   %r8b
  6f3ae6:	3d ff ff 7f 7f       	cmp    $0x7f7fffff,%eax
  6f3aeb:	7f 69                	jg     6f3b56 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2716>
  6f3aed:	84 c9                	test   %cl,%cl
  6f3aef:	75 65                	jne    6f3b56 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2716>
  6f3af1:	84 d2                	test   %dl,%dl
  6f3af3:	75 61                	jne    6f3b56 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2716>
  6f3af5:	40 84 f6             	test   %sil,%sil
  6f3af8:	75 5c                	jne    6f3b56 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2716>
  6f3afa:	40 84 ff             	test   %dil,%dil
  6f3afd:	75 57                	jne    6f3b56 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2716>
  6f3aff:	45 84 c0             	test   %r8b,%r8b
  6f3b02:	74 52                	je     6f3b56 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2716>
  6f3b04:	0f 29 4c 24 60       	movaps %xmm1,0x60(%rsp)
  6f3b09:	0f 29 8c 24 a0 00 00 	movaps %xmm1,0xa0(%rsp)
  6f3b10:	00 
  6f3b11:	0f 29 94 24 00 01 00 	movaps %xmm2,0x100(%rsp)
  6f3b18:	00 
  6f3b19:	66 0f 13 94 24 b0 00 	movlpd %xmm2,0xb0(%rsp)
  6f3b20:	00 00 
  6f3b22:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
  6f3b29:	00 
  6f3b2a:	ff 15 00 7f 39 00    	call   *0x397f00(%rip)        # a8ba30 <_DYNAMIC+0x5d8>
  6f3b30:	84 c0                	test   %al,%al
  6f3b32:	74 22                	je     6f3b56 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2716>
  6f3b34:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  6f3b39:	0f 11 84 24 e8 02 00 	movups %xmm0,0x2e8(%rsp)
  6f3b40:	00 
  6f3b41:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
  6f3b48:	00 
  6f3b49:	0f 13 84 24 f8 02 00 	movlps %xmm0,0x2f8(%rsp)
  6f3b50:	00 
  6f3b51:	bb 01 00 00 00       	mov    $0x1,%ebx
  6f3b56:	4f 8d 3c fc          	lea    (%r12,%r15,8),%r15
  6f3b5a:	89 9c 24 e4 02 00 00 	mov    %ebx,0x2e4(%rsp)
  6f3b61:	0f 57 c0             	xorps  %xmm0,%xmm0
  6f3b64:	66 0f 14 84 24 a0 02 	unpcklpd 0x2a0(%rsp),%xmm0
  6f3b6b:	00 00 
  6f3b6d:	0f 11 84 24 30 03 00 	movups %xmm0,0x330(%rsp)
  6f3b74:	00 
  6f3b75:	80 7c 24 2f 00       	cmpb   $0x0,0x2f(%rsp)
  6f3b7a:	74 6a                	je     6f3be6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x27a6>
  6f3b7c:	41 8b 4f 08          	mov    0x8(%r15),%ecx
  6f3b80:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  6f3b85:	48 39 c1             	cmp    %rax,%rcx
  6f3b88:	0f 84 84 00 00 00    	je     6f3c12 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x27d2>
  6f3b8e:	48 8b 84 24 30 02 00 	mov    0x230(%rsp),%rax
  6f3b95:	00 
  6f3b96:	48 39 c8             	cmp    %rcx,%rax
  6f3b99:	0f 86 0b 2a 00 00    	jbe    6f65aa <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x516a>
  6f3b9f:	48 8b 84 24 28 02 00 	mov    0x228(%rsp),%rax
  6f3ba6:	00 
  6f3ba7:	48 89 ca             	mov    %rcx,%rdx
  6f3baa:	48 c1 e2 04          	shl    $0x4,%rdx
  6f3bae:	0f 10 0c 10          	movups (%rax,%rdx,1),%xmm1
  6f3bb2:	0f 57 c0             	xorps  %xmm0,%xmm0
  6f3bb5:	66 0f 14 84 24 20 01 	unpcklpd 0x120(%rsp),%xmm0
  6f3bbc:	00 00 
  6f3bbe:	0f 11 84 24 a0 00 00 	movups %xmm0,0xa0(%rsp)
  6f3bc5:	00 
  6f3bc6:	48 8b 84 24 48 02 00 	mov    0x248(%rsp),%rax
  6f3bcd:	00 
  6f3bce:	48 39 c8             	cmp    %rcx,%rax
  6f3bd1:	0f 86 e1 29 00 00    	jbe    6f65b8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5178>
  6f3bd7:	0f 29 4c 24 60       	movaps %xmm1,0x60(%rsp)
  6f3bdc:	48 03 94 24 40 02 00 	add    0x240(%rsp),%rdx
  6f3be3:	00 
  6f3be4:	eb 55                	jmp    6f3c3b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x27fb>
  6f3be6:	0f 57 c0             	xorps  %xmm0,%xmm0
  6f3be9:	66 0f 14 84 24 20 01 	unpcklpd 0x120(%rsp),%xmm0
  6f3bf0:	00 00 
  6f3bf2:	0f 11 84 24 70 02 00 	movups %xmm0,0x270(%rsp)
  6f3bf9:	00 
  6f3bfa:	c7 84 24 00 01 00 00 	movl   $0x0,0x100(%rsp)
  6f3c01:	00 00 00 00 
  6f3c05:	0f 28 84 24 50 08 00 	movaps 0x850(%rsp),%xmm0
  6f3c0c:	00 
  6f3c0d:	e9 97 00 00 00       	jmp    6f3ca9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2869>
  6f3c12:	0f 57 c0             	xorps  %xmm0,%xmm0
  6f3c15:	66 0f 14 84 24 20 01 	unpcklpd 0x120(%rsp),%xmm0
  6f3c1c:	00 00 
  6f3c1e:	0f 11 84 24 a0 00 00 	movups %xmm0,0xa0(%rsp)
  6f3c25:	00 
  6f3c26:	48 8d 94 24 a0 00 00 	lea    0xa0(%rsp),%rdx
  6f3c2d:	00 
  6f3c2e:	0f 28 84 24 50 08 00 	movaps 0x850(%rsp),%xmm0
  6f3c35:	00 
  6f3c36:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  6f3c3b:	0f 10 02             	movups (%rdx),%xmm0
  6f3c3e:	0f 29 84 24 70 02 00 	movaps %xmm0,0x270(%rsp)
  6f3c45:	00 
  6f3c46:	41 8b 7f 10          	mov    0x10(%r15),%edi
  6f3c4a:	e8 41 b8 ff ff       	call   6ef490 <<gpui::runtime::Node>::kind>
  6f3c4f:	b1 01                	mov    $0x1,%cl
  6f3c51:	89 8c 24 00 01 00 00 	mov    %ecx,0x100(%rsp)
  6f3c58:	3c 07                	cmp    $0x7,%al
  6f3c5a:	75 07                	jne    6f3c63 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2823>
  6f3c5c:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  6f3c61:	eb 46                	jmp    6f3ca9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2869>
  6f3c63:	41 8b 4f 08          	mov    0x8(%r15),%ecx
  6f3c67:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  6f3c6c:	48 39 c1             	cmp    %rax,%rcx
  6f3c6f:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  6f3c74:	74 28                	je     6f3c9e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x285e>
  6f3c76:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  6f3c7d:	00 
  6f3c7e:	48 39 c8             	cmp    %rcx,%rax
  6f3c81:	0f 86 86 29 00 00    	jbe    6f660d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51cd>
  6f3c87:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  6f3c8e:	00 
  6f3c8f:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
  6f3c93:	24 01                	and    $0x1,%al
  6f3c95:	89 84 24 00 01 00 00 	mov    %eax,0x100(%rsp)
  6f3c9c:	eb 0b                	jmp    6f3ca9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2869>
  6f3c9e:	c7 84 24 00 01 00 00 	movl   $0x0,0x100(%rsp)
  6f3ca5:	00 00 00 00 
  6f3ca9:	0f 29 84 24 90 01 00 	movaps %xmm0,0x190(%rsp)
  6f3cb0:	00 
  6f3cb1:	41 8b 47 10          	mov    0x10(%r15),%eax
  6f3cb5:	83 e0 0f             	and    $0xf,%eax
  6f3cb8:	83 f8 07             	cmp    $0x7,%eax
  6f3cbb:	72 0c                	jb     6f3cc9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2889>
  6f3cbd:	8d 48 f8             	lea    -0x8(%rax),%ecx
  6f3cc0:	83 f9 02             	cmp    $0x2,%ecx
  6f3cc3:	0f 83 4b 09 00 00    	jae    6f4614 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x31d4>
  6f3cc9:	41 8b 4f 08          	mov    0x8(%r15),%ecx
  6f3ccd:	45 31 ed             	xor    %r13d,%r13d
  6f3cd0:	ba ff ff ff ff       	mov    $0xffffffff,%edx
  6f3cd5:	48 39 d1             	cmp    %rdx,%rcx
  6f3cd8:	74 1e                	je     6f3cf8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x28b8>
  6f3cda:	48 39 8c 24 88 01 00 	cmp    %rcx,0x188(%rsp)
  6f3ce1:	00 
  6f3ce2:	76 14                	jbe    6f3cf8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x28b8>
  6f3ce4:	48 8b 94 24 80 01 00 	mov    0x180(%rsp),%rdx
  6f3ceb:	00 
  6f3cec:	44 0f b6 2c 0a       	movzbl (%rdx,%rcx,1),%r13d
  6f3cf1:	41 80 e5 02          	and    $0x2,%r13b
  6f3cf5:	41 d0 ed             	shr    $1,%r13b
  6f3cf8:	80 7c 24 2f 00       	cmpb   $0x0,0x2f(%rsp)
  6f3cfd:	74 4d                	je     6f3d4c <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x290c>
  6f3cff:	4c 8b b4 24 88 01 00 	mov    0x188(%rsp),%r14
  6f3d06:	00 
  6f3d07:	4c 3b b4 24 78 01 00 	cmp    0x178(%rsp),%r14
  6f3d0e:	00 
  6f3d0f:	75 0e                	jne    6f3d1f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x28df>
  6f3d11:	48 8d bc 24 78 01 00 	lea    0x178(%rsp),%rdi
  6f3d18:	00 
  6f3d19:	ff 15 19 7d 39 00    	call   *0x397d19(%rip)        # a8ba38 <_DYNAMIC+0x5e0>
  6f3d1f:	42 8d 04 6d 00 00 00 	lea    0x0(,%r13,2),%eax
  6f3d26:	00 
  6f3d27:	02 84 24 00 01 00 00 	add    0x100(%rsp),%al
  6f3d2e:	48 8b 8c 24 80 01 00 	mov    0x180(%rsp),%rcx
  6f3d35:	00 
  6f3d36:	42 88 04 31          	mov    %al,(%rcx,%r14,1)
  6f3d3a:	49 ff c6             	inc    %r14
  6f3d3d:	4c 89 b4 24 88 01 00 	mov    %r14,0x188(%rsp)
  6f3d44:	00 
  6f3d45:	41 8b 47 10          	mov    0x10(%r15),%eax
  6f3d49:	83 e0 0f             	and    $0xf,%eax
  6f3d4c:	83 f8 09             	cmp    $0x9,%eax
  6f3d4f:	0f 87 c5 26 00 00    	ja     6f641a <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4fda>
  6f3d55:	b9 4f 03 00 00       	mov    $0x34f,%ecx
  6f3d5a:	0f a3 c1             	bt     %eax,%ecx
  6f3d5d:	0f 82 83 00 00 00    	jb     6f3de6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x29a6>
  6f3d63:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
  6f3d6a:	00 
  6f3d6b:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  6f3d72:	00 
  6f3d73:	0f 10 84 24 30 03 00 	movups 0x330(%rsp),%xmm0
  6f3d7a:	00 
  6f3d7b:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  6f3d82:	00 
  6f3d83:	48 8d bc 24 10 08 00 	lea    0x810(%rsp),%rdi
  6f3d8a:	00 
  6f3d8b:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6f3d92:	00 
  6f3d93:	48 8d 94 24 70 02 00 	lea    0x270(%rsp),%rdx
  6f3d9a:	00 
  6f3d9b:	48 8d 8c 24 e4 02 00 	lea    0x2e4(%rsp),%rcx
  6f3da2:	00 
  6f3da3:	4c 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%r8
  6f3daa:	00 
  6f3dab:	4c 8b 8c 24 00 03 00 	mov    0x300(%rsp),%r9
  6f3db2:	00 
  6f3db3:	ff 15 87 7c 39 00    	call   *0x397c87(%rip)        # a8ba40 <_DYNAMIC+0x5e8>
  6f3db9:	83 bc 24 10 08 00 00 	cmpl   $0xfffffffe,0x810(%rsp)
  6f3dc0:	fe 
  6f3dc1:	0f 85 8f 21 00 00    	jne    6f5f56 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4b16>
  6f3dc7:	48 8d 84 24 18 08 00 	lea    0x818(%rsp),%rax
  6f3dce:	00 
  6f3dcf:	0f 10 00             	movups (%rax),%xmm0
  6f3dd2:	0f 29 84 24 90 01 00 	movaps %xmm0,0x190(%rsp)
  6f3dd9:	00 
  6f3dda:	0f 10 40 10          	movups 0x10(%rax),%xmm0
  6f3dde:	0f 29 84 24 70 02 00 	movaps %xmm0,0x270(%rsp)
  6f3de5:	00 
  6f3de6:	80 7c 24 2f 00       	cmpb   $0x0,0x2f(%rsp)
  6f3deb:	0f 84 9a 00 00 00    	je     6f3e8b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2a4b>
  6f3df1:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
  6f3df8:	00 
  6f3df9:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  6f3e00:	00 
  6f3e01:	4c 8b b4 24 30 02 00 	mov    0x230(%rsp),%r14
  6f3e08:	00 
  6f3e09:	4c 3b b4 24 20 02 00 	cmp    0x220(%rsp),%r14
  6f3e10:	00 
  6f3e11:	75 0d                	jne    6f3e20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x29e0>
  6f3e13:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
  6f3e1a:	00 
  6f3e1b:	e8 00 ce 02 00       	call   720c20 <<alloc::raw_vec::RawVec<gpui_reactivity_core::geometry::Rect>>::grow_one>
  6f3e20:	48 8b 84 24 28 02 00 	mov    0x228(%rsp),%rax
  6f3e27:	00 
  6f3e28:	4c 89 f1             	mov    %r14,%rcx
  6f3e2b:	48 c1 e1 04          	shl    $0x4,%rcx
  6f3e2f:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
  6f3e36:	00 
  6f3e37:	0f 11 04 08          	movups %xmm0,(%rax,%rcx,1)
  6f3e3b:	49 ff c6             	inc    %r14
  6f3e3e:	4c 89 b4 24 30 02 00 	mov    %r14,0x230(%rsp)
  6f3e45:	00 
  6f3e46:	4c 8b b4 24 48 02 00 	mov    0x248(%rsp),%r14
  6f3e4d:	00 
  6f3e4e:	4c 3b b4 24 38 02 00 	cmp    0x238(%rsp),%r14
  6f3e55:	00 
  6f3e56:	75 0d                	jne    6f3e65 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2a25>
  6f3e58:	48 8d bc 24 38 02 00 	lea    0x238(%rsp),%rdi
  6f3e5f:	00 
  6f3e60:	e8 bb cd 02 00       	call   720c20 <<alloc::raw_vec::RawVec<gpui_reactivity_core::geometry::Rect>>::grow_one>
  6f3e65:	48 8b 84 24 40 02 00 	mov    0x240(%rsp),%rax
  6f3e6c:	00 
  6f3e6d:	4c 89 f1             	mov    %r14,%rcx
  6f3e70:	48 c1 e1 04          	shl    $0x4,%rcx
  6f3e74:	0f 28 84 24 70 02 00 	movaps 0x270(%rsp),%xmm0
  6f3e7b:	00 
  6f3e7c:	0f 11 04 08          	movups %xmm0,(%rax,%rcx,1)
  6f3e80:	49 ff c6             	inc    %r14
  6f3e83:	4c 89 b4 24 48 02 00 	mov    %r14,0x248(%rsp)
  6f3e8a:	00 
  6f3e8b:	85 db                	test   %ebx,%ebx
  6f3e8d:	74 34                	je     6f3ec3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2a83>
  6f3e8f:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
  6f3e96:	00 
  6f3e97:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
  6f3e9e:	00 
  6f3e9f:	48 8d 94 24 e8 02 00 	lea    0x2e8(%rsp),%rdx
  6f3ea6:	00 
  6f3ea7:	e8 24 43 ff ff       	call   6e81d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner::{closure#24}>
  6f3eac:	83 bc 24 a0 00 00 00 	cmpl   $0x1,0xa0(%rsp)
  6f3eb3:	01 
  6f3eb4:	75 0d                	jne    6f3ec3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2a83>
  6f3eb6:	48 8d 84 24 a4 00 00 	lea    0xa4(%rsp),%rax
  6f3ebd:	00 
  6f3ebe:	0f 10 00             	movups (%rax),%xmm0
  6f3ec1:	eb 03                	jmp    6f3ec6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2a86>
  6f3ec3:	0f 57 c0             	xorps  %xmm0,%xmm0
  6f3ec6:	0f 29 84 24 f0 03 00 	movaps %xmm0,0x3f0(%rsp)
  6f3ecd:	00 
  6f3ece:	8b 84 24 00 01 00 00 	mov    0x100(%rsp),%eax
  6f3ed5:	44 08 e8             	or     %r13b,%al
  6f3ed8:	3c 01                	cmp    $0x1,%al
  6f3eda:	74 0d                	je     6f3ee9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2aa9>
  6f3edc:	41 8b 7f 10          	mov    0x10(%r15),%edi
  6f3ee0:	e8 ab b5 ff ff       	call   6ef490 <<gpui::runtime::Node>::kind>
  6f3ee5:	3c 06                	cmp    $0x6,%al
  6f3ee7:	75 20                	jne    6f3f09 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2ac9>
  6f3ee9:	48 8d bc 24 b8 02 00 	lea    0x2b8(%rsp),%rdi
  6f3ef0:	00 
  6f3ef1:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
  6f3ef8:	00 
  6f3ef9:	48 8d 94 24 70 02 00 	lea    0x270(%rsp),%rdx
  6f3f00:	00 
  6f3f01:	ff 15 41 7b 39 00    	call   *0x397b41(%rip)        # a8ba48 <_DYNAMIC+0x5f0>
  6f3f07:	eb 6d                	jmp    6f3f76 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2b36>
  6f3f09:	f2 0f 10 84 24 f0 03 	movsd  0x3f0(%rsp),%xmm0
  6f3f10:	00 00 
  6f3f12:	f2 0f 10 8c 24 f8 03 	movsd  0x3f8(%rsp),%xmm1
  6f3f19:	00 00 
  6f3f1b:	0f 28 d0             	movaps %xmm0,%xmm2
  6f3f1e:	0f 58 c8             	addps  %xmm0,%xmm1
  6f3f21:	0f 57 e4             	xorps  %xmm4,%xmm4
  6f3f24:	0f 5f c4             	maxps  %xmm4,%xmm0
  6f3f27:	0f 28 d8             	movaps %xmm0,%xmm3
  6f3f2a:	0f c2 d8 03          	cmpunordps %xmm0,%xmm3
  6f3f2e:	0f 54 d3             	andps  %xmm3,%xmm2
  6f3f31:	0f 55 d8             	andnps %xmm0,%xmm3
  6f3f34:	0f 56 da             	orps   %xmm2,%xmm3
  6f3f37:	0f 28 c1             	movaps %xmm1,%xmm0
  6f3f3a:	0f 5d 84 24 20 01 00 	minps  0x120(%rsp),%xmm0
  6f3f41:	00 
  6f3f42:	0f 28 d0             	movaps %xmm0,%xmm2
  6f3f45:	0f c2 d0 03          	cmpunordps %xmm0,%xmm2
  6f3f49:	0f 54 ca             	andps  %xmm2,%xmm1
  6f3f4c:	0f 55 d0             	andnps %xmm0,%xmm2
  6f3f4f:	0f 56 d1             	orps   %xmm1,%xmm2
  6f3f52:	0f 5c d3             	subps  %xmm3,%xmm2
  6f3f55:	0f 28 c2             	movaps %xmm2,%xmm0
  6f3f58:	0f 5f c4             	maxps  %xmm4,%xmm0
  6f3f5b:	0f 28 c8             	movaps %xmm0,%xmm1
  6f3f5e:	0f c2 c8 03          	cmpunordps %xmm0,%xmm1
  6f3f62:	0f 54 d1             	andps  %xmm1,%xmm2
  6f3f65:	0f 55 c8             	andnps %xmm0,%xmm1
  6f3f68:	0f 56 ca             	orps   %xmm2,%xmm1
  6f3f6b:	0f 16 d9             	movlhps %xmm1,%xmm3
  6f3f6e:	0f 11 9c 24 b8 02 00 	movups %xmm3,0x2b8(%rsp)
  6f3f75:	00 
  6f3f76:	45 84 ed             	test   %r13b,%r13b
  6f3f79:	74 2d                	je     6f3fa8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2b68>
  6f3f7b:	f3 0f 10 84 24 c0 02 	movss  0x2c0(%rsp),%xmm0
  6f3f82:	00 00 
  6f3f84:	31 ed                	xor    %ebp,%ebp
  6f3f86:	0f 57 c9             	xorps  %xmm1,%xmm1
  6f3f89:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6f3f8c:	75 06                	jne    6f3f94 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2b54>
  6f3f8e:	0f 8b 82 02 00 00    	jnp    6f4216 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2dd6>
  6f3f94:	f3 0f 10 84 24 c4 02 	movss  0x2c4(%rsp),%xmm0
  6f3f9b:	00 00 
  6f3f9d:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6f3fa0:	75 06                	jne    6f3fa8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2b68>
  6f3fa2:	0f 8b 6e 02 00 00    	jnp    6f4216 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2dd6>
  6f3fa8:	8b 84 24 a8 04 00 00 	mov    0x4a8(%rsp),%eax
  6f3faf:	b9 ff ff ff 3f       	mov    $0x3fffffff,%ecx
  6f3fb4:	21 c8                	and    %ecx,%eax
  6f3fb6:	3d 01 00 80 3f       	cmp    $0x3f800001,%eax
  6f3fbb:	b9 00 00 00 80       	mov    $0x80000000,%ecx
  6f3fc0:	0f 44 c1             	cmove  %ecx,%eax
  6f3fc3:	66 0f 6e c0          	movd   %eax,%xmm0
  6f3fc7:	0f 57 c9             	xorps  %xmm1,%xmm1
  6f3fca:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6f3fcd:	0f 86 e0 00 00 00    	jbe    6f40b3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2c73>
  6f3fd3:	c7 84 24 a8 00 00 00 	movl   $0x1,0xa8(%rsp)
  6f3fda:	01 00 00 00 
  6f3fde:	48 c7 84 24 a0 00 00 	movq   $0x23,0xa0(%rsp)
  6f3fe5:	00 23 00 00 00 
  6f3fea:	84 db                	test   %bl,%bl
  6f3fec:	0f 84 3f 1f 00 00    	je     6f5f31 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4af1>
  6f3ff2:	48 8d 9c 24 a0 00 00 	lea    0xa0(%rsp),%rbx
  6f3ff9:	00 
  6f3ffa:	48 89 df             	mov    %rbx,%rdi
  6f3ffd:	e8 ae 11 ff ff       	call   6e51b0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6f4002:	48 8d 84 24 e8 02 00 	lea    0x2e8(%rsp),%rax
  6f4009:	00 
  6f400a:	0f 10 00             	movups (%rax),%xmm0
  6f400d:	0f 29 84 24 c0 08 00 	movaps %xmm0,0x8c0(%rsp)
  6f4014:	00 
  6f4015:	48 8b 40 10          	mov    0x10(%rax),%rax
  6f4019:	48 89 84 24 d0 08 00 	mov    %rax,0x8d0(%rsp)
  6f4020:	00 
  6f4021:	48 89 df             	mov    %rbx,%rdi
  6f4024:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  6f4029:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  6f402e:	31 c9                	xor    %ecx,%ecx
  6f4030:	ff 15 1a 7a 39 00    	call   *0x397a1a(%rip)        # a8ba50 <_DYNAMIC+0x5f8>
  6f4036:	4c 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%r9
  6f403d:	00 
  6f403e:	4d 85 c9             	test   %r9,%r9
  6f4041:	0f 84 58 01 00 00    	je     6f419f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2d5f>
  6f4047:	0f 10 84 24 a0 00 00 	movups 0xa0(%rsp),%xmm0
  6f404e:	00 
  6f404f:	0f 29 84 24 40 01 00 	movaps %xmm0,0x140(%rsp)
  6f4056:	00 
  6f4057:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
  6f405e:	00 
  6f405f:	0f 29 84 24 50 02 00 	movaps %xmm0,0x250(%rsp)
  6f4066:	00 
  6f4067:	0f 10 84 24 30 03 00 	movups 0x330(%rsp),%xmm0
  6f406e:	00 
  6f406f:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  6f4076:	00 
  6f4077:	48 8d bc 24 30 09 00 	lea    0x930(%rsp),%rdi
  6f407e:	00 
  6f407f:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6f4086:	00 
  6f4087:	f3 0f 10 84 24 e8 00 	movss  0xe8(%rsp),%xmm0
  6f408e:	00 00 
  6f4090:	48 8d 94 24 c0 08 00 	lea    0x8c0(%rsp),%rdx
  6f4097:	00 
  6f4098:	48 8d 8c 24 50 02 00 	lea    0x250(%rsp),%rcx
  6f409f:	00 
  6f40a0:	4c 8d 84 24 40 01 00 	lea    0x140(%rsp),%r8
  6f40a7:	00 
  6f40a8:	ff 15 aa 79 39 00    	call   *0x3979aa(%rip)        # a8ba58 <_DYNAMIC+0x600>
  6f40ae:	e9 de 00 00 00       	jmp    6f4191 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2d51>
  6f40b3:	41 8b 7f 10          	mov    0x10(%r15),%edi
  6f40b7:	85 ff                	test   %edi,%edi
  6f40b9:	78 10                	js     6f40cb <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2c8b>
  6f40bb:	e8 d0 b3 ff ff       	call   6ef490 <<gpui::runtime::Node>::kind>
  6f40c0:	40 b5 01             	mov    $0x1,%bpl
  6f40c3:	3c 04                	cmp    $0x4,%al
  6f40c5:	0f 85 4b 01 00 00    	jne    6f4216 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2dd6>
  6f40cb:	c7 84 24 a8 00 00 00 	movl   $0x1,0xa8(%rsp)
  6f40d2:	01 00 00 00 
  6f40d6:	48 c7 84 24 a0 00 00 	movq   $0x23,0xa0(%rsp)
  6f40dd:	00 23 00 00 00 
  6f40e2:	84 db                	test   %bl,%bl
  6f40e4:	0f 84 6a 1f 00 00    	je     6f6054 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4c14>
  6f40ea:	48 8d 9c 24 a0 00 00 	lea    0xa0(%rsp),%rbx
  6f40f1:	00 
  6f40f2:	48 89 df             	mov    %rbx,%rdi
  6f40f5:	e8 b6 10 ff ff       	call   6e51b0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6f40fa:	48 8d 8c 24 e8 02 00 	lea    0x2e8(%rsp),%rcx
  6f4101:	00 
  6f4102:	0f 10 01             	movups (%rcx),%xmm0
  6f4105:	0f 29 84 24 50 02 00 	movaps %xmm0,0x250(%rsp)
  6f410c:	00 
  6f410d:	48 8b 41 10          	mov    0x10(%rcx),%rax
  6f4111:	48 89 84 24 60 02 00 	mov    %rax,0x260(%rsp)
  6f4118:	00 
  6f4119:	0f 10 01             	movups (%rcx),%xmm0
  6f411c:	0f 29 84 24 60 0b 00 	movaps %xmm0,0xb60(%rsp)
  6f4123:	00 
  6f4124:	48 8b 41 10          	mov    0x10(%rcx),%rax
  6f4128:	48 89 84 24 70 0b 00 	mov    %rax,0xb70(%rsp)
  6f412f:	00 
  6f4130:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
  6f4137:	00 
  6f4138:	0f 29 84 24 40 01 00 	movaps %xmm0,0x140(%rsp)
  6f413f:	00 
  6f4140:	0f 10 84 24 30 03 00 	movups 0x330(%rsp),%xmm0
  6f4147:	00 
  6f4148:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  6f414f:	00 
  6f4150:	0f 10 05 b9 35 96 ff 	movups -0x69ca47(%rip),%xmm0        # 57710 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x10f0>
  6f4157:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  6f415e:	00 
  6f415f:	48 8d bc 24 30 09 00 	lea    0x930(%rsp),%rdi
  6f4166:	00 
  6f4167:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6f416e:	00 
  6f416f:	f3 0f 10 84 24 e8 00 	movss  0xe8(%rsp),%xmm0
  6f4176:	00 00 
  6f4178:	48 8d 94 24 60 0b 00 	lea    0xb60(%rsp),%rdx
  6f417f:	00 
  6f4180:	48 8d 8c 24 40 01 00 	lea    0x140(%rsp),%rcx
  6f4187:	00 
  6f4188:	49 89 d8             	mov    %rbx,%r8
  6f418b:	ff 15 cf 78 39 00    	call   *0x3978cf(%rip)        # a8ba60 <_DYNAMIC+0x608>
  6f4191:	83 f8 ff             	cmp    $0xffffffff,%eax
  6f4194:	0f 85 12 1d 00 00    	jne    6f5eac <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4a6c>
  6f419a:	40 b5 01             	mov    $0x1,%bpl
  6f419d:	eb 77                	jmp    6f4216 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2dd6>
  6f419f:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
  6f41a6:	00 
  6f41a7:	0f 29 84 24 50 02 00 	movaps %xmm0,0x250(%rsp)
  6f41ae:	00 
  6f41af:	48 8d 84 24 ac 04 00 	lea    0x4ac(%rsp),%rax
  6f41b6:	00 
  6f41b7:	0f 10 40 f0          	movups -0x10(%rax),%xmm0
  6f41bb:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  6f41c2:	00 
  6f41c3:	0f 10 84 24 30 03 00 	movups 0x330(%rsp),%xmm0
  6f41ca:	00 
  6f41cb:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  6f41d2:	00 
  6f41d3:	48 8d bc 24 30 09 00 	lea    0x930(%rsp),%rdi
  6f41da:	00 
  6f41db:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
  6f41e2:	00 
  6f41e3:	f3 0f 10 84 24 e8 00 	movss  0xe8(%rsp),%xmm0
  6f41ea:	00 00 
  6f41ec:	48 8d 94 24 c0 08 00 	lea    0x8c0(%rsp),%rdx
  6f41f3:	00 
  6f41f4:	48 8d 8c 24 50 02 00 	lea    0x250(%rsp),%rcx
  6f41fb:	00 
  6f41fc:	4c 8d 84 24 80 00 00 	lea    0x80(%rsp),%r8
  6f4203:	00 
  6f4204:	ff 15 56 78 39 00    	call   *0x397856(%rip)        # a8ba60 <_DYNAMIC+0x608>
  6f420a:	40 b5 01             	mov    $0x1,%bpl
  6f420d:	83 f8 ff             	cmp    $0xffffffff,%eax
  6f4210:	0f 85 96 1c 00 00    	jne    6f5eac <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4a6c>
  6f4216:	41 8b 7f 10          	mov    0x10(%r15),%edi
  6f421a:	e8 a1 b2 ff ff       	call   6ef4c0 <<gpui::runtime::Node>::text_slot>
  6f421f:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  6f4224:	48 8b b1 b0 02 00 00 	mov    0x2b0(%rcx),%rsi
  6f422b:	48 8b 91 b8 02 00 00 	mov    0x2b8(%rcx),%rdx
  6f4232:	89 c7                	mov    %eax,%edi
  6f4234:	e8 07 b2 ff ff       	call   6ef440 <<gpui::runtime::TextSlot>::get_mut>
  6f4239:	48 85 c0             	test   %rax,%rax
  6f423c:	4c 89 7c 24 60       	mov    %r15,0x60(%rsp)
  6f4241:	0f 84 bc 03 00 00    	je     6f4603 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x31c3>
  6f4247:	48 8d 8c 24 ac 04 00 	lea    0x4ac(%rsp),%rcx
  6f424e:	00 
  6f424f:	0f 10 41 e0          	movups -0x20(%rcx),%xmm0
  6f4253:	0f 29 84 24 b0 08 00 	movaps %xmm0,0x8b0(%rsp)
  6f425a:	00 
  6f425b:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  6f4260:	48 8b 99 c8 06 00 00 	mov    0x6c8(%rcx),%rbx
  6f4267:	be 1e 00 00 00       	mov    $0x1e,%esi
  6f426c:	48 85 db             	test   %rbx,%rbx
  6f426f:	0f 84 9d 20 00 00    	je     6f6312 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4ed2>
  6f4275:	48 83 7b 30 00       	cmpq   $0x0,0x30(%rbx)
  6f427a:	48 8b 8c 24 90 07 00 	mov    0x790(%rsp),%rcx
  6f4281:	00 
  6f4282:	0f 84 8a 20 00 00    	je     6f6312 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4ed2>
  6f4288:	41 b4 02             	mov    $0x2,%r12b
  6f428b:	80 7c 24 70 02       	cmpb   $0x2,0x70(%rsp)
  6f4290:	74 49                	je     6f42db <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2e9b>
  6f4292:	49 3b 0f             	cmp    (%r15),%rcx
  6f4295:	75 44                	jne    6f42db <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x2e9b>
  6f4297:	0f b6 8c 24 f2 00 00 	movzbl 0xf2(%rsp),%ecx
  6f429e:	00 
  6f429f:	88 8c 24 fe 00 00 00 	mov    %cl,0xfe(%rsp)
  6f42a6:	0f b7 8c 24 f0 00 00 	movzwl 0xf0(%rsp),%ecx
  6f42ad:	00 
  6f42ae:	66 89 8c 24 fc 00 00 	mov    %cx,0xfc(%rsp)
  6f42b5:	00 
  6f42b6:	0f b7 8c 24 ec 00 00 	movzwl 0xec(%rsp),%ecx
  6f42bd:	00 
  6f42be:	66 89 8c 24 f8 00 00 	mov    %cx,0xf8(%rsp)
  6f42c5:	00 
  6f42c6:	0f b6 8c 24 ee 00 00 	movzbl 0xee(%rsp),%ecx
  6f42cd:	00 
  6f42ce:	88 8c 24 fa 00 00 00 	mov    %cl,0xfa(%rsp)
  6f42d5:	44 0f b6 64 24 70    	movzbl 0x70(%rsp),%r12d
  6f42db:	48 83 bc 24 a8 01 00 	cmpq   $0x0,0x1a8(%rsp)
  6f42e2:	00 00 
  6f42e4:	0f 84 64 20 00 00    	je     6f634e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4f0e>
  6f42ea:	f3 0f 10 84 24 88 04 	movss  0x488(%rsp),%xmm0
  6f42f1:	00 00 
  6f42f3:	0f 28 8c 24 a0 02 00 	movaps 0x2a0(%rsp),%xmm1
  6f42fa:	00 
  6f42fb:	f3 0f 5c 8c 24 e0 03 	subss  0x3e0(%rsp),%xmm1
  6f4302:	00 00 
  6f4304:	f3 0f 5c 8c 24 18 03 	subss  0x318(%rsp),%xmm1
  6f430b:	00 00 
  6f430d:	f3 0f 5c 8c 24 80 08 	subss  0x880(%rsp),%xmm1
  6f4314:	00 00 
  6f4316:	f3 0f 5c 8c 24 1c 03 	subss  0x31c(%rsp),%xmm1
  6f431d:	00 00 
  6f431f:	f3 0f 5c 8c 24 70 08 	subss  0x870(%rsp),%xmm1
  6f4326:	00 00 
  6f4328:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
  6f432f:	00 
  6f4330:	48 89 c6             	mov    %rax,%rsi
  6f4333:	48 8d 94 24 a8 01 00 	lea    0x1a8(%rsp),%rdx
  6f433a:	00 
  6f433b:	b9 01 00 00 00       	mov    $0x1,%ecx
  6f4340:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  6f4346:	ff 15 5c 74 39 00    	call   *0x39745c(%rip)        # a8b7a8 <_DYNAMIC+0x350>
  6f434c:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  6f4353:	00 
  6f4354:	4c 8b bc 24 a8 00 00 	mov    0xa8(%rsp),%r15
  6f435b:	00 
  6f435c:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6f4360:	0f 85 5d 1b 00 00    	jne    6f5ec3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4a83>
  6f4366:	0f 28 84 24 e0 03 00 	movaps 0x3e0(%rsp),%xmm0
  6f436d:	00 
  6f436e:	f3 0f 11 84 24 38 01 	movss  %xmm0,0x138(%rsp)
  6f4375:	00 00 
  6f4377:	0f 28 84 24 60 08 00 	movaps 0x860(%rsp),%xmm0
  6f437e:	00 
  6f437f:	f3 0f 11 84 24 3c 01 	movss  %xmm0,0x13c(%rsp)
  6f4386:	00 00 
  6f4388:	49 8b 47 20          	mov    0x20(%r15),%rax
  6f438c:	48 85 c0             	test   %rax,%rax
  6f438f:	0f 84 4e 20 00 00    	je     6f63e3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4fa3>
  6f4395:	f0 48 ff 00          	lock incq (%rax)
  6f4399:	0f 8e 98 22 00 00    	jle    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f439f:	f2 0f 10 84 24 38 01 	movsd  0x138(%rsp),%xmm0
  6f43a6:	00 00 
  6f43a8:	f2 0f 11 84 24 08 03 	movsd  %xmm0,0x308(%rsp)
  6f43af:	00 00 
  6f43b1:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
  6f43b8:	00 
  6f43b9:	40 84 ed             	test   %bpl,%bpl
  6f43bc:	0f 84 82 04 00 00    	je     6f4844 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3404>
  6f43c2:	f6 84 24 e4 02 00 00 	testb  $0x1,0x2e4(%rsp)
  6f43c9:	01 
  6f43ca:	c7 84 24 a8 00 00 00 	movl   $0x1,0xa8(%rsp)
  6f43d1:	01 00 00 00 
  6f43d5:	48 c7 84 24 a0 00 00 	movq   $0x23,0xa0(%rsp)
  6f43dc:	00 23 00 00 00 
  6f43e1:	0f 84 1d 1c 00 00    	je     6f6004 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4bc4>
  6f43e7:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
  6f43ee:	00 
  6f43ef:	e8 bc 0d ff ff       	call   6e51b0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6f43f4:	48 8d 8c 24 e8 02 00 	lea    0x2e8(%rsp),%rcx
  6f43fb:	00 
  6f43fc:	0f 10 01             	movups (%rcx),%xmm0
  6f43ff:	0f 29 84 24 e0 08 00 	movaps %xmm0,0x8e0(%rsp)
  6f4406:	00 
  6f4407:	48 8b 41 10          	mov    0x10(%rcx),%rax
  6f440b:	48 89 84 24 f0 08 00 	mov    %rax,0x8f0(%rsp)
  6f4412:	00 
  6f4413:	0f 10 01             	movups (%rcx),%xmm0
  6f4416:	0f 29 84 24 50 02 00 	movaps %xmm0,0x250(%rsp)
  6f441d:	00 
  6f441e:	48 8b 41 10          	mov    0x10(%rcx),%rax
  6f4422:	48 89 84 24 60 02 00 	mov    %rax,0x260(%rsp)
  6f4429:	00 
  6f442a:	41 80 fc 02          	cmp    $0x2,%r12b
  6f442e:	0f 84 0e 01 00 00    	je     6f4542 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3102>
  6f4434:	8b 84 24 74 01 00 00 	mov    0x174(%rsp),%eax
  6f443b:	89 84 24 80 00 00 00 	mov    %eax,0x80(%rsp)
  6f4442:	0f b6 44 24 7e       	movzbl 0x7e(%rsp),%eax
  6f4447:	88 84 24 84 00 00 00 	mov    %al,0x84(%rsp)
  6f444e:	0f b6 84 24 fe 00 00 	movzbl 0xfe(%rsp),%eax
  6f4455:	00 
  6f4456:	48 8d 8c 24 85 00 00 	lea    0x85(%rsp),%rcx
  6f445d:	00 
  6f445e:	88 41 02             	mov    %al,0x2(%rcx)
  6f4461:	0f b7 84 24 fc 00 00 	movzwl 0xfc(%rsp),%eax
  6f4468:	00 
  6f4469:	66 89 01             	mov    %ax,(%rcx)
  6f446c:	8b 84 24 d4 01 00 00 	mov    0x1d4(%rsp),%eax
  6f4473:	89 84 24 88 00 00 00 	mov    %eax,0x88(%rsp)
  6f447a:	44 88 a4 24 8c 00 00 	mov    %r12b,0x8c(%rsp)
  6f4481:	00 
  6f4482:	0f b6 84 24 fa 00 00 	movzbl 0xfa(%rsp),%eax
  6f4489:	00 
  6f448a:	88 41 0a             	mov    %al,0xa(%rcx)
  6f448d:	0f b7 84 24 f8 00 00 	movzwl 0xf8(%rsp),%eax
  6f4494:	00 
  6f4495:	66 89 41 08          	mov    %ax,0x8(%rcx)
  6f4499:	c7 84 24 40 01 00 00 	movl   $0xffffffff,0x140(%rsp)
  6f44a0:	ff ff ff ff 
  6f44a4:	49 8b 7f 20          	mov    0x20(%r15),%rdi
  6f44a8:	48 85 ff             	test   %rdi,%rdi
  6f44ab:	0f 84 42 1b 00 00    	je     6f5ff3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4bb3>
  6f44b1:	48 83 c7 10          	add    $0x10,%rdi
  6f44b5:	48 8d 84 24 40 01 00 	lea    0x140(%rsp),%rax
  6f44bc:	00 
  6f44bd:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6f44c4:	00 
  6f44c5:	48 8d 84 24 30 09 00 	lea    0x930(%rsp),%rax
  6f44cc:	00 
  6f44cd:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  6f44d4:	00 
  6f44d5:	48 8d 84 24 38 01 00 	lea    0x138(%rsp),%rax
  6f44dc:	00 
  6f44dd:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  6f44e4:	00 
  6f44e5:	48 8d 84 24 3c 01 00 	lea    0x13c(%rsp),%rax
  6f44ec:	00 
  6f44ed:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  6f44f4:	00 
  6f44f5:	48 8d 84 24 50 02 00 	lea    0x250(%rsp),%rax
  6f44fc:	00 
  6f44fd:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  6f4504:	00 
  6f4505:	48 8d 84 24 90 01 00 	lea    0x190(%rsp),%rax
  6f450c:	00 
  6f450d:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  6f4514:	00 
  6f4515:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6f451c:	00 
  6f451d:	48 8d 94 24 a0 00 00 	lea    0xa0(%rsp),%rdx
  6f4524:	00 
  6f4525:	e8 46 1b 02 00       	call   716070 <<gpui_canvas::text::layout::TextGeometry>::selection_rects::<<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner::{closure#28}>>
  6f452a:	84 c0                	test   %al,%al
  6f452c:	0f 84 c1 1a 00 00    	je     6f5ff3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4bb3>
  6f4532:	8b 84 24 40 01 00 00 	mov    0x140(%rsp),%eax
  6f4539:	83 f8 ff             	cmp    $0xffffffff,%eax
  6f453c:	0f 85 b6 1b 00 00    	jne    6f60f8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4cb8>
  6f4542:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  6f4549:	00 
  6f454a:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  6f454f:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  6f4554:	b9 01 00 00 00       	mov    $0x1,%ecx
  6f4559:	ff 15 f1 74 39 00    	call   *0x3974f1(%rip)        # a8ba50 <_DYNAMIC+0x5f8>
  6f455f:	48 83 c3 30          	add    $0x30,%rbx
  6f4563:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f456a:	00 
  6f456b:	48 85 c0             	test   %rax,%rax
  6f456e:	0f 84 b1 00 00 00    	je     6f4625 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x31e5>
  6f4574:	0f 10 84 24 80 00 00 	movups 0x80(%rsp),%xmm0
  6f457b:	00 
  6f457c:	0f 29 84 24 00 04 00 	movaps %xmm0,0x400(%rsp)
  6f4583:	00 
  6f4584:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
  6f458b:	00 
  6f458c:	0f 29 84 24 40 01 00 	movaps %xmm0,0x140(%rsp)
  6f4593:	00 
  6f4594:	f3 0f 10 84 24 38 01 	movss  0x138(%rsp),%xmm0
  6f459b:	00 00 
  6f459d:	f3 0f 10 8c 24 3c 01 	movss  0x13c(%rsp),%xmm1
  6f45a4:	00 00 
  6f45a6:	48 8d 94 24 e8 02 00 	lea    0x2e8(%rsp),%rdx
  6f45ad:	00 
  6f45ae:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  6f45b2:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
  6f45b9:	00 
  6f45ba:	0f 10 12             	movups (%rdx),%xmm2
  6f45bd:	0f 29 94 24 a0 00 00 	movaps %xmm2,0xa0(%rsp)
  6f45c4:	00 
  6f45c5:	48 89 04 24          	mov    %rax,(%rsp)
  6f45c9:	48 8d bc 24 30 09 00 	lea    0x930(%rsp),%rdi
  6f45d0:	00 
  6f45d1:	48 89 de             	mov    %rbx,%rsi
  6f45d4:	4c 89 fa             	mov    %r15,%rdx
  6f45d7:	48 8d 8c 24 a0 00 00 	lea    0xa0(%rsp),%rcx
  6f45de:	00 
  6f45df:	4c 8d 84 24 40 01 00 	lea    0x140(%rsp),%r8
  6f45e6:	00 
  6f45e7:	4c 8d 8c 24 00 04 00 	lea    0x400(%rsp),%r9
  6f45ee:	00 
  6f45ef:	f3 0f 10 94 24 9c 00 	movss  0x9c(%rsp),%xmm2
  6f45f6:	00 00 
  6f45f8:	ff 15 6a 74 39 00    	call   *0x39746a(%rip)        # a8ba68 <_DYNAMIC+0x610>
  6f45fe:	e9 a8 00 00 00       	jmp    6f46ab <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x326b>
  6f4603:	48 c7 84 24 18 02 00 	movq   $0x0,0x218(%rsp)
  6f460a:	00 00 00 00 00 
  6f460f:	e9 55 02 00 00       	jmp    6f4869 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3429>
  6f4614:	41 b5 01             	mov    $0x1,%r13b
  6f4617:	83 f8 07             	cmp    $0x7,%eax
  6f461a:	0f 84 d8 f6 ff ff    	je     6f3cf8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x28b8>
  6f4620:	e9 f5 1d 00 00       	jmp    6f641a <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4fda>
  6f4625:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
  6f462c:	00 
  6f462d:	0f 29 84 24 40 01 00 	movaps %xmm0,0x140(%rsp)
  6f4634:	00 
  6f4635:	f3 0f 10 84 24 38 01 	movss  0x138(%rsp),%xmm0
  6f463c:	00 00 
  6f463e:	f3 0f 10 8c 24 3c 01 	movss  0x13c(%rsp),%xmm1
  6f4645:	00 00 
  6f4647:	48 8d 8c 24 e8 02 00 	lea    0x2e8(%rsp),%rcx
  6f464e:	00 
  6f464f:	48 8b 41 10          	mov    0x10(%rcx),%rax
  6f4653:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  6f465a:	00 
  6f465b:	0f 10 11             	movups (%rcx),%xmm2
  6f465e:	0f 29 94 24 a0 00 00 	movaps %xmm2,0xa0(%rsp)
  6f4665:	00 
  6f4666:	0f 28 94 24 b0 08 00 	movaps 0x8b0(%rsp),%xmm2
  6f466d:	00 
  6f466e:	0f 29 94 24 80 00 00 	movaps %xmm2,0x80(%rsp)
  6f4675:	00 
  6f4676:	48 8d bc 24 30 09 00 	lea    0x930(%rsp),%rdi
  6f467d:	00 
  6f467e:	48 89 de             	mov    %rbx,%rsi
  6f4681:	4c 89 fa             	mov    %r15,%rdx
  6f4684:	48 8d 8c 24 a0 00 00 	lea    0xa0(%rsp),%rcx
  6f468b:	00 
  6f468c:	4c 8d 84 24 40 01 00 	lea    0x140(%rsp),%r8
  6f4693:	00 
  6f4694:	4c 8d 8c 24 80 00 00 	lea    0x80(%rsp),%r9
  6f469b:	00 
  6f469c:	f3 0f 10 94 24 9c 00 	movss  0x9c(%rsp),%xmm2
  6f46a3:	00 00 
  6f46a5:	ff 15 c5 73 39 00    	call   *0x3973c5(%rip)        # a8ba70 <_DYNAMIC+0x618>
  6f46ab:	83 f8 ff             	cmp    $0xffffffff,%eax
  6f46ae:	0f 85 89 19 00 00    	jne    6f603d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4bfd>
  6f46b4:	41 80 fc 02          	cmp    $0x2,%r12b
  6f46b8:	0f 84 86 01 00 00    	je     6f4844 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3404>
  6f46be:	8b 84 24 d4 01 00 00 	mov    0x1d4(%rsp),%eax
  6f46c5:	39 84 24 74 01 00 00 	cmp    %eax,0x174(%rsp)
  6f46cc:	0f 85 72 01 00 00    	jne    6f4844 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3404>
  6f46d2:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  6f46d7:	48 8b 80 18 06 00 00 	mov    0x618(%rax),%rax
  6f46de:	48 85 c0             	test   %rax,%rax
  6f46e1:	0f 84 5d 01 00 00    	je     6f4844 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3404>
  6f46e7:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  6f46ec:	48 3b 81 c0 05 00 00 	cmp    0x5c0(%rcx),%rax
  6f46f3:	0f 85 4b 01 00 00    	jne    6f4844 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3404>
  6f46f9:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  6f46fe:	48 8b 00             	mov    (%rax),%rax
  6f4701:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  6f4706:	48 39 81 20 06 00 00 	cmp    %rax,0x620(%rcx)
  6f470d:	0f 85 31 01 00 00    	jne    6f4844 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3404>
  6f4713:	41 0f b6 cc          	movzbl %r12b,%ecx
  6f4717:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  6f471e:	00 
  6f471f:	4c 89 fe             	mov    %r15,%rsi
  6f4722:	8b 94 24 74 01 00 00 	mov    0x174(%rsp),%edx
  6f4729:	ff 15 49 73 39 00    	call   *0x397349(%rip)        # a8ba78 <_DYNAMIC+0x620>
  6f472f:	48 c7 84 24 a0 00 00 	movq   $0x18,0xa0(%rsp)
  6f4736:	00 18 00 00 00 
  6f473b:	83 bc 24 80 00 00 00 	cmpl   $0x1,0x80(%rsp)
  6f4742:	01 
  6f4743:	0f 85 aa 18 00 00    	jne    6f5ff3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4bb3>
  6f4749:	48 8d 9c 24 a0 00 00 	lea    0xa0(%rsp),%rbx
  6f4750:	00 
  6f4751:	48 89 df             	mov    %rbx,%rdi
  6f4754:	e8 57 0a ff ff       	call   6e51b0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6f4759:	f2 0f 10 84 24 84 00 	movsd  0x84(%rsp),%xmm0
  6f4760:	00 00 
  6f4762:	0f 28 8c 24 e0 03 00 	movaps 0x3e0(%rsp),%xmm1
  6f4769:	00 
  6f476a:	0f 14 8c 24 60 08 00 	unpcklps 0x860(%rsp),%xmm1
  6f4771:	00 
  6f4772:	0f 58 c8             	addps  %xmm0,%xmm1
  6f4775:	0f 16 8c 24 8c 00 00 	movhps 0x8c(%rsp),%xmm1
  6f477c:	00 
  6f477d:	0f 11 8c 24 00 04 00 	movups %xmm1,0x400(%rsp)
  6f4784:	00 
  6f4785:	48 89 df             	mov    %rbx,%rdi
  6f4788:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  6f478d:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  6f4792:	b9 01 00 00 00       	mov    $0x1,%ecx
  6f4797:	ff 15 b3 72 39 00    	call   *0x3972b3(%rip)        # a8ba50 <_DYNAMIC+0x5f8>
  6f479d:	4c 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%r9
  6f47a4:	00 
  6f47a5:	4d 85 c9             	test   %r9,%r9
  6f47a8:	74 53                	je     6f47fd <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x33bd>
  6f47aa:	0f 10 84 24 a0 00 00 	movups 0xa0(%rsp),%xmm0
  6f47b1:	00 
  6f47b2:	0f 29 84 24 40 01 00 	movaps %xmm0,0x140(%rsp)
  6f47b9:	00 
  6f47ba:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
  6f47c1:	00 
  6f47c2:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  6f47c9:	00 
  6f47ca:	0f 57 c0             	xorps  %xmm0,%xmm0
  6f47cd:	48 8d bc 24 30 09 00 	lea    0x930(%rsp),%rdi
  6f47d4:	00 
  6f47d5:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
  6f47dc:	00 
  6f47dd:	48 8d 94 24 e0 08 00 	lea    0x8e0(%rsp),%rdx
  6f47e4:	00 
  6f47e5:	48 8d 8c 24 80 00 00 	lea    0x80(%rsp),%rcx
  6f47ec:	00 
  6f47ed:	4c 8d 84 24 40 01 00 	lea    0x140(%rsp),%r8
  6f47f4:	00 
  6f47f5:	ff 15 5d 72 39 00    	call   *0x39725d(%rip)        # a8ba58 <_DYNAMIC+0x600>
  6f47fb:	eb 3e                	jmp    6f483b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x33fb>
  6f47fd:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
  6f4804:	00 
  6f4805:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  6f480c:	00 
  6f480d:	48 8d bc 24 30 09 00 	lea    0x930(%rsp),%rdi
  6f4814:	00 
  6f4815:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
  6f481c:	00 
  6f481d:	48 8d 94 24 e0 08 00 	lea    0x8e0(%rsp),%rdx
  6f4824:	00 
  6f4825:	48 8d 8c 24 a0 00 00 	lea    0xa0(%rsp),%rcx
  6f482c:	00 
  6f482d:	4c 8d 84 24 b0 08 00 	lea    0x8b0(%rsp),%r8
  6f4834:	00 
  6f4835:	ff 15 45 72 39 00    	call   *0x397245(%rip)        # a8ba80 <_DYNAMIC+0x628>
  6f483b:	83 f8 ff             	cmp    $0xffffffff,%eax
  6f483e:	0f 85 f9 17 00 00    	jne    6f603d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4bfd>
  6f4844:	48 8b 84 24 08 03 00 	mov    0x308(%rsp),%rax
  6f484b:	00 
  6f484c:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  6f4853:	00 
  6f4854:	48 8b 84 24 10 03 00 	mov    0x310(%rsp),%rax
  6f485b:	00 
  6f485c:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
  6f4863:	00 
  6f4864:	4c 8b 7c 24 60       	mov    0x60(%rsp),%r15
  6f4869:	40 84 ed             	test   %bpl,%bpl
  6f486c:	0f 84 5d 01 00 00    	je     6f49cf <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x358f>
  6f4872:	41 8b 7f 10          	mov    0x10(%r15),%edi
  6f4876:	41 b4 01             	mov    $0x1,%r12b
  6f4879:	ff 15 19 6f 39 00    	call   *0x396f19(%rip)        # a8b798 <_DYNAMIC+0x340>
  6f487f:	89 d5                	mov    %edx,%ebp
  6f4881:	80 fa 02             	cmp    $0x2,%dl
  6f4884:	4c 8b 7c 24 60       	mov    0x60(%rsp),%r15
  6f4889:	0f 84 40 01 00 00    	je     6f49cf <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x358f>
  6f488f:	48 8b 8c 24 a0 01 00 	mov    0x1a0(%rsp),%rcx
  6f4896:	00 
  6f4897:	48 8b 09             	mov    (%rcx),%rcx
  6f489a:	48 85 c9             	test   %rcx,%rcx
  6f489d:	0f 84 60 1b 00 00    	je     6f6403 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4fc3>
  6f48a3:	48 8b 71 10          	mov    0x10(%rcx),%rsi
  6f48a7:	89 c3                	mov    %eax,%ebx
  6f48a9:	48 39 de             	cmp    %rbx,%rsi
  6f48ac:	0f 86 23 1d 00 00    	jbe    6f65d5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5195>
  6f48b2:	48 8b 41 08          	mov    0x8(%rcx),%rax
  6f48b6:	0f 28 9c 24 80 08 00 	movaps 0x880(%rsp),%xmm3
  6f48bd:	00 
  6f48be:	0f 28 c3             	movaps %xmm3,%xmm0
  6f48c1:	0f c6 c3 e8          	shufps $0xe8,%xmm3,%xmm0
  6f48c5:	0f 28 ac 24 90 08 00 	movaps 0x890(%rsp),%xmm5
  6f48cc:	00 
  6f48cd:	0f 58 e8             	addps  %xmm0,%xmm5
  6f48d0:	0f 28 a4 24 e0 03 00 	movaps 0x3e0(%rsp),%xmm4
  6f48d7:	00 
  6f48d8:	0f 28 cc             	movaps %xmm4,%xmm1
  6f48db:	0f c6 cc e8          	shufps $0xe8,%xmm4,%xmm1
  6f48df:	0f 28 94 24 a0 02 00 	movaps 0x2a0(%rsp),%xmm2
  6f48e6:	00 
  6f48e7:	0f 5c d1             	subps  %xmm1,%xmm2
  6f48ea:	0f 58 cd             	addps  %xmm5,%xmm1
  6f48ed:	0f c6 e4 ed          	shufps $0xed,%xmm4,%xmm4
  6f48f1:	0f 5c d4             	subps  %xmm4,%xmm2
  6f48f4:	0f 5c d0             	subps  %xmm0,%xmm2
  6f48f7:	0f c6 db ed          	shufps $0xed,%xmm3,%xmm3
  6f48fb:	0f 5c d3             	subps  %xmm3,%xmm2
  6f48fe:	0f 5c 94 24 70 08 00 	subps  0x870(%rsp),%xmm2
  6f4905:	00 
  6f4906:	0f 16 ca             	movlhps %xmm2,%xmm1
  6f4909:	0f 11 8c 24 40 01 00 	movups %xmm1,0x140(%rsp)
  6f4910:	00 
  6f4911:	f6 84 24 e4 02 00 00 	testb  $0x1,0x2e4(%rsp)
  6f4918:	01 
  6f4919:	c7 84 24 a8 00 00 00 	movl   $0x1,0xa8(%rsp)
  6f4920:	01 00 00 00 
  6f4924:	48 c7 84 24 a0 00 00 	movq   $0x23,0xa0(%rsp)
  6f492b:	00 23 00 00 00 
  6f4930:	0f 84 57 17 00 00    	je     6f608d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4c4d>
  6f4936:	48 8d 1c d8          	lea    (%rax,%rbx,8),%rbx
  6f493a:	4c 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%r14
  6f4941:	00 
  6f4942:	4c 89 f7             	mov    %r14,%rdi
  6f4945:	e8 66 08 ff ff       	call   6e51b0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6f494a:	48 8d 8c 24 e8 02 00 	lea    0x2e8(%rsp),%rcx
  6f4951:	00 
  6f4952:	0f 10 01             	movups (%rcx),%xmm0
  6f4955:	0f 29 84 24 50 02 00 	movaps %xmm0,0x250(%rsp)
  6f495c:	00 
  6f495d:	48 8b 41 10          	mov    0x10(%rcx),%rax
  6f4961:	48 89 84 24 60 02 00 	mov    %rax,0x260(%rsp)
  6f4968:	00 
  6f4969:	0f 10 01             	movups (%rcx),%xmm0
  6f496c:	0f 29 84 24 80 0b 00 	movaps %xmm0,0xb80(%rsp)
  6f4973:	00 
  6f4974:	48 8b 41 10          	mov    0x10(%rcx),%rax
  6f4978:	48 89 84 24 90 0b 00 	mov    %rax,0xb90(%rsp)
  6f497f:	00 
  6f4980:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
  6f4987:	00 
  6f4988:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  6f498f:	00 
  6f4990:	44 0f b6 cd          	movzbl %bpl,%r9d
  6f4994:	48 8d bc 24 30 09 00 	lea    0x930(%rsp),%rdi
  6f499b:	00 
  6f499c:	48 89 de             	mov    %rbx,%rsi
  6f499f:	48 8d 94 24 40 01 00 	lea    0x140(%rsp),%rdx
  6f49a6:	00 
  6f49a7:	48 8d 8c 24 80 0b 00 	lea    0xb80(%rsp),%rcx
  6f49ae:	00 
  6f49af:	4d 89 f0             	mov    %r14,%r8
  6f49b2:	f3 0f 10 84 24 e8 00 	movss  0xe8(%rsp),%xmm0
  6f49b9:	00 00 
  6f49bb:	ff 15 c7 70 39 00    	call   *0x3970c7(%rip)        # a8ba88 <_DYNAMIC+0x630>
  6f49c1:	83 f8 ff             	cmp    $0xffffffff,%eax
  6f49c4:	0f 85 f9 16 00 00    	jne    6f60c3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4c83>
  6f49ca:	4c 8b 7c 24 60       	mov    0x60(%rsp),%r15
  6f49cf:	41 8b 5f 08          	mov    0x8(%r15),%ebx
  6f49d3:	80 7c 24 2f 00       	cmpb   $0x0,0x2f(%rsp)
  6f49d8:	74 28                	je     6f4a02 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x35c2>
  6f49da:	83 fb ff             	cmp    $0xffffffff,%ebx
  6f49dd:	74 1e                	je     6f49fd <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x35bd>
  6f49df:	48 8b b4 24 68 01 00 	mov    0x168(%rsp),%rsi
  6f49e6:	00 
  6f49e7:	48 39 de             	cmp    %rbx,%rsi
  6f49ea:	0f 86 d6 1b 00 00    	jbe    6f65c6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5186>
  6f49f0:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
  6f49f7:	00 
  6f49f8:	8b 1c 98             	mov    (%rax,%rbx,4),%ebx
  6f49fb:	eb 05                	jmp    6f4a02 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x35c2>
  6f49fd:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
  6f4a02:	80 bc 24 00 01 00 00 	cmpb   $0x0,0x100(%rsp)
  6f4a09:	00 
  6f4a0a:	74 2b                	je     6f4a37 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x35f7>
  6f4a0c:	f3 0f 10 84 24 c0 02 	movss  0x2c0(%rsp),%xmm0
  6f4a13:	00 00 
  6f4a15:	0f 57 c9             	xorps  %xmm1,%xmm1
  6f4a18:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6f4a1b:	75 06                	jne    6f4a23 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x35e3>
  6f4a1d:	0f 8b 3d 01 00 00    	jnp    6f4b60 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3720>
  6f4a23:	f3 0f 10 84 24 c4 02 	movss  0x2c4(%rsp),%xmm0
  6f4a2a:	00 00 
  6f4a2c:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6f4a2f:	75 06                	jne    6f4a37 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x35f7>
  6f4a31:	0f 8b 29 01 00 00    	jnp    6f4b60 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3720>
  6f4a37:	41 8b 7f 10          	mov    0x10(%r15),%edi
  6f4a3b:	41 b4 01             	mov    $0x1,%r12b
  6f4a3e:	e8 4d aa ff ff       	call   6ef490 <<gpui::runtime::Node>::kind>
  6f4a43:	3c 07                	cmp    $0x7,%al
  6f4a45:	75 18                	jne    6f4a5f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x361f>
  6f4a47:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  6f4a4c:	48 8b 30             	mov    (%rax),%rsi
  6f4a4f:	41 b4 01             	mov    $0x1,%r12b
  6f4a52:	48 8d bc 24 b8 03 00 	lea    0x3b8(%rsp),%rdi
  6f4a59:	00 
  6f4a5a:	e8 01 4b 01 00       	call   709560 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6f4a5f:	80 7c 24 2f 00       	cmpb   $0x0,0x2f(%rsp)
  6f4a64:	74 51                	je     6f4ab7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3677>
  6f4a66:	48 8b b4 24 c8 01 00 	mov    0x1c8(%rsp),%rsi
  6f4a6d:	00 
  6f4a6e:	bf 01 00 00 00       	mov    $0x1,%edi
  6f4a73:	41 b4 01             	mov    $0x1,%r12b
  6f4a76:	ff 15 14 70 39 00    	call   *0x397014(%rip)        # a8ba90 <_DYNAMIC+0x638>
  6f4a7c:	89 c5                	mov    %eax,%ebp
  6f4a7e:	4c 8b b4 24 68 01 00 	mov    0x168(%rsp),%r14
  6f4a85:	00 
  6f4a86:	4c 3b b4 24 58 01 00 	cmp    0x158(%rsp),%r14
  6f4a8d:	00 
  6f4a8e:	75 10                	jne    6f4aa0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3660>
  6f4a90:	41 b4 01             	mov    $0x1,%r12b
  6f4a93:	48 8d bc 24 58 01 00 	lea    0x158(%rsp),%rdi
  6f4a9a:	00 
  6f4a9b:	e8 20 c4 02 00       	call   720ec0 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  6f4aa0:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
  6f4aa7:	00 
  6f4aa8:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
  6f4aac:	49 ff c6             	inc    %r14
  6f4aaf:	4c 89 b4 24 68 01 00 	mov    %r14,0x168(%rsp)
  6f4ab6:	00 
  6f4ab7:	f3 0f 10 84 24 c0 02 	movss  0x2c0(%rsp),%xmm0
  6f4abe:	00 00 
  6f4ac0:	31 ed                	xor    %ebp,%ebp
  6f4ac2:	0f 57 c9             	xorps  %xmm1,%xmm1
  6f4ac5:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6f4ac8:	75 06                	jne    6f4ad0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3690>
  6f4aca:	0f 8b 56 01 00 00    	jnp    6f4c26 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x37e6>
  6f4ad0:	f3 0f 10 84 24 c4 02 	movss  0x2c4(%rsp),%xmm0
  6f4ad7:	00 00 
  6f4ad9:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6f4adc:	41 be 00 00 00 00    	mov    $0x0,%r14d
  6f4ae2:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  6f4ae7:	75 06                	jne    6f4aef <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x36af>
  6f4ae9:	0f 8b 3a 01 00 00    	jnp    6f4c29 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x37e9>
  6f4aef:	8b 78 10             	mov    0x10(%rax),%edi
  6f4af2:	41 b4 01             	mov    $0x1,%r12b
  6f4af5:	e8 c6 a9 ff ff       	call   6ef4c0 <<gpui::runtime::Node>::text_slot>
  6f4afa:	41 b6 01             	mov    $0x1,%r14b
  6f4afd:	83 f8 ff             	cmp    $0xffffffff,%eax
  6f4b00:	0f 85 23 01 00 00    	jne    6f4c29 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x37e9>
  6f4b06:	8b 84 24 a8 04 00 00 	mov    0x4a8(%rsp),%eax
  6f4b0d:	b9 ff ff ff 3f       	mov    $0x3fffffff,%ecx
  6f4b12:	21 c8                	and    %ecx,%eax
  6f4b14:	3d 01 00 80 3f       	cmp    $0x3f800001,%eax
  6f4b19:	b9 00 00 00 80       	mov    $0x80000000,%ecx
  6f4b1e:	0f 44 c1             	cmove  %ecx,%eax
  6f4b21:	66 0f 6e c0          	movd   %eax,%xmm0
  6f4b25:	0f 57 c9             	xorps  %xmm1,%xmm1
  6f4b28:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6f4b2b:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  6f4b30:	0f 87 f3 00 00 00    	ja     6f4c29 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x37e9>
  6f4b36:	8b 78 10             	mov    0x10(%rax),%edi
  6f4b39:	85 ff                	test   %edi,%edi
  6f4b3b:	0f 88 e8 00 00 00    	js     6f4c29 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x37e9>
  6f4b41:	41 b4 01             	mov    $0x1,%r12b
  6f4b44:	e8 47 a9 ff ff       	call   6ef490 <<gpui::runtime::Node>::kind>
  6f4b49:	8d 48 fc             	lea    -0x4(%rax),%ecx
  6f4b4c:	3c 02                	cmp    $0x2,%al
  6f4b4e:	0f 93 c0             	setae  %al
  6f4b51:	f6 c1 fb             	test   $0xfb,%cl
  6f4b54:	41 0f 94 c6          	sete   %r14b
  6f4b58:	41 20 c6             	and    %al,%r14b
  6f4b5b:	e9 c9 00 00 00       	jmp    6f4c29 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x37e9>
  6f4b60:	80 bc 24 d8 01 00 00 	cmpb   $0x0,0x1d8(%rsp)
  6f4b67:	00 
  6f4b68:	74 28                	je     6f4b92 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3752>
  6f4b6a:	f3 0f 10 84 24 78 02 	movss  0x278(%rsp),%xmm0
  6f4b71:	00 00 
  6f4b73:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6f4b76:	75 02                	jne    6f4b7a <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x373a>
  6f4b78:	7b 18                	jnp    6f4b92 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3752>
  6f4b7a:	f3 0f 10 84 24 7c 02 	movss  0x27c(%rsp),%xmm0
  6f4b81:	00 00 
  6f4b83:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6f4b86:	0f 85 ab fe ff ff    	jne    6f4a37 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x35f7>
  6f4b8c:	0f 8a a5 fe ff ff    	jp     6f4a37 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x35f7>
  6f4b92:	45 84 ed             	test   %r13b,%r13b
  6f4b95:	74 28                	je     6f4bbf <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x377f>
  6f4b97:	f3 0f 10 84 24 78 02 	movss  0x278(%rsp),%xmm0
  6f4b9e:	00 00 
  6f4ba0:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6f4ba3:	75 02                	jne    6f4ba7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3767>
  6f4ba5:	7b 18                	jnp    6f4bbf <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x377f>
  6f4ba7:	f3 0f 10 84 24 7c 02 	movss  0x27c(%rsp),%xmm0
  6f4bae:	00 00 
  6f4bb0:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6f4bb3:	0f 85 7e fe ff ff    	jne    6f4a37 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x35f7>
  6f4bb9:	0f 8a 78 fe ff ff    	jp     6f4a37 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x35f7>
  6f4bbf:	4c 8b b4 24 68 01 00 	mov    0x168(%rsp),%r14
  6f4bc6:	00 
  6f4bc7:	4c 3b b4 24 58 01 00 	cmp    0x158(%rsp),%r14
  6f4bce:	00 
  6f4bcf:	75 10                	jne    6f4be1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x37a1>
  6f4bd1:	41 b4 01             	mov    $0x1,%r12b
  6f4bd4:	48 8d bc 24 58 01 00 	lea    0x158(%rsp),%rdi
  6f4bdb:	00 
  6f4bdc:	e8 df c2 02 00       	call   720ec0 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  6f4be1:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
  6f4be8:	00 
  6f4be9:	42 89 1c b0          	mov    %ebx,(%rax,%r14,4)
  6f4bed:	49 ff c6             	inc    %r14
  6f4bf0:	4c 89 b4 24 68 01 00 	mov    %r14,0x168(%rsp)
  6f4bf7:	00 
  6f4bf8:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
  6f4bff:	00 
  6f4c00:	48 85 c0             	test   %rax,%rax
  6f4c03:	0f 84 84 e7 ff ff    	je     6f338d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1f4d>
  6f4c09:	f0 48 ff 08          	lock decq (%rax)
  6f4c0d:	0f 85 7a e7 ff ff    	jne    6f338d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1f4d>
  6f4c13:	48 8d bc 24 18 02 00 	lea    0x218(%rsp),%rdi
  6f4c1a:	00 
  6f4c1b:	ff 15 e7 6a 39 00    	call   *0x396ae7(%rip)        # a8b708 <_DYNAMIC+0x2b0>
  6f4c21:	e9 67 e7 ff ff       	jmp    6f338d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1f4d>
  6f4c26:	45 31 f6             	xor    %r14d,%r14d
  6f4c29:	48 8b 84 24 c8 01 00 	mov    0x1c8(%rsp),%rax
  6f4c30:	00 
  6f4c31:	48 85 c0             	test   %rax,%rax
  6f4c34:	74 15                	je     6f4c4b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x380b>
  6f4c36:	48 8b 8c 24 c0 01 00 	mov    0x1c0(%rsp),%rcx
  6f4c3d:	00 
  6f4c3e:	48 c1 e0 06          	shl    $0x6,%rax
  6f4c42:	8b 4c 01 f8          	mov    -0x8(%rcx,%rax,1),%ecx
  6f4c46:	bd 01 00 00 00       	mov    $0x1,%ebp
  6f4c4b:	44 89 f0             	mov    %r14d,%eax
  6f4c4e:	34 01                	xor    $0x1,%al
  6f4c50:	0f b6 f0             	movzbl %al,%esi
  6f4c53:	41 b4 01             	mov    $0x1,%r12b
  6f4c56:	89 df                	mov    %ebx,%edi
  6f4c58:	89 ea                	mov    %ebp,%edx
  6f4c5a:	ff 15 38 6e 39 00    	call   *0x396e38(%rip)        # a8ba98 <_DYNAMIC+0x640>
  6f4c60:	89 84 24 00 01 00 00 	mov    %eax,0x100(%rsp)
  6f4c67:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
  6f4c6e:	00 
  6f4c6f:	48 85 c0             	test   %rax,%rax
  6f4c72:	41 0f 94 c5          	sete   %r13b
  6f4c76:	74 40                	je     6f4cb8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3878>
  6f4c78:	8b 8c 24 c8 01 00 00 	mov    0x1c8(%rsp),%ecx
  6f4c7f:	89 8c 24 b0 00 00 00 	mov    %ecx,0xb0(%rsp)
  6f4c86:	f2 0f 10 84 24 10 02 	movsd  0x210(%rsp),%xmm0
  6f4c8d:	00 00 
  6f4c8f:	f2 0f 11 84 24 a8 00 	movsd  %xmm0,0xa8(%rsp)
  6f4c96:	00 00 
  6f4c98:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6f4c9f:	00 
  6f4ca0:	45 31 e4             	xor    %r12d,%r12d
  6f4ca3:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
  6f4caa:	00 
  6f4cab:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
  6f4cb2:	00 
  6f4cb3:	e8 38 a5 ff ff       	call   6ef1f0 <<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>::push_mut>
  6f4cb8:	83 fb ff             	cmp    $0xffffffff,%ebx
  6f4cbb:	44 88 6c 24 30       	mov    %r13b,0x30(%rsp)
  6f4cc0:	74 33                	je     6f4cf5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x38b5>
  6f4cc2:	89 df                	mov    %ebx,%edi
  6f4cc4:	48 8b b4 24 c8 01 00 	mov    0x1c8(%rsp),%rsi
  6f4ccb:	00 
  6f4ccc:	48 39 fe             	cmp    %rdi,%rsi
  6f4ccf:	0f 86 c3 18 00 00    	jbe    6f6598 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5158>
  6f4cd5:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
  6f4cdc:	00 
  6f4cdd:	48 c1 e7 06          	shl    $0x6,%rdi
  6f4ce1:	48 8b 44 38 30       	mov    0x30(%rax,%rdi,1),%rax
  6f4ce6:	48 89 84 24 a4 00 00 	mov    %rax,0xa4(%rsp)
  6f4ced:	00 
  6f4cee:	b8 01 00 00 00       	mov    $0x1,%eax
  6f4cf3:	eb 02                	jmp    6f4cf7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x38b7>
  6f4cf5:	31 c0                	xor    %eax,%eax
  6f4cf7:	89 84 24 a0 00 00 00 	mov    %eax,0xa0(%rsp)
  6f4cfe:	45 89 ec             	mov    %r13d,%r12d
  6f4d01:	48 8d bc 24 e4 02 00 	lea    0x2e4(%rsp),%rdi
  6f4d08:	00 
  6f4d09:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
  6f4d10:	00 
  6f4d11:	48 8d 94 24 c8 02 00 	lea    0x2c8(%rsp),%rdx
  6f4d18:	00 
  6f4d19:	ff 15 81 6d 39 00    	call   *0x396d81(%rip)        # a8baa0 <_DYNAMIC+0x648>
  6f4d1f:	48 89 c3             	mov    %rax,%rbx
  6f4d22:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  6f4d27:	48 8b 28             	mov    (%rax),%rbp
  6f4d2a:	8b 78 10             	mov    0x10(%rax),%edi
  6f4d2d:	45 89 ec             	mov    %r13d,%r12d
  6f4d30:	e8 5b a7 ff ff       	call   6ef490 <<gpui::runtime::Node>::kind>
  6f4d35:	41 89 c7             	mov    %eax,%r15d
  6f4d38:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  6f4d3d:	8b 78 10             	mov    0x10(%rax),%edi
  6f4d40:	45 89 ec             	mov    %r13d,%r12d
  6f4d43:	e8 78 a7 ff ff       	call   6ef4c0 <<gpui::runtime::Node>::text_slot>
  6f4d48:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  6f4d4d:	48 8b b1 b0 02 00 00 	mov    0x2b0(%rcx),%rsi
  6f4d54:	48 8b 91 b8 02 00 00 	mov    0x2b8(%rcx),%rdx
  6f4d5b:	45 89 ec             	mov    %r13d,%r12d
  6f4d5e:	89 c7                	mov    %eax,%edi
  6f4d60:	e8 8b a6 ff ff       	call   6ef3f0 <<gpui::runtime::TextSlot>::get>
  6f4d65:	48 85 c0             	test   %rax,%rax
  6f4d68:	74 3e                	je     6f4da8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3968>
  6f4d6a:	4c 8b 60 40          	mov    0x40(%rax),%r12
  6f4d6e:	41 f6 04 24 01       	testb  $0x1,(%r12)
  6f4d73:	75 2e                	jne    6f4da3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3963>
  6f4d75:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  6f4d7a:	a8 01                	test   $0x1,%al
  6f4d7c:	75 25                	jne    6f4da3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3963>
  6f4d7e:	b8 02 00 00 00       	mov    $0x2,%eax
  6f4d83:	f0 49 0f c1 44 24 08 	lock xadd %rax,0x8(%r12)
  6f4d8a:	48 23 84 24 78 07 00 	and    0x778(%rsp),%rax
  6f4d91:	00 
  6f4d92:	45 89 f5             	mov    %r14d,%r13d
  6f4d95:	48 f7 d8             	neg    %rax
  6f4d98:	71 14                	jno    6f4dae <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x396e>
  6f4d9a:	f0 49 83 4c 24 08 01 	lock orq $0x1,0x8(%r12)
  6f4da1:	eb 0b                	jmp    6f4dae <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x396e>
  6f4da3:	45 89 f5             	mov    %r14d,%r13d
  6f4da6:	eb 06                	jmp    6f4dae <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x396e>
  6f4da8:	45 89 f5             	mov    %r14d,%r13d
  6f4dab:	45 31 e4             	xor    %r12d,%r12d
  6f4dae:	66 0f 6f 84 24 a0 02 	movdqa 0x2a0(%rsp),%xmm0
  6f4db5:	00 00 
  6f4db7:	66 0f 7e c6          	movd   %xmm0,%esi
  6f4dbb:	0f c6 c0 55          	shufps $0x55,%xmm0,%xmm0
  6f4dbf:	66 0f 7e c0          	movd   %xmm0,%eax
  6f4dc3:	48 c1 e0 20          	shl    $0x20,%rax
  6f4dc7:	48 09 c6             	or     %rax,%rsi
  6f4dca:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  6f4dd1:	00 
  6f4dd2:	48 8d 94 24 e4 02 00 	lea    0x2e4(%rsp),%rdx
  6f4dd9:	00 
  6f4dda:	ff 15 c8 6c 39 00    	call   *0x396cc8(%rip)        # a8baa8 <_DYNAMIC+0x650>
  6f4de0:	4c 8b 74 24 60       	mov    0x60(%rsp),%r14
  6f4de5:	41 8b 7e 10          	mov    0x10(%r14),%edi
  6f4de9:	e8 a2 a6 ff ff       	call   6ef490 <<gpui::runtime::Node>::kind>
  6f4dee:	41 8b 76 10          	mov    0x10(%r14),%esi
  6f4df2:	0f b6 f8             	movzbl %al,%edi
  6f4df5:	c1 ee 1f             	shr    $0x1f,%esi
  6f4df8:	e8 93 a5 ff ff       	call   6ef390 <<gpui::runtime::semantics::Actions>::for_node>
  6f4dfd:	41 8b 4e 08          	mov    0x8(%r14),%ecx
  6f4e01:	ba ff ff ff ff       	mov    $0xffffffff,%edx
  6f4e06:	48 39 d1             	cmp    %rdx,%rcx
  6f4e09:	74 34                	je     6f4e3f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x39ff>
  6f4e0b:	48 39 8c 24 88 01 00 	cmp    %rcx,0x188(%rsp)
  6f4e12:	00 
  6f4e13:	8b b4 24 00 01 00 00 	mov    0x100(%rsp),%esi
  6f4e1a:	76 1a                	jbe    6f4e36 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x39f6>
  6f4e1c:	48 8b 94 24 80 01 00 	mov    0x180(%rsp),%rdx
  6f4e23:	00 
  6f4e24:	80 3c 0a 00          	cmpb   $0x0,(%rdx,%rcx,1)
  6f4e28:	0f 95 c1             	setne  %cl
  6f4e2b:	8b 94 24 1c 01 00 00 	mov    0x11c(%rsp),%edx
  6f4e32:	08 ca                	or     %cl,%dl
  6f4e34:	eb 17                	jmp    6f4e4d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3a0d>
  6f4e36:	8b 94 24 1c 01 00 00 	mov    0x11c(%rsp),%edx
  6f4e3d:	eb 0e                	jmp    6f4e4d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3a0d>
  6f4e3f:	8b 94 24 1c 01 00 00 	mov    0x11c(%rsp),%edx
  6f4e46:	8b b4 24 00 01 00 00 	mov    0x100(%rsp),%esi
  6f4e4d:	0f b6 c8             	movzbl %al,%ecx
  6f4e50:	0c 20                	or     $0x20,%al
  6f4e52:	0f b6 c0             	movzbl %al,%eax
  6f4e55:	84 d2                	test   %dl,%dl
  6f4e57:	0f 44 c1             	cmove  %ecx,%eax
  6f4e5a:	48 89 ac 24 c0 00 00 	mov    %rbp,0xc0(%rsp)
  6f4e61:	00 
  6f4e62:	89 b4 24 d8 00 00 00 	mov    %esi,0xd8(%rsp)
  6f4e69:	44 88 bc 24 dd 00 00 	mov    %r15b,0xdd(%rsp)
  6f4e70:	00 
  6f4e71:	4c 89 a4 24 c8 00 00 	mov    %r12,0xc8(%rsp)
  6f4e78:	00 
  6f4e79:	0f 10 84 24 80 00 00 	movups 0x80(%rsp),%xmm0
  6f4e80:	00 
  6f4e81:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  6f4e88:	00 
  6f4e89:	48 89 9c 24 d0 00 00 	mov    %rbx,0xd0(%rsp)
  6f4e90:	00 
  6f4e91:	0f 10 84 24 b8 02 00 	movups 0x2b8(%rsp),%xmm0
  6f4e98:	00 
  6f4e99:	48 8d 8c 24 a4 00 00 	lea    0xa4(%rsp),%rcx
  6f4ea0:	00 
  6f4ea1:	0f 11 41 0c          	movups %xmm0,0xc(%rcx)
  6f4ea5:	44 88 ac 24 de 00 00 	mov    %r13b,0xde(%rsp)
  6f4eac:	00 
  6f4ead:	88 84 24 dc 00 00 00 	mov    %al,0xdc(%rsp)
  6f4eb4:	0f b6 6c 24 30       	movzbl 0x30(%rsp),%ebp
  6f4eb9:	41 89 ec             	mov    %ebp,%r12d
  6f4ebc:	48 8d bc 24 b8 01 00 	lea    0x1b8(%rsp),%rdi
  6f4ec3:	00 
  6f4ec4:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
  6f4ecb:	00 
  6f4ecc:	e8 9f a2 ff ff       	call   6ef170 <<alloc::vec::Vec<gpui::runtime::Presented>>::push_mut>
  6f4ed1:	83 bc 24 10 07 00 00 	cmpl   $0xffffffff,0x710(%rsp)
  6f4ed8:	ff 
  6f4ed9:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  6f4ede:	0f 84 a9 e4 ff ff    	je     6f338d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1f4d>
  6f4ee4:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  6f4eeb:	00 
  6f4eec:	48 8b 18             	mov    (%rax),%rbx
  6f4eef:	48 85 db             	test   %rbx,%rbx
  6f4ef2:	0f 84 95 e4 ff ff    	je     6f338d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1f4d>
  6f4ef8:	4c 8b 39             	mov    (%rcx),%r15
  6f4efb:	4c 89 bc 24 a0 00 00 	mov    %r15,0xa0(%rsp)
  6f4f02:	00 
  6f4f03:	41 89 ec             	mov    %ebp,%r12d
  6f4f06:	48 8b bc 24 80 07 00 	mov    0x780(%rsp),%rdi
  6f4f0d:	00 
  6f4f0e:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
  6f4f15:	00 
  6f4f16:	e8 d5 39 01 00       	call   7088f0 <<alloc::collections::btree::map::BTreeMap<u64, gpui::property::Overlay<gpui::property::GeometryStyle>>>::get::<u64>>
  6f4f1b:	41 89 ec             	mov    %ebp,%r12d
  6f4f1e:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f4f25:	00 
  6f4f26:	48 89 de             	mov    %rbx,%rsi
  6f4f29:	4c 89 fa             	mov    %r15,%rdx
  6f4f2c:	48 89 c1             	mov    %rax,%rcx
  6f4f2f:	ff 15 ab 69 39 00    	call   *0x3969ab(%rip)        # a8b8e0 <_DYNAMIC+0x488>
  6f4f35:	e9 53 e4 ff ff       	jmp    6f338d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1f4d>
  6f4f3a:	48 8b 8c 24 40 09 00 	mov    0x940(%rsp),%rcx
  6f4f41:	00 
  6f4f42:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  6f4f47:	48 89 4a 30          	mov    %rcx,0x30(%rdx)
  6f4f4b:	0f 28 84 24 30 09 00 	movaps 0x930(%rsp),%xmm0
  6f4f52:	00 
  6f4f53:	0f 11 42 20          	movups %xmm0,0x20(%rdx)
  6f4f57:	0f 28 84 24 70 03 00 	movaps 0x370(%rsp),%xmm0
  6f4f5e:	00 
  6f4f5f:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
  6f4f66:	00 
  6f4f67:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  6f4f6b:	48 89 02             	mov    %rax,(%rdx)
  6f4f6e:	48 89 72 08          	mov    %rsi,0x8(%rdx)
  6f4f72:	41 b4 01             	mov    $0x1,%r12b
  6f4f75:	83 bc 24 10 07 00 00 	cmpl   $0xffffffff,0x710(%rsp)
  6f4f7c:	ff 
  6f4f7d:	41 b7 01             	mov    $0x1,%r15b
  6f4f80:	40 b5 01             	mov    $0x1,%bpl
  6f4f83:	0f 85 fe 11 00 00    	jne    6f6187 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4d47>
  6f4f89:	e9 06 12 00 00       	jmp    6f6194 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4d54>
  6f4f8e:	31 d2                	xor    %edx,%edx
  6f4f90:	48 89 d7             	mov    %rdx,%rdi
  6f4f93:	49 89 c8             	mov    %rcx,%r8
  6f4f96:	49 d1 e8             	shr    $1,%r8
  6f4f99:	4c 01 c2             	add    %r8,%rdx
  6f4f9c:	4c 8d 0c 52          	lea    (%rdx,%rdx,2),%r9
  6f4fa0:	4a 39 34 88          	cmp    %rsi,(%rax,%r9,4)
  6f4fa4:	48 0f 47 d7          	cmova  %rdi,%rdx
  6f4fa8:	4c 29 c1             	sub    %r8,%rcx
  6f4fab:	48 83 f9 01          	cmp    $0x1,%rcx
  6f4faf:	77 df                	ja     6f4f90 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3b50>
  6f4fb1:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
  6f4fb5:	48 39 34 88          	cmp    %rsi,(%rax,%rcx,4)
  6f4fb9:	0f 85 27 c8 ff ff    	jne    6f17e6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3a6>
  6f4fbf:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
  6f4fc3:	8b 70 08             	mov    0x8(%rax),%esi
  6f4fc6:	4c 89 ef             	mov    %r13,%rdi
  6f4fc9:	e8 72 65 ff ff       	call   6eb540 <<gpui::runtime::Runtime<route_columns_cost::Page>>::editing_at>
  6f4fce:	48 85 c0             	test   %rax,%rax
  6f4fd1:	0f 84 0f c8 ff ff    	je     6f17e6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3a6>
  6f4fd7:	48 8b 08             	mov    (%rax),%rcx
  6f4fda:	48 89 8c 24 90 07 00 	mov    %rcx,0x790(%rsp)
  6f4fe1:	00 
  6f4fe2:	8b 48 18             	mov    0x18(%rax),%ecx
  6f4fe5:	89 8c 24 74 01 00 00 	mov    %ecx,0x174(%rsp)
  6f4fec:	0f b6 48 1c          	movzbl 0x1c(%rax),%ecx
  6f4ff0:	88 4c 24 7e          	mov    %cl,0x7e(%rsp)
  6f4ff4:	0f b6 48 1f          	movzbl 0x1f(%rax),%ecx
  6f4ff8:	88 8c 24 f2 00 00 00 	mov    %cl,0xf2(%rsp)
  6f4fff:	0f b7 48 1d          	movzwl 0x1d(%rax),%ecx
  6f5003:	66 89 8c 24 f0 00 00 	mov    %cx,0xf0(%rsp)
  6f500a:	00 
  6f500b:	8b 48 20             	mov    0x20(%rax),%ecx
  6f500e:	89 8c 24 d4 01 00 00 	mov    %ecx,0x1d4(%rsp)
  6f5015:	0f b6 48 24          	movzbl 0x24(%rax),%ecx
  6f5019:	88 4c 24 70          	mov    %cl,0x70(%rsp)
  6f501d:	0f b6 48 27          	movzbl 0x27(%rax),%ecx
  6f5021:	88 8c 24 ee 00 00 00 	mov    %cl,0xee(%rsp)
  6f5028:	0f b7 40 25          	movzwl 0x25(%rax),%eax
  6f502c:	66 89 84 24 ec 00 00 	mov    %ax,0xec(%rsp)
  6f5033:	00 
  6f5034:	e9 b2 c7 ff ff       	jmp    6f17eb <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3ab>
  6f5039:	31 d2                	xor    %edx,%edx
  6f503b:	48 89 d7             	mov    %rdx,%rdi
  6f503e:	49 89 c8             	mov    %rcx,%r8
  6f5041:	49 d1 e8             	shr    $1,%r8
  6f5044:	4c 01 c2             	add    %r8,%rdx
  6f5047:	4c 8d 0c 52          	lea    (%rdx,%rdx,2),%r9
  6f504b:	4a 39 34 88          	cmp    %rsi,(%rax,%r9,4)
  6f504f:	48 0f 47 d7          	cmova  %rdi,%rdx
  6f5053:	4c 29 c1             	sub    %r8,%rcx
  6f5056:	48 83 f9 01          	cmp    $0x1,%rcx
  6f505a:	77 df                	ja     6f503b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3bfb>
  6f505c:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
  6f5060:	48 39 34 88          	cmp    %rsi,(%rax,%rcx,4)
  6f5064:	0f 85 ae c7 ff ff    	jne    6f1818 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3d8>
  6f506a:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
  6f506e:	8b 70 08             	mov    0x8(%rax),%esi
  6f5071:	4c 89 ef             	mov    %r13,%rdi
  6f5074:	e8 c7 64 ff ff       	call   6eb540 <<gpui::runtime::Runtime<route_columns_cost::Page>>::editing_at>
  6f5079:	48 85 c0             	test   %rax,%rax
  6f507c:	0f 84 96 c7 ff ff    	je     6f1818 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3d8>
  6f5082:	0f b6 48 24          	movzbl 0x24(%rax),%ecx
  6f5086:	80 f9 02             	cmp    $0x2,%cl
  6f5089:	0f 84 89 c7 ff ff    	je     6f1818 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3d8>
  6f508f:	48 8b 10             	mov    (%rax),%rdx
  6f5092:	48 89 94 24 70 07 00 	mov    %rdx,0x770(%rsp)
  6f5099:	00 
  6f509a:	48 85 d2             	test   %rdx,%rdx
  6f509d:	0f 84 95 13 00 00    	je     6f6438 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4ff8>
  6f50a3:	48 8d 50 18          	lea    0x18(%rax),%rdx
  6f50a7:	48 83 c0 25          	add    $0x25,%rax
  6f50ab:	8b 72 08             	mov    0x8(%rdx),%esi
  6f50ae:	89 b4 24 b0 03 00 00 	mov    %esi,0x3b0(%rsp)
  6f50b5:	48 8b 12             	mov    (%rdx),%rdx
  6f50b8:	48 89 94 24 a8 03 00 	mov    %rdx,0x3a8(%rsp)
  6f50bf:	00 
  6f50c0:	0f b7 10             	movzwl (%rax),%edx
  6f50c3:	66 89 94 24 f4 00 00 	mov    %dx,0xf4(%rsp)
  6f50ca:	00 
  6f50cb:	0f b6 40 02          	movzbl 0x2(%rax),%eax
  6f50cf:	88 84 24 f6 00 00 00 	mov    %al,0xf6(%rsp)
  6f50d6:	88 4c 24 57          	mov    %cl,0x57(%rsp)
  6f50da:	e9 39 c7 ff ff       	jmp    6f1818 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3d8>
  6f50df:	83 bc 24 10 07 00 00 	cmpl   $0xffffffff,0x710(%rsp)
  6f50e6:	ff 
  6f50e7:	74 0e                	je     6f50f7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3cb7>
  6f50e9:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f50f0:	00 
  6f50f1:	ff 15 f1 67 39 00    	call   *0x3967f1(%rip)        # a8b8e8 <_DYNAMIC+0x490>
  6f50f7:	49 8d 9d e8 01 00 00 	lea    0x1e8(%r13),%rbx
  6f50fe:	49 8b 85 40 06 00 00 	mov    0x640(%r13),%rax
  6f5105:	48 85 c0             	test   %rax,%rax
  6f5108:	0f 84 db 00 00 00    	je     6f51e9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3da9>
  6f510e:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
  6f5115:	48 8d 84 24 c8 02 00 	lea    0x2c8(%rsp),%rax
  6f511c:	00 
  6f511d:	48 89 84 24 70 04 00 	mov    %rax,0x470(%rsp)
  6f5124:	00 
  6f5125:	48 8d 44 24 2f       	lea    0x2f(%rsp),%rax
  6f512a:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
  6f5131:	00 
  6f5132:	48 89 9c 24 80 04 00 	mov    %rbx,0x480(%rsp)
  6f5139:	00 
  6f513a:	48 8d 84 24 58 01 00 	lea    0x158(%rsp),%rax
  6f5141:	00 
  6f5142:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
  6f5149:	00 
  6f514a:	48 8d 84 24 b8 01 00 	lea    0x1b8(%rsp),%rax
  6f5151:	00 
  6f5152:	48 89 84 24 90 04 00 	mov    %rax,0x490(%rsp)
  6f5159:	00 
  6f515a:	48 85 d2             	test   %rdx,%rdx
  6f515d:	0f 84 86 00 00 00    	je     6f51e9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3da9>
  6f5163:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
  6f516a:	00 
  6f516b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
  6f5172:	00 
  6f5173:	e8 98 30 ff ff       	call   6e8210 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner::{closure#36}>
  6f5178:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  6f517f:	00 
  6f5180:	48 89 84 24 80 03 00 	mov    %rax,0x380(%rsp)
  6f5187:	00 
  6f5188:	0f 10 84 24 a0 00 00 	movups 0xa0(%rsp),%xmm0
  6f518f:	00 
  6f5190:	0f 29 84 24 70 03 00 	movaps %xmm0,0x370(%rsp)
  6f5197:	00 
  6f5198:	eb 5b                	jmp    6f51f5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3db5>
  6f519a:	0f 28 84 24 30 09 00 	movaps 0x930(%rsp),%xmm0
  6f51a1:	00 
  6f51a2:	0f 28 8c 24 40 09 00 	movaps 0x940(%rsp),%xmm1
  6f51a9:	00 
  6f51aa:	0f 28 94 24 50 09 00 	movaps 0x950(%rsp),%xmm2
  6f51b1:	00 
  6f51b2:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  6f51b7:	0f 11 51 28          	movups %xmm2,0x28(%rcx)
  6f51bb:	0f 11 49 18          	movups %xmm1,0x18(%rcx)
  6f51bf:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
  6f51c3:	48 89 01             	mov    %rax,(%rcx)
  6f51c6:	41 b4 01             	mov    $0x1,%r12b
  6f51c9:	41 b6 01             	mov    $0x1,%r14b
  6f51cc:	41 b7 01             	mov    $0x1,%r15b
  6f51cf:	40 b5 01             	mov    $0x1,%bpl
  6f51d2:	41 b5 01             	mov    $0x1,%r13b
  6f51d5:	48 83 bc 24 90 02 00 	cmpq   $0xffffffffffffffff,0x290(%rsp)
  6f51dc:	00 ff 
  6f51de:	0f 85 84 0f 00 00    	jne    6f6168 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4d28>
  6f51e4:	e9 8f 0f 00 00       	jmp    6f6178 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4d38>
  6f51e9:	48 c7 84 24 70 03 00 	movq   $0xffffffffffffffff,0x370(%rsp)
  6f51f0:	00 ff ff ff ff 
  6f51f5:	48 89 5c 24 60       	mov    %rbx,0x60(%rsp)
  6f51fa:	48 8b 84 24 d8 02 00 	mov    0x2d8(%rsp),%rax
  6f5201:	00 
  6f5202:	48 89 84 24 80 04 00 	mov    %rax,0x480(%rsp)
  6f5209:	00 
  6f520a:	0f 10 84 24 c8 02 00 	movups 0x2c8(%rsp),%xmm0
  6f5211:	00 
  6f5212:	0f 29 84 24 70 04 00 	movaps %xmm0,0x470(%rsp)
  6f5219:	00 
  6f521a:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  6f5221:	00 
  6f5222:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
  6f5229:	00 
  6f522a:	48 8d 94 24 70 04 00 	lea    0x470(%rsp),%rdx
  6f5231:	00 
  6f5232:	e8 b9 c2 fe ff       	call   6e14f0 <<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner::{closure#37}>>
  6f5237:	41 80 bd 4d 07 00 00 	cmpb   $0x0,0x74d(%r13)
  6f523e:	00 
  6f523f:	74 4f                	je     6f5290 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3e50>
  6f5241:	48 8d 9c 24 70 04 00 	lea    0x470(%rsp),%rbx
  6f5248:	00 
  6f5249:	48 8d b4 24 30 09 00 	lea    0x930(%rsp),%rsi
  6f5250:	00 
  6f5251:	ba f0 01 00 00       	mov    $0x1f0,%edx
  6f5256:	48 89 df             	mov    %rbx,%rdi
  6f5259:	ff 15 59 64 39 00    	call   *0x396459(%rip)        # a8b6b8 <memcpy@GLIBC_2.14>
  6f525f:	41 b7 01             	mov    $0x1,%r15b
  6f5262:	41 b4 01             	mov    $0x1,%r12b
  6f5265:	b0 01                	mov    $0x1,%al
  6f5267:	89 44 24 48          	mov    %eax,0x48(%rsp)
  6f526b:	41 b6 01             	mov    $0x1,%r14b
  6f526e:	41 b5 01             	mov    $0x1,%r13b
  6f5271:	40 b5 01             	mov    $0x1,%bpl
  6f5274:	c6 44 24 58 01       	movb   $0x1,0x58(%rsp)
  6f5279:	48 89 df             	mov    %rbx,%rdi
  6f527c:	ff 15 2e 68 39 00    	call   *0x39682e(%rip)        # a8bab0 <_DYNAMIC+0x658>
  6f5282:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
  6f5289:	00 00 
  6f528b:	e9 83 00 00 00       	jmp    6f5313 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3ed3>
  6f5290:	48 8d 9c 24 70 04 00 	lea    0x470(%rsp),%rbx
  6f5297:	00 
  6f5298:	48 8d b4 24 30 09 00 	lea    0x930(%rsp),%rsi
  6f529f:	00 
  6f52a0:	ba f0 01 00 00       	mov    $0x1f0,%edx
  6f52a5:	48 89 df             	mov    %rbx,%rdi
  6f52a8:	ff 15 0a 64 39 00    	call   *0x39640a(%rip)        # a8b6b8 <memcpy@GLIBC_2.14>
  6f52ae:	41 b7 01             	mov    $0x1,%r15b
  6f52b1:	41 b4 01             	mov    $0x1,%r12b
  6f52b4:	b0 01                	mov    $0x1,%al
  6f52b6:	89 44 24 48          	mov    %eax,0x48(%rsp)
  6f52ba:	41 b6 01             	mov    $0x1,%r14b
  6f52bd:	41 b5 01             	mov    $0x1,%r13b
  6f52c0:	40 b5 01             	mov    $0x1,%bpl
  6f52c3:	c6 44 24 58 01       	movb   $0x1,0x58(%rsp)
  6f52c8:	48 89 df             	mov    %rbx,%rdi
  6f52cb:	ff 15 e7 67 39 00    	call   *0x3967e7(%rip)        # a8bab8 <_DYNAMIC+0x660>
  6f52d1:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  6f52d6:	48 83 b9 88 05 00 00 	cmpq   $0xffffffffffffffff,0x588(%rcx)
  6f52dd:	ff 
  6f52de:	74 09                	je     6f52e9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3ea9>
  6f52e0:	48 8b b1 a0 05 00 00 	mov    0x5a0(%rcx),%rsi
  6f52e7:	eb 02                	jmp    6f52eb <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3eab>
  6f52e9:	31 f6                	xor    %esi,%esi
  6f52eb:	41 b7 01             	mov    $0x1,%r15b
  6f52ee:	41 b4 01             	mov    $0x1,%r12b
  6f52f1:	b1 01                	mov    $0x1,%cl
  6f52f3:	89 4c 24 48          	mov    %ecx,0x48(%rsp)
  6f52f7:	41 b6 01             	mov    $0x1,%r14b
  6f52fa:	41 b5 01             	mov    $0x1,%r13b
  6f52fd:	40 b5 01             	mov    $0x1,%bpl
  6f5300:	c6 44 24 58 01       	movb   $0x1,0x58(%rsp)
  6f5305:	48 89 c7             	mov    %rax,%rdi
  6f5308:	ff 15 aa 65 39 00    	call   *0x3965aa(%rip)        # a8b8b8 <_DYNAMIC+0x460>
  6f530e:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  6f5313:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  6f5318:	48 8b 81 48 06 00 00 	mov    0x648(%rcx),%rax
  6f531f:	4c 8b a1 58 06 00 00 	mov    0x658(%rcx),%r12
  6f5326:	48 85 c0             	test   %rax,%rax
  6f5329:	0f 95 c1             	setne  %cl
  6f532c:	4d 85 e4             	test   %r12,%r12
  6f532f:	0f 95 c2             	setne  %dl
  6f5332:	20 ca                	and    %cl,%dl
  6f5334:	80 fa 01             	cmp    $0x1,%dl
  6f5337:	0f 85 26 02 00 00    	jne    6f5563 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4123>
  6f533d:	45 31 ed             	xor    %r13d,%r13d
  6f5340:	48 85 c0             	test   %rax,%rax
  6f5343:	41 0f 95 c5          	setne  %r13b
  6f5347:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  6f534c:	48 8b 99 50 06 00 00 	mov    0x650(%rcx),%rbx
  6f5353:	31 ed                	xor    %ebp,%ebp
  6f5355:	4c 8d bc 24 40 03 00 	lea    0x340(%rsp),%r15
  6f535c:	00 
  6f535d:	eb 0e                	jmp    6f536d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3f2d>
  6f535f:	b8 00 00 00 00       	mov    $0x0,%eax
  6f5364:	49 ff cc             	dec    %r12
  6f5367:	0f 84 f6 01 00 00    	je     6f5563 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4123>
  6f536d:	48 85 ed             	test   %rbp,%rbp
  6f5370:	75 45                	jne    6f53b7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3f77>
  6f5372:	41 f6 c5 01          	test   $0x1,%r13b
  6f5376:	74 3f                	je     6f53b7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3f77>
  6f5378:	41 bd 01 00 00 00    	mov    $0x1,%r13d
  6f537e:	48 85 db             	test   %rbx,%rbx
  6f5381:	74 55                	je     6f53d8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3f98>
  6f5383:	48 89 d9             	mov    %rbx,%rcx
  6f5386:	48 89 c5             	mov    %rax,%rbp
  6f5389:	48 83 e1 07          	and    $0x7,%rcx
  6f538d:	74 4e                	je     6f53dd <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3f9d>
  6f538f:	31 d2                	xor    %edx,%edx
  6f5391:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f5398:	0f 1f 84 00 00 00 00 
  6f539f:	00 
  6f53a0:	48 8b ad 90 05 00 00 	mov    0x590(%rbp),%rbp
  6f53a7:	48 ff c2             	inc    %rdx
  6f53aa:	48 39 d1             	cmp    %rdx,%rcx
  6f53ad:	75 f1                	jne    6f53a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3f60>
  6f53af:	48 89 d8             	mov    %rbx,%rax
  6f53b2:	48 29 d0             	sub    %rdx,%rax
  6f53b5:	eb 29                	jmp    6f53e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3fa0>
  6f53b7:	41 f6 c5 01          	test   $0x1,%r13b
  6f53bb:	0f 84 fb 0e 00 00    	je     6f62bc <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4e7c>
  6f53c1:	0f b7 8d 8a 05 00 00 	movzwl 0x58a(%rbp),%ecx
  6f53c8:	48 39 cb             	cmp    %rcx,%rbx
  6f53cb:	73 73                	jae    6f5440 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4000>
  6f53cd:	48 89 e9             	mov    %rbp,%rcx
  6f53d0:	48 89 da             	mov    %rbx,%rdx
  6f53d3:	e9 8e 00 00 00       	jmp    6f5466 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4026>
  6f53d8:	48 89 c5             	mov    %rax,%rbp
  6f53db:	eb 51                	jmp    6f542e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3fee>
  6f53dd:	48 89 d8             	mov    %rbx,%rax
  6f53e0:	48 83 fb 08          	cmp    $0x8,%rbx
  6f53e4:	72 48                	jb     6f542e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3fee>
  6f53e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6f53ed:	00 00 00 
  6f53f0:	48 8b 8d 90 05 00 00 	mov    0x590(%rbp),%rcx
  6f53f7:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  6f53fe:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  6f5405:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  6f540c:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  6f5413:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  6f541a:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  6f5421:	48 8b a9 90 05 00 00 	mov    0x590(%rcx),%rbp
  6f5428:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  6f542c:	75 c2                	jne    6f53f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3fb0>
  6f542e:	31 db                	xor    %ebx,%ebx
  6f5430:	31 c0                	xor    %eax,%eax
  6f5432:	0f b7 8d 8a 05 00 00 	movzwl 0x58a(%rbp),%ecx
  6f5439:	48 39 cb             	cmp    %rcx,%rbx
  6f543c:	72 8f                	jb     6f53cd <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3f8d>
  6f543e:	66 90                	xchg   %ax,%ax
  6f5440:	48 8b 8d 80 05 00 00 	mov    0x580(%rbp),%rcx
  6f5447:	48 85 c9             	test   %rcx,%rcx
  6f544a:	0f 84 41 10 00 00    	je     6f6491 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5051>
  6f5450:	48 ff c0             	inc    %rax
  6f5453:	0f b7 95 88 05 00 00 	movzwl 0x588(%rbp),%edx
  6f545a:	48 89 cd             	mov    %rcx,%rbp
  6f545d:	66 3b 91 8a 05 00 00 	cmp    0x58a(%rcx),%dx
  6f5464:	73 da                	jae    6f5440 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4000>
  6f5466:	48 85 c0             	test   %rax,%rax
  6f5469:	74 3f                	je     6f54aa <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x406a>
  6f546b:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
  6f546f:	48 81 c6 98 05 00 00 	add    $0x598,%rsi
  6f5476:	48 89 c7             	mov    %rax,%rdi
  6f5479:	48 83 e7 07          	and    $0x7,%rdi
  6f547d:	74 34                	je     6f54b3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4073>
  6f547f:	45 31 c0             	xor    %r8d,%r8d
  6f5482:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f5489:	1f 84 00 00 00 00 00 
  6f5490:	48 8b 2e             	mov    (%rsi),%rbp
  6f5493:	48 8d b5 90 05 00 00 	lea    0x590(%rbp),%rsi
  6f549a:	49 ff c0             	inc    %r8
  6f549d:	4c 39 c7             	cmp    %r8,%rdi
  6f54a0:	75 ee                	jne    6f5490 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4050>
  6f54a2:	48 89 c7             	mov    %rax,%rdi
  6f54a5:	4c 29 c7             	sub    %r8,%rdi
  6f54a8:	eb 0c                	jmp    6f54b6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4076>
  6f54aa:	48 8d 5a 01          	lea    0x1(%rdx),%rbx
  6f54ae:	48 89 cd             	mov    %rcx,%rbp
  6f54b1:	eb 50                	jmp    6f5503 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x40c3>
  6f54b3:	48 89 c7             	mov    %rax,%rdi
  6f54b6:	48 83 f8 08          	cmp    $0x8,%rax
  6f54ba:	72 45                	jb     6f5501 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x40c1>
  6f54bc:	0f 1f 40 00          	nopl   0x0(%rax)
  6f54c0:	48 8b 06             	mov    (%rsi),%rax
  6f54c3:	48 8b 80 90 05 00 00 	mov    0x590(%rax),%rax
  6f54ca:	48 8b 80 90 05 00 00 	mov    0x590(%rax),%rax
  6f54d1:	48 8b 80 90 05 00 00 	mov    0x590(%rax),%rax
  6f54d8:	48 8b 80 90 05 00 00 	mov    0x590(%rax),%rax
  6f54df:	48 8b 80 90 05 00 00 	mov    0x590(%rax),%rax
  6f54e6:	48 8b 80 90 05 00 00 	mov    0x590(%rax),%rax
  6f54ed:	48 8b a8 90 05 00 00 	mov    0x590(%rax),%rbp
  6f54f4:	48 8d b5 90 05 00 00 	lea    0x590(%rbp),%rsi
  6f54fb:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  6f54ff:	75 bf                	jne    6f54c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4080>
  6f5501:	31 db                	xor    %ebx,%ebx
  6f5503:	48 89 d0             	mov    %rdx,%rax
  6f5506:	48 c1 e0 04          	shl    $0x4,%rax
  6f550a:	80 3c 01 00          	cmpb   $0x0,(%rcx,%rax,1)
  6f550e:	0f 84 4b fe ff ff    	je     6f535f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3f1f>
  6f5514:	48 6b d2 70          	imul   $0x70,%rdx,%rdx
  6f5518:	4c 8d 34 11          	lea    (%rcx,%rdx,1),%r14
  6f551c:	49 81 c6 b0 00 00 00 	add    $0xb0,%r14
  6f5523:	41 83 3e 02          	cmpl   $0x2,(%r14)
  6f5527:	0f 85 32 fe ff ff    	jne    6f535f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3f1f>
  6f552d:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
  6f5532:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f5539:	00 
  6f553a:	4c 89 fe             	mov    %r15,%rsi
  6f553d:	ff 15 d5 64 39 00    	call   *0x3964d5(%rip)        # a8ba18 <_DYNAMIC+0x5c0>
  6f5543:	83 bc 24 70 04 00 00 	cmpl   $0x1,0x470(%rsp)
  6f554a:	01 
  6f554b:	0f 85 0e fe ff ff    	jne    6f535f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3f1f>
  6f5551:	0f 10 84 24 78 04 00 	movups 0x478(%rsp),%xmm0
  6f5558:	00 
  6f5559:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
  6f555e:	e9 fc fd ff ff       	jmp    6f535f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x3f1f>
  6f5563:	4c 8b 64 24 40       	mov    0x40(%rsp),%r12
  6f5568:	4d 8b 8c 24 60 06 00 	mov    0x660(%r12),%r9
  6f556f:	00 
  6f5570:	49 8b 84 24 70 06 00 	mov    0x670(%r12),%rax
  6f5577:	00 
  6f5578:	4d 85 c9             	test   %r9,%r9
  6f557b:	0f 95 c1             	setne  %cl
  6f557e:	48 85 c0             	test   %rax,%rax
  6f5581:	0f 95 c2             	setne  %dl
  6f5584:	20 ca                	and    %cl,%dl
  6f5586:	80 fa 01             	cmp    $0x1,%dl
  6f5589:	48 8b 9c 24 00 03 00 	mov    0x300(%rsp),%rbx
  6f5590:	00 
  6f5591:	0f 85 52 02 00 00    	jne    6f57e9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x43a9>
  6f5597:	31 c9                	xor    %ecx,%ecx
  6f5599:	4d 85 c9             	test   %r9,%r9
  6f559c:	0f 95 c1             	setne  %cl
  6f559f:	49 8b b4 24 68 06 00 	mov    0x668(%r12),%rsi
  6f55a6:	00 
  6f55a7:	31 d2                	xor    %edx,%edx
  6f55a9:	eb 20                	jmp    6f55cb <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x418b>
  6f55ab:	45 31 c9             	xor    %r9d,%r9d
  6f55ae:	48 ff c8             	dec    %rax
  6f55b1:	49 c1 e0 05          	shl    $0x5,%r8
  6f55b5:	4c 01 c7             	add    %r8,%rdi
  6f55b8:	44 88 4f 1c          	mov    %r9b,0x1c(%rdi)
  6f55bc:	41 b9 00 00 00 00    	mov    $0x0,%r9d
  6f55c2:	48 85 c0             	test   %rax,%rax
  6f55c5:	0f 84 1e 02 00 00    	je     6f57e9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x43a9>
  6f55cb:	48 85 d2             	test   %rdx,%rdx
  6f55ce:	75 37                	jne    6f5607 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x41c7>
  6f55d0:	f6 c1 01             	test   $0x1,%cl
  6f55d3:	74 32                	je     6f5607 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x41c7>
  6f55d5:	b9 01 00 00 00       	mov    $0x1,%ecx
  6f55da:	48 85 f6             	test   %rsi,%rsi
  6f55dd:	74 48                	je     6f5627 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x41e7>
  6f55df:	48 89 f7             	mov    %rsi,%rdi
  6f55e2:	4c 89 ca             	mov    %r9,%rdx
  6f55e5:	48 83 e7 07          	and    $0x7,%rdi
  6f55e9:	74 41                	je     6f562c <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x41ec>
  6f55eb:	45 31 c0             	xor    %r8d,%r8d
  6f55ee:	66 90                	xchg   %ax,%ax
  6f55f0:	48 8b 92 c8 01 00 00 	mov    0x1c8(%rdx),%rdx
  6f55f7:	49 ff c0             	inc    %r8
  6f55fa:	4c 39 c7             	cmp    %r8,%rdi
  6f55fd:	75 f1                	jne    6f55f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x41b0>
  6f55ff:	48 89 f7             	mov    %rsi,%rdi
  6f5602:	4c 29 c7             	sub    %r8,%rdi
  6f5605:	eb 28                	jmp    6f562f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x41ef>
  6f5607:	f6 c1 01             	test   $0x1,%cl
  6f560a:	0f 84 ac 0c 00 00    	je     6f62bc <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4e7c>
  6f5610:	0f b7 ba c2 01 00 00 	movzwl 0x1c2(%rdx),%edi
  6f5617:	48 39 fe             	cmp    %rdi,%rsi
  6f561a:	73 74                	jae    6f5690 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4250>
  6f561c:	48 89 d7             	mov    %rdx,%rdi
  6f561f:	49 89 f0             	mov    %rsi,%r8
  6f5622:	e9 91 00 00 00       	jmp    6f56b8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4278>
  6f5627:	4c 89 ca             	mov    %r9,%rdx
  6f562a:	eb 52                	jmp    6f567e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x423e>
  6f562c:	48 89 f7             	mov    %rsi,%rdi
  6f562f:	48 83 fe 08          	cmp    $0x8,%rsi
  6f5633:	72 49                	jb     6f567e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x423e>
  6f5635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6f563c:	00 00 00 00 
  6f5640:	48 8b 92 c8 01 00 00 	mov    0x1c8(%rdx),%rdx
  6f5647:	48 8b 92 c8 01 00 00 	mov    0x1c8(%rdx),%rdx
  6f564e:	48 8b 92 c8 01 00 00 	mov    0x1c8(%rdx),%rdx
  6f5655:	48 8b 92 c8 01 00 00 	mov    0x1c8(%rdx),%rdx
  6f565c:	48 8b 92 c8 01 00 00 	mov    0x1c8(%rdx),%rdx
  6f5663:	48 8b 92 c8 01 00 00 	mov    0x1c8(%rdx),%rdx
  6f566a:	48 8b 92 c8 01 00 00 	mov    0x1c8(%rdx),%rdx
  6f5671:	48 8b 92 c8 01 00 00 	mov    0x1c8(%rdx),%rdx
  6f5678:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  6f567c:	75 c2                	jne    6f5640 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4200>
  6f567e:	45 31 c9             	xor    %r9d,%r9d
  6f5681:	31 f6                	xor    %esi,%esi
  6f5683:	0f b7 ba c2 01 00 00 	movzwl 0x1c2(%rdx),%edi
  6f568a:	48 39 fe             	cmp    %rdi,%rsi
  6f568d:	72 8d                	jb     6f561c <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x41dc>
  6f568f:	90                   	nop
  6f5690:	48 8b ba 60 01 00 00 	mov    0x160(%rdx),%rdi
  6f5697:	48 85 ff             	test   %rdi,%rdi
  6f569a:	0f 84 03 0e 00 00    	je     6f64a3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5063>
  6f56a0:	49 ff c1             	inc    %r9
  6f56a3:	44 0f b7 82 c0 01 00 	movzwl 0x1c0(%rdx),%r8d
  6f56aa:	00 
  6f56ab:	48 89 fa             	mov    %rdi,%rdx
  6f56ae:	66 44 3b 87 c2 01 00 	cmp    0x1c2(%rdi),%r8w
  6f56b5:	00 
  6f56b6:	73 d8                	jae    6f5690 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4250>
  6f56b8:	4d 85 c9             	test   %r9,%r9
  6f56bb:	74 3d                	je     6f56fa <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x42ba>
  6f56bd:	4a 8d 34 c7          	lea    (%rdi,%r8,8),%rsi
  6f56c1:	48 81 c6 d0 01 00 00 	add    $0x1d0,%rsi
  6f56c8:	4d 89 ca             	mov    %r9,%r10
  6f56cb:	49 83 e2 07          	and    $0x7,%r10
  6f56cf:	4c 8b 64 24 40       	mov    0x40(%rsp),%r12
  6f56d4:	74 32                	je     6f5708 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x42c8>
  6f56d6:	45 31 db             	xor    %r11d,%r11d
  6f56d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6f56e0:	48 8b 16             	mov    (%rsi),%rdx
  6f56e3:	48 8d b2 c8 01 00 00 	lea    0x1c8(%rdx),%rsi
  6f56ea:	49 ff c3             	inc    %r11
  6f56ed:	4d 39 da             	cmp    %r11,%r10
  6f56f0:	75 ee                	jne    6f56e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x42a0>
  6f56f2:	4d 89 ca             	mov    %r9,%r10
  6f56f5:	4d 29 da             	sub    %r11,%r10
  6f56f8:	eb 11                	jmp    6f570b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x42cb>
  6f56fa:	49 8d 70 01          	lea    0x1(%r8),%rsi
  6f56fe:	48 89 fa             	mov    %rdi,%rdx
  6f5701:	4c 8b 64 24 40       	mov    0x40(%rsp),%r12
  6f5706:	eb 5b                	jmp    6f5763 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4323>
  6f5708:	4d 89 ca             	mov    %r9,%r10
  6f570b:	49 83 f9 08          	cmp    $0x8,%r9
  6f570f:	72 50                	jb     6f5761 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4321>
  6f5711:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f5718:	0f 1f 84 00 00 00 00 
  6f571f:	00 
  6f5720:	48 8b 16             	mov    (%rsi),%rdx
  6f5723:	48 8b 92 c8 01 00 00 	mov    0x1c8(%rdx),%rdx
  6f572a:	48 8b 92 c8 01 00 00 	mov    0x1c8(%rdx),%rdx
  6f5731:	48 8b 92 c8 01 00 00 	mov    0x1c8(%rdx),%rdx
  6f5738:	48 8b 92 c8 01 00 00 	mov    0x1c8(%rdx),%rdx
  6f573f:	48 8b 92 c8 01 00 00 	mov    0x1c8(%rdx),%rdx
  6f5746:	48 8b 92 c8 01 00 00 	mov    0x1c8(%rdx),%rdx
  6f574d:	48 8b 92 c8 01 00 00 	mov    0x1c8(%rdx),%rdx
  6f5754:	48 8d b2 c8 01 00 00 	lea    0x1c8(%rdx),%rsi
  6f575b:	49 83 c2 f8          	add    $0xfffffffffffffff8,%r10
  6f575f:	75 bf                	jne    6f5720 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x42e0>
  6f5761:	31 f6                	xor    %esi,%esi
  6f5763:	4c 8b 8c 24 b8 03 00 	mov    0x3b8(%rsp),%r9
  6f576a:	00 
  6f576b:	4d 85 c9             	test   %r9,%r9
  6f576e:	0f 84 37 fe ff ff    	je     6f55ab <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x416b>
  6f5774:	49 89 dd             	mov    %rbx,%r13
  6f5777:	4e 8b 94 c7 68 01 00 	mov    0x168(%rdi,%r8,8),%r10
  6f577e:	00 
  6f577f:	4c 8b 9c 24 c0 03 00 	mov    0x3c0(%rsp),%r11
  6f5786:	00 
  6f5787:	45 0f b7 71 62       	movzwl 0x62(%r9),%r14d
  6f578c:	45 89 f7             	mov    %r14d,%r15d
  6f578f:	41 c1 e7 03          	shl    $0x3,%r15d
  6f5793:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
  6f579a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  6f57a0:	4d 85 ff             	test   %r15,%r15
  6f57a3:	74 24                	je     6f57c9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4389>
  6f57a5:	4d 3b 54 d9 10       	cmp    0x10(%r9,%rbx,8),%r10
  6f57aa:	40 0f 97 c5          	seta   %bpl
  6f57ae:	40 80 dd 00          	sbb    $0x0,%bpl
  6f57b2:	48 ff c3             	inc    %rbx
  6f57b5:	49 83 c7 f8          	add    $0xfffffffffffffff8,%r15
  6f57b9:	40 80 fd 01          	cmp    $0x1,%bpl
  6f57bd:	74 e1                	je     6f57a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4360>
  6f57bf:	40 0f b6 ed          	movzbl %bpl,%ebp
  6f57c3:	85 ed                	test   %ebp,%ebp
  6f57c5:	75 05                	jne    6f57cc <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x438c>
  6f57c7:	eb 10                	jmp    6f57d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4399>
  6f57c9:	4c 89 f3             	mov    %r14,%rbx
  6f57cc:	49 83 eb 01          	sub    $0x1,%r11
  6f57d0:	72 12                	jb     6f57e4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x43a4>
  6f57d2:	4d 8b 4c d9 68       	mov    0x68(%r9,%rbx,8),%r9
  6f57d7:	eb ae                	jmp    6f5787 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4347>
  6f57d9:	41 b1 01             	mov    $0x1,%r9b
  6f57dc:	4c 89 eb             	mov    %r13,%rbx
  6f57df:	e9 ca fd ff ff       	jmp    6f55ae <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x416e>
  6f57e4:	45 31 c9             	xor    %r9d,%r9d
  6f57e7:	eb f3                	jmp    6f57dc <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x439c>
  6f57e9:	41 b7 01             	mov    $0x1,%r15b
  6f57ec:	83 bc 24 e0 0b 00 00 	cmpl   $0x2,0xbe0(%rsp)
  6f57f3:	02 
  6f57f4:	40 b5 01             	mov    $0x1,%bpl
  6f57f7:	74 3b                	je     6f5834 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x43f4>
  6f57f9:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f5800:	00 
  6f5801:	48 8d b4 24 e0 0b 00 	lea    0xbe0(%rsp),%rsi
  6f5808:	00 
  6f5809:	ba e8 01 00 00       	mov    $0x1e8,%edx
  6f580e:	ff 15 a4 5e 39 00    	call   *0x395ea4(%rip)        # a8b6b8 <memcpy@GLIBC_2.14>
  6f5814:	4c 89 e7             	mov    %r12,%rdi
  6f5817:	e8 e4 fc fe ff       	call   6e5500 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  6f581c:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
  6f5823:	00 
  6f5824:	ba e8 01 00 00       	mov    $0x1e8,%edx
  6f5829:	4c 89 e7             	mov    %r12,%rdi
  6f582c:	ff 15 86 5e 39 00    	call   *0x395e86(%rip)        # a8b6b8 <memcpy@GLIBC_2.14>
  6f5832:	31 ed                	xor    %ebp,%ebp
  6f5834:	83 bc 24 10 07 00 00 	cmpl   $0xffffffff,0x710(%rsp)
  6f583b:	ff 
  6f583c:	41 b6 01             	mov    $0x1,%r14b
  6f583f:	0f 84 bc 01 00 00    	je     6f5a01 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x45c1>
  6f5845:	0f 10 84 24 60 07 00 	movups 0x760(%rsp),%xmm0
  6f584c:	00 
  6f584d:	0f 29 84 24 60 04 00 	movaps %xmm0,0x460(%rsp)
  6f5854:	00 
  6f5855:	0f 10 84 24 50 07 00 	movups 0x750(%rsp),%xmm0
  6f585c:	00 
  6f585d:	0f 29 84 24 50 04 00 	movaps %xmm0,0x450(%rsp)
  6f5864:	00 
  6f5865:	0f 10 84 24 10 07 00 	movups 0x710(%rsp),%xmm0
  6f586c:	00 
  6f586d:	0f 10 8c 24 20 07 00 	movups 0x720(%rsp),%xmm1
  6f5874:	00 
  6f5875:	0f 10 94 24 30 07 00 	movups 0x730(%rsp),%xmm2
  6f587c:	00 
  6f587d:	66 0f 10 9c 24 40 07 	movupd 0x740(%rsp),%xmm3
  6f5884:	00 00 
  6f5886:	66 0f 29 9c 24 40 04 	movapd %xmm3,0x440(%rsp)
  6f588d:	00 00 
  6f588f:	0f 29 94 24 30 04 00 	movaps %xmm2,0x430(%rsp)
  6f5896:	00 
  6f5897:	0f 29 8c 24 20 04 00 	movaps %xmm1,0x420(%rsp)
  6f589e:	00 
  6f589f:	0f 29 84 24 10 04 00 	movaps %xmm0,0x410(%rsp)
  6f58a6:	00 
  6f58a7:	4c 8b b4 24 50 01 00 	mov    0x150(%rsp),%r14
  6f58ae:	00 
  6f58af:	49 83 3e 00          	cmpq   $0x0,(%r14)
  6f58b3:	0f 84 24 01 00 00    	je     6f59dd <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x459d>
  6f58b9:	0f 28 84 24 40 03 00 	movaps 0x340(%rsp),%xmm0
  6f58c0:	00 
  6f58c1:	0f 28 8c 24 50 03 00 	movaps 0x350(%rsp),%xmm1
  6f58c8:	00 
  6f58c9:	0f 28 94 24 60 03 00 	movaps 0x360(%rsp),%xmm2
  6f58d0:	00 
  6f58d1:	0f 29 94 24 90 04 00 	movaps %xmm2,0x490(%rsp)
  6f58d8:	00 
  6f58d9:	0f 29 8c 24 80 04 00 	movaps %xmm1,0x480(%rsp)
  6f58e0:	00 
  6f58e1:	0f 29 84 24 70 04 00 	movaps %xmm0,0x470(%rsp)
  6f58e8:	00 
  6f58e9:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  6f58ee:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6f58f5:	00 
  6f58f6:	48 8d 84 24 58 01 00 	lea    0x158(%rsp),%rax
  6f58fd:	00 
  6f58fe:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  6f5905:	00 
  6f5906:	48 8d 84 24 b8 01 00 	lea    0x1b8(%rsp),%rax
  6f590d:	00 
  6f590e:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  6f5915:	00 
  6f5916:	48 8d bc 24 70 03 00 	lea    0x370(%rsp),%rdi
  6f591d:	00 
  6f591e:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
  6f5925:	00 
  6f5926:	48 8d 94 24 a0 00 00 	lea    0xa0(%rsp),%rdx
  6f592d:	00 
  6f592e:	e8 4d 0d 02 00       	call   716680 <<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner::{closure#39}>>
  6f5933:	48 8d bc 24 10 04 00 	lea    0x410(%rsp),%rdi
  6f593a:	00 
  6f593b:	e8 b0 09 ff ff       	call   6e62f0 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportColumn>>
  6f5940:	48 8b 84 24 80 03 00 	mov    0x380(%rsp),%rax
  6f5947:	00 
  6f5948:	48 89 84 24 20 04 00 	mov    %rax,0x420(%rsp)
  6f594f:	00 
  6f5950:	0f 10 84 24 70 03 00 	movups 0x370(%rsp),%xmm0
  6f5957:	00 
  6f5958:	0f 29 84 24 10 04 00 	movaps %xmm0,0x410(%rsp)
  6f595f:	00 
  6f5960:	49 8b 3e             	mov    (%r14),%rdi
  6f5963:	83 7f 60 ff          	cmpl   $0xffffffff,0x60(%rdi)
  6f5967:	74 0c                	je     6f5975 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4535>
  6f5969:	48 83 c7 60          	add    $0x60,%rdi
  6f596d:	e8 4e 0d ff ff       	call   6e66c0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  6f5972:	49 8b 3e             	mov    (%r14),%rdi
  6f5975:	0f 28 84 24 60 04 00 	movaps 0x460(%rsp),%xmm0
  6f597c:	00 
  6f597d:	0f 11 87 b0 00 00 00 	movups %xmm0,0xb0(%rdi)
  6f5984:	0f 28 84 24 50 04 00 	movaps 0x450(%rsp),%xmm0
  6f598b:	00 
  6f598c:	0f 11 87 a0 00 00 00 	movups %xmm0,0xa0(%rdi)
  6f5993:	0f 28 84 24 10 04 00 	movaps 0x410(%rsp),%xmm0
  6f599a:	00 
  6f599b:	48 8b 84 24 20 04 00 	mov    0x420(%rsp),%rax
  6f59a2:	00 
  6f59a3:	48 8b 8c 24 28 04 00 	mov    0x428(%rsp),%rcx
  6f59aa:	00 
  6f59ab:	0f 28 8c 24 30 04 00 	movaps 0x430(%rsp),%xmm1
  6f59b2:	00 
  6f59b3:	0f 28 94 24 40 04 00 	movaps 0x440(%rsp),%xmm2
  6f59ba:	00 
  6f59bb:	0f 11 97 90 00 00 00 	movups %xmm2,0x90(%rdi)
  6f59c2:	0f 11 8f 80 00 00 00 	movups %xmm1,0x80(%rdi)
  6f59c9:	48 89 47 70          	mov    %rax,0x70(%rdi)
  6f59cd:	48 89 4f 78          	mov    %rcx,0x78(%rdi)
  6f59d1:	0f 11 47 60          	movups %xmm0,0x60(%rdi)
  6f59d5:	45 31 ff             	xor    %r15d,%r15d
  6f59d8:	45 31 f6             	xor    %r14d,%r14d
  6f59db:	eb 24                	jmp    6f5a01 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x45c1>
  6f59dd:	41 b7 01             	mov    $0x1,%r15b
  6f59e0:	45 31 f6             	xor    %r14d,%r14d
  6f59e3:	48 8d bc 24 10 04 00 	lea    0x410(%rsp),%rdi
  6f59ea:	00 
  6f59eb:	41 b4 01             	mov    $0x1,%r12b
  6f59ee:	b0 01                	mov    $0x1,%al
  6f59f0:	89 44 24 48          	mov    %eax,0x48(%rsp)
  6f59f4:	41 b5 01             	mov    $0x1,%r13b
  6f59f7:	c6 44 24 58 01       	movb   $0x1,0x58(%rsp)
  6f59fc:	e8 bf 0c ff ff       	call   6e66c0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  6f5a01:	44 89 bc 24 20 01 00 	mov    %r15d,0x120(%rsp)
  6f5a08:	00 
  6f5a09:	44 89 74 24 60       	mov    %r14d,0x60(%rsp)
  6f5a0e:	4c 8b bc 24 80 00 00 	mov    0x80(%rsp),%r15
  6f5a15:	00 
  6f5a16:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
  6f5a1a:	0f 94 44 24 58       	sete   0x58(%rsp)
  6f5a1f:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
  6f5a24:	48 8b b4 24 98 02 00 	mov    0x298(%rsp),%rsi
  6f5a2b:	00 
  6f5a2c:	74 4d                	je     6f5a7b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x463b>
  6f5a2e:	49 89 dd             	mov    %rbx,%r13
  6f5a31:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  6f5a38:	00 
  6f5a39:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  6f5a3e:	4c 8b a4 24 50 01 00 	mov    0x150(%rsp),%r12
  6f5a45:	00 
  6f5a46:	4c 89 e7             	mov    %r12,%rdi
  6f5a49:	e8 b2 bc fe ff       	call   6e1700 <<core::option::Option<alloc::boxed::Box<gpui::runtime::metadata::Metadata>>>::get_or_insert_with::<<alloc::boxed::Box<gpui::runtime::metadata::Metadata> as core::default::Default>::default>>
  6f5a4e:	bb 00 01 00 00       	mov    $0x100,%ebx
  6f5a53:	49 03 1c 24          	add    (%r12),%rbx
  6f5a57:	48 89 df             	mov    %rbx,%rdi
  6f5a5a:	e8 01 bb fe ff       	call   6e1560 <<core::option::Option<alloc::boxed::Box<gpui::runtime::geometry::Geometry>>>::get_or_insert_with::<<alloc::boxed::Box<gpui::runtime::geometry::Geometry> as core::default::Default>::default>>
  6f5a5f:	48 8b 3b             	mov    (%rbx),%rdi
  6f5a62:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6f5a69:	00 
  6f5a6a:	ff 15 50 60 39 00    	call   *0x396050(%rip)        # a8bac0 <_DYNAMIC+0x668>
  6f5a70:	4c 89 eb             	mov    %r13,%rbx
  6f5a73:	48 8b b4 24 98 02 00 	mov    0x298(%rsp),%rsi
  6f5a7a:	00 
  6f5a7b:	48 83 bc 24 90 02 00 	cmpq   $0xffffffffffffffff,0x290(%rsp)
  6f5a82:	00 ff 
  6f5a84:	74 34                	je     6f5aba <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x467a>
  6f5a86:	48 8b 84 24 a0 01 00 	mov    0x1a0(%rsp),%rax
  6f5a8d:	00 
  6f5a8e:	48 8b 38             	mov    (%rax),%rdi
  6f5a91:	48 85 ff             	test   %rdi,%rdi
  6f5a94:	0f 84 dc 09 00 00    	je     6f6476 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5036>
  6f5a9a:	48 8d 94 24 c0 07 00 	lea    0x7c0(%rsp),%rdx
  6f5aa1:	00 
  6f5aa2:	ff 15 20 60 39 00    	call   *0x396020(%rip)        # a8bac8 <_DYNAMIC+0x670>
  6f5aa8:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  6f5aaf:	00 
  6f5ab0:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
  6f5ab7:	00 
  6f5ab8:	eb 0e                	jmp    6f5ac8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4688>
  6f5aba:	b0 01                	mov    $0x1,%al
  6f5abc:	89 44 24 48          	mov    %eax,0x48(%rsp)
  6f5ac0:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  6f5ac7:	00 
  6f5ac8:	48 8b 00             	mov    (%rax),%rax
  6f5acb:	48 85 c0             	test   %rax,%rax
  6f5ace:	74 4d                	je     6f5b1d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x46dd>
  6f5ad0:	48 8b 80 e0 00 00 00 	mov    0xe0(%rax),%rax
  6f5ad7:	48 85 c0             	test   %rax,%rax
  6f5ada:	74 41                	je     6f5b1d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x46dd>
  6f5adc:	48 8b 8c 24 70 07 00 	mov    0x770(%rsp),%rcx
  6f5ae3:	00 
  6f5ae4:	48 89 48 40          	mov    %rcx,0x40(%rax)
  6f5ae8:	48 8b 8c 24 a8 03 00 	mov    0x3a8(%rsp),%rcx
  6f5aef:	00 
  6f5af0:	48 89 48 48          	mov    %rcx,0x48(%rax)
  6f5af4:	8b 8c 24 b0 03 00 00 	mov    0x3b0(%rsp),%ecx
  6f5afb:	89 48 50             	mov    %ecx,0x50(%rax)
  6f5afe:	0f b6 4c 24 57       	movzbl 0x57(%rsp),%ecx
  6f5b03:	88 48 54             	mov    %cl,0x54(%rax)
  6f5b06:	0f b7 8c 24 f4 00 00 	movzwl 0xf4(%rsp),%ecx
  6f5b0d:	00 
  6f5b0e:	66 89 48 55          	mov    %cx,0x55(%rax)
  6f5b12:	0f b6 8c 24 f6 00 00 	movzbl 0xf6(%rsp),%ecx
  6f5b19:	00 
  6f5b1a:	88 48 57             	mov    %cl,0x57(%rax)
  6f5b1d:	49 8b be c8 06 00 00 	mov    0x6c8(%r14),%rdi
  6f5b24:	48 85 ff             	test   %rdi,%rdi
  6f5b27:	74 4d                	je     6f5b76 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4736>
  6f5b29:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
  6f5b30:	00 
  6f5b31:	48 89 84 24 80 04 00 	mov    %rax,0x480(%rsp)
  6f5b38:	00 
  6f5b39:	0f 10 84 24 e0 01 00 	movups 0x1e0(%rsp),%xmm0
  6f5b40:	00 
  6f5b41:	0f 29 84 24 70 04 00 	movaps %xmm0,0x470(%rsp)
  6f5b48:	00 
  6f5b49:	48 83 c7 18          	add    $0x18,%rdi
  6f5b4d:	e8 ce bf fe ff       	call   6e1b20 <core::ptr::drop_glue::<core::option::Option<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>>
  6f5b52:	49 8b 86 c8 06 00 00 	mov    0x6c8(%r14),%rax
  6f5b59:	48 8b 8c 24 80 04 00 	mov    0x480(%rsp),%rcx
  6f5b60:	00 
  6f5b61:	48 89 48 28          	mov    %rcx,0x28(%rax)
  6f5b65:	0f 28 84 24 70 04 00 	movaps 0x470(%rsp),%xmm0
  6f5b6c:	00 
  6f5b6d:	0f 11 40 18          	movups %xmm0,0x18(%rax)
  6f5b71:	45 31 e4             	xor    %r12d,%r12d
  6f5b74:	eb 03                	jmp    6f5b79 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4739>
  6f5b76:	41 b4 01             	mov    $0x1,%r12b
  6f5b79:	48 8b 84 24 c8 01 00 	mov    0x1c8(%rsp),%rax
  6f5b80:	00 
  6f5b81:	48 89 84 24 80 04 00 	mov    %rax,0x480(%rsp)
  6f5b88:	00 
  6f5b89:	0f 10 84 24 b8 01 00 	movups 0x1b8(%rsp),%xmm0
  6f5b90:	00 
  6f5b91:	0f 29 84 24 70 04 00 	movaps %xmm0,0x470(%rsp)
  6f5b98:	00 
  6f5b99:	4d 8d be 88 05 00 00 	lea    0x588(%r14),%r15
  6f5ba0:	4c 89 ff             	mov    %r15,%rdi
  6f5ba3:	e8 08 cb fe ff       	call   6e26b0 <core::ptr::drop_glue::<core::option::Option<gpui::runtime::Prepared>>>
  6f5ba8:	48 8b 84 24 80 04 00 	mov    0x480(%rsp),%rax
  6f5baf:	00 
  6f5bb0:	49 89 47 10          	mov    %rax,0x10(%r15)
  6f5bb4:	0f 28 84 24 70 04 00 	movaps 0x470(%rsp),%xmm0
  6f5bbb:	00 
  6f5bbc:	41 0f 11 07          	movups %xmm0,(%r15)
  6f5bc0:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  6f5bc5:	49 89 86 a0 05 00 00 	mov    %rax,0x5a0(%r14)
  6f5bcc:	66 41 89 9e a8 05 00 	mov    %bx,0x5a8(%r14)
  6f5bd3:	00 
  6f5bd4:	8b 84 24 dc 01 00 00 	mov    0x1dc(%rsp),%eax
  6f5bdb:	66 41 89 86 aa 05 00 	mov    %ax,0x5aa(%r14)
  6f5be2:	00 
  6f5be3:	f3 0f 10 84 24 9c 00 	movss  0x9c(%rsp),%xmm0
  6f5bea:	00 00 
  6f5bec:	f3 41 0f 11 86 ac 05 	movss  %xmm0,0x5ac(%r14)
  6f5bf3:	00 00 
  6f5bf5:	4c 89 f7             	mov    %r14,%rdi
  6f5bf8:	45 31 ed             	xor    %r13d,%r13d
  6f5bfb:	44 8b 74 24 60       	mov    0x60(%rsp),%r14d
  6f5c00:	44 8b bc 24 20 01 00 	mov    0x120(%rsp),%r15d
  6f5c07:	00 
  6f5c08:	e8 63 58 ff ff       	call   6eb470 <<gpui::runtime::Runtime<route_columns_cost::Page>>::prune_focus>
  6f5c0d:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
  6f5c12:	48 8b 84 24 28 03 00 	mov    0x328(%rsp),%rax
  6f5c19:	00 
  6f5c1a:	49 89 86 b0 06 00 00 	mov    %rax,0x6b0(%r14)
  6f5c21:	48 8b 84 24 98 02 00 	mov    0x298(%rsp),%rax
  6f5c28:	00 
  6f5c29:	49 89 86 b8 06 00 00 	mov    %rax,0x6b8(%r14)
  6f5c30:	49 8b 86 90 06 00 00 	mov    0x690(%r14),%rax
  6f5c37:	49 8b be c8 06 00 00 	mov    0x6c8(%r14),%rdi
  6f5c3e:	49 89 86 c0 06 00 00 	mov    %rax,0x6c0(%r14)
  6f5c45:	48 8b 84 24 b8 07 00 	mov    0x7b8(%rsp),%rax
  6f5c4c:	00 
  6f5c4d:	49 89 86 c8 05 00 00 	mov    %rax,0x5c8(%r14)
  6f5c54:	49 83 be b8 02 00 00 	cmpq   $0x0,0x2b8(%r14)
  6f5c5b:	00 
  6f5c5c:	0f 95 c0             	setne  %al
  6f5c5f:	48 85 ff             	test   %rdi,%rdi
  6f5c62:	0f 94 c1             	sete   %cl
  6f5c65:	08 c1                	or     %al,%cl
  6f5c67:	80 f9 01             	cmp    $0x1,%cl
  6f5c6a:	74 18                	je     6f5c84 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4844>
  6f5c6c:	48 83 c7 30          	add    $0x30,%rdi
  6f5c70:	e8 eb ce fe ff       	call   6e2b60 <core::ptr::drop_glue::<core::option::Option<gpui_canvas::text::TextSystem>>>
  6f5c75:	49 8b 86 c8 06 00 00 	mov    0x6c8(%r14),%rax
  6f5c7c:	48 c7 40 30 00 00 00 	movq   $0x0,0x30(%rax)
  6f5c83:	00 
  6f5c84:	41 c6 86 4b 07 00 00 	movb   $0x0,0x74b(%r14)
  6f5c8b:	00 
  6f5c8c:	66 41 c7 86 48 07 00 	movw   $0x0,0x748(%r14)
  6f5c93:	00 00 00 
  6f5c96:	49 8d be 78 06 00 00 	lea    0x678(%r14),%rdi
  6f5c9d:	45 31 ed             	xor    %r13d,%r13d
  6f5ca0:	44 8b 74 24 60       	mov    0x60(%rsp),%r14d
  6f5ca5:	e8 46 37 01 00       	call   7093f0 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::clear>
  6f5caa:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  6f5caf:	80 be 4d 07 00 00 00 	cmpb   $0x0,0x74d(%rsi)
  6f5cb6:	74 32                	je     6f5cea <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x48aa>
  6f5cb8:	45 31 ed             	xor    %r13d,%r13d
  6f5cbb:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  6f5cc2:	00 
  6f5cc3:	48 8b 94 24 28 03 00 	mov    0x328(%rsp),%rdx
  6f5cca:	00 
  6f5ccb:	48 8b 8c 24 98 02 00 	mov    0x298(%rsp),%rcx
  6f5cd2:	00 
  6f5cd3:	e8 78 b0 ff ff       	call   6f0d50 <<gpui::runtime::Runtime<route_columns_cost::Page>>::acknowledge>
  6f5cd8:	48 8b 84 24 70 04 00 	mov    0x470(%rsp),%rax
  6f5cdf:	00 
  6f5ce0:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6f5ce4:	0f 85 33 01 00 00    	jne    6f5e1d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x49dd>
  6f5cea:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6f5cef:	48 c7 00 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rax)
  6f5cf6:	45 84 ff             	test   %r15b,%r15b
  6f5cf9:	74 0d                	je     6f5d08 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x48c8>
  6f5cfb:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  6f5d02:	00 
  6f5d03:	e8 98 05 ff ff       	call   6e62a0 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportBuild>>
  6f5d08:	45 31 ff             	xor    %r15d,%r15d
  6f5d0b:	48 8d bc 24 b8 03 00 	lea    0x3b8(%rsp),%rdi
  6f5d12:	00 
  6f5d13:	e8 a8 58 01 00       	call   70b5c0 <<alloc::collections::btree::map::BTreeMap<gpui::list::ListId, alloc::collections::btree::set_val::SetValZST> as core::ops::drop::Drop>::drop>
  6f5d18:	48 8b b4 24 58 01 00 	mov    0x158(%rsp),%rsi
  6f5d1f:	00 
  6f5d20:	48 85 f6             	test   %rsi,%rsi
  6f5d23:	74 17                	je     6f5d3c <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x48fc>
  6f5d25:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
  6f5d2c:	00 
  6f5d2d:	48 c1 e6 02          	shl    $0x2,%rsi
  6f5d31:	ba 04 00 00 00       	mov    $0x4,%edx
  6f5d36:	ff 15 6c 59 39 00    	call   *0x39596c(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f5d3c:	48 8b b4 24 78 01 00 	mov    0x178(%rsp),%rsi
  6f5d43:	00 
  6f5d44:	48 85 f6             	test   %rsi,%rsi
  6f5d47:	74 13                	je     6f5d5c <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x491c>
  6f5d49:	48 8b bc 24 80 01 00 	mov    0x180(%rsp),%rdi
  6f5d50:	00 
  6f5d51:	ba 01 00 00 00       	mov    $0x1,%edx
  6f5d56:	ff 15 4c 59 39 00    	call   *0x39594c(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f5d5c:	48 8b b4 24 38 02 00 	mov    0x238(%rsp),%rsi
  6f5d63:	00 
  6f5d64:	48 85 f6             	test   %rsi,%rsi
  6f5d67:	74 17                	je     6f5d80 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4940>
  6f5d69:	48 8b bc 24 40 02 00 	mov    0x240(%rsp),%rdi
  6f5d70:	00 
  6f5d71:	48 c1 e6 04          	shl    $0x4,%rsi
  6f5d75:	ba 04 00 00 00       	mov    $0x4,%edx
  6f5d7a:	ff 15 28 59 39 00    	call   *0x395928(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f5d80:	48 8b b4 24 20 02 00 	mov    0x220(%rsp),%rsi
  6f5d87:	00 
  6f5d88:	48 85 f6             	test   %rsi,%rsi
  6f5d8b:	74 17                	je     6f5da4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4964>
  6f5d8d:	48 8b bc 24 28 02 00 	mov    0x228(%rsp),%rdi
  6f5d94:	00 
  6f5d95:	48 c1 e6 04          	shl    $0x4,%rsi
  6f5d99:	ba 04 00 00 00       	mov    $0x4,%edx
  6f5d9e:	ff 15 04 59 39 00    	call   *0x395904(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f5da4:	48 8b 84 24 f8 01 00 	mov    0x1f8(%rsp),%rax
  6f5dab:	00 
  6f5dac:	48 85 c0             	test   %rax,%rax
  6f5daf:	74 17                	je     6f5dc8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4988>
  6f5db1:	48 8b bc 24 00 02 00 	mov    0x200(%rsp),%rdi
  6f5db8:	00 
  6f5db9:	48 6b f0 38          	imul   $0x38,%rax,%rsi
  6f5dbd:	ba 08 00 00 00       	mov    $0x8,%edx
  6f5dc2:	ff 15 e0 58 39 00    	call   *0x3958e0(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f5dc8:	48 8b bc 24 a8 01 00 	mov    0x1a8(%rsp),%rdi
  6f5dcf:	00 
  6f5dd0:	48 8b b4 24 b0 01 00 	mov    0x1b0(%rsp),%rsi
  6f5dd7:	00 
  6f5dd8:	e8 13 ca fe ff       	call   6e27f0 <core::ptr::drop_glue::<core::option::Option<gpui_canvas::text::TextShaper>>>
  6f5ddd:	45 84 e4             	test   %r12b,%r12b
  6f5de0:	74 0d                	je     6f5def <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x49af>
  6f5de2:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
  6f5de9:	00 
  6f5dea:	e8 41 e4 fe ff       	call   6e4230 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  6f5def:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
  6f5df6:	00 
  6f5df7:	48 85 c0             	test   %rax,%rax
  6f5dfa:	0f 84 c3 d1 ff ff    	je     6f2fc3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b83>
  6f5e00:	f0 48 ff 08          	lock decq (%rax)
  6f5e04:	0f 85 b9 d1 ff ff    	jne    6f2fc3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b83>
  6f5e0a:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
  6f5e11:	00 
  6f5e12:	ff 15 e8 58 39 00    	call   *0x3958e8(%rip)        # a8b700 <_DYNAMIC+0x2a8>
  6f5e18:	e9 a6 d1 ff ff       	jmp    6f2fc3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b83>
  6f5e1d:	48 8b 8c 24 98 04 00 	mov    0x498(%rsp),%rcx
  6f5e24:	00 
  6f5e25:	0f b6 94 24 a0 04 00 	movzbl 0x4a0(%rsp),%edx
  6f5e2c:	00 
  6f5e2d:	8b b4 24 a4 04 00 00 	mov    0x4a4(%rsp),%esi
  6f5e34:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  6f5e39:	89 77 34             	mov    %esi,0x34(%rdi)
  6f5e3c:	8b b4 24 a1 04 00 00 	mov    0x4a1(%rsp),%esi
  6f5e43:	89 77 31             	mov    %esi,0x31(%rdi)
  6f5e46:	0f 10 84 24 78 04 00 	movups 0x478(%rsp),%xmm0
  6f5e4d:	00 
  6f5e4e:	0f 10 8c 24 88 04 00 	movups 0x488(%rsp),%xmm1
  6f5e55:	00 
  6f5e56:	48 89 07             	mov    %rax,(%rdi)
  6f5e59:	0f 11 47 08          	movups %xmm0,0x8(%rdi)
  6f5e5d:	0f 11 4f 18          	movups %xmm1,0x18(%rdi)
  6f5e61:	48 89 4f 28          	mov    %rcx,0x28(%rdi)
  6f5e65:	88 57 30             	mov    %dl,0x30(%rdi)
  6f5e68:	44 89 f8             	mov    %r15d,%eax
  6f5e6b:	45 31 ff             	xor    %r15d,%r15d
  6f5e6e:	84 c0                	test   %al,%al
  6f5e70:	8b 5c 24 48          	mov    0x48(%rsp),%ebx
  6f5e74:	0f 85 ce 02 00 00    	jne    6f6148 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4d08>
  6f5e7a:	e9 d6 02 00 00       	jmp    6f6155 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4d15>
  6f5e7f:	0f b6 84 24 71 04 00 	movzbl 0x471(%rsp),%eax
  6f5e86:	00 
  6f5e87:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  6f5e8c:	48 c7 01 22 00 00 00 	movq   $0x22,(%rcx)
  6f5e93:	88 41 08             	mov    %al,0x8(%rcx)
  6f5e96:	e9 92 02 00 00       	jmp    6f612d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4ced>
  6f5e9b:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6f5ea0:	48 c7 00 1f 00 00 00 	movq   $0x1f,(%rax)
  6f5ea7:	e9 17 d1 ff ff       	jmp    6f2fc3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1b83>
  6f5eac:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  6f5eb1:	48 c7 01 23 00 00 00 	movq   $0x23,(%rcx)
  6f5eb8:	89 41 08             	mov    %eax,0x8(%rcx)
  6f5ebb:	89 51 0c             	mov    %edx,0xc(%rcx)
  6f5ebe:	e9 6a 02 00 00       	jmp    6f612d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4ced>
  6f5ec3:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
  6f5eca:	00 
  6f5ecb:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  6f5ed0:	48 89 4a 30          	mov    %rcx,0x30(%rdx)
  6f5ed4:	0f 10 84 24 b0 00 00 	movups 0xb0(%rsp),%xmm0
  6f5edb:	00 
  6f5edc:	0f 10 8c 24 c0 00 00 	movups 0xc0(%rsp),%xmm1
  6f5ee3:	00 
  6f5ee4:	0f 11 4a 20          	movups %xmm1,0x20(%rdx)
  6f5ee8:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  6f5eec:	48 89 02             	mov    %rax,(%rdx)
  6f5eef:	4c 89 7a 08          	mov    %r15,0x8(%rdx)
  6f5ef3:	e9 35 02 00 00       	jmp    6f612d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4ced>
  6f5ef8:	48 8b 84 24 a0 04 00 	mov    0x4a0(%rsp),%rax
  6f5eff:	00 
  6f5f00:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  6f5f05:	48 89 41 30          	mov    %rax,0x30(%rcx)
  6f5f09:	0f 10 84 24 70 04 00 	movups 0x470(%rsp),%xmm0
  6f5f10:	00 
  6f5f11:	0f 10 8c 24 80 04 00 	movups 0x480(%rsp),%xmm1
  6f5f18:	00 
  6f5f19:	0f 10 94 24 90 04 00 	movups 0x490(%rsp),%xmm2
  6f5f20:	00 
  6f5f21:	0f 11 51 20          	movups %xmm2,0x20(%rcx)
  6f5f25:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
  6f5f29:	0f 11 01             	movups %xmm0,(%rcx)
  6f5f2c:	e9 fc 01 00 00       	jmp    6f612d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4ced>
  6f5f31:	48 8d 8c 24 a4 00 00 	lea    0xa4(%rsp),%rcx
  6f5f38:	00 
  6f5f39:	48 8b 41 14          	mov    0x14(%rcx),%rax
  6f5f3d:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6f5f44:	00 
  6f5f45:	0f 10 41 04          	movups 0x4(%rcx),%xmm0
  6f5f49:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  6f5f50:	00 
  6f5f51:	e9 1e 01 00 00       	jmp    6f6074 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4c34>
  6f5f56:	41 8b 77 10          	mov    0x10(%r15),%esi
  6f5f5a:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
  6f5f61:	00 
  6f5f62:	48 8d 94 24 10 08 00 	lea    0x810(%rsp),%rdx
  6f5f69:	00 
  6f5f6a:	e8 c1 21 ff ff       	call   6e8130 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner::{closure#23}>
  6f5f6f:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  6f5f76:	00 
  6f5f77:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
  6f5f7e:	00 
  6f5f7f:	0f 10 84 24 a0 00 00 	movups 0xa0(%rsp),%xmm0
  6f5f86:	00 
  6f5f87:	0f 10 8c 24 b0 00 00 	movups 0xb0(%rsp),%xmm1
  6f5f8e:	00 
  6f5f8f:	0f 10 94 24 c0 00 00 	movups 0xc0(%rsp),%xmm2
  6f5f96:	00 
  6f5f97:	0f 29 94 24 30 08 00 	movaps %xmm2,0x830(%rsp)
  6f5f9e:	00 
  6f5f9f:	0f 29 8c 24 20 08 00 	movaps %xmm1,0x820(%rsp)
  6f5fa6:	00 
  6f5fa7:	0f 29 84 24 10 08 00 	movaps %xmm0,0x810(%rsp)
  6f5fae:	00 
  6f5faf:	48 8b 84 24 10 08 00 	mov    0x810(%rsp),%rax
  6f5fb6:	00 
  6f5fb7:	48 8b 8c 24 38 08 00 	mov    0x838(%rsp),%rcx
  6f5fbe:	00 
  6f5fbf:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  6f5fc4:	48 89 4a 28          	mov    %rcx,0x28(%rdx)
  6f5fc8:	48 8b 8c 24 40 08 00 	mov    0x840(%rsp),%rcx
  6f5fcf:	00 
  6f5fd0:	48 89 4a 30          	mov    %rcx,0x30(%rdx)
  6f5fd4:	48 8d 8c 24 18 08 00 	lea    0x818(%rsp),%rcx
  6f5fdb:	00 
  6f5fdc:	0f 10 01             	movups (%rcx),%xmm0
  6f5fdf:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
  6f5fe3:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
  6f5fe7:	0f 11 4a 18          	movups %xmm1,0x18(%rdx)
  6f5feb:	48 89 02             	mov    %rax,(%rdx)
  6f5fee:	e9 3a 01 00 00       	jmp    6f612d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4ced>
  6f5ff3:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6f5ff8:	48 c7 00 18 00 00 00 	movq   $0x18,(%rax)
  6f5fff:	e9 0d 01 00 00       	jmp    6f6111 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4cd1>
  6f6004:	48 8d 8c 24 a4 00 00 	lea    0xa4(%rsp),%rcx
  6f600b:	00 
  6f600c:	48 8b 41 14          	mov    0x14(%rcx),%rax
  6f6010:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6f6017:	00 
  6f6018:	0f 10 41 04          	movups 0x4(%rcx),%xmm0
  6f601c:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  6f6023:	00 
  6f6024:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  6f6029:	48 89 41 18          	mov    %rax,0x18(%rcx)
  6f602d:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
  6f6031:	48 c7 01 23 00 00 00 	movq   $0x23,(%rcx)
  6f6038:	e9 d4 00 00 00       	jmp    6f6111 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4cd1>
  6f603d:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  6f6042:	48 c7 01 23 00 00 00 	movq   $0x23,(%rcx)
  6f6049:	89 41 08             	mov    %eax,0x8(%rcx)
  6f604c:	89 51 0c             	mov    %edx,0xc(%rcx)
  6f604f:	e9 bd 00 00 00       	jmp    6f6111 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4cd1>
  6f6054:	48 8d 8c 24 a4 00 00 	lea    0xa4(%rsp),%rcx
  6f605b:	00 
  6f605c:	48 8b 41 14          	mov    0x14(%rcx),%rax
  6f6060:	0f 10 41 04          	movups 0x4(%rcx),%xmm0
  6f6064:	0f 29 84 24 50 02 00 	movaps %xmm0,0x250(%rsp)
  6f606b:	00 
  6f606c:	48 89 84 24 60 02 00 	mov    %rax,0x260(%rsp)
  6f6073:	00 
  6f6074:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  6f6079:	48 89 41 18          	mov    %rax,0x18(%rcx)
  6f607d:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
  6f6081:	48 c7 01 23 00 00 00 	movq   $0x23,(%rcx)
  6f6088:	e9 a0 00 00 00       	jmp    6f612d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4ced>
  6f608d:	48 8d 8c 24 a4 00 00 	lea    0xa4(%rsp),%rcx
  6f6094:	00 
  6f6095:	48 8b 41 14          	mov    0x14(%rcx),%rax
  6f6099:	0f 10 41 04          	movups 0x4(%rcx),%xmm0
  6f609d:	0f 29 84 24 50 02 00 	movaps %xmm0,0x250(%rsp)
  6f60a4:	00 
  6f60a5:	48 89 84 24 60 02 00 	mov    %rax,0x260(%rsp)
  6f60ac:	00 
  6f60ad:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  6f60b2:	48 89 41 18          	mov    %rax,0x18(%rcx)
  6f60b6:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
  6f60ba:	48 c7 01 23 00 00 00 	movq   $0x23,(%rcx)
  6f60c1:	eb 12                	jmp    6f60d5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4c95>
  6f60c3:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  6f60c8:	48 c7 01 23 00 00 00 	movq   $0x23,(%rcx)
  6f60cf:	89 41 08             	mov    %eax,0x8(%rcx)
  6f60d2:	89 51 0c             	mov    %edx,0xc(%rcx)
  6f60d5:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
  6f60dc:	00 
  6f60dd:	48 85 c0             	test   %rax,%rax
  6f60e0:	74 4b                	je     6f612d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4ced>
  6f60e2:	f0 48 ff 08          	lock decq (%rax)
  6f60e6:	75 45                	jne    6f612d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4ced>
  6f60e8:	48 8d bc 24 18 02 00 	lea    0x218(%rsp),%rdi
  6f60ef:	00 
  6f60f0:	ff 15 12 56 39 00    	call   *0x395612(%rip)        # a8b708 <_DYNAMIC+0x2b0>
  6f60f6:	eb 35                	jmp    6f612d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4ced>
  6f60f8:	8b 8c 24 44 01 00 00 	mov    0x144(%rsp),%ecx
  6f60ff:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  6f6104:	48 c7 02 23 00 00 00 	movq   $0x23,(%rdx)
  6f610b:	89 42 08             	mov    %eax,0x8(%rdx)
  6f610e:	89 4a 0c             	mov    %ecx,0xc(%rdx)
  6f6111:	48 8b 84 24 10 03 00 	mov    0x310(%rsp),%rax
  6f6118:	00 
  6f6119:	f0 48 ff 08          	lock decq (%rax)
  6f611d:	75 0e                	jne    6f612d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4ced>
  6f611f:	48 8d bc 24 10 03 00 	lea    0x310(%rsp),%rdi
  6f6126:	00 
  6f6127:	ff 15 db 55 39 00    	call   *0x3955db(%rip)        # a8b708 <_DYNAMIC+0x2b0>
  6f612d:	48 8d bc 24 30 09 00 	lea    0x930(%rsp),%rdi
  6f6134:	00 
  6f6135:	e8 c6 f3 fe ff       	call   6e5500 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  6f613a:	41 b4 01             	mov    $0x1,%r12b
  6f613d:	b3 01                	mov    $0x1,%bl
  6f613f:	41 b6 01             	mov    $0x1,%r14b
  6f6142:	41 b7 01             	mov    $0x1,%r15b
  6f6145:	40 b5 01             	mov    $0x1,%bpl
  6f6148:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  6f614f:	00 
  6f6150:	e8 4b 01 ff ff       	call   6e62a0 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportBuild>>
  6f6155:	48 83 bc 24 90 02 00 	cmpq   $0xffffffffffffffff,0x290(%rsp)
  6f615c:	00 ff 
  6f615e:	0f 95 c0             	setne  %al
  6f6161:	45 89 fd             	mov    %r15d,%r13d
  6f6164:	84 d8                	test   %bl,%al
  6f6166:	74 10                	je     6f6178 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4d38>
  6f6168:	48 8d bc 24 c0 07 00 	lea    0x7c0(%rsp),%rdi
  6f616f:	00 
  6f6170:	e8 4b df fe ff       	call   6e40c0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui_canvas::image::Image>>>
  6f6175:	45 89 ef             	mov    %r13d,%r15d
  6f6178:	83 bc 24 10 07 00 00 	cmpl   $0xffffffff,0x710(%rsp)
  6f617f:	ff 
  6f6180:	74 12                	je     6f6194 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4d54>
  6f6182:	45 84 f6             	test   %r14b,%r14b
  6f6185:	74 0d                	je     6f6194 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4d54>
  6f6187:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f618e:	00 
  6f618f:	e8 2c 05 ff ff       	call   6e66c0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  6f6194:	48 8d bc 24 b8 03 00 	lea    0x3b8(%rsp),%rdi
  6f619b:	00 
  6f619c:	e8 1f 54 01 00       	call   70b5c0 <<alloc::collections::btree::map::BTreeMap<gpui::list::ListId, alloc::collections::btree::set_val::SetValZST> as core::ops::drop::Drop>::drop>
  6f61a1:	48 8b b4 24 58 01 00 	mov    0x158(%rsp),%rsi
  6f61a8:	00 
  6f61a9:	48 85 f6             	test   %rsi,%rsi
  6f61ac:	74 17                	je     6f61c5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4d85>
  6f61ae:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
  6f61b5:	00 
  6f61b6:	48 c1 e6 02          	shl    $0x2,%rsi
  6f61ba:	ba 04 00 00 00       	mov    $0x4,%edx
  6f61bf:	ff 15 e3 54 39 00    	call   *0x3954e3(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f61c5:	48 8b b4 24 78 01 00 	mov    0x178(%rsp),%rsi
  6f61cc:	00 
  6f61cd:	48 85 f6             	test   %rsi,%rsi
  6f61d0:	74 13                	je     6f61e5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4da5>
  6f61d2:	48 8b bc 24 80 01 00 	mov    0x180(%rsp),%rdi
  6f61d9:	00 
  6f61da:	ba 01 00 00 00       	mov    $0x1,%edx
  6f61df:	ff 15 c3 54 39 00    	call   *0x3954c3(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f61e5:	48 8b b4 24 38 02 00 	mov    0x238(%rsp),%rsi
  6f61ec:	00 
  6f61ed:	48 85 f6             	test   %rsi,%rsi
  6f61f0:	74 17                	je     6f6209 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4dc9>
  6f61f2:	48 8b bc 24 40 02 00 	mov    0x240(%rsp),%rdi
  6f61f9:	00 
  6f61fa:	48 c1 e6 04          	shl    $0x4,%rsi
  6f61fe:	ba 04 00 00 00       	mov    $0x4,%edx
  6f6203:	ff 15 9f 54 39 00    	call   *0x39549f(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f6209:	48 8b b4 24 20 02 00 	mov    0x220(%rsp),%rsi
  6f6210:	00 
  6f6211:	48 85 f6             	test   %rsi,%rsi
  6f6214:	74 17                	je     6f622d <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4ded>
  6f6216:	48 8b bc 24 28 02 00 	mov    0x228(%rsp),%rdi
  6f621d:	00 
  6f621e:	48 c1 e6 04          	shl    $0x4,%rsi
  6f6222:	ba 04 00 00 00       	mov    $0x4,%edx
  6f6227:	ff 15 7b 54 39 00    	call   *0x39547b(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f622d:	48 8b 84 24 f8 01 00 	mov    0x1f8(%rsp),%rax
  6f6234:	00 
  6f6235:	48 85 c0             	test   %rax,%rax
  6f6238:	74 17                	je     6f6251 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4e11>
  6f623a:	48 8b bc 24 00 02 00 	mov    0x200(%rsp),%rdi
  6f6241:	00 
  6f6242:	48 6b f0 38          	imul   $0x38,%rax,%rsi
  6f6246:	ba 08 00 00 00       	mov    $0x8,%edx
  6f624b:	ff 15 57 54 39 00    	call   *0x395457(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f6251:	45 84 ff             	test   %r15b,%r15b
  6f6254:	74 31                	je     6f6287 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4e47>
  6f6256:	48 8b b4 24 c8 02 00 	mov    0x2c8(%rsp),%rsi
  6f625d:	00 
  6f625e:	48 85 f6             	test   %rsi,%rsi
  6f6261:	74 17                	je     6f627a <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4e3a>
  6f6263:	48 8b bc 24 d0 02 00 	mov    0x2d0(%rsp),%rdi
  6f626a:	00 
  6f626b:	48 c1 e6 04          	shl    $0x4,%rsi
  6f626f:	ba 04 00 00 00       	mov    $0x4,%edx
  6f6274:	ff 15 2e 54 39 00    	call   *0x39542e(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f627a:	48 8d bc 24 b8 01 00 	lea    0x1b8(%rsp),%rdi
  6f6281:	00 
  6f6282:	e8 b9 dc fe ff       	call   6e3f40 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  6f6287:	48 8b 84 24 d8 07 00 	mov    0x7d8(%rsp),%rax
  6f628e:	00 
  6f628f:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6f6293:	0f 85 ae c8 ff ff    	jne    6f2b47 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1707>
  6f6299:	e9 60 cc ff ff       	jmp    6f2efe <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x1abe>
  6f629e:	48 8d 3d b9 47 96 ff 	lea    -0x69b847(%rip),%rdi        # 5aa5e <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2db6>
  6f62a5:	48 8d 15 b4 cb 36 00 	lea    0x36cbb4(%rip),%rdx        # a62e60 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa60>
  6f62ac:	be 83 00 00 00       	mov    $0x83,%esi
  6f62b1:	ff 15 31 54 39 00    	call   *0x395431(%rip)        # a8b6e8 <_DYNAMIC+0x290>
  6f62b7:	e9 7b 03 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f62bc:	41 b7 01             	mov    $0x1,%r15b
  6f62bf:	48 8d 3d 52 cb 36 00 	lea    0x36cb52(%rip),%rdi        # a62e18 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa18>
  6f62c6:	41 b4 01             	mov    $0x1,%r12b
  6f62c9:	b0 01                	mov    $0x1,%al
  6f62cb:	89 44 24 48          	mov    %eax,0x48(%rsp)
  6f62cf:	41 b6 01             	mov    $0x1,%r14b
  6f62d2:	41 b5 01             	mov    $0x1,%r13b
  6f62d5:	40 b5 01             	mov    $0x1,%bpl
  6f62d8:	c6 44 24 58 01       	movb   $0x1,0x58(%rsp)
  6f62dd:	ff 15 ed 53 39 00    	call   *0x3953ed(%rip)        # a8b6d0 <_DYNAMIC+0x278>
  6f62e3:	e9 4f 03 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f62e8:	40 b5 01             	mov    $0x1,%bpl
  6f62eb:	bf 08 00 00 00       	mov    $0x8,%edi
  6f62f0:	be 78 00 00 00       	mov    $0x78,%esi
  6f62f5:	ff 15 c5 53 39 00    	call   *0x3953c5(%rip)        # a8b6c0 <_DYNAMIC+0x268>
  6f62fb:	e9 37 03 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f6300:	48 8d 3d 69 d3 36 00 	lea    0x36d369(%rip),%rdi        # a63670 <anon.92a5b798a24d77726913e1a598e97bdf.3.llvm.13561988957598541395>
  6f6307:	ff 15 c3 53 39 00    	call   *0x3953c3(%rip)        # a8b6d0 <_DYNAMIC+0x278>
  6f630d:	e9 25 03 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f6312:	48 8d 05 86 47 96 ff 	lea    -0x69b87a(%rip),%rax        # 5aa9f <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2df7>
  6f6319:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
  6f6320:	00 
  6f6321:	48 8d 05 98 cc 36 00 	lea    0x36cc98(%rip),%rax        # a62fc0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xbc0>
  6f6328:	eb 3a                	jmp    6f6364 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4f24>
  6f632a:	48 8d 3d d7 c4 36 00 	lea    0x36c4d7(%rip),%rdi        # a62808 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x408>
  6f6331:	ff 15 99 53 39 00    	call   *0x395399(%rip)        # a8b6d0 <_DYNAMIC+0x278>
  6f6337:	e9 fb 02 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f633c:	48 8d 3d 2d d3 36 00 	lea    0x36d32d(%rip),%rdi        # a63670 <anon.92a5b798a24d77726913e1a598e97bdf.3.llvm.13561988957598541395>
  6f6343:	ff 15 87 53 39 00    	call   *0x395387(%rip)        # a8b6d0 <_DYNAMIC+0x278>
  6f6349:	e9 e9 02 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f634e:	48 8d 05 4a 47 96 ff 	lea    -0x69b8b6(%rip),%rax        # 5aa9f <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2df7>
  6f6355:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
  6f635c:	00 
  6f635d:	48 8d 05 74 cc 36 00 	lea    0x36cc74(%rip),%rax        # a62fd8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xbd8>
  6f6364:	48 89 84 24 80 02 00 	mov    %rax,0x280(%rsp)
  6f636b:	00 
  6f636c:	eb 7a                	jmp    6f63e8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x4fa8>
  6f636e:	48 8b b4 24 80 04 00 	mov    0x480(%rsp),%rsi
  6f6375:	00 
  6f6376:	40 b5 01             	mov    $0x1,%bpl
  6f6379:	ff 15 f1 53 39 00    	call   *0x3953f1(%rip)        # a8b770 <_DYNAMIC+0x318>
  6f637f:	e9 b3 02 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f6384:	48 8b b4 24 80 04 00 	mov    0x480(%rsp),%rsi
  6f638b:	00 
  6f638c:	ff 15 de 53 39 00    	call   *0x3953de(%rip)        # a8b770 <_DYNAMIC+0x318>
  6f6392:	e9 a0 02 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f6397:	48 8b b4 24 80 04 00 	mov    0x480(%rsp),%rsi
  6f639e:	00 
  6f639f:	ff 15 cb 53 39 00    	call   *0x3953cb(%rip)        # a8b770 <_DYNAMIC+0x318>
  6f63a5:	e9 8d 02 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f63aa:	48 8b b4 24 80 04 00 	mov    0x480(%rsp),%rsi
  6f63b1:	00 
  6f63b2:	ff 15 b8 53 39 00    	call   *0x3953b8(%rip)        # a8b770 <_DYNAMIC+0x318>
  6f63b8:	e9 7a 02 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f63bd:	48 8b b4 24 80 04 00 	mov    0x480(%rsp),%rsi
  6f63c4:	00 
  6f63c5:	ff 15 a5 53 39 00    	call   *0x3953a5(%rip)        # a8b770 <_DYNAMIC+0x318>
  6f63cb:	e9 67 02 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f63d0:	48 8b b4 24 80 04 00 	mov    0x480(%rsp),%rsi
  6f63d7:	00 
  6f63d8:	ff 15 92 53 39 00    	call   *0x395392(%rip)        # a8b770 <_DYNAMIC+0x318>
  6f63de:	e9 54 02 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f63e3:	be 1f 00 00 00       	mov    $0x1f,%esi
  6f63e8:	48 8b bc 24 88 02 00 	mov    0x288(%rsp),%rdi
  6f63ef:	00 
  6f63f0:	48 8b 94 24 80 02 00 	mov    0x280(%rsp),%rdx
  6f63f7:	00 
  6f63f8:	ff 15 b2 53 39 00    	call   *0x3953b2(%rip)        # a8b7b0 <_DYNAMIC+0x358>
  6f63fe:	e9 34 02 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f6403:	c6 44 24 30 01       	movb   $0x1,0x30(%rsp)
  6f6408:	48 8d 3d f9 cb 36 00 	lea    0x36cbf9(%rip),%rdi        # a63008 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xc08>
  6f640f:	ff 15 bb 52 39 00    	call   *0x3952bb(%rip)        # a8b6d0 <_DYNAMIC+0x278>
  6f6415:	e9 1d 02 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f641a:	48 8d 3d 3d 46 96 ff 	lea    -0x69b9c3(%rip),%rdi        # 5aa5e <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2db6>
  6f6421:	48 8d 15 38 ca 36 00 	lea    0x36ca38(%rip),%rdx        # a62e60 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa60>
  6f6428:	be 83 00 00 00       	mov    $0x83,%esi
  6f642d:	ff 15 b5 52 39 00    	call   *0x3952b5(%rip)        # a8b6e8 <_DYNAMIC+0x290>
  6f6433:	e9 ff 01 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f6438:	48 8d 05 e1 c7 36 00 	lea    0x36c7e1(%rip),%rax        # a62c20 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x820>
  6f643f:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  6f6446:	00 
  6f6447:	be 1c 00 00 00       	mov    $0x1c,%esi
  6f644c:	48 8d 05 81 44 96 ff 	lea    -0x69bb7f(%rip),%rax        # 5a8d4 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2c2c>
  6f6453:	48 89 84 24 a0 02 00 	mov    %rax,0x2a0(%rsp)
  6f645a:	00 
  6f645b:	48 8b bc 24 a0 02 00 	mov    0x2a0(%rsp),%rdi
  6f6462:	00 
  6f6463:	48 8b 94 24 00 01 00 	mov    0x100(%rsp),%rdx
  6f646a:	00 
  6f646b:	ff 15 3f 53 39 00    	call   *0x39533f(%rip)        # a8b7b0 <_DYNAMIC+0x358>
  6f6471:	e9 c1 01 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f6476:	48 8d 3d cb ca 36 00 	lea    0x36cacb(%rip),%rdi        # a62f48 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xb48>
  6f647d:	ff 15 4d 52 39 00    	call   *0x39524d(%rip)        # a8b6d0 <_DYNAMIC+0x278>
  6f6483:	e9 af 01 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f6488:	48 8d 05 89 c2 36 00 	lea    0x36c289(%rip),%rax        # a62718 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x318>
  6f648f:	eb 7e                	jmp    6f650f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x50cf>
  6f6491:	48 8d 3d 50 c2 36 00 	lea    0x36c250(%rip),%rdi        # a626e8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x2e8>
  6f6498:	ff 15 32 52 39 00    	call   *0x395232(%rip)        # a8b6d0 <_DYNAMIC+0x278>
  6f649e:	e9 94 01 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f64a3:	48 8d 3d 3e c2 36 00 	lea    0x36c23e(%rip),%rdi        # a626e8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x2e8>
  6f64aa:	ff 15 20 52 39 00    	call   *0x395220(%rip)        # a8b6d0 <_DYNAMIC+0x278>
  6f64b0:	e9 82 01 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f64b5:	48 8d 05 04 ca 36 00 	lea    0x36ca04(%rip),%rax        # a62ec0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xac0>
  6f64bc:	eb 51                	jmp    6f650f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x50cf>
  6f64be:	48 8d 05 13 ca 36 00 	lea    0x36ca13(%rip),%rax        # a62ed8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xad8>
  6f64c5:	eb 48                	jmp    6f650f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x50cf>
  6f64c7:	48 8d 05 42 c6 36 00 	lea    0x36c642(%rip),%rax        # a62b10 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x710>
  6f64ce:	eb 3f                	jmp    6f650f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x50cf>
  6f64d0:	48 8d 05 21 c6 36 00 	lea    0x36c621(%rip),%rax        # a62af8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x6f8>
  6f64d7:	eb 36                	jmp    6f650f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x50cf>
  6f64d9:	4c 89 e3             	mov    %r12,%rbx
  6f64dc:	48 8d 05 15 c6 36 00 	lea    0x36c615(%rip),%rax        # a62af8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x6f8>
  6f64e3:	eb 2a                	jmp    6f650f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x50cf>
  6f64e5:	4c 89 e3             	mov    %r12,%rbx
  6f64e8:	eb 1e                	jmp    6f6508 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x50c8>
  6f64ea:	49 89 c5             	mov    %rax,%r13
  6f64ed:	48 8d 05 04 c6 36 00 	lea    0x36c604(%rip),%rax        # a62af8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x6f8>
  6f64f4:	eb 19                	jmp    6f650f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x50cf>
  6f64f6:	48 89 cb             	mov    %rcx,%rbx
  6f64f9:	49 89 c5             	mov    %rax,%r13
  6f64fc:	48 8d 05 0d c6 36 00 	lea    0x36c60d(%rip),%rax        # a62b10 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x710>
  6f6503:	eb 0a                	jmp    6f650f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x50cf>
  6f6505:	49 89 c5             	mov    %rax,%r13
  6f6508:	48 8d 05 d1 c5 36 00 	lea    0x36c5d1(%rip),%rax        # a62ae0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x6e0>
  6f650f:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  6f6514:	48 89 df             	mov    %rbx,%rdi
  6f6517:	4c 89 ee             	mov    %r13,%rsi
  6f651a:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  6f651f:	ff 15 9b 52 39 00    	call   *0x39529b(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6f6525:	e9 0d 01 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f652a:	41 b4 01             	mov    $0x1,%r12b
  6f652d:	48 8d 15 d4 c9 36 00 	lea    0x36c9d4(%rip),%rdx        # a62f08 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xb08>
  6f6534:	40 b5 01             	mov    $0x1,%bpl
  6f6537:	31 ff                	xor    %edi,%edi
  6f6539:	31 f6                	xor    %esi,%esi
  6f653b:	ff 15 7f 52 39 00    	call   *0x39527f(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6f6541:	e9 f1 00 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f6546:	48 89 f0             	mov    %rsi,%rax
  6f6549:	48 8d 0d 58 ca 36 00 	lea    0x36ca58(%rip),%rcx        # a62fa8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xba8>
  6f6550:	e9 c4 00 00 00       	jmp    6f6619 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51d9>
  6f6555:	48 89 f0             	mov    %rsi,%rax
  6f6558:	48 8d 0d 19 ca 36 00 	lea    0x36ca19(%rip),%rcx        # a62f78 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xb78>
  6f655f:	e9 b5 00 00 00       	jmp    6f6619 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51d9>
  6f6564:	48 89 f0             	mov    %rsi,%rax
  6f6567:	48 8d 0d 22 ca 36 00 	lea    0x36ca22(%rip),%rcx        # a62f90 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xb90>
  6f656e:	e9 a6 00 00 00       	jmp    6f6619 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51d9>
  6f6573:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
  6f6578:	48 89 f0             	mov    %rsi,%rax
  6f657b:	48 8d 0d 56 c2 36 00 	lea    0x36c256(%rip),%rcx        # a627d8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x3d8>
  6f6582:	e9 92 00 00 00       	jmp    6f6619 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51d9>
  6f6587:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  6f658c:	48 8d 0d 5d c2 36 00 	lea    0x36c25d(%rip),%rcx        # a627f0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x3f0>
  6f6593:	e9 81 00 00 00       	jmp    6f6619 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51d9>
  6f6598:	48 8d 15 e1 c2 36 00 	lea    0x36c2e1(%rip),%rdx        # a62880 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x480>
  6f659f:	ff 15 1b 52 39 00    	call   *0x39521b(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6f65a5:	e9 8d 00 00 00       	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f65aa:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  6f65af:	48 8d 0d 6a c2 36 00 	lea    0x36c26a(%rip),%rcx        # a62820 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x420>
  6f65b6:	eb 61                	jmp    6f6619 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51d9>
  6f65b8:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  6f65bd:	48 8d 0d 74 c2 36 00 	lea    0x36c274(%rip),%rcx        # a62838 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x438>
  6f65c4:	eb 53                	jmp    6f6619 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51d9>
  6f65c6:	48 8d 05 9b c2 36 00 	lea    0x36c29b(%rip),%rax        # a62868 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x468>
  6f65cd:	48 89 84 24 20 03 00 	mov    %rax,0x320(%rsp)
  6f65d4:	00 
  6f65d5:	c6 44 24 30 01       	movb   $0x1,0x30(%rsp)
  6f65da:	48 89 df             	mov    %rbx,%rdi
  6f65dd:	48 8b 94 24 20 03 00 	mov    0x320(%rsp),%rdx
  6f65e4:	00 
  6f65e5:	ff 15 d5 51 39 00    	call   *0x3951d5(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6f65eb:	eb 4a                	jmp    6f6637 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51f7>
  6f65ed:	48 8d 0d 04 c5 36 00 	lea    0x36c504(%rip),%rcx        # a62af8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x6f8>
  6f65f4:	eb 23                	jmp    6f6619 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51d9>
  6f65f6:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  6f65fb:	48 8d 0d 0e c5 36 00 	lea    0x36c50e(%rip),%rcx        # a62b10 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x710>
  6f6602:	eb 15                	jmp    6f6619 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51d9>
  6f6604:	48 8d 0d d5 c4 36 00 	lea    0x36c4d5(%rip),%rcx        # a62ae0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x6e0>
  6f660b:	eb 0c                	jmp    6f6619 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x51d9>
  6f660d:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  6f6612:	48 8d 0d 37 c2 36 00 	lea    0x36c237(%rip),%rcx        # a62850 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x450>
  6f6619:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
  6f6620:	00 
  6f6621:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  6f6626:	48 89 c6             	mov    %rax,%rsi
  6f6629:	48 8b 94 24 e0 00 00 	mov    0xe0(%rsp),%rdx
  6f6630:	00 
  6f6631:	ff 15 89 51 39 00    	call   *0x395189(%rip)        # a8b7c0 <_DYNAMIC+0x368>
  6f6637:	0f 0b                	ud2
  6f6639:	48 89 c3             	mov    %rax,%rbx
  6f663c:	49 8b 06             	mov    (%r14),%rax
  6f663f:	0f 28 84 24 60 04 00 	movaps 0x460(%rsp),%xmm0
  6f6646:	00 
  6f6647:	0f 11 80 b0 00 00 00 	movups %xmm0,0xb0(%rax)
  6f664e:	0f 28 84 24 50 04 00 	movaps 0x450(%rsp),%xmm0
  6f6655:	00 
  6f6656:	0f 11 80 a0 00 00 00 	movups %xmm0,0xa0(%rax)
  6f665d:	0f 28 84 24 10 04 00 	movaps 0x410(%rsp),%xmm0
  6f6664:	00 
  6f6665:	0f 28 8c 24 20 04 00 	movaps 0x420(%rsp),%xmm1
  6f666c:	00 
  6f666d:	0f 28 94 24 30 04 00 	movaps 0x430(%rsp),%xmm2
  6f6674:	00 
  6f6675:	66 0f 28 9c 24 40 04 	movapd 0x440(%rsp),%xmm3
  6f667c:	00 00 
  6f667e:	66 0f 11 98 90 00 00 	movupd %xmm3,0x90(%rax)
  6f6685:	00 
  6f6686:	0f 11 90 80 00 00 00 	movups %xmm2,0x80(%rax)
  6f668d:	0f 11 48 70          	movups %xmm1,0x70(%rax)
  6f6691:	0f 11 40 60          	movups %xmm0,0x60(%rax)
  6f6695:	eb 5a                	jmp    6f66f1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x52b1>
  6f6697:	48 89 c3             	mov    %rax,%rbx
  6f669a:	e9 64 06 00 00       	jmp    6f6d03 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x58c3>
  6f669f:	48 89 c3             	mov    %rax,%rbx
  6f66a2:	48 8d bc 24 28 04 00 	lea    0x428(%rsp),%rdi
  6f66a9:	00 
  6f66aa:	e8 51 dd fe ff       	call   6e4400 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::metadata::TextSlot>>>
  6f66af:	48 8d bc 24 40 04 00 	lea    0x440(%rsp),%rdi
  6f66b6:	00 
  6f66b7:	e8 44 dd fe ff       	call   6e4400 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::metadata::TextSlot>>>
  6f66bc:	48 8d bc 24 10 04 00 	lea    0x410(%rsp),%rdi
  6f66c3:	00 
  6f66c4:	e8 27 fc fe ff       	call   6e62f0 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportColumn>>
  6f66c9:	48 8b 84 24 58 04 00 	mov    0x458(%rsp),%rax
  6f66d0:	00 
  6f66d1:	48 85 c0             	test   %rax,%rax
  6f66d4:	74 1b                	je     6f66f1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x52b1>
  6f66d6:	48 8b bc 24 60 04 00 	mov    0x460(%rsp),%rdi
  6f66dd:	00 
  6f66de:	48 c1 e0 03          	shl    $0x3,%rax
  6f66e2:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6f66e6:	ba 08 00 00 00       	mov    $0x8,%edx
  6f66eb:	ff 15 b7 4f 39 00    	call   *0x394fb7(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f66f1:	41 b4 01             	mov    $0x1,%r12b
  6f66f4:	c7 84 24 20 01 00 00 	movl   $0x0,0x120(%rsp)
  6f66fb:	00 00 00 00 
  6f66ff:	b0 01                	mov    $0x1,%al
  6f6701:	89 44 24 48          	mov    %eax,0x48(%rsp)
  6f6705:	c7 44 24 60 00 00 00 	movl   $0x0,0x60(%rsp)
  6f670c:	00 
  6f670d:	41 b5 01             	mov    $0x1,%r13b
  6f6710:	e9 8e 01 00 00       	jmp    6f68a3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5463>
  6f6715:	48 89 c3             	mov    %rax,%rbx
  6f6718:	49 8b 86 c8 06 00 00 	mov    0x6c8(%r14),%rax
  6f671f:	48 c7 40 30 00 00 00 	movq   $0x0,0x30(%rax)
  6f6726:	00 
  6f6727:	45 31 ed             	xor    %r13d,%r13d
  6f672a:	e9 f7 03 00 00       	jmp    6f6b26 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x56e6>
  6f672f:	48 89 c3             	mov    %rax,%rbx
  6f6732:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
  6f6739:	00 
  6f673a:	ba e8 01 00 00       	mov    $0x1e8,%edx
  6f673f:	4c 89 e7             	mov    %r12,%rdi
  6f6742:	ff 15 70 4f 39 00    	call   *0x394f70(%rip)        # a8b6b8 <memcpy@GLIBC_2.14>
  6f6748:	b0 01                	mov    $0x1,%al
  6f674a:	89 84 24 20 01 00 00 	mov    %eax,0x120(%rsp)
  6f6751:	31 ed                	xor    %ebp,%ebp
  6f6753:	41 b4 01             	mov    $0x1,%r12b
  6f6756:	b0 01                	mov    $0x1,%al
  6f6758:	89 44 24 48          	mov    %eax,0x48(%rsp)
  6f675c:	b0 01                	mov    $0x1,%al
  6f675e:	89 44 24 60          	mov    %eax,0x60(%rsp)
  6f6762:	41 b5 01             	mov    $0x1,%r13b
  6f6765:	e9 39 01 00 00       	jmp    6f68a3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5463>
  6f676a:	48 89 c3             	mov    %rax,%rbx
  6f676d:	e9 ae 02 00 00       	jmp    6f6a20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x55e0>
  6f6772:	48 89 c3             	mov    %rax,%rbx
  6f6775:	49 8b 86 c8 06 00 00 	mov    0x6c8(%r14),%rax
  6f677c:	48 8b 8c 24 80 04 00 	mov    0x480(%rsp),%rcx
  6f6783:	00 
  6f6784:	48 89 48 28          	mov    %rcx,0x28(%rax)
  6f6788:	0f 28 84 24 70 04 00 	movaps 0x470(%rsp),%xmm0
  6f678f:	00 
  6f6790:	0f 11 40 18          	movups %xmm0,0x18(%rax)
  6f6794:	41 b5 01             	mov    $0x1,%r13b
  6f6797:	45 31 e4             	xor    %r12d,%r12d
  6f679a:	e9 87 03 00 00       	jmp    6f6b26 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x56e6>
  6f679f:	48 89 c3             	mov    %rax,%rbx
  6f67a2:	41 b4 01             	mov    $0x1,%r12b
  6f67a5:	eb 7d                	jmp    6f6824 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x53e4>
  6f67a7:	48 89 d9             	mov    %rbx,%rcx
  6f67aa:	48 89 c3             	mov    %rax,%rbx
  6f67ad:	48 8b 84 24 80 04 00 	mov    0x480(%rsp),%rax
  6f67b4:	00 
  6f67b5:	49 89 47 10          	mov    %rax,0x10(%r15)
  6f67b9:	0f 28 84 24 70 04 00 	movaps 0x470(%rsp),%xmm0
  6f67c0:	00 
  6f67c1:	41 0f 11 07          	movups %xmm0,(%r15)
  6f67c5:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  6f67ca:	49 89 86 a0 05 00 00 	mov    %rax,0x5a0(%r14)
  6f67d1:	66 41 89 8e a8 05 00 	mov    %cx,0x5a8(%r14)
  6f67d8:	00 
  6f67d9:	8b 84 24 dc 01 00 00 	mov    0x1dc(%rsp),%eax
  6f67e0:	66 41 89 86 aa 05 00 	mov    %ax,0x5aa(%r14)
  6f67e7:	00 
  6f67e8:	f3 0f 10 84 24 9c 00 	movss  0x9c(%rsp),%xmm0
  6f67ef:	00 00 
  6f67f1:	f3 41 0f 11 86 ac 05 	movss  %xmm0,0x5ac(%r14)
  6f67f8:	00 00 
  6f67fa:	45 31 ed             	xor    %r13d,%r13d
  6f67fd:	e9 24 03 00 00       	jmp    6f6b26 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x56e6>
  6f6802:	48 89 c3             	mov    %rax,%rbx
  6f6805:	41 b4 01             	mov    $0x1,%r12b
  6f6808:	4d 85 ff             	test   %r15,%r15
  6f680b:	74 17                	je     6f6824 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x53e4>
  6f680d:	49 c1 e7 04          	shl    $0x4,%r15
  6f6811:	ba 04 00 00 00       	mov    $0x4,%edx
  6f6816:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  6f681b:	4c 89 fe             	mov    %r15,%rsi
  6f681e:	ff 15 84 4e 39 00    	call   *0x394e84(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f6824:	b0 01                	mov    $0x1,%al
  6f6826:	89 44 24 48          	mov    %eax,0x48(%rsp)
  6f682a:	41 b5 01             	mov    $0x1,%r13b
  6f682d:	45 31 ff             	xor    %r15d,%r15d
  6f6830:	80 bc 24 20 01 00 00 	cmpb   $0x0,0x120(%rsp)
  6f6837:	00 
  6f6838:	0f 84 20 03 00 00    	je     6f6b5e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x571e>
  6f683e:	e9 35 03 00 00       	jmp    6f6b78 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5738>
  6f6843:	48 89 c3             	mov    %rax,%rbx
  6f6846:	41 b4 01             	mov    $0x1,%r12b
  6f6849:	b0 01                	mov    $0x1,%al
  6f684b:	89 44 24 48          	mov    %eax,0x48(%rsp)
  6f684f:	b0 01                	mov    $0x1,%al
  6f6851:	89 44 24 60          	mov    %eax,0x60(%rsp)
  6f6855:	41 b7 01             	mov    $0x1,%r15b
  6f6858:	41 b5 01             	mov    $0x1,%r13b
  6f685b:	40 b5 01             	mov    $0x1,%bpl
  6f685e:	48 83 bc 24 90 02 00 	cmpq   $0xffffffffffffffff,0x290(%rsp)
  6f6865:	00 ff 
  6f6867:	0f 85 23 03 00 00    	jne    6f6b90 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5750>
  6f686d:	e9 32 03 00 00       	jmp    6f6ba4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5764>
  6f6872:	44 89 74 24 60       	mov    %r14d,0x60(%rsp)
  6f6877:	48 89 c3             	mov    %rax,%rbx
  6f687a:	45 89 ef             	mov    %r13d,%r15d
  6f687d:	e9 22 03 00 00       	jmp    6f6ba4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5764>
  6f6882:	48 89 c3             	mov    %rax,%rbx
  6f6885:	b0 01                	mov    $0x1,%al
  6f6887:	89 84 24 20 01 00 00 	mov    %eax,0x120(%rsp)
  6f688e:	41 b4 01             	mov    $0x1,%r12b
  6f6891:	b0 01                	mov    $0x1,%al
  6f6893:	89 44 24 48          	mov    %eax,0x48(%rsp)
  6f6897:	b0 01                	mov    $0x1,%al
  6f6899:	89 44 24 60          	mov    %eax,0x60(%rsp)
  6f689d:	41 b5 01             	mov    $0x1,%r13b
  6f68a0:	40 b5 01             	mov    $0x1,%bpl
  6f68a3:	c6 44 24 58 01       	movb   $0x1,0x58(%rsp)
  6f68a8:	e9 79 02 00 00       	jmp    6f6b26 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x56e6>
  6f68ad:	48 89 c3             	mov    %rax,%rbx
  6f68b0:	45 89 fd             	mov    %r15d,%r13d
  6f68b3:	e9 17 03 00 00       	jmp    6f6bcf <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x578f>
  6f68b8:	48 89 c3             	mov    %rax,%rbx
  6f68bb:	45 89 fd             	mov    %r15d,%r13d
  6f68be:	e9 ff 02 00 00       	jmp    6f6bc2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5782>
  6f68c3:	48 89 c3             	mov    %rax,%rbx
  6f68c6:	48 8b 84 24 10 03 00 	mov    0x310(%rsp),%rax
  6f68cd:	00 
  6f68ce:	f0 48 ff 08          	lock decq (%rax)
  6f68d2:	0f 85 17 02 00 00    	jne    6f6aef <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x56af>
  6f68d8:	48 8d bc 24 10 03 00 	lea    0x310(%rsp),%rdi
  6f68df:	00 
  6f68e0:	ff 15 22 4e 39 00    	call   *0x394e22(%rip)        # a8b708 <_DYNAMIC+0x2b0>
  6f68e6:	e9 04 02 00 00       	jmp    6f6aef <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x56af>
  6f68eb:	48 89 c3             	mov    %rax,%rbx
  6f68ee:	40 b5 01             	mov    $0x1,%bpl
  6f68f1:	41 b5 01             	mov    $0x1,%r13b
  6f68f4:	41 b7 01             	mov    $0x1,%r15b
  6f68f7:	b0 01                	mov    $0x1,%al
  6f68f9:	89 44 24 60          	mov    %eax,0x60(%rsp)
  6f68fd:	b0 01                	mov    $0x1,%al
  6f68ff:	89 44 24 48          	mov    %eax,0x48(%rsp)
  6f6903:	41 b4 01             	mov    $0x1,%r12b
  6f6906:	e9 6d 02 00 00       	jmp    6f6b78 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5738>
  6f690b:	48 89 c3             	mov    %rax,%rbx
  6f690e:	4c 89 e7             	mov    %r12,%rdi
  6f6911:	e8 6a bc fe ff       	call   6e2580 <core::ptr::drop_glue::<core::option::Option<gpui::shared_text::SharedText>>>
  6f6916:	e9 2a 01 00 00       	jmp    6f6a45 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5605>
  6f691b:	48 89 c3             	mov    %rax,%rbx
  6f691e:	49 8b 85 c8 06 00 00 	mov    0x6c8(%r13),%rax
  6f6925:	4c 89 78 30          	mov    %r15,0x30(%rax)
  6f6929:	44 89 70 38          	mov    %r14d,0x38(%rax)
  6f692d:	89 68 3c             	mov    %ebp,0x3c(%rax)
  6f6930:	0f 28 84 24 30 09 00 	movaps 0x930(%rsp),%xmm0
  6f6937:	00 
  6f6938:	0f 28 8c 24 40 09 00 	movaps 0x940(%rsp),%xmm1
  6f693f:	00 
  6f6940:	0f 28 94 24 50 09 00 	movaps 0x950(%rsp),%xmm2
  6f6947:	00 
  6f6948:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  6f694c:	0f 11 48 50          	movups %xmm1,0x50(%rax)
  6f6950:	0f 11 50 60          	movups %xmm2,0x60(%rax)
  6f6954:	48 8b 8c 24 60 09 00 	mov    0x960(%rsp),%rcx
  6f695b:	00 
  6f695c:	48 89 48 70          	mov    %rcx,0x70(%rax)
  6f6960:	40 b5 01             	mov    $0x1,%bpl
  6f6963:	e9 bc 03 00 00       	jmp    6f6d24 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x58e4>
  6f6968:	48 89 c3             	mov    %rax,%rbx
  6f696b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
  6f6972:	00 
  6f6973:	ba 98 02 00 00       	mov    $0x298,%edx
  6f6978:	4c 89 f7             	mov    %r14,%rdi
  6f697b:	ff 15 37 4d 39 00    	call   *0x394d37(%rip)        # a8b6b8 <memcpy@GLIBC_2.14>
  6f6981:	e9 50 03 00 00       	jmp    6f6cd6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5896>
  6f6986:	48 89 c3             	mov    %rax,%rbx
  6f6989:	e9 63 03 00 00       	jmp    6f6cf1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x58b1>
  6f698e:	48 89 c3             	mov    %rax,%rbx
  6f6991:	44 88 64 24 30       	mov    %r12b,0x30(%rsp)
  6f6996:	e9 aa 00 00 00       	jmp    6f6a45 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5605>
  6f699b:	e9 4c 01 00 00       	jmp    6f6aec <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x56ac>
  6f69a0:	0f 0b                	ud2
  6f69a2:	0f 0b                	ud2
  6f69a4:	48 89 c3             	mov    %rax,%rbx
  6f69a7:	4d 85 ff             	test   %r15,%r15
  6f69aa:	75 31                	jne    6f69dd <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x559d>
  6f69ac:	48 8b 84 24 e0 01 00 	mov    0x1e0(%rsp),%rax
  6f69b3:	00 
  6f69b4:	48 85 c0             	test   %rax,%rax
  6f69b7:	0f 84 46 03 00 00    	je     6f6d03 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x58c3>
  6f69bd:	48 8b bc 24 e8 01 00 	mov    0x1e8(%rsp),%rdi
  6f69c4:	00 
  6f69c5:	48 c1 e0 03          	shl    $0x3,%rax
  6f69c9:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6f69cd:	ba 08 00 00 00       	mov    $0x8,%edx
  6f69d2:	ff 15 d0 4c 39 00    	call   *0x394cd0(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f69d8:	e9 26 03 00 00       	jmp    6f6d03 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x58c3>
  6f69dd:	49 83 c6 18          	add    $0x18,%r14
  6f69e1:	49 f7 df             	neg    %r15
  6f69e4:	eb 13                	jmp    6f69f9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x55b9>
  6f69e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6f69ed:	00 00 00 
  6f69f0:	49 83 c6 18          	add    $0x18,%r14
  6f69f4:	49 ff cf             	dec    %r15
  6f69f7:	74 b3                	je     6f69ac <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x556c>
  6f69f9:	49 8b 06             	mov    (%r14),%rax
  6f69fc:	f0 48 ff 08          	lock decq (%rax)
  6f6a00:	75 ee                	jne    6f69f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x55b0>
  6f6a02:	4c 89 f7             	mov    %r14,%rdi
  6f6a05:	41 ff d4             	call   *%r12
  6f6a08:	eb e6                	jmp    6f69f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x55b0>
  6f6a0a:	ff 15 d0 4c 39 00    	call   *0x394cd0(%rip)        # a8b6e0 <_DYNAMIC+0x288>
  6f6a10:	48 89 c3             	mov    %rax,%rbx
  6f6a13:	48 8d bc 24 c0 07 00 	lea    0x7c0(%rsp),%rdi
  6f6a1a:	00 
  6f6a1b:	e8 a0 d6 fe ff       	call   6e40c0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui_canvas::image::Image>>>
  6f6a20:	41 b4 01             	mov    $0x1,%r12b
  6f6a23:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
  6f6a2a:	00 
  6f6a2b:	41 b5 01             	mov    $0x1,%r13b
  6f6a2e:	e9 f3 00 00 00       	jmp    6f6b26 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x56e6>
  6f6a33:	e9 9b 02 00 00       	jmp    6f6cd3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5893>
  6f6a38:	e9 96 02 00 00       	jmp    6f6cd3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5893>
  6f6a3d:	e9 91 02 00 00       	jmp    6f6cd3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5893>
  6f6a42:	48 89 c3             	mov    %rax,%rbx
  6f6a45:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
  6f6a4c:	00 
  6f6a4d:	48 85 c0             	test   %rax,%rax
  6f6a50:	0f 95 c1             	setne  %cl
  6f6a53:	84 4c 24 30          	test   %cl,0x30(%rsp)
  6f6a57:	0f 84 92 00 00 00    	je     6f6aef <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x56af>
  6f6a5d:	f0 48 ff 08          	lock decq (%rax)
  6f6a61:	0f 85 88 00 00 00    	jne    6f6aef <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x56af>
  6f6a67:	48 8d bc 24 18 02 00 	lea    0x218(%rsp),%rdi
  6f6a6e:	00 
  6f6a6f:	ff 15 93 4c 39 00    	call   *0x394c93(%rip)        # a8b708 <_DYNAMIC+0x2b0>
  6f6a75:	eb 78                	jmp    6f6aef <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x56af>
  6f6a77:	48 89 c3             	mov    %rax,%rbx
  6f6a7a:	41 b4 01             	mov    $0x1,%r12b
  6f6a7d:	41 b7 01             	mov    $0x1,%r15b
  6f6a80:	41 b5 01             	mov    $0x1,%r13b
  6f6a83:	40 b5 01             	mov    $0x1,%bpl
  6f6a86:	e9 68 01 00 00       	jmp    6f6bf3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x57b3>
  6f6a8b:	48 89 c3             	mov    %rax,%rbx
  6f6a8e:	41 b4 01             	mov    $0x1,%r12b
  6f6a91:	41 b7 01             	mov    $0x1,%r15b
  6f6a94:	41 b5 01             	mov    $0x1,%r13b
  6f6a97:	40 b5 01             	mov    $0x1,%bpl
  6f6a9a:	e9 74 01 00 00       	jmp    6f6c13 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x57d3>
  6f6a9f:	48 89 c3             	mov    %rax,%rbx
  6f6aa2:	41 b4 01             	mov    $0x1,%r12b
  6f6aa5:	41 b7 01             	mov    $0x1,%r15b
  6f6aa8:	41 b5 01             	mov    $0x1,%r13b
  6f6aab:	40 b5 01             	mov    $0x1,%bpl
  6f6aae:	e9 84 01 00 00       	jmp    6f6c37 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x57f7>
  6f6ab3:	48 89 c3             	mov    %rax,%rbx
  6f6ab6:	41 b4 01             	mov    $0x1,%r12b
  6f6ab9:	41 b7 01             	mov    $0x1,%r15b
  6f6abc:	41 b5 01             	mov    $0x1,%r13b
  6f6abf:	40 b5 01             	mov    $0x1,%bpl
  6f6ac2:	e9 94 01 00 00       	jmp    6f6c5b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x581b>
  6f6ac7:	48 89 c3             	mov    %rax,%rbx
  6f6aca:	40 b5 01             	mov    $0x1,%bpl
  6f6acd:	41 b5 01             	mov    $0x1,%r13b
  6f6ad0:	41 b4 01             	mov    $0x1,%r12b
  6f6ad3:	e9 ac 01 00 00       	jmp    6f6c84 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5844>
  6f6ad8:	48 89 c3             	mov    %rax,%rbx
  6f6adb:	e9 da 01 00 00       	jmp    6f6cba <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x587a>
  6f6ae0:	0f 0b                	ud2
  6f6ae2:	0f 0b                	ud2
  6f6ae4:	48 89 c3             	mov    %rax,%rbx
  6f6ae7:	e9 38 02 00 00       	jmp    6f6d24 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x58e4>
  6f6aec:	48 89 c3             	mov    %rax,%rbx
  6f6aef:	40 b5 01             	mov    $0x1,%bpl
  6f6af2:	48 8d bc 24 30 09 00 	lea    0x930(%rsp),%rdi
  6f6af9:	00 
  6f6afa:	e8 01 ea fe ff       	call   6e5500 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  6f6aff:	41 b5 01             	mov    $0x1,%r13b
  6f6b02:	41 b7 01             	mov    $0x1,%r15b
  6f6b05:	b0 01                	mov    $0x1,%al
  6f6b07:	89 44 24 60          	mov    %eax,0x60(%rsp)
  6f6b0b:	b0 01                	mov    $0x1,%al
  6f6b0d:	89 44 24 48          	mov    %eax,0x48(%rsp)
  6f6b11:	41 b4 01             	mov    $0x1,%r12b
  6f6b14:	eb 62                	jmp    6f6b78 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5738>
  6f6b16:	44 89 bc 24 20 01 00 	mov    %r15d,0x120(%rsp)
  6f6b1d:	00 
  6f6b1e:	44 89 74 24 60       	mov    %r14d,0x60(%rsp)
  6f6b23:	48 89 c3             	mov    %rax,%rbx
  6f6b26:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  6f6b2d:	00 
  6f6b2e:	48 85 f6             	test   %rsi,%rsi
  6f6b31:	0f 9f c0             	setg   %al
  6f6b34:	84 44 24 58          	test   %al,0x58(%rsp)
  6f6b38:	74 31                	je     6f6b6b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x572b>
  6f6b3a:	48 8b bc 24 88 00 00 	mov    0x88(%rsp),%rdi
  6f6b41:	00 
  6f6b42:	48 c1 e6 04          	shl    $0x4,%rsi
  6f6b46:	ba 04 00 00 00       	mov    $0x4,%edx
  6f6b4b:	ff 15 57 4b 39 00    	call   *0x394b57(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f6b51:	45 31 ff             	xor    %r15d,%r15d
  6f6b54:	80 bc 24 20 01 00 00 	cmpb   $0x0,0x120(%rsp)
  6f6b5b:	00 
  6f6b5c:	75 1a                	jne    6f6b78 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5738>
  6f6b5e:	48 83 bc 24 90 02 00 	cmpq   $0xffffffffffffffff,0x290(%rsp)
  6f6b65:	00 ff 
  6f6b67:	75 27                	jne    6f6b90 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5750>
  6f6b69:	eb 39                	jmp    6f6ba4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5764>
  6f6b6b:	45 31 ff             	xor    %r15d,%r15d
  6f6b6e:	80 bc 24 20 01 00 00 	cmpb   $0x0,0x120(%rsp)
  6f6b75:	00 
  6f6b76:	74 e6                	je     6f6b5e <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x571e>
  6f6b78:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  6f6b7f:	00 
  6f6b80:	e8 1b f7 fe ff       	call   6e62a0 <core::ptr::drop_glue::<gpui::runtime::scroll::ViewportBuild>>
  6f6b85:	48 83 bc 24 90 02 00 	cmpq   $0xffffffffffffffff,0x290(%rsp)
  6f6b8c:	00 ff 
  6f6b8e:	74 14                	je     6f6ba4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5764>
  6f6b90:	80 7c 24 48 00       	cmpb   $0x0,0x48(%rsp)
  6f6b95:	74 0d                	je     6f6ba4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5764>
  6f6b97:	48 8d bc 24 c0 07 00 	lea    0x7c0(%rsp),%rdi
  6f6b9e:	00 
  6f6b9f:	e8 1c d5 fe ff       	call   6e40c0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui_canvas::image::Image>>>
  6f6ba4:	83 bc 24 10 07 00 00 	cmpl   $0xffffffff,0x710(%rsp)
  6f6bab:	ff 
  6f6bac:	74 14                	je     6f6bc2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5782>
  6f6bae:	80 7c 24 60 00       	cmpb   $0x0,0x60(%rsp)
  6f6bb3:	74 0d                	je     6f6bc2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5782>
  6f6bb5:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f6bbc:	00 
  6f6bbd:	e8 fe fa fe ff       	call   6e66c0 <core::ptr::drop_glue::<gpui::runtime::metadata::Sheet>>
  6f6bc2:	48 8d bc 24 b8 03 00 	lea    0x3b8(%rsp),%rdi
  6f6bc9:	00 
  6f6bca:	e8 f1 49 01 00       	call   70b5c0 <<alloc::collections::btree::map::BTreeMap<gpui::list::ListId, alloc::collections::btree::set_val::SetValZST> as core::ops::drop::Drop>::drop>
  6f6bcf:	48 8b b4 24 58 01 00 	mov    0x158(%rsp),%rsi
  6f6bd6:	00 
  6f6bd7:	48 85 f6             	test   %rsi,%rsi
  6f6bda:	74 17                	je     6f6bf3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x57b3>
  6f6bdc:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
  6f6be3:	00 
  6f6be4:	48 c1 e6 02          	shl    $0x2,%rsi
  6f6be8:	ba 04 00 00 00       	mov    $0x4,%edx
  6f6bed:	ff 15 b5 4a 39 00    	call   *0x394ab5(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f6bf3:	48 8b b4 24 78 01 00 	mov    0x178(%rsp),%rsi
  6f6bfa:	00 
  6f6bfb:	48 85 f6             	test   %rsi,%rsi
  6f6bfe:	74 13                	je     6f6c13 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x57d3>
  6f6c00:	48 8b bc 24 80 01 00 	mov    0x180(%rsp),%rdi
  6f6c07:	00 
  6f6c08:	ba 01 00 00 00       	mov    $0x1,%edx
  6f6c0d:	ff 15 95 4a 39 00    	call   *0x394a95(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f6c13:	48 8b b4 24 38 02 00 	mov    0x238(%rsp),%rsi
  6f6c1a:	00 
  6f6c1b:	48 85 f6             	test   %rsi,%rsi
  6f6c1e:	74 17                	je     6f6c37 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x57f7>
  6f6c20:	48 8b bc 24 40 02 00 	mov    0x240(%rsp),%rdi
  6f6c27:	00 
  6f6c28:	48 c1 e6 04          	shl    $0x4,%rsi
  6f6c2c:	ba 04 00 00 00       	mov    $0x4,%edx
  6f6c31:	ff 15 71 4a 39 00    	call   *0x394a71(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f6c37:	48 8b b4 24 20 02 00 	mov    0x220(%rsp),%rsi
  6f6c3e:	00 
  6f6c3f:	48 85 f6             	test   %rsi,%rsi
  6f6c42:	74 17                	je     6f6c5b <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x581b>
  6f6c44:	48 8b bc 24 28 02 00 	mov    0x228(%rsp),%rdi
  6f6c4b:	00 
  6f6c4c:	48 c1 e6 04          	shl    $0x4,%rsi
  6f6c50:	ba 04 00 00 00       	mov    $0x4,%edx
  6f6c55:	ff 15 4d 4a 39 00    	call   *0x394a4d(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f6c5b:	48 8b 84 24 f8 01 00 	mov    0x1f8(%rsp),%rax
  6f6c62:	00 
  6f6c63:	48 85 c0             	test   %rax,%rax
  6f6c66:	74 17                	je     6f6c7f <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x583f>
  6f6c68:	48 8b bc 24 00 02 00 	mov    0x200(%rsp),%rdi
  6f6c6f:	00 
  6f6c70:	48 6b f0 38          	imul   $0x38,%rax,%rsi
  6f6c74:	ba 08 00 00 00       	mov    $0x8,%edx
  6f6c79:	ff 15 29 4a 39 00    	call   *0x394a29(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f6c7f:	45 84 ff             	test   %r15b,%r15b
  6f6c82:	74 24                	je     6f6ca8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5868>
  6f6c84:	48 8b b4 24 c8 02 00 	mov    0x2c8(%rsp),%rsi
  6f6c8b:	00 
  6f6c8c:	48 85 f6             	test   %rsi,%rsi
  6f6c8f:	74 17                	je     6f6ca8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5868>
  6f6c91:	48 8b bc 24 d0 02 00 	mov    0x2d0(%rsp),%rdi
  6f6c98:	00 
  6f6c99:	48 c1 e6 04          	shl    $0x4,%rsi
  6f6c9d:	ba 04 00 00 00       	mov    $0x4,%edx
  6f6ca2:	ff 15 00 4a 39 00    	call   *0x394a00(%rip)        # a8b6a8 <_DYNAMIC+0x250>
  6f6ca8:	45 84 ed             	test   %r13b,%r13b
  6f6cab:	74 0d                	je     6f6cba <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x587a>
  6f6cad:	48 8d bc 24 b8 01 00 	lea    0x1b8(%rsp),%rdi
  6f6cb4:	00 
  6f6cb5:	e8 86 d2 fe ff       	call   6e3f40 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::Presented>>>
  6f6cba:	83 bc 24 d8 07 00 00 	cmpl   $0xfffffffe,0x7d8(%rsp)
  6f6cc1:	fe 
  6f6cc2:	74 18                	je     6f6cdc <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x589c>
  6f6cc4:	48 8d bc 24 d8 07 00 	lea    0x7d8(%rsp),%rdi
  6f6ccb:	00 
  6f6ccc:	e8 df e4 fe ff       	call   6e51b0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6f6cd1:	eb 09                	jmp    6f6cdc <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x589c>
  6f6cd3:	48 89 c3             	mov    %rax,%rbx
  6f6cd6:	41 b4 01             	mov    $0x1,%r12b
  6f6cd9:	40 b5 01             	mov    $0x1,%bpl
  6f6cdc:	48 8b bc 24 a8 01 00 	mov    0x1a8(%rsp),%rdi
  6f6ce3:	00 
  6f6ce4:	48 8b b4 24 b0 01 00 	mov    0x1b0(%rsp),%rsi
  6f6ceb:	00 
  6f6cec:	e8 ff ba fe ff       	call   6e27f0 <core::ptr::drop_glue::<core::option::Option<gpui_canvas::text::TextShaper>>>
  6f6cf1:	45 84 e4             	test   %r12b,%r12b
  6f6cf4:	74 0d                	je     6f6d03 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x58c3>
  6f6cf6:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
  6f6cfd:	00 
  6f6cfe:	e8 2d d5 fe ff       	call   6e4230 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::text_geometry::Entry>>>
  6f6d03:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
  6f6d0a:	00 
  6f6d0b:	48 85 c0             	test   %rax,%rax
  6f6d0e:	74 14                	je     6f6d24 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x58e4>
  6f6d10:	f0 48 ff 08          	lock decq (%rax)
  6f6d14:	75 0e                	jne    6f6d24 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x58e4>
  6f6d16:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
  6f6d1d:	00 
  6f6d1e:	ff 15 dc 49 39 00    	call   *0x3949dc(%rip)        # a8b700 <_DYNAMIC+0x2a8>
  6f6d24:	83 bc 24 e0 0b 00 00 	cmpl   $0x2,0xbe0(%rsp)
  6f6d2b:	02 
  6f6d2c:	74 12                	je     6f6d40 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5900>
  6f6d2e:	40 84 ed             	test   %bpl,%bpl
  6f6d31:	74 0d                	je     6f6d40 <<gpui::runtime::Runtime<route_columns_cost::Page>>::present_inner+0x5900>
  6f6d33:	48 8d bc 24 e0 0b 00 	lea    0xbe0(%rsp),%rdi
  6f6d3a:	00 
  6f6d3b:	e8 c0 e7 fe ff       	call   6e5500 <core::ptr::drop_glue::<gpui_canvas::canvas::Canvas>>
  6f6d40:	48 89 df             	mov    %rbx,%rdi
  6f6d43:	e8 88 a2 36 00       	call   a60fd0 <_Unwind_Resume@plt>
  6f6d48:	ff 15 92 49 39 00    	call   *0x394992(%rip)        # a8b6e0 <_DYNAMIC+0x288>
