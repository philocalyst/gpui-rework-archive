# Matched baseline fingerprint recovery

Before the packed timing capture, review found that the original baseline's actual Cargo fingerprint JSON had not been preserved across the required source-switch clean. The source/configuration ledger and compiler-artifact JSON were preserved, but were insufficient to claim actual flags. No packed timing capture had started. The baseline was rebuilt once with the unchanged archived instrumentation patch, compiler, configuration, feature set, release profile and benchmark fixture, using one build job.

The rebuilt benchmark binary is byte-identical to the original frozen baseline: SHA-256 `2b183734b499446cbda49ab5ee86357c89d9cbd45b1bc4e4166bfb41cffcb193`. Both its library and example artifacts report `fresh=false`. The actual library and example fingerprint JSON files are byte-identical to the corresponding preserved packed 513 fingerprints. In particular, they have matching compiler fingerprint `12019306335353385202`, release profile `2040997289075261528`, features `[]`, flags `-C symbol-mangling-version=v0 --cfg tokio_unstable`, Cargo configuration `9396254390672932401`, compile kind zero and target IDs. `comparison-proof.json` records this comparison.

The existing complete-owner allocator test was built in release mode with `fresh=false` and frozen separately. Its initial Cargo test invocation omitted `--ignored` and therefore reported one ignored test; that original output is preserved. The frozen test executable was then explicitly run with `--ignored`, and the test passes with all owner rows. It confirms Node/OptionNode 40 bytes, Runtime<()> 1,824 bytes, Win 8 bytes, Handler 16 bytes, El 176 bytes and Draft 152 bytes. This fresh release baseline ledger is not mixed with the earlier debug owner comparison tables. Six benchmark check-mode oracles also pass. No timing mode was run during recovery.

The old unrun timing runner is retained. Version 2 only adds guards for the actual fingerprint files and a version docstring; binaries, cases, counts and ordering are unchanged. Version 2 SHA-256 is `fab2ece2996374bf6da5a458cf77a6a736f256ef6f581f1bc91ebf87bd1ae6d6`.

Commands from the baseline worktree:

```sh
source /tmp/gpui-native-env.sh
unset RUSTFLAGS CARGO_ENCODED_RUSTFLAGS
export CARGO_TARGET_DIR=/root/gpui-route-columns/reactivity/target
cargo clean -p gpui --release
CARGO_BUILD_JOBS=1 cargo build --offline --locked -p gpui --no-default-features --release --example route_columns_cost --jobs 1 --message-format=json
CARGO_BUILD_JOBS=1 cargo test --offline --locked -p gpui --no-default-features --release --lib runtime::route_ledger::complete_owner_route_requests --jobs 1 --message-format=json -- --exact --nocapture --test-threads=1
/tmp/gpui-route-topology-matched-baseline/bin/baseline-release-owner runtime::route_ledger::complete_owner_route_requests --exact --ignored --nocapture --test-threads=1
```

Artifact JSON, build logs, test output, actual fingerprints and the byte-identity comparison accompany this report. The original missing fingerprint evidence was recovered by actual reproduction, not inferred from intended environment settings.
