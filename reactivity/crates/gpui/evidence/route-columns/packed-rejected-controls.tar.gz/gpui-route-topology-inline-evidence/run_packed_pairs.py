#!/usr/bin/env python3
"""Preregistered single capture; run only after the coordinated phase grant."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--cpu', type=int, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parent
assert args.cpu in os.sched_getaffinity(0)
pairs = 9
budget_seconds = 300
cases = [
    ('activate', 1000, 1000, 100000),
    ('activate', 1000, 500, 100000),
    ('activate', 16384, 164, 100000),
    ('activate', 16384, 8192, 100000),
    ('equal', 16384, 0, 32),
    ('equal', 16384, 164, 32),
    ('equal', 16384, 8192, 32),
    ('resize', 16384, 0, 32),
    ('resize', 16384, 164, 32),
    ('snapshot', 16384, 164, 32),
]
paths = {'baseline': root / 'bin/baseline-cost',
         'packed': root / 'bin/topology-inline-cost'}
expected = {
    'baseline': '2b183734b499446cbda49ab5ee86357c89d9cbd45b1bc4e4166bfb41cffcb193',
    'packed': 'b370a49bf1a38df24a69ff117c95164d3b97171c2ae28619f67243615f719c46',
}
source_expected = {
    'source.patch': 'c307666597715a5b5f48e2b7546ab11daa3e49940a0b1d1f8556e2a27f45300b',
    'baseline-expanded-instrumentation.patch': '1a784132ca488f1c4c9fc2d7b676b00d444d2df97a676d8a27ed21a5fe47e732',
    'route_columns_cost.rs': '8ccfa902400b4e8be8e07168130795f5cd9f52181e2496f9233a9d909656b149',
}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert {name: digest(path) for name, path in paths.items()} == expected
assert {name: digest(root / name) for name in source_expected} == source_expected
stats = {name: (path.stat().st_ino, path.stat().st_size, path.stat().st_mtime_ns)
         for name, path in paths.items()}
args.output.mkdir(parents=True, exist_ok=False)
(args.output / 'protocol.json').write_text(json.dumps({
    'cpu': args.cpu, 'affinity_before': sorted(os.sched_getaffinity(0)),
    'pairs': pairs, 'cases': cases, 'sha256': expected,
    'runner_sha256': digest(Path(__file__)), 'source_sha256': source_expected,
    'baseline_commit': '89aeabd53942c3a4643bcb6fd978e6a24703f6d2',
    'candidate_commit': '5135d88bc69c52543d0632726d4af07407668051',
    'order': 'AB for even pairs, BA for odd pairs; fresh process per observation',
    'budget_seconds': budget_seconds,
    'limits': 'Single capture. No deletion, retry, threshold tuning or replacement. Preserve partial failure.',
}, indent=2) + '\n')

def audit(stem):
    result = subprocess.run(['ps', '-eo', 'pid,ppid,psr,pcpu,stat,etime,comm'],
                            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    (args.output / f'{stem}-processes.txt').write_text(result.stdout)
    blocked = {'cargo', 'rustc', 'rust-lld', 'ld', 'ld.lld', 'lld', 'clang', 'clang++', 'gcc', 'g++'}
    active = [line for line in result.stdout.splitlines()[1:]
              if len(line.split()) >= 7 and not line.split()[4].startswith('Z')
              and line.split()[-1] in blocked]
    assert not active, ('build process audit', active)

def child_affinity():
    os.sched_setaffinity(0, {args.cpu})

audit('before')
start = time.monotonic()
with (args.output / 'samples.csv').open('w', newline='') as handle:
    fields = ['pair', 'order', 'position', 'variant', 'operation', 'nodes', 'routes',
              'repetitions', 'elapsed_ns', 'owner_reruns', 'exact_updates', 'digest', 'sha256', 'raw']
    writer = csv.DictWriter(handle, fieldnames=fields)
    writer.writeheader()
    handle.flush()
    for pair in range(pairs):
        audit(f'p{pair}-before')
        order = ['baseline', 'packed'] if pair % 2 == 0 else ['packed', 'baseline']
        for case_number, (operation, nodes, routes, repetitions) in enumerate(cases):
            for position, variant in enumerate(order):
                remaining = budget_seconds - (time.monotonic() - start)
                assert remaining > 0, 'hard capture budget exhausted'
                stem = f'p{pair}-c{case_number}-{position}-{variant}'
                stat = paths[variant].stat()
                assert (stat.st_ino, stat.st_size, stat.st_mtime_ns) == stats[variant]
                try:
                    result = subprocess.run([str(paths[variant]), 'measure', operation, str(nodes),
                                             str(routes), str(repetitions)], text=True,
                                            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                            preexec_fn=child_affinity, timeout=remaining)
                except subprocess.TimeoutExpired as failure:
                    (args.output / (stem + '-partial.txt')).write_text(
                        repr(failure.stdout) + '\n' + repr(failure.stderr) + '\n')
                    raise
                raw = stem + '.txt'
                (args.output / raw).write_text(result.stdout + result.stderr)
                assert result.returncode == 0, (stem, result.returncode, result.stderr)
                lines = [line for line in result.stdout.splitlines() if line.startswith('route_cost,')]
                assert len(lines) == 1, (stem, result.stdout)
                values = dict(field.split('=', 1) for field in lines[0].split(',')[1:])
                assert values['operation'] == operation
                assert int(values['nodes']) == nodes and int(values['routes']) == routes
                assert int(values['repetitions']) == repetitions and int(values['elapsed_ns']) > 0
                assert int(values['owner_reruns']) == (repetitions if operation == 'equal' else 0)
                assert int(values['exact_updates']) == (repetitions if operation == 'activate' else 0)
                assert int(values['digest']) == (routes * repetitions if operation == 'snapshot' else 0)
                writer.writerow(dict(pair=pair, order='AB' if pair % 2 == 0 else 'BA',
                                     position=position, variant=variant, sha256=expected[variant],
                                     raw=raw, **values))
                handle.flush()
        audit(f'p{pair}-after')
        print(f'packed pair {pair + 1}/{pairs} complete, elapsed {time.monotonic() - start:.1f}s', flush=True)
audit('after')
assert {name: digest(path) for name, path in paths.items()} == expected
assert {name: digest(root / name) for name in source_expected} == source_expected
