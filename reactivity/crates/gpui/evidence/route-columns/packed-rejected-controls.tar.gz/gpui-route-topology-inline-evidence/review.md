# Constructor inline successor

Source commit `5135d88bc69c52543d0632726d4af07407668051` differs from frozen packed topology control `8095615af6` by one `#[inline]` attribute on `Topology::new`. No other source change is included. Source count is 30,602 shipping core lines, +89 from baseline and +1 from the packed control.

The release example's selected Cargo artifact has `fresh=false`. The executable was copied before any later build and hashed. Its six check-mode output oracles pass; no measured timing mode was run.

The constructor no longer has a standalone symbol or call. The known-zero fresh-node initialization folds away. The final constructor's bound checks and field packing are visible inline in `describe.asm`, followed by direct row storage. The actual caller grows from 32,572 to 32,735 bytes (+163); removing the 135-byte constructor and changed padding yield linked `.text` of 3,729,735 bytes (+16 from packed control, -416 from baseline). Read-only data grows 8 bytes from packed control (+160 from baseline). Direct activation is still 1,126 bytes and retains the same row load, shift, no-route branch, bounds check, and handler-slot indexing. There is no need for additional const/EMPTY machinery to eliminate the zero initializer.

The packed control's complete-owner ledger and focused correctness results are preserved in the sibling evidence directory. They are not described as tests rebuilt from this successor: this successor has only a release example build and six check-mode output oracles so far. There are no new default, native, strict, foreign-target or timing results.

- Source patch SHA-256: `c307666597715a5b5f48e2b7546ab11daa3e49940a0b1d1f8556e2a27f45300b`.
- Executable SHA-256: `b370a49bf1a38df24a69ff117c95164d3b97171c2ae28619f67243615f719c46`.
- Frozen packed control executable SHA-256: `a7d51e45d197917a7961f92f2be47ff6e1cbe52d72564575f79e44f204940fca`.
- Frozen baseline executable SHA-256: `2b183734b499446cbda49ab5ee86357c89d9cbd45b1bc4e4166bfb41cffcb193`.
