
/tmp/gpui-route-topology-inline-evidence/bin/topology-inline-cost:     file format elf64-x86-64


Disassembly of section .text:

00000000006f7000 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner>:
  6f7000:	55                   	push   %rbp
  6f7001:	41 57                	push   %r15
  6f7003:	41 56                	push   %r14
  6f7005:	41 55                	push   %r13
  6f7007:	41 54                	push   %r12
  6f7009:	53                   	push   %rbx
  6f700a:	48 81 ec e8 08 00 00 	sub    $0x8e8,%rsp
  6f7011:	4d 89 c4             	mov    %r8,%r12
  6f7014:	48 89 cb             	mov    %rcx,%rbx
  6f7017:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  6f701c:	0f b6 86 4a 07 00 00 	movzbl 0x74a(%rsi),%eax
  6f7023:	88 84 24 80 03 00 00 	mov    %al,0x380(%rsp)
  6f702a:	48 ff 86 d8 06 00 00 	incq   0x6d8(%rsi)
  6f7031:	85 d2                	test   %edx,%edx
  6f7033:	75 07                	jne    6f703c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3c>
  6f7035:	48 ff 86 d0 06 00 00 	incq   0x6d0(%rsi)
  6f703c:	48 c7 84 24 90 08 00 	movq   $0x0,0x890(%rsp)
  6f7043:	00 00 00 00 00 
  6f7048:	48 c7 84 24 a0 08 00 	movq   $0x0,0x8a0(%rsp)
  6f704f:	00 00 00 00 00 
  6f7054:	48 8d 86 d0 05 00 00 	lea    0x5d0(%rsi),%rax
  6f705b:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6f7060:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  6f7065:	48 8b 86 40 06 00 00 	mov    0x640(%rsi),%rax
  6f706c:	48 85 c0             	test   %rax,%rax
  6f706f:	74 09                	je     6f707a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a>
  6f7071:	48 8b 90 d8 00 00 00 	mov    0xd8(%rax),%rdx
  6f7078:	eb 02                	jmp    6f707c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c>
  6f707a:	31 d2                	xor    %edx,%edx
  6f707c:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  6f7081:	49 8b 8e a8 06 00 00 	mov    0x6a8(%r14),%rcx
  6f7088:	66 41 0f 6e 86 40 07 	movd   0x740(%r14),%xmm0
  6f708f:	00 00 
  6f7091:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f7098:	00 
  6f7099:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  6f709e:	e8 2d 94 02 00       	call   7204d0 <gpui::runtime::inspector::description::<route_columns_cost::Page>>
  6f70a3:	4d 8d be 28 06 00 00 	lea    0x628(%r14),%r15
  6f70aa:	49 8d 8e 48 06 00 00 	lea    0x648(%r14),%rcx
  6f70b1:	48 8d 84 24 90 08 00 	lea    0x890(%rsp),%rax
  6f70b8:	00 
  6f70b9:	48 89 84 24 f0 02 00 	mov    %rax,0x2f0(%rsp)
  6f70c0:	00 
  6f70c1:	4c 89 bc 24 f8 02 00 	mov    %r15,0x2f8(%rsp)
  6f70c8:	00 
  6f70c9:	48 89 8c 24 40 02 00 	mov    %rcx,0x240(%rsp)
  6f70d0:	00 
  6f70d1:	48 89 8c 24 00 03 00 	mov    %rcx,0x300(%rsp)
  6f70d8:	00 
  6f70d9:	48 c7 84 24 08 03 00 	movq   $0x8,0x308(%rsp)
  6f70e0:	00 08 00 00 00 
  6f70e5:	48 c7 84 24 10 03 00 	movq   $0x0,0x310(%rsp)
  6f70ec:	00 00 00 00 00 
  6f70f1:	4c 8d 05 d0 b5 36 00 	lea    0x36b5d0(%rip),%r8        # a626c8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x238>
  6f70f8:	48 8d bc 24 20 07 00 	lea    0x720(%rsp),%rdi
  6f70ff:	00 
  6f7100:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f7107:	00 
  6f7108:	4c 8d 8c 24 f0 02 00 	lea    0x2f0(%rsp),%r9
  6f710f:	00 
  6f7110:	ba a0 86 01 00       	mov    $0x186a0,%edx
  6f7115:	48 89 d9             	mov    %rbx,%rcx
  6f7118:	e8 43 66 01 00       	call   70d760 <<gpui::element::El>::flatten_lists::<<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#1}>>
  6f711d:	48 8b 94 24 20 07 00 	mov    0x720(%rsp),%rdx
  6f7124:	00 
  6f7125:	48 8b 8c 24 28 07 00 	mov    0x728(%rsp),%rcx
  6f712c:	00 
  6f712d:	4c 8b 84 24 30 07 00 	mov    0x730(%rsp),%r8
  6f7134:	00 
  6f7135:	48 8b bc 24 38 07 00 	mov    0x738(%rsp),%rdi
  6f713c:	00 
  6f713d:	48 8b b4 24 40 07 00 	mov    0x740(%rsp),%rsi
  6f7144:	00 
  6f7145:	4c 8b 8c 24 48 07 00 	mov    0x748(%rsp),%r9
  6f714c:	00 
  6f714d:	48 8d 84 24 50 07 00 	lea    0x750(%rsp),%rax
  6f7154:	00 
  6f7155:	48 89 94 24 50 01 00 	mov    %rdx,0x150(%rsp)
  6f715c:	00 
  6f715d:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
  6f7161:	0f 84 e0 01 00 00    	je     6f7347 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x347>
  6f7167:	4c 89 8c 24 80 00 00 	mov    %r9,0x80(%rsp)
  6f716e:	00 
  6f716f:	4c 89 64 24 78       	mov    %r12,0x78(%rsp)
  6f7174:	4c 89 84 24 88 00 00 	mov    %r8,0x88(%rsp)
  6f717b:	00 
  6f717c:	4c 89 bc 24 20 04 00 	mov    %r15,0x420(%rsp)
  6f7183:	00 
  6f7184:	48 89 bc 24 20 02 00 	mov    %rdi,0x220(%rsp)
  6f718b:	00 
  6f718c:	48 89 b4 24 38 02 00 	mov    %rsi,0x238(%rsp)
  6f7193:	00 
  6f7194:	48 89 8c 24 58 01 00 	mov    %rcx,0x158(%rsp)
  6f719b:	00 
  6f719c:	48 8b 48 10          	mov    0x10(%rax),%rcx
  6f71a0:	48 89 8c 24 00 08 00 	mov    %rcx,0x800(%rsp)
  6f71a7:	00 
  6f71a8:	f3 0f 6f 00          	movdqu (%rax),%xmm0
  6f71ac:	66 0f 7f 84 24 f0 07 	movdqa %xmm0,0x7f0(%rsp)
  6f71b3:	00 00 
  6f71b5:	48 8b 84 24 68 07 00 	mov    0x768(%rsp),%rax
  6f71bc:	00 
  6f71bd:	48 69 94 24 78 07 00 	imul   $0xa8,0x778(%rsp),%rdx
  6f71c4:	00 a8 00 00 00 
  6f71c9:	48 8b b4 24 70 07 00 	mov    0x770(%rsp),%rsi
  6f71d0:	00 
  6f71d1:	48 8b bc 24 90 07 00 	mov    0x790(%rsp),%rdi
  6f71d8:	00 
  6f71d9:	48 89 bc 24 f0 04 00 	mov    %rdi,0x4f0(%rsp)
  6f71e0:	00 
  6f71e1:	f3 0f 6f 8c 24 80 07 	movdqu 0x780(%rsp),%xmm1
  6f71e8:	00 00 
  6f71ea:	66 0f 7f 8c 24 e0 04 	movdqa %xmm1,0x4e0(%rsp)
  6f71f1:	00 00 
  6f71f3:	48 8b bc 24 98 07 00 	mov    0x798(%rsp),%rdi
  6f71fa:	00 
  6f71fb:	48 89 bc 24 28 04 00 	mov    %rdi,0x428(%rsp)
  6f7202:	00 
  6f7203:	48 8b bc 24 a0 07 00 	mov    0x7a0(%rsp),%rdi
  6f720a:	00 
  6f720b:	48 89 bc 24 28 05 00 	mov    %rdi,0x528(%rsp)
  6f7212:	00 
  6f7213:	4c 8b ac 24 a8 07 00 	mov    0x7a8(%rsp),%r13
  6f721a:	00 
  6f721b:	48 89 8c 24 40 04 00 	mov    %rcx,0x440(%rsp)
  6f7222:	00 
  6f7223:	66 0f 7f 84 24 30 04 	movdqa %xmm0,0x430(%rsp)
  6f722a:	00 00 
  6f722c:	48 c7 84 24 48 05 00 	movq   $0x0,0x548(%rsp)
  6f7233:	00 00 00 00 00 
  6f7238:	48 c7 84 24 50 05 00 	movq   $0x8,0x550(%rsp)
  6f723f:	00 08 00 00 00 
  6f7244:	48 c7 84 24 58 05 00 	movq   $0x0,0x558(%rsp)
  6f724b:	00 00 00 00 00 
  6f7250:	48 01 f2             	add    %rsi,%rdx
  6f7253:	48 89 b4 24 90 00 00 	mov    %rsi,0x90(%rsp)
  6f725a:	00 
  6f725b:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
  6f7262:	00 
  6f7263:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6f726a:	00 
  6f726b:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
  6f7272:	00 
  6f7273:	48 8d 84 24 48 05 00 	lea    0x548(%rsp),%rax
  6f727a:	00 
  6f727b:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  6f7282:	00 
  6f7283:	48 8d bc 24 f0 05 00 	lea    0x5f0(%rsp),%rdi
  6f728a:	00 
  6f728b:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f7292:	00 
  6f7293:	e8 18 76 02 00       	call   71e8b0 <alloc::vec::in_place_collect::from_iter_in_place::<core::iter::adapters::filter_map::FilterMap<alloc::vec::into_iter::IntoIter<gpui::list::ViewportDraft>, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#2}>, gpui::list::ListDraft>>
  6f7298:	48 8b 9c 24 f8 05 00 	mov    0x5f8(%rsp),%rbx
  6f729f:	00 
  6f72a0:	4c 69 b4 24 00 06 00 	imul   $0xa8,0x600(%rsp),%r14
  6f72a7:	00 a8 00 00 00 
  6f72ac:	49 01 de             	add    %rbx,%r14
  6f72af:	41 b7 01             	mov    $0x1,%r15b
  6f72b2:	48 8d bc 24 60 08 00 	lea    0x860(%rsp),%rdi
  6f72b9:	00 
  6f72ba:	b0 01                	mov    $0x1,%al
  6f72bc:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6f72c0:	40 b5 01             	mov    $0x1,%bpl
  6f72c3:	41 b4 01             	mov    $0x1,%r12b
  6f72c6:	48 89 de             	mov    %rbx,%rsi
  6f72c9:	4c 89 f2             	mov    %r14,%rdx
  6f72cc:	e8 1f 1b 01 00       	call   708df0 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::iter::traits::collect::FromIterator<(usize, gpui::list::ListId)>>::from_iter::<core::iter::adapters::map::Map<core::slice::iter::Iter<gpui::list::ListDraft>, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#3}>>>
  6f72d1:	48 89 9c 24 90 00 00 	mov    %rbx,0x90(%rsp)
  6f72d8:	00 
  6f72d9:	4c 89 b4 24 98 00 00 	mov    %r14,0x98(%rsp)
  6f72e0:	00 
  6f72e1:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
  6f72e8:	00 00 00 00 00 
  6f72ed:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  6f72f4:	00 00 00 00 00 
  6f72f9:	b3 01                	mov    $0x1,%bl
  6f72fb:	48 8d bc 24 78 08 00 	lea    0x878(%rsp),%rdi
  6f7302:	00 
  6f7303:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f730a:	00 
  6f730b:	b0 01                	mov    $0x1,%al
  6f730d:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6f7311:	40 b5 01             	mov    $0x1,%bpl
  6f7314:	41 b4 01             	mov    $0x1,%r12b
  6f7317:	e8 34 1d 01 00       	call   709050 <<alloc::collections::btree::map::BTreeMap<usize, (gpui::list::ListId, &gpui::list::RowDraft)> as core::iter::traits::collect::FromIterator<(usize, (gpui::list::ListId, &gpui::list::RowDraft))>>::from_iter::<core::iter::adapters::flatten::FlatMap<core::slice::iter::Iter<gpui::list::ListDraft>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui::list::RowDraft>, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#4}::{closure#0}>, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#4}>>>
  6f731c:	4c 8b b4 24 40 04 00 	mov    0x440(%rsp),%r14
  6f7323:	00 
  6f7324:	49 81 fe a0 86 01 00 	cmp    $0x186a0,%r14
  6f732b:	76 50                	jbe    6f737d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x37d>
  6f732d:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f7332:	48 c7 00 1e 00 00 00 	movq   $0x1e,(%rax)
  6f7339:	b0 01                	mov    $0x1,%al
  6f733b:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6f733f:	40 b5 01             	mov    $0x1,%bpl
  6f7342:	e9 1f 61 00 00       	jmp    6fd466 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6466>
  6f7347:	0f 10 00             	movups (%rax),%xmm0
  6f734a:	0f 29 84 24 f0 07 00 	movaps %xmm0,0x7f0(%rsp)
  6f7351:	00 
  6f7352:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f7357:	48 89 08             	mov    %rcx,(%rax)
  6f735a:	4c 89 40 08          	mov    %r8,0x8(%rax)
  6f735e:	48 89 78 10          	mov    %rdi,0x10(%rax)
  6f7362:	48 89 70 18          	mov    %rsi,0x18(%rax)
  6f7366:	4c 89 48 20          	mov    %r9,0x20(%rax)
  6f736a:	66 0f 6f 84 24 f0 07 	movdqa 0x7f0(%rsp),%xmm0
  6f7371:	00 00 
  6f7373:	f3 0f 7f 40 28       	movdqu %xmm0,0x28(%rax)
  6f7378:	e9 2f 63 00 00       	jmp    6fd6ac <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x66ac>
  6f737d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f7382:	48 8b 80 10 06 00 00 	mov    0x610(%rax),%rax
  6f7389:	4c 01 f0             	add    %r14,%rax
  6f738c:	0f 82 f4 63 00 00    	jb     6fd786 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6786>
  6f7392:	48 8b 84 24 28 04 00 	mov    0x428(%rsp),%rax
  6f7399:	00 
  6f739a:	48 89 84 24 f0 02 00 	mov    %rax,0x2f0(%rsp)
  6f73a1:	00 
  6f73a2:	48 8b 84 24 28 05 00 	mov    0x528(%rsp),%rax
  6f73a9:	00 
  6f73aa:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
  6f73b1:	00 
  6f73b2:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
  6f73b9:	00 
  6f73ba:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f73c1:	00 
  6f73c2:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
  6f73c9:	00 
  6f73ca:	ff 15 90 47 39 00    	call   *0x394790(%rip)        # a8bb60 <_DYNAMIC+0x678>
  6f73d0:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f73d7:	00 
  6f73d8:	0f 10 84 24 98 00 00 	movups 0x98(%rsp),%xmm0
  6f73df:	00 
  6f73e0:	0f 29 84 24 20 07 00 	movaps %xmm0,0x720(%rsp)
  6f73e7:	00 
  6f73e8:	0f 10 84 24 a8 00 00 	movups 0xa8(%rsp),%xmm0
  6f73ef:	00 
  6f73f0:	0f 29 84 24 30 07 00 	movaps %xmm0,0x730(%rsp)
  6f73f7:	00 
  6f73f8:	0f 10 84 24 b8 00 00 	movups 0xb8(%rsp),%xmm0
  6f73ff:	00 
  6f7400:	0f 29 84 24 40 07 00 	movaps %xmm0,0x740(%rsp)
  6f7407:	00 
  6f7408:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6f740c:	0f 85 fd 00 00 00    	jne    6f750f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x50f>
  6f7412:	48 8b 84 24 30 07 00 	mov    0x730(%rsp),%rax
  6f7419:	00 
  6f741a:	48 89 84 24 c0 04 00 	mov    %rax,0x4c0(%rsp)
  6f7421:	00 
  6f7422:	0f 28 84 24 20 07 00 	movaps 0x720(%rsp),%xmm0
  6f7429:	00 
  6f742a:	0f 29 84 24 b0 04 00 	movaps %xmm0,0x4b0(%rsp)
  6f7431:	00 
  6f7432:	48 8b 84 24 48 07 00 	mov    0x748(%rsp),%rax
  6f7439:	00 
  6f743a:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
  6f7441:	00 
  6f7442:	f3 0f 6f 84 24 38 07 	movdqu 0x738(%rsp),%xmm0
  6f7449:	00 00 
  6f744b:	66 0f 7f 84 24 c0 07 	movdqa %xmm0,0x7c0(%rsp)
  6f7452:	00 00 
  6f7454:	4d 85 f6             	test   %r14,%r14
  6f7457:	0f 84 f1 00 00 00    	je     6f754e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x54e>
  6f745d:	4a 8d 1c f5 00 00 00 	lea    0x0(,%r14,8),%rbx
  6f7464:	00 
  6f7465:	ff 15 bd 42 39 00    	call   *0x3942bd(%rip)        # a8b728 <_DYNAMIC+0x240>
  6f746b:	be 08 00 00 00       	mov    $0x8,%esi
  6f7470:	48 89 df             	mov    %rbx,%rdi
  6f7473:	ff 15 b7 42 39 00    	call   *0x3942b7(%rip)        # a8b730 <_DYNAMIC+0x248>
  6f7479:	48 85 c0             	test   %rax,%rax
  6f747c:	0f 84 5c 66 00 00    	je     6fdade <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6ade>
  6f7482:	4c 89 b4 24 d8 02 00 	mov    %r14,0x2d8(%rsp)
  6f7489:	00 
  6f748a:	48 89 84 24 e0 02 00 	mov    %rax,0x2e0(%rsp)
  6f7491:	00 
  6f7492:	48 c7 84 24 e8 02 00 	movq   $0x0,0x2e8(%rsp)
  6f7499:	00 00 00 00 00 
  6f749e:	ff 15 84 42 39 00    	call   *0x394284(%rip)        # a8b728 <_DYNAMIC+0x240>
  6f74a4:	be 08 00 00 00       	mov    $0x8,%esi
  6f74a9:	48 89 df             	mov    %rbx,%rdi
  6f74ac:	ff 15 7e 42 39 00    	call   *0x39427e(%rip)        # a8b730 <_DYNAMIC+0x248>
  6f74b2:	48 85 c0             	test   %rax,%rax
  6f74b5:	0f 84 36 66 00 00    	je     6fdaf1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6af1>
  6f74bb:	4c 89 b4 24 48 02 00 	mov    %r14,0x248(%rsp)
  6f74c2:	00 
  6f74c3:	48 89 84 24 50 02 00 	mov    %rax,0x250(%rsp)
  6f74ca:	00 
  6f74cb:	48 c7 84 24 58 02 00 	movq   $0x0,0x258(%rsp)
  6f74d2:	00 00 00 00 00 
  6f74d7:	4a 8d 1c b5 00 00 00 	lea    0x0(,%r14,4),%rbx
  6f74de:	00 
  6f74df:	ff 15 43 42 39 00    	call   *0x394243(%rip)        # a8b728 <_DYNAMIC+0x240>
  6f74e5:	be 04 00 00 00       	mov    $0x4,%esi
  6f74ea:	48 89 df             	mov    %rbx,%rdi
  6f74ed:	ff 15 3d 42 39 00    	call   *0x39423d(%rip)        # a8b730 <_DYNAMIC+0x248>
  6f74f3:	48 85 c0             	test   %rax,%rax
  6f74f6:	0f 85 9f 00 00 00    	jne    6f759b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x59b>
  6f74fc:	bf 04 00 00 00       	mov    $0x4,%edi
  6f7501:	48 89 de             	mov    %rbx,%rsi
  6f7504:	ff 15 f6 42 39 00    	call   *0x3942f6(%rip)        # a8b800 <_DYNAMIC+0x318>
  6f750a:	e9 6e 68 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6f750f:	66 0f 6f 84 24 20 07 	movdqa 0x720(%rsp),%xmm0
  6f7516:	00 00 
  6f7518:	66 0f 6f 8c 24 30 07 	movdqa 0x730(%rsp),%xmm1
  6f751f:	00 00 
  6f7521:	66 0f 6f 94 24 40 07 	movdqa 0x740(%rsp),%xmm2
  6f7528:	00 00 
  6f752a:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6f752f:	f3 0f 7f 51 28       	movdqu %xmm2,0x28(%rcx)
  6f7534:	f3 0f 7f 49 18       	movdqu %xmm1,0x18(%rcx)
  6f7539:	f3 0f 7f 41 08       	movdqu %xmm0,0x8(%rcx)
  6f753e:	48 89 01             	mov    %rax,(%rcx)
  6f7541:	b0 01                	mov    $0x1,%al
  6f7543:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6f7547:	31 ed                	xor    %ebp,%ebp
  6f7549:	e9 18 5f 00 00       	jmp    6fd466 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6466>
  6f754e:	48 c7 84 24 d8 02 00 	movq   $0x0,0x2d8(%rsp)
  6f7555:	00 00 00 00 00 
  6f755a:	48 c7 84 24 e0 02 00 	movq   $0x8,0x2e0(%rsp)
  6f7561:	00 08 00 00 00 
  6f7566:	48 c7 84 24 e8 02 00 	movq   $0x0,0x2e8(%rsp)
  6f756d:	00 00 00 00 00 
  6f7572:	48 c7 84 24 48 02 00 	movq   $0x0,0x248(%rsp)
  6f7579:	00 00 00 00 00 
  6f757e:	48 c7 84 24 50 02 00 	movq   $0x8,0x250(%rsp)
  6f7585:	00 08 00 00 00 
  6f758a:	48 c7 84 24 58 02 00 	movq   $0x0,0x258(%rsp)
  6f7591:	00 00 00 00 00 
  6f7596:	b8 04 00 00 00       	mov    $0x4,%eax
  6f759b:	4c 89 b4 24 60 02 00 	mov    %r14,0x260(%rsp)
  6f75a2:	00 
  6f75a3:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
  6f75aa:	00 
  6f75ab:	48 c7 84 24 70 02 00 	movq   $0x0,0x270(%rsp)
  6f75b2:	00 00 00 00 00 
  6f75b7:	4a 8d 1c f5 08 00 00 	lea    0x8(,%r14,8),%rbx
  6f75be:	00 
  6f75bf:	ff 15 63 41 39 00    	call   *0x394163(%rip)        # a8b728 <_DYNAMIC+0x240>
  6f75c5:	be 08 00 00 00       	mov    $0x8,%esi
  6f75ca:	48 89 9c 24 18 04 00 	mov    %rbx,0x418(%rsp)
  6f75d1:	00 
  6f75d2:	48 89 df             	mov    %rbx,%rdi
  6f75d5:	ff 15 8d 45 39 00    	call   *0x39458d(%rip)        # a8bb68 <_DYNAMIC+0x680>
  6f75db:	48 89 84 24 d0 02 00 	mov    %rax,0x2d0(%rsp)
  6f75e2:	00 
  6f75e3:	48 85 c0             	test   %rax,%rax
  6f75e6:	0f 84 70 64 00 00    	je     6fda5c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a5c>
  6f75ec:	49 8d 46 01          	lea    0x1(%r14),%rax
  6f75f0:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
  6f75f7:	00 
  6f75f8:	4c 8b bc 24 38 04 00 	mov    0x438(%rsp),%r15
  6f75ff:	00 
  6f7600:	48 c7 84 24 60 01 00 	movq   $0x0,0x160(%rsp)
  6f7607:	00 00 00 00 00 
  6f760c:	48 c7 84 24 70 01 00 	movq   $0x0,0x170(%rsp)
  6f7613:	00 00 00 00 00 
  6f7618:	4d 85 f6             	test   %r14,%r14
  6f761b:	4c 89 b4 24 90 02 00 	mov    %r14,0x290(%rsp)
  6f7622:	00 
  6f7623:	0f 84 c6 04 00 00    	je     6f7aef <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xaef>
  6f7629:	49 69 c6 98 00 00 00 	imul   $0x98,%r14,%rax
  6f7630:	4c 01 f8             	add    %r15,%rax
  6f7633:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6f7638:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f763d:	48 05 28 02 00 00    	add    $0x228,%rax
  6f7643:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6f7648:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
  6f764f:	00 00 
  6f7651:	48 8d 05 e8 b2 36 00 	lea    0x36b2e8(%rip),%rax        # a62940 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x4b0>
  6f7658:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6f765d:	48 b8 01 00 00 00 00 	movabs $0x8000000000000001,%rax
  6f7664:	00 00 80 
  6f7667:	48 ff c0             	inc    %rax
  6f766a:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  6f766f:	48 c7 84 24 18 02 00 	movq   $0x0,0x218(%rsp)
  6f7676:	00 00 00 00 00 
  6f767b:	41 0f b6 5f 18       	movzbl 0x18(%r15),%ebx
  6f7680:	41 8b 6f 1c          	mov    0x1c(%r15),%ebp
  6f7684:	48 8d 45 01          	lea    0x1(%rbp),%rax
  6f7688:	84 db                	test   %bl,%bl
  6f768a:	b9 00 00 00 00       	mov    $0x0,%ecx
  6f768f:	48 0f 45 c8          	cmovne %rax,%rcx
  6f7693:	48 3b 8c 24 90 02 00 	cmp    0x290(%rsp),%rcx
  6f769a:	00 
  6f769b:	0f 87 a4 63 00 00    	ja     6fda45 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a45>
  6f76a1:	48 8b 84 24 d0 02 00 	mov    0x2d0(%rsp),%rax
  6f76a8:	00 
  6f76a9:	48 ff 04 c8          	incq   (%rax,%rcx,8)
  6f76ad:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
  6f76b4:	00 
  6f76b5:	4c 8b a4 24 e8 02 00 	mov    0x2e8(%rsp),%r12
  6f76bc:	00 
  6f76bd:	84 db                	test   %bl,%bl
  6f76bf:	74 29                	je     6f76ea <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6ea>
  6f76c1:	49 39 ec             	cmp    %rbp,%r12
  6f76c4:	0f 86 46 64 00 00    	jbe    6fdb10 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b10>
  6f76ca:	4c 8b 34 e8          	mov    (%rax,%rbp,8),%r14
  6f76ce:	49 ff c6             	inc    %r14
  6f76d1:	49 81 fe 80 00 00 00 	cmp    $0x80,%r14
  6f76d8:	0f 87 ab 39 00 00    	ja     6fb089 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4089>
  6f76de:	4c 3b a4 24 d8 02 00 	cmp    0x2d8(%rsp),%r12
  6f76e5:	00 
  6f76e6:	74 0f                	je     6f76f7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6f7>
  6f76e8:	eb 23                	jmp    6f770d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x70d>
  6f76ea:	45 31 f6             	xor    %r14d,%r14d
  6f76ed:	4c 3b a4 24 d8 02 00 	cmp    0x2d8(%rsp),%r12
  6f76f4:	00 
  6f76f5:	75 16                	jne    6f770d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x70d>
  6f76f7:	48 8d bc 24 d8 02 00 	lea    0x2d8(%rsp),%rdi
  6f76fe:	00 
  6f76ff:	ff 15 6b 44 39 00    	call   *0x39446b(%rip)        # a8bb70 <_DYNAMIC+0x688>
  6f7705:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
  6f770c:	00 
  6f770d:	4e 89 34 e0          	mov    %r14,(%rax,%r12,8)
  6f7711:	49 ff c4             	inc    %r12
  6f7714:	4c 89 a4 24 e8 02 00 	mov    %r12,0x2e8(%rsp)
  6f771b:	00 
  6f771c:	45 31 f6             	xor    %r14d,%r14d
  6f771f:	84 db                	test   %bl,%bl
  6f7721:	74 1d                	je     6f7740 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x740>
  6f7723:	4c 8b a4 24 70 02 00 	mov    0x270(%rsp),%r12
  6f772a:	00 
  6f772b:	49 39 ec             	cmp    %rbp,%r12
  6f772e:	0f 86 d0 63 00 00    	jbe    6fdb04 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b04>
  6f7734:	48 8b 84 24 68 02 00 	mov    0x268(%rsp),%rax
  6f773b:	00 
  6f773c:	44 8b 34 a8          	mov    (%rax,%rbp,4),%r14d
  6f7740:	4d 8b a7 88 00 00 00 	mov    0x88(%r15),%r12
  6f7747:	4d 85 e4             	test   %r12,%r12
  6f774a:	0f 84 9a 00 00 00    	je     6f77ea <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ea>
  6f7750:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
  6f7755:	0f 84 e7 5f 00 00    	je     6fd742 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6742>
  6f775b:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
  6f7760:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f7767:	00 
  6f7768:	4c 89 e6             	mov    %r12,%rsi
  6f776b:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f7770:	48 8d 0d 11 af 36 00 	lea    0x36af11(%rip),%rcx        # a62688 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x1f8>
  6f7777:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  6f777c:	4c 8d 0d 25 af 36 00 	lea    0x36af25(%rip),%r9        # a626a8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x218>
  6f7783:	ff 15 ef 43 39 00    	call   *0x3943ef(%rip)        # a8bb78 <_DYNAMIC+0x690>
  6f7789:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f7790:	00 
  6f7791:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f7795:	0f 85 de 06 00 00    	jne    6f7e79 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xe79>
  6f779b:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f77a2:	00 
  6f77a3:	4c 89 e6             	mov    %r12,%rsi
  6f77a6:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f77ab:	48 8d 0d d6 ae 36 00 	lea    0x36aed6(%rip),%rcx        # a62688 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x1f8>
  6f77b2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  6f77b7:	4c 8d 0d ea ae 36 00 	lea    0x36aeea(%rip),%r9        # a626a8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x218>
  6f77be:	ff 15 bc 43 39 00    	call   *0x3943bc(%rip)        # a8bb80 <_DYNAMIC+0x698>
  6f77c4:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f77cb:	00 
  6f77cc:	44 8b b4 24 98 00 00 	mov    0x98(%rsp),%r14d
  6f77d3:	00 
  6f77d4:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f77d8:	0f 85 bc 06 00 00    	jne    6f7e9a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xe9a>
  6f77de:	49 89 dc             	mov    %rbx,%r12
  6f77e1:	48 85 db             	test   %rbx,%rbx
  6f77e4:	0f 85 66 ff ff ff    	jne    6f7750 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x750>
  6f77ea:	48 8b 9c 24 70 02 00 	mov    0x270(%rsp),%rbx
  6f77f1:	00 
  6f77f2:	48 3b 9c 24 60 02 00 	cmp    0x260(%rsp),%rbx
  6f77f9:	00 
  6f77fa:	75 0e                	jne    6f780a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x80a>
  6f77fc:	48 8d bc 24 60 02 00 	lea    0x260(%rsp),%rdi
  6f7803:	00 
  6f7804:	ff 15 7e 43 39 00    	call   *0x39437e(%rip)        # a8bb88 <_DYNAMIC+0x6a0>
  6f780a:	48 8b 84 24 68 02 00 	mov    0x268(%rsp),%rax
  6f7811:	00 
  6f7812:	44 89 34 98          	mov    %r14d,(%rax,%rbx,4)
  6f7816:	48 ff c3             	inc    %rbx
  6f7819:	48 89 9c 24 70 02 00 	mov    %rbx,0x270(%rsp)
  6f7820:	00 
  6f7821:	49 83 7f 78 00       	cmpq   $0x0,0x78(%r15)
  6f7826:	74 54                	je     6f787c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x87c>
  6f7828:	49 8d 77 78          	lea    0x78(%r15),%rsi
  6f782c:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f7833:	00 
  6f7834:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f7839:	48 8d 0d 48 ae 36 00 	lea    0x36ae48(%rip),%rcx        # a62688 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x1f8>
  6f7840:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  6f7845:	4c 8d 0d 5c ae 36 00 	lea    0x36ae5c(%rip),%r9        # a626a8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x218>
  6f784c:	ff 15 be 41 39 00    	call   *0x3941be(%rip)        # a8ba10 <_DYNAMIC+0x528>
  6f7852:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f7859:	00 
  6f785a:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f785e:	0f 85 36 38 00 00    	jne    6fb09a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x409a>
  6f7864:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6f7869:	48 ff c0             	inc    %rax
  6f786c:	4d 8b 27             	mov    (%r15),%r12
  6f786f:	49 83 fc ff          	cmp    $0xffffffffffffffff,%r12
  6f7873:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  6f7878:	75 15                	jne    6f788f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x88f>
  6f787a:	eb 67                	jmp    6f78e3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x8e3>
  6f787c:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6f7881:	4d 8b 27             	mov    (%r15),%r12
  6f7884:	49 83 fc ff          	cmp    $0xffffffffffffffff,%r12
  6f7888:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  6f788d:	74 54                	je     6f78e3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x8e3>
  6f788f:	4c 3b 64 24 68       	cmp    0x68(%rsp),%r12
  6f7894:	75 4d                	jne    6f78e3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x8e3>
  6f7896:	49 8b 4f 08          	mov    0x8(%r15),%rcx
  6f789a:	4d 8b 47 10          	mov    0x10(%r15),%r8
  6f789e:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f78a5:	00 
  6f78a6:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  6f78ab:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f78b0:	e8 2b 9b 02 00       	call   7213e0 <<gpui::source::Sources<route_columns_cost::Page>>::resolve>
  6f78b5:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f78bc:	00 
  6f78bd:	48 8b 9c 24 98 00 00 	mov    0x98(%rsp),%rbx
  6f78c4:	00 
  6f78c5:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f78c9:	0f 85 41 5e 00 00    	jne    6fd710 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6710>
  6f78cf:	41 80 bf 90 00 00 00 	cmpb   $0x4,0x90(%r15)
  6f78d6:	04 
  6f78d7:	75 16                	jne    6f78ef <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x8ef>
  6f78d9:	48 85 db             	test   %rbx,%rbx
  6f78dc:	75 1a                	jne    6f78f8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x8f8>
  6f78de:	e9 4d 59 00 00       	jmp    6fd230 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6230>
  6f78e3:	31 db                	xor    %ebx,%ebx
  6f78e5:	41 80 bf 90 00 00 00 	cmpb   $0x4,0x90(%r15)
  6f78ec:	04 
  6f78ed:	74 ea                	je     6f78d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x8d9>
  6f78ef:	48 85 db             	test   %rbx,%rbx
  6f78f2:	0f 84 7d 01 00 00    	je     6f7a75 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xa75>
  6f78f8:	49 83 fc ff          	cmp    $0xffffffffffffffff,%r12
  6f78fc:	0f 84 44 19 00 00    	je     6f9246 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2246>
  6f7902:	4c 89 ff             	mov    %r15,%rdi
  6f7905:	ff 15 85 42 39 00    	call   *0x394285(%rip)        # a8bb90 <_DYNAMIC+0x6a8>
  6f790b:	48 85 c0             	test   %rax,%rax
  6f790e:	0f 84 32 19 00 00    	je     6f9246 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2246>
  6f7914:	48 8b 8c 24 60 01 00 	mov    0x160(%rsp),%rcx
  6f791b:	00 
  6f791c:	48 85 c9             	test   %rcx,%rcx
  6f791f:	0f 84 7d 00 00 00    	je     6f79a2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x9a2>
  6f7925:	48 8b 94 24 68 01 00 	mov    0x168(%rsp),%rdx
  6f792c:	00 
  6f792d:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6f7934:	89 f7                	mov    %esi,%edi
  6f7936:	c1 e7 03             	shl    $0x3,%edi
  6f7939:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
  6f7940:	48 85 ff             	test   %rdi,%rdi
  6f7943:	74 27                	je     6f796c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x96c>
  6f7945:	4a 3b 9c e9 70 01 00 	cmp    0x170(%rcx,%r13,8),%rbx
  6f794c:	00 
  6f794d:	41 0f 97 c0          	seta   %r8b
  6f7951:	41 80 d8 00          	sbb    $0x0,%r8b
  6f7955:	49 ff c5             	inc    %r13
  6f7958:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  6f795c:	41 80 f8 01          	cmp    $0x1,%r8b
  6f7960:	74 de                	je     6f7940 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x940>
  6f7962:	41 0f b6 f0          	movzbl %r8b,%esi
  6f7966:	85 f6                	test   %esi,%esi
  6f7968:	75 05                	jne    6f796f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x96f>
  6f796a:	eb 17                	jmp    6f7983 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x983>
  6f796c:	49 89 f5             	mov    %rsi,%r13
  6f796f:	48 83 ea 01          	sub    $0x1,%rdx
  6f7973:	0f 82 4e 01 00 00    	jb     6f7ac7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xac7>
  6f7979:	4a 8b 8c e9 c8 01 00 	mov    0x1c8(%rcx,%r13,8),%rcx
  6f7980:	00 
  6f7981:	eb aa                	jmp    6f792d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x92d>
  6f7983:	4c 89 ee             	mov    %r13,%rsi
  6f7986:	4c 8d ac 24 60 01 00 	lea    0x160(%rsp),%r13
  6f798d:	00 
  6f798e:	48 89 f7             	mov    %rsi,%rdi
  6f7991:	48 c1 e7 05          	shl    $0x5,%rdi
  6f7995:	48 01 cf             	add    %rcx,%rdi
  6f7998:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
  6f799d:	e9 94 00 00 00       	jmp    6f7a36 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xa36>
  6f79a2:	31 d2                	xor    %edx,%edx
  6f79a4:	48 89 9c 24 90 00 00 	mov    %rbx,0x90(%rsp)
  6f79ab:	00 
  6f79ac:	48 8d 8c 24 60 01 00 	lea    0x160(%rsp),%rcx
  6f79b3:	00 
  6f79b4:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  6f79bb:	00 
  6f79bc:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
  6f79c3:	00 
  6f79c4:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  6f79c9:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
  6f79d0:	00 
  6f79d1:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
  6f79d8:	00 
  6f79d9:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
  6f79e0:	00 
  6f79e1:	48 c7 84 24 f0 02 00 	movq   $0x0,0x2f0(%rsp)
  6f79e8:	00 00 00 00 00 
  6f79ed:	48 c7 84 24 f8 02 00 	movq   $0x4,0x2f8(%rsp)
  6f79f4:	00 04 00 00 00 
  6f79f9:	48 c7 84 24 00 03 00 	movq   $0x0,0x300(%rsp)
  6f7a00:	00 00 00 00 00 
  6f7a05:	48 8d bc 24 20 07 00 	lea    0x720(%rsp),%rdi
  6f7a0c:	00 
  6f7a0d:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f7a14:	00 
  6f7a15:	48 8d 94 24 f0 02 00 	lea    0x2f0(%rsp),%rdx
  6f7a1c:	00 
  6f7a1d:	e8 9e 9e 01 00       	call   7118c0 <<alloc::collections::btree::map::entry::VacantEntry<gpui::source::FieldId, gpui::runtime::Fanout>>::insert_entry>
  6f7a22:	48 8b bc 24 30 07 00 	mov    0x730(%rsp),%rdi
  6f7a29:	00 
  6f7a2a:	48 c1 e7 05          	shl    $0x5,%rdi
  6f7a2e:	48 03 bc 24 20 07 00 	add    0x720(%rsp),%rdi
  6f7a35:	00 
  6f7a36:	ff 15 5c 41 39 00    	call   *0x39415c(%rip)        # a8bb98 <_DYNAMIC+0x6b0>
  6f7a3c:	49 89 c4             	mov    %rax,%r12
  6f7a3f:	48 8b bc 24 18 02 00 	mov    0x218(%rsp),%rdi
  6f7a46:	00 
  6f7a47:	31 f6                	xor    %esi,%esi
  6f7a49:	ff 15 51 41 39 00    	call   *0x394151(%rip)        # a8bba0 <_DYNAMIC+0x6b8>
  6f7a4f:	89 c5                	mov    %eax,%ebp
  6f7a51:	4d 8b 74 24 10       	mov    0x10(%r12),%r14
  6f7a56:	4d 3b 34 24          	cmp    (%r12),%r14
  6f7a5a:	75 08                	jne    6f7a64 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xa64>
  6f7a5c:	4c 89 e7             	mov    %r12,%rdi
  6f7a5f:	e8 1c 95 02 00       	call   720f80 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  6f7a64:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  6f7a69:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
  6f7a6d:	49 ff c6             	inc    %r14
  6f7a70:	4d 89 74 24 10       	mov    %r14,0x10(%r12)
  6f7a75:	4c 8b b4 24 58 02 00 	mov    0x258(%rsp),%r14
  6f7a7c:	00 
  6f7a7d:	4c 3b b4 24 48 02 00 	cmp    0x248(%rsp),%r14
  6f7a84:	00 
  6f7a85:	75 0d                	jne    6f7a94 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xa94>
  6f7a87:	48 8d bc 24 48 02 00 	lea    0x248(%rsp),%rdi
  6f7a8e:	00 
  6f7a8f:	e8 fc 90 02 00       	call   720b90 <<alloc::raw_vec::RawVec<core::option::Option<gpui::source::FieldId>>>::grow_one>
  6f7a94:	49 81 c7 98 00 00 00 	add    $0x98,%r15
  6f7a9b:	48 ff 84 24 18 02 00 	incq   0x218(%rsp)
  6f7aa2:	00 
  6f7aa3:	48 8b 84 24 50 02 00 	mov    0x250(%rsp),%rax
  6f7aaa:	00 
  6f7aab:	4a 89 1c f0          	mov    %rbx,(%rax,%r14,8)
  6f7aaf:	49 ff c6             	inc    %r14
  6f7ab2:	4c 89 b4 24 58 02 00 	mov    %r14,0x258(%rsp)
  6f7ab9:	00 
  6f7aba:	4c 3b 7c 24 40       	cmp    0x40(%rsp),%r15
  6f7abf:	0f 85 b6 fb ff ff    	jne    6f767b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x67b>
  6f7ac5:	eb 31                	jmp    6f7af8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xaf8>
  6f7ac7:	48 89 ca             	mov    %rcx,%rdx
  6f7aca:	48 8d 8c 24 60 01 00 	lea    0x160(%rsp),%rcx
  6f7ad1:	00 
  6f7ad2:	be 00 00 00 00       	mov    $0x0,%esi
  6f7ad7:	bf 00 00 00 00       	mov    $0x0,%edi
  6f7adc:	48 89 7c 24 60       	mov    %rdi,0x60(%rsp)
  6f7ae1:	48 85 db             	test   %rbx,%rbx
  6f7ae4:	0f 85 ba fe ff ff    	jne    6f79a4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x9a4>
  6f7aea:	e9 9f fe ff ff       	jmp    6f798e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x98e>
  6f7aef:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
  6f7af6:	00 00 
  6f7af8:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
  6f7aff:	00 
  6f7b00:	48 89 ca             	mov    %rcx,%rdx
  6f7b03:	48 c1 e2 04          	shl    $0x4,%rdx
  6f7b07:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  6f7b0e:	00 
  6f7b0f:	48 89 94 24 50 08 00 	mov    %rdx,0x850(%rsp)
  6f7b16:	00 
  6f7b17:	48 01 d0             	add    %rdx,%rax
  6f7b1a:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
  6f7b21:	00 
  6f7b22:	48 85 c9             	test   %rcx,%rcx
  6f7b25:	74 4a                	je     6f7b71 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xb71>
  6f7b27:	4c 8b 3d c2 3d 39 00 	mov    0x393dc2(%rip),%r15        # a8b8f0 <_DYNAMIC+0x408>
  6f7b2e:	48 8d 9c 24 90 00 00 	lea    0x90(%rsp),%rbx
  6f7b35:	00 
  6f7b36:	4c 8b a4 24 58 01 00 	mov    0x158(%rsp),%r12
  6f7b3d:	00 
  6f7b3e:	66 90                	xchg   %ax,%ax
  6f7b40:	4d 8b 34 24          	mov    (%r12),%r14
  6f7b44:	66 41 0f 6e 44 24 08 	movd   0x8(%r12),%xmm0
  6f7b4b:	66 0f 7e 84 24 90 00 	movd   %xmm0,0x90(%rsp)
  6f7b52:	00 00 
  6f7b54:	48 89 df             	mov    %rbx,%rdi
  6f7b57:	41 ff 57 10          	call   *0x10(%r15)
  6f7b5b:	3c ff                	cmp    $0xff,%al
  6f7b5d:	0f 85 90 08 00 00    	jne    6f83f3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x13f3>
  6f7b63:	49 83 c4 10          	add    $0x10,%r12
  6f7b67:	4c 3b a4 24 18 02 00 	cmp    0x218(%rsp),%r12
  6f7b6e:	00 
  6f7b6f:	75 cf                	jne    6f7b40 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xb40>
  6f7b71:	48 c7 84 24 f0 07 00 	movq   $0x0,0x7f0(%rsp)
  6f7b78:	00 00 00 00 00 
  6f7b7d:	48 c7 84 24 f8 07 00 	movq   $0x8,0x7f8(%rsp)
  6f7b84:	00 08 00 00 00 
  6f7b89:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6f7b8d:	f3 0f 7f 84 24 00 08 	movdqu %xmm0,0x800(%rsp)
  6f7b94:	00 00 
  6f7b96:	48 c7 84 24 10 08 00 	movq   $0x4,0x810(%rsp)
  6f7b9d:	00 04 00 00 00 
  6f7ba2:	48 c7 84 24 48 08 00 	movq   $0x0,0x848(%rsp)
  6f7ba9:	00 00 00 00 00 
  6f7bae:	f3 0f 7f 84 24 18 08 	movdqu %xmm0,0x818(%rsp)
  6f7bb5:	00 00 
  6f7bb7:	48 c7 84 24 28 08 00 	movq   $0x4,0x828(%rsp)
  6f7bbe:	00 04 00 00 00 
  6f7bc3:	f3 0f 7f 84 24 30 08 	movdqu %xmm0,0x830(%rsp)
  6f7bca:	00 00 
  6f7bcc:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  6f7bd3:	00 
  6f7bd4:	48 85 c0             	test   %rax,%rax
  6f7bd7:	0f 84 ec 02 00 00    	je     6f7ec9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xec9>
  6f7bdd:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  6f7be1:	4c 8b ac 24 38 02 00 	mov    0x238(%rsp),%r13
  6f7be8:	00 
  6f7be9:	48 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%rax
  6f7bf0:	00 
  6f7bf1:	4c 01 e8             	add    %r13,%rax
  6f7bf4:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6f7bf9:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f7bfe:	48 05 28 02 00 00    	add    $0x228,%rax
  6f7c04:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6f7c0b:	00 
  6f7c0c:	48 8b 84 24 38 04 00 	mov    0x438(%rsp),%rax
  6f7c13:	00 
  6f7c14:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6f7c19:	48 8b 84 24 40 04 00 	mov    0x440(%rsp),%rax
  6f7c20:	00 
  6f7c21:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f7c26:	eb 1e                	jmp    6f7c46 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xc46>
  6f7c28:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6f7c2c:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
  6f7c30:	49 ff c6             	inc    %r14
  6f7c33:	4c 89 73 10          	mov    %r14,0x10(%rbx)
  6f7c37:	49 83 c5 18          	add    $0x18,%r13
  6f7c3b:	4c 3b 6c 24 40       	cmp    0x40(%rsp),%r13
  6f7c40:	0f 84 83 02 00 00    	je     6f7ec9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xec9>
  6f7c46:	41 0f b7 6d 14       	movzwl 0x14(%r13),%ebp
  6f7c4b:	66 85 ed             	test   %bp,%bp
  6f7c4e:	0f 84 75 02 00 00    	je     6f7ec9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xec9>
  6f7c54:	49 8b 5d 00          	mov    0x0(%r13),%rbx
  6f7c58:	4d 8b 75 08          	mov    0x8(%r13),%r14
  6f7c5c:	41 8b 45 10          	mov    0x10(%r13),%eax
  6f7c60:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6f7c65:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f7c6c:	00 
  6f7c6d:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  6f7c74:	00 
  6f7c75:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f7c7a:	48 89 d9             	mov    %rbx,%rcx
  6f7c7d:	4d 89 f0             	mov    %r14,%r8
  6f7c80:	e8 5b 97 02 00       	call   7213e0 <<gpui::source::Sources<route_columns_cost::Page>>::resolve>
  6f7c85:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f7c8c:	00 
  6f7c8d:	4c 8b bc 24 98 00 00 	mov    0x98(%rsp),%r15
  6f7c94:	00 
  6f7c95:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f7c99:	0f 85 bc 13 00 00    	jne    6f905b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x205b>
  6f7c9f:	4d 85 ff             	test   %r15,%r15
  6f7ca2:	74 93                	je     6f7c37 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xc37>
  6f7ca4:	89 e8                	mov    %ebp,%eax
  6f7ca6:	25 fe ff 00 00       	and    $0xfffe,%eax
  6f7cab:	66 83 f8 06          	cmp    $0x6,%ax
  6f7caf:	75 5d                	jne    6f7d0e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd0e>
  6f7cb1:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  6f7cb6:	48 39 7c 24 60       	cmp    %rdi,0x60(%rsp)
  6f7cbb:	0f 86 67 5e 00 00    	jbe    6fdb28 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b28>
  6f7cc1:	48 69 c7 98 00 00 00 	imul   $0x98,%rdi,%rax
  6f7cc8:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  6f7ccd:	f3 0f 6f 44 01 3c    	movdqu 0x3c(%rcx,%rax,1),%xmm0
  6f7cd3:	66 0f 7f 84 24 c0 08 	movdqa %xmm0,0x8c0(%rsp)
  6f7cda:	00 00 
  6f7cdc:	66 83 fd 06          	cmp    $0x6,%bp
  6f7ce0:	74 13                	je     6f7cf5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xcf5>
  6f7ce2:	48 03 44 24 50       	add    0x50(%rsp),%rax
  6f7ce7:	f3 0f 6f 40 4c       	movdqu 0x4c(%rax),%xmm0
  6f7cec:	66 0f 7f 84 24 c0 08 	movdqa %xmm0,0x8c0(%rsp)
  6f7cf3:	00 00 
  6f7cf5:	48 8d bc 24 f0 07 00 	lea    0x7f0(%rsp),%rdi
  6f7cfc:	00 
  6f7cfd:	4c 89 fe             	mov    %r15,%rsi
  6f7d00:	48 8d 94 24 c0 08 00 	lea    0x8c0(%rsp),%rdx
  6f7d07:	00 
  6f7d08:	ff 15 9a 3e 39 00    	call   *0x393e9a(%rip)        # a8bba8 <_DYNAMIC+0x6c0>
  6f7d0e:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
  6f7d15:	00 
  6f7d16:	48 85 ff             	test   %rdi,%rdi
  6f7d19:	0f 84 80 00 00 00    	je     6f7d9f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd9f>
  6f7d1f:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  6f7d26:	00 
  6f7d27:	0f b7 8f c2 01 00 00 	movzwl 0x1c2(%rdi),%ecx
  6f7d2e:	89 ce                	mov    %ecx,%esi
  6f7d30:	c1 e6 05             	shl    $0x5,%esi
  6f7d33:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
  6f7d3a:	31 d2                	xor    %edx,%edx
  6f7d3c:	0f 1f 40 00          	nopl   0x0(%rax)
  6f7d40:	49 89 f0             	mov    %rsi,%r8
  6f7d43:	49 01 d0             	add    %rdx,%r8
  6f7d46:	74 27                	je     6f7d6f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd6f>
  6f7d48:	4e 3b bc e7 70 01 00 	cmp    0x170(%rdi,%r12,8),%r15
  6f7d4f:	00 
  6f7d50:	41 0f 97 c0          	seta   %r8b
  6f7d54:	41 80 d8 00          	sbb    $0x0,%r8b
  6f7d58:	48 83 c2 e0          	add    $0xffffffffffffffe0,%rdx
  6f7d5c:	49 ff c4             	inc    %r12
  6f7d5f:	41 80 f8 01          	cmp    $0x1,%r8b
  6f7d63:	74 db                	je     6f7d40 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd40>
  6f7d65:	41 0f b6 c8          	movzbl %r8b,%ecx
  6f7d69:	85 c9                	test   %ecx,%ecx
  6f7d6b:	75 05                	jne    6f7d72 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd72>
  6f7d6d:	eb 17                	jmp    6f7d86 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd86>
  6f7d6f:	49 89 cc             	mov    %rcx,%r12
  6f7d72:	48 83 e8 01          	sub    $0x1,%rax
  6f7d76:	0f 82 f0 00 00 00    	jb     6f7e6c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xe6c>
  6f7d7c:	4a 8b bc e7 c8 01 00 	mov    0x1c8(%rdi,%r12,8),%rdi
  6f7d83:	00 
  6f7d84:	eb a1                	jmp    6f7d27 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd27>
  6f7d86:	48 29 d7             	sub    %rdx,%rdi
  6f7d89:	48 83 c7 e0          	add    $0xffffffffffffffe0,%rdi
  6f7d8d:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
  6f7d94:	00 
  6f7d95:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  6f7d9a:	e9 9b 00 00 00       	jmp    6f7e3a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xe3a>
  6f7d9f:	31 ff                	xor    %edi,%edi
  6f7da1:	4c 89 bc 24 90 00 00 	mov    %r15,0x90(%rsp)
  6f7da8:	00 
  6f7da9:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
  6f7db0:	00 
  6f7db1:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
  6f7db8:	00 
  6f7db9:	48 89 bc 24 a0 00 00 	mov    %rdi,0xa0(%rsp)
  6f7dc0:	00 
  6f7dc1:	4c 89 a4 24 a8 00 00 	mov    %r12,0xa8(%rsp)
  6f7dc8:	00 
  6f7dc9:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  6f7dce:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  6f7dd5:	00 
  6f7dd6:	48 89 df             	mov    %rbx,%rdi
  6f7dd9:	41 ff 56 30          	call   *0x30(%r14)
  6f7ddd:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
  6f7de4:	00 
  6f7de5:	48 c7 84 24 f0 02 00 	movq   $0x0,0x2f0(%rsp)
  6f7dec:	00 00 00 00 00 
  6f7df1:	48 c7 84 24 f8 02 00 	movq   $0x4,0x2f8(%rsp)
  6f7df8:	00 04 00 00 00 
  6f7dfd:	48 c7 84 24 00 03 00 	movq   $0x0,0x300(%rsp)
  6f7e04:	00 00 00 00 00 
  6f7e09:	48 8d bc 24 20 07 00 	lea    0x720(%rsp),%rdi
  6f7e10:	00 
  6f7e11:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f7e18:	00 
  6f7e19:	48 8d 94 24 f0 02 00 	lea    0x2f0(%rsp),%rdx
  6f7e20:	00 
  6f7e21:	e8 9a 9a 01 00       	call   7118c0 <<alloc::collections::btree::map::entry::VacantEntry<gpui::source::FieldId, gpui::runtime::Fanout>>::insert_entry>
  6f7e26:	48 8b bc 24 30 07 00 	mov    0x730(%rsp),%rdi
  6f7e2d:	00 
  6f7e2e:	48 c1 e7 05          	shl    $0x5,%rdi
  6f7e32:	48 03 bc 24 20 07 00 	add    0x720(%rsp),%rdi
  6f7e39:	00 
  6f7e3a:	ff 15 58 3d 39 00    	call   *0x393d58(%rip)        # a8bb98 <_DYNAMIC+0x6b0>
  6f7e40:	48 89 c3             	mov    %rax,%rbx
  6f7e43:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  6f7e48:	89 ee                	mov    %ebp,%esi
  6f7e4a:	ff 15 60 3d 39 00    	call   *0x393d60(%rip)        # a8bbb0 <_DYNAMIC+0x6c8>
  6f7e50:	89 c5                	mov    %eax,%ebp
  6f7e52:	4c 8b 73 10          	mov    0x10(%rbx),%r14
  6f7e56:	4c 3b 33             	cmp    (%rbx),%r14
  6f7e59:	0f 85 c9 fd ff ff    	jne    6f7c28 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xc28>
  6f7e5f:	48 89 df             	mov    %rbx,%rdi
  6f7e62:	e8 19 91 02 00       	call   720f80 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  6f7e67:	e9 bc fd ff ff       	jmp    6f7c28 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xc28>
  6f7e6c:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
  6f7e71:	45 31 e4             	xor    %r12d,%r12d
  6f7e74:	e9 28 ff ff ff       	jmp    6f7da1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xda1>
  6f7e79:	0f 10 84 24 98 00 00 	movups 0x98(%rsp),%xmm0
  6f7e80:	00 
  6f7e81:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6f7e86:	48 c7 01 20 00 00 00 	movq   $0x20,(%rcx)
  6f7e8d:	48 89 41 08          	mov    %rax,0x8(%rcx)
  6f7e91:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
  6f7e95:	e9 ae 53 00 00       	jmp    6fd248 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6248>
  6f7e9a:	8b 8c 24 a4 00 00 00 	mov    0xa4(%rsp),%ecx
  6f7ea1:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  6f7ea6:	89 4a 1c             	mov    %ecx,0x1c(%rdx)
  6f7ea9:	48 8b 8c 24 9c 00 00 	mov    0x9c(%rsp),%rcx
  6f7eb0:	00 
  6f7eb1:	48 89 4a 14          	mov    %rcx,0x14(%rdx)
  6f7eb5:	48 c7 02 20 00 00 00 	movq   $0x20,(%rdx)
  6f7ebc:	48 89 42 08          	mov    %rax,0x8(%rdx)
  6f7ec0:	44 89 72 10          	mov    %r14d,0x10(%rdx)
  6f7ec4:	e9 7f 53 00 00       	jmp    6fd248 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6248>
  6f7ec9:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
  6f7ed0:	00 
  6f7ed1:	48 85 c0             	test   %rax,%rax
  6f7ed4:	74 1f                	je     6f7ef5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xef5>
  6f7ed6:	48 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%rax
  6f7edd:	00 
  6f7ede:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6f7ee2:	ba 08 00 00 00       	mov    $0x8,%edx
  6f7ee7:	48 8b bc 24 38 02 00 	mov    0x238(%rsp),%rdi
  6f7eee:	00 
  6f7eef:	ff 15 43 38 39 00    	call   *0x393843(%rip)        # a8b738 <_DYNAMIC+0x250>
  6f7ef5:	4c 8b bc 24 f0 04 00 	mov    0x4f0(%rsp),%r15
  6f7efc:	00 
  6f7efd:	4d 85 ff             	test   %r15,%r15
  6f7f00:	0f 84 1f 05 00 00    	je     6f8425 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1425>
  6f7f06:	4c 89 fb             	mov    %r15,%rbx
  6f7f09:	48 c1 e3 04          	shl    $0x4,%rbx
  6f7f0d:	ff 15 15 38 39 00    	call   *0x393815(%rip)        # a8b728 <_DYNAMIC+0x240>
  6f7f13:	be 08 00 00 00       	mov    $0x8,%esi
  6f7f18:	48 89 df             	mov    %rbx,%rdi
  6f7f1b:	ff 15 0f 38 39 00    	call   *0x39380f(%rip)        # a8b730 <_DYNAMIC+0x248>
  6f7f21:	48 85 c0             	test   %rax,%rax
  6f7f24:	0f 84 10 5d 00 00    	je     6fdc3a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c3a>
  6f7f2a:	4c 89 bc 24 78 02 00 	mov    %r15,0x278(%rsp)
  6f7f31:	00 
  6f7f32:	48 89 84 24 80 02 00 	mov    %rax,0x280(%rsp)
  6f7f39:	00 
  6f7f3a:	48 c7 84 24 88 02 00 	movq   $0x0,0x288(%rsp)
  6f7f41:	00 00 00 00 00 
  6f7f46:	4c 8b b4 24 e8 04 00 	mov    0x4e8(%rsp),%r14
  6f7f4d:	00 
  6f7f4e:	49 6b c7 38          	imul   $0x38,%r15,%rax
  6f7f52:	4c 01 f0             	add    %r14,%rax
  6f7f55:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6f7f5a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f7f5f:	48 05 28 02 00 00    	add    $0x228,%rax
  6f7f65:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  6f7f6a:	48 b8 01 00 00 00 00 	movabs $0x8000000000000001,%rax
  6f7f71:	00 00 80 
  6f7f74:	48 ff c0             	inc    %rax
  6f7f77:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6f7f7e:	00 
  6f7f7f:	eb 44                	jmp    6f7fc5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xfc5>
  6f7f81:	48 8d bc 24 78 02 00 	lea    0x278(%rsp),%rdi
  6f7f88:	00 
  6f7f89:	e8 22 8b 02 00       	call   720ab0 <<alloc::raw_vec::RawVec<[core::option::Option<gpui::source::FieldId>; 2]>>::grow_one>
  6f7f8e:	49 83 c6 38          	add    $0x38,%r14
  6f7f92:	48 8b 84 24 80 02 00 	mov    0x280(%rsp),%rax
  6f7f99:	00 
  6f7f9a:	48 89 d9             	mov    %rbx,%rcx
  6f7f9d:	48 c1 e1 04          	shl    $0x4,%rcx
  6f7fa1:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  6f7fa6:	48 89 14 08          	mov    %rdx,(%rax,%rcx,1)
  6f7faa:	4c 89 64 08 08       	mov    %r12,0x8(%rax,%rcx,1)
  6f7faf:	48 ff c3             	inc    %rbx
  6f7fb2:	48 89 9c 24 88 02 00 	mov    %rbx,0x288(%rsp)
  6f7fb9:	00 
  6f7fba:	4c 3b 74 24 40       	cmp    0x40(%rsp),%r14
  6f7fbf:	0f 84 84 04 00 00    	je     6f8449 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1449>
  6f7fc5:	49 8b 06             	mov    (%r14),%rax
  6f7fc8:	4d 8b 7e 18          	mov    0x18(%r14),%r15
  6f7fcc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f7fd0:	0f 84 ea 00 00 00    	je     6f80c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x10c0>
  6f7fd6:	48 3b 84 24 80 00 00 	cmp    0x80(%rsp),%rax
  6f7fdd:	00 
  6f7fde:	0f 85 dc 00 00 00    	jne    6f80c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x10c0>
  6f7fe4:	49 8b 4e 08          	mov    0x8(%r14),%rcx
  6f7fe8:	4d 8b 46 10          	mov    0x10(%r14),%r8
  6f7fec:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f7ff3:	00 
  6f7ff4:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  6f7ff9:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f7ffe:	e8 dd 93 02 00       	call   7213e0 <<gpui::source::Sources<route_columns_cost::Page>>::resolve>
  6f8003:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f800a:	00 
  6f800b:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f800f:	0f 85 0e 12 00 00    	jne    6f9223 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2223>
  6f8015:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  6f801c:	00 
  6f801d:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  6f8022:	48 85 c9             	test   %rcx,%rcx
  6f8025:	0f 84 95 00 00 00    	je     6f80c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x10c0>
  6f802b:	4c 89 f7             	mov    %r14,%rdi
  6f802e:	ff 15 5c 3b 39 00    	call   *0x393b5c(%rip)        # a8bb90 <_DYNAMIC+0x6a8>
  6f8034:	48 85 c0             	test   %rax,%rax
  6f8037:	0f 84 28 3d 00 00    	je     6fbd65 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d65>
  6f803d:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
  6f8044:	00 
  6f8045:	48 85 ff             	test   %rdi,%rdi
  6f8048:	0f 84 9a 01 00 00    	je     6f81e8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x11e8>
  6f804e:	48 8b 8c 24 68 01 00 	mov    0x168(%rsp),%rcx
  6f8055:	00 
  6f8056:	0f b7 97 c2 01 00 00 	movzwl 0x1c2(%rdi),%edx
  6f805d:	41 89 d0             	mov    %edx,%r8d
  6f8060:	41 c1 e0 05          	shl    $0x5,%r8d
  6f8064:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
  6f806b:	31 f6                	xor    %esi,%esi
  6f806d:	0f 1f 00             	nopl   (%rax)
  6f8070:	4d 89 c1             	mov    %r8,%r9
  6f8073:	49 01 f1             	add    %rsi,%r9
  6f8076:	74 2f                	je     6f80a7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x10a7>
  6f8078:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
  6f807d:	4e 3b 8c ef 70 01 00 	cmp    0x170(%rdi,%r13,8),%r9
  6f8084:	00 
  6f8085:	41 0f 97 c1          	seta   %r9b
  6f8089:	41 80 d9 00          	sbb    $0x0,%r9b
  6f808d:	48 83 c6 e0          	add    $0xffffffffffffffe0,%rsi
  6f8091:	49 ff c5             	inc    %r13
  6f8094:	41 80 f9 01          	cmp    $0x1,%r9b
  6f8098:	74 d6                	je     6f8070 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1070>
  6f809a:	41 0f b6 d1          	movzbl %r9b,%edx
  6f809e:	85 d2                	test   %edx,%edx
  6f80a0:	75 08                	jne    6f80aa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x10aa>
  6f80a2:	e9 0f 01 00 00       	jmp    6f81b6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x11b6>
  6f80a7:	49 89 d5             	mov    %rdx,%r13
  6f80aa:	48 83 e9 01          	sub    $0x1,%rcx
  6f80ae:	0f 82 23 03 00 00    	jb     6f83d7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x13d7>
  6f80b4:	4a 8b bc ef c8 01 00 	mov    0x1c8(%rdi,%r13,8),%rdi
  6f80bb:	00 
  6f80bc:	eb 98                	jmp    6f8056 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1056>
  6f80be:	66 90                	xchg   %ax,%ax
  6f80c0:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  6f80c7:	00 00 
  6f80c9:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
  6f80cd:	0f 84 fd 01 00 00    	je     6f82d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x12d0>
  6f80d3:	49 8d 5e 18          	lea    0x18(%r14),%rbx
  6f80d7:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  6f80de:	00 
  6f80df:	48 39 03             	cmp    %rax,(%rbx)
  6f80e2:	0f 85 e8 01 00 00    	jne    6f82d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x12d0>
  6f80e8:	49 8b 4e 20          	mov    0x20(%r14),%rcx
  6f80ec:	4d 8b 46 28          	mov    0x28(%r14),%r8
  6f80f0:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f80f7:	00 
  6f80f8:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  6f80fd:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f8102:	e8 d9 92 02 00       	call   7213e0 <<gpui::source::Sources<route_columns_cost::Page>>::resolve>
  6f8107:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f810e:	00 
  6f810f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f8113:	0f 85 0a 11 00 00    	jne    6f9223 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2223>
  6f8119:	4c 8b a4 24 98 00 00 	mov    0x98(%rsp),%r12
  6f8120:	00 
  6f8121:	4d 85 e4             	test   %r12,%r12
  6f8124:	0f 84 a6 01 00 00    	je     6f82d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x12d0>
  6f812a:	48 89 df             	mov    %rbx,%rdi
  6f812d:	ff 15 5d 3a 39 00    	call   *0x393a5d(%rip)        # a8bb90 <_DYNAMIC+0x6a8>
  6f8133:	48 85 c0             	test   %rax,%rax
  6f8136:	0f 84 2e 3c 00 00    	je     6fbd6a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d6a>
  6f813c:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
  6f8143:	00 
  6f8144:	48 85 ff             	test   %rdi,%rdi
  6f8147:	0f 84 a1 01 00 00    	je     6f82ee <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x12ee>
  6f814d:	48 8b 8c 24 68 01 00 	mov    0x168(%rsp),%rcx
  6f8154:	00 
  6f8155:	0f b7 97 c2 01 00 00 	movzwl 0x1c2(%rdi),%edx
  6f815c:	41 89 d0             	mov    %edx,%r8d
  6f815f:	41 c1 e0 05          	shl    $0x5,%r8d
  6f8163:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
  6f816a:	31 f6                	xor    %esi,%esi
  6f816c:	0f 1f 40 00          	nopl   0x0(%rax)
  6f8170:	4d 89 c1             	mov    %r8,%r9
  6f8173:	49 01 f1             	add    %rsi,%r9
  6f8176:	74 27                	je     6f819f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x119f>
  6f8178:	4e 3b a4 ef 70 01 00 	cmp    0x170(%rdi,%r13,8),%r12
  6f817f:	00 
  6f8180:	41 0f 97 c1          	seta   %r9b
  6f8184:	41 80 d9 00          	sbb    $0x0,%r9b
  6f8188:	48 83 c6 e0          	add    $0xffffffffffffffe0,%rsi
  6f818c:	49 ff c5             	inc    %r13
  6f818f:	41 80 f9 01          	cmp    $0x1,%r9b
  6f8193:	74 db                	je     6f8170 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1170>
  6f8195:	41 0f b6 d1          	movzbl %r9b,%edx
  6f8199:	85 d2                	test   %edx,%edx
  6f819b:	75 05                	jne    6f81a2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x11a2>
  6f819d:	eb 30                	jmp    6f81cf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x11cf>
  6f819f:	49 89 d5             	mov    %rdx,%r13
  6f81a2:	48 83 e9 01          	sub    $0x1,%rcx
  6f81a6:	0f 82 39 02 00 00    	jb     6f83e5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x13e5>
  6f81ac:	4a 8b bc ef c8 01 00 	mov    0x1c8(%rdi,%r13,8),%rdi
  6f81b3:	00 
  6f81b4:	eb 9f                	jmp    6f8155 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1155>
  6f81b6:	48 29 f7             	sub    %rsi,%rdi
  6f81b9:	48 83 c7 e0          	add    $0xffffffffffffffe0,%rdi
  6f81bd:	4c 89 6c 24 50       	mov    %r13,0x50(%rsp)
  6f81c2:	4c 8d ac 24 60 01 00 	lea    0x160(%rsp),%r13
  6f81c9:	00 
  6f81ca:	e9 b2 00 00 00       	jmp    6f8281 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1281>
  6f81cf:	48 29 f7             	sub    %rsi,%rdi
  6f81d2:	48 83 c7 e0          	add    $0xffffffffffffffe0,%rdi
  6f81d6:	4c 89 6c 24 50       	mov    %r13,0x50(%rsp)
  6f81db:	4c 8d ac 24 60 01 00 	lea    0x160(%rsp),%r13
  6f81e2:	00 
  6f81e3:	e9 9a 01 00 00       	jmp    6f8382 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1382>
  6f81e8:	31 ff                	xor    %edi,%edi
  6f81ea:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  6f81ef:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  6f81f6:	00 
  6f81f7:	48 8d 8c 24 60 01 00 	lea    0x160(%rsp),%rcx
  6f81fe:	00 
  6f81ff:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  6f8206:	00 
  6f8207:	48 89 bc 24 a0 00 00 	mov    %rdi,0xa0(%rsp)
  6f820e:	00 
  6f820f:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  6f8214:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
  6f821b:	00 
  6f821c:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
  6f8223:	00 
  6f8224:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
  6f822b:	00 
  6f822c:	48 c7 84 24 f0 02 00 	movq   $0x0,0x2f0(%rsp)
  6f8233:	00 00 00 00 00 
  6f8238:	48 c7 84 24 f8 02 00 	movq   $0x4,0x2f8(%rsp)
  6f823f:	00 04 00 00 00 
  6f8244:	48 c7 84 24 00 03 00 	movq   $0x0,0x300(%rsp)
  6f824b:	00 00 00 00 00 
  6f8250:	48 8d bc 24 20 07 00 	lea    0x720(%rsp),%rdi
  6f8257:	00 
  6f8258:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f825f:	00 
  6f8260:	48 8d 94 24 f0 02 00 	lea    0x2f0(%rsp),%rdx
  6f8267:	00 
  6f8268:	e8 53 96 01 00       	call   7118c0 <<alloc::collections::btree::map::entry::VacantEntry<gpui::source::FieldId, gpui::runtime::Fanout>>::insert_entry>
  6f826d:	48 8b bc 24 30 07 00 	mov    0x730(%rsp),%rdi
  6f8274:	00 
  6f8275:	48 c1 e7 05          	shl    $0x5,%rdi
  6f8279:	48 03 bc 24 20 07 00 	add    0x720(%rsp),%rdi
  6f8280:	00 
  6f8281:	ff 15 11 39 39 00    	call   *0x393911(%rip)        # a8bb98 <_DYNAMIC+0x6b0>
  6f8287:	48 89 c3             	mov    %rax,%rbx
  6f828a:	41 8b 7e 30          	mov    0x30(%r14),%edi
  6f828e:	be 01 00 00 00       	mov    $0x1,%esi
  6f8293:	ff 15 07 39 39 00    	call   *0x393907(%rip)        # a8bba0 <_DYNAMIC+0x6b8>
  6f8299:	89 c5                	mov    %eax,%ebp
  6f829b:	4c 8b 63 10          	mov    0x10(%rbx),%r12
  6f829f:	4c 3b 23             	cmp    (%rbx),%r12
  6f82a2:	75 08                	jne    6f82ac <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x12ac>
  6f82a4:	48 89 df             	mov    %rbx,%rdi
  6f82a7:	e8 d4 8c 02 00       	call   720f80 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  6f82ac:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6f82b0:	42 89 2c a0          	mov    %ebp,(%rax,%r12,4)
  6f82b4:	49 ff c4             	inc    %r12
  6f82b7:	4c 89 63 10          	mov    %r12,0x10(%rbx)
  6f82bb:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
  6f82bf:	0f 85 0e fe ff ff    	jne    6f80d3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x10d3>
  6f82c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6f82cc:	00 00 00 00 
  6f82d0:	45 31 e4             	xor    %r12d,%r12d
  6f82d3:	48 8b 9c 24 88 02 00 	mov    0x288(%rsp),%rbx
  6f82da:	00 
  6f82db:	48 3b 9c 24 78 02 00 	cmp    0x278(%rsp),%rbx
  6f82e2:	00 
  6f82e3:	0f 85 a5 fc ff ff    	jne    6f7f8e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xf8e>
  6f82e9:	e9 93 fc ff ff       	jmp    6f7f81 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xf81>
  6f82ee:	31 ff                	xor    %edi,%edi
  6f82f0:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
  6f82f7:	00 
  6f82f8:	48 8d 8c 24 60 01 00 	lea    0x160(%rsp),%rcx
  6f82ff:	00 
  6f8300:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  6f8307:	00 
  6f8308:	48 89 bc 24 a0 00 00 	mov    %rdi,0xa0(%rsp)
  6f830f:	00 
  6f8310:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  6f8315:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
  6f831c:	00 
  6f831d:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
  6f8324:	00 
  6f8325:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
  6f832c:	00 
  6f832d:	48 c7 84 24 f0 02 00 	movq   $0x0,0x2f0(%rsp)
  6f8334:	00 00 00 00 00 
  6f8339:	48 c7 84 24 f8 02 00 	movq   $0x4,0x2f8(%rsp)
  6f8340:	00 04 00 00 00 
  6f8345:	48 c7 84 24 00 03 00 	movq   $0x0,0x300(%rsp)
  6f834c:	00 00 00 00 00 
  6f8351:	48 8d bc 24 20 07 00 	lea    0x720(%rsp),%rdi
  6f8358:	00 
  6f8359:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f8360:	00 
  6f8361:	48 8d 94 24 f0 02 00 	lea    0x2f0(%rsp),%rdx
  6f8368:	00 
  6f8369:	e8 52 95 01 00       	call   7118c0 <<alloc::collections::btree::map::entry::VacantEntry<gpui::source::FieldId, gpui::runtime::Fanout>>::insert_entry>
  6f836e:	48 8b bc 24 30 07 00 	mov    0x730(%rsp),%rdi
  6f8375:	00 
  6f8376:	48 c1 e7 05          	shl    $0x5,%rdi
  6f837a:	48 03 bc 24 20 07 00 	add    0x720(%rsp),%rdi
  6f8381:	00 
  6f8382:	ff 15 10 38 39 00    	call   *0x393810(%rip)        # a8bb98 <_DYNAMIC+0x6b0>
  6f8388:	48 89 c3             	mov    %rax,%rbx
  6f838b:	41 8b 7e 30          	mov    0x30(%r14),%edi
  6f838f:	be 02 00 00 00       	mov    $0x2,%esi
  6f8394:	ff 15 06 38 39 00    	call   *0x393806(%rip)        # a8bba0 <_DYNAMIC+0x6b8>
  6f839a:	89 c5                	mov    %eax,%ebp
  6f839c:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
  6f83a0:	4c 3b 3b             	cmp    (%rbx),%r15
  6f83a3:	75 08                	jne    6f83ad <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x13ad>
  6f83a5:	48 89 df             	mov    %rbx,%rdi
  6f83a8:	e8 d3 8b 02 00       	call   720f80 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  6f83ad:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6f83b1:	42 89 2c b8          	mov    %ebp,(%rax,%r15,4)
  6f83b5:	49 ff c7             	inc    %r15
  6f83b8:	4c 89 7b 10          	mov    %r15,0x10(%rbx)
  6f83bc:	48 8b 9c 24 88 02 00 	mov    0x288(%rsp),%rbx
  6f83c3:	00 
  6f83c4:	48 3b 9c 24 78 02 00 	cmp    0x278(%rsp),%rbx
  6f83cb:	00 
  6f83cc:	0f 85 bc fb ff ff    	jne    6f7f8e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xf8e>
  6f83d2:	e9 aa fb ff ff       	jmp    6f7f81 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xf81>
  6f83d7:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  6f83de:	00 00 
  6f83e0:	e9 05 fe ff ff       	jmp    6f81ea <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x11ea>
  6f83e5:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  6f83ec:	00 00 
  6f83ee:	e9 fd fe ff ff       	jmp    6f82f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x12f0>
  6f83f3:	41 0f b7 4f 30       	movzwl 0x30(%r15),%ecx
  6f83f8:	25 ff ff ff 00       	and    $0xffffff,%eax
  6f83fd:	89 c2                	mov    %eax,%edx
  6f83ff:	c1 ea 10             	shr    $0x10,%edx
  6f8402:	48 c1 e0 10          	shl    $0x10,%rax
  6f8406:	48 09 c8             	or     %rcx,%rax
  6f8409:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6f840e:	48 c7 01 25 00 00 00 	movq   $0x25,(%rcx)
  6f8415:	4c 89 71 08          	mov    %r14,0x8(%rcx)
  6f8419:	66 89 51 14          	mov    %dx,0x14(%rcx)
  6f841d:	89 41 10             	mov    %eax,0x10(%rcx)
  6f8420:	e9 23 4e 00 00       	jmp    6fd248 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6248>
  6f8425:	48 c7 84 24 78 02 00 	movq   $0x0,0x278(%rsp)
  6f842c:	00 00 00 00 00 
  6f8431:	48 c7 84 24 80 02 00 	movq   $0x8,0x280(%rsp)
  6f8438:	00 08 00 00 00 
  6f843d:	48 c7 84 24 88 02 00 	movq   $0x0,0x288(%rsp)
  6f8444:	00 00 00 00 00 
  6f8449:	48 c7 84 24 48 04 00 	movq   $0x0,0x448(%rsp)
  6f8450:	00 00 00 00 00 
  6f8455:	48 c7 84 24 58 04 00 	movq   $0x0,0x458(%rsp)
  6f845c:	00 00 00 00 00 
  6f8461:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
  6f8468:	00 
  6f8469:	4c 8b b4 24 70 01 00 	mov    0x170(%rsp),%r14
  6f8470:	00 
  6f8471:	48 85 c0             	test   %rax,%rax
  6f8474:	0f 95 c1             	setne  %cl
  6f8477:	4d 85 f6             	test   %r14,%r14
  6f847a:	0f 95 c2             	setne  %dl
  6f847d:	20 ca                	and    %cl,%dl
  6f847f:	80 fa 01             	cmp    $0x1,%dl
  6f8482:	0f 85 4f 02 00 00    	jne    6f86d7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x16d7>
  6f8488:	48 8b ac 24 68 01 00 	mov    0x168(%rsp),%rbp
  6f848f:	00 
  6f8490:	45 31 ed             	xor    %r13d,%r13d
  6f8493:	4c 8b 3d fe 36 39 00 	mov    0x3936fe(%rip),%r15        # a8bb98 <_DYNAMIC+0x6b0>
  6f849a:	4c 8d 64 24 77       	lea    0x77(%rsp),%r12
  6f849f:	48 8d 9c 24 90 00 00 	lea    0x90(%rsp),%rbx
  6f84a6:	00 
  6f84a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f84ae:	00 00 
  6f84b0:	4d 85 ed             	test   %r13,%r13
  6f84b3:	74 1c                	je     6f84d1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x14d1>
  6f84b5:	41 0f b7 8d c2 01 00 	movzwl 0x1c2(%r13),%ecx
  6f84bc:	00 
  6f84bd:	48 39 cd             	cmp    %rcx,%rbp
  6f84c0:	0f 83 ba 00 00 00    	jae    6f8580 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1580>
  6f84c6:	4c 89 ef             	mov    %r13,%rdi
  6f84c9:	48 89 e9             	mov    %rbp,%rcx
  6f84cc:	e9 d6 00 00 00       	jmp    6f85a7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x15a7>
  6f84d1:	48 85 ed             	test   %rbp,%rbp
  6f84d4:	74 37                	je     6f850d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x150d>
  6f84d6:	48 89 e9             	mov    %rbp,%rcx
  6f84d9:	49 89 c5             	mov    %rax,%r13
  6f84dc:	48 83 e1 07          	and    $0x7,%rcx
  6f84e0:	74 30                	je     6f8512 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1512>
  6f84e2:	31 d2                	xor    %edx,%edx
  6f84e4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f84eb:	00 00 00 00 00 
  6f84f0:	4d 8b ad c8 01 00 00 	mov    0x1c8(%r13),%r13
  6f84f7:	48 ff c2             	inc    %rdx
  6f84fa:	48 39 d1             	cmp    %rdx,%rcx
  6f84fd:	75 f1                	jne    6f84f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x14f0>
  6f84ff:	48 89 e8             	mov    %rbp,%rax
  6f8502:	48 29 d0             	sub    %rdx,%rax
  6f8505:	48 83 fd 08          	cmp    $0x8,%rbp
  6f8509:	73 15                	jae    6f8520 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1520>
  6f850b:	eb 51                	jmp    6f855e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x155e>
  6f850d:	49 89 c5             	mov    %rax,%r13
  6f8510:	eb 4c                	jmp    6f855e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x155e>
  6f8512:	48 89 e8             	mov    %rbp,%rax
  6f8515:	48 83 fd 08          	cmp    $0x8,%rbp
  6f8519:	72 43                	jb     6f855e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x155e>
  6f851b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6f8520:	49 8b 8d c8 01 00 00 	mov    0x1c8(%r13),%rcx
  6f8527:	48 8b 89 c8 01 00 00 	mov    0x1c8(%rcx),%rcx
  6f852e:	48 8b 89 c8 01 00 00 	mov    0x1c8(%rcx),%rcx
  6f8535:	48 8b 89 c8 01 00 00 	mov    0x1c8(%rcx),%rcx
  6f853c:	48 8b 89 c8 01 00 00 	mov    0x1c8(%rcx),%rcx
  6f8543:	48 8b 89 c8 01 00 00 	mov    0x1c8(%rcx),%rcx
  6f854a:	48 8b 89 c8 01 00 00 	mov    0x1c8(%rcx),%rcx
  6f8551:	4c 8b a9 c8 01 00 00 	mov    0x1c8(%rcx),%r13
  6f8558:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  6f855c:	75 c2                	jne    6f8520 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1520>
  6f855e:	31 c0                	xor    %eax,%eax
  6f8560:	31 ed                	xor    %ebp,%ebp
  6f8562:	41 0f b7 8d c2 01 00 	movzwl 0x1c2(%r13),%ecx
  6f8569:	00 
  6f856a:	48 39 cd             	cmp    %rcx,%rbp
  6f856d:	0f 82 53 ff ff ff    	jb     6f84c6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x14c6>
  6f8573:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f857a:	84 00 00 00 00 00 
  6f8580:	49 8b bd 60 01 00 00 	mov    0x160(%r13),%rdi
  6f8587:	48 85 ff             	test   %rdi,%rdi
  6f858a:	0f 84 6c 53 00 00    	je     6fd8fc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x68fc>
  6f8590:	48 ff c0             	inc    %rax
  6f8593:	41 0f b7 8d c0 01 00 	movzwl 0x1c0(%r13),%ecx
  6f859a:	00 
  6f859b:	49 89 fd             	mov    %rdi,%r13
  6f859e:	66 3b 8f c2 01 00 00 	cmp    0x1c2(%rdi),%cx
  6f85a5:	73 d9                	jae    6f8580 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1580>
  6f85a7:	48 85 c0             	test   %rax,%rax
  6f85aa:	0f 84 85 00 00 00    	je     6f8635 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1635>
  6f85b0:	48 8d 14 cf          	lea    (%rdi,%rcx,8),%rdx
  6f85b4:	48 81 c2 d0 01 00 00 	add    $0x1d0,%rdx
  6f85bb:	48 89 c6             	mov    %rax,%rsi
  6f85be:	48 83 e6 07          	and    $0x7,%rsi
  6f85c2:	0f 84 a4 00 00 00    	je     6f866c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x166c>
  6f85c8:	45 31 c0             	xor    %r8d,%r8d
  6f85cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6f85d0:	4c 8b 2a             	mov    (%rdx),%r13
  6f85d3:	49 8d 95 c8 01 00 00 	lea    0x1c8(%r13),%rdx
  6f85da:	49 ff c0             	inc    %r8
  6f85dd:	4c 39 c6             	cmp    %r8,%rsi
  6f85e0:	75 ee                	jne    6f85d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x15d0>
  6f85e2:	48 89 c6             	mov    %rax,%rsi
  6f85e5:	4c 29 c6             	sub    %r8,%rsi
  6f85e8:	48 83 f8 08          	cmp    $0x8,%rax
  6f85ec:	72 43                	jb     6f8631 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1631>
  6f85ee:	66 90                	xchg   %ax,%ax
  6f85f0:	48 8b 02             	mov    (%rdx),%rax
  6f85f3:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f85fa:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f8601:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f8608:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f860f:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f8616:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f861d:	4c 8b a8 c8 01 00 00 	mov    0x1c8(%rax),%r13
  6f8624:	49 8d 95 c8 01 00 00 	lea    0x1c8(%r13),%rdx
  6f862b:	48 83 c6 f8          	add    $0xfffffffffffffff8,%rsi
  6f862f:	75 bf                	jne    6f85f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x15f0>
  6f8631:	31 ed                	xor    %ebp,%ebp
  6f8633:	eb 07                	jmp    6f863c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x163c>
  6f8635:	48 8d 69 01          	lea    0x1(%rcx),%rbp
  6f8639:	49 89 fd             	mov    %rdi,%r13
  6f863c:	48 c1 e1 05          	shl    $0x5,%rcx
  6f8640:	48 01 cf             	add    %rcx,%rdi
  6f8643:	41 ff d7             	call   *%r15
  6f8646:	48 8b 78 08          	mov    0x8(%rax),%rdi
  6f864a:	48 8b 70 10          	mov    0x10(%rax),%rsi
  6f864e:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
  6f8655:	00 
  6f8656:	48 83 fe 02          	cmp    $0x2,%rsi
  6f865a:	73 1e                	jae    6f867a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x167a>
  6f865c:	b8 00 00 00 00       	mov    $0x0,%eax
  6f8661:	49 ff ce             	dec    %r14
  6f8664:	0f 85 46 fe ff ff    	jne    6f84b0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x14b0>
  6f866a:	eb 6b                	jmp    6f86d7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x16d7>
  6f866c:	48 89 c6             	mov    %rax,%rsi
  6f866f:	48 83 f8 08          	cmp    $0x8,%rax
  6f8673:	72 bc                	jb     6f8631 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1631>
  6f8675:	e9 76 ff ff ff       	jmp    6f85f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x15f0>
  6f867a:	48 83 fe 15          	cmp    $0x15,%rsi
  6f867e:	73 4d                	jae    6f86cd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x16cd>
  6f8680:	48 8d 04 b7          	lea    (%rdi,%rsi,4),%rax
  6f8684:	48 8d 4f 04          	lea    0x4(%rdi),%rcx
  6f8688:	ba 04 00 00 00       	mov    $0x4,%edx
  6f868d:	eb 13                	jmp    6f86a2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x16a2>
  6f868f:	49 89 f8             	mov    %rdi,%r8
  6f8692:	41 89 30             	mov    %esi,(%r8)
  6f8695:	48 83 c1 04          	add    $0x4,%rcx
  6f8699:	48 83 c2 04          	add    $0x4,%rdx
  6f869d:	48 39 c1             	cmp    %rax,%rcx
  6f86a0:	74 ba                	je     6f865c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x165c>
  6f86a2:	44 8b 49 fc          	mov    -0x4(%rcx),%r9d
  6f86a6:	8b 31                	mov    (%rcx),%esi
  6f86a8:	44 39 ce             	cmp    %r9d,%esi
  6f86ab:	73 e8                	jae    6f8695 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1695>
  6f86ad:	49 89 d0             	mov    %rdx,%r8
  6f86b0:	46 89 0c 07          	mov    %r9d,(%rdi,%r8,1)
  6f86b4:	49 83 f8 04          	cmp    $0x4,%r8
  6f86b8:	74 d5                	je     6f868f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x168f>
  6f86ba:	46 8b 4c 07 f8       	mov    -0x8(%rdi,%r8,1),%r9d
  6f86bf:	49 83 c0 fc          	add    $0xfffffffffffffffc,%r8
  6f86c3:	44 39 ce             	cmp    %r9d,%esi
  6f86c6:	72 e8                	jb     6f86b0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x16b0>
  6f86c8:	49 01 f8             	add    %rdi,%r8
  6f86cb:	eb c5                	jmp    6f8692 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1692>
  6f86cd:	48 89 da             	mov    %rbx,%rdx
  6f86d0:	e8 2b 9f 01 00       	call   712600 <core::slice::sort::unstable::ipnsort::<gpui::runtime::metadata::Destination, <[gpui::runtime::metadata::Destination]>::sort_unstable_by_key<u32, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#14}>::{closure#0}>>
  6f86d5:	eb 85                	jmp    6f865c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x165c>
  6f86d7:	48 8d bc 24 f0 07 00 	lea    0x7f0(%rsp),%rdi
  6f86de:	00 
  6f86df:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
  6f86e6:	00 
  6f86e7:	ff 15 cb 34 39 00    	call   *0x3934cb(%rip)        # a8bbb8 <_DYNAMIC+0x6d0>
  6f86ed:	48 8b 84 24 38 08 00 	mov    0x838(%rsp),%rax
  6f86f4:	00 
  6f86f5:	48 8b 9c 24 48 08 00 	mov    0x848(%rsp),%rbx
  6f86fc:	00 
  6f86fd:	48 85 c0             	test   %rax,%rax
  6f8700:	0f 95 c1             	setne  %cl
  6f8703:	48 85 db             	test   %rbx,%rbx
  6f8706:	0f 95 c2             	setne  %dl
  6f8709:	20 ca                	and    %cl,%dl
  6f870b:	80 fa 01             	cmp    $0x1,%dl
  6f870e:	0f 85 a5 02 00 00    	jne    6f89b9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x19b9>
  6f8714:	4c 8b a4 24 40 08 00 	mov    0x840(%rsp),%r12
  6f871b:	00 
  6f871c:	45 31 ff             	xor    %r15d,%r15d
  6f871f:	eb 2d                	jmp    6f874e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x174e>
  6f8721:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f8728:	0f 1f 84 00 00 00 00 
  6f872f:	00 
  6f8730:	4b c7 44 35 e0 ff ff 	movq   $0xffffffffffffffff,-0x20(%r13,%r14,1)
  6f8737:	ff ff 
  6f8739:	43 89 6c 35 e8       	mov    %ebp,-0x18(%r13,%r14,1)
  6f873e:	b1 01                	mov    $0x1,%cl
  6f8740:	b8 00 00 00 00       	mov    $0x0,%eax
  6f8745:	48 85 db             	test   %rbx,%rbx
  6f8748:	0f 84 6b 02 00 00    	je     6f89b9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x19b9>
  6f874e:	f6 c1 01             	test   $0x1,%cl
  6f8751:	0f 84 99 52 00 00    	je     6fd9f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x69f0>
  6f8757:	4d 85 ff             	test   %r15,%r15
  6f875a:	74 1c                	je     6f8778 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1778>
  6f875c:	41 0f b7 8f 8e 00 00 	movzwl 0x8e(%r15),%ecx
  6f8763:	00 
  6f8764:	49 39 cc             	cmp    %rcx,%r12
  6f8767:	0f 83 b3 00 00 00    	jae    6f8820 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1820>
  6f876d:	4c 89 f9             	mov    %r15,%rcx
  6f8770:	4c 89 e2             	mov    %r12,%rdx
  6f8773:	e9 cb 00 00 00       	jmp    6f8843 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1843>
  6f8778:	4d 85 e4             	test   %r12,%r12
  6f877b:	74 30                	je     6f87ad <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x17ad>
  6f877d:	4c 89 e1             	mov    %r12,%rcx
  6f8780:	49 89 c7             	mov    %rax,%r15
  6f8783:	48 83 e1 07          	and    $0x7,%rcx
  6f8787:	74 29                	je     6f87b2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x17b2>
  6f8789:	31 d2                	xor    %edx,%edx
  6f878b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6f8790:	4d 8b bf 90 00 00 00 	mov    0x90(%r15),%r15
  6f8797:	48 ff c2             	inc    %rdx
  6f879a:	48 39 d1             	cmp    %rdx,%rcx
  6f879d:	75 f1                	jne    6f8790 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1790>
  6f879f:	4c 89 e0             	mov    %r12,%rax
  6f87a2:	48 29 d0             	sub    %rdx,%rax
  6f87a5:	49 83 fc 08          	cmp    $0x8,%r12
  6f87a9:	73 15                	jae    6f87c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x17c0>
  6f87ab:	eb 51                	jmp    6f87fe <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x17fe>
  6f87ad:	49 89 c7             	mov    %rax,%r15
  6f87b0:	eb 4c                	jmp    6f87fe <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x17fe>
  6f87b2:	4c 89 e0             	mov    %r12,%rax
  6f87b5:	49 83 fc 08          	cmp    $0x8,%r12
  6f87b9:	72 43                	jb     6f87fe <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x17fe>
  6f87bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6f87c0:	49 8b 8f 90 00 00 00 	mov    0x90(%r15),%rcx
  6f87c7:	48 8b 89 90 00 00 00 	mov    0x90(%rcx),%rcx
  6f87ce:	48 8b 89 90 00 00 00 	mov    0x90(%rcx),%rcx
  6f87d5:	48 8b 89 90 00 00 00 	mov    0x90(%rcx),%rcx
  6f87dc:	48 8b 89 90 00 00 00 	mov    0x90(%rcx),%rcx
  6f87e3:	48 8b 89 90 00 00 00 	mov    0x90(%rcx),%rcx
  6f87ea:	48 8b 89 90 00 00 00 	mov    0x90(%rcx),%rcx
  6f87f1:	4c 8b b9 90 00 00 00 	mov    0x90(%rcx),%r15
  6f87f8:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  6f87fc:	75 c2                	jne    6f87c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x17c0>
  6f87fe:	31 c0                	xor    %eax,%eax
  6f8800:	45 31 e4             	xor    %r12d,%r12d
  6f8803:	41 0f b7 8f 8e 00 00 	movzwl 0x8e(%r15),%ecx
  6f880a:	00 
  6f880b:	49 39 cc             	cmp    %rcx,%r12
  6f880e:	0f 82 59 ff ff ff    	jb     6f876d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x176d>
  6f8814:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f881b:	00 00 00 00 00 
  6f8820:	49 8b 0f             	mov    (%r15),%rcx
  6f8823:	48 85 c9             	test   %rcx,%rcx
  6f8826:	0f 84 e2 50 00 00    	je     6fd90e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x690e>
  6f882c:	48 ff c0             	inc    %rax
  6f882f:	41 0f b7 97 8c 00 00 	movzwl 0x8c(%r15),%edx
  6f8836:	00 
  6f8837:	49 89 cf             	mov    %rcx,%r15
  6f883a:	66 3b 91 8e 00 00 00 	cmp    0x8e(%rcx),%dx
  6f8841:	73 dd                	jae    6f8820 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1820>
  6f8843:	48 85 c0             	test   %rax,%rax
  6f8846:	0f 84 9a 00 00 00    	je     6f88e6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x18e6>
  6f884c:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
  6f8850:	48 81 c6 98 00 00 00 	add    $0x98,%rsi
  6f8857:	48 89 c7             	mov    %rax,%rdi
  6f885a:	48 83 e7 07          	and    $0x7,%rdi
  6f885e:	0f 84 43 01 00 00    	je     6f89a7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x19a7>
  6f8864:	45 31 c0             	xor    %r8d,%r8d
  6f8867:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f886e:	00 00 
  6f8870:	4c 8b 3e             	mov    (%rsi),%r15
  6f8873:	49 8d b7 90 00 00 00 	lea    0x90(%r15),%rsi
  6f887a:	49 ff c0             	inc    %r8
  6f887d:	4c 39 c7             	cmp    %r8,%rdi
  6f8880:	75 ee                	jne    6f8870 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1870>
  6f8882:	48 89 c7             	mov    %rax,%rdi
  6f8885:	4c 29 c7             	sub    %r8,%rdi
  6f8888:	48 83 f8 08          	cmp    $0x8,%rax
  6f888c:	72 43                	jb     6f88d1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x18d1>
  6f888e:	66 90                	xchg   %ax,%ax
  6f8890:	48 8b 06             	mov    (%rsi),%rax
  6f8893:	48 8b 80 90 00 00 00 	mov    0x90(%rax),%rax
  6f889a:	48 8b 80 90 00 00 00 	mov    0x90(%rax),%rax
  6f88a1:	48 8b 80 90 00 00 00 	mov    0x90(%rax),%rax
  6f88a8:	48 8b 80 90 00 00 00 	mov    0x90(%rax),%rax
  6f88af:	48 8b 80 90 00 00 00 	mov    0x90(%rax),%rax
  6f88b6:	48 8b 80 90 00 00 00 	mov    0x90(%rax),%rax
  6f88bd:	4c 8b b8 90 00 00 00 	mov    0x90(%rax),%r15
  6f88c4:	49 8d b7 90 00 00 00 	lea    0x90(%r15),%rsi
  6f88cb:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  6f88cf:	75 bf                	jne    6f8890 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1890>
  6f88d1:	45 31 e4             	xor    %r12d,%r12d
  6f88d4:	4c 8b ac 24 60 01 00 	mov    0x160(%rsp),%r13
  6f88db:	00 
  6f88dc:	4d 85 ed             	test   %r13,%r13
  6f88df:	75 1d                	jne    6f88fe <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x18fe>
  6f88e1:	e9 ec 50 00 00       	jmp    6fd9d2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x69d2>
  6f88e6:	4c 8d 62 01          	lea    0x1(%rdx),%r12
  6f88ea:	49 89 cf             	mov    %rcx,%r15
  6f88ed:	4c 8b ac 24 60 01 00 	mov    0x160(%rsp),%r13
  6f88f4:	00 
  6f88f5:	4d 85 ed             	test   %r13,%r13
  6f88f8:	0f 84 d4 50 00 00    	je     6fd9d2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x69d2>
  6f88fe:	48 ff cb             	dec    %rbx
  6f8901:	48 8b 44 d1 08       	mov    0x8(%rcx,%rdx,8),%rax
  6f8906:	8b 6c 91 60          	mov    0x60(%rcx,%rdx,4),%ebp
  6f890a:	48 8b 8c 24 68 01 00 	mov    0x168(%rsp),%rcx
  6f8911:	00 
  6f8912:	41 0f b7 b5 c2 01 00 	movzwl 0x1c2(%r13),%esi
  6f8919:	00 
  6f891a:	89 f7                	mov    %esi,%edi
  6f891c:	c1 e7 05             	shl    $0x5,%edi
  6f891f:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6f8926:	45 31 f6             	xor    %r14d,%r14d
  6f8929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6f8930:	4c 39 f7             	cmp    %r14,%rdi
  6f8933:	74 2b                	je     6f8960 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1960>
  6f8935:	49 3b 84 d5 70 01 00 	cmp    0x170(%r13,%rdx,8),%rax
  6f893c:	00 
  6f893d:	41 0f 97 c0          	seta   %r8b
  6f8941:	41 80 d8 00          	sbb    $0x0,%r8b
  6f8945:	49 83 c6 20          	add    $0x20,%r14
  6f8949:	48 ff c2             	inc    %rdx
  6f894c:	41 80 f8 01          	cmp    $0x1,%r8b
  6f8950:	74 de                	je     6f8930 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1930>
  6f8952:	41 0f b6 f0          	movzbl %r8b,%esi
  6f8956:	85 f6                	test   %esi,%esi
  6f8958:	75 09                	jne    6f8963 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1963>
  6f895a:	eb 24                	jmp    6f8980 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1980>
  6f895c:	0f 1f 40 00          	nopl   0x0(%rax)
  6f8960:	48 89 f2             	mov    %rsi,%rdx
  6f8963:	48 83 e9 01          	sub    $0x1,%rcx
  6f8967:	0f 82 65 50 00 00    	jb     6fd9d2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x69d2>
  6f896d:	4d 8b ac d5 c8 01 00 	mov    0x1c8(%r13,%rdx,8),%r13
  6f8974:	00 
  6f8975:	eb 9b                	jmp    6f8912 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1912>
  6f8977:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f897e:	00 00 
  6f8980:	4b 8b 74 35 e0       	mov    -0x20(%r13,%r14,1),%rsi
  6f8985:	48 85 f6             	test   %rsi,%rsi
  6f8988:	0f 8e a2 fd ff ff    	jle    6f8730 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1730>
  6f898e:	4b 8b 7c 35 e8       	mov    -0x18(%r13,%r14,1),%rdi
  6f8993:	48 c1 e6 02          	shl    $0x2,%rsi
  6f8997:	ba 04 00 00 00       	mov    $0x4,%edx
  6f899c:	ff 15 96 2d 39 00    	call   *0x392d96(%rip)        # a8b738 <_DYNAMIC+0x250>
  6f89a2:	e9 89 fd ff ff       	jmp    6f8730 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1730>
  6f89a7:	48 89 c7             	mov    %rax,%rdi
  6f89aa:	48 83 f8 08          	cmp    $0x8,%rax
  6f89ae:	0f 82 1d ff ff ff    	jb     6f88d1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x18d1>
  6f89b4:	e9 d7 fe ff ff       	jmp    6f8890 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1890>
  6f89b9:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
  6f89be:	48 8b 83 20 02 00 00 	mov    0x220(%rbx),%rax
  6f89c5:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
  6f89cc:	00 
  6f89cd:	f3 0f 6f 83 00 02 00 	movdqu 0x200(%rbx),%xmm0
  6f89d4:	00 
  6f89d5:	f3 0f 6f 8b 10 02 00 	movdqu 0x210(%rbx),%xmm1
  6f89dc:	00 
  6f89dd:	66 0f 7f 8c 24 c0 06 	movdqa %xmm1,0x6c0(%rsp)
  6f89e4:	00 00 
  6f89e6:	66 0f 7f 84 24 b0 06 	movdqa %xmm0,0x6b0(%rsp)
  6f89ed:	00 00 
  6f89ef:	48 c7 83 00 02 00 00 	movq   $0x0,0x200(%rbx)
  6f89f6:	00 00 00 00 
  6f89fa:	48 8b b3 98 02 00 00 	mov    0x298(%rbx),%rsi
  6f8a01:	48 8b 93 a0 02 00 00 	mov    0x2a0(%rbx),%rdx
  6f8a08:	48 8d bc 24 d8 07 00 	lea    0x7d8(%rsp),%rdi
  6f8a0f:	00 
  6f8a10:	ff 15 aa 31 39 00    	call   *0x3931aa(%rip)        # a8bbc0 <_DYNAMIC+0x6d8>
  6f8a16:	48 8b 83 b0 05 00 00 	mov    0x5b0(%rbx),%rax
  6f8a1d:	48 89 84 24 10 05 00 	mov    %rax,0x510(%rsp)
  6f8a24:	00 
  6f8a25:	48 8b 83 b8 05 00 00 	mov    0x5b8(%rbx),%rax
  6f8a2c:	48 89 84 24 00 04 00 	mov    %rax,0x400(%rsp)
  6f8a33:	00 
  6f8a34:	48 c7 83 b0 05 00 00 	movq   $0x8,0x5b0(%rbx)
  6f8a3b:	08 00 00 00 
  6f8a3f:	48 c7 83 b8 05 00 00 	movq   $0x0,0x5b8(%rbx)
  6f8a46:	00 00 00 00 
  6f8a4a:	48 8b 83 90 02 00 00 	mov    0x290(%rbx),%rax
  6f8a51:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
  6f8a58:	00 
  6f8a59:	48 8b 83 98 02 00 00 	mov    0x298(%rbx),%rax
  6f8a60:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f8a65:	4c 8b b3 a0 02 00 00 	mov    0x2a0(%rbx),%r14
  6f8a6c:	48 c7 83 90 02 00 00 	movq   $0x0,0x290(%rbx)
  6f8a73:	00 00 00 00 
  6f8a77:	48 c7 83 98 02 00 00 	movq   $0x8,0x298(%rbx)
  6f8a7e:	08 00 00 00 
  6f8a82:	48 c7 83 a0 02 00 00 	movq   $0x0,0x2a0(%rbx)
  6f8a89:	00 00 00 00 
  6f8a8d:	48 c7 84 24 80 06 00 	movq   $0x0,0x680(%rsp)
  6f8a94:	00 00 00 00 00 
  6f8a99:	48 c7 84 24 90 06 00 	movq   $0x0,0x690(%rsp)
  6f8aa0:	00 00 00 00 00 
  6f8aa5:	48 c7 84 24 98 06 00 	movq   $0x0,0x698(%rsp)
  6f8aac:	00 00 00 00 00 
  6f8ab1:	48 c7 84 24 a8 06 00 	movq   $0x0,0x6a8(%rsp)
  6f8ab8:	00 00 00 00 00 
  6f8abd:	48 8b 83 48 06 00 00 	mov    0x648(%rbx),%rax
  6f8ac4:	48 8b 8b 50 06 00 00 	mov    0x650(%rbx),%rcx
  6f8acb:	31 d2                	xor    %edx,%edx
  6f8acd:	48 89 c6             	mov    %rax,%rsi
  6f8ad0:	48 85 c0             	test   %rax,%rax
  6f8ad3:	40 0f 95 c7          	setne  %dil
  6f8ad7:	74 0c                	je     6f8ae5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ae5>
  6f8ad9:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  6f8ade:	48 8b b6 58 06 00 00 	mov    0x658(%rsi),%rsi
  6f8ae5:	40 88 fa             	mov    %dil,%dl
  6f8ae8:	48 89 94 24 90 00 00 	mov    %rdx,0x90(%rsp)
  6f8aef:	00 
  6f8af0:	48 c7 84 24 98 00 00 	movq   $0x0,0x98(%rsp)
  6f8af7:	00 00 00 00 00 
  6f8afc:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6f8b03:	00 
  6f8b04:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
  6f8b0b:	00 
  6f8b0c:	48 89 94 24 b0 00 00 	mov    %rdx,0xb0(%rsp)
  6f8b13:	00 
  6f8b14:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  6f8b1b:	00 00 00 00 00 
  6f8b20:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  6f8b27:	00 
  6f8b28:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
  6f8b2f:	00 
  6f8b30:	48 89 b4 24 d0 00 00 	mov    %rsi,0xd0(%rsp)
  6f8b37:	00 
  6f8b38:	41 b7 01             	mov    $0x1,%r15b
  6f8b3b:	48 8d bc 24 a8 08 00 	lea    0x8a8(%rsp),%rdi
  6f8b42:	00 
  6f8b43:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f8b4a:	00 
  6f8b4b:	41 b5 01             	mov    $0x1,%r13b
  6f8b4e:	e8 bd 06 01 00       	call   709210 <<alloc::collections::btree::map::BTreeMap<u64, gpui::list::ListId> as core::iter::traits::collect::FromIterator<(u64, gpui::list::ListId)>>::from_iter::<core::iter::adapters::filter_map::FilterMap<alloc::collections::btree::map::Iter<gpui::runtime::scroll::ViewportKey, gpui::runtime::scroll::ViewportState>, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#15}>>>
  6f8b53:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
  6f8b58:	4d 85 f6             	test   %r14,%r14
  6f8b5b:	4c 89 74 24 40       	mov    %r14,0x40(%rsp)
  6f8b60:	0f 84 4a 05 00 00    	je     6f90b0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x20b0>
  6f8b66:	4b 8d 04 76          	lea    (%r14,%r14,2),%rax
  6f8b6a:	48 8b 6c 24 60       	mov    0x60(%rsp),%rbp
  6f8b6f:	48 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%rax
  6f8b76:	00 
  6f8b77:	48 01 e8             	add    %rbp,%rax
  6f8b7a:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6f8b7f:	4c 8b a4 24 a8 08 00 	mov    0x8a8(%rsp),%r12
  6f8b86:	00 
  6f8b87:	48 8b 84 24 b0 08 00 	mov    0x8b0(%rsp),%rax
  6f8b8e:	00 
  6f8b8f:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6f8b94:	31 db                	xor    %ebx,%ebx
  6f8b96:	eb 2a                	jmp    6f8bc2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1bc2>
  6f8b98:	48 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%rcx
  6f8b9f:	00 
  6f8ba0:	48 89 9c c8 68 01 00 	mov    %rbx,0x168(%rax,%rcx,8)
  6f8ba7:	00 
  6f8ba8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6f8baf:	00 
  6f8bb0:	48 83 c5 18          	add    $0x18,%rbp
  6f8bb4:	48 ff c3             	inc    %rbx
  6f8bb7:	48 3b 6c 24 20       	cmp    0x20(%rsp),%rbp
  6f8bbc:	0f 84 1e 04 00 00    	je     6f8fe0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1fe0>
  6f8bc2:	48 8b 45 00          	mov    0x0(%rbp),%rax
  6f8bc6:	48 85 c0             	test   %rax,%rax
  6f8bc9:	0f 84 93 4b 00 00    	je     6fd762 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6762>
  6f8bcf:	8b 7d 08             	mov    0x8(%rbp),%edi
  6f8bd2:	b9 ff ff 01 00       	mov    $0x1ffff,%ecx
  6f8bd7:	21 cf                	and    %ecx,%edi
  6f8bd9:	74 3f                	je     6f8c1a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1c1a>
  6f8bdb:	ff cf                	dec    %edi
  6f8bdd:	48 39 7c 24 40       	cmp    %rdi,0x40(%rsp)
  6f8be2:	0f 86 34 4e 00 00    	jbe    6fda1c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a1c>
  6f8be8:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  6f8bec:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  6f8bf1:	4c 8b 34 ca          	mov    (%rdx,%rcx,8),%r14
  6f8bf5:	41 bf 01 00 00 00    	mov    $0x1,%r15d
  6f8bfb:	4d 85 f6             	test   %r14,%r14
  6f8bfe:	0f 84 2b 4c 00 00    	je     6fd82f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x682f>
  6f8c04:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6f8c09:	48 8b 8a 60 06 00 00 	mov    0x660(%rdx),%rcx
  6f8c10:	48 85 c9             	test   %rcx,%rcx
  6f8c13:	75 1d                	jne    6f8c32 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1c32>
  6f8c15:	e9 f6 01 00 00       	jmp    6f8e10 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e10>
  6f8c1a:	45 31 ff             	xor    %r15d,%r15d
  6f8c1d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6f8c22:	48 8b 8a 60 06 00 00 	mov    0x660(%rdx),%rcx
  6f8c29:	48 85 c9             	test   %rcx,%rcx
  6f8c2c:	0f 84 de 01 00 00    	je     6f8e10 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e10>
  6f8c32:	48 8b b2 68 06 00 00 	mov    0x668(%rdx),%rsi
  6f8c39:	44 0f b7 81 c2 01 00 	movzwl 0x1c2(%rcx),%r8d
  6f8c40:	00 
  6f8c41:	45 89 c1             	mov    %r8d,%r9d
  6f8c44:	41 c1 e1 05          	shl    $0x5,%r9d
  6f8c48:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
  6f8c4f:	31 d2                	xor    %edx,%edx
  6f8c51:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f8c58:	0f 1f 84 00 00 00 00 
  6f8c5f:	00 
  6f8c60:	49 39 d1             	cmp    %rdx,%r9
  6f8c63:	74 2b                	je     6f8c90 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1c90>
  6f8c65:	48 3b 84 f9 70 01 00 	cmp    0x170(%rcx,%rdi,8),%rax
  6f8c6c:	00 
  6f8c6d:	41 0f 97 c2          	seta   %r10b
  6f8c71:	41 80 da 00          	sbb    $0x0,%r10b
  6f8c75:	48 83 c2 20          	add    $0x20,%rdx
  6f8c79:	48 ff c7             	inc    %rdi
  6f8c7c:	41 80 fa 01          	cmp    $0x1,%r10b
  6f8c80:	74 de                	je     6f8c60 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1c60>
  6f8c82:	45 0f b6 c2          	movzbl %r10b,%r8d
  6f8c86:	45 85 c0             	test   %r8d,%r8d
  6f8c89:	75 08                	jne    6f8c93 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1c93>
  6f8c8b:	eb 23                	jmp    6f8cb0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1cb0>
  6f8c8d:	0f 1f 00             	nopl   (%rax)
  6f8c90:	4c 89 c7             	mov    %r8,%rdi
  6f8c93:	48 83 ee 01          	sub    $0x1,%rsi
  6f8c97:	0f 82 73 01 00 00    	jb     6f8e10 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e10>
  6f8c9d:	48 8b 8c f9 c8 01 00 	mov    0x1c8(%rcx,%rdi,8),%rcx
  6f8ca4:	00 
  6f8ca5:	eb 92                	jmp    6f8c39 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1c39>
  6f8ca7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f8cae:	00 00 
  6f8cb0:	80 7c 11 fc 01       	cmpb   $0x1,-0x4(%rcx,%rdx,1)
  6f8cb5:	0f 85 55 01 00 00    	jne    6f8e10 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e10>
  6f8cbb:	8b 45 10             	mov    0x10(%rbp),%eax
  6f8cbe:	83 e0 0f             	and    $0xf,%eax
  6f8cc1:	83 f8 09             	cmp    $0x9,%eax
  6f8cc4:	0f 87 ee 4b 00 00    	ja     6fd8b8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x68b8>
  6f8cca:	48 8d 35 53 f0 95 ff 	lea    -0x6a0fad(%rip),%rsi        # 57d24 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x7c>
  6f8cd1:	48 63 04 86          	movslq (%rsi,%rax,4),%rax
  6f8cd5:	48 01 f0             	add    %rsi,%rax
  6f8cd8:	ff e0                	jmp    *%rax
  6f8cda:	31 c0                	xor    %eax,%eax
  6f8cdc:	eb 1e                	jmp    6f8cfc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1cfc>
  6f8cde:	b0 06                	mov    $0x6,%al
  6f8ce0:	eb 1a                	jmp    6f8cfc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1cfc>
  6f8ce2:	b0 04                	mov    $0x4,%al
  6f8ce4:	eb 16                	jmp    6f8cfc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1cfc>
  6f8ce6:	b0 05                	mov    $0x5,%al
  6f8ce8:	eb 12                	jmp    6f8cfc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1cfc>
  6f8cea:	b0 09                	mov    $0x9,%al
  6f8cec:	eb 0e                	jmp    6f8cfc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1cfc>
  6f8cee:	b0 02                	mov    $0x2,%al
  6f8cf0:	eb 0a                	jmp    6f8cfc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1cfc>
  6f8cf2:	b0 03                	mov    $0x3,%al
  6f8cf4:	eb 06                	jmp    6f8cfc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1cfc>
  6f8cf6:	b0 07                	mov    $0x7,%al
  6f8cf8:	eb 02                	jmp    6f8cfc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1cfc>
  6f8cfa:	b0 08                	mov    $0x8,%al
  6f8cfc:	4c 8b 6c 11 e8       	mov    -0x18(%rcx,%rdx,1),%r13
  6f8d01:	4c 89 bc 24 f0 02 00 	mov    %r15,0x2f0(%rsp)
  6f8d08:	00 
  6f8d09:	4c 89 b4 24 f8 02 00 	mov    %r14,0x2f8(%rsp)
  6f8d10:	00 
  6f8d11:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
  6f8d18:	00 
  6f8d19:	88 84 24 08 03 00 00 	mov    %al,0x308(%rsp)
  6f8d20:	48 8b b4 24 80 06 00 	mov    0x680(%rsp),%rsi
  6f8d27:	00 
  6f8d28:	48 85 f6             	test   %rsi,%rsi
  6f8d2b:	74 5a                	je     6f8d87 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1d87>
  6f8d2d:	48 8b 94 24 88 06 00 	mov    0x688(%rsp),%rdx
  6f8d34:	00 
  6f8d35:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f8d3c:	00 
  6f8d3d:	48 8d 8c 24 f0 02 00 	lea    0x2f0(%rsp),%rcx
  6f8d44:	00 
  6f8d45:	e8 76 6b fe ff       	call   6df8c0 <<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Mut, (core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize, alloc::collections::btree::node::marker::LeafOrInternal>>::search_tree::<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind)>>
  6f8d4a:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  6f8d51:	00 
  6f8d52:	80 bc 24 90 00 00 00 	cmpb   $0x0,0x90(%rsp)
  6f8d59:	00 
  6f8d5a:	0f 84 9c 00 00 00    	je     6f8dfc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1dfc>
  6f8d60:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
  6f8d67:	00 
  6f8d68:	f3 0f 6f 06          	movdqu (%rsi),%xmm0
  6f8d6c:	66 0f 7f 84 24 a0 01 	movdqa %xmm0,0x1a0(%rsp)
  6f8d73:	00 00 
  6f8d75:	48 8b 94 24 f8 02 00 	mov    0x2f8(%rsp),%rdx
  6f8d7c:	00 
  6f8d7d:	48 8b 8c 24 08 03 00 	mov    0x308(%rsp),%rcx
  6f8d84:	00 
  6f8d85:	eb 15                	jmp    6f8d9c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1d9c>
  6f8d87:	48 8b 8c 24 08 03 00 	mov    0x308(%rsp),%rcx
  6f8d8e:	00 
  6f8d8f:	4c 89 f2             	mov    %r14,%rdx
  6f8d92:	31 c0                	xor    %eax,%eax
  6f8d94:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
  6f8d9b:	00 
  6f8d9c:	4c 89 bc 24 90 00 00 	mov    %r15,0x90(%rsp)
  6f8da3:	00 
  6f8da4:	48 89 94 24 98 00 00 	mov    %rdx,0x98(%rsp)
  6f8dab:	00 
  6f8dac:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
  6f8db3:	00 
  6f8db4:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
  6f8dbb:	00 
  6f8dbc:	48 8d 8c 24 80 06 00 	lea    0x680(%rsp),%rcx
  6f8dc3:	00 
  6f8dc4:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
  6f8dcb:	00 
  6f8dcc:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  6f8dd3:	00 
  6f8dd4:	66 0f 6f 84 24 a0 01 	movdqa 0x1a0(%rsp),%xmm0
  6f8ddb:	00 00 
  6f8ddd:	f3 0f 7f 46 20       	movdqu %xmm0,0x20(%rsi)
  6f8de2:	48 8d bc 24 20 07 00 	lea    0x720(%rsp),%rdi
  6f8de9:	00 
  6f8dea:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f8df1:	00 
  6f8df2:	48 89 da             	mov    %rbx,%rdx
  6f8df5:	e8 f6 8e 01 00       	call   711cf0 <<alloc::collections::btree::map::entry::VacantEntry<(core::option::Option<u64>, gpui::list::ItemKey, gpui::element::NodeKind), usize>>::insert_entry>
  6f8dfa:	eb 10                	jmp    6f8e0c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e0c>
  6f8dfc:	48 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%rcx
  6f8e03:	00 
  6f8e04:	48 89 9c c8 68 01 00 	mov    %rbx,0x168(%rax,%rcx,8)
  6f8e0b:	00 
  6f8e0c:	48 8b 45 00          	mov    0x0(%rbp),%rax
  6f8e10:	4d 85 e4             	test   %r12,%r12
  6f8e13:	0f 84 97 fd ff ff    	je     6f8bb0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1bb0>
  6f8e19:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  6f8e1e:	4c 89 e1             	mov    %r12,%rcx
  6f8e21:	0f b7 b9 ba 00 00 00 	movzwl 0xba(%rcx),%edi
  6f8e28:	41 89 f8             	mov    %edi,%r8d
  6f8e2b:	41 c1 e0 03          	shl    $0x3,%r8d
  6f8e2f:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6f8e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6f8e3d:	00 00 00 
  6f8e40:	4d 85 c0             	test   %r8,%r8
  6f8e43:	74 2b                	je     6f8e70 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e70>
  6f8e45:	48 3b 44 d1 10       	cmp    0x10(%rcx,%rdx,8),%rax
  6f8e4a:	41 0f 97 c1          	seta   %r9b
  6f8e4e:	41 80 d9 00          	sbb    $0x0,%r9b
  6f8e52:	48 ff c2             	inc    %rdx
  6f8e55:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  6f8e59:	41 80 f9 01          	cmp    $0x1,%r9b
  6f8e5d:	74 e1                	je     6f8e40 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e40>
  6f8e5f:	41 0f b6 f9          	movzbl %r9b,%edi
  6f8e63:	85 ff                	test   %edi,%edi
  6f8e65:	75 0c                	jne    6f8e73 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e73>
  6f8e67:	eb 27                	jmp    6f8e90 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e90>
  6f8e69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6f8e70:	48 89 fa             	mov    %rdi,%rdx
  6f8e73:	48 83 ee 01          	sub    $0x1,%rsi
  6f8e77:	0f 82 33 fd ff ff    	jb     6f8bb0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1bb0>
  6f8e7d:	48 8b 8c d1 c0 00 00 	mov    0xc0(%rcx,%rdx,8),%rcx
  6f8e84:	00 
  6f8e85:	eb 9a                	jmp    6f8e21 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e21>
  6f8e87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f8e8e:	00 00 
  6f8e90:	8b 45 10             	mov    0x10(%rbp),%eax
  6f8e93:	83 e0 0f             	and    $0xf,%eax
  6f8e96:	83 f8 09             	cmp    $0x9,%eax
  6f8e99:	0f 87 19 4a 00 00    	ja     6fd8b8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x68b8>
  6f8e9f:	48 8d 35 a6 ee 95 ff 	lea    -0x6a115a(%rip),%rsi        # 57d4c <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0xa4>
  6f8ea6:	48 63 04 86          	movslq (%rsi,%rax,4),%rax
  6f8eaa:	48 01 f0             	add    %rsi,%rax
  6f8ead:	ff e0                	jmp    *%rax
  6f8eaf:	31 c0                	xor    %eax,%eax
  6f8eb1:	eb 2d                	jmp    6f8ee0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ee0>
  6f8eb3:	b0 06                	mov    $0x6,%al
  6f8eb5:	eb 29                	jmp    6f8ee0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ee0>
  6f8eb7:	b0 04                	mov    $0x4,%al
  6f8eb9:	eb 25                	jmp    6f8ee0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ee0>
  6f8ebb:	b0 05                	mov    $0x5,%al
  6f8ebd:	eb 21                	jmp    6f8ee0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ee0>
  6f8ebf:	b0 09                	mov    $0x9,%al
  6f8ec1:	eb 1d                	jmp    6f8ee0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ee0>
  6f8ec3:	b0 02                	mov    $0x2,%al
  6f8ec5:	eb 19                	jmp    6f8ee0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ee0>
  6f8ec7:	b0 03                	mov    $0x3,%al
  6f8ec9:	eb 15                	jmp    6f8ee0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ee0>
  6f8ecb:	b0 07                	mov    $0x7,%al
  6f8ecd:	eb 11                	jmp    6f8ee0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ee0>
  6f8ecf:	b0 08                	mov    $0x8,%al
  6f8ed1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f8ed8:	0f 1f 84 00 00 00 00 
  6f8edf:	00 
  6f8ee0:	4c 8b 6c d1 60       	mov    0x60(%rcx,%rdx,8),%r13
  6f8ee5:	4c 89 bc 24 f0 02 00 	mov    %r15,0x2f0(%rsp)
  6f8eec:	00 
  6f8eed:	4c 89 b4 24 f8 02 00 	mov    %r14,0x2f8(%rsp)
  6f8ef4:	00 
  6f8ef5:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
  6f8efc:	00 
  6f8efd:	88 84 24 08 03 00 00 	mov    %al,0x308(%rsp)
  6f8f04:	48 8b b4 24 98 06 00 	mov    0x698(%rsp),%rsi
  6f8f0b:	00 
  6f8f0c:	48 85 f6             	test   %rsi,%rsi
  6f8f0f:	74 5a                	je     6f8f6b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1f6b>
  6f8f11:	48 8b 94 24 a0 06 00 	mov    0x6a0(%rsp),%rdx
  6f8f18:	00 
  6f8f19:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6f8f20:	00 
  6f8f21:	48 8d 8c 24 f0 02 00 	lea    0x2f0(%rsp),%rcx
  6f8f28:	00 
  6f8f29:	e8 92 69 fe ff       	call   6df8c0 <<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Mut, (core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize, alloc::collections::btree::node::marker::LeafOrInternal>>::search_tree::<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind)>>
  6f8f2e:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  6f8f35:	00 
  6f8f36:	80 bc 24 90 00 00 00 	cmpb   $0x0,0x90(%rsp)
  6f8f3d:	00 
  6f8f3e:	0f 84 54 fc ff ff    	je     6f8b98 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1b98>
  6f8f44:	48 8d 94 24 a0 00 00 	lea    0xa0(%rsp),%rdx
  6f8f4b:	00 
  6f8f4c:	f3 0f 6f 02          	movdqu (%rdx),%xmm0
  6f8f50:	66 0f 7f 84 24 a0 01 	movdqa %xmm0,0x1a0(%rsp)
  6f8f57:	00 00 
  6f8f59:	4c 8b b4 24 f8 02 00 	mov    0x2f8(%rsp),%r14
  6f8f60:	00 
  6f8f61:	48 8b 8c 24 08 03 00 	mov    0x308(%rsp),%rcx
  6f8f68:	00 
  6f8f69:	eb 12                	jmp    6f8f7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1f7d>
  6f8f6b:	48 8b 8c 24 08 03 00 	mov    0x308(%rsp),%rcx
  6f8f72:	00 
  6f8f73:	31 c0                	xor    %eax,%eax
  6f8f75:	48 8d 94 24 a0 00 00 	lea    0xa0(%rsp),%rdx
  6f8f7c:	00 
  6f8f7d:	4c 89 bc 24 90 00 00 	mov    %r15,0x90(%rsp)
  6f8f84:	00 
  6f8f85:	4c 89 b4 24 98 00 00 	mov    %r14,0x98(%rsp)
  6f8f8c:	00 
  6f8f8d:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
  6f8f94:	00 
  6f8f95:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
  6f8f9c:	00 
  6f8f9d:	48 8d 8c 24 98 06 00 	lea    0x698(%rsp),%rcx
  6f8fa4:	00 
  6f8fa5:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
  6f8fac:	00 
  6f8fad:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  6f8fb4:	00 
  6f8fb5:	66 0f 6f 84 24 a0 01 	movdqa 0x1a0(%rsp),%xmm0
  6f8fbc:	00 00 
  6f8fbe:	f3 0f 7f 42 20       	movdqu %xmm0,0x20(%rdx)
  6f8fc3:	48 8d bc 24 20 07 00 	lea    0x720(%rsp),%rdi
  6f8fca:	00 
  6f8fcb:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f8fd2:	00 
  6f8fd3:	48 89 da             	mov    %rbx,%rdx
  6f8fd6:	e8 15 8c 01 00       	call   711bf0 <<alloc::collections::btree::map::entry::VacantEntry<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize>>::insert_entry>
  6f8fdb:	e9 d0 fb ff ff       	jmp    6f8bb0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1bb0>
  6f8fe0:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
  6f8fe5:	4a 8d 1c f5 00 00 00 	lea    0x0(,%r14,8),%rbx
  6f8fec:	00 
  6f8fed:	ff 15 35 27 39 00    	call   *0x392735(%rip)        # a8b728 <_DYNAMIC+0x240>
  6f8ff3:	be 08 00 00 00       	mov    $0x8,%esi
  6f8ff8:	48 89 df             	mov    %rbx,%rdi
  6f8ffb:	ff 15 2f 27 39 00    	call   *0x39272f(%rip)        # a8b730 <_DYNAMIC+0x248>
  6f9001:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6f9008:	00 
  6f9009:	48 85 c0             	test   %rax,%rax
  6f900c:	0f 84 88 4c 00 00    	je     6fdc9a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c9a>
  6f9012:	31 c0                	xor    %eax,%eax
  6f9014:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  6f9019:	4c 8b ac 24 90 02 00 	mov    0x290(%rsp),%r13
  6f9020:	00 
  6f9021:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  6f9028:	00 
  6f9029:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6f9030:	48 8b 11             	mov    (%rcx),%rdx
  6f9033:	48 85 d2             	test   %rdx,%rdx
  6f9036:	0f 84 38 47 00 00    	je     6fd774 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6774>
  6f903c:	48 89 14 c6          	mov    %rdx,(%rsi,%rax,8)
  6f9040:	48 ff c0             	inc    %rax
  6f9043:	48 83 c1 18          	add    $0x18,%rcx
  6f9047:	49 39 c6             	cmp    %rax,%r14
  6f904a:	75 e4                	jne    6f9030 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2030>
  6f904c:	4c 89 b4 24 a8 02 00 	mov    %r14,0x2a8(%rsp)
  6f9053:	00 
  6f9054:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
  6f9059:	eb 76                	jmp    6f90d1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x20d1>
  6f905b:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  6f9062:	00 
  6f9063:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  6f9068:	48 c7 02 20 00 00 00 	movq   $0x20,(%rdx)
  6f906f:	48 89 42 08          	mov    %rax,0x8(%rdx)
  6f9073:	4c 89 7a 10          	mov    %r15,0x10(%rdx)
  6f9077:	48 89 4a 18          	mov    %rcx,0x18(%rdx)
  6f907b:	48 83 bc 24 20 02 00 	cmpq   $0x0,0x220(%rsp)
  6f9082:	00 00 
  6f9084:	0f 84 1c 2d 00 00    	je     6fbda6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4da6>
  6f908a:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
  6f9091:	00 
  6f9092:	48 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%rax
  6f9099:	00 
  6f909a:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6f909e:	ba 08 00 00 00       	mov    $0x8,%edx
  6f90a3:	48 8b bc 24 38 02 00 	mov    0x238(%rsp),%rdi
  6f90aa:	00 
  6f90ab:	e9 f0 2c 00 00       	jmp    6fbda0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4da0>
  6f90b0:	b8 08 00 00 00       	mov    $0x8,%eax
  6f90b5:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6f90bc:	00 
  6f90bd:	48 c7 84 24 a8 02 00 	movq   $0x0,0x2a8(%rsp)
  6f90c4:	00 00 00 00 00 
  6f90c9:	4c 8b ac 24 90 02 00 	mov    0x290(%rsp),%r13
  6f90d0:	00 
  6f90d1:	4c 8b b4 24 40 04 00 	mov    0x440(%rsp),%r14
  6f90d8:	00 
  6f90d9:	0f 10 84 24 40 08 00 	movups 0x840(%rsp),%xmm0
  6f90e0:	00 
  6f90e1:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
  6f90e8:	00 
  6f90e9:	0f 10 84 24 30 08 00 	movups 0x830(%rsp),%xmm0
  6f90f0:	00 
  6f90f1:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
  6f90f8:	00 
  6f90f9:	f3 0f 6f 84 24 f0 07 	movdqu 0x7f0(%rsp),%xmm0
  6f9100:	00 00 
  6f9102:	f3 0f 6f 8c 24 00 08 	movdqu 0x800(%rsp),%xmm1
  6f9109:	00 00 
  6f910b:	f3 0f 6f 94 24 10 08 	movdqu 0x810(%rsp),%xmm2
  6f9112:	00 00 
  6f9114:	0f 10 9c 24 20 08 00 	movups 0x820(%rsp),%xmm3
  6f911b:	00 
  6f911c:	0f 29 9c 24 c0 00 00 	movaps %xmm3,0xc0(%rsp)
  6f9123:	00 
  6f9124:	66 0f 7f 94 24 b0 00 	movdqa %xmm2,0xb0(%rsp)
  6f912b:	00 00 
  6f912d:	66 0f 7f 8c 24 a0 00 	movdqa %xmm1,0xa0(%rsp)
  6f9134:	00 00 
  6f9136:	66 0f 7f 84 24 90 00 	movdqa %xmm0,0x90(%rsp)
  6f913d:	00 00 
  6f913f:	48 8d bc 24 20 07 00 	lea    0x720(%rsp),%rdi
  6f9146:	00 
  6f9147:	48 8d 94 24 90 00 00 	lea    0x90(%rsp),%rdx
  6f914e:	00 
  6f914f:	4c 89 f6             	mov    %r14,%rsi
  6f9152:	ff 15 70 2a 39 00    	call   *0x392a70(%rip)        # a8bbc8 <_DYNAMIC+0x6e0>
  6f9158:	4d 85 f6             	test   %r14,%r14
  6f915b:	74 30                	je     6f918d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x218d>
  6f915d:	4a 8d 04 f5 00 00 00 	lea    0x0(,%r14,8),%rax
  6f9164:	00 
  6f9165:	48 8d 1c 40          	lea    (%rax,%rax,2),%rbx
  6f9169:	ff 15 b9 25 39 00    	call   *0x3925b9(%rip)        # a8b728 <_DYNAMIC+0x240>
  6f916f:	be 08 00 00 00       	mov    $0x8,%esi
  6f9174:	48 89 df             	mov    %rbx,%rdi
  6f9177:	ff 15 b3 25 39 00    	call   *0x3925b3(%rip)        # a8b730 <_DYNAMIC+0x248>
  6f917d:	48 85 c0             	test   %rax,%rax
  6f9180:	0f 84 01 4b 00 00    	je     6fdc87 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c87>
  6f9186:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
  6f918b:	eb 05                	jmp    6f9192 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2192>
  6f918d:	b8 08 00 00 00       	mov    $0x8,%eax
  6f9192:	4c 89 b4 24 b0 02 00 	mov    %r14,0x2b0(%rsp)
  6f9199:	00 
  6f919a:	4c 89 b4 24 80 01 00 	mov    %r14,0x180(%rsp)
  6f91a1:	00 
  6f91a2:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
  6f91a9:	00 
  6f91aa:	48 c7 84 24 90 01 00 	movq   $0x0,0x190(%rsp)
  6f91b1:	00 00 00 00 00 
  6f91b6:	49 89 de             	mov    %rbx,%r14
  6f91b9:	49 c1 e6 04          	shl    $0x4,%r14
  6f91bd:	48 89 d8             	mov    %rbx,%rax
  6f91c0:	48 c1 e8 3c          	shr    $0x3c,%rax
  6f91c4:	0f 95 c0             	setne  %al
  6f91c7:	48 b9 01 00 00 00 00 	movabs $0x8000000000000001,%rcx
  6f91ce:	00 00 80 
  6f91d1:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
  6f91d5:	49 39 ce             	cmp    %rcx,%r14
  6f91d8:	0f 97 c1             	seta   %cl
  6f91db:	08 c1                	or     %al,%cl
  6f91dd:	74 14                	je     6f91f3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x21f3>
  6f91df:	45 31 ff             	xor    %r15d,%r15d
  6f91e2:	4c 89 ff             	mov    %r15,%rdi
  6f91e5:	4c 89 f6             	mov    %r14,%rsi
  6f91e8:	ff 15 12 26 39 00    	call   *0x392612(%rip)        # a8b800 <_DYNAMIC+0x318>
  6f91ee:	e9 8a 4b 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6f91f3:	bb 08 00 00 00       	mov    $0x8,%ebx
  6f91f8:	4d 85 f6             	test   %r14,%r14
  6f91fb:	74 66                	je     6f9263 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2263>
  6f91fd:	ff 15 25 25 39 00    	call   *0x392525(%rip)        # a8b728 <_DYNAMIC+0x240>
  6f9203:	41 bf 08 00 00 00    	mov    $0x8,%r15d
  6f9209:	be 08 00 00 00       	mov    $0x8,%esi
  6f920e:	4c 89 f7             	mov    %r14,%rdi
  6f9211:	ff 15 19 25 39 00    	call   *0x392519(%rip)        # a8b730 <_DYNAMIC+0x248>
  6f9217:	48 85 c0             	test   %rax,%rax
  6f921a:	74 c6                	je     6f91e2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x21e2>
  6f921c:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  6f9221:	eb 47                	jmp    6f926a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x226a>
  6f9223:	f3 0f 6f 84 24 98 00 	movdqu 0x98(%rsp),%xmm0
  6f922a:	00 00 
  6f922c:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6f9231:	48 c7 01 20 00 00 00 	movq   $0x20,(%rcx)
  6f9238:	48 89 41 08          	mov    %rax,0x8(%rcx)
  6f923c:	f3 0f 7f 41 10       	movdqu %xmm0,0x10(%rcx)
  6f9241:	e9 3c 2b 00 00       	jmp    6fbd82 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d82>
  6f9246:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f924b:	48 89 58 10          	mov    %rbx,0x10(%rax)
  6f924f:	48 c7 00 20 00 00 00 	movq   $0x20,(%rax)
  6f9256:	48 c7 40 08 0c 00 00 	movq   $0xc,0x8(%rax)
  6f925d:	00 
  6f925e:	e9 e5 3f 00 00       	jmp    6fd248 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6248>
  6f9263:	31 c9                	xor    %ecx,%ecx
  6f9265:	b8 08 00 00 00       	mov    $0x8,%eax
  6f926a:	48 89 8c 24 60 05 00 	mov    %rcx,0x560(%rsp)
  6f9271:	00 
  6f9272:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
  6f9279:	00 
  6f927a:	48 c7 84 24 70 05 00 	movq   $0x0,0x570(%rsp)
  6f9281:	00 00 00 00 00 
  6f9286:	48 8b 84 24 38 04 00 	mov    0x438(%rsp),%rax
  6f928d:	00 
  6f928e:	4c 8b b4 24 b0 02 00 	mov    0x2b0(%rsp),%r14
  6f9295:	00 
  6f9296:	4d 85 f6             	test   %r14,%r14
  6f9299:	74 13                	je     6f92ae <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x22ae>
  6f929b:	44 89 f1             	mov    %r14d,%ecx
  6f929e:	83 e1 03             	and    $0x3,%ecx
  6f92a1:	49 83 fe 04          	cmp    $0x4,%r14
  6f92a5:	73 0f                	jae    6f92b6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x22b6>
  6f92a7:	31 d2                	xor    %edx,%edx
  6f92a9:	45 31 ff             	xor    %r15d,%r15d
  6f92ac:	eb 76                	jmp    6f9324 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2324>
  6f92ae:	49 89 c4             	mov    %rax,%r12
  6f92b1:	e9 d8 00 00 00       	jmp    6f938e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x238e>
  6f92b6:	48 be fc ff ff ff ff 	movabs $0xfffffffffffffc,%rsi
  6f92bd:	ff ff 00 
  6f92c0:	4c 21 f6             	and    %r14,%rsi
  6f92c3:	31 d2                	xor    %edx,%edx
  6f92c5:	48 89 c7             	mov    %rax,%rdi
  6f92c8:	45 31 ff             	xor    %r15d,%r15d
  6f92cb:	45 31 c0             	xor    %r8d,%r8d
  6f92ce:	48 83 3f ff          	cmpq   $0xffffffffffffffff,(%rdi)
  6f92d2:	41 0f 95 c0          	setne  %r8b
  6f92d6:	4d 01 f8             	add    %r15,%r8
  6f92d9:	45 31 c9             	xor    %r9d,%r9d
  6f92dc:	48 83 bf 98 00 00 00 	cmpq   $0xffffffffffffffff,0x98(%rdi)
  6f92e3:	ff 
  6f92e4:	41 0f 95 c1          	setne  %r9b
  6f92e8:	45 31 d2             	xor    %r10d,%r10d
  6f92eb:	48 83 bf 30 01 00 00 	cmpq   $0xffffffffffffffff,0x130(%rdi)
  6f92f2:	ff 
  6f92f3:	41 0f 95 c2          	setne  %r10b
  6f92f7:	4d 01 ca             	add    %r9,%r10
  6f92fa:	4d 01 c2             	add    %r8,%r10
  6f92fd:	45 31 ff             	xor    %r15d,%r15d
  6f9300:	48 83 bf c8 01 00 00 	cmpq   $0xffffffffffffffff,0x1c8(%rdi)
  6f9307:	ff 
  6f9308:	41 0f 95 c7          	setne  %r15b
  6f930c:	4d 01 d7             	add    %r10,%r15
  6f930f:	48 83 c2 04          	add    $0x4,%rdx
  6f9313:	48 81 c7 60 02 00 00 	add    $0x260,%rdi
  6f931a:	48 39 d6             	cmp    %rdx,%rsi
  6f931d:	75 ac                	jne    6f92cb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x22cb>
  6f931f:	48 85 c9             	test   %rcx,%rcx
  6f9322:	74 2d                	je     6f9351 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2351>
  6f9324:	48 69 d2 98 00 00 00 	imul   $0x98,%rdx,%rdx
  6f932b:	48 01 c2             	add    %rax,%rdx
  6f932e:	48 69 c9 98 00 00 00 	imul   $0x98,%rcx,%rcx
  6f9335:	31 f6                	xor    %esi,%esi
  6f9337:	31 ff                	xor    %edi,%edi
  6f9339:	48 83 3c 32 ff       	cmpq   $0xffffffffffffffff,(%rdx,%rsi,1)
  6f933e:	40 0f 95 c7          	setne  %dil
  6f9342:	49 01 ff             	add    %rdi,%r15
  6f9345:	48 81 c6 98 00 00 00 	add    $0x98,%rsi
  6f934c:	48 39 f1             	cmp    %rsi,%rcx
  6f934f:	75 e6                	jne    6f9337 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2337>
  6f9351:	49 89 c4             	mov    %rax,%r12
  6f9354:	4d 85 ff             	test   %r15,%r15
  6f9357:	74 35                	je     6f938e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x238e>
  6f9359:	4c 89 f8             	mov    %r15,%rax
  6f935c:	48 c1 e0 04          	shl    $0x4,%rax
  6f9360:	4c 8d 34 80          	lea    (%rax,%rax,4),%r14
  6f9364:	ff 15 be 23 39 00    	call   *0x3923be(%rip)        # a8b728 <_DYNAMIC+0x240>
  6f936a:	be 08 00 00 00       	mov    $0x8,%esi
  6f936f:	4c 89 f7             	mov    %r14,%rdi
  6f9372:	ff 15 b8 23 39 00    	call   *0x3923b8(%rip)        # a8b730 <_DYNAMIC+0x248>
  6f9378:	48 85 c0             	test   %rax,%rax
  6f937b:	0f 84 ee 49 00 00    	je     6fdd6f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d6f>
  6f9381:	48 89 c3             	mov    %rax,%rbx
  6f9384:	4c 8b b4 24 b0 02 00 	mov    0x2b0(%rsp),%r14
  6f938b:	00 
  6f938c:	eb 03                	jmp    6f9391 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2391>
  6f938e:	45 31 ff             	xor    %r15d,%r15d
  6f9391:	4c 89 bc 24 78 05 00 	mov    %r15,0x578(%rsp)
  6f9398:	00 
  6f9399:	48 89 9c 24 80 05 00 	mov    %rbx,0x580(%rsp)
  6f93a0:	00 
  6f93a1:	48 c7 84 24 88 05 00 	movq   $0x0,0x588(%rsp)
  6f93a8:	00 00 00 00 00 
  6f93ad:	4a 8d 1c b5 04 00 00 	lea    0x4(,%r14,4),%rbx
  6f93b4:	00 
  6f93b5:	ff 15 6d 23 39 00    	call   *0x39236d(%rip)        # a8b728 <_DYNAMIC+0x240>
  6f93bb:	be 04 00 00 00       	mov    $0x4,%esi
  6f93c0:	48 89 df             	mov    %rbx,%rdi
  6f93c3:	ff 15 9f 27 39 00    	call   *0x39279f(%rip)        # a8bb68 <_DYNAMIC+0x680>
  6f93c9:	48 89 84 24 30 02 00 	mov    %rax,0x230(%rsp)
  6f93d0:	00 
  6f93d1:	48 85 c0             	test   %rax,%rax
  6f93d4:	0f 84 ee 48 00 00    	je     6fdcc8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cc8>
  6f93da:	48 89 9c 24 a0 02 00 	mov    %rbx,0x2a0(%rsp)
  6f93e1:	00 
  6f93e2:	49 69 ce 98 00 00 00 	imul   $0x98,%r14,%rcx
  6f93e9:	4c 01 e1             	add    %r12,%rcx
  6f93ec:	48 8b 84 24 30 04 00 	mov    0x430(%rsp),%rax
  6f93f3:	00 
  6f93f4:	4c 89 a4 24 e0 06 00 	mov    %r12,0x6e0(%rsp)
  6f93fb:	00 
  6f93fc:	4c 89 a4 24 e8 06 00 	mov    %r12,0x6e8(%rsp)
  6f9403:	00 
  6f9404:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
  6f940b:	00 
  6f940c:	48 89 8c 24 58 08 00 	mov    %rcx,0x858(%rsp)
  6f9413:	00 
  6f9414:	48 89 8c 24 f8 06 00 	mov    %rcx,0x6f8(%rsp)
  6f941b:	00 
  6f941c:	48 c7 84 24 00 07 00 	movq   $0x0,0x700(%rsp)
  6f9423:	00 00 00 00 00 
  6f9428:	4d 85 f6             	test   %r14,%r14
  6f942b:	4c 8b bc 24 88 00 00 	mov    0x88(%rsp),%r15
  6f9432:	00 
  6f9433:	0f 84 c3 1a 00 00    	je     6faefc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3efc>
  6f9439:	4c 89 e6             	mov    %r12,%rsi
  6f943c:	49 8d 46 01          	lea    0x1(%r14),%rax
  6f9440:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
  6f9447:	00 
  6f9448:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f944d:	48 05 78 06 00 00    	add    $0x678,%rax
  6f9453:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  6f945a:	00 
  6f945b:	48 8d 05 f6 9c 36 00 	lea    0x369cf6(%rip),%rax        # a63158 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xcc8>
  6f9462:	48 89 84 24 f0 03 00 	mov    %rax,0x3f0(%rsp)
  6f9469:	00 
  6f946a:	48 8d 05 47 95 36 00 	lea    0x369547(%rip),%rax        # a629b8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x528>
  6f9471:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
  6f9478:	00 
  6f9479:	48 8d 05 20 9d 36 00 	lea    0x369d20(%rip),%rax        # a631a0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xd10>
  6f9480:	48 89 84 24 68 06 00 	mov    %rax,0x668(%rsp)
  6f9487:	00 
  6f9488:	48 8d 05 71 95 36 00 	lea    0x369571(%rip),%rax        # a62a00 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x570>
  6f948f:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
  6f9496:	00 
  6f9497:	45 31 f6             	xor    %r14d,%r14d
  6f949a:	48 c7 84 24 18 05 00 	movq   $0x0,0x518(%rsp)
  6f94a1:	00 00 00 00 00 
  6f94a6:	4c 8b 64 24 40       	mov    0x40(%rsp),%r12
  6f94ab:	48 8d 86 98 00 00 00 	lea    0x98(%rsi),%rax
  6f94b2:	48 89 84 24 e8 06 00 	mov    %rax,0x6e8(%rsp)
  6f94b9:	00 
  6f94ba:	48 8b 1e             	mov    (%rsi),%rbx
  6f94bd:	48 83 fb fe          	cmp    $0xfffffffffffffffe,%rbx
  6f94c1:	0f 84 46 1a 00 00    	je     6faf0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3f0d>
  6f94c7:	48 89 84 24 20 05 00 	mov    %rax,0x520(%rsp)
  6f94ce:	00 
  6f94cf:	48 83 c6 08          	add    $0x8,%rsi
  6f94d3:	ba 90 00 00 00       	mov    $0x90,%edx
  6f94d8:	4c 8d bc 24 f0 02 00 	lea    0x2f0(%rsp),%r15
  6f94df:	00 
  6f94e0:	4c 89 ff             	mov    %r15,%rdi
  6f94e3:	48 8b 2d 5e 22 39 00 	mov    0x39225e(%rip),%rbp        # a8b748 <memcpy@GLIBC_2.14>
  6f94ea:	ff d5                	call   *%rbp
  6f94ec:	49 8d 46 01          	lea    0x1(%r14),%rax
  6f94f0:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
  6f94f7:	00 
  6f94f8:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
  6f94ff:	00 
  6f9500:	48 89 9c 24 90 00 00 	mov    %rbx,0x90(%rsp)
  6f9507:	00 
  6f9508:	ba 90 00 00 00       	mov    $0x90,%edx
  6f950d:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
  6f9514:	00 
  6f9515:	4c 89 fe             	mov    %r15,%rsi
  6f9518:	ff d5                	call   *%rbp
  6f951a:	0f b6 94 24 a8 00 00 	movzbl 0xa8(%rsp),%edx
  6f9521:	00 
  6f9522:	8b 84 24 ac 00 00 00 	mov    0xac(%rsp),%eax
  6f9529:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  6f952e:	4c 8d 78 01          	lea    0x1(%rax),%r15
  6f9532:	84 d2                	test   %dl,%dl
  6f9534:	bb 00 00 00 00       	mov    $0x0,%ebx
  6f9539:	49 0f 45 df          	cmovne %r15,%rbx
  6f953d:	48 3b 9c 24 b0 02 00 	cmp    0x2b0(%rsp),%rbx
  6f9544:	00 
  6f9545:	0f 87 1e 47 00 00    	ja     6fdc69 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c69>
  6f954b:	48 8b 8c 24 30 02 00 	mov    0x230(%rsp),%rcx
  6f9552:	00 
  6f9553:	8b 04 99             	mov    (%rcx,%rbx,4),%eax
  6f9556:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6f955b:	ff c0                	inc    %eax
  6f955d:	89 04 99             	mov    %eax,(%rcx,%rbx,4)
  6f9560:	88 94 24 c8 02 00 00 	mov    %dl,0x2c8(%rsp)
  6f9567:	84 d2                	test   %dl,%dl
  6f9569:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
  6f956e:	0f 84 d1 00 00 00    	je     6f9645 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2645>
  6f9574:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  6f957b:	00 
  6f957c:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  6f9581:	48 39 c8             	cmp    %rcx,%rax
  6f9584:	0f 86 0a 46 00 00    	jbe    6fdb94 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b94>
  6f958a:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  6f9591:	00 
  6f9592:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  6f9596:	48 8b 2c c8          	mov    (%rax,%rcx,8),%rbp
  6f959a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f959f:	48 8b 80 e8 01 00 00 	mov    0x1e8(%rax),%rax
  6f95a6:	48 85 c0             	test   %rax,%rax
  6f95a9:	0f 84 db 00 00 00    	je     6f968a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x268a>
  6f95af:	83 f8 01             	cmp    $0x1,%eax
  6f95b2:	0f 85 f7 00 00 00    	jne    6f96af <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x26af>
  6f95b8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f95bd:	48 8b 91 f8 01 00 00 	mov    0x1f8(%rcx),%rdx
  6f95c4:	b8 04 00 00 00       	mov    $0x4,%eax
  6f95c9:	48 85 d2             	test   %rdx,%rdx
  6f95cc:	0f 84 5a 01 00 00    	je     6f972c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x272c>
  6f95d2:	48 8b 89 f0 01 00 00 	mov    0x1f0(%rcx),%rcx
  6f95d9:	31 f6                	xor    %esi,%esi
  6f95db:	48 83 fa 01          	cmp    $0x1,%rdx
  6f95df:	74 24                	je     6f9605 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2605>
  6f95e1:	48 89 f7             	mov    %rsi,%rdi
  6f95e4:	49 89 d0             	mov    %rdx,%r8
  6f95e7:	49 d1 e8             	shr    $1,%r8
  6f95ea:	4c 01 c6             	add    %r8,%rsi
  6f95ed:	49 89 f1             	mov    %rsi,%r9
  6f95f0:	49 c1 e1 04          	shl    $0x4,%r9
  6f95f4:	4a 39 2c 09          	cmp    %rbp,(%rcx,%r9,1)
  6f95f8:	48 0f 47 f7          	cmova  %rdi,%rsi
  6f95fc:	4c 29 c2             	sub    %r8,%rdx
  6f95ff:	48 83 fa 01          	cmp    $0x1,%rdx
  6f9603:	77 dc                	ja     6f95e1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x25e1>
  6f9605:	48 89 f7             	mov    %rsi,%rdi
  6f9608:	48 c1 e7 04          	shl    $0x4,%rdi
  6f960c:	31 d2                	xor    %edx,%edx
  6f960e:	48 39 2c 39          	cmp    %rbp,(%rcx,%rdi,1)
  6f9612:	0f 96 c2             	setbe  %dl
  6f9615:	48 01 f2             	add    %rsi,%rdx
  6f9618:	0f 84 0c 01 00 00    	je     6f972a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x272a>
  6f961e:	48 c1 e2 04          	shl    $0x4,%rdx
  6f9622:	48 89 ee             	mov    %rbp,%rsi
  6f9625:	48 2b 74 11 f0       	sub    -0x10(%rcx,%rdx,1),%rsi
  6f962a:	8b 7c 11 fc          	mov    -0x4(%rcx,%rdx,1),%edi
  6f962e:	48 39 fe             	cmp    %rdi,%rsi
  6f9631:	0f 83 f3 00 00 00    	jae    6f972a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x272a>
  6f9637:	48 01 d1             	add    %rdx,%rcx
  6f963a:	8b 41 f8             	mov    -0x8(%rcx),%eax
  6f963d:	48 01 c6             	add    %rax,%rsi
  6f9640:	e9 c8 00 00 00       	jmp    6f970d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x270d>
  6f9645:	31 ff                	xor    %edi,%edi
  6f9647:	ff 15 d3 24 39 00    	call   *0x3924d3(%rip)        # a8bb20 <_DYNAMIC+0x638>
  6f964d:	48 8d bc 24 d8 07 00 	lea    0x7d8(%rsp),%rdi
  6f9654:	00 
  6f9655:	89 c6                	mov    %eax,%esi
  6f9657:	ff 15 73 25 39 00    	call   *0x392573(%rip)        # a8bbd0 <_DYNAMIC+0x6e8>
  6f965d:	31 c9                	xor    %ecx,%ecx
  6f965f:	80 bc 24 80 03 00 00 	cmpb   $0x0,0x380(%rsp)
  6f9666:	00 
  6f9667:	0f 85 d2 00 00 00    	jne    6f973f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x273f>
  6f966d:	31 f6                	xor    %esi,%esi
  6f966f:	48 8b bc 24 78 08 00 	mov    0x878(%rsp),%rdi
  6f9676:	00 
  6f9677:	48 85 ff             	test   %rdi,%rdi
  6f967a:	48 89 6c 24 68       	mov    %rbp,0x68(%rsp)
  6f967f:	0f 85 e9 00 00 00    	jne    6f976e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x276e>
  6f9685:	e9 cf 01 00 00       	jmp    6f9859 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2859>
  6f968a:	b8 04 00 00 00       	mov    $0x4,%eax
  6f968f:	48 89 ee             	mov    %rbp,%rsi
  6f9692:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f9697:	48 2b b1 f0 01 00 00 	sub    0x1f0(%rcx),%rsi
  6f969e:	0f 82 86 00 00 00    	jb     6f972a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x272a>
  6f96a4:	48 3b b1 f8 01 00 00 	cmp    0x1f8(%rcx),%rsi
  6f96ab:	73 7d                	jae    6f972a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x272a>
  6f96ad:	eb 5e                	jmp    6f970d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x270d>
  6f96af:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f96b4:	48 8b 91 f8 01 00 00 	mov    0x1f8(%rcx),%rdx
  6f96bb:	b8 04 00 00 00       	mov    $0x4,%eax
  6f96c0:	48 85 d2             	test   %rdx,%rdx
  6f96c3:	74 67                	je     6f972c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x272c>
  6f96c5:	48 8b 89 f0 01 00 00 	mov    0x1f0(%rcx),%rcx
  6f96cc:	48 83 fa 01          	cmp    $0x1,%rdx
  6f96d0:	75 07                	jne    6f96d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x26d9>
  6f96d2:	48 39 29             	cmp    %rbp,(%rcx)
  6f96d5:	74 33                	je     6f970a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x270a>
  6f96d7:	eb 51                	jmp    6f972a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x272a>
  6f96d9:	31 f6                	xor    %esi,%esi
  6f96db:	48 89 f7             	mov    %rsi,%rdi
  6f96de:	49 89 d0             	mov    %rdx,%r8
  6f96e1:	49 d1 e8             	shr    $1,%r8
  6f96e4:	4c 01 c6             	add    %r8,%rsi
  6f96e7:	4c 8d 0c 76          	lea    (%rsi,%rsi,2),%r9
  6f96eb:	4a 39 2c 89          	cmp    %rbp,(%rcx,%r9,4)
  6f96ef:	48 0f 47 f7          	cmova  %rdi,%rsi
  6f96f3:	4c 29 c2             	sub    %r8,%rdx
  6f96f6:	48 83 fa 01          	cmp    $0x1,%rdx
  6f96fa:	77 df                	ja     6f96db <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x26db>
  6f96fc:	48 8d 14 76          	lea    (%rsi,%rsi,2),%rdx
  6f9700:	48 39 2c 91          	cmp    %rbp,(%rcx,%rdx,4)
  6f9704:	75 24                	jne    6f972a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x272a>
  6f9706:	48 8d 0c 91          	lea    (%rcx,%rdx,4),%rcx
  6f970a:	8b 71 08             	mov    0x8(%rcx),%esi
  6f970d:	bf 01 00 00 00       	mov    $0x1,%edi
  6f9712:	ff 15 08 24 39 00    	call   *0x392408(%rip)        # a8bb20 <_DYNAMIC+0x638>
  6f9718:	48 8d bc 24 d8 07 00 	lea    0x7d8(%rsp),%rdi
  6f971f:	00 
  6f9720:	89 c6                	mov    %eax,%esi
  6f9722:	ff 15 a8 24 39 00    	call   *0x3924a8(%rip)        # a8bbd0 <_DYNAMIC+0x6e8>
  6f9728:	eb 02                	jmp    6f972c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x272c>
  6f972a:	31 d2                	xor    %edx,%edx
  6f972c:	b9 01 00 00 00       	mov    $0x1,%ecx
  6f9731:	80 bc 24 80 03 00 00 	cmpb   $0x0,0x380(%rsp)
  6f9738:	00 
  6f9739:	0f 84 2e ff ff ff    	je     6f966d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x266d>
  6f973f:	4c 39 eb             	cmp    %r13,%rbx
  6f9742:	0f 87 63 44 00 00    	ja     6fdbab <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6bab>
  6f9748:	48 8b b4 24 d0 02 00 	mov    0x2d0(%rsp),%rsi
  6f974f:	00 
  6f9750:	48 3b 14 de          	cmp    (%rsi,%rbx,8),%rdx
  6f9754:	40 0f 94 c6          	sete   %sil
  6f9758:	48 8b bc 24 78 08 00 	mov    0x878(%rsp),%rdi
  6f975f:	00 
  6f9760:	48 85 ff             	test   %rdi,%rdi
  6f9763:	48 89 6c 24 68       	mov    %rbp,0x68(%rsp)
  6f9768:	0f 84 eb 00 00 00    	je     6f9859 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2859>
  6f976e:	4c 8b 84 24 80 08 00 	mov    0x880(%rsp),%r8
  6f9775:	00 
  6f9776:	44 0f b7 97 12 01 00 	movzwl 0x112(%rdi),%r10d
  6f977d:	00 
  6f977e:	44 89 d3             	mov    %r10d,%ebx
  6f9781:	c1 e3 04             	shl    $0x4,%ebx
  6f9784:	49 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%r9
  6f978b:	45 31 db             	xor    %r11d,%r11d
  6f978e:	66 90                	xchg   %ax,%ax
  6f9790:	4c 39 db             	cmp    %r11,%rbx
  6f9793:	74 28                	je     6f97bd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x27bd>
  6f9795:	4e 3b b4 cf c0 00 00 	cmp    0xc0(%rdi,%r9,8),%r14
  6f979c:	00 
  6f979d:	40 0f 97 c5          	seta   %bpl
  6f97a1:	40 80 dd 00          	sbb    $0x0,%bpl
  6f97a5:	49 83 c3 10          	add    $0x10,%r11
  6f97a9:	49 ff c1             	inc    %r9
  6f97ac:	40 80 fd 01          	cmp    $0x1,%bpl
  6f97b0:	74 de                	je     6f9790 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2790>
  6f97b2:	44 0f b6 d5          	movzbl %bpl,%r10d
  6f97b6:	45 85 d2             	test   %r10d,%r10d
  6f97b9:	75 05                	jne    6f97c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x27c0>
  6f97bb:	eb 1c                	jmp    6f97d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x27d9>
  6f97bd:	4d 89 d1             	mov    %r10,%r9
  6f97c0:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
  6f97c5:	49 83 e8 01          	sub    $0x1,%r8
  6f97c9:	0f 82 8a 00 00 00    	jb     6f9859 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2859>
  6f97cf:	4a 8b bc cf 18 01 00 	mov    0x118(%rdi,%r9,8),%rdi
  6f97d6:	00 
  6f97d7:	eb 9d                	jmp    6f9776 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2776>
  6f97d9:	80 bc 24 80 03 00 00 	cmpb   $0x0,0x380(%rsp)
  6f97e0:	00 
  6f97e1:	4c 8b 44 24 68       	mov    0x68(%rsp),%r8
  6f97e6:	0f 84 88 04 00 00    	je     6f9c74 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c74>
  6f97ec:	4a 8b 44 1f f8       	mov    -0x8(%rdi,%r11,1),%rax
  6f97f1:	48 8b 40 08          	mov    0x8(%rax),%rax
  6f97f5:	8b 94 24 20 01 00 00 	mov    0x120(%rsp),%edx
  6f97fc:	80 fa 02             	cmp    $0x2,%dl
  6f97ff:	be 00 00 00 00       	mov    $0x0,%esi
  6f9804:	0f 42 d6             	cmovb  %esi,%edx
  6f9807:	48 89 8c 24 90 03 00 	mov    %rcx,0x390(%rsp)
  6f980e:	00 
  6f980f:	4c 89 84 24 98 03 00 	mov    %r8,0x398(%rsp)
  6f9816:	00 
  6f9817:	48 89 84 24 a0 03 00 	mov    %rax,0x3a0(%rsp)
  6f981e:	00 
  6f981f:	88 94 24 a8 03 00 00 	mov    %dl,0x3a8(%rsp)
  6f9826:	48 8b b4 24 80 06 00 	mov    0x680(%rsp),%rsi
  6f982d:	00 
  6f982e:	48 85 f6             	test   %rsi,%rsi
  6f9831:	0f 84 3d 04 00 00    	je     6f9c74 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c74>
  6f9837:	48 8b 94 24 88 06 00 	mov    0x688(%rsp),%rdx
  6f983e:	00 
  6f983f:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6f9846:	00 
  6f9847:	48 8d 8c 24 90 03 00 	lea    0x390(%rsp),%rcx
  6f984e:	00 
  6f984f:	e8 6c 60 fe ff       	call   6df8c0 <<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Mut, (core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize, alloc::collections::btree::node::marker::LeafOrInternal>>::search_tree::<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind)>>
  6f9854:	e9 e7 00 00 00       	jmp    6f9940 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2940>
  6f9859:	48 8b bc 24 60 08 00 	mov    0x860(%rsp),%rdi
  6f9860:	00 
  6f9861:	48 85 ff             	test   %rdi,%rdi
  6f9864:	0f 84 75 01 00 00    	je     6f99df <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x29df>
  6f986a:	4c 8b 84 24 68 08 00 	mov    0x868(%rsp),%r8
  6f9871:	00 
  6f9872:	44 0f b7 97 ba 00 00 	movzwl 0xba(%rdi),%r10d
  6f9879:	00 
  6f987a:	45 89 d3             	mov    %r10d,%r11d
  6f987d:	41 c1 e3 03          	shl    $0x3,%r11d
  6f9881:	49 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%r9
  6f9888:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6f988f:	00 
  6f9890:	4d 85 db             	test   %r11,%r11
  6f9893:	74 22                	je     6f98b7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x28b7>
  6f9895:	4e 3b 74 cf 10       	cmp    0x10(%rdi,%r9,8),%r14
  6f989a:	0f 97 c3             	seta   %bl
  6f989d:	80 db 00             	sbb    $0x0,%bl
  6f98a0:	49 ff c1             	inc    %r9
  6f98a3:	49 83 c3 f8          	add    $0xfffffffffffffff8,%r11
  6f98a7:	80 fb 01             	cmp    $0x1,%bl
  6f98aa:	74 e4                	je     6f9890 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2890>
  6f98ac:	44 0f b6 d3          	movzbl %bl,%r10d
  6f98b0:	45 85 d2             	test   %r10d,%r10d
  6f98b3:	75 05                	jne    6f98ba <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x28ba>
  6f98b5:	eb 17                	jmp    6f98ce <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x28ce>
  6f98b7:	4d 89 d1             	mov    %r10,%r9
  6f98ba:	49 83 e8 01          	sub    $0x1,%r8
  6f98be:	0f 82 1b 01 00 00    	jb     6f99df <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x29df>
  6f98c4:	4a 8b bc cf c0 00 00 	mov    0xc0(%rdi,%r9,8),%rdi
  6f98cb:	00 
  6f98cc:	eb a4                	jmp    6f9872 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2872>
  6f98ce:	80 bc 24 80 03 00 00 	cmpb   $0x0,0x380(%rsp)
  6f98d5:	00 
  6f98d6:	0f 84 98 03 00 00    	je     6f9c74 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c74>
  6f98dc:	4a 8b 44 cf 60       	mov    0x60(%rdi,%r9,8),%rax
  6f98e1:	8b 94 24 20 01 00 00 	mov    0x120(%rsp),%edx
  6f98e8:	80 fa 02             	cmp    $0x2,%dl
  6f98eb:	be 00 00 00 00       	mov    $0x0,%esi
  6f98f0:	0f 42 d6             	cmovb  %esi,%edx
  6f98f3:	48 89 8c 24 90 03 00 	mov    %rcx,0x390(%rsp)
  6f98fa:	00 
  6f98fb:	48 89 ac 24 98 03 00 	mov    %rbp,0x398(%rsp)
  6f9902:	00 
  6f9903:	48 89 84 24 a0 03 00 	mov    %rax,0x3a0(%rsp)
  6f990a:	00 
  6f990b:	88 94 24 a8 03 00 00 	mov    %dl,0x3a8(%rsp)
  6f9912:	48 8b b4 24 98 06 00 	mov    0x698(%rsp),%rsi
  6f9919:	00 
  6f991a:	48 85 f6             	test   %rsi,%rsi
  6f991d:	0f 84 51 03 00 00    	je     6f9c74 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c74>
  6f9923:	48 8b 94 24 a0 06 00 	mov    0x6a0(%rsp),%rdx
  6f992a:	00 
  6f992b:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6f9932:	00 
  6f9933:	48 8d 8c 24 90 03 00 	lea    0x390(%rsp),%rcx
  6f993a:	00 
  6f993b:	e8 80 5f fe ff       	call   6df8c0 <<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Mut, (core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize, alloc::collections::btree::node::marker::LeafOrInternal>>::search_tree::<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind)>>
  6f9940:	83 bc 24 a0 01 00 00 	cmpl   $0x1,0x1a0(%rsp)
  6f9947:	01 
  6f9948:	0f 84 26 03 00 00    	je     6f9c74 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c74>
  6f994e:	48 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%rax
  6f9955:	00 
  6f9956:	48 8b 8c 24 b8 01 00 	mov    0x1b8(%rsp),%rcx
  6f995d:	00 
  6f995e:	4c 8b bc c8 68 01 00 	mov    0x168(%rax,%rcx,8),%r15
  6f9965:	00 
  6f9966:	4d 39 e7             	cmp    %r12,%r15
  6f9969:	0f 83 de 42 00 00    	jae    6fdc4d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c4d>
  6f996f:	4b 8d 04 7f          	lea    (%r15,%r15,2),%rax
  6f9973:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  6f9978:	48 8b 1c c1          	mov    (%rcx,%rax,8),%rbx
  6f997c:	4c 8b 64 c1 08       	mov    0x8(%rcx,%rax,8),%r12
  6f9981:	4c 8b 6c c1 10       	mov    0x10(%rcx,%rax,8),%r13
  6f9986:	48 c7 04 c1 00 00 00 	movq   $0x0,(%rcx,%rax,8)
  6f998d:	00 
  6f998e:	48 85 db             	test   %rbx,%rbx
  6f9991:	0f 84 dd 02 00 00    	je     6f9c74 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c74>
  6f9997:	4c 89 e0             	mov    %r12,%rax
  6f999a:	48 c1 e8 22          	shr    $0x22,%rax
  6f999e:	0f 84 cb 00 00 00    	je     6f9a6f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2a6f>
  6f99a4:	48 ff c8             	dec    %rax
  6f99a7:	48 3b 84 24 00 04 00 	cmp    0x400(%rsp),%rax
  6f99ae:	00 
  6f99af:	0f 83 73 43 00 00    	jae    6fdd28 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d28>
  6f99b5:	48 c1 e0 04          	shl    $0x4,%rax
  6f99b9:	48 8b 8c 24 10 05 00 	mov    0x510(%rsp),%rcx
  6f99c0:	00 
  6f99c1:	48 8b 2c 01          	mov    (%rcx,%rax,1),%rbp
  6f99c5:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
  6f99ca:	48 89 94 24 48 01 00 	mov    %rdx,0x148(%rsp)
  6f99d1:	00 
  6f99d2:	48 c7 04 01 00 00 00 	movq   $0x0,(%rcx,%rax,1)
  6f99d9:	00 
  6f99da:	e9 92 00 00 00       	jmp    6f9a71 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2a71>
  6f99df:	40 84 f6             	test   %sil,%sil
  6f99e2:	0f 84 8c 02 00 00    	je     6f9c74 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c74>
  6f99e8:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  6f99ed:	48 39 ca             	cmp    %rcx,%rdx
  6f99f0:	0f 86 7e 02 00 00    	jbe    6f9c74 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c74>
  6f99f6:	44 8b 3c 88          	mov    (%rax,%rcx,4),%r15d
  6f99fa:	4d 39 fc             	cmp    %r15,%r12
  6f99fd:	0f 86 44 43 00 00    	jbe    6fdd47 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d47>
  6f9a03:	4b 8d 04 7f          	lea    (%r15,%r15,2),%rax
  6f9a07:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  6f9a0c:	48 83 3c c1 00       	cmpq   $0x0,(%rcx,%rax,8)
  6f9a11:	0f 84 5d 02 00 00    	je     6f9c74 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c74>
  6f9a17:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
  6f9a1b:	8b 48 10             	mov    0x10(%rax),%ecx
  6f9a1e:	83 e1 0f             	and    $0xf,%ecx
  6f9a21:	83 f9 09             	cmp    $0x9,%ecx
  6f9a24:	0f 87 4a 40 00 00    	ja     6fda74 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a74>
  6f9a2a:	0f b6 84 24 20 01 00 	movzbl 0x120(%rsp),%eax
  6f9a31:	00 
  6f9a32:	48 8d 15 3b e3 95 ff 	lea    -0x6a1cc5(%rip),%rdx        # 57d74 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0xcc>
  6f9a39:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
  6f9a3d:	48 01 d1             	add    %rdx,%rcx
  6f9a40:	ff e1                	jmp    *%rcx
  6f9a42:	83 f8 0a             	cmp    $0xa,%eax
  6f9a45:	0f 87 29 02 00 00    	ja     6f9c74 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c74>
  6f9a4b:	b9 03 04 00 00       	mov    $0x403,%ecx
  6f9a50:	0f a3 c1             	bt     %eax,%ecx
  6f9a53:	0f 83 1b 02 00 00    	jae    6f9c74 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c74>
  6f9a59:	3c 02                	cmp    $0x2,%al
  6f9a5b:	0f 92 c1             	setb   %cl
  6f9a5e:	f6 d0                	not    %al
  6f9a60:	08 c8                	or     %cl,%al
  6f9a62:	a8 01                	test   $0x1,%al
  6f9a64:	0f 85 fc fe ff ff    	jne    6f9966 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2966>
  6f9a6a:	e9 05 02 00 00       	jmp    6f9c74 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c74>
  6f9a6f:	31 ed                	xor    %ebp,%ebp
  6f9a71:	48 8b b4 24 70 02 00 	mov    0x270(%rsp),%rsi
  6f9a78:	00 
  6f9a79:	49 39 f6             	cmp    %rsi,%r14
  6f9a7c:	0f 83 59 42 00 00    	jae    6fdcdb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6f9a82:	4c 89 e9             	mov    %r13,%rcx
  6f9a85:	48 c1 e9 20          	shr    $0x20,%rcx
  6f9a89:	48 8b 84 24 68 02 00 	mov    0x268(%rsp),%rax
  6f9a90:	00 
  6f9a91:	48 89 8c 24 78 01 00 	mov    %rcx,0x178(%rsp)
  6f9a98:	00 
  6f9a99:	42 39 0c b0          	cmp    %ecx,(%rax,%r14,4)
  6f9a9d:	75 3e                	jne    6f9add <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2add>
  6f9a9f:	48 8b 84 24 b0 06 00 	mov    0x6b0(%rsp),%rax
  6f9aa6:	00 
  6f9aa7:	48 8d 15 ee e2 95 ff 	lea    -0x6a1d12(%rip),%rdx        # 57d9c <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0xf4>
  6f9aae:	48 63 0c 82          	movslq (%rdx,%rax,4),%rcx
  6f9ab2:	48 01 d1             	add    %rdx,%rcx
  6f9ab5:	48 8d 05 64 e4 95 ff 	lea    -0x6a1b9c(%rip),%rax        # 57f20 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x278>
  6f9abc:	ff e1                	jmp    *%rcx
  6f9abe:	48 8b b4 24 c8 06 00 	mov    0x6c8(%rsp),%rsi
  6f9ac5:	00 
  6f9ac6:	49 39 f7             	cmp    %rsi,%r15
  6f9ac9:	0f 83 cf 42 00 00    	jae    6fdd9e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d9e>
  6f9acf:	49 6b c7 58          	imul   $0x58,%r15,%rax
  6f9ad3:	48 03 84 24 c0 06 00 	add    0x6c0(%rsp),%rax
  6f9ada:	00 
  6f9adb:	eb 78                	jmp    6f9b55 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2b55>
  6f9add:	48 85 ed             	test   %rbp,%rbp
  6f9ae0:	0f 84 8e 01 00 00    	je     6f9c74 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c74>
  6f9ae6:	48 8b 9c 24 48 01 00 	mov    0x148(%rsp),%rbx
  6f9aed:	00 
  6f9aee:	48 8b 03             	mov    (%rbx),%rax
  6f9af1:	48 85 c0             	test   %rax,%rax
  6f9af4:	74 05                	je     6f9afb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2afb>
  6f9af6:	48 89 ef             	mov    %rbp,%rdi
  6f9af9:	ff d0                	call   *%rax
  6f9afb:	48 8b 73 08          	mov    0x8(%rbx),%rsi
  6f9aff:	48 85 f6             	test   %rsi,%rsi
  6f9b02:	0f 84 6c 01 00 00    	je     6f9c74 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c74>
  6f9b08:	48 8b 53 10          	mov    0x10(%rbx),%rdx
  6f9b0c:	48 89 ef             	mov    %rbp,%rdi
  6f9b0f:	ff 15 23 1c 39 00    	call   *0x391c23(%rip)        # a8b738 <_DYNAMIC+0x250>
  6f9b15:	e9 5a 01 00 00       	jmp    6f9c74 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c74>
  6f9b1a:	48 8b b4 24 d0 06 00 	mov    0x6d0(%rsp),%rsi
  6f9b21:	00 
  6f9b22:	49 39 f7             	cmp    %rsi,%r15
  6f9b25:	0f 83 8f 42 00 00    	jae    6fddba <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6dba>
  6f9b2b:	48 8b b4 24 c0 06 00 	mov    0x6c0(%rsp),%rsi
  6f9b32:	00 
  6f9b33:	48 8b 84 24 c8 06 00 	mov    0x6c8(%rsp),%rax
  6f9b3a:	00 
  6f9b3b:	42 0f b6 04 38       	movzbl (%rax,%r15,1),%eax
  6f9b40:	48 39 c6             	cmp    %rax,%rsi
  6f9b43:	0f 86 8d 42 00 00    	jbe    6fddd6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6dd6>
  6f9b49:	48 6b c0 58          	imul   $0x58,%rax,%rax
  6f9b4d:	48 03 84 24 b8 06 00 	add    0x6b8(%rsp),%rax
  6f9b54:	00 
  6f9b55:	48 8b 48 50          	mov    0x50(%rax),%rcx
  6f9b59:	48 89 8c 24 e0 05 00 	mov    %rcx,0x5e0(%rsp)
  6f9b60:	00 
  6f9b61:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  6f9b65:	0f 29 84 24 d0 05 00 	movaps %xmm0,0x5d0(%rsp)
  6f9b6c:	00 
  6f9b6d:	f3 0f 6f 00          	movdqu (%rax),%xmm0
  6f9b71:	f3 0f 6f 48 10       	movdqu 0x10(%rax),%xmm1
  6f9b76:	f3 0f 6f 50 20       	movdqu 0x20(%rax),%xmm2
  6f9b7b:	0f 10 58 30          	movups 0x30(%rax),%xmm3
  6f9b7f:	0f 29 9c 24 c0 05 00 	movaps %xmm3,0x5c0(%rsp)
  6f9b86:	00 
  6f9b87:	66 0f 7f 94 24 b0 05 	movdqa %xmm2,0x5b0(%rsp)
  6f9b8e:	00 00 
  6f9b90:	66 0f 7f 8c 24 a0 05 	movdqa %xmm1,0x5a0(%rsp)
  6f9b97:	00 00 
  6f9b99:	66 0f 7f 84 24 90 05 	movdqa %xmm0,0x590(%rsp)
  6f9ba0:	00 00 
  6f9ba2:	eb 19                	jmp    6f9bbd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2bbd>
  6f9ba4:	48 8b b4 24 b8 06 00 	mov    0x6b8(%rsp),%rsi
  6f9bab:	00 
  6f9bac:	48 8d bc 24 90 05 00 	lea    0x590(%rsp),%rdi
  6f9bb3:	00 
  6f9bb4:	4c 89 fa             	mov    %r15,%rdx
  6f9bb7:	ff 15 73 1c 39 00    	call   *0x391c73(%rip)        # a8b830 <_DYNAMIC+0x348>
  6f9bbd:	48 8d bc 24 90 03 00 	lea    0x390(%rsp),%rdi
  6f9bc4:	00 
  6f9bc5:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
  6f9bcc:	00 
  6f9bcd:	4c 89 fa             	mov    %r15,%rdx
  6f9bd0:	ff 15 02 20 39 00    	call   *0x392002(%rip)        # a8bbd8 <_DYNAMIC+0x6f0>
  6f9bd6:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6f9bdd:	00 
  6f9bde:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
  6f9be5:	00 
  6f9be6:	4c 89 f2             	mov    %r14,%rdx
  6f9be9:	ff 15 f1 1f 39 00    	call   *0x391ff1(%rip)        # a8bbe0 <_DYNAMIC+0x6f8>
  6f9bef:	48 8b 84 24 a0 01 00 	mov    0x1a0(%rsp),%rax
  6f9bf6:	00 
  6f9bf7:	48 3b 84 24 90 03 00 	cmp    0x390(%rsp),%rax
  6f9bfe:	00 
  6f9bff:	75 12                	jne    6f9c13 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c13>
  6f9c01:	48 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%rax
  6f9c08:	00 
  6f9c09:	48 3b 84 24 98 03 00 	cmp    0x398(%rsp),%rax
  6f9c10:	00 
  6f9c11:	74 0c                	je     6f9c1f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c1f>
  6f9c13:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f9c18:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6f9c1f:	48 b8 ff ff ff ff 03 	movabs $0x3ffffffff,%rax
  6f9c26:	00 00 00 
  6f9c29:	49 39 c4             	cmp    %rax,%r12
  6f9c2c:	0f 97 c0             	seta   %al
  6f9c2f:	48 89 84 24 10 04 00 	mov    %rax,0x410(%rsp)
  6f9c36:	00 
  6f9c37:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
  6f9c3e:	00 
  6f9c3f:	e9 5f 01 00 00       	jmp    6f9da3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2da3>
  6f9c44:	b1 04                	mov    $0x4,%cl
  6f9c46:	eb 1a                	jmp    6f9c62 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c62>
  6f9c48:	b1 02                	mov    $0x2,%cl
  6f9c4a:	eb 16                	jmp    6f9c62 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c62>
  6f9c4c:	b1 03                	mov    $0x3,%cl
  6f9c4e:	eb 12                	jmp    6f9c62 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c62>
  6f9c50:	b1 07                	mov    $0x7,%cl
  6f9c52:	eb 0e                	jmp    6f9c62 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c62>
  6f9c54:	31 c9                	xor    %ecx,%ecx
  6f9c56:	eb 0a                	jmp    6f9c62 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c62>
  6f9c58:	b1 01                	mov    $0x1,%cl
  6f9c5a:	eb 06                	jmp    6f9c62 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c62>
  6f9c5c:	b1 05                	mov    $0x5,%cl
  6f9c5e:	eb 02                	jmp    6f9c62 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c62>
  6f9c60:	b1 06                	mov    $0x6,%cl
  6f9c62:	2c 02                	sub    $0x2,%al
  6f9c64:	0f 93 c2             	setae  %dl
  6f9c67:	38 c8                	cmp    %cl,%al
  6f9c69:	0f 94 c0             	sete   %al
  6f9c6c:	84 c2                	test   %al,%dl
  6f9c6e:	0f 85 f2 fc ff ff    	jne    6f9966 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2966>
  6f9c74:	48 8d 8c 24 98 00 00 	lea    0x98(%rsp),%rcx
  6f9c7b:	00 
  6f9c7c:	48 8b 41 68          	mov    0x68(%rcx),%rax
  6f9c80:	48 89 84 24 e0 05 00 	mov    %rax,0x5e0(%rsp)
  6f9c87:	00 
  6f9c88:	0f 10 41 58          	movups 0x58(%rcx),%xmm0
  6f9c8c:	0f 29 84 24 d0 05 00 	movaps %xmm0,0x5d0(%rsp)
  6f9c93:	00 
  6f9c94:	f3 0f 6f 41 18       	movdqu 0x18(%rcx),%xmm0
  6f9c99:	f3 0f 6f 49 28       	movdqu 0x28(%rcx),%xmm1
  6f9c9e:	f3 0f 6f 51 38       	movdqu 0x38(%rcx),%xmm2
  6f9ca3:	0f 10 59 48          	movups 0x48(%rcx),%xmm3
  6f9ca7:	0f 29 9c 24 c0 05 00 	movaps %xmm3,0x5c0(%rsp)
  6f9cae:	00 
  6f9caf:	66 0f 7f 94 24 b0 05 	movdqa %xmm2,0x5b0(%rsp)
  6f9cb6:	00 00 
  6f9cb8:	66 0f 7f 8c 24 a0 05 	movdqa %xmm1,0x5a0(%rsp)
  6f9cbf:	00 00 
  6f9cc1:	66 0f 7f 84 24 90 05 	movdqa %xmm0,0x590(%rsp)
  6f9cc8:	00 00 
  6f9cca:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f9ccf:	48 8b 99 10 06 00 00 	mov    0x610(%rcx),%rbx
  6f9cd6:	48 8d 43 01          	lea    0x1(%rbx),%rax
  6f9cda:	48 89 81 10 06 00 00 	mov    %rax,0x610(%rcx)
  6f9ce1:	31 ed                	xor    %ebp,%ebp
  6f9ce3:	48 8b bc 24 10 02 00 	mov    0x210(%rsp),%rdi
  6f9cea:	00 
  6f9ceb:	48 89 de             	mov    %rbx,%rsi
  6f9cee:	e8 1d f9 00 00       	call   709610 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6f9cf3:	48 85 db             	test   %rbx,%rbx
  6f9cf6:	0f 84 83 3b 00 00    	je     6fd87f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x687f>
  6f9cfc:	0f b6 84 24 20 01 00 	movzbl 0x120(%rsp),%eax
  6f9d03:	00 
  6f9d04:	8d 48 fe             	lea    -0x2(%rax),%ecx
  6f9d07:	83 f8 02             	cmp    $0x2,%eax
  6f9d0a:	0f b6 c9             	movzbl %cl,%ecx
  6f9d0d:	ba 08 00 00 00       	mov    $0x8,%edx
  6f9d12:	0f 42 ca             	cmovb  %edx,%ecx
  6f9d15:	44 0f b6 e9          	movzbl %cl,%r13d
  6f9d19:	48 8d 15 8c e0 95 ff 	lea    -0x6a1f74(%rip),%rdx        # 57dac <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x104>
  6f9d20:	4a 63 0c aa          	movslq (%rdx,%r13,4),%rcx
  6f9d24:	48 01 d1             	add    %rdx,%rcx
  6f9d27:	ff e1                	jmp    *%rcx
  6f9d29:	41 bd 01 00 00 00    	mov    $0x1,%r13d
  6f9d2f:	eb 39                	jmp    6f9d6a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d6a>
  6f9d31:	41 bd 04 00 00 00    	mov    $0x4,%r13d
  6f9d37:	eb 31                	jmp    6f9d6a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d6a>
  6f9d39:	41 bd 02 00 00 00    	mov    $0x2,%r13d
  6f9d3f:	eb 29                	jmp    6f9d6a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d6a>
  6f9d41:	41 bd 03 00 00 00    	mov    $0x3,%r13d
  6f9d47:	eb 21                	jmp    6f9d6a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d6a>
  6f9d49:	41 bd 07 00 00 00    	mov    $0x7,%r13d
  6f9d4f:	eb 19                	jmp    6f9d6a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d6a>
  6f9d51:	41 bd 05 00 00 00    	mov    $0x5,%r13d
  6f9d57:	eb 11                	jmp    6f9d6a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d6a>
  6f9d59:	41 bd 06 00 00 00    	mov    $0x6,%r13d
  6f9d5f:	eb 09                	jmp    6f9d6a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d6a>
  6f9d61:	83 e0 01             	and    $0x1,%eax
  6f9d64:	83 c8 08             	or     $0x8,%eax
  6f9d67:	41 89 c5             	mov    %eax,%r13d
  6f9d6a:	48 8b b4 24 70 02 00 	mov    0x270(%rsp),%rsi
  6f9d71:	00 
  6f9d72:	49 39 f6             	cmp    %rsi,%r14
  6f9d75:	0f 83 55 3d 00 00    	jae    6fdad0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6ad0>
  6f9d7b:	48 8b 84 24 68 02 00 	mov    0x268(%rsp),%rax
  6f9d82:	00 
  6f9d83:	42 8b 04 b0          	mov    (%rax,%r14,4),%eax
  6f9d87:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
  6f9d8e:	00 
  6f9d8f:	b0 01                	mov    $0x1,%al
  6f9d91:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6f9d95:	31 ed                	xor    %ebp,%ebp
  6f9d97:	48 c7 84 24 10 04 00 	movq   $0x0,0x410(%rsp)
  6f9d9e:	00 00 00 00 00 
  6f9da3:	48 89 6c 24 58       	mov    %rbp,0x58(%rsp)
  6f9da8:	45 89 ef             	mov    %r13d,%r15d
  6f9dab:	41 83 e7 0f          	and    $0xf,%r15d
  6f9daf:	41 83 ff 09          	cmp    $0x9,%r15d
  6f9db3:	0f 87 67 3b 00 00    	ja     6fd920 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6920>
  6f9db9:	41 83 ff 06          	cmp    $0x6,%r15d
  6f9dbd:	74 7e                	je     6f9e3d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2e3d>
  6f9dbf:	44 89 e8             	mov    %r13d,%eax
  6f9dc2:	c1 e8 04             	shr    $0x4,%eax
  6f9dc5:	74 76                	je     6f9e3d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2e3d>
  6f9dc7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f9dcc:	48 8b b1 b8 02 00 00 	mov    0x2b8(%rcx),%rsi
  6f9dd3:	ff c8                	dec    %eax
  6f9dd5:	48 39 c6             	cmp    %rax,%rsi
  6f9dd8:	0f 86 8e 3d 00 00    	jbe    6fdb6c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b6c>
  6f9dde:	48 8b 89 b0 02 00 00 	mov    0x2b0(%rcx),%rcx
  6f9de5:	48 8d 04 80          	lea    (%rax,%rax,4),%rax
  6f9de9:	48 c1 e0 04          	shl    $0x4,%rax
  6f9ded:	0f 10 44 01 40       	movups 0x40(%rcx,%rax,1),%xmm0
  6f9df2:	0f 29 84 24 a0 04 00 	movaps %xmm0,0x4a0(%rsp)
  6f9df9:	00 
  6f9dfa:	f3 0f 6f 04 01       	movdqu (%rcx,%rax,1),%xmm0
  6f9dff:	f3 0f 6f 4c 01 10    	movdqu 0x10(%rcx,%rax,1),%xmm1
  6f9e05:	f3 0f 6f 54 01 20    	movdqu 0x20(%rcx,%rax,1),%xmm2
  6f9e0b:	0f 10 5c 01 30       	movups 0x30(%rcx,%rax,1),%xmm3
  6f9e10:	0f 29 9c 24 90 04 00 	movaps %xmm3,0x490(%rsp)
  6f9e17:	00 
  6f9e18:	66 0f 7f 94 24 80 04 	movdqa %xmm2,0x480(%rsp)
  6f9e1f:	00 00 
  6f9e21:	66 0f 7f 8c 24 70 04 	movdqa %xmm1,0x470(%rsp)
  6f9e28:	00 00 
  6f9e2a:	66 0f 7f 84 24 60 04 	movdqa %xmm0,0x460(%rsp)
  6f9e31:	00 00 
  6f9e33:	48 c7 04 01 fe ff ff 	movq   $0xfffffffffffffffe,(%rcx,%rax,1)
  6f9e3a:	ff 
  6f9e3b:	eb 0c                	jmp    6f9e49 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2e49>
  6f9e3d:	48 c7 84 24 60 04 00 	movq   $0xfffffffffffffffe,0x460(%rsp)
  6f9e44:	00 fe ff ff ff 
  6f9e49:	44 89 ef             	mov    %r13d,%edi
  6f9e4c:	ff 15 d6 19 39 00    	call   *0x3919d6(%rip)        # a8b828 <_DYNAMIC+0x340>
  6f9e52:	b1 02                	mov    $0x2,%cl
  6f9e54:	80 fa 02             	cmp    $0x2,%dl
  6f9e57:	74 35                	je     6f9e8e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2e8e>
  6f9e59:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f9e5e:	48 8b 89 f0 05 00 00 	mov    0x5f0(%rcx),%rcx
  6f9e65:	48 85 c9             	test   %rcx,%rcx
  6f9e68:	0f 84 38 3a 00 00    	je     6fd8a6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x68a6>
  6f9e6e:	89 c7                	mov    %eax,%edi
  6f9e70:	48 8b 71 10          	mov    0x10(%rcx),%rsi
  6f9e74:	48 39 fe             	cmp    %rdi,%rsi
  6f9e77:	0f 86 4a 3d 00 00    	jbe    6fdbc7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6bc7>
  6f9e7d:	48 8b 41 08          	mov    0x8(%rcx),%rax
  6f9e81:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
  6f9e85:	48 8b 78 28          	mov    0x28(%rax),%rdi
  6f9e89:	80 e2 01             	and    $0x1,%dl
  6f9e8c:	89 d1                	mov    %edx,%ecx
  6f9e8e:	48 8b 84 24 c0 07 00 	mov    0x7c0(%rsp),%rax
  6f9e95:	00 
  6f9e96:	48 85 c0             	test   %rax,%rax
  6f9e99:	0f 84 c0 00 00 00    	je     6f9f5f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f5f>
  6f9e9f:	48 8b 94 24 c8 07 00 	mov    0x7c8(%rsp),%rdx
  6f9ea6:	00 
  6f9ea7:	0f b7 b0 ba 00 00 00 	movzwl 0xba(%rax),%esi
  6f9eae:	41 89 f1             	mov    %esi,%r9d
  6f9eb1:	41 c1 e1 03          	shl    $0x3,%r9d
  6f9eb5:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
  6f9ebc:	0f 1f 40 00          	nopl   0x0(%rax)
  6f9ec0:	4d 85 c9             	test   %r9,%r9
  6f9ec3:	74 24                	je     6f9ee9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2ee9>
  6f9ec5:	4e 3b 74 c0 10       	cmp    0x10(%rax,%r8,8),%r14
  6f9eca:	41 0f 97 c2          	seta   %r10b
  6f9ece:	41 80 da 00          	sbb    $0x0,%r10b
  6f9ed2:	49 ff c0             	inc    %r8
  6f9ed5:	49 83 c1 f8          	add    $0xfffffffffffffff8,%r9
  6f9ed9:	41 80 fa 01          	cmp    $0x1,%r10b
  6f9edd:	74 e1                	je     6f9ec0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2ec0>
  6f9edf:	41 0f b6 f2          	movzbl %r10b,%esi
  6f9ee3:	85 f6                	test   %esi,%esi
  6f9ee5:	75 05                	jne    6f9eec <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2eec>
  6f9ee7:	eb 13                	jmp    6f9efc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2efc>
  6f9ee9:	49 89 f0             	mov    %rsi,%r8
  6f9eec:	48 83 ea 01          	sub    $0x1,%rdx
  6f9ef0:	72 6d                	jb     6f9f5f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f5f>
  6f9ef2:	4a 8b 84 c0 c0 00 00 	mov    0xc0(%rax,%r8,8),%rax
  6f9ef9:	00 
  6f9efa:	eb ab                	jmp    6f9ea7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2ea7>
  6f9efc:	46 8b 4c c0 60       	mov    0x60(%rax,%r8,8),%r9d
  6f9f01:	48 8b b4 24 c0 04 00 	mov    0x4c0(%rsp),%rsi
  6f9f08:	00 
  6f9f09:	4c 89 8c 24 98 01 00 	mov    %r9,0x198(%rsp)
  6f9f10:	00 
  6f9f11:	4c 39 ce             	cmp    %r9,%rsi
  6f9f14:	0f 86 38 3c 00 00    	jbe    6fdb52 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b52>
  6f9f1a:	42 0f b6 44 c0 64    	movzbl 0x64(%rax,%r8,8),%eax
  6f9f20:	88 84 24 00 02 00 00 	mov    %al,0x200(%rsp)
  6f9f27:	c7 84 24 c0 02 00 00 	movl   $0x0,0x2c0(%rsp)
  6f9f2e:	00 00 00 00 
  6f9f32:	80 f9 02             	cmp    $0x2,%cl
  6f9f35:	74 46                	je     6f9f7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f7d>
  6f9f37:	48 8b 84 24 b8 04 00 	mov    0x4b8(%rsp),%rax
  6f9f3e:	00 
  6f9f3f:	48 8b 94 24 98 01 00 	mov    0x198(%rsp),%rdx
  6f9f46:	00 
  6f9f47:	48 8b 04 d0          	mov    (%rax,%rdx,8),%rax
  6f9f4b:	48 3b 78 28          	cmp    0x28(%rax),%rdi
  6f9f4f:	75 2c                	jne    6f9f7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f7d>
  6f9f51:	32 8c 24 00 02 00 00 	xor    0x200(%rsp),%cl
  6f9f58:	f6 c1 01             	test   $0x1,%cl
  6f9f5b:	74 42                	je     6f9f9f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f9f>
  6f9f5d:	eb 1e                	jmp    6f9f7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f7d>
  6f9f5f:	c6 84 24 00 02 00 00 	movb   $0x2,0x200(%rsp)
  6f9f66:	02 
  6f9f67:	b0 01                	mov    $0x1,%al
  6f9f69:	89 84 24 c0 02 00 00 	mov    %eax,0x2c0(%rsp)
  6f9f70:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
  6f9f77:	00 
  6f9f78:	80 f9 02             	cmp    $0x2,%cl
  6f9f7b:	74 22                	je     6f9f9f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f9f>
  6f9f7d:	48 8b bc 24 10 02 00 	mov    0x210(%rsp),%rdi
  6f9f84:	00 
  6f9f85:	48 89 de             	mov    %rbx,%rsi
  6f9f88:	e8 83 f6 00 00       	call   709610 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6f9f8d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f9f92:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6f9f99:	b0 01                	mov    $0x1,%al
  6f9f9b:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6f9f9f:	41 83 ff 09          	cmp    $0x9,%r15d
  6f9fa3:	0f 87 95 39 00 00    	ja     6fd93e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x693e>
  6f9fa9:	44 89 f8             	mov    %r15d,%eax
  6f9fac:	48 8d 0d 1d de 95 ff 	lea    -0x6a21e3(%rip),%rcx        # 57dd0 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x128>
  6f9fb3:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
  6f9fb7:	48 01 c8             	add    %rcx,%rax
  6f9fba:	ff e0                	jmp    *%rax
  6f9fbc:	b0 02                	mov    $0x2,%al
  6f9fbe:	eb 21                	jmp    6f9fe1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fe1>
  6f9fc0:	b0 06                	mov    $0x6,%al
  6f9fc2:	eb 1d                	jmp    6f9fe1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fe1>
  6f9fc4:	b0 01                	mov    $0x1,%al
  6f9fc6:	e9 88 03 00 00       	jmp    6fa353 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3353>
  6f9fcb:	b0 04                	mov    $0x4,%al
  6f9fcd:	eb 12                	jmp    6f9fe1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fe1>
  6f9fcf:	b0 05                	mov    $0x5,%al
  6f9fd1:	eb 0e                	jmp    6f9fe1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fe1>
  6f9fd3:	b0 09                	mov    $0x9,%al
  6f9fd5:	eb 0a                	jmp    6f9fe1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fe1>
  6f9fd7:	b0 03                	mov    $0x3,%al
  6f9fd9:	eb 06                	jmp    6f9fe1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fe1>
  6f9fdb:	b0 07                	mov    $0x7,%al
  6f9fdd:	eb 02                	jmp    6f9fe1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fe1>
  6f9fdf:	b0 08                	mov    $0x8,%al
  6f9fe1:	0f b6 8c 24 20 01 00 	movzbl 0x120(%rsp),%ecx
  6f9fe8:	00 
  6f9fe9:	8d 50 fe             	lea    -0x2(%rax),%edx
  6f9fec:	89 ce                	mov    %ecx,%esi
  6f9fee:	40 80 ee 02          	sub    $0x2,%sil
  6f9ff2:	40 0f b6 f6          	movzbl %sil,%esi
  6f9ff6:	bf 08 00 00 00       	mov    $0x8,%edi
  6f9ffb:	0f 42 f7             	cmovb  %edi,%esi
  6f9ffe:	40 38 f2             	cmp    %sil,%dl
  6fa001:	75 0f                	jne    6fa012 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3012>
  6fa003:	80 fa 08             	cmp    $0x8,%dl
  6fa006:	0f 95 c2             	setne  %dl
  6fa009:	38 c8                	cmp    %cl,%al
  6fa00b:	0f 94 c0             	sete   %al
  6fa00e:	08 d0                	or     %dl,%al
  6fa010:	75 12                	jne    6fa024 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3024>
  6fa012:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fa017:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6fa01e:	b0 01                	mov    $0x1,%al
  6fa020:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fa024:	48 83 bc 24 90 00 00 	cmpq   $0xffffffffffffffff,0x90(%rsp)
  6fa02b:	00 ff 
  6fa02d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
  6fa032:	74 5d                	je     6fa091 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3091>
  6fa034:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6fa03b:	00 
  6fa03c:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6fa043:	00 
  6fa044:	ff 15 9e 1b 39 00    	call   *0x391b9e(%rip)        # a8bbe8 <_DYNAMIC+0x700>
  6fa04a:	48 8b 8c 24 a0 01 00 	mov    0x1a0(%rsp),%rcx
  6fa051:	00 
  6fa052:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fa057:	48 ff 80 f0 06 00 00 	incq   0x6f0(%rax)
  6fa05e:	48 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%rax
  6fa065:	00 
  6fa066:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
  6fa06d:	00 
  6fa06e:	4c 8b bc 24 b0 01 00 	mov    0x1b0(%rsp),%r15
  6fa075:	00 
  6fa076:	4c 8b a4 24 60 04 00 	mov    0x460(%rsp),%r12
  6fa07d:	00 
  6fa07e:	49 83 fc fe          	cmp    $0xfffffffffffffffe,%r12
  6fa082:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  6fa087:	75 2d                	jne    6fa0b6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x30b6>
  6fa089:	48 83 f9 fe          	cmp    $0xfffffffffffffffe,%rcx
  6fa08d:	74 19                	je     6fa0a8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x30a8>
  6fa08f:	eb 7c                	jmp    6fa10d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x310d>
  6fa091:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fa096:	48 ff 80 f0 06 00 00 	incq   0x6f0(%rax)
  6fa09d:	48 83 bc 24 60 04 00 	cmpq   $0xfffffffffffffffe,0x460(%rsp)
  6fa0a4:	00 fe 
  6fa0a6:	75 19                	jne    6fa0c1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x30c1>
  6fa0a8:	48 c7 44 24 48 fe ff 	movq   $0xfffffffffffffffe,0x48(%rsp)
  6fa0af:	ff ff 
  6fa0b1:	e9 cd 03 00 00       	jmp    6fa483 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3483>
  6fa0b6:	48 83 f9 fe          	cmp    $0xfffffffffffffffe,%rcx
  6fa0ba:	75 21                	jne    6fa0dd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x30dd>
  6fa0bc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fa0c1:	c6 80 48 07 00 00 01 	movb   $0x1,0x748(%rax)
  6fa0c8:	49 c7 c7 fe ff ff ff 	mov    $0xfffffffffffffffe,%r15
  6fa0cf:	48 c7 44 24 48 fe ff 	movq   $0xfffffffffffffffe,0x48(%rsp)
  6fa0d6:	ff ff 
  6fa0d8:	e9 20 03 00 00       	jmp    6fa3fd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33fd>
  6fa0dd:	48 8b bc 24 a0 04 00 	mov    0x4a0(%rsp),%rdi
  6fa0e4:	00 
  6fa0e5:	48 8b 07             	mov    (%rdi),%rax
  6fa0e8:	48 d1 e8             	shr    $1,%rax
  6fa0eb:	4c 39 f8             	cmp    %r15,%rax
  6fa0ee:	75 1d                	jne    6fa10d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x310d>
  6fa0f0:	48 83 c7 10          	add    $0x10,%rdi
  6fa0f4:	48 8b b4 24 08 04 00 	mov    0x408(%rsp),%rsi
  6fa0fb:	00 
  6fa0fc:	4c 89 fa             	mov    %r15,%rdx
  6fa0ff:	ff 15 13 18 39 00    	call   *0x391813(%rip)        # a8b918 <bcmp@GLIBC_2.2.5>
  6fa105:	85 c0                	test   %eax,%eax
  6fa107:	0f 84 76 03 00 00    	je     6fa483 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3483>
  6fa10d:	49 83 fc fe          	cmp    $0xfffffffffffffffe,%r12
  6fa111:	0f 94 c0             	sete   %al
  6fa114:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6fa119:	08 81 48 07 00 00    	or     %al,0x748(%rcx)
  6fa11f:	48 8b b4 24 58 02 00 	mov    0x258(%rsp),%rsi
  6fa126:	00 
  6fa127:	49 39 f6             	cmp    %rsi,%r14
  6fa12a:	0f 83 d0 3a 00 00    	jae    6fdc00 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c00>
  6fa130:	48 8b ac 24 50 02 00 	mov    0x250(%rsp),%rbp
  6fa137:	00 
  6fa138:	4a 8b 44 f5 00       	mov    0x0(%rbp,%r14,8),%rax
  6fa13d:	48 85 c0             	test   %rax,%rax
  6fa140:	74 6d                	je     6fa1af <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x31af>
  6fa142:	48 8b 8c 24 48 04 00 	mov    0x448(%rsp),%rcx
  6fa149:	00 
  6fa14a:	48 85 c9             	test   %rcx,%rcx
  6fa14d:	74 60                	je     6fa1af <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x31af>
  6fa14f:	48 8b 94 24 50 04 00 	mov    0x450(%rsp),%rdx
  6fa156:	00 
  6fa157:	0f b7 b9 ba 00 00 00 	movzwl 0xba(%rcx),%edi
  6fa15e:	41 89 f8             	mov    %edi,%r8d
  6fa161:	41 c1 e0 03          	shl    $0x3,%r8d
  6fa165:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
  6fa16c:	0f 1f 40 00          	nopl   0x0(%rax)
  6fa170:	4d 85 c0             	test   %r8,%r8
  6fa173:	74 27                	je     6fa19c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x319c>
  6fa175:	48 3b 44 f1 10       	cmp    0x10(%rcx,%rsi,8),%rax
  6fa17a:	41 0f 97 c1          	seta   %r9b
  6fa17e:	41 80 d9 00          	sbb    $0x0,%r9b
  6fa182:	48 ff c6             	inc    %rsi
  6fa185:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  6fa189:	41 80 f9 01          	cmp    $0x1,%r9b
  6fa18d:	74 e1                	je     6fa170 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3170>
  6fa18f:	41 0f b6 f9          	movzbl %r9b,%edi
  6fa193:	85 ff                	test   %edi,%edi
  6fa195:	75 08                	jne    6fa19f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x319f>
  6fa197:	e9 64 01 00 00       	jmp    6fa300 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3300>
  6fa19c:	48 89 fe             	mov    %rdi,%rsi
  6fa19f:	48 83 ea 01          	sub    $0x1,%rdx
  6fa1a3:	72 0a                	jb     6fa1af <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x31af>
  6fa1a5:	48 8b 8c f1 c0 00 00 	mov    0xc0(%rcx,%rsi,8),%rcx
  6fa1ac:	00 
  6fa1ad:	eb a8                	jmp    6fa157 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3157>
  6fa1af:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fa1b4:	f3 0f 6f 80 f8 06 00 	movdqu 0x6f8(%rax),%xmm0
  6fa1bb:	00 
  6fa1bc:	66 49 0f 6e cf       	movq   %r15,%xmm1
  6fa1c1:	66 0f 6f 15 77 cd 95 	movdqa -0x6a3289(%rip),%xmm2        # 56f40 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x920>
  6fa1c8:	ff 
  6fa1c9:	66 0f 6c d1          	punpcklqdq %xmm1,%xmm2
  6fa1cd:	66 0f d4 d0          	paddq  %xmm0,%xmm2
  6fa1d1:	f3 0f 7f 90 f8 06 00 	movdqu %xmm2,0x6f8(%rax)
  6fa1d8:	00 
  6fa1d9:	48 8d 05 20 d5 95 ff 	lea    -0x6a2ae0(%rip),%rax        # 57700 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x10e0>
  6fa1e0:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
  6fa1e7:	00 
  6fa1e8:	4d 85 ff             	test   %r15,%r15
  6fa1eb:	74 57                	je     6fa244 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3244>
  6fa1ed:	41 b5 01             	mov    $0x1,%r13b
  6fa1f0:	41 b4 01             	mov    $0x1,%r12b
  6fa1f3:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6fa1fa:	00 
  6fa1fb:	4c 89 fe             	mov    %r15,%rsi
  6fa1fe:	31 d2                	xor    %edx,%edx
  6fa200:	31 c9                	xor    %ecx,%ecx
  6fa202:	ff 15 18 17 39 00    	call   *0x391718(%rip)        # a8b920 <_DYNAMIC+0x438>
  6fa208:	48 8b bc 24 a0 01 00 	mov    0x1a0(%rsp),%rdi
  6fa20f:	00 
  6fa210:	48 83 ff ff          	cmp    $0xffffffffffffffff,%rdi
  6fa214:	0f 85 93 3a 00 00    	jne    6fdcad <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cad>
  6fa21a:	48 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%rax
  6fa221:	00 
  6fa222:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
  6fa229:	00 
  6fa22a:	48 8d 78 10          	lea    0x10(%rax),%rdi
  6fa22e:	48 8b b4 24 08 04 00 	mov    0x408(%rsp),%rsi
  6fa235:	00 
  6fa236:	4c 89 fa             	mov    %r15,%rdx
  6fa239:	ff 15 09 15 39 00    	call   *0x391509(%rip)        # a8b748 <memcpy@GLIBC_2.14>
  6fa23f:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
  6fa244:	4a 8b 44 f5 00       	mov    0x0(%rbp,%r14,8),%rax
  6fa249:	48 85 c0             	test   %rax,%rax
  6fa24c:	0f 84 8c 01 00 00    	je     6fa3de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33de>
  6fa252:	4c 8b 94 24 28 02 00 	mov    0x228(%rsp),%r10
  6fa259:	00 
  6fa25a:	41 f6 02 01          	testb  $0x1,(%r10)
  6fa25e:	75 2f                	jne    6fa28f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x328f>
  6fa260:	49 8b 4a 08          	mov    0x8(%r10),%rcx
  6fa264:	f6 c1 01             	test   $0x1,%cl
  6fa267:	75 26                	jne    6fa28f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x328f>
  6fa269:	b9 02 00 00 00       	mov    $0x2,%ecx
  6fa26e:	f0 49 0f c1 4a 08    	lock xadd %rcx,0x8(%r10)
  6fa274:	48 ba 01 00 00 00 00 	movabs $0x8000000000000001,%rdx
  6fa27b:	00 00 80 
  6fa27e:	48 21 d1             	and    %rdx,%rcx
  6fa281:	48 ff ca             	dec    %rdx
  6fa284:	48 39 d1             	cmp    %rdx,%rcx
  6fa287:	75 06                	jne    6fa28f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x328f>
  6fa289:	f0 49 83 4a 08 01    	lock orq $0x1,0x8(%r10)
  6fa28f:	48 8b 8c 24 48 04 00 	mov    0x448(%rsp),%rcx
  6fa296:	00 
  6fa297:	48 85 c9             	test   %rcx,%rcx
  6fa29a:	0f 84 f0 00 00 00    	je     6fa390 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3390>
  6fa2a0:	48 8b 94 24 50 04 00 	mov    0x450(%rsp),%rdx
  6fa2a7:	00 
  6fa2a8:	0f b7 b9 ba 00 00 00 	movzwl 0xba(%rcx),%edi
  6fa2af:	41 89 f8             	mov    %edi,%r8d
  6fa2b2:	41 c1 e0 03          	shl    $0x3,%r8d
  6fa2b6:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
  6fa2bd:	0f 1f 00             	nopl   (%rax)
  6fa2c0:	4d 85 c0             	test   %r8,%r8
  6fa2c3:	74 24                	je     6fa2e9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x32e9>
  6fa2c5:	48 3b 44 f1 10       	cmp    0x10(%rcx,%rsi,8),%rax
  6fa2ca:	41 0f 97 c1          	seta   %r9b
  6fa2ce:	41 80 d9 00          	sbb    $0x0,%r9b
  6fa2d2:	48 ff c6             	inc    %rsi
  6fa2d5:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  6fa2d9:	41 80 f9 01          	cmp    $0x1,%r9b
  6fa2dd:	74 e1                	je     6fa2c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x32c0>
  6fa2df:	41 0f b6 f9          	movzbl %r9b,%edi
  6fa2e3:	85 ff                	test   %edi,%edi
  6fa2e5:	75 05                	jne    6fa2ec <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x32ec>
  6fa2e7:	eb 79                	jmp    6fa362 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3362>
  6fa2e9:	48 89 fe             	mov    %rdi,%rsi
  6fa2ec:	48 83 ea 01          	sub    $0x1,%rdx
  6fa2f0:	0f 82 9c 00 00 00    	jb     6fa392 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3392>
  6fa2f6:	48 8b 8c f1 c0 00 00 	mov    0xc0(%rcx,%rsi,8),%rcx
  6fa2fd:	00 
  6fa2fe:	eb a8                	jmp    6fa2a8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x32a8>
  6fa300:	48 8b 54 f1 60       	mov    0x60(%rcx,%rsi,8),%rdx
  6fa305:	f6 02 01             	testb  $0x1,(%rdx)
  6fa308:	48 89 94 24 28 02 00 	mov    %rdx,0x228(%rsp)
  6fa30f:	00 
  6fa310:	0f 85 c8 00 00 00    	jne    6fa3de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33de>
  6fa316:	48 8b 42 08          	mov    0x8(%rdx),%rax
  6fa31a:	a8 01                	test   $0x1,%al
  6fa31c:	0f 85 bc 00 00 00    	jne    6fa3de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33de>
  6fa322:	b8 02 00 00 00       	mov    $0x2,%eax
  6fa327:	f0 48 0f c1 42 08    	lock xadd %rax,0x8(%rdx)
  6fa32d:	48 b9 01 00 00 00 00 	movabs $0x8000000000000001,%rcx
  6fa334:	00 00 80 
  6fa337:	48 21 c8             	and    %rcx,%rax
  6fa33a:	48 ff c9             	dec    %rcx
  6fa33d:	48 39 c8             	cmp    %rcx,%rax
  6fa340:	0f 85 98 00 00 00    	jne    6fa3de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33de>
  6fa346:	f0 48 83 4a 08 01    	lock orq $0x1,0x8(%rdx)
  6fa34c:	e9 8d 00 00 00       	jmp    6fa3de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33de>
  6fa351:	31 c0                	xor    %eax,%eax
  6fa353:	b2 08                	mov    $0x8,%dl
  6fa355:	0f b6 8c 24 20 01 00 	movzbl 0x120(%rsp),%ecx
  6fa35c:	00 
  6fa35d:	e9 8a fc ff ff       	jmp    6f9fec <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fec>
  6fa362:	48 8b 7c f1 60       	mov    0x60(%rcx,%rsi,8),%rdi
  6fa367:	4c 89 54 f1 60       	mov    %r10,0x60(%rcx,%rsi,8)
  6fa36c:	f6 07 01             	testb  $0x1,(%rdi)
  6fa36f:	75 6d                	jne    6fa3de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33de>
  6fa371:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fa375:	a8 01                	test   $0x1,%al
  6fa377:	75 65                	jne    6fa3de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33de>
  6fa379:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6fa37d:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6fa382:	75 5a                	jne    6fa3de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33de>
  6fa384:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fa388:	ff 15 f2 13 39 00    	call   *0x3913f2(%rip)        # a8b780 <_DYNAMIC+0x298>
  6fa38e:	eb 4e                	jmp    6fa3de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33de>
  6fa390:	31 c9                	xor    %ecx,%ecx
  6fa392:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
  6fa399:	00 
  6fa39a:	48 8d 84 24 48 04 00 	lea    0x448(%rsp),%rax
  6fa3a1:	00 
  6fa3a2:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
  6fa3a9:	00 
  6fa3aa:	48 89 8c 24 b0 01 00 	mov    %rcx,0x1b0(%rsp)
  6fa3b1:	00 
  6fa3b2:	48 c7 84 24 b8 01 00 	movq   $0x0,0x1b8(%rsp)
  6fa3b9:	00 00 00 00 00 
  6fa3be:	48 89 b4 24 c0 01 00 	mov    %rsi,0x1c0(%rsp)
  6fa3c5:	00 
  6fa3c6:	48 8d bc 24 90 03 00 	lea    0x390(%rsp),%rdi
  6fa3cd:	00 
  6fa3ce:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
  6fa3d5:	00 
  6fa3d6:	4c 89 d2             	mov    %r10,%rdx
  6fa3d9:	e8 e2 73 01 00       	call   7117c0 <<alloc::collections::btree::map::entry::VacantEntry<gpui::source::FieldId, gpui::shared_text::SharedText>>::insert_entry>
  6fa3de:	4a 8b 44 f5 00       	mov    0x0(%rbp,%r14,8),%rax
  6fa3e3:	48 89 84 24 78 06 00 	mov    %rax,0x678(%rsp)
  6fa3ea:	00 
  6fa3eb:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
  6fa3f2:	48 83 bc 24 60 04 00 	cmpq   $0xfffffffffffffffe,0x460(%rsp)
  6fa3f9:	00 fe 
  6fa3fb:	74 31                	je     6fa42e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x342e>
  6fa3fd:	48 8b bc 24 a0 04 00 	mov    0x4a0(%rsp),%rdi
  6fa404:	00 
  6fa405:	f6 07 01             	testb  $0x1,(%rdi)
  6fa408:	75 17                	jne    6fa421 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3421>
  6fa40a:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fa40e:	a8 01                	test   $0x1,%al
  6fa410:	75 0f                	jne    6fa421 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3421>
  6fa412:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6fa416:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6fa41b:	0f 84 cc 0a 00 00    	je     6faeed <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3eed>
  6fa421:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
  6fa428:	00 
  6fa429:	e8 e2 81 fe ff       	call   6e2610 <core::ptr::drop_glue::<core::option::Option<gpui::runtime::Shaped>>>
  6fa42e:	4c 89 bc 24 60 04 00 	mov    %r15,0x460(%rsp)
  6fa435:	00 
  6fa436:	48 8b 84 24 28 02 00 	mov    0x228(%rsp),%rax
  6fa43d:	00 
  6fa43e:	48 89 84 24 a0 04 00 	mov    %rax,0x4a0(%rsp)
  6fa445:	00 
  6fa446:	48 8b 84 24 78 06 00 	mov    0x678(%rsp),%rax
  6fa44d:	00 
  6fa44e:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
  6fa455:	00 
  6fa456:	41 b5 01             	mov    $0x1,%r13b
  6fa459:	41 b4 01             	mov    $0x1,%r12b
  6fa45c:	48 8b bc 24 10 02 00 	mov    0x210(%rsp),%rdi
  6fa463:	00 
  6fa464:	48 89 de             	mov    %rbx,%rsi
  6fa467:	e8 a4 f1 00 00       	call   709610 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6fa46c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fa471:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6fa478:	b0 01                	mov    $0x1,%al
  6fa47a:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fa47e:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
  6fa483:	48 8d 8c 24 98 00 00 	lea    0x98(%rsp),%rcx
  6fa48a:	00 
  6fa48b:	48 8b 41 68          	mov    0x68(%rcx),%rax
  6fa48f:	48 89 84 24 e0 03 00 	mov    %rax,0x3e0(%rsp)
  6fa496:	00 
  6fa497:	0f 10 41 58          	movups 0x58(%rcx),%xmm0
  6fa49b:	0f 29 84 24 d0 03 00 	movaps %xmm0,0x3d0(%rsp)
  6fa4a2:	00 
  6fa4a3:	f3 0f 6f 41 18       	movdqu 0x18(%rcx),%xmm0
  6fa4a8:	f3 0f 6f 49 28       	movdqu 0x28(%rcx),%xmm1
  6fa4ad:	f3 0f 6f 51 38       	movdqu 0x38(%rcx),%xmm2
  6fa4b2:	0f 10 59 48          	movups 0x48(%rcx),%xmm3
  6fa4b6:	0f 29 9c 24 c0 03 00 	movaps %xmm3,0x3c0(%rsp)
  6fa4bd:	00 
  6fa4be:	66 0f 7f 94 24 b0 03 	movdqa %xmm2,0x3b0(%rsp)
  6fa4c5:	00 00 
  6fa4c7:	66 0f 7f 8c 24 a0 03 	movdqa %xmm1,0x3a0(%rsp)
  6fa4ce:	00 00 
  6fa4d0:	66 0f 7f 84 24 90 03 	movdqa %xmm0,0x390(%rsp)
  6fa4d7:	00 00 
  6fa4d9:	48 8b 84 24 20 04 00 	mov    0x420(%rsp),%rax
  6fa4e0:	00 
  6fa4e1:	4c 8b 38             	mov    (%rax),%r15
  6fa4e4:	48 8d 84 24 08 06 00 	lea    0x608(%rsp),%rax
  6fa4eb:	00 
  6fa4ec:	4d 85 ff             	test   %r15,%r15
  6fa4ef:	0f 84 f7 00 00 00    	je     6fa5ec <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x35ec>
  6fa4f5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fa4fa:	48 8b 80 30 06 00 00 	mov    0x630(%rax),%rax
  6fa501:	41 0f b7 97 32 05 00 	movzwl 0x532(%r15),%edx
  6fa508:	00 
  6fa509:	48 6b fa 70          	imul   $0x70,%rdx,%rdi
  6fa50d:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
  6fa514:	31 f6                	xor    %esi,%esi
  6fa516:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6fa51d:	00 00 00 
  6fa520:	49 89 f8             	mov    %rdi,%r8
  6fa523:	49 01 f0             	add    %rsi,%r8
  6fa526:	74 27                	je     6fa54f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x354f>
  6fa528:	49 3b 9c cf e0 04 00 	cmp    0x4e0(%r15,%rcx,8),%rbx
  6fa52f:	00 
  6fa530:	41 0f 97 c0          	seta   %r8b
  6fa534:	41 80 d8 00          	sbb    $0x0,%r8b
  6fa538:	48 83 c6 90          	add    $0xffffffffffffff90,%rsi
  6fa53c:	48 ff c1             	inc    %rcx
  6fa53f:	41 80 f8 01          	cmp    $0x1,%r8b
  6fa543:	74 db                	je     6fa520 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3520>
  6fa545:	41 0f b6 d0          	movzbl %r8b,%edx
  6fa549:	85 d2                	test   %edx,%edx
  6fa54b:	75 05                	jne    6fa552 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3552>
  6fa54d:	eb 17                	jmp    6fa566 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3566>
  6fa54f:	48 89 d1             	mov    %rdx,%rcx
  6fa552:	48 83 e8 01          	sub    $0x1,%rax
  6fa556:	0f 82 84 09 00 00    	jb     6faee0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3ee0>
  6fa55c:	4d 8b bc cf 38 05 00 	mov    0x538(%r15,%rcx,8),%r15
  6fa563:	00 
  6fa564:	eb 9b                	jmp    6fa501 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3501>
  6fa566:	49 29 f7             	sub    %rsi,%r15
  6fa569:	49 8d 57 e8          	lea    -0x18(%r15),%rdx
  6fa56d:	48 8d 8c 24 98 00 00 	lea    0x98(%rsp),%rcx
  6fa574:	00 
  6fa575:	48 8b 41 68          	mov    0x68(%rcx),%rax
  6fa579:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
  6fa580:	00 
  6fa581:	0f 10 41 58          	movups 0x58(%rcx),%xmm0
  6fa585:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
  6fa58c:	00 
  6fa58d:	f3 0f 6f 41 18       	movdqu 0x18(%rcx),%xmm0
  6fa592:	f3 0f 6f 49 28       	movdqu 0x28(%rcx),%xmm1
  6fa597:	f3 0f 6f 51 38       	movdqu 0x38(%rcx),%xmm2
  6fa59c:	0f 10 59 48          	movups 0x48(%rcx),%xmm3
  6fa5a0:	0f 29 9c 24 d0 01 00 	movaps %xmm3,0x1d0(%rsp)
  6fa5a7:	00 
  6fa5a8:	66 0f 7f 94 24 c0 01 	movdqa %xmm2,0x1c0(%rsp)
  6fa5af:	00 00 
  6fa5b1:	66 0f 7f 8c 24 b0 01 	movdqa %xmm1,0x1b0(%rsp)
  6fa5b8:	00 00 
  6fa5ba:	66 0f 7f 84 24 a0 01 	movdqa %xmm0,0x1a0(%rsp)
  6fa5c1:	00 00 
  6fa5c3:	41 b5 01             	mov    $0x1,%r13b
  6fa5c6:	41 b4 01             	mov    $0x1,%r12b
  6fa5c9:	48 8d bc 24 08 06 00 	lea    0x608(%rsp),%rdi
  6fa5d0:	00 
  6fa5d1:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
  6fa5d8:	00 
  6fa5d9:	31 c9                	xor    %ecx,%ecx
  6fa5db:	e8 90 0d 02 00       	call   71b370 <gpui::property::apply_except::<gpui::style::Style>>
  6fa5e0:	49 83 c7 90          	add    $0xffffffffffffff90,%r15
  6fa5e4:	4c 89 f8             	mov    %r15,%rax
  6fa5e7:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
  6fa5ec:	48 8b 8c 24 e0 03 00 	mov    0x3e0(%rsp),%rcx
  6fa5f3:	00 
  6fa5f4:	48 89 48 50          	mov    %rcx,0x50(%rax)
  6fa5f8:	0f 28 84 24 d0 03 00 	movaps 0x3d0(%rsp),%xmm0
  6fa5ff:	00 
  6fa600:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  6fa604:	66 0f 6f 84 24 90 03 	movdqa 0x390(%rsp),%xmm0
  6fa60b:	00 00 
  6fa60d:	66 0f 6f 8c 24 a0 03 	movdqa 0x3a0(%rsp),%xmm1
  6fa614:	00 00 
  6fa616:	66 0f 6f 94 24 b0 03 	movdqa 0x3b0(%rsp),%xmm2
  6fa61d:	00 00 
  6fa61f:	0f 28 9c 24 c0 03 00 	movaps 0x3c0(%rsp),%xmm3
  6fa626:	00 
  6fa627:	0f 11 58 30          	movups %xmm3,0x30(%rax)
  6fa62b:	f3 0f 7f 50 20       	movdqu %xmm2,0x20(%rax)
  6fa630:	f3 0f 7f 48 10       	movdqu %xmm1,0x10(%rax)
  6fa635:	f3 0f 7f 00          	movdqu %xmm0,(%rax)
  6fa639:	44 8b a4 24 90 05 00 	mov    0x590(%rsp),%r12d
  6fa640:	00 
  6fa641:	44 0f b6 bc 24 08 06 	movzbl 0x608(%rsp),%r15d
  6fa648:	00 00 
  6fa64a:	41 83 fc 01          	cmp    $0x1,%r12d
  6fa64e:	75 1b                	jne    6fa66b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x366b>
  6fa650:	8b 84 24 0c 06 00 00 	mov    0x60c(%rsp),%eax
  6fa657:	39 84 24 94 05 00 00 	cmp    %eax,0x594(%rsp)
  6fa65e:	0f 94 c0             	sete   %al
  6fa661:	41 84 c7             	test   %al,%r15b
  6fa664:	75 0f                	jne    6fa675 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3675>
  6fa666:	e9 1d 01 00 00       	jmp    6fa788 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3788>
  6fa66b:	41 f6 c7 01          	test   $0x1,%r15b
  6fa66f:	0f 85 13 01 00 00    	jne    6fa788 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3788>
  6fa675:	0f b6 84 24 10 06 00 	movzbl 0x610(%rsp),%eax
  6fa67c:	00 
  6fa67d:	83 bc 24 98 05 00 00 	cmpl   $0x1,0x598(%rsp)
  6fa684:	01 
  6fa685:	75 1a                	jne    6fa6a1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x36a1>
  6fa687:	8b 8c 24 14 06 00 00 	mov    0x614(%rsp),%ecx
  6fa68e:	39 8c 24 9c 05 00 00 	cmp    %ecx,0x59c(%rsp)
  6fa695:	0f 94 c1             	sete   %cl
  6fa698:	84 c8                	test   %cl,%al
  6fa69a:	75 0d                	jne    6fa6a9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x36a9>
  6fa69c:	e9 e7 00 00 00       	jmp    6fa788 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3788>
  6fa6a1:	a8 01                	test   $0x1,%al
  6fa6a3:	0f 85 df 00 00 00    	jne    6fa788 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3788>
  6fa6a9:	8b 84 24 a0 05 00 00 	mov    0x5a0(%rsp),%eax
  6fa6b0:	3b 84 24 18 06 00 00 	cmp    0x618(%rsp),%eax
  6fa6b7:	0f 85 cb 00 00 00    	jne    6fa788 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3788>
  6fa6bd:	8b 84 24 a4 05 00 00 	mov    0x5a4(%rsp),%eax
  6fa6c4:	3b 84 24 1c 06 00 00 	cmp    0x61c(%rsp),%eax
  6fa6cb:	0f 85 b7 00 00 00    	jne    6fa788 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3788>
  6fa6d1:	8b 84 24 a8 05 00 00 	mov    0x5a8(%rsp),%eax
  6fa6d8:	3b 84 24 20 06 00 00 	cmp    0x620(%rsp),%eax
  6fa6df:	0f 85 a3 00 00 00    	jne    6fa788 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3788>
  6fa6e5:	0f b6 84 24 e4 05 00 	movzbl 0x5e4(%rsp),%eax
  6fa6ec:	00 
  6fa6ed:	3a 84 24 5c 06 00 00 	cmp    0x65c(%rsp),%al
  6fa6f4:	0f 85 8e 00 00 00    	jne    6fa788 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3788>
  6fa6fa:	0f b6 84 24 e6 05 00 	movzbl 0x5e6(%rsp),%eax
  6fa701:	00 
  6fa702:	3a 84 24 5e 06 00 00 	cmp    0x65e(%rsp),%al
  6fa709:	75 7d                	jne    6fa788 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3788>
  6fa70b:	0f b6 84 24 e7 05 00 	movzbl 0x5e7(%rsp),%eax
  6fa712:	00 
  6fa713:	3a 84 24 5f 06 00 00 	cmp    0x65f(%rsp),%al
  6fa71a:	75 6c                	jne    6fa788 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3788>
  6fa71c:	0f b6 84 24 e5 05 00 	movzbl 0x5e5(%rsp),%eax
  6fa723:	00 
  6fa724:	3a 84 24 5d 06 00 00 	cmp    0x65d(%rsp),%al
  6fa72b:	75 5b                	jne    6fa788 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3788>
  6fa72d:	48 8d bc 24 cc 05 00 	lea    0x5cc(%rsp),%rdi
  6fa734:	00 
  6fa735:	48 8d b4 24 44 06 00 	lea    0x644(%rsp),%rsi
  6fa73c:	00 
  6fa73d:	e8 ce 63 00 00       	call   700b10 <<gpui_reactivity_core::geometry::Affine as gpui::property::ExactValue>::same>
  6fa742:	84 c0                	test   %al,%al
  6fa744:	74 42                	je     6fa788 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3788>
  6fa746:	f3 0f 6f 84 24 ac 05 	movdqu 0x5ac(%rsp),%xmm0
  6fa74d:	00 00 
  6fa74f:	f3 0f 6f 8c 24 24 06 	movdqu 0x624(%rsp),%xmm1
  6fa756:	00 00 
  6fa758:	66 0f 74 c8          	pcmpeqb %xmm0,%xmm1
  6fa75c:	66 0f d7 c1          	pmovmskb %xmm1,%eax
  6fa760:	3d ff ff 00 00       	cmp    $0xffff,%eax
  6fa765:	75 21                	jne    6fa788 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3788>
  6fa767:	f3 0f 6f 84 24 bc 05 	movdqu 0x5bc(%rsp),%xmm0
  6fa76e:	00 00 
  6fa770:	f3 0f 6f 8c 24 34 06 	movdqu 0x634(%rsp),%xmm1
  6fa777:	00 00 
  6fa779:	66 0f 74 c8          	pcmpeqb %xmm0,%xmm1
  6fa77d:	66 0f d7 c1          	pmovmskb %xmm1,%eax
  6fa781:	3d ff ff 00 00       	cmp    $0xffff,%eax
  6fa786:	74 12                	je     6fa79a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x379a>
  6fa788:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fa78d:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6fa794:	b0 01                	mov    $0x1,%al
  6fa796:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fa79a:	41 f6 c4 01          	test   $0x1,%r12b
  6fa79e:	74 29                	je     6fa7c9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x37c9>
  6fa7a0:	41 f6 c7 01          	test   $0x1,%r15b
  6fa7a4:	0f 84 f1 00 00 00    	je     6fa89b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x389b>
  6fa7aa:	f3 0f 10 84 24 94 05 	movss  0x594(%rsp),%xmm0
  6fa7b1:	00 00 
  6fa7b3:	0f 2e 84 24 0c 06 00 	ucomiss 0x60c(%rsp),%xmm0
  6fa7ba:	00 
  6fa7bb:	0f 85 da 00 00 00    	jne    6fa89b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x389b>
  6fa7c1:	0f 8a d4 00 00 00    	jp     6fa89b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x389b>
  6fa7c7:	eb 0a                	jmp    6fa7d3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x37d3>
  6fa7c9:	41 f6 c7 01          	test   $0x1,%r15b
  6fa7cd:	0f 85 c8 00 00 00    	jne    6fa89b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x389b>
  6fa7d3:	0f b6 84 24 10 06 00 	movzbl 0x610(%rsp),%eax
  6fa7da:	00 
  6fa7db:	83 bc 24 98 05 00 00 	cmpl   $0x1,0x598(%rsp)
  6fa7e2:	01 
  6fa7e3:	75 27                	jne    6fa80c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x380c>
  6fa7e5:	84 c0                	test   %al,%al
  6fa7e7:	0f 84 ae 00 00 00    	je     6fa89b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x389b>
  6fa7ed:	f3 0f 10 84 24 9c 05 	movss  0x59c(%rsp),%xmm0
  6fa7f4:	00 00 
  6fa7f6:	0f 2e 84 24 14 06 00 	ucomiss 0x614(%rsp),%xmm0
  6fa7fd:	00 
  6fa7fe:	0f 85 97 00 00 00    	jne    6fa89b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x389b>
  6fa804:	0f 8a 91 00 00 00    	jp     6fa89b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x389b>
  6fa80a:	eb 08                	jmp    6fa814 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3814>
  6fa80c:	84 c0                	test   %al,%al
  6fa80e:	0f 85 87 00 00 00    	jne    6fa89b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x389b>
  6fa814:	f3 0f 10 84 24 a0 05 	movss  0x5a0(%rsp),%xmm0
  6fa81b:	00 00 
  6fa81d:	0f 2e 84 24 18 06 00 	ucomiss 0x618(%rsp),%xmm0
  6fa824:	00 
  6fa825:	75 74                	jne    6fa89b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x389b>
  6fa827:	7a 72                	jp     6fa89b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x389b>
  6fa829:	f3 0f 10 84 24 a4 05 	movss  0x5a4(%rsp),%xmm0
  6fa830:	00 00 
  6fa832:	0f 2e 84 24 1c 06 00 	ucomiss 0x61c(%rsp),%xmm0
  6fa839:	00 
  6fa83a:	75 5f                	jne    6fa89b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x389b>
  6fa83c:	7a 5d                	jp     6fa89b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x389b>
  6fa83e:	f3 0f 10 84 24 a8 05 	movss  0x5a8(%rsp),%xmm0
  6fa845:	00 00 
  6fa847:	f3 0f 10 8c 24 20 06 	movss  0x620(%rsp),%xmm1
  6fa84e:	00 00 
  6fa850:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6fa853:	75 46                	jne    6fa89b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x389b>
  6fa855:	7a 44                	jp     6fa89b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x389b>
  6fa857:	0f b6 84 24 e4 05 00 	movzbl 0x5e4(%rsp),%eax
  6fa85e:	00 
  6fa85f:	3a 84 24 5c 06 00 00 	cmp    0x65c(%rsp),%al
  6fa866:	75 33                	jne    6fa89b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x389b>
  6fa868:	0f b6 84 24 e6 05 00 	movzbl 0x5e6(%rsp),%eax
  6fa86f:	00 
  6fa870:	3a 84 24 5e 06 00 00 	cmp    0x65e(%rsp),%al
  6fa877:	75 22                	jne    6fa89b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x389b>
  6fa879:	0f b6 84 24 e7 05 00 	movzbl 0x5e7(%rsp),%eax
  6fa880:	00 
  6fa881:	3a 84 24 5f 06 00 00 	cmp    0x65f(%rsp),%al
  6fa888:	75 11                	jne    6fa89b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x389b>
  6fa88a:	0f b6 84 24 e5 05 00 	movzbl 0x5e5(%rsp),%eax
  6fa891:	00 
  6fa892:	3a 84 24 5d 06 00 00 	cmp    0x65d(%rsp),%al
  6fa899:	74 2d                	je     6fa8c8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38c8>
  6fa89b:	41 b5 01             	mov    $0x1,%r13b
  6fa89e:	41 b4 01             	mov    $0x1,%r12b
  6fa8a1:	48 8b bc 24 10 02 00 	mov    0x210(%rsp),%rdi
  6fa8a8:	00 
  6fa8a9:	48 89 de             	mov    %rbx,%rsi
  6fa8ac:	e8 5f ed 00 00       	call   709610 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6fa8b1:	f3 0f 10 84 24 a8 05 	movss  0x5a8(%rsp),%xmm0
  6fa8b8:	00 00 
  6fa8ba:	f3 0f 10 8c 24 20 06 	movss  0x620(%rsp),%xmm1
  6fa8c1:	00 00 
  6fa8c3:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
  6fa8c8:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6fa8cb:	4c 8b bc 24 20 04 00 	mov    0x420(%rsp),%r15
  6fa8d2:	00 
  6fa8d3:	75 02                	jne    6fa8d7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38d7>
  6fa8d5:	7b 24                	jnp    6fa8fb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38fb>
  6fa8d7:	48 83 bc 24 60 04 00 	cmpq   $0xfffffffffffffffe,0x460(%rsp)
  6fa8de:	00 fe 
  6fa8e0:	74 19                	je     6fa8fb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38fb>
  6fa8e2:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
  6fa8e9:	00 
  6fa8ea:	e8 21 7d fe ff       	call   6e2610 <core::ptr::drop_glue::<core::option::Option<gpui::runtime::Shaped>>>
  6fa8ef:	48 c7 84 24 60 04 00 	movq   $0xffffffffffffffff,0x460(%rsp)
  6fa8f6:	00 ff ff ff ff 
  6fa8fb:	48 83 bc 24 08 01 00 	cmpq   $0x0,0x108(%rsp)
  6fa902:	00 00 
  6fa904:	0f 95 c0             	setne  %al
  6fa907:	38 84 24 10 04 00 00 	cmp    %al,0x410(%rsp)
  6fa90e:	74 12                	je     6fa922 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3922>
  6fa910:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fa915:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6fa91c:	b0 01                	mov    $0x1,%al
  6fa91e:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fa922:	41 b5 01             	mov    $0x1,%r13b
  6fa925:	41 b4 01             	mov    $0x1,%r12b
  6fa928:	48 8d bc 24 90 03 00 	lea    0x390(%rsp),%rdi
  6fa92f:	00 
  6fa930:	4c 89 fe             	mov    %r15,%rsi
  6fa933:	48 89 da             	mov    %rbx,%rdx
  6fa936:	48 8b 0d 7b 0f 39 00 	mov    0x390f7b(%rip),%rcx        # a8b8b8 <_DYNAMIC+0x3d0>
  6fa93d:	e8 5e 03 02 00       	call   71aca0 <<gpui::property::Overrides>::get::<gpui_canvas::color::Color>>
  6fa942:	8b ac 24 90 03 00 00 	mov    0x390(%rsp),%ebp
  6fa949:	41 b5 01             	mov    $0x1,%r13b
  6fa94c:	41 b4 01             	mov    $0x1,%r12b
  6fa94f:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6fa956:	00 
  6fa957:	48 8b b4 24 20 04 00 	mov    0x420(%rsp),%rsi
  6fa95e:	00 
  6fa95f:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6fa964:	48 8b 0d 55 0f 39 00 	mov    0x390f55(%rip),%rcx        # a8b8c0 <_DYNAMIC+0x3d8>
  6fa96b:	e8 30 03 02 00       	call   71aca0 <<gpui::property::Overrides>::get::<gpui_canvas::color::Color>>
  6fa970:	0f b6 84 24 a0 01 00 	movzbl 0x1a0(%rsp),%eax
  6fa977:	00 
  6fa978:	00 c0                	add    %al,%al
  6fa97a:	40 08 e8             	or     %bpl,%al
  6fa97d:	48 8d 94 24 98 00 00 	lea    0x98(%rsp),%rdx
  6fa984:	00 
  6fa985:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
  6fa989:	48 89 8c 24 e0 03 00 	mov    %rcx,0x3e0(%rsp)
  6fa990:	00 
  6fa991:	0f 10 42 58          	movups 0x58(%rdx),%xmm0
  6fa995:	0f 29 84 24 d0 03 00 	movaps %xmm0,0x3d0(%rsp)
  6fa99c:	00 
  6fa99d:	0f 10 42 18          	movups 0x18(%rdx),%xmm0
  6fa9a1:	0f 10 4a 28          	movups 0x28(%rdx),%xmm1
  6fa9a5:	0f 10 52 38          	movups 0x38(%rdx),%xmm2
  6fa9a9:	0f 10 5a 48          	movups 0x48(%rdx),%xmm3
  6fa9ad:	0f 29 9c 24 c0 03 00 	movaps %xmm3,0x3c0(%rsp)
  6fa9b4:	00 
  6fa9b5:	0f 29 94 24 b0 03 00 	movaps %xmm2,0x3b0(%rsp)
  6fa9bc:	00 
  6fa9bd:	0f 29 8c 24 a0 03 00 	movaps %xmm1,0x3a0(%rsp)
  6fa9c4:	00 
  6fa9c5:	0f 29 84 24 90 03 00 	movaps %xmm0,0x390(%rsp)
  6fa9cc:	00 
  6fa9cd:	48 8b 8c 24 58 06 00 	mov    0x658(%rsp),%rcx
  6fa9d4:	00 
  6fa9d5:	48 89 8c 24 f0 01 00 	mov    %rcx,0x1f0(%rsp)
  6fa9dc:	00 
  6fa9dd:	0f 10 84 24 48 06 00 	movups 0x648(%rsp),%xmm0
  6fa9e4:	00 
  6fa9e5:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
  6fa9ec:	00 
  6fa9ed:	f3 0f 6f 84 24 08 06 	movdqu 0x608(%rsp),%xmm0
  6fa9f4:	00 00 
  6fa9f6:	f3 0f 6f 8c 24 18 06 	movdqu 0x618(%rsp),%xmm1
  6fa9fd:	00 00 
  6fa9ff:	f3 0f 6f 94 24 28 06 	movdqu 0x628(%rsp),%xmm2
  6faa06:	00 00 
  6faa08:	0f 10 9c 24 38 06 00 	movups 0x638(%rsp),%xmm3
  6faa0f:	00 
  6faa10:	0f 29 9c 24 d0 01 00 	movaps %xmm3,0x1d0(%rsp)
  6faa17:	00 
  6faa18:	66 0f 7f 94 24 c0 01 	movdqa %xmm2,0x1c0(%rsp)
  6faa1f:	00 00 
  6faa21:	66 0f 7f 8c 24 b0 01 	movdqa %xmm1,0x1b0(%rsp)
  6faa28:	00 00 
  6faa2a:	66 0f 7f 84 24 a0 01 	movdqa %xmm0,0x1a0(%rsp)
  6faa31:	00 00 
  6faa33:	41 b5 01             	mov    $0x1,%r13b
  6faa36:	44 0f b6 c0          	movzbl %al,%r8d
  6faa3a:	41 b4 01             	mov    $0x1,%r12b
  6faa3d:	48 8d bc 24 20 07 00 	lea    0x720(%rsp),%rdi
  6faa44:	00 
  6faa45:	4c 89 f6             	mov    %r14,%rsi
  6faa48:	48 8d 94 24 90 03 00 	lea    0x390(%rsp),%rdx
  6faa4f:	00 
  6faa50:	48 8d 8c 24 a0 01 00 	lea    0x1a0(%rsp),%rcx
  6faa57:	00 
  6faa58:	ff 15 92 11 39 00    	call   *0x391192(%rip)        # a8bbf0 <_DYNAMIC+0x708>
  6faa5e:	4c 8b 7c 24 58       	mov    0x58(%rsp),%r15
  6faa63:	4d 85 ff             	test   %r15,%r15
  6faa66:	0f b6 ac 24 c8 02 00 	movzbl 0x2c8(%rsp),%ebp
  6faa6d:	00 
  6faa6e:	74 3b                	je     6faaab <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3aab>
  6faa70:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  6faa77:	00 
  6faa78:	48 8b 00             	mov    (%rax),%rax
  6faa7b:	48 85 c0             	test   %rax,%rax
  6faa7e:	74 05                	je     6faa85 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3a85>
  6faa80:	4c 89 ff             	mov    %r15,%rdi
  6faa83:	ff d0                	call   *%rax
  6faa85:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  6faa8c:	00 
  6faa8d:	48 8b 70 08          	mov    0x8(%rax),%rsi
  6faa91:	48 85 f6             	test   %rsi,%rsi
  6faa94:	74 15                	je     6faaab <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3aab>
  6faa96:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  6faa9d:	00 
  6faa9e:	48 8b 50 10          	mov    0x10(%rax),%rdx
  6faaa2:	4c 89 ff             	mov    %r15,%rdi
  6faaa5:	ff 15 8d 0c 39 00    	call   *0x390c8d(%rip)        # a8b738 <_DYNAMIC+0x250>
  6faaab:	4c 8b bc 24 08 01 00 	mov    0x108(%rsp),%r15
  6faab2:	00 
  6faab3:	4d 85 ff             	test   %r15,%r15
  6faab6:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  6faabb:	74 51                	je     6fab0e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3b0e>
  6faabd:	4c 8b ac 24 10 01 00 	mov    0x110(%rsp),%r13
  6faac4:	00 
  6faac5:	4c 8b a4 24 70 05 00 	mov    0x570(%rsp),%r12
  6faacc:	00 
  6faacd:	4c 3b a4 24 60 05 00 	cmp    0x560(%rsp),%r12
  6faad4:	00 
  6faad5:	75 0d                	jne    6faae4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3ae4>
  6faad7:	48 8d bc 24 60 05 00 	lea    0x560(%rsp),%rdi
  6faade:	00 
  6faadf:	e8 cc 5f 02 00       	call   720ab0 <<alloc::raw_vec::RawVec<[core::option::Option<gpui::source::FieldId>; 2]>>::grow_one>
  6faae4:	48 8b 84 24 68 05 00 	mov    0x568(%rsp),%rax
  6faaeb:	00 
  6faaec:	4c 89 e1             	mov    %r12,%rcx
  6faaef:	48 c1 e1 04          	shl    $0x4,%rcx
  6faaf3:	4c 89 3c 08          	mov    %r15,(%rax,%rcx,1)
  6faaf7:	4c 89 6c 08 08       	mov    %r13,0x8(%rax,%rcx,1)
  6faafc:	49 8d 44 24 01       	lea    0x1(%r12),%rax
  6fab01:	48 89 84 24 70 05 00 	mov    %rax,0x570(%rsp)
  6fab08:	00 
  6fab09:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  6fab0e:	3d a0 86 01 00       	cmp    $0x186a0,%eax
  6fab13:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6fab18:	0f 83 38 2d 00 00    	jae    6fd856 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6856>
  6fab1e:	40 84 ed             	test   %bpl,%bpl
  6fab21:	74 34                	je     6fab57 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3b57>
  6fab23:	3d 9f 86 01 00       	cmp    $0x1869f,%eax
  6fab28:	0f 87 13 2d 00 00    	ja     6fd841 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6841>
  6fab2e:	48 ff c0             	inc    %rax
  6fab31:	4d 85 ff             	test   %r15,%r15
  6fab34:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  6fab39:	75 28                	jne    6fab63 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3b63>
  6fab3b:	31 db                	xor    %ebx,%ebx
  6fab3d:	48 83 bc 24 60 04 00 	cmpq   $0xfffffffffffffffe,0x460(%rsp)
  6fab44:	00 fe 
  6fab46:	41 0f 94 c5          	sete   %r13b
  6fab4a:	41 bc ff ff ff ff    	mov    $0xffffffff,%r12d
  6fab50:	75 4c                	jne    6fab9e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3b9e>
  6fab52:	e9 aa 01 00 00       	jmp    6fad01 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d01>
  6fab57:	31 c0                	xor    %eax,%eax
  6fab59:	4d 85 ff             	test   %r15,%r15
  6fab5c:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  6fab61:	74 d8                	je     6fab3b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3b3b>
  6fab63:	49 81 fc 9f 86 01 00 	cmp    $0x1869f,%r12
  6fab6a:	0f 87 d1 2c 00 00    	ja     6fd841 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6841>
  6fab70:	49 c1 e4 22          	shl    $0x22,%r12
  6fab74:	48 b8 ff ff ff ff 03 	movabs $0x3ffffffff,%rax
  6fab7b:	00 00 00 
  6fab7e:	4a 8d 1c 20          	lea    (%rax,%r12,1),%rbx
  6fab82:	48 ff c3             	inc    %rbx
  6fab85:	48 83 bc 24 60 04 00 	cmpq   $0xfffffffffffffffe,0x460(%rsp)
  6fab8c:	00 fe 
  6fab8e:	41 0f 94 c5          	sete   %r13b
  6fab92:	41 bc ff ff ff ff    	mov    $0xffffffff,%r12d
  6fab98:	0f 84 63 01 00 00    	je     6fad01 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d01>
  6fab9e:	0f 28 84 24 a0 04 00 	movaps 0x4a0(%rsp),%xmm0
  6faba5:	00 
  6faba6:	0f 29 84 24 d0 03 00 	movaps %xmm0,0x3d0(%rsp)
  6fabad:	00 
  6fabae:	66 0f 6f 84 24 60 04 	movdqa 0x460(%rsp),%xmm0
  6fabb5:	00 00 
  6fabb7:	66 0f 6f 8c 24 70 04 	movdqa 0x470(%rsp),%xmm1
  6fabbe:	00 00 
  6fabc0:	66 0f 6f 94 24 80 04 	movdqa 0x480(%rsp),%xmm2
  6fabc7:	00 00 
  6fabc9:	0f 28 9c 24 90 04 00 	movaps 0x490(%rsp),%xmm3
  6fabd0:	00 
  6fabd1:	0f 29 9c 24 c0 03 00 	movaps %xmm3,0x3c0(%rsp)
  6fabd8:	00 
  6fabd9:	66 0f 7f 94 24 b0 03 	movdqa %xmm2,0x3b0(%rsp)
  6fabe0:	00 00 
  6fabe2:	66 0f 7f 8c 24 a0 03 	movdqa %xmm1,0x3a0(%rsp)
  6fabe9:	00 00 
  6fabeb:	66 0f 7f 84 24 90 03 	movdqa %xmm0,0x390(%rsp)
  6fabf2:	00 00 
  6fabf4:	48 8b b4 24 58 02 00 	mov    0x258(%rsp),%rsi
  6fabfb:	00 
  6fabfc:	49 39 f6             	cmp    %rsi,%r14
  6fabff:	0f 83 d4 2f 00 00    	jae    6fdbd9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6bd9>
  6fac05:	48 8b 84 24 50 02 00 	mov    0x250(%rsp),%rax
  6fac0c:	00 
  6fac0d:	4a 8b 04 f0          	mov    (%rax,%r14,8),%rax
  6fac11:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
  6fac18:	00 
  6fac19:	4c 8b a4 24 88 05 00 	mov    0x588(%rsp),%r12
  6fac20:	00 
  6fac21:	48 8b 84 24 d0 03 00 	mov    0x3d0(%rsp),%rax
  6fac28:	00 
  6fac29:	48 89 84 24 e0 01 00 	mov    %rax,0x1e0(%rsp)
  6fac30:	00 
  6fac31:	48 8b 84 24 d8 03 00 	mov    0x3d8(%rsp),%rax
  6fac38:	00 
  6fac39:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
  6fac40:	00 
  6fac41:	66 0f 6f 84 24 90 03 	movdqa 0x390(%rsp),%xmm0
  6fac48:	00 00 
  6fac4a:	66 0f 6f 8c 24 a0 03 	movdqa 0x3a0(%rsp),%xmm1
  6fac51:	00 00 
  6fac53:	66 0f 6f 94 24 b0 03 	movdqa 0x3b0(%rsp),%xmm2
  6fac5a:	00 00 
  6fac5c:	0f 28 9c 24 c0 03 00 	movaps 0x3c0(%rsp),%xmm3
  6fac63:	00 
  6fac64:	0f 29 9c 24 d0 01 00 	movaps %xmm3,0x1d0(%rsp)
  6fac6b:	00 
  6fac6c:	66 0f 7f 94 24 c0 01 	movdqa %xmm2,0x1c0(%rsp)
  6fac73:	00 00 
  6fac75:	66 0f 7f 8c 24 b0 01 	movdqa %xmm1,0x1b0(%rsp)
  6fac7c:	00 00 
  6fac7e:	66 0f 7f 84 24 a0 01 	movdqa %xmm0,0x1a0(%rsp)
  6fac85:	00 00 
  6fac87:	4c 3b a4 24 78 05 00 	cmp    0x578(%rsp),%r12
  6fac8e:	00 
  6fac8f:	75 0d                	jne    6fac9e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3c9e>
  6fac91:	48 8d bc 24 78 05 00 	lea    0x578(%rsp),%rdi
  6fac98:	00 
  6fac99:	e8 62 5f 02 00       	call   720c00 <<alloc::raw_vec::RawVec<core::option::Option<gpui::runtime::TextSite>>>::grow_one>
  6fac9e:	48 8b 84 24 80 05 00 	mov    0x580(%rsp),%rax
  6faca5:	00 
  6faca6:	4b 8d 0c a4          	lea    (%r12,%r12,4),%rcx
  6facaa:	48 c1 e1 04          	shl    $0x4,%rcx
  6facae:	0f 28 84 24 e0 01 00 	movaps 0x1e0(%rsp),%xmm0
  6facb5:	00 
  6facb6:	0f 11 44 08 40       	movups %xmm0,0x40(%rax,%rcx,1)
  6facbb:	66 0f 6f 84 24 a0 01 	movdqa 0x1a0(%rsp),%xmm0
  6facc2:	00 00 
  6facc4:	66 0f 6f 8c 24 b0 01 	movdqa 0x1b0(%rsp),%xmm1
  6faccb:	00 00 
  6faccd:	66 0f 6f 94 24 c0 01 	movdqa 0x1c0(%rsp),%xmm2
  6facd4:	00 00 
  6facd6:	0f 28 9c 24 d0 01 00 	movaps 0x1d0(%rsp),%xmm3
  6facdd:	00 
  6facde:	0f 11 5c 08 30       	movups %xmm3,0x30(%rax,%rcx,1)
  6face3:	f3 0f 7f 54 08 20    	movdqu %xmm2,0x20(%rax,%rcx,1)
  6face9:	f3 0f 7f 4c 08 10    	movdqu %xmm1,0x10(%rax,%rcx,1)
  6facef:	f3 0f 7f 04 08       	movdqu %xmm0,(%rax,%rcx,1)
  6facf4:	49 8d 44 24 01       	lea    0x1(%r12),%rax
  6facf9:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
  6fad00:	00 
  6fad01:	80 bc 24 c0 02 00 00 	cmpb   $0x0,0x2c0(%rsp)
  6fad08:	00 
  6fad09:	74 3a                	je     6fad45 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d45>
  6fad0b:	0f b6 84 24 20 01 00 	movzbl 0x120(%rsp),%eax
  6fad12:	00 
  6fad13:	8d 48 fe             	lea    -0x2(%rax),%ecx
  6fad16:	83 f8 02             	cmp    $0x2,%eax
  6fad19:	0f b6 c9             	movzbl %cl,%ecx
  6fad1c:	ba 08 00 00 00       	mov    $0x8,%edx
  6fad21:	0f 42 ca             	cmovb  %edx,%ecx
  6fad24:	44 0f b6 f1          	movzbl %cl,%r14d
  6fad28:	48 8d 15 c9 d0 95 ff 	lea    -0x6a2f37(%rip),%rdx        # 57df8 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x150>
  6fad2f:	4a 63 0c b2          	movslq (%rdx,%r14,4),%rcx
  6fad33:	48 01 d1             	add    %rdx,%rcx
  6fad36:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  6fad3b:	ff e1                	jmp    *%rcx
  6fad3d:	41 be 01 00 00 00    	mov    $0x1,%r14d
  6fad43:	eb 5c                	jmp    6fada1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3da1>
  6fad45:	45 31 e4             	xor    %r12d,%r12d
  6fad48:	0f b6 b4 24 00 02 00 	movzbl 0x200(%rsp),%esi
  6fad4f:	00 
  6fad50:	48 8b bc 24 98 01 00 	mov    0x198(%rsp),%rdi
  6fad57:	00 
  6fad58:	ff 15 9a 0e 39 00    	call   *0x390e9a(%rip)        # a8bbf8 <_DYNAMIC+0x710>
  6fad5e:	41 89 c6             	mov    %eax,%r14d
  6fad61:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  6fad66:	eb 57                	jmp    6fadbf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3dbf>
  6fad68:	41 be 04 00 00 00    	mov    $0x4,%r14d
  6fad6e:	eb 31                	jmp    6fada1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3da1>
  6fad70:	41 be 02 00 00 00    	mov    $0x2,%r14d
  6fad76:	eb 29                	jmp    6fada1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3da1>
  6fad78:	41 be 03 00 00 00    	mov    $0x3,%r14d
  6fad7e:	eb 21                	jmp    6fada1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3da1>
  6fad80:	41 be 07 00 00 00    	mov    $0x7,%r14d
  6fad86:	eb 19                	jmp    6fada1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3da1>
  6fad88:	41 be 05 00 00 00    	mov    $0x5,%r14d
  6fad8e:	eb 11                	jmp    6fada1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3da1>
  6fad90:	41 be 06 00 00 00    	mov    $0x6,%r14d
  6fad96:	eb 09                	jmp    6fada1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3da1>
  6fad98:	83 e0 01             	and    $0x1,%eax
  6fad9b:	83 c8 08             	or     $0x8,%eax
  6fad9e:	41 89 c6             	mov    %eax,%r14d
  6fada1:	41 83 fc ff          	cmp    $0xffffffff,%r12d
  6fada5:	74 18                	je     6fadbf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3dbf>
  6fada7:	41 81 fc a0 86 01 00 	cmp    $0x186a0,%r12d
  6fadae:	0f 83 22 2b 00 00    	jae    6fd8d6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x68d6>
  6fadb4:	41 c1 e4 04          	shl    $0x4,%r12d
  6fadb8:	41 83 c4 10          	add    $0x10,%r12d
  6fadbc:	45 09 e6             	or     %r12d,%r14d
  6fadbf:	48 3b 54 24 20       	cmp    0x20(%rsp),%rdx
  6fadc4:	b8 00 00 00 00       	mov    $0x0,%eax
  6fadc9:	48 0f 44 d0          	cmove  %rax,%rdx
  6fadcd:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
  6fadd2:	40 0f 94 c5          	sete   %bpl
  6fadd6:	4c 8b bc 24 90 01 00 	mov    0x190(%rsp),%r15
  6faddd:	00 
  6fadde:	4c 3b bc 24 80 01 00 	cmp    0x180(%rsp),%r15
  6fade5:	00 
  6fade6:	75 10                	jne    6fadf8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3df8>
  6fade8:	45 31 e4             	xor    %r12d,%r12d
  6fadeb:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  6fadf2:	00 
  6fadf3:	e8 58 5f 02 00       	call   720d50 <<alloc::raw_vec::RawVec<gpui::style_port::Draft>>::grow_one>
  6fadf8:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  6fadfd:	48 c1 e0 11          	shl    $0x11,%rax
  6fae01:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  6fae06:	48 01 c2             	add    %rax,%rdx
  6fae09:	48 01 da             	add    %rbx,%rdx
  6fae0c:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  6fae13:	00 
  6fae14:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
  6fae18:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  6fae1d:	48 89 34 c8          	mov    %rsi,(%rax,%rcx,8)
  6fae21:	48 89 54 c8 08       	mov    %rdx,0x8(%rax,%rcx,8)
  6fae26:	44 89 74 c8 10       	mov    %r14d,0x10(%rax,%rcx,8)
  6fae2b:	48 8b 94 24 78 01 00 	mov    0x178(%rsp),%rdx
  6fae32:	00 
  6fae33:	89 54 c8 14          	mov    %edx,0x14(%rax,%rcx,8)
  6fae37:	49 ff c7             	inc    %r15
  6fae3a:	4c 89 bc 24 90 01 00 	mov    %r15,0x190(%rsp)
  6fae41:	00 
  6fae42:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  6fae47:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
  6fae4b:	48 83 f8 fc          	cmp    $0xfffffffffffffffc,%rax
  6fae4f:	77 13                	ja     6fae64 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3e64>
  6fae51:	ba 01 00 00 00       	mov    $0x1,%edx
  6fae56:	48 8b bc 24 08 04 00 	mov    0x408(%rsp),%rdi
  6fae5d:	00 
  6fae5e:	ff 15 d4 08 39 00    	call   *0x3908d4(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fae64:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
  6fae6b:	00 
  6fae6c:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fae70:	4c 8b bc 24 88 00 00 	mov    0x88(%rsp),%r15
  6fae77:	00 
  6fae78:	4c 8b 64 24 40       	mov    0x40(%rsp),%r12
  6fae7d:	74 18                	je     6fae97 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3e97>
  6fae7f:	48 85 f6             	test   %rsi,%rsi
  6fae82:	7e 13                	jle    6fae97 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3e97>
  6fae84:	48 8b bc 24 98 00 00 	mov    0x98(%rsp),%rdi
  6fae8b:	00 
  6fae8c:	ba 01 00 00 00       	mov    $0x1,%edx
  6fae91:	ff 15 a1 08 39 00    	call   *0x3908a1(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fae97:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  6fae9e:	00 
  6fae9f:	e8 dc a1 fe ff       	call   6e5080 <core::ptr::drop_glue::<gpui::element::ComponentBoundaries>>
  6faea4:	40 0a 6c 24 18       	or     0x18(%rsp),%bpl
  6faea9:	40 0f b6 c5          	movzbl %bpl,%eax
  6faead:	48 01 84 24 18 05 00 	add    %rax,0x518(%rsp)
  6faeb4:	00 
  6faeb5:	4c 8b b4 24 08 02 00 	mov    0x208(%rsp),%r14
  6faebc:	00 
  6faebd:	48 8b 84 24 20 05 00 	mov    0x520(%rsp),%rax
  6faec4:	00 
  6faec5:	48 89 c6             	mov    %rax,%rsi
  6faec8:	48 3b 84 24 58 08 00 	cmp    0x858(%rsp),%rax
  6faecf:	00 
  6faed0:	4c 8b ac 24 90 02 00 	mov    0x290(%rsp),%r13
  6faed7:	00 
  6faed8:	0f 85 cd e5 ff ff    	jne    6f94ab <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x24ab>
  6faede:	eb 2d                	jmp    6faf0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3f0d>
  6faee0:	48 8d 84 24 08 06 00 	lea    0x608(%rsp),%rax
  6faee7:	00 
  6faee8:	e9 ff f6 ff ff       	jmp    6fa5ec <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x35ec>
  6faeed:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6faef1:	ff 15 89 08 39 00    	call   *0x390889(%rip)        # a8b780 <_DYNAMIC+0x298>
  6faef7:	e9 25 f5 ff ff       	jmp    6fa421 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3421>
  6faefc:	48 c7 84 24 18 05 00 	movq   $0x0,0x518(%rsp)
  6faf03:	00 00 00 00 00 
  6faf08:	4c 8b 64 24 40       	mov    0x40(%rsp),%r12
  6faf0d:	b3 01                	mov    $0x1,%bl
  6faf0f:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  6faf16:	00 
  6faf17:	40 b5 01             	mov    $0x1,%bpl
  6faf1a:	e8 01 45 02 00       	call   71f420 <<alloc::vec::into_iter::IntoIter<gpui::element::DraftNode> as core::ops::drop::Drop>::drop>
  6faf1f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6faf24:	48 8d b8 f0 05 00 00 	lea    0x5f0(%rax),%rdi
  6faf2b:	48 8b 84 24 c0 04 00 	mov    0x4c0(%rsp),%rax
  6faf32:	00 
  6faf33:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6faf3a:	00 
  6faf3b:	66 0f 6f 84 24 b0 04 	movdqa 0x4b0(%rsp),%xmm0
  6faf42:	00 00 
  6faf44:	66 0f 7f 84 24 90 00 	movdqa %xmm0,0x90(%rsp)
  6faf4b:	00 00 
  6faf4d:	31 ed                	xor    %ebp,%ebp
  6faf4f:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6faf56:	00 
  6faf57:	ff 15 a3 0c 39 00    	call   *0x390ca3(%rip)        # a8bc00 <_DYNAMIC+0x718>
  6faf5d:	4d 85 e4             	test   %r12,%r12
  6faf60:	74 18                	je     6faf7a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3f7a>
  6faf62:	44 89 e0             	mov    %r12d,%eax
  6faf65:	83 e0 03             	and    $0x3,%eax
  6faf68:	49 83 fc 04          	cmp    $0x4,%r12
  6faf6c:	4c 8b 44 24 78       	mov    0x78(%rsp),%r8
  6faf71:	73 11                	jae    6faf84 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3f84>
  6faf73:	31 c9                	xor    %ecx,%ecx
  6faf75:	45 31 f6             	xor    %r14d,%r14d
  6faf78:	eb 5a                	jmp    6fafd4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3fd4>
  6faf7a:	45 31 f6             	xor    %r14d,%r14d
  6faf7d:	4c 8b 44 24 78       	mov    0x78(%rsp),%r8
  6faf82:	eb 78                	jmp    6faffc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3ffc>
  6faf84:	48 ba 00 00 00 00 00 	movabs $0x800000000000000,%rdx
  6faf8b:	00 00 08 
  6faf8e:	48 83 c2 fc          	add    $0xfffffffffffffffc,%rdx
  6faf92:	4c 21 e2             	and    %r12,%rdx
  6faf95:	31 c9                	xor    %ecx,%ecx
  6faf97:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  6faf9c:	45 31 f6             	xor    %r14d,%r14d
  6faf9f:	48 83 3e 01          	cmpq   $0x1,(%rsi)
  6fafa3:	49 83 de ff          	sbb    $0xffffffffffffffff,%r14
  6fafa7:	48 83 7e 18 01       	cmpq   $0x1,0x18(%rsi)
  6fafac:	49 83 de ff          	sbb    $0xffffffffffffffff,%r14
  6fafb0:	48 83 7e 30 01       	cmpq   $0x1,0x30(%rsi)
  6fafb5:	49 83 de ff          	sbb    $0xffffffffffffffff,%r14
  6fafb9:	48 83 7e 48 01       	cmpq   $0x1,0x48(%rsi)
  6fafbe:	49 83 de ff          	sbb    $0xffffffffffffffff,%r14
  6fafc2:	48 83 c1 04          	add    $0x4,%rcx
  6fafc6:	48 83 c6 60          	add    $0x60,%rsi
  6fafca:	48 39 ca             	cmp    %rcx,%rdx
  6fafcd:	75 d0                	jne    6faf9f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3f9f>
  6fafcf:	48 85 c0             	test   %rax,%rax
  6fafd2:	74 28                	je     6faffc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3ffc>
  6fafd4:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  6fafd8:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  6fafdd:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
  6fafe1:	c1 e0 03             	shl    $0x3,%eax
  6fafe4:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  6fafe8:	31 d2                	xor    %edx,%edx
  6fafea:	48 83 3c 11 01       	cmpq   $0x1,(%rcx,%rdx,1)
  6fafef:	49 83 de ff          	sbb    $0xffffffffffffffff,%r14
  6faff3:	48 83 c2 18          	add    $0x18,%rdx
  6faff7:	48 39 d0             	cmp    %rdx,%rax
  6faffa:	75 ee                	jne    6fafea <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3fea>
  6faffc:	4c 03 b4 24 18 05 00 	add    0x518(%rsp),%r14
  6fb003:	00 
  6fb004:	4d 85 c0             	test   %r8,%r8
  6fb007:	74 31                	je     6fb03a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x403a>
  6fb009:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fb00e:	48 8d b8 e8 01 00 00 	lea    0x1e8(%rax),%rdi
  6fb015:	4c 89 c6             	mov    %r8,%rsi
  6fb018:	31 ed                	xor    %ebp,%ebp
  6fb01a:	e8 61 41 ff ff       	call   6ef180 <<gpui::runtime::identity_index::IdentityIndex>::required>
  6fb01f:	4c 39 e0             	cmp    %r12,%rax
  6fb022:	0f 83 ce 2c 00 00    	jae    6fdcf6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cf6>
  6fb028:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  6fb02c:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  6fb031:	48 83 3c c1 01       	cmpq   $0x1,(%rcx,%rax,8)
  6fb036:	49 83 d6 00          	adc    $0x0,%r14
  6fb03a:	b0 01                	mov    $0x1,%al
  6fb03c:	48 8b 8c 24 a8 02 00 	mov    0x2a8(%rsp),%rcx
  6fb043:	00 
  6fb044:	48 3b 8c 24 90 01 00 	cmp    0x190(%rsp),%rcx
  6fb04b:	00 
  6fb04c:	75 72                	jne    6fb0c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x40c0>
  6fb04e:	48 83 bc 24 a8 02 00 	cmpq   $0x0,0x2a8(%rsp)
  6fb055:	00 00 
  6fb057:	74 65                	je     6fb0be <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x40be>
  6fb059:	48 8b 8c 24 88 01 00 	mov    0x188(%rsp),%rcx
  6fb060:	00 
  6fb061:	49 ff cc             	dec    %r12
  6fb064:	31 d2                	xor    %edx,%edx
  6fb066:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  6fb06d:	00 
  6fb06e:	48 8b 04 d0          	mov    (%rax,%rdx,8),%rax
  6fb072:	48 3b 01             	cmp    (%rcx),%rax
  6fb075:	0f 95 c0             	setne  %al
  6fb078:	75 46                	jne    6fb0c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x40c0>
  6fb07a:	48 83 c1 18          	add    $0x18,%rcx
  6fb07e:	49 39 d4             	cmp    %rdx,%r12
  6fb081:	48 8d 52 01          	lea    0x1(%rdx),%rdx
  6fb085:	75 df                	jne    6fb066 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4066>
  6fb087:	eb 37                	jmp    6fb0c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x40c0>
  6fb089:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6fb08e:	48 c7 00 1d 00 00 00 	movq   $0x1d,(%rax)
  6fb095:	e9 a2 21 00 00       	jmp    6fd23c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x623c>
  6fb09a:	48 8d 8c 24 98 00 00 	lea    0x98(%rsp),%rcx
  6fb0a1:	00 
  6fb0a2:	0f 10 01             	movups (%rcx),%xmm0
  6fb0a5:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6fb0aa:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
  6fb0ae:	48 c7 01 20 00 00 00 	movq   $0x20,(%rcx)
  6fb0b5:	48 89 41 08          	mov    %rax,0x8(%rcx)
  6fb0b9:	e9 8a 21 00 00       	jmp    6fd248 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6248>
  6fb0be:	31 c0                	xor    %eax,%eax
  6fb0c0:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6fb0c5:	08 81 49 07 00 00    	or     %al,0x749(%rcx)
  6fb0cb:	08 81 4b 07 00 00    	or     %al,0x74b(%rcx)
  6fb0d1:	48 c7 84 24 30 05 00 	movq   $0x0,0x530(%rsp)
  6fb0d8:	00 00 00 00 00 
  6fb0dd:	48 c7 84 24 40 05 00 	movq   $0x0,0x540(%rsp)
  6fb0e4:	00 00 00 00 00 
  6fb0e9:	48 c7 84 24 08 07 00 	movq   $0x0,0x708(%rsp)
  6fb0f0:	00 00 00 00 00 
  6fb0f5:	48 c7 84 24 18 07 00 	movq   $0x0,0x718(%rsp)
  6fb0fc:	00 00 00 00 00 
  6fb101:	48 8b 94 24 f0 05 00 	mov    0x5f0(%rsp),%rdx
  6fb108:	00 
  6fb109:	4c 8b ac 24 f8 05 00 	mov    0x5f8(%rsp),%r13
  6fb110:	00 
  6fb111:	48 8b 84 24 00 06 00 	mov    0x600(%rsp),%rax
  6fb118:	00 
  6fb119:	48 69 f0 a8 00 00 00 	imul   $0xa8,%rax,%rsi
  6fb120:	4c 01 ee             	add    %r13,%rsi
  6fb123:	4c 89 ac 24 90 03 00 	mov    %r13,0x390(%rsp)
  6fb12a:	00 
  6fb12b:	4c 89 ac 24 98 03 00 	mov    %r13,0x398(%rsp)
  6fb132:	00 
  6fb133:	48 89 94 24 b0 02 00 	mov    %rdx,0x2b0(%rsp)
  6fb13a:	00 
  6fb13b:	48 89 94 24 a0 03 00 	mov    %rdx,0x3a0(%rsp)
  6fb142:	00 
  6fb143:	48 89 b4 24 00 02 00 	mov    %rsi,0x200(%rsp)
  6fb14a:	00 
  6fb14b:	48 89 b4 24 a8 03 00 	mov    %rsi,0x3a8(%rsp)
  6fb152:	00 
  6fb153:	4c 89 ac 24 b8 02 00 	mov    %r13,0x2b8(%rsp)
  6fb15a:	00 
  6fb15b:	48 85 c0             	test   %rax,%rax
  6fb15e:	4c 89 b4 24 08 02 00 	mov    %r14,0x208(%rsp)
  6fb165:	00 
  6fb166:	0f 84 8d 07 00 00    	je     6fb8f9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x48f9>
  6fb16c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fb171:	48 05 78 06 00 00    	add    $0x678,%rax
  6fb177:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6fb17c:	48 8b 84 24 b8 02 00 	mov    0x2b8(%rsp),%rax
  6fb183:	00 
  6fb184:	48 8b 8c 24 40 02 00 	mov    0x240(%rsp),%rcx
  6fb18b:	00 
  6fb18c:	eb 11                	jmp    6fb19f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x419f>
  6fb18e:	48 89 d8             	mov    %rbx,%rax
  6fb191:	48 3b 9c 24 00 02 00 	cmp    0x200(%rsp),%rbx
  6fb198:	00 
  6fb199:	0f 84 4a 07 00 00    	je     6fb8e9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x48e9>
  6fb19f:	4c 8d a8 a8 00 00 00 	lea    0xa8(%rax),%r13
  6fb1a6:	48 8b 10             	mov    (%rax),%rdx
  6fb1a9:	48 83 fa 02          	cmp    $0x2,%rdx
  6fb1ad:	0f 84 3e 07 00 00    	je     6fb8f1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x48f1>
  6fb1b3:	48 89 94 24 10 04 00 	mov    %rdx,0x410(%rsp)
  6fb1ba:	00 
  6fb1bb:	48 8b 50 18          	mov    0x18(%rax),%rdx
  6fb1bf:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
  6fb1c4:	48 8b 50 20          	mov    0x20(%rax),%rdx
  6fb1c8:	48 8b 70 30          	mov    0x30(%rax),%rsi
  6fb1cc:	48 89 74 24 40       	mov    %rsi,0x40(%rsp)
  6fb1d1:	48 8b 70 38          	mov    0x38(%rax),%rsi
  6fb1d5:	48 89 74 24 68       	mov    %rsi,0x68(%rsp)
  6fb1da:	48 8b 70 40          	mov    0x40(%rax),%rsi
  6fb1de:	48 89 74 24 50       	mov    %rsi,0x50(%rsp)
  6fb1e3:	48 8b 70 48          	mov    0x48(%rax),%rsi
  6fb1e7:	48 89 b4 24 10 02 00 	mov    %rsi,0x210(%rsp)
  6fb1ee:	00 
  6fb1ef:	48 8b 70 50          	mov    0x50(%rax),%rsi
  6fb1f3:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  6fb1f8:	0f 10 40 58          	movups 0x58(%rax),%xmm0
  6fb1fc:	0f 29 84 24 80 03 00 	movaps %xmm0,0x380(%rsp)
  6fb203:	00 
  6fb204:	0f 10 40 68          	movups 0x68(%rax),%xmm0
  6fb208:	0f 29 84 24 90 02 00 	movaps %xmm0,0x290(%rsp)
  6fb20f:	00 
  6fb210:	48 8b 70 78          	mov    0x78(%rax),%rsi
  6fb214:	48 89 74 24 48       	mov    %rsi,0x48(%rsp)
  6fb219:	48 8b b0 80 00 00 00 	mov    0x80(%rax),%rsi
  6fb220:	48 89 b4 24 78 01 00 	mov    %rsi,0x178(%rsp)
  6fb227:	00 
  6fb228:	48 8b b0 88 00 00 00 	mov    0x88(%rax),%rsi
  6fb22f:	48 89 74 24 78       	mov    %rsi,0x78(%rsp)
  6fb234:	4c 8b a0 90 00 00 00 	mov    0x90(%rax),%r12
  6fb23b:	48 8b b0 98 00 00 00 	mov    0x98(%rax),%rsi
  6fb242:	4c 8b b8 a0 00 00 00 	mov    0xa0(%rax),%r15
  6fb249:	66 0f 10 40 08       	movupd 0x8(%rax),%xmm0
  6fb24e:	66 0f 29 84 24 60 04 	movapd %xmm0,0x460(%rsp)
  6fb255:	00 00 
  6fb257:	48 8b bc 24 90 01 00 	mov    0x190(%rsp),%rdi
  6fb25e:	00 
  6fb25f:	48 89 b4 24 98 01 00 	mov    %rsi,0x198(%rsp)
  6fb266:	00 
  6fb267:	48 89 bc 24 48 01 00 	mov    %rdi,0x148(%rsp)
  6fb26e:	00 
  6fb26f:	48 39 fe             	cmp    %rdi,%rsi
  6fb272:	48 89 94 24 c0 02 00 	mov    %rdx,0x2c0(%rsp)
  6fb279:	00 
  6fb27a:	0f 83 26 28 00 00    	jae    6fdaa6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6aa6>
  6fb280:	48 8b 09             	mov    (%rcx),%rcx
  6fb283:	b0 01                	mov    $0x1,%al
  6fb285:	48 85 c9             	test   %rcx,%rcx
  6fb288:	4c 89 ac 24 c8 02 00 	mov    %r13,0x2c8(%rsp)
  6fb28f:	00 
  6fb290:	0f 84 4a 01 00 00    	je     6fb3e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43e0>
  6fb296:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6fb29b:	48 8b b2 50 06 00 00 	mov    0x650(%rdx),%rsi
  6fb2a2:	0f b7 b9 8a 05 00 00 	movzwl 0x58a(%rcx),%edi
  6fb2a9:	4c 6b c7 70          	imul   $0x70,%rdi,%r8
  6fb2ad:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
  6fb2b4:	31 d2                	xor    %edx,%edx
  6fb2b6:	45 31 d2             	xor    %r10d,%r10d
  6fb2b9:	49 89 cb             	mov    %rcx,%r11
  6fb2bc:	0f 1f 40 00          	nopl   0x0(%rax)
  6fb2c0:	49 39 d0             	cmp    %rdx,%r8
  6fb2c3:	74 3c                	je     6fb301 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4301>
  6fb2c5:	41 80 3b 00          	cmpb   $0x0,(%r11)
  6fb2c9:	75 33                	jne    6fb2fe <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x42fe>
  6fb2cb:	49 89 d9             	mov    %rbx,%r9
  6fb2ce:	49 ff c2             	inc    %r10
  6fb2d1:	4d 3b 7b 08          	cmp    0x8(%r11),%r15
  6fb2d5:	4d 8d 5b 10          	lea    0x10(%r11),%r11
  6fb2d9:	40 0f 97 c5          	seta   %bpl
  6fb2dd:	40 80 dd 00          	sbb    $0x0,%bpl
  6fb2e1:	48 83 c2 70          	add    $0x70,%rdx
  6fb2e5:	48 ff c3             	inc    %rbx
  6fb2e8:	40 80 fd 01          	cmp    $0x1,%bpl
  6fb2ec:	74 d2                	je     6fb2c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x42c0>
  6fb2ee:	40 0f b6 fd          	movzbl %bpl,%edi
  6fb2f2:	85 ff                	test   %edi,%edi
  6fb2f4:	74 1f                	je     6fb315 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4315>
  6fb2f6:	49 ff c1             	inc    %r9
  6fb2f9:	4c 89 cf             	mov    %r9,%rdi
  6fb2fc:	eb 03                	jmp    6fb301 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4301>
  6fb2fe:	4c 89 d7             	mov    %r10,%rdi
  6fb301:	48 83 ee 01          	sub    $0x1,%rsi
  6fb305:	0f 82 d5 00 00 00    	jb     6fb3e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43e0>
  6fb30b:	48 8b 8c f9 90 05 00 	mov    0x590(%rcx,%rdi,8),%rcx
  6fb312:	00 
  6fb313:	eb 8d                	jmp    6fb2a2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x42a2>
  6fb315:	83 7c 11 40 02       	cmpl   $0x2,0x40(%rcx,%rdx,1)
  6fb31a:	0f 84 c0 00 00 00    	je     6fb3e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43e0>
  6fb320:	f2 0f 10 84 11 88 00 	movsd  0x88(%rcx,%rdx,1),%xmm0
  6fb327:	00 00 
  6fb329:	66 0f 28 8c 24 80 03 	movapd 0x380(%rsp),%xmm1
  6fb330:	00 00 
  6fb332:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
  6fb336:	0f 85 a4 00 00 00    	jne    6fb3e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43e0>
  6fb33c:	0f 8a 9e 00 00 00    	jp     6fb3e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43e0>
  6fb342:	f2 0f 10 84 11 90 00 	movsd  0x90(%rcx,%rdx,1),%xmm0
  6fb349:	00 00 
  6fb34b:	66 0f 15 c9          	unpckhpd %xmm1,%xmm1
  6fb34f:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
  6fb353:	0f 85 87 00 00 00    	jne    6fb3e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43e0>
  6fb359:	0f 8a 81 00 00 00    	jp     6fb3e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43e0>
  6fb35f:	f2 0f 10 84 11 98 00 	movsd  0x98(%rcx,%rdx,1),%xmm0
  6fb366:	00 00 
  6fb368:	66 0f 28 8c 24 90 02 	movapd 0x290(%rsp),%xmm1
  6fb36f:	00 00 
  6fb371:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
  6fb375:	75 69                	jne    6fb3e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43e0>
  6fb377:	7a 67                	jp     6fb3e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43e0>
  6fb379:	f2 0f 10 84 11 a0 00 	movsd  0xa0(%rcx,%rdx,1),%xmm0
  6fb380:	00 00 
  6fb382:	66 0f 15 c9          	unpckhpd %xmm1,%xmm1
  6fb386:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
  6fb38a:	75 54                	jne    6fb3e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43e0>
  6fb38c:	7a 52                	jp     6fb3e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43e0>
  6fb38e:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  6fb393:	48 39 b4 11 80 00 00 	cmp    %rsi,0x80(%rcx,%rdx,1)
  6fb39a:	00 
  6fb39b:	75 43                	jne    6fb3e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43e0>
  6fb39d:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  6fb3a2:	48 39 74 11 60       	cmp    %rsi,0x60(%rcx,%rdx,1)
  6fb3a7:	75 37                	jne    6fb3e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43e0>
  6fb3a9:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  6fb3ae:	48 39 74 11 68       	cmp    %rsi,0x68(%rcx,%rdx,1)
  6fb3b3:	75 2b                	jne    6fb3e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43e0>
  6fb3b5:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  6fb3ba:	48 39 74 11 70       	cmp    %rsi,0x70(%rcx,%rdx,1)
  6fb3bf:	75 1f                	jne    6fb3e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43e0>
  6fb3c1:	48 8b b4 24 10 02 00 	mov    0x210(%rsp),%rsi
  6fb3c8:	00 
  6fb3c9:	48 39 74 11 78       	cmp    %rsi,0x78(%rcx,%rdx,1)
  6fb3ce:	75 10                	jne    6fb3e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43e0>
  6fb3d0:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  6fb3d5:	48 39 84 11 a8 00 00 	cmp    %rax,0xa8(%rcx,%rdx,1)
  6fb3dc:	00 
  6fb3dd:	0f 95 c0             	setne  %al
  6fb3e0:	48 8b 8c 24 88 01 00 	mov    0x188(%rsp),%rcx
  6fb3e7:	00 
  6fb3e8:	48 8b 94 24 98 01 00 	mov    0x198(%rsp),%rdx
  6fb3ef:	00 
  6fb3f0:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  6fb3f4:	48 8b 0c d1          	mov    (%rcx,%rdx,8),%rcx
  6fb3f8:	48 89 8c 24 20 05 00 	mov    %rcx,0x520(%rsp)
  6fb3ff:	00 
  6fb400:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6fb405:	08 81 4b 07 00 00    	or     %al,0x74b(%rcx)
  6fb40b:	4d 85 e4             	test   %r12,%r12
  6fb40e:	0f 84 74 02 00 00    	je     6fb688 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4688>
  6fb414:	49 c1 e4 05          	shl    $0x5,%r12
  6fb418:	4c 8b 6c 24 78       	mov    0x78(%rsp),%r13
  6fb41d:	4d 01 ec             	add    %r13,%r12
  6fb420:	eb 35                	jmp    6fb457 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4457>
  6fb422:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fb429:	1f 84 00 00 00 00 00 
  6fb430:	0f 10 84 24 a0 01 00 	movups 0x1a0(%rsp),%xmm0
  6fb437:	00 
  6fb438:	0f 10 8c 24 b0 01 00 	movups 0x1b0(%rsp),%xmm1
  6fb43f:	00 
  6fb440:	0f 11 4c 38 f0       	movups %xmm1,-0x10(%rax,%rdi,1)
  6fb445:	0f 11 44 38 e0       	movups %xmm0,-0x20(%rax,%rdi,1)
  6fb44a:	49 83 c5 20          	add    $0x20,%r13
  6fb44e:	4d 39 e5             	cmp    %r12,%r13
  6fb451:	0f 84 31 02 00 00    	je     6fb688 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4688>
  6fb457:	49 8b 7d 00          	mov    0x0(%r13),%rdi
  6fb45b:	48 8b b4 24 90 01 00 	mov    0x190(%rsp),%rsi
  6fb462:	00 
  6fb463:	48 39 f7             	cmp    %rsi,%rdi
  6fb466:	0f 83 44 25 00 00    	jae    6fd9b0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x69b0>
  6fb46c:	4d 8b 75 08          	mov    0x8(%r13),%r14
  6fb470:	41 8b 6d 10          	mov    0x10(%r13),%ebp
  6fb474:	f2 41 0f 10 45 14    	movsd  0x14(%r13),%xmm0
  6fb47a:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  6fb47f:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  6fb486:	00 
  6fb487:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  6fb48b:	48 8b 1c c8          	mov    (%rax,%rcx,8),%rbx
  6fb48f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fb494:	48 8b 80 60 06 00 00 	mov    0x660(%rax),%rax
  6fb49b:	48 85 c0             	test   %rax,%rax
  6fb49e:	0f 84 b1 00 00 00    	je     6fb555 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4555>
  6fb4a4:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6fb4a9:	48 8b 89 68 06 00 00 	mov    0x668(%rcx),%rcx
  6fb4b0:	0f b7 b8 c2 01 00 00 	movzwl 0x1c2(%rax),%edi
  6fb4b7:	41 89 f8             	mov    %edi,%r8d
  6fb4ba:	41 c1 e0 05          	shl    $0x5,%r8d
  6fb4be:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6fb4c5:	31 f6                	xor    %esi,%esi
  6fb4c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6fb4ce:	00 00 
  6fb4d0:	49 39 f0             	cmp    %rsi,%r8
  6fb4d3:	74 3b                	je     6fb510 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4510>
  6fb4d5:	48 3b 9c d0 70 01 00 	cmp    0x170(%rax,%rdx,8),%rbx
  6fb4dc:	00 
  6fb4dd:	41 0f 97 c1          	seta   %r9b
  6fb4e1:	41 80 d9 00          	sbb    $0x0,%r9b
  6fb4e5:	48 83 c6 20          	add    $0x20,%rsi
  6fb4e9:	48 ff c2             	inc    %rdx
  6fb4ec:	41 80 f9 01          	cmp    $0x1,%r9b
  6fb4f0:	74 de                	je     6fb4d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x44d0>
  6fb4f2:	41 0f b6 f9          	movzbl %r9b,%edi
  6fb4f6:	85 ff                	test   %edi,%edi
  6fb4f8:	74 36                	je     6fb530 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4530>
  6fb4fa:	48 83 e9 01          	sub    $0x1,%rcx
  6fb4fe:	73 19                	jae    6fb519 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4519>
  6fb500:	eb 53                	jmp    6fb555 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4555>
  6fb502:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fb509:	1f 84 00 00 00 00 00 
  6fb510:	48 89 fa             	mov    %rdi,%rdx
  6fb513:	48 83 e9 01          	sub    $0x1,%rcx
  6fb517:	72 3c                	jb     6fb555 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4555>
  6fb519:	48 8b 84 d0 c8 01 00 	mov    0x1c8(%rax,%rdx,8),%rax
  6fb520:	00 
  6fb521:	eb 8d                	jmp    6fb4b0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x44b0>
  6fb523:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fb52a:	84 00 00 00 00 00 
  6fb530:	f3 0f 10 44 30 f4    	movss  -0xc(%rax,%rsi,1),%xmm0
  6fb536:	0f 2e 44 24 20       	ucomiss 0x20(%rsp),%xmm0
  6fb53b:	75 18                	jne    6fb555 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4555>
  6fb53d:	7a 16                	jp     6fb555 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4555>
  6fb53f:	f3 0f 10 44 30 f8    	movss  -0x8(%rax,%rsi,1),%xmm0
  6fb545:	0f 28 4c 24 20       	movaps 0x20(%rsp),%xmm1
  6fb54a:	0f c6 c9 55          	shufps $0x55,%xmm1,%xmm1
  6fb54e:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6fb551:	75 02                	jne    6fb555 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4555>
  6fb553:	7b 19                	jnp    6fb56e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x456e>
  6fb555:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  6fb55a:	48 89 de             	mov    %rbx,%rsi
  6fb55d:	e8 ae e0 00 00       	call   709610 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6fb562:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fb567:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6fb56e:	4c 89 bc 24 a0 01 00 	mov    %r15,0x1a0(%rsp)
  6fb575:	00 
  6fb576:	4c 89 b4 24 a8 01 00 	mov    %r14,0x1a8(%rsp)
  6fb57d:	00 
  6fb57e:	89 ac 24 b0 01 00 00 	mov    %ebp,0x1b0(%rsp)
  6fb585:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
  6fb58a:	0f 13 84 24 b4 01 00 	movlps %xmm0,0x1b4(%rsp)
  6fb591:	00 
  6fb592:	c6 84 24 bc 01 00 00 	movb   $0x1,0x1bc(%rsp)
  6fb599:	01 
  6fb59a:	48 8b 84 24 08 07 00 	mov    0x708(%rsp),%rax
  6fb5a1:	00 
  6fb5a2:	48 85 c0             	test   %rax,%rax
  6fb5a5:	0f 84 85 00 00 00    	je     6fb630 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4630>
  6fb5ab:	48 8b 8c 24 10 07 00 	mov    0x710(%rsp),%rcx
  6fb5b2:	00 
  6fb5b3:	0f b7 b0 c2 01 00 00 	movzwl 0x1c2(%rax),%esi
  6fb5ba:	41 89 f0             	mov    %esi,%r8d
  6fb5bd:	41 c1 e0 05          	shl    $0x5,%r8d
  6fb5c1:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6fb5c8:	31 ff                	xor    %edi,%edi
  6fb5ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  6fb5d0:	49 39 f8             	cmp    %rdi,%r8
  6fb5d3:	74 3b                	je     6fb610 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4610>
  6fb5d5:	48 3b 9c d0 70 01 00 	cmp    0x170(%rax,%rdx,8),%rbx
  6fb5dc:	00 
  6fb5dd:	41 0f 97 c1          	seta   %r9b
  6fb5e1:	41 80 d9 00          	sbb    $0x0,%r9b
  6fb5e5:	48 83 c7 20          	add    $0x20,%rdi
  6fb5e9:	48 ff c2             	inc    %rdx
  6fb5ec:	41 80 f9 01          	cmp    $0x1,%r9b
  6fb5f0:	74 de                	je     6fb5d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x45d0>
  6fb5f2:	41 0f b6 f1          	movzbl %r9b,%esi
  6fb5f6:	85 f6                	test   %esi,%esi
  6fb5f8:	0f 84 32 fe ff ff    	je     6fb430 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4430>
  6fb5fe:	48 83 e9 01          	sub    $0x1,%rcx
  6fb602:	73 15                	jae    6fb619 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4619>
  6fb604:	eb 2c                	jmp    6fb632 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4632>
  6fb606:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6fb60d:	00 00 00 
  6fb610:	48 89 f2             	mov    %rsi,%rdx
  6fb613:	48 83 e9 01          	sub    $0x1,%rcx
  6fb617:	72 19                	jb     6fb632 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4632>
  6fb619:	48 8b 84 d0 c8 01 00 	mov    0x1c8(%rax,%rdx,8),%rax
  6fb620:	00 
  6fb621:	eb 90                	jmp    6fb5b3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x45b3>
  6fb623:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fb62a:	84 00 00 00 00 00 
  6fb630:	31 c0                	xor    %eax,%eax
  6fb632:	48 8d 8c 24 08 07 00 	lea    0x708(%rsp),%rcx
  6fb639:	00 
  6fb63a:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  6fb641:	00 
  6fb642:	48 89 9c 24 98 00 00 	mov    %rbx,0x98(%rsp)
  6fb649:	00 
  6fb64a:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6fb651:	00 
  6fb652:	48 c7 84 24 a8 00 00 	movq   $0x0,0xa8(%rsp)
  6fb659:	00 00 00 00 00 
  6fb65e:	48 89 94 24 b0 00 00 	mov    %rdx,0xb0(%rsp)
  6fb665:	00 
  6fb666:	48 8d bc 24 f0 02 00 	lea    0x2f0(%rsp),%rdi
  6fb66d:	00 
  6fb66e:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6fb675:	00 
  6fb676:	48 8d 94 24 a0 01 00 	lea    0x1a0(%rsp),%rdx
  6fb67d:	00 
  6fb67e:	e8 6d 67 01 00       	call   711df0 <<alloc::collections::btree::map::entry::VacantEntry<u64, gpui::runtime::list::ListRow>>::insert_entry>
  6fb683:	e9 c2 fd ff ff       	jmp    6fb44a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x444a>
  6fb688:	48 8b b4 24 78 01 00 	mov    0x178(%rsp),%rsi
  6fb68f:	00 
  6fb690:	48 85 f6             	test   %rsi,%rsi
  6fb693:	74 14                	je     6fb6a9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x46a9>
  6fb695:	48 c1 e6 05          	shl    $0x5,%rsi
  6fb699:	ba 08 00 00 00       	mov    $0x8,%edx
  6fb69e:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  6fb6a3:	ff 15 8f 00 39 00    	call   *0x39008f(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fb6a9:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  6fb6ae:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  6fb6b5:	00 
  6fb6b6:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  6fb6bb:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  6fb6c2:	00 
  6fb6c3:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  6fb6c8:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  6fb6cf:	00 
  6fb6d0:	48 8b 84 24 10 02 00 	mov    0x210(%rsp),%rax
  6fb6d7:	00 
  6fb6d8:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  6fb6df:	00 
  6fb6e0:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6fb6e5:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  6fb6ec:	00 
  6fb6ed:	0f 28 84 24 80 03 00 	movaps 0x380(%rsp),%xmm0
  6fb6f4:	00 
  6fb6f5:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
  6fb6fc:	00 
  6fb6fd:	0f 28 84 24 90 02 00 	movaps 0x290(%rsp),%xmm0
  6fb704:	00 
  6fb705:	0f 11 84 24 e8 00 00 	movups %xmm0,0xe8(%rsp)
  6fb70c:	00 
  6fb70d:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  6fb712:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
  6fb719:	00 
  6fb71a:	48 8b 84 24 10 04 00 	mov    0x410(%rsp),%rax
  6fb721:	00 
  6fb722:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6fb729:	00 
  6fb72a:	66 0f 28 84 24 60 04 	movapd 0x460(%rsp),%xmm0
  6fb731:	00 00 
  6fb733:	48 8d 84 24 98 00 00 	lea    0x98(%rsp),%rax
  6fb73a:	00 
  6fb73b:	66 0f 11 00          	movupd %xmm0,(%rax)
  6fb73f:	48 8b 84 24 20 05 00 	mov    0x520(%rsp),%rax
  6fb746:	00 
  6fb747:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  6fb74e:	00 
  6fb74f:	48 8b 84 24 30 05 00 	mov    0x530(%rsp),%rax
  6fb756:	00 
  6fb757:	48 85 c0             	test   %rax,%rax
  6fb75a:	48 8b 9c 24 c8 02 00 	mov    0x2c8(%rsp),%rbx
  6fb761:	00 
  6fb762:	4c 8b 74 24 58       	mov    0x58(%rsp),%r14
  6fb767:	0f 84 dd 00 00 00    	je     6fb84a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x484a>
  6fb76d:	48 8b 8c 24 38 05 00 	mov    0x538(%rsp),%rcx
  6fb774:	00 
  6fb775:	0f b7 b8 8a 05 00 00 	movzwl 0x58a(%rax),%edi
  6fb77c:	48 8d 70 40          	lea    0x40(%rax),%rsi
  6fb780:	41 89 f8             	mov    %edi,%r8d
  6fb783:	41 c1 e0 04          	shl    $0x4,%r8d
  6fb787:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6fb78e:	45 31 c9             	xor    %r9d,%r9d
  6fb791:	eb 21                	jmp    6fb7b4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x47b4>
  6fb793:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fb79a:	84 00 00 00 00 00 
  6fb7a0:	41 f6 da             	neg    %r10b
  6fb7a3:	48 83 c6 70          	add    $0x70,%rsi
  6fb7a7:	48 ff c2             	inc    %rdx
  6fb7aa:	49 83 c1 10          	add    $0x10,%r9
  6fb7ae:	41 80 fa 01          	cmp    $0x1,%r10b
  6fb7b2:	75 1e                	jne    6fb7d2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x47d2>
  6fb7b4:	4d 39 c8             	cmp    %r9,%r8
  6fb7b7:	74 23                	je     6fb7dc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x47dc>
  6fb7b9:	46 0f b6 14 08       	movzbl (%rax,%r9,1),%r10d
  6fb7be:	45 84 d2             	test   %r10b,%r10b
  6fb7c1:	75 dd                	jne    6fb7a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x47a0>
  6fb7c3:	4e 3b 7c 08 08       	cmp    0x8(%rax,%r9,1),%r15
  6fb7c8:	41 0f 97 c2          	seta   %r10b
  6fb7cc:	41 80 da 00          	sbb    $0x0,%r10b
  6fb7d0:	eb d1                	jmp    6fb7a3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x47a3>
  6fb7d2:	41 0f b6 fa          	movzbl %r10b,%edi
  6fb7d6:	85 ff                	test   %edi,%edi
  6fb7d8:	75 05                	jne    6fb7df <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x47df>
  6fb7da:	eb 13                	jmp    6fb7ef <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x47ef>
  6fb7dc:	48 89 fa             	mov    %rdi,%rdx
  6fb7df:	48 83 e9 01          	sub    $0x1,%rcx
  6fb7e3:	72 67                	jb     6fb84c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x484c>
  6fb7e5:	48 8b 84 d0 90 05 00 	mov    0x590(%rax,%rdx,8),%rax
  6fb7ec:	00 
  6fb7ed:	eb 86                	jmp    6fb775 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4775>
  6fb7ef:	0f 10 84 24 f0 00 00 	movups 0xf0(%rsp),%xmm0
  6fb7f6:	00 
  6fb7f7:	0f 11 46 60          	movups %xmm0,0x60(%rsi)
  6fb7fb:	0f 10 84 24 e0 00 00 	movups 0xe0(%rsp),%xmm0
  6fb802:	00 
  6fb803:	0f 11 46 50          	movups %xmm0,0x50(%rsi)
  6fb807:	0f 10 84 24 d0 00 00 	movups 0xd0(%rsp),%xmm0
  6fb80e:	00 
  6fb80f:	0f 11 46 40          	movups %xmm0,0x40(%rsi)
  6fb813:	66 0f 10 84 24 90 00 	movupd 0x90(%rsp),%xmm0
  6fb81a:	00 00 
  6fb81c:	66 0f 10 8c 24 a0 00 	movupd 0xa0(%rsp),%xmm1
  6fb823:	00 00 
  6fb825:	f3 0f 6f 94 24 b0 00 	movdqu 0xb0(%rsp),%xmm2
  6fb82c:	00 00 
  6fb82e:	0f 10 9c 24 c0 00 00 	movups 0xc0(%rsp),%xmm3
  6fb835:	00 
  6fb836:	0f 11 5e 30          	movups %xmm3,0x30(%rsi)
  6fb83a:	f3 0f 7f 56 20       	movdqu %xmm2,0x20(%rsi)
  6fb83f:	66 0f 11 4e 10       	movupd %xmm1,0x10(%rsi)
  6fb844:	66 0f 11 06          	movupd %xmm0,(%rsi)
  6fb848:	eb 5f                	jmp    6fb8a9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x48a9>
  6fb84a:	31 c0                	xor    %eax,%eax
  6fb84c:	48 c7 84 24 f0 02 00 	movq   $0x0,0x2f0(%rsp)
  6fb853:	00 00 00 00 00 
  6fb858:	4c 89 bc 24 f8 02 00 	mov    %r15,0x2f8(%rsp)
  6fb85f:	00 
  6fb860:	48 8d 8c 24 30 05 00 	lea    0x530(%rsp),%rcx
  6fb867:	00 
  6fb868:	48 89 8c 24 00 03 00 	mov    %rcx,0x300(%rsp)
  6fb86f:	00 
  6fb870:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
  6fb877:	00 
  6fb878:	48 c7 84 24 10 03 00 	movq   $0x0,0x310(%rsp)
  6fb87f:	00 00 00 00 00 
  6fb884:	48 89 94 24 18 03 00 	mov    %rdx,0x318(%rsp)
  6fb88b:	00 
  6fb88c:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6fb893:	00 
  6fb894:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
  6fb89b:	00 
  6fb89c:	48 8d 94 24 90 00 00 	lea    0x90(%rsp),%rdx
  6fb8a3:	00 
  6fb8a4:	e8 07 62 01 00       	call   711ab0 <<alloc::collections::btree::map::entry::VacantEntry<gpui::runtime::scroll::ViewportKey, gpui::runtime::scroll::ViewportState>>::insert_entry>
  6fb8a9:	48 8b 8c 24 40 02 00 	mov    0x240(%rsp),%rcx
  6fb8b0:	00 
  6fb8b1:	4c 8b bc 24 88 00 00 	mov    0x88(%rsp),%r15
  6fb8b8:	00 
  6fb8b9:	4d 85 f6             	test   %r14,%r14
  6fb8bc:	0f 84 cc f8 ff ff    	je     6fb18e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x418e>
  6fb8c2:	49 c1 e6 03          	shl    $0x3,%r14
  6fb8c6:	ba 08 00 00 00       	mov    $0x8,%edx
  6fb8cb:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
  6fb8d2:	00 
  6fb8d3:	4c 89 f6             	mov    %r14,%rsi
  6fb8d6:	ff 15 5c fe 38 00    	call   *0x38fe5c(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fb8dc:	48 8b 8c 24 40 02 00 	mov    0x240(%rsp),%rcx
  6fb8e3:	00 
  6fb8e4:	e9 a5 f8 ff ff       	jmp    6fb18e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x418e>
  6fb8e9:	4c 8b ac 24 00 02 00 	mov    0x200(%rsp),%r13
  6fb8f0:	00 
  6fb8f1:	4c 89 ac 24 98 03 00 	mov    %r13,0x398(%rsp)
  6fb8f8:	00 
  6fb8f9:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
  6fb900:	00 
  6fb901:	48 89 f0             	mov    %rsi,%rax
  6fb904:	4c 29 e8             	sub    %r13,%rax
  6fb907:	48 c1 e8 03          	shr    $0x3,%rax
  6fb90b:	48 b9 31 0c c3 30 0c 	movabs $0xc30c30c30c30c31,%rcx
  6fb912:	c3 30 0c 
  6fb915:	48 f7 e1             	mul    %rcx
  6fb918:	4c 39 ee             	cmp    %r13,%rsi
  6fb91b:	74 53                	je     6fb970 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4970>
  6fb91d:	48 89 d3             	mov    %rdx,%rbx
  6fb920:	49 81 c5 88 00 00 00 	add    $0x88,%r13
  6fb927:	4c 8b 35 0a fe 38 00 	mov    0x38fe0a(%rip),%r14        # a8b738 <_DYNAMIC+0x250>
  6fb92e:	eb 0c                	jmp    6fb93c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x493c>
  6fb930:	49 81 c5 a8 00 00 00 	add    $0xa8,%r13
  6fb937:	48 ff cb             	dec    %rbx
  6fb93a:	74 34                	je     6fb970 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4970>
  6fb93c:	49 8b 75 90          	mov    -0x70(%r13),%rsi
  6fb940:	48 85 f6             	test   %rsi,%rsi
  6fb943:	74 10                	je     6fb955 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4955>
  6fb945:	49 8b 7d 98          	mov    -0x68(%r13),%rdi
  6fb949:	48 c1 e6 03          	shl    $0x3,%rsi
  6fb94d:	ba 08 00 00 00       	mov    $0x8,%edx
  6fb952:	41 ff d6             	call   *%r14
  6fb955:	49 8b 75 f8          	mov    -0x8(%r13),%rsi
  6fb959:	48 85 f6             	test   %rsi,%rsi
  6fb95c:	74 d2                	je     6fb930 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4930>
  6fb95e:	49 8b 7d 00          	mov    0x0(%r13),%rdi
  6fb962:	48 c1 e6 05          	shl    $0x5,%rsi
  6fb966:	ba 08 00 00 00       	mov    $0x8,%edx
  6fb96b:	41 ff d6             	call   *%r14
  6fb96e:	eb c0                	jmp    6fb930 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4930>
  6fb970:	48 8b 84 24 b0 02 00 	mov    0x2b0(%rsp),%rax
  6fb977:	00 
  6fb978:	48 85 c0             	test   %rax,%rax
  6fb97b:	74 1a                	je     6fb997 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4997>
  6fb97d:	48 69 f0 a8 00 00 00 	imul   $0xa8,%rax,%rsi
  6fb984:	ba 08 00 00 00       	mov    $0x8,%edx
  6fb989:	48 8b bc 24 b8 02 00 	mov    0x2b8(%rsp),%rdi
  6fb990:	00 
  6fb991:	ff 15 a1 fd 38 00    	call   *0x38fda1(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fb997:	48 8b 84 24 48 05 00 	mov    0x548(%rsp),%rax
  6fb99e:	00 
  6fb99f:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6fb9a4:	48 8b 84 24 50 05 00 	mov    0x550(%rsp),%rax
  6fb9ab:	00 
  6fb9ac:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6fb9b1:	48 8b ac 24 58 05 00 	mov    0x558(%rsp),%rbp
  6fb9b8:	00 
  6fb9b9:	48 85 ed             	test   %rbp,%rbp
  6fb9bc:	0f 84 ff 02 00 00    	je     6fbcc1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4cc1>
  6fb9c2:	48 c1 e5 04          	shl    $0x4,%rbp
  6fb9c6:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
  6fb9cb:	48 01 dd             	add    %rbx,%rbp
  6fb9ce:	4c 8d ac 24 90 00 00 	lea    0x90(%rsp),%r13
  6fb9d5:	00 
  6fb9d6:	eb 66                	jmp    6fba3e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4a3e>
  6fb9d8:	0f 10 84 24 f0 00 00 	movups 0xf0(%rsp),%xmm0
  6fb9df:	00 
  6fb9e0:	0f 11 47 60          	movups %xmm0,0x60(%rdi)
  6fb9e4:	0f 10 84 24 e0 00 00 	movups 0xe0(%rsp),%xmm0
  6fb9eb:	00 
  6fb9ec:	0f 11 47 50          	movups %xmm0,0x50(%rdi)
  6fb9f0:	0f 10 84 24 d0 00 00 	movups 0xd0(%rsp),%xmm0
  6fb9f7:	00 
  6fb9f8:	0f 11 47 40          	movups %xmm0,0x40(%rdi)
  6fb9fc:	f3 0f 6f 84 24 90 00 	movdqu 0x90(%rsp),%xmm0
  6fba03:	00 00 
  6fba05:	f3 0f 6f 8c 24 a0 00 	movdqu 0xa0(%rsp),%xmm1
  6fba0c:	00 00 
  6fba0e:	f3 0f 6f 94 24 b0 00 	movdqu 0xb0(%rsp),%xmm2
  6fba15:	00 00 
  6fba17:	0f 10 9c 24 c0 00 00 	movups 0xc0(%rsp),%xmm3
  6fba1e:	00 
  6fba1f:	0f 11 5f 30          	movups %xmm3,0x30(%rdi)
  6fba23:	f3 0f 7f 57 20       	movdqu %xmm2,0x20(%rdi)
  6fba28:	f3 0f 7f 4f 10       	movdqu %xmm1,0x10(%rdi)
  6fba2d:	f3 0f 7f 07          	movdqu %xmm0,(%rdi)
  6fba31:	48 83 c3 10          	add    $0x10,%rbx
  6fba35:	48 39 eb             	cmp    %rbp,%rbx
  6fba38:	0f 84 83 02 00 00    	je     6fbcc1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4cc1>
  6fba3e:	48 8b 3b             	mov    (%rbx),%rdi
  6fba41:	48 8b b4 24 90 01 00 	mov    0x190(%rsp),%rsi
  6fba48:	00 
  6fba49:	48 39 f7             	cmp    %rsi,%rdi
  6fba4c:	0f 83 e1 1f 00 00    	jae    6fda33 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a33>
  6fba52:	0f b6 4b 08          	movzbl 0x8(%rbx),%ecx
  6fba56:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  6fba5d:	00 
  6fba5e:	48 8d 14 7f          	lea    (%rdi,%rdi,2),%rdx
  6fba62:	48 8b 04 d0          	mov    (%rax,%rdx,8),%rax
  6fba66:	48 8b 94 24 40 02 00 	mov    0x240(%rsp),%rdx
  6fba6d:	00 
  6fba6e:	48 8b 12             	mov    (%rdx),%rdx
  6fba71:	48 85 d2             	test   %rdx,%rdx
  6fba74:	0f 84 22 01 00 00    	je     6fbb9c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b9c>
  6fba7a:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  6fba7f:	48 8b b6 50 06 00 00 	mov    0x650(%rsi),%rsi
  6fba86:	48 89 f7             	mov    %rsi,%rdi
  6fba89:	49 89 d0             	mov    %rdx,%r8
  6fba8c:	45 0f b7 b0 8a 05 00 	movzwl 0x58a(%r8),%r14d
  6fba93:	00 
  6fba94:	4d 8d 48 48          	lea    0x48(%r8),%r9
  6fba98:	45 89 f3             	mov    %r14d,%r11d
  6fba9b:	41 c1 e3 04          	shl    $0x4,%r11d
  6fba9f:	49 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%r10
  6fbaa6:	45 31 ff             	xor    %r15d,%r15d
  6fbaa9:	eb 23                	jmp    6fbace <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4ace>
  6fbaab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6fbab0:	4b 3b 44 38 08       	cmp    0x8(%r8,%r15,1),%rax
  6fbab5:	41 0f 97 c4          	seta   %r12b
  6fbab9:	41 80 dc 00          	sbb    $0x0,%r12b
  6fbabd:	49 83 c1 70          	add    $0x70,%r9
  6fbac1:	49 ff c2             	inc    %r10
  6fbac4:	49 83 c7 10          	add    $0x10,%r15
  6fbac8:	41 80 fc 01          	cmp    $0x1,%r12b
  6fbacc:	75 12                	jne    6fbae0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4ae0>
  6fbace:	4d 39 fb             	cmp    %r15,%r11
  6fbad1:	74 18                	je     6fbaeb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4aeb>
  6fbad3:	4b 83 3c 38 00       	cmpq   $0x0,(%r8,%r15,1)
  6fbad8:	75 d6                	jne    6fbab0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4ab0>
  6fbada:	41 b4 01             	mov    $0x1,%r12b
  6fbadd:	eb de                	jmp    6fbabd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4abd>
  6fbadf:	90                   	nop
  6fbae0:	45 0f b6 dc          	movzbl %r12b,%r11d
  6fbae4:	45 85 db             	test   %r11d,%r11d
  6fbae7:	75 05                	jne    6fbaee <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4aee>
  6fbae9:	eb 17                	jmp    6fbb02 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b02>
  6fbaeb:	4d 89 f2             	mov    %r14,%r10
  6fbaee:	48 83 ef 01          	sub    $0x1,%rdi
  6fbaf2:	0f 82 b8 01 00 00    	jb     6fbcb0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4cb0>
  6fbaf8:	4f 8b 84 d0 90 05 00 	mov    0x590(%r8,%r10,8),%r8
  6fbaff:	00 
  6fbb00:	eb 8a                	jmp    6fba8c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4a8c>
  6fbb02:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fbb06:	41 83 79 f8 02       	cmpl   $0x2,-0x8(%r9)
  6fbb0b:	4c 8b bc 24 88 00 00 	mov    0x88(%rsp),%r15
  6fbb12:	00 
  6fbb13:	75 0b                	jne    6fbb20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b20>
  6fbb15:	f3 41 0f 6f 01       	movdqu (%r9),%xmm0
  6fbb1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  6fbb20:	44 0f b7 8a 8a 05 00 	movzwl 0x58a(%rdx),%r9d
  6fbb27:	00 
  6fbb28:	4c 8d 42 40          	lea    0x40(%rdx),%r8
  6fbb2c:	45 89 ca             	mov    %r9d,%r10d
  6fbb2f:	41 c1 e2 04          	shl    $0x4,%r10d
  6fbb33:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
  6fbb3a:	45 31 db             	xor    %r11d,%r11d
  6fbb3d:	eb 1f                	jmp    6fbb5e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b5e>
  6fbb3f:	90                   	nop
  6fbb40:	4a 3b 44 1a 08       	cmp    0x8(%rdx,%r11,1),%rax
  6fbb45:	41 0f 97 c6          	seta   %r14b
  6fbb49:	41 80 de 00          	sbb    $0x0,%r14b
  6fbb4d:	49 83 c0 70          	add    $0x70,%r8
  6fbb51:	48 ff c7             	inc    %rdi
  6fbb54:	49 83 c3 10          	add    $0x10,%r11
  6fbb58:	41 80 fe 01          	cmp    $0x1,%r14b
  6fbb5c:	75 12                	jne    6fbb70 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b70>
  6fbb5e:	4d 39 da             	cmp    %r11,%r10
  6fbb61:	74 18                	je     6fbb7b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b7b>
  6fbb63:	4a 83 3c 1a 00       	cmpq   $0x0,(%rdx,%r11,1)
  6fbb68:	75 d6                	jne    6fbb40 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b40>
  6fbb6a:	41 b6 01             	mov    $0x1,%r14b
  6fbb6d:	eb de                	jmp    6fbb4d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b4d>
  6fbb6f:	90                   	nop
  6fbb70:	45 0f b6 ce          	movzbl %r14b,%r9d
  6fbb74:	45 85 c9             	test   %r9d,%r9d
  6fbb77:	75 05                	jne    6fbb7e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b7e>
  6fbb79:	eb 13                	jmp    6fbb8e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b8e>
  6fbb7b:	4c 89 cf             	mov    %r9,%rdi
  6fbb7e:	48 83 ee 01          	sub    $0x1,%rsi
  6fbb82:	72 1c                	jb     6fbba0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4ba0>
  6fbb84:	48 8b 94 fa 90 05 00 	mov    0x590(%rdx,%rdi,8),%rdx
  6fbb8b:	00 
  6fbb8c:	eb 92                	jmp    6fbb20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b20>
  6fbb8e:	41 83 38 02          	cmpl   $0x2,(%r8)
  6fbb92:	75 0c                	jne    6fbba0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4ba0>
  6fbb94:	41 38 48 18          	cmp    %cl,0x18(%r8)
  6fbb98:	75 06                	jne    6fbba0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4ba0>
  6fbb9a:	eb 10                	jmp    6fbbac <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4bac>
  6fbb9c:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fbba0:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6fbba5:	c6 82 4b 07 00 00 01 	movb   $0x1,0x74b(%rdx)
  6fbbac:	f3 0f 7f 84 24 98 00 	movdqu %xmm0,0x98(%rsp)
  6fbbb3:	00 00 
  6fbbb5:	88 8c 24 a8 00 00 00 	mov    %cl,0xa8(%rsp)
  6fbbbc:	48 c7 84 24 90 00 00 	movq   $0x2,0x90(%rsp)
  6fbbc3:	00 02 00 00 00 
  6fbbc8:	48 8b 8c 24 30 05 00 	mov    0x530(%rsp),%rcx
  6fbbcf:	00 
  6fbbd0:	48 85 c9             	test   %rcx,%rcx
  6fbbd3:	74 7c                	je     6fbc51 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c51>
  6fbbd5:	48 8b 94 24 38 05 00 	mov    0x538(%rsp),%rdx
  6fbbdc:	00 
  6fbbdd:	44 0f b7 81 8a 05 00 	movzwl 0x58a(%rcx),%r8d
  6fbbe4:	00 
  6fbbe5:	48 8d 79 40          	lea    0x40(%rcx),%rdi
  6fbbe9:	45 89 c1             	mov    %r8d,%r9d
  6fbbec:	41 c1 e1 04          	shl    $0x4,%r9d
  6fbbf0:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
  6fbbf7:	45 31 d2             	xor    %r10d,%r10d
  6fbbfa:	eb 22                	jmp    6fbc1e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c1e>
  6fbbfc:	0f 1f 40 00          	nopl   0x0(%rax)
  6fbc00:	4a 3b 44 11 08       	cmp    0x8(%rcx,%r10,1),%rax
  6fbc05:	41 0f 97 c3          	seta   %r11b
  6fbc09:	41 80 db 00          	sbb    $0x0,%r11b
  6fbc0d:	48 83 c7 70          	add    $0x70,%rdi
  6fbc11:	48 ff c6             	inc    %rsi
  6fbc14:	49 83 c2 10          	add    $0x10,%r10
  6fbc18:	41 80 fb 01          	cmp    $0x1,%r11b
  6fbc1c:	75 12                	jne    6fbc30 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c30>
  6fbc1e:	4d 39 d1             	cmp    %r10,%r9
  6fbc21:	74 1b                	je     6fbc3e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c3e>
  6fbc23:	4a 83 3c 11 00       	cmpq   $0x0,(%rcx,%r10,1)
  6fbc28:	75 d6                	jne    6fbc00 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c00>
  6fbc2a:	41 b3 01             	mov    $0x1,%r11b
  6fbc2d:	eb de                	jmp    6fbc0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c0d>
  6fbc2f:	90                   	nop
  6fbc30:	45 0f b6 c3          	movzbl %r11b,%r8d
  6fbc34:	45 85 c0             	test   %r8d,%r8d
  6fbc37:	75 08                	jne    6fbc41 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c41>
  6fbc39:	e9 9a fd ff ff       	jmp    6fb9d8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x49d8>
  6fbc3e:	4c 89 c6             	mov    %r8,%rsi
  6fbc41:	48 83 ea 01          	sub    $0x1,%rdx
  6fbc45:	72 0c                	jb     6fbc53 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c53>
  6fbc47:	48 8b 8c f1 90 05 00 	mov    0x590(%rcx,%rsi,8),%rcx
  6fbc4e:	00 
  6fbc4f:	eb 8c                	jmp    6fbbdd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4bdd>
  6fbc51:	31 c9                	xor    %ecx,%ecx
  6fbc53:	48 c7 84 24 f0 02 00 	movq   $0x1,0x2f0(%rsp)
  6fbc5a:	00 01 00 00 00 
  6fbc5f:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
  6fbc66:	00 
  6fbc67:	48 8d 84 24 30 05 00 	lea    0x530(%rsp),%rax
  6fbc6e:	00 
  6fbc6f:	48 89 84 24 00 03 00 	mov    %rax,0x300(%rsp)
  6fbc76:	00 
  6fbc77:	48 89 8c 24 08 03 00 	mov    %rcx,0x308(%rsp)
  6fbc7e:	00 
  6fbc7f:	48 c7 84 24 10 03 00 	movq   $0x0,0x310(%rsp)
  6fbc86:	00 00 00 00 00 
  6fbc8b:	48 89 b4 24 18 03 00 	mov    %rsi,0x318(%rsp)
  6fbc92:	00 
  6fbc93:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6fbc9a:	00 
  6fbc9b:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
  6fbca2:	00 
  6fbca3:	4c 89 ea             	mov    %r13,%rdx
  6fbca6:	e8 05 5e 01 00       	call   711ab0 <<alloc::collections::btree::map::entry::VacantEntry<gpui::runtime::scroll::ViewportKey, gpui::runtime::scroll::ViewportState>>::insert_entry>
  6fbcab:	e9 81 fd ff ff       	jmp    6fba31 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4a31>
  6fbcb0:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fbcb4:	4c 8b bc 24 88 00 00 	mov    0x88(%rsp),%r15
  6fbcbb:	00 
  6fbcbc:	e9 5f fe ff ff       	jmp    6fbb20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b20>
  6fbcc1:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  6fbcc6:	48 85 f6             	test   %rsi,%rsi
  6fbcc9:	74 14                	je     6fbcdf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4cdf>
  6fbccb:	48 c1 e6 04          	shl    $0x4,%rsi
  6fbccf:	ba 08 00 00 00       	mov    $0x8,%edx
  6fbcd4:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6fbcd9:	ff 15 59 fa 38 00    	call   *0x38fa59(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fbcdf:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fbce4:	48 8d b8 40 06 00 00 	lea    0x640(%rax),%rdi
  6fbceb:	48 8b 9c 24 f0 04 00 	mov    0x4f0(%rsp),%rbx
  6fbcf2:	00 
  6fbcf3:	48 85 db             	test   %rbx,%rbx
  6fbcf6:	4c 8b ac 24 08 02 00 	mov    0x208(%rsp),%r13
  6fbcfd:	00 
  6fbcfe:	48 89 bc 24 90 02 00 	mov    %rdi,0x290(%rsp)
  6fbd05:	00 
  6fbd06:	75 35                	jne    6fbd3d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d3d>
  6fbd08:	48 83 bc 24 40 05 00 	cmpq   $0x0,0x540(%rsp)
  6fbd0f:	00 00 
  6fbd11:	75 2a                	jne    6fbd3d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d3d>
  6fbd13:	48 83 3f 00          	cmpq   $0x0,(%rdi)
  6fbd17:	75 24                	jne    6fbd3d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d3d>
  6fbd19:	b0 01                	mov    $0x1,%al
  6fbd1b:	89 44 24 38          	mov    %eax,0x38(%rsp)
  6fbd1f:	4d 85 ff             	test   %r15,%r15
  6fbd22:	0f 84 df 0d 00 00    	je     6fcb07 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5b07>
  6fbd28:	4c 8b b4 24 88 01 00 	mov    0x188(%rsp),%r14
  6fbd2f:	00 
  6fbd30:	48 8b 9c 24 90 01 00 	mov    0x190(%rsp),%rbx
  6fbd37:	00 
  6fbd38:	e9 87 02 00 00       	jmp    6fbfc4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4fc4>
  6fbd3d:	e8 ae 58 fe ff       	call   6e15f0 <<core::option::Option<alloc::boxed::Box<gpui::runtime::metadata::Metadata>>>::get_or_insert_with::<<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#44}>>
  6fbd42:	4c 8b ac 24 e8 04 00 	mov    0x4e8(%rsp),%r13
  6fbd49:	00 
  6fbd4a:	48 85 db             	test   %rbx,%rbx
  6fbd4d:	74 0f                	je     6fbd5e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d5e>
  6fbd4f:	48 83 fb 01          	cmp    $0x1,%rbx
  6fbd53:	75 68                	jne    6fbdbd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4dbd>
  6fbd55:	31 c0                	xor    %eax,%eax
  6fbd57:	31 f6                	xor    %esi,%esi
  6fbd59:	e9 af 00 00 00       	jmp    6fbe0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4e0d>
  6fbd5e:	31 f6                	xor    %esi,%esi
  6fbd60:	e9 c6 00 00 00       	jmp    6fbe2b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4e2b>
  6fbd65:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  6fbd6a:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6fbd6f:	4c 89 60 10          	mov    %r12,0x10(%rax)
  6fbd73:	48 c7 00 20 00 00 00 	movq   $0x20,(%rax)
  6fbd7a:	48 c7 40 08 0c 00 00 	movq   $0xc,0x8(%rax)
  6fbd81:	00 
  6fbd82:	48 8b b4 24 78 02 00 	mov    0x278(%rsp),%rsi
  6fbd89:	00 
  6fbd8a:	48 85 f6             	test   %rsi,%rsi
  6fbd8d:	74 17                	je     6fbda6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4da6>
  6fbd8f:	48 8b bc 24 80 02 00 	mov    0x280(%rsp),%rdi
  6fbd96:	00 
  6fbd97:	48 c1 e6 04          	shl    $0x4,%rsi
  6fbd9b:	ba 08 00 00 00       	mov    $0x8,%edx
  6fbda0:	ff 15 92 f9 38 00    	call   *0x38f992(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fbda6:	31 db                	xor    %ebx,%ebx
  6fbda8:	48 8d bc 24 f0 07 00 	lea    0x7f0(%rsp),%rdi
  6fbdaf:	00 
  6fbdb0:	e8 6b b5 fe ff       	call   6e7320 <core::ptr::drop_glue::<gpui::runtime::styles::colours::Discovery>>
  6fbdb5:	45 31 e4             	xor    %r12d,%r12d
  6fbdb8:	e9 8e 14 00 00       	jmp    6fd24b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x624b>
  6fbdbd:	48 b9 fe ff ff ff ff 	movabs $0x3fffffffffffffe,%rcx
  6fbdc4:	ff ff 03 
  6fbdc7:	48 21 d9             	and    %rbx,%rcx
  6fbdca:	31 c0                	xor    %eax,%eax
  6fbdcc:	4c 89 ea             	mov    %r13,%rdx
  6fbdcf:	31 f6                	xor    %esi,%esi
  6fbdd1:	48 8b 7a 18          	mov    0x18(%rdx),%rdi
  6fbdd5:	4c 8b 42 50          	mov    0x50(%rdx),%r8
  6fbdd9:	48 23 3a             	and    (%rdx),%rdi
  6fbddc:	45 31 c9             	xor    %r9d,%r9d
  6fbddf:	48 83 ff ff          	cmp    $0xffffffffffffffff,%rdi
  6fbde3:	41 0f 95 c1          	setne  %r9b
  6fbde7:	4c 23 42 38          	and    0x38(%rdx),%r8
  6fbdeb:	49 01 f1             	add    %rsi,%r9
  6fbdee:	31 f6                	xor    %esi,%esi
  6fbdf0:	49 83 f8 ff          	cmp    $0xffffffffffffffff,%r8
  6fbdf4:	40 0f 95 c6          	setne  %sil
  6fbdf8:	4c 01 ce             	add    %r9,%rsi
  6fbdfb:	48 83 c0 02          	add    $0x2,%rax
  6fbdff:	48 83 c2 70          	add    $0x70,%rdx
  6fbe03:	48 39 c1             	cmp    %rax,%rcx
  6fbe06:	75 c9                	jne    6fbdd1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4dd1>
  6fbe08:	f6 c3 01             	test   $0x1,%bl
  6fbe0b:	74 1e                	je     6fbe2b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4e2b>
  6fbe0d:	48 89 f1             	mov    %rsi,%rcx
  6fbe10:	48 6b c0 38          	imul   $0x38,%rax,%rax
  6fbe14:	49 8b 54 05 18       	mov    0x18(%r13,%rax,1),%rdx
  6fbe19:	49 23 54 05 00       	and    0x0(%r13,%rax,1),%rdx
  6fbe1e:	31 f6                	xor    %esi,%esi
  6fbe20:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
  6fbe24:	40 0f 95 c6          	setne  %sil
  6fbe28:	48 01 ce             	add    %rcx,%rsi
  6fbe2b:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6fbe32:	00 
  6fbe33:	b9 08 00 00 00       	mov    $0x8,%ecx
  6fbe38:	41 b8 18 00 00 00    	mov    $0x18,%r8d
  6fbe3e:	31 d2                	xor    %edx,%edx
  6fbe40:	e8 ab 53 02 00       	call   7211f0 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6fbe45:	48 8b bc 24 98 00 00 	mov    0x98(%rsp),%rdi
  6fbe4c:	00 
  6fbe4d:	83 bc 24 90 00 00 00 	cmpl   $0x1,0x90(%rsp)
  6fbe54:	01 
  6fbe55:	0f 84 42 1b 00 00    	je     6fd99d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x699d>
  6fbe5b:	48 6b f3 38          	imul   $0x38,%rbx,%rsi
  6fbe5f:	4c 01 ee             	add    %r13,%rsi
  6fbe62:	48 8b 8c 24 78 02 00 	mov    0x278(%rsp),%rcx
  6fbe69:	00 
  6fbe6a:	48 8b 84 24 80 02 00 	mov    0x280(%rsp),%rax
  6fbe71:	00 
  6fbe72:	4c 8b 84 24 88 02 00 	mov    0x288(%rsp),%r8
  6fbe79:	00 
  6fbe7a:	49 c1 e0 04          	shl    $0x4,%r8
  6fbe7e:	49 01 c0             	add    %rax,%r8
  6fbe81:	48 89 bc 24 c8 04 00 	mov    %rdi,0x4c8(%rsp)
  6fbe88:	00 
  6fbe89:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
  6fbe90:	00 
  6fbe91:	48 89 94 24 d0 04 00 	mov    %rdx,0x4d0(%rsp)
  6fbe98:	00 
  6fbe99:	48 c7 84 24 d8 04 00 	movq   $0x0,0x4d8(%rsp)
  6fbea0:	00 00 00 00 00 
  6fbea5:	48 8b 94 24 e0 04 00 	mov    0x4e0(%rsp),%rdx
  6fbeac:	00 
  6fbead:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fbeb1:	f3 0f 7f 84 24 d0 00 	movdqu %xmm0,0xd0(%rsp)
  6fbeb8:	00 00 
  6fbeba:	4c 89 ac 24 90 00 00 	mov    %r13,0x90(%rsp)
  6fbec1:	00 
  6fbec2:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
  6fbec9:	00 
  6fbeca:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
  6fbed1:	00 
  6fbed2:	48 89 74 24 40       	mov    %rsi,0x40(%rsp)
  6fbed7:	48 89 b4 24 a8 00 00 	mov    %rsi,0xa8(%rsp)
  6fbede:	00 
  6fbedf:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  6fbee6:	00 
  6fbee7:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  6fbeee:	00 
  6fbeef:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
  6fbef6:	00 
  6fbef7:	4c 89 44 24 38       	mov    %r8,0x38(%rsp)
  6fbefc:	4c 89 84 24 c8 00 00 	mov    %r8,0xc8(%rsp)
  6fbf03:	00 
  6fbf04:	48 85 db             	test   %rbx,%rbx
  6fbf07:	0f 85 7d 02 00 00    	jne    6fc18a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x518a>
  6fbf0d:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6fbf14:	00 
  6fbf15:	e8 46 8c fe ff       	call   6e4b60 <core::ptr::drop_glue::<core::iter::adapters::zip::Zip<alloc::vec::into_iter::IntoIter<gpui::semantic::AnnotationDraft>, alloc::vec::into_iter::IntoIter<[core::option::Option<gpui::source::FieldId>; 2]>>>>
  6fbf1a:	48 8b bc 24 d0 04 00 	mov    0x4d0(%rsp),%rdi
  6fbf21:	00 
  6fbf22:	48 8b b4 24 d8 04 00 	mov    0x4d8(%rsp),%rsi
  6fbf29:	00 
  6fbf2a:	e8 71 55 fe ff       	call   6e14a0 <<[gpui::runtime::metadata::Declared]>::sort_unstable_by_key::<u64, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#48}>>
  6fbf2f:	48 8b 84 24 d8 04 00 	mov    0x4d8(%rsp),%rax
  6fbf36:	00 
  6fbf37:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6fbf3e:	00 
  6fbf3f:	0f 10 84 24 c8 04 00 	movups 0x4c8(%rsp),%xmm0
  6fbf46:	00 
  6fbf47:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
  6fbf4e:	00 
  6fbf4f:	bf c0 00 00 00       	mov    $0xc0,%edi
  6fbf54:	48 8b 9c 24 90 02 00 	mov    0x290(%rsp),%rbx
  6fbf5b:	00 
  6fbf5c:	48 03 3b             	add    (%rbx),%rdi
  6fbf5f:	e8 cc 83 fe ff       	call   6e4330 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::metadata::Declared>>>
  6fbf64:	4c 8b bc 24 88 00 00 	mov    0x88(%rsp),%r15
  6fbf6b:	00 
  6fbf6c:	4c 8b ac 24 08 02 00 	mov    0x208(%rsp),%r13
  6fbf73:	00 
  6fbf74:	48 8b 03             	mov    (%rbx),%rax
  6fbf77:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  6fbf7e:	00 
  6fbf7f:	48 89 88 d0 00 00 00 	mov    %rcx,0xd0(%rax)
  6fbf86:	66 0f 6f 84 24 90 00 	movdqa 0x90(%rsp),%xmm0
  6fbf8d:	00 00 
  6fbf8f:	f3 0f 7f 80 c0 00 00 	movdqu %xmm0,0xc0(%rax)
  6fbf96:	00 
  6fbf97:	4c 8b 23             	mov    (%rbx),%r12
  6fbf9a:	4c 8b b4 24 88 01 00 	mov    0x188(%rsp),%r14
  6fbfa1:	00 
  6fbfa2:	48 8b 9c 24 90 01 00 	mov    0x190(%rsp),%rbx
  6fbfa9:	00 
  6fbfaa:	4d 85 ff             	test   %r15,%r15
  6fbfad:	0f 84 58 12 00 00    	je     6fd20b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x620b>
  6fbfb3:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
  6fbfba:	00 
  6fbfbb:	4d 85 e4             	test   %r12,%r12
  6fbfbe:	0f 85 b7 00 00 00    	jne    6fc07b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x507b>
  6fbfc4:	ff 15 5e f7 38 00    	call   *0x38f75e(%rip)        # a8b728 <_DYNAMIC+0x240>
  6fbfca:	41 bc 08 01 00 00    	mov    $0x108,%r12d
  6fbfd0:	bf 08 01 00 00       	mov    $0x108,%edi
  6fbfd5:	be 08 00 00 00       	mov    $0x8,%esi
  6fbfda:	ff 15 50 f7 38 00    	call   *0x38f750(%rip)        # a8b730 <_DYNAMIC+0x248>
  6fbfe0:	48 85 c0             	test   %rax,%rax
  6fbfe3:	0f 84 a1 19 00 00    	je     6fd98a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x698a>
  6fbfe9:	48 89 c1             	mov    %rax,%rcx
  6fbfec:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fbff0:	f3 0f 7f 80 d8 00 00 	movdqu %xmm0,0xd8(%rax)
  6fbff7:	00 
  6fbff8:	f3 0f 7f 40 28       	movdqu %xmm0,0x28(%rax)
  6fbffd:	f3 0f 7f 40 40       	movdqu %xmm0,0x40(%rax)
  6fc002:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  6fc009:	48 c7 40 18 00 00 00 	movq   $0x0,0x18(%rax)
  6fc010:	00 
  6fc011:	48 c7 40 20 08 00 00 	movq   $0x8,0x20(%rax)
  6fc018:	00 
  6fc019:	48 c7 40 38 08 00 00 	movq   $0x8,0x38(%rax)
  6fc020:	00 
  6fc021:	48 c7 40 50 08 00 00 	movq   $0x8,0x50(%rax)
  6fc028:	00 
  6fc029:	48 c7 40 58 00 00 00 	movq   $0x0,0x58(%rax)
  6fc030:	00 
  6fc031:	48 c7 40 60 ff ff ff 	movq   $0xffffffffffffffff,0x60(%rax)
  6fc038:	ff 
  6fc039:	48 c7 80 c0 00 00 00 	movq   $0x0,0xc0(%rax)
  6fc040:	00 00 00 00 
  6fc044:	48 c7 80 c8 00 00 00 	movq   $0x8,0xc8(%rax)
  6fc04b:	08 00 00 00 
  6fc04f:	48 c7 80 d0 00 00 00 	movq   $0x0,0xd0(%rax)
  6fc056:	00 00 00 00 
  6fc05a:	48 c7 80 e8 00 00 00 	movq   $0x0,0xe8(%rax)
  6fc061:	00 00 00 00 
  6fc065:	f3 0f 7f 80 f8 00 00 	movdqu %xmm0,0xf8(%rax)
  6fc06c:	00 
  6fc06d:	48 8b 84 24 90 02 00 	mov    0x290(%rsp),%rax
  6fc074:	00 
  6fc075:	48 89 08             	mov    %rcx,(%rax)
  6fc078:	49 89 cc             	mov    %rcx,%r12
  6fc07b:	49 8b 84 24 00 01 00 	mov    0x100(%r12),%rax
  6fc082:	00 
  6fc083:	49 c7 84 24 00 01 00 	movq   $0x0,0x100(%r12)
  6fc08a:	00 00 00 00 00 
  6fc08f:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6fc094:	48 85 c0             	test   %rax,%rax
  6fc097:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
  6fc09c:	75 6f                	jne    6fc10d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x510d>
  6fc09e:	ff 15 84 f6 38 00    	call   *0x38f684(%rip)        # a8b728 <_DYNAMIC+0x240>
  6fc0a4:	41 bc 60 00 00 00    	mov    $0x60,%r12d
  6fc0aa:	bf 60 00 00 00       	mov    $0x60,%edi
  6fc0af:	be 08 00 00 00       	mov    $0x8,%esi
  6fc0b4:	ff 15 76 f6 38 00    	call   *0x38f676(%rip)        # a8b730 <_DYNAMIC+0x248>
  6fc0ba:	48 85 c0             	test   %rax,%rax
  6fc0bd:	0f 84 c7 18 00 00    	je     6fd98a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x698a>
  6fc0c3:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fc0c7:	f3 0f 7f 40 10       	movdqu %xmm0,0x10(%rax)
  6fc0cc:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  6fc0d3:	48 c7 40 08 08 00 00 	movq   $0x8,0x8(%rax)
  6fc0da:	00 
  6fc0db:	48 c7 40 20 04 00 00 	movq   $0x4,0x20(%rax)
  6fc0e2:	00 
  6fc0e3:	48 c7 40 28 00 00 00 	movq   $0x0,0x28(%rax)
  6fc0ea:	00 
  6fc0eb:	48 c7 40 30 ff ff ff 	movq   $0xffffffffffffffff,0x30(%rax)
  6fc0f2:	ff 
  6fc0f3:	48 c7 40 48 00 00 00 	movq   $0x0,0x48(%rax)
  6fc0fa:	00 
  6fc0fb:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6fc100:	48 c7 40 58 00 00 00 	movq   $0x0,0x58(%rax)
  6fc107:	00 
  6fc108:	4c 8b 64 24 40       	mov    0x40(%rsp),%r12
  6fc10d:	4d 85 ff             	test   %r15,%r15
  6fc110:	0f 84 f4 06 00 00    	je     6fc80a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x580a>
  6fc116:	ff 15 0c f6 38 00    	call   *0x38f60c(%rip)        # a8b728 <_DYNAMIC+0x240>
  6fc11c:	be 08 00 00 00       	mov    $0x8,%esi
  6fc121:	4c 8b a4 24 50 08 00 	mov    0x850(%rsp),%r12
  6fc128:	00 
  6fc129:	4c 89 e7             	mov    %r12,%rdi
  6fc12c:	ff 15 fe f5 38 00    	call   *0x38f5fe(%rip)        # a8b730 <_DYNAMIC+0x248>
  6fc132:	48 85 c0             	test   %rax,%rax
  6fc135:	0f 84 24 1c 00 00    	je     6fdd5f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d5f>
  6fc13b:	4c 8b 64 24 40       	mov    0x40(%rsp),%r12
  6fc140:	e9 ca 06 00 00       	jmp    6fc80f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x580f>
  6fc145:	48 8b 84 24 d0 04 00 	mov    0x4d0(%rsp),%rax
  6fc14c:	00 
  6fc14d:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
  6fc151:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  6fc156:	48 89 14 c8          	mov    %rdx,(%rax,%rcx,8)
  6fc15a:	4c 89 74 c8 08       	mov    %r14,0x8(%rax,%rcx,8)
  6fc15f:	48 89 5c c8 10       	mov    %rbx,0x10(%rax,%rcx,8)
  6fc164:	49 ff c7             	inc    %r15
  6fc167:	4c 89 bc 24 d8 04 00 	mov    %r15,0x4d8(%rsp)
  6fc16e:	00 
  6fc16f:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  6fc174:	49 89 cd             	mov    %rcx,%r13
  6fc177:	48 8b 84 24 80 03 00 	mov    0x380(%rsp),%rax
  6fc17e:	00 
  6fc17f:	48 3b 4c 24 40       	cmp    0x40(%rsp),%rcx
  6fc184:	0f 84 83 fd ff ff    	je     6fbf0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4f0d>
  6fc18a:	49 8d 4d 38          	lea    0x38(%r13),%rcx
  6fc18e:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  6fc195:	00 
  6fc196:	4d 8b 65 00          	mov    0x0(%r13),%r12
  6fc19a:	49 83 fc fe          	cmp    $0xfffffffffffffffe,%r12
  6fc19e:	0f 84 69 fd ff ff    	je     6fbf0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4f0d>
  6fc1a4:	49 8b 5d 08          	mov    0x8(%r13),%rbx
  6fc1a8:	4d 8b 75 18          	mov    0x18(%r13),%r14
  6fc1ac:	4d 8b 7d 20          	mov    0x20(%r13),%r15
  6fc1b0:	48 3b 44 24 38       	cmp    0x38(%rsp),%rax
  6fc1b5:	0f 84 10 15 00 00    	je     6fd6cb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x66cb>
  6fc1bb:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  6fc1c0:	49 8b 6d 10          	mov    0x10(%r13),%rbp
  6fc1c4:	48 8d 48 10          	lea    0x10(%rax),%rcx
  6fc1c8:	48 89 8c 24 80 03 00 	mov    %rcx,0x380(%rsp)
  6fc1cf:	00 
  6fc1d0:	48 89 8c 24 b8 00 00 	mov    %rcx,0xb8(%rsp)
  6fc1d7:	00 
  6fc1d8:	f3 0f 6f 00          	movdqu (%rax),%xmm0
  6fc1dc:	66 0f 7f 84 24 d0 08 	movdqa %xmm0,0x8d0(%rsp)
  6fc1e3:	00 00 
  6fc1e5:	41 8b 7d 30          	mov    0x30(%r13),%edi
  6fc1e9:	48 8b b4 24 90 01 00 	mov    0x190(%rsp),%rsi
  6fc1f0:	00 
  6fc1f1:	48 39 fe             	cmp    %rdi,%rsi
  6fc1f4:	0f 86 f4 19 00 00    	jbe    6fdbee <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6bee>
  6fc1fa:	4d 8b 6d 28          	mov    0x28(%r13),%r13
  6fc1fe:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  6fc205:	00 
  6fc206:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  6fc20a:	48 8b 34 c8          	mov    (%rax,%rcx,8),%rsi
  6fc20e:	48 8b 84 24 90 02 00 	mov    0x290(%rsp),%rax
  6fc215:	00 
  6fc216:	48 8b 38             	mov    (%rax),%rdi
  6fc219:	48 89 74 24 78       	mov    %rsi,0x78(%rsp)
  6fc21e:	ff 15 ec f6 38 00    	call   *0x38f6ec(%rip)        # a8b910 <_DYNAMIC+0x428>
  6fc224:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6fc229:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fc22d:	66 0f 7f 84 24 00 05 	movdqa %xmm0,0x500(%rsp)
  6fc234:	00 00 
  6fc236:	4c 89 a4 24 00 03 00 	mov    %r12,0x300(%rsp)
  6fc23d:	00 
  6fc23e:	48 89 9c 24 08 03 00 	mov    %rbx,0x308(%rsp)
  6fc245:	00 
  6fc246:	48 89 ac 24 10 03 00 	mov    %rbp,0x310(%rsp)
  6fc24d:	00 
  6fc24e:	4c 89 b4 24 18 03 00 	mov    %r14,0x318(%rsp)
  6fc255:	00 
  6fc256:	4c 89 bc 24 20 03 00 	mov    %r15,0x320(%rsp)
  6fc25d:	00 
  6fc25e:	4c 89 ac 24 28 03 00 	mov    %r13,0x328(%rsp)
  6fc265:	00 
  6fc266:	48 c7 84 24 f8 02 00 	movq   $0x2,0x2f8(%rsp)
  6fc26d:	00 02 00 00 00 
  6fc272:	48 c7 84 24 30 03 00 	movq   $0x0,0x330(%rsp)
  6fc279:	00 00 00 00 00 
  6fc27e:	bb 02 00 00 00       	mov    $0x2,%ebx
  6fc283:	31 c9                	xor    %ecx,%ecx
  6fc285:	4c 8d a4 24 00 03 00 	lea    0x300(%rsp),%r12
  6fc28c:	00 
  6fc28d:	eb 1d                	jmp    6fc2ac <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x52ac>
  6fc28f:	90                   	nop
  6fc290:	48 8b 84 24 f0 02 00 	mov    0x2f0(%rsp),%rax
  6fc297:	00 
  6fc298:	48 8b 9c 24 f8 02 00 	mov    0x2f8(%rsp),%rbx
  6fc29f:	00 
  6fc2a0:	48 89 c1             	mov    %rax,%rcx
  6fc2a3:	48 39 c3             	cmp    %rax,%rbx
  6fc2a6:	0f 84 e5 04 00 00    	je     6fc791 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5791>
  6fc2ac:	48 8d 41 01          	lea    0x1(%rcx),%rax
  6fc2b0:	48 89 84 24 f0 02 00 	mov    %rax,0x2f0(%rsp)
  6fc2b7:	00 
  6fc2b8:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  6fc2bc:	4d 8b 34 cc          	mov    (%r12,%rcx,8),%r14
  6fc2c0:	49 83 fe fe          	cmp    $0xfffffffffffffffe,%r14
  6fc2c4:	0f 84 c2 04 00 00    	je     6fc78c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x578c>
  6fc2ca:	4c 8b bc 24 30 03 00 	mov    0x330(%rsp),%r15
  6fc2d1:	00 
  6fc2d2:	49 8d 57 01          	lea    0x1(%r15),%rdx
  6fc2d6:	48 89 94 24 30 03 00 	mov    %rdx,0x330(%rsp)
  6fc2dd:	00 
  6fc2de:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
  6fc2e2:	74 bc                	je     6fc2a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x52a0>
  6fc2e4:	49 8d 04 cc          	lea    (%r12,%rcx,8),%rax
  6fc2e8:	4c 89 b4 24 e0 06 00 	mov    %r14,0x6e0(%rsp)
  6fc2ef:	00 
  6fc2f0:	f3 0f 6f 40 08       	movdqu 0x8(%rax),%xmm0
  6fc2f5:	48 8d 84 24 e8 06 00 	lea    0x6e8(%rsp),%rax
  6fc2fc:	00 
  6fc2fd:	f3 0f 7f 00          	movdqu %xmm0,(%rax)
  6fc301:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
  6fc308:	00 
  6fc309:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
  6fc310:	00 
  6fc311:	ff 15 d1 f8 38 00    	call   *0x38f8d1(%rip)        # a8bbe8 <_DYNAMIC+0x700>
  6fc317:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  6fc31c:	48 85 f6             	test   %rsi,%rsi
  6fc31f:	0f 84 ab 00 00 00    	je     6fc3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x53d0>
  6fc325:	31 c0                	xor    %eax,%eax
  6fc327:	4d 85 ff             	test   %r15,%r15
  6fc32a:	0f 95 c0             	setne  %al
  6fc32d:	48 83 7c c6 08 00    	cmpq   $0x0,0x8(%rsi,%rax,8)
  6fc333:	0f 84 97 00 00 00    	je     6fc3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x53d0>
  6fc339:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6fc33e:	48 ff 81 f0 06 00 00 	incq   0x6f0(%rcx)
  6fc345:	48 8d 04 c5 08 00 00 	lea    0x8(,%rax,8),%rax
  6fc34c:	00 
  6fc34d:	48 8b 94 24 70 04 00 	mov    0x470(%rsp),%rdx
  6fc354:	00 
  6fc355:	4c 8b 24 06          	mov    (%rsi,%rax,1),%r12
  6fc359:	49 8b 1c 24          	mov    (%r12),%rbx
  6fc35d:	48 89 d8             	mov    %rbx,%rax
  6fc360:	48 d1 e8             	shr    $1,%rax
  6fc363:	48 39 d0             	cmp    %rdx,%rax
  6fc366:	75 74                	jne    6fc3dc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x53dc>
  6fc368:	48 8b b4 24 68 04 00 	mov    0x468(%rsp),%rsi
  6fc36f:	00 
  6fc370:	49 8d 7c 24 10       	lea    0x10(%r12),%rdi
  6fc375:	ff 15 9d f5 38 00    	call   *0x38f59d(%rip)        # a8b918 <bcmp@GLIBC_2.2.5>
  6fc37b:	85 c0                	test   %eax,%eax
  6fc37d:	75 5d                	jne    6fc3dc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x53dc>
  6fc37f:	f6 c3 01             	test   $0x1,%bl
  6fc382:	75 31                	jne    6fc3b5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x53b5>
  6fc384:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  6fc389:	a8 01                	test   $0x1,%al
  6fc38b:	75 28                	jne    6fc3b5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x53b5>
  6fc38d:	b8 02 00 00 00       	mov    $0x2,%eax
  6fc392:	f0 49 0f c1 44 24 08 	lock xadd %rax,0x8(%r12)
  6fc399:	48 b9 01 00 00 00 00 	movabs $0x8000000000000001,%rcx
  6fc3a0:	00 00 80 
  6fc3a3:	48 21 c8             	and    %rcx,%rax
  6fc3a6:	48 ff c9             	dec    %rcx
  6fc3a9:	48 39 c8             	cmp    %rcx,%rax
  6fc3ac:	75 07                	jne    6fc3b5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x53b5>
  6fc3ae:	f0 49 83 4c 24 08 01 	lock orq $0x1,0x8(%r12)
  6fc3b5:	49 83 ff 01          	cmp    $0x1,%r15
  6fc3b9:	0f 86 31 03 00 00    	jbe    6fc6f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56f0>
  6fc3bf:	e9 5c 18 00 00       	jmp    6fdc20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c20>
  6fc3c4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fc3cb:	00 00 00 00 00 
  6fc3d0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fc3d5:	48 ff 80 f0 06 00 00 	incq   0x6f0(%rax)
  6fc3dc:	49 83 ff 02          	cmp    $0x2,%r15
  6fc3e0:	0f 83 1c 16 00 00    	jae    6fda02 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a02>
  6fc3e6:	4e 8b ac fc d0 08 00 	mov    0x8d0(%rsp,%r15,8),%r13
  6fc3ed:	00 
  6fc3ee:	4d 85 ed             	test   %r13,%r13
  6fc3f1:	74 70                	je     6fc463 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5463>
  6fc3f3:	48 8b 84 24 48 04 00 	mov    0x448(%rsp),%rax
  6fc3fa:	00 
  6fc3fb:	48 85 c0             	test   %rax,%rax
  6fc3fe:	0f 84 3c 01 00 00    	je     6fc540 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5540>
  6fc404:	48 8b 8c 24 50 04 00 	mov    0x450(%rsp),%rcx
  6fc40b:	00 
  6fc40c:	0f b7 b0 ba 00 00 00 	movzwl 0xba(%rax),%esi
  6fc413:	89 f7                	mov    %esi,%edi
  6fc415:	c1 e7 03             	shl    $0x3,%edi
  6fc418:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6fc41f:	90                   	nop
  6fc420:	48 85 ff             	test   %rdi,%rdi
  6fc423:	74 27                	je     6fc44c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x544c>
  6fc425:	4c 3b 6c d0 10       	cmp    0x10(%rax,%rdx,8),%r13
  6fc42a:	41 0f 97 c0          	seta   %r8b
  6fc42e:	41 80 d8 00          	sbb    $0x0,%r8b
  6fc432:	48 ff c2             	inc    %rdx
  6fc435:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  6fc439:	41 80 f8 01          	cmp    $0x1,%r8b
  6fc43d:	74 e1                	je     6fc420 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5420>
  6fc43f:	41 0f b6 f0          	movzbl %r8b,%esi
  6fc443:	85 f6                	test   %esi,%esi
  6fc445:	75 08                	jne    6fc44f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x544f>
  6fc447:	e9 a6 00 00 00       	jmp    6fc4f2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x54f2>
  6fc44c:	48 89 f2             	mov    %rsi,%rdx
  6fc44f:	48 83 e9 01          	sub    $0x1,%rcx
  6fc453:	0f 82 e7 00 00 00    	jb     6fc540 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5540>
  6fc459:	48 8b 84 d0 c0 00 00 	mov    0xc0(%rax,%rdx,8),%rax
  6fc460:	00 
  6fc461:	eb a9                	jmp    6fc40c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x540c>
  6fc463:	48 8b 9c 24 70 04 00 	mov    0x470(%rsp),%rbx
  6fc46a:	00 
  6fc46b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fc470:	f3 0f 6f 80 f8 06 00 	movdqu 0x6f8(%rax),%xmm0
  6fc477:	00 
  6fc478:	66 48 0f 6e cb       	movq   %rbx,%xmm1
  6fc47d:	66 0f 6f 15 bb aa 95 	movdqa -0x6a5545(%rip),%xmm2        # 56f40 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x920>
  6fc484:	ff 
  6fc485:	66 0f 6c d1          	punpcklqdq %xmm1,%xmm2
  6fc489:	66 0f d4 d0          	paddq  %xmm0,%xmm2
  6fc48d:	f3 0f 7f 90 f8 06 00 	movdqu %xmm2,0x6f8(%rax)
  6fc494:	00 
  6fc495:	4c 8d 25 64 b2 95 ff 	lea    -0x6a4d9c(%rip),%r12        # 57700 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x10e0>
  6fc49c:	48 85 db             	test   %rbx,%rbx
  6fc49f:	0f 84 4b 02 00 00    	je     6fc6f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56f0>
  6fc4a5:	48 8b ac 24 68 04 00 	mov    0x468(%rsp),%rbp
  6fc4ac:	00 
  6fc4ad:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6fc4b4:	00 
  6fc4b5:	48 89 de             	mov    %rbx,%rsi
  6fc4b8:	31 d2                	xor    %edx,%edx
  6fc4ba:	31 c9                	xor    %ecx,%ecx
  6fc4bc:	ff 15 5e f4 38 00    	call   *0x38f45e(%rip)        # a8b920 <_DYNAMIC+0x438>
  6fc4c2:	48 8b bc 24 a0 01 00 	mov    0x1a0(%rsp),%rdi
  6fc4c9:	00 
  6fc4ca:	48 83 ff ff          	cmp    $0xffffffffffffffff,%rdi
  6fc4ce:	0f 85 be 15 00 00    	jne    6fda92 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a92>
  6fc4d4:	4c 8b a4 24 a8 01 00 	mov    0x1a8(%rsp),%r12
  6fc4db:	00 
  6fc4dc:	49 8d 7c 24 10       	lea    0x10(%r12),%rdi
  6fc4e1:	48 89 ee             	mov    %rbp,%rsi
  6fc4e4:	48 89 da             	mov    %rbx,%rdx
  6fc4e7:	ff 15 5b f2 38 00    	call   *0x38f25b(%rip)        # a8b748 <memcpy@GLIBC_2.14>
  6fc4ed:	e9 fe 01 00 00       	jmp    6fc6f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56f0>
  6fc4f2:	4c 8b 64 d0 60       	mov    0x60(%rax,%rdx,8),%r12
  6fc4f7:	41 f6 04 24 01       	testb  $0x1,(%r12)
  6fc4fc:	0f 85 ee 01 00 00    	jne    6fc6f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56f0>
  6fc502:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  6fc507:	a8 01                	test   $0x1,%al
  6fc509:	0f 85 e1 01 00 00    	jne    6fc6f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56f0>
  6fc50f:	b8 02 00 00 00       	mov    $0x2,%eax
  6fc514:	f0 49 0f c1 44 24 08 	lock xadd %rax,0x8(%r12)
  6fc51b:	48 b9 01 00 00 00 00 	movabs $0x8000000000000001,%rcx
  6fc522:	00 00 80 
  6fc525:	48 21 c8             	and    %rcx,%rax
  6fc528:	48 ff c9             	dec    %rcx
  6fc52b:	48 39 c8             	cmp    %rcx,%rax
  6fc52e:	0f 85 bc 01 00 00    	jne    6fc6f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56f0>
  6fc534:	f0 49 83 4c 24 08 01 	lock orq $0x1,0x8(%r12)
  6fc53b:	e9 b0 01 00 00       	jmp    6fc6f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56f0>
  6fc540:	48 8b 9c 24 70 04 00 	mov    0x470(%rsp),%rbx
  6fc547:	00 
  6fc548:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fc54d:	f3 0f 6f 80 f8 06 00 	movdqu 0x6f8(%rax),%xmm0
  6fc554:	00 
  6fc555:	66 48 0f 6e cb       	movq   %rbx,%xmm1
  6fc55a:	66 0f 6f 15 de a9 95 	movdqa -0x6a5622(%rip),%xmm2        # 56f40 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x920>
  6fc561:	ff 
  6fc562:	66 0f 6c d1          	punpcklqdq %xmm1,%xmm2
  6fc566:	66 0f d4 d0          	paddq  %xmm0,%xmm2
  6fc56a:	f3 0f 7f 90 f8 06 00 	movdqu %xmm2,0x6f8(%rax)
  6fc571:	00 
  6fc572:	4c 8d 25 87 b1 95 ff 	lea    -0x6a4e79(%rip),%r12        # 57700 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x10e0>
  6fc579:	48 85 db             	test   %rbx,%rbx
  6fc57c:	74 48                	je     6fc5c6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x55c6>
  6fc57e:	48 8b ac 24 68 04 00 	mov    0x468(%rsp),%rbp
  6fc585:	00 
  6fc586:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6fc58d:	00 
  6fc58e:	48 89 de             	mov    %rbx,%rsi
  6fc591:	31 d2                	xor    %edx,%edx
  6fc593:	31 c9                	xor    %ecx,%ecx
  6fc595:	ff 15 85 f3 38 00    	call   *0x38f385(%rip)        # a8b920 <_DYNAMIC+0x438>
  6fc59b:	48 8b bc 24 a0 01 00 	mov    0x1a0(%rsp),%rdi
  6fc5a2:	00 
  6fc5a3:	48 83 ff ff          	cmp    $0xffffffffffffffff,%rdi
  6fc5a7:	0f 85 e5 14 00 00    	jne    6fda92 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a92>
  6fc5ad:	4c 8b a4 24 a8 01 00 	mov    0x1a8(%rsp),%r12
  6fc5b4:	00 
  6fc5b5:	49 8d 7c 24 10       	lea    0x10(%r12),%rdi
  6fc5ba:	48 89 ee             	mov    %rbp,%rsi
  6fc5bd:	48 89 da             	mov    %rbx,%rdx
  6fc5c0:	ff 15 82 f1 38 00    	call   *0x38f182(%rip)        # a8b748 <memcpy@GLIBC_2.14>
  6fc5c6:	41 f6 04 24 01       	testb  $0x1,(%r12)
  6fc5cb:	75 31                	jne    6fc5fe <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x55fe>
  6fc5cd:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  6fc5d2:	a8 01                	test   $0x1,%al
  6fc5d4:	75 28                	jne    6fc5fe <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x55fe>
  6fc5d6:	b8 02 00 00 00       	mov    $0x2,%eax
  6fc5db:	f0 49 0f c1 44 24 08 	lock xadd %rax,0x8(%r12)
  6fc5e2:	48 b9 01 00 00 00 00 	movabs $0x8000000000000001,%rcx
  6fc5e9:	00 00 80 
  6fc5ec:	48 21 c8             	and    %rcx,%rax
  6fc5ef:	48 ff c9             	dec    %rcx
  6fc5f2:	48 39 c8             	cmp    %rcx,%rax
  6fc5f5:	75 07                	jne    6fc5fe <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x55fe>
  6fc5f7:	f0 49 83 4c 24 08 01 	lock orq $0x1,0x8(%r12)
  6fc5fe:	48 8b 84 24 48 04 00 	mov    0x448(%rsp),%rax
  6fc605:	00 
  6fc606:	48 85 c0             	test   %rax,%rax
  6fc609:	0f 84 8b 00 00 00    	je     6fc69a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x569a>
  6fc60f:	48 8b 8c 24 50 04 00 	mov    0x450(%rsp),%rcx
  6fc616:	00 
  6fc617:	0f b7 b0 ba 00 00 00 	movzwl 0xba(%rax),%esi
  6fc61e:	89 f7                	mov    %esi,%edi
  6fc620:	c1 e7 03             	shl    $0x3,%edi
  6fc623:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6fc62a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  6fc630:	48 85 ff             	test   %rdi,%rdi
  6fc633:	74 24                	je     6fc659 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5659>
  6fc635:	4c 3b 6c d0 10       	cmp    0x10(%rax,%rdx,8),%r13
  6fc63a:	41 0f 97 c0          	seta   %r8b
  6fc63e:	41 80 d8 00          	sbb    $0x0,%r8b
  6fc642:	48 ff c2             	inc    %rdx
  6fc645:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  6fc649:	41 80 f8 01          	cmp    $0x1,%r8b
  6fc64d:	74 e1                	je     6fc630 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5630>
  6fc64f:	41 0f b6 f0          	movzbl %r8b,%esi
  6fc653:	85 f6                	test   %esi,%esi
  6fc655:	75 05                	jne    6fc65c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x565c>
  6fc657:	eb 13                	jmp    6fc66c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x566c>
  6fc659:	48 89 f2             	mov    %rsi,%rdx
  6fc65c:	48 83 e9 01          	sub    $0x1,%rcx
  6fc660:	72 3a                	jb     6fc69c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x569c>
  6fc662:	48 8b 84 d0 c0 00 00 	mov    0xc0(%rax,%rdx,8),%rax
  6fc669:	00 
  6fc66a:	eb ab                	jmp    6fc617 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5617>
  6fc66c:	48 8b 7c d0 60       	mov    0x60(%rax,%rdx,8),%rdi
  6fc671:	4c 89 64 d0 60       	mov    %r12,0x60(%rax,%rdx,8)
  6fc676:	f6 07 01             	testb  $0x1,(%rdi)
  6fc679:	75 75                	jne    6fc6f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56f0>
  6fc67b:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fc67f:	a8 01                	test   $0x1,%al
  6fc681:	75 6d                	jne    6fc6f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56f0>
  6fc683:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6fc687:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6fc68c:	75 62                	jne    6fc6f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56f0>
  6fc68e:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fc692:	ff 15 e8 f0 38 00    	call   *0x38f0e8(%rip)        # a8b780 <_DYNAMIC+0x298>
  6fc698:	eb 56                	jmp    6fc6f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56f0>
  6fc69a:	31 c0                	xor    %eax,%eax
  6fc69c:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
  6fc6a3:	00 
  6fc6a4:	48 8d 8c 24 48 04 00 	lea    0x448(%rsp),%rcx
  6fc6ab:	00 
  6fc6ac:	48 89 8c 24 a8 01 00 	mov    %rcx,0x1a8(%rsp)
  6fc6b3:	00 
  6fc6b4:	48 89 84 24 b0 01 00 	mov    %rax,0x1b0(%rsp)
  6fc6bb:	00 
  6fc6bc:	48 c7 84 24 b8 01 00 	movq   $0x0,0x1b8(%rsp)
  6fc6c3:	00 00 00 00 00 
  6fc6c8:	48 89 94 24 c0 01 00 	mov    %rdx,0x1c0(%rsp)
  6fc6cf:	00 
  6fc6d0:	48 8d bc 24 90 03 00 	lea    0x390(%rsp),%rdi
  6fc6d7:	00 
  6fc6d8:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
  6fc6df:	00 
  6fc6e0:	4c 89 e2             	mov    %r12,%rdx
  6fc6e3:	e8 d8 50 01 00       	call   7117c0 <<alloc::collections::btree::map::entry::VacantEntry<gpui::source::FieldId, gpui::shared_text::SharedText>>::insert_entry>
  6fc6e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6fc6ef:	00 
  6fc6f0:	4a 8b bc fc 00 05 00 	mov    0x500(%rsp,%r15,8),%rdi
  6fc6f7:	00 
  6fc6f8:	48 85 ff             	test   %rdi,%rdi
  6fc6fb:	74 23                	je     6fc720 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5720>
  6fc6fd:	f6 07 01             	testb  $0x1,(%rdi)
  6fc700:	75 1e                	jne    6fc720 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5720>
  6fc702:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fc706:	a8 01                	test   $0x1,%al
  6fc708:	75 16                	jne    6fc720 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5720>
  6fc70a:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6fc70e:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6fc713:	74 6b                	je     6fc780 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5780>
  6fc715:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6fc71c:	00 00 00 00 
  6fc720:	4e 89 a4 fc 00 05 00 	mov    %r12,0x500(%rsp,%r15,8)
  6fc727:	00 
  6fc728:	48 8b b4 24 60 04 00 	mov    0x460(%rsp),%rsi
  6fc72f:	00 
  6fc730:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fc734:	74 18                	je     6fc74e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x574e>
  6fc736:	48 85 f6             	test   %rsi,%rsi
  6fc739:	74 13                	je     6fc74e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x574e>
  6fc73b:	48 8b bc 24 68 04 00 	mov    0x468(%rsp),%rdi
  6fc742:	00 
  6fc743:	ba 01 00 00 00       	mov    $0x1,%edx
  6fc748:	ff 15 ea ef 38 00    	call   *0x38efea(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fc74e:	4d 85 f6             	test   %r14,%r14
  6fc751:	4c 8d a4 24 00 03 00 	lea    0x300(%rsp),%r12
  6fc758:	00 
  6fc759:	0f 88 31 fb ff ff    	js     6fc290 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5290>
  6fc75f:	0f 84 2b fb ff ff    	je     6fc290 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5290>
  6fc765:	48 8b bc 24 e8 06 00 	mov    0x6e8(%rsp),%rdi
  6fc76c:	00 
  6fc76d:	ba 01 00 00 00       	mov    $0x1,%edx
  6fc772:	4c 89 f6             	mov    %r14,%rsi
  6fc775:	ff 15 bd ef 38 00    	call   *0x38efbd(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fc77b:	e9 10 fb ff ff       	jmp    6fc290 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5290>
  6fc780:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fc784:	ff 15 f6 ef 38 00    	call   *0x38eff6(%rip)        # a8b780 <_DYNAMIC+0x298>
  6fc78a:	eb 94                	jmp    6fc720 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5720>
  6fc78c:	48 29 c3             	sub    %rax,%rbx
  6fc78f:	75 44                	jne    6fc7d5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x57d5>
  6fc791:	4c 8b b4 24 00 05 00 	mov    0x500(%rsp),%r14
  6fc798:	00 
  6fc799:	48 8b 9c 24 08 05 00 	mov    0x508(%rsp),%rbx
  6fc7a0:	00 
  6fc7a1:	4c 89 f0             	mov    %r14,%rax
  6fc7a4:	48 09 d8             	or     %rbx,%rax
  6fc7a7:	0f 84 c2 f9 ff ff    	je     6fc16f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x516f>
  6fc7ad:	4c 8b bc 24 d8 04 00 	mov    0x4d8(%rsp),%r15
  6fc7b4:	00 
  6fc7b5:	4c 3b bc 24 c8 04 00 	cmp    0x4c8(%rsp),%r15
  6fc7bc:	00 
  6fc7bd:	0f 85 82 f9 ff ff    	jne    6fc145 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5145>
  6fc7c3:	48 8d bc 24 c8 04 00 	lea    0x4c8(%rsp),%rdi
  6fc7ca:	00 
  6fc7cb:	e8 80 45 02 00       	call   720d50 <<alloc::raw_vec::RawVec<gpui::style_port::Draft>>::grow_one>
  6fc7d0:	e9 70 f9 ff ff       	jmp    6fc145 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5145>
  6fc7d5:	4d 8d 34 cc          	lea    (%r12,%rcx,8),%r14
  6fc7d9:	49 83 c6 20          	add    $0x20,%r14
  6fc7dd:	eb 0a                	jmp    6fc7e9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x57e9>
  6fc7df:	90                   	nop
  6fc7e0:	49 83 c6 18          	add    $0x18,%r14
  6fc7e4:	48 ff cb             	dec    %rbx
  6fc7e7:	74 a8                	je     6fc791 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5791>
  6fc7e9:	49 8b 76 f8          	mov    -0x8(%r14),%rsi
  6fc7ed:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fc7f1:	74 ed                	je     6fc7e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x57e0>
  6fc7f3:	48 85 f6             	test   %rsi,%rsi
  6fc7f6:	78 e8                	js     6fc7e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x57e0>
  6fc7f8:	74 e6                	je     6fc7e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x57e0>
  6fc7fa:	49 8b 3e             	mov    (%r14),%rdi
  6fc7fd:	ba 01 00 00 00       	mov    $0x1,%edx
  6fc802:	ff 15 30 ef 38 00    	call   *0x38ef30(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fc808:	eb d6                	jmp    6fc7e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x57e0>
  6fc80a:	b8 08 00 00 00       	mov    $0x8,%eax
  6fc80f:	4c 89 bc 24 f0 02 00 	mov    %r15,0x2f0(%rsp)
  6fc816:	00 
  6fc817:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
  6fc81e:	00 
  6fc81f:	48 c7 84 24 00 03 00 	movq   $0x0,0x300(%rsp)
  6fc826:	00 00 00 00 00 
  6fc82b:	48 85 db             	test   %rbx,%rbx
  6fc82e:	0f 84 45 02 00 00    	je     6fca79 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5a79>
  6fc834:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
  6fc838:	49 8d 04 c6          	lea    (%r14,%rax,8),%rax
  6fc83c:	48 89 84 24 80 03 00 	mov    %rax,0x380(%rsp)
  6fc843:	00 
  6fc844:	41 bc 02 00 00 00    	mov    $0x2,%r12d
  6fc84a:	45 31 ff             	xor    %r15d,%r15d
  6fc84d:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  6fc854:	00 
  6fc855:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  6fc85c:	00 
  6fc85d:	eb 47                	jmp    6fc8a6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x58a6>
  6fc85f:	48 8b 84 24 f8 02 00 	mov    0x2f8(%rsp),%rax
  6fc866:	00 
  6fc867:	48 89 e9             	mov    %rbp,%rcx
  6fc86a:	48 c1 e1 04          	shl    $0x4,%rcx
  6fc86e:	4c 89 2c 08          	mov    %r13,(%rax,%rcx,1)
  6fc872:	66 0f 6e 44 24 20    	movd   0x20(%rsp),%xmm0
  6fc878:	66 0f 7e 44 08 08    	movd   %xmm0,0x8(%rax,%rcx,1)
  6fc87e:	48 ff c5             	inc    %rbp
  6fc881:	48 89 ac 24 00 03 00 	mov    %rbp,0x300(%rsp)
  6fc888:	00 
  6fc889:	49 83 c6 18          	add    $0x18,%r14
  6fc88d:	49 ff c7             	inc    %r15
  6fc890:	4c 3b b4 24 80 03 00 	cmp    0x380(%rsp),%r14
  6fc897:	00 
  6fc898:	4c 8b ac 24 08 02 00 	mov    0x208(%rsp),%r13
  6fc89f:	00 
  6fc8a0:	0f 84 a7 01 00 00    	je     6fca4d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5a4d>
  6fc8a6:	49 83 fc 02          	cmp    $0x2,%r12
  6fc8aa:	74 1c                	je     6fc8c8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x58c8>
  6fc8ac:	49 83 fc 01          	cmp    $0x1,%r12
  6fc8b0:	75 55                	jne    6fc907 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5907>
  6fc8b2:	4c 39 fb             	cmp    %r15,%rbx
  6fc8b5:	75 50                	jne    6fc907 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5907>
  6fc8b7:	41 bc 02 00 00 00    	mov    $0x2,%r12d
  6fc8bd:	4c 89 fb             	mov    %r15,%rbx
  6fc8c0:	66 0f 6e 44 24 78    	movd   0x78(%rsp),%xmm0
  6fc8c6:	eb 43                	jmp    6fc90b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x590b>
  6fc8c8:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
  6fc8cf:	00 
  6fc8d0:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
  6fc8d7:	00 
  6fc8d8:	48 39 c1             	cmp    %rax,%rcx
  6fc8db:	0f 84 53 01 00 00    	je     6fca34 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5a34>
  6fc8e1:	48 8b 19             	mov    (%rcx),%rbx
  6fc8e4:	66 0f 6e 41 08       	movd   0x8(%rcx),%xmm0
  6fc8e9:	66 0f 7e 44 24 78    	movd   %xmm0,0x78(%rsp)
  6fc8ef:	48 8d 41 10          	lea    0x10(%rcx),%rax
  6fc8f3:	41 bc 01 00 00 00    	mov    $0x1,%r12d
  6fc8f9:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  6fc900:	00 
  6fc901:	49 83 fc 01          	cmp    $0x1,%r12
  6fc905:	74 ab                	je     6fc8b2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x58b2>
  6fc907:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fc90b:	66 0f 7e 44 24 20    	movd   %xmm0,0x20(%rsp)
  6fc911:	4d 8b 2e             	mov    (%r14),%r13
  6fc914:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  6fc919:	4c 89 ee             	mov    %r13,%rsi
  6fc91c:	ff 15 7e f1 38 00    	call   *0x38f17e(%rip)        # a8baa0 <_DYNAMIC+0x5b8>
  6fc922:	66 0f 7e 84 24 a0 01 	movd   %xmm0,0x1a0(%rsp)
  6fc929:	00 00 
  6fc92b:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  6fc930:	48 8b 41 48          	mov    0x48(%rcx),%rax
  6fc934:	48 85 c0             	test   %rax,%rax
  6fc937:	0f 84 7d 00 00 00    	je     6fc9ba <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x59ba>
  6fc93d:	48 8b 49 50          	mov    0x50(%rcx),%rcx
  6fc941:	66 0f 6e 44 24 20    	movd   0x20(%rsp),%xmm0
  6fc947:	0f b7 b0 c2 01 00 00 	movzwl 0x1c2(%rax),%esi
  6fc94e:	48 8d 68 e0          	lea    -0x20(%rax),%rbp
  6fc952:	89 f7                	mov    %esi,%edi
  6fc954:	c1 e7 03             	shl    $0x3,%edi
  6fc957:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6fc95e:	66 90                	xchg   %ax,%ax
  6fc960:	48 85 ff             	test   %rdi,%rdi
  6fc963:	74 2b                	je     6fc990 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5990>
  6fc965:	4c 3b ac d0 70 01 00 	cmp    0x170(%rax,%rdx,8),%r13
  6fc96c:	00 
  6fc96d:	41 0f 97 c0          	seta   %r8b
  6fc971:	41 80 d8 00          	sbb    $0x0,%r8b
  6fc975:	48 83 c5 20          	add    $0x20,%rbp
  6fc979:	48 ff c2             	inc    %rdx
  6fc97c:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  6fc980:	41 80 f8 01          	cmp    $0x1,%r8b
  6fc984:	74 da                	je     6fc960 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5960>
  6fc986:	41 0f b6 f0          	movzbl %r8b,%esi
  6fc98a:	85 f6                	test   %esi,%esi
  6fc98c:	75 05                	jne    6fc993 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5993>
  6fc98e:	eb 13                	jmp    6fc9a3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x59a3>
  6fc990:	48 89 f2             	mov    %rsi,%rdx
  6fc993:	48 83 e9 01          	sub    $0x1,%rcx
  6fc997:	72 27                	jb     6fc9c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x59c0>
  6fc999:	48 8b 84 d0 c8 01 00 	mov    0x1c8(%rax,%rdx,8),%rax
  6fc9a0:	00 
  6fc9a1:	eb a4                	jmp    6fc947 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5947>
  6fc9a3:	48 89 ef             	mov    %rbp,%rdi
  6fc9a6:	31 f6                	xor    %esi,%esi
  6fc9a8:	e8 d3 e6 01 00       	call   71b080 <gpui::property::apply_except::<gpui::property::GeometryStyle>>
  6fc9ad:	66 0f 6e 4c 24 20    	movd   0x20(%rsp),%xmm1
  6fc9b3:	66 0f 7e 4d 18       	movd   %xmm1,0x18(%rbp)
  6fc9b8:	eb 06                	jmp    6fc9c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x59c0>
  6fc9ba:	66 0f 6e 44 24 20    	movd   0x20(%rsp),%xmm0
  6fc9c0:	66 0f 7e 44 24 20    	movd   %xmm0,0x20(%rsp)
  6fc9c6:	66 0f 7e 84 24 90 00 	movd   %xmm0,0x90(%rsp)
  6fc9cd:	00 00 
  6fc9cf:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6fc9d6:	00 
  6fc9d7:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6fc9de:	00 
  6fc9df:	48 8b 05 0a ef 38 00 	mov    0x38ef0a(%rip),%rax        # a8b8f0 <_DYNAMIC+0x408>
  6fc9e6:	ff 50 18             	call   *0x18(%rax)
  6fc9e9:	84 c0                	test   %al,%al
  6fc9eb:	75 0c                	jne    6fc9f9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x59f9>
  6fc9ed:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fc9f2:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6fc9f9:	66 0f 6e 44 24 20    	movd   0x20(%rsp),%xmm0
  6fc9ff:	66 0f 7e c0          	movd   %xmm0,%eax
  6fca03:	85 c0                	test   %eax,%eax
  6fca05:	0f 84 7e fe ff ff    	je     6fc889 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5889>
  6fca0b:	48 8b ac 24 00 03 00 	mov    0x300(%rsp),%rbp
  6fca12:	00 
  6fca13:	48 3b ac 24 f0 02 00 	cmp    0x2f0(%rsp),%rbp
  6fca1a:	00 
  6fca1b:	0f 85 3e fe ff ff    	jne    6fc85f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x585f>
  6fca21:	48 8d bc 24 f0 02 00 	lea    0x2f0(%rsp),%rdi
  6fca28:	00 
  6fca29:	ff 15 d9 f1 38 00    	call   *0x38f1d9(%rip)        # a8bc08 <_DYNAMIC+0x720>
  6fca2f:	e9 2b fe ff ff       	jmp    6fc85f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x585f>
  6fca34:	0f 57 c0             	xorps  %xmm0,%xmm0
  6fca37:	f3 0f 11 44 24 20    	movss  %xmm0,0x20(%rsp)
  6fca3d:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  6fca44:	00 
  6fca45:	45 31 e4             	xor    %r12d,%r12d
  6fca48:	e9 c4 fe ff ff       	jmp    6fc911 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5911>
  6fca4d:	48 8b bc 24 f8 02 00 	mov    0x2f8(%rsp),%rdi
  6fca54:	00 
  6fca55:	48 8b b4 24 00 03 00 	mov    0x300(%rsp),%rsi
  6fca5c:	00 
  6fca5d:	48 8d 44 24 77       	lea    0x77(%rsp),%rax
  6fca62:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6fca69:	00 
  6fca6a:	48 83 fe 02          	cmp    $0x2,%rsi
  6fca6e:	4c 8b 64 24 40       	mov    0x40(%rsp),%r12
  6fca73:	0f 83 e3 0e 00 00    	jae    6fd95c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x695c>
  6fca79:	48 8b 84 24 00 03 00 	mov    0x300(%rsp),%rax
  6fca80:	00 
  6fca81:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6fca88:	00 
  6fca89:	0f 10 84 24 f0 02 00 	movups 0x2f0(%rsp),%xmm0
  6fca90:	00 
  6fca91:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
  6fca98:	00 
  6fca99:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  6fca9e:	48 8b 33             	mov    (%rbx),%rsi
  6fcaa1:	48 85 f6             	test   %rsi,%rsi
  6fcaa4:	74 13                	je     6fcab9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5ab9>
  6fcaa6:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
  6fcaaa:	48 c1 e6 04          	shl    $0x4,%rsi
  6fcaae:	ba 08 00 00 00       	mov    $0x8,%edx
  6fcab3:	ff 15 7f ec 38 00    	call   *0x38ec7f(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fcab9:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  6fcac0:	00 
  6fcac1:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fcac5:	66 0f 6f 84 24 90 00 	movdqa 0x90(%rsp),%xmm0
  6fcacc:	00 00 
  6fcace:	f3 0f 7f 03          	movdqu %xmm0,(%rbx)
  6fcad2:	48 83 7b 10 00       	cmpq   $0x0,0x10(%rbx)
  6fcad7:	75 19                	jne    6fcaf2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5af2>
  6fcad9:	48 83 7b 58 00       	cmpq   $0x0,0x58(%rbx)
  6fcade:	75 12                	jne    6fcaf2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5af2>
  6fcae0:	48 83 7b 28 00       	cmpq   $0x0,0x28(%rbx)
  6fcae5:	75 0b                	jne    6fcaf2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5af2>
  6fcae7:	48 83 7b 30 ff       	cmpq   $0xffffffffffffffff,0x30(%rbx)
  6fcaec:	0f 84 a5 0c 00 00    	je     6fd797 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6797>
  6fcaf2:	49 8b bc 24 00 01 00 	mov    0x100(%r12),%rdi
  6fcaf9:	00 
  6fcafa:	e8 d1 58 fe ff       	call   6e23d0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::geometry::Geometry>>>>
  6fcaff:	49 89 9c 24 00 01 00 	mov    %rbx,0x100(%r12)
  6fcb06:	00 
  6fcb07:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
  6fcb0e:	00 
  6fcb0f:	48 85 f6             	test   %rsi,%rsi
  6fcb12:	74 17                	je     6fcb2b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5b2b>
  6fcb14:	48 c1 e6 04          	shl    $0x4,%rsi
  6fcb18:	ba 08 00 00 00       	mov    $0x8,%edx
  6fcb1d:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  6fcb24:	00 
  6fcb25:	ff 15 0d ec 38 00    	call   *0x38ec0d(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fcb2b:	48 8b 84 24 40 05 00 	mov    0x540(%rsp),%rax
  6fcb32:	00 
  6fcb33:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6fcb3a:	00 
  6fcb3b:	0f 10 84 24 30 05 00 	movups 0x530(%rsp),%xmm0
  6fcb42:	00 
  6fcb43:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
  6fcb4a:	00 
  6fcb4b:	48 8b 9c 24 40 02 00 	mov    0x240(%rsp),%rbx
  6fcb52:	00 
  6fcb53:	48 89 df             	mov    %rbx,%rdi
  6fcb56:	e8 95 f6 00 00       	call   70c1f0 <<alloc::collections::btree::map::BTreeMap<gpui::runtime::scroll::ViewportKey, gpui::runtime::scroll::ViewportState> as core::ops::drop::Drop>::drop>
  6fcb5b:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  6fcb62:	00 
  6fcb63:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fcb67:	0f 28 84 24 90 00 00 	movaps 0x90(%rsp),%xmm0
  6fcb6e:	00 
  6fcb6f:	0f 11 03             	movups %xmm0,(%rbx)
  6fcb72:	48 8b 84 24 18 07 00 	mov    0x718(%rsp),%rax
  6fcb79:	00 
  6fcb7a:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6fcb81:	00 
  6fcb82:	0f 10 84 24 08 07 00 	movups 0x708(%rsp),%xmm0
  6fcb89:	00 
  6fcb8a:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
  6fcb91:	00 
  6fcb92:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
  6fcb97:	49 8d 9c 24 60 06 00 	lea    0x660(%r12),%rbx
  6fcb9e:	00 
  6fcb9f:	48 89 df             	mov    %rbx,%rdi
  6fcba2:	e8 b9 f9 00 00       	call   70c560 <<alloc::collections::btree::map::BTreeMap<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize> as core::ops::drop::Drop>::drop>
  6fcba7:	4d 8d b4 24 90 02 00 	lea    0x290(%r12),%r14
  6fcbae:	00 
  6fcbaf:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  6fcbb6:	00 
  6fcbb7:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fcbbb:	0f 28 84 24 90 00 00 	movaps 0x90(%rsp),%xmm0
  6fcbc2:	00 
  6fcbc3:	0f 11 03             	movups %xmm0,(%rbx)
  6fcbc6:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  6fcbcd:	00 
  6fcbce:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6fcbd5:	00 
  6fcbd6:	0f 10 84 24 80 01 00 	movups 0x180(%rsp),%xmm0
  6fcbdd:	00 
  6fcbde:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
  6fcbe5:	00 
  6fcbe6:	49 8b 06             	mov    (%r14),%rax
  6fcbe9:	48 85 c0             	test   %rax,%rax
  6fcbec:	74 1b                	je     6fcc09 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5c09>
  6fcbee:	49 8b bc 24 98 02 00 	mov    0x298(%r12),%rdi
  6fcbf5:	00 
  6fcbf6:	48 c1 e0 03          	shl    $0x3,%rax
  6fcbfa:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6fcbfe:	ba 08 00 00 00       	mov    $0x8,%edx
  6fcc03:	ff 15 2f eb 38 00    	call   *0x38eb2f(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fcc09:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  6fcc10:	00 
  6fcc11:	49 89 46 10          	mov    %rax,0x10(%r14)
  6fcc15:	0f 28 84 24 90 00 00 	movaps 0x90(%rsp),%xmm0
  6fcc1c:	00 
  6fcc1d:	41 0f 11 06          	movups %xmm0,(%r14)
  6fcc21:	48 8b 84 24 70 05 00 	mov    0x570(%rsp),%rax
  6fcc28:	00 
  6fcc29:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6fcc30:	00 
  6fcc31:	f3 0f 6f 84 24 60 05 	movdqu 0x560(%rsp),%xmm0
  6fcc38:	00 00 
  6fcc3a:	66 0f 7f 84 24 90 00 	movdqa %xmm0,0x90(%rsp)
  6fcc41:	00 00 
  6fcc43:	41 b7 01             	mov    $0x1,%r15b
  6fcc46:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6fcc4d:	00 
  6fcc4e:	e8 dd 63 00 00       	call   703030 <<alloc::vec::Vec<core::option::Option<gpui::element::Handler>>>::into_boxed_slice>
  6fcc53:	49 89 c6             	mov    %rax,%r14
  6fcc56:	48 89 d3             	mov    %rdx,%rbx
  6fcc59:	49 8b bc 24 b0 05 00 	mov    0x5b0(%r12),%rdi
  6fcc60:	00 
  6fcc61:	49 8b b4 24 b8 05 00 	mov    0x5b8(%r12),%rsi
  6fcc68:	00 
  6fcc69:	e8 e2 79 fe ff       	call   6e4650 <core::ptr::drop_glue::<alloc::boxed::Box<[core::option::Option<gpui::element::Handler>]>>>
  6fcc6e:	4d 89 b4 24 b0 05 00 	mov    %r14,0x5b0(%r12)
  6fcc75:	00 
  6fcc76:	49 89 9c 24 b8 05 00 	mov    %rbx,0x5b8(%r12)
  6fcc7d:	00 
  6fcc7e:	48 8d 9c 24 90 00 00 	lea    0x90(%rsp),%rbx
  6fcc85:	00 
  6fcc86:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
  6fcc8d:	00 
  6fcc8e:	ba a0 00 00 00       	mov    $0xa0,%edx
  6fcc93:	48 89 df             	mov    %rbx,%rdi
  6fcc96:	ff 15 ac ea 38 00    	call   *0x38eaac(%rip)        # a8b748 <memcpy@GLIBC_2.14>
  6fcc9c:	45 31 ff             	xor    %r15d,%r15d
  6fcc9f:	48 8d bc 24 f0 02 00 	lea    0x2f0(%rsp),%rdi
  6fcca6:	00 
  6fcca7:	48 89 de             	mov    %rbx,%rsi
  6fccaa:	ff 15 60 ef 38 00    	call   *0x38ef60(%rip)        # a8bc10 <_DYNAMIC+0x728>
  6fccb0:	49 8d 9c 24 00 02 00 	lea    0x200(%r12),%rbx
  6fccb7:	00 
  6fccb8:	48 89 df             	mov    %rbx,%rdi
  6fccbb:	e8 e0 96 fe ff       	call   6e63a0 <core::ptr::drop_glue::<gpui::runtime::styles::Styles>>
  6fccc0:	48 8b 84 24 10 03 00 	mov    0x310(%rsp),%rax
  6fccc7:	00 
  6fccc8:	48 89 43 20          	mov    %rax,0x20(%rbx)
  6fcccc:	0f 10 84 24 f0 02 00 	movups 0x2f0(%rsp),%xmm0
  6fccd3:	00 
  6fccd4:	f3 0f 6f 8c 24 00 03 	movdqu 0x300(%rsp),%xmm1
  6fccdb:	00 00 
  6fccdd:	f3 0f 7f 4b 10       	movdqu %xmm1,0x10(%rbx)
  6fcce2:	0f 11 03             	movups %xmm0,(%rbx)
  6fcce5:	41 83 bc 24 00 02 00 	cmpl   $0x3,0x200(%r12)
  6fccec:	00 03 
  6fccee:	0f 94 c0             	sete   %al
  6fccf1:	41 08 84 24 4b 07 00 	or     %al,0x74b(%r12)
  6fccf8:	00 
  6fccf9:	48 8b 84 24 88 05 00 	mov    0x588(%rsp),%rax
  6fcd00:	00 
  6fcd01:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6fcd08:	00 
  6fcd09:	0f 10 84 24 78 05 00 	movups 0x578(%rsp),%xmm0
  6fcd10:	00 
  6fcd11:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
  6fcd18:	00 
  6fcd19:	49 8d 9c 24 a8 02 00 	lea    0x2a8(%r12),%rbx
  6fcd20:	00 
  6fcd21:	48 89 df             	mov    %rbx,%rdi
  6fcd24:	e8 17 73 00 00       	call   704040 <<alloc::vec::Vec<core::option::Option<gpui::runtime::TextSite>> as core::ops::drop::Drop>::drop>
  6fcd29:	48 8b 03             	mov    (%rbx),%rax
  6fcd2c:	48 85 c0             	test   %rax,%rax
  6fcd2f:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  6fcd34:	74 1a                	je     6fcd50 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5d50>
  6fcd36:	49 8b be b0 02 00 00 	mov    0x2b0(%r14),%rdi
  6fcd3d:	48 c1 e0 04          	shl    $0x4,%rax
  6fcd41:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
  6fcd45:	ba 08 00 00 00       	mov    $0x8,%edx
  6fcd4a:	ff 15 e8 e9 38 00    	call   *0x38e9e8(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fcd50:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  6fcd57:	00 
  6fcd58:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fcd5c:	0f 28 84 24 90 00 00 	movaps 0x90(%rsp),%xmm0
  6fcd63:	00 
  6fcd64:	0f 11 03             	movups %xmm0,(%rbx)
  6fcd67:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  6fcd6e:	00 
  6fcd6f:	48 89 84 24 b0 01 00 	mov    %rax,0x1b0(%rsp)
  6fcd76:	00 
  6fcd77:	f3 0f 6f 84 24 60 01 	movdqu 0x160(%rsp),%xmm0
  6fcd7e:	00 00 
  6fcd80:	66 0f 7f 84 24 a0 01 	movdqa %xmm0,0x1a0(%rsp)
  6fcd87:	00 00 
  6fcd89:	49 8b 8e f8 05 00 00 	mov    0x5f8(%r14),%rcx
  6fcd90:	48 85 c9             	test   %rcx,%rcx
  6fcd93:	74 4d                	je     6fcde2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5de2>
  6fcd95:	49 8b 96 00 06 00 00 	mov    0x600(%r14),%rdx
  6fcd9c:	49 8b 86 08 06 00 00 	mov    0x608(%r14),%rax
  6fcda3:	48 c7 84 24 98 00 00 	movq   $0x0,0x98(%rsp)
  6fcdaa:	00 00 00 00 00 
  6fcdaf:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
  6fcdb6:	00 
  6fcdb7:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
  6fcdbe:	00 
  6fcdbf:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  6fcdc6:	00 00 00 00 00 
  6fcdcb:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
  6fcdd2:	00 
  6fcdd3:	48 89 94 24 c8 00 00 	mov    %rdx,0xc8(%rsp)
  6fcdda:	00 
  6fcddb:	b9 01 00 00 00       	mov    $0x1,%ecx
  6fcde0:	eb 04                	jmp    6fcde6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5de6>
  6fcde2:	31 c9                	xor    %ecx,%ecx
  6fcde4:	31 c0                	xor    %eax,%eax
  6fcde6:	4d 8d be f8 05 00 00 	lea    0x5f8(%r14),%r15
  6fcded:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  6fcdf4:	00 
  6fcdf5:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
  6fcdfc:	00 
  6fcdfd:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  6fce04:	00 
  6fce05:	48 8d bc 24 f0 02 00 	lea    0x2f0(%rsp),%rdi
  6fce0c:	00 
  6fce0d:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6fce14:	00 
  6fce15:	e8 86 d4 00 00       	call   70a2a0 <<alloc::collections::btree::map::IntoIter<gpui::source::FieldId, gpui::runtime::Fanout>>::dying_next>
  6fce1a:	48 8b 84 24 f0 02 00 	mov    0x2f0(%rsp),%rax
  6fce21:	00 
  6fce22:	48 85 c0             	test   %rax,%rax
  6fce25:	74 5f                	je     6fce86 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5e86>
  6fce27:	48 8d 9c 24 f0 02 00 	lea    0x2f0(%rsp),%rbx
  6fce2e:	00 
  6fce2f:	4c 8d b4 24 90 00 00 	lea    0x90(%rsp),%r14
  6fce36:	00 
  6fce37:	4c 8b 25 fa e8 38 00 	mov    0x38e8fa(%rip),%r12        # a8b738 <_DYNAMIC+0x250>
  6fce3e:	66 90                	xchg   %ax,%ax
  6fce40:	48 8b 8c 24 00 03 00 	mov    0x300(%rsp),%rcx
  6fce47:	00 
  6fce48:	48 c1 e1 05          	shl    $0x5,%rcx
  6fce4c:	48 8b 34 08          	mov    (%rax,%rcx,1),%rsi
  6fce50:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fce54:	74 18                	je     6fce6e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5e6e>
  6fce56:	48 85 f6             	test   %rsi,%rsi
  6fce59:	74 13                	je     6fce6e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5e6e>
  6fce5b:	48 01 c8             	add    %rcx,%rax
  6fce5e:	48 8b 78 08          	mov    0x8(%rax),%rdi
  6fce62:	48 c1 e6 02          	shl    $0x2,%rsi
  6fce66:	ba 04 00 00 00       	mov    $0x4,%edx
  6fce6b:	41 ff d4             	call   *%r12
  6fce6e:	48 89 df             	mov    %rbx,%rdi
  6fce71:	4c 89 f6             	mov    %r14,%rsi
  6fce74:	e8 27 d4 00 00       	call   70a2a0 <<alloc::collections::btree::map::IntoIter<gpui::source::FieldId, gpui::runtime::Fanout>>::dying_next>
  6fce79:	48 8b 84 24 f0 02 00 	mov    0x2f0(%rsp),%rax
  6fce80:	00 
  6fce81:	48 85 c0             	test   %rax,%rax
  6fce84:	75 ba                	jne    6fce40 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5e40>
  6fce86:	48 8b 84 24 b0 01 00 	mov    0x1b0(%rsp),%rax
  6fce8d:	00 
  6fce8e:	49 89 47 10          	mov    %rax,0x10(%r15)
  6fce92:	66 0f 6f 84 24 a0 01 	movdqa 0x1a0(%rsp),%xmm0
  6fce99:	00 00 
  6fce9b:	f3 41 0f 7f 07       	movdqu %xmm0,(%r15)
  6fcea0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fcea5:	48 8b b0 98 02 00 00 	mov    0x298(%rax),%rsi
  6fceac:	48 8b 80 a0 02 00 00 	mov    0x2a0(%rax),%rax
  6fceb3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  6fceb7:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
  6fcebb:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6fcec2:	00 
  6fcec3:	44 8b 7c 24 38       	mov    0x38(%rsp),%r15d
  6fcec8:	e8 33 bd 01 00       	call   718c00 <<gpui::runtime::identity_index::IdentityIndex>::from_ids::<core::iter::adapters::map::Map<core::slice::iter::Iter<gpui::runtime::Node>, <gpui::runtime::Node>::identity>>>
  6fcecd:	4c 8b a4 24 90 02 00 	mov    0x290(%rsp),%r12
  6fced4:	00 
  6fced5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fceda:	48 8d 98 e8 01 00 00 	lea    0x1e8(%rax),%rbx
  6fcee1:	48 8b 80 e8 01 00 00 	mov    0x1e8(%rax),%rax
  6fcee8:	48 85 c0             	test   %rax,%rax
  6fceeb:	4c 8b b4 24 20 04 00 	mov    0x420(%rsp),%r14
  6fcef2:	00 
  6fcef3:	74 5d                	je     6fcf52 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5f52>
  6fcef5:	83 f8 01             	cmp    $0x1,%eax
  6fcef8:	75 28                	jne    6fcf22 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5f22>
  6fcefa:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fceff:	48 8b b0 f8 01 00 00 	mov    0x1f8(%rax),%rsi
  6fcf06:	48 85 f6             	test   %rsi,%rsi
  6fcf09:	74 47                	je     6fcf52 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5f52>
  6fcf0b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fcf10:	48 8b b8 f0 01 00 00 	mov    0x1f0(%rax),%rdi
  6fcf17:	48 c1 e6 04          	shl    $0x4,%rsi
  6fcf1b:	ba 08 00 00 00       	mov    $0x8,%edx
  6fcf20:	eb 2a                	jmp    6fcf4c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5f4c>
  6fcf22:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fcf27:	48 8b 80 f8 01 00 00 	mov    0x1f8(%rax),%rax
  6fcf2e:	48 85 c0             	test   %rax,%rax
  6fcf31:	74 1f                	je     6fcf52 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5f52>
  6fcf33:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6fcf38:	48 8b b9 f0 01 00 00 	mov    0x1f0(%rcx),%rdi
  6fcf3f:	48 c1 e0 02          	shl    $0x2,%rax
  6fcf43:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6fcf47:	ba 04 00 00 00       	mov    $0x4,%edx
  6fcf4c:	ff 15 e6 e7 38 00    	call   *0x38e7e6(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fcf52:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  6fcf59:	00 
  6fcf5a:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fcf5e:	f3 0f 6f 84 24 90 00 	movdqu 0x90(%rsp),%xmm0
  6fcf65:	00 00 
  6fcf67:	f3 0f 7f 03          	movdqu %xmm0,(%rbx)
  6fcf6b:	4c 89 f7             	mov    %r14,%rdi
  6fcf6e:	48 89 de             	mov    %rbx,%rsi
  6fcf71:	e8 fa de 01 00       	call   71ae70 <<gpui::property::Overrides>::retain::<<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#49}>>
  6fcf76:	49 8b 3c 24          	mov    (%r12),%rdi
  6fcf7a:	48 85 ff             	test   %rdi,%rdi
  6fcf7d:	74 69                	je     6fcfe8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5fe8>
  6fcf7f:	48 81 c7 e8 00 00 00 	add    $0xe8,%rdi
  6fcf86:	48 89 de             	mov    %rbx,%rsi
  6fcf89:	e8 42 48 fe ff       	call   6e17d0 <<alloc::collections::btree::map::BTreeMap<u64, [gpui::property::Contribution<core::option::Option<gpui::shared_text::SharedText>>; 2]>>::retain::<<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#50}>>
  6fcf8e:	4d 8b 34 24          	mov    (%r12),%r14
  6fcf92:	49 8b be 00 01 00 00 	mov    0x100(%r14),%rdi
  6fcf99:	48 85 ff             	test   %rdi,%rdi
  6fcf9c:	74 4a                	je     6fcfe8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5fe8>
  6fcf9e:	48 83 c7 48          	add    $0x48,%rdi
  6fcfa2:	48 89 de             	mov    %rbx,%rsi
  6fcfa5:	e8 56 db 01 00       	call   71ab00 <<gpui::property::Overrides<gpui::property::GeometryStyle>>::retain::<<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#51}>>
  6fcfaa:	49 8b 86 00 01 00 00 	mov    0x100(%r14),%rax
  6fcfb1:	48 8b 48 58          	mov    0x58(%rax),%rcx
  6fcfb5:	48 0b 48 10          	or     0x10(%rax),%rcx
  6fcfb9:	75 2d                	jne    6fcfe8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5fe8>
  6fcfbb:	48 83 78 28 00       	cmpq   $0x0,0x28(%rax)
  6fcfc0:	75 26                	jne    6fcfe8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5fe8>
  6fcfc2:	48 83 78 30 ff       	cmpq   $0xffffffffffffffff,0x30(%rax)
  6fcfc7:	75 1f                	jne    6fcfe8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5fe8>
  6fcfc9:	49 8b 04 24          	mov    (%r12),%rax
  6fcfcd:	48 8b b8 00 01 00 00 	mov    0x100(%rax),%rdi
  6fcfd4:	e8 f7 53 fe ff       	call   6e23d0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::geometry::Geometry>>>>
  6fcfd9:	49 8b 04 24          	mov    (%r12),%rax
  6fcfdd:	48 c7 80 00 01 00 00 	movq   $0x0,0x100(%rax)
  6fcfe4:	00 00 00 00 
  6fcfe8:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  6fcfed:	c6 87 4a 07 00 00 01 	movb   $0x1,0x74a(%rdi)
  6fcff4:	e8 77 e4 fe ff       	call   6eb470 <<gpui::runtime::Runtime<route_columns_cost::Page>>::prune_focus>
  6fcff9:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fcffe:	4c 89 a8 38 07 00 00 	mov    %r13,0x738(%rax)
  6fd005:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6fd00a:	48 c7 00 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rax)
  6fd011:	ba 04 00 00 00       	mov    $0x4,%edx
  6fd016:	48 8b bc 24 30 02 00 	mov    0x230(%rsp),%rdi
  6fd01d:	00 
  6fd01e:	48 8b b4 24 a0 02 00 	mov    0x2a0(%rsp),%rsi
  6fd025:	00 
  6fd026:	ff 15 0c e7 38 00    	call   *0x38e70c(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd02c:	48 8b b4 24 a8 02 00 	mov    0x2a8(%rsp),%rsi
  6fd033:	00 
  6fd034:	48 85 f6             	test   %rsi,%rsi
  6fd037:	74 17                	je     6fd050 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6050>
  6fd039:	48 c1 e6 03          	shl    $0x3,%rsi
  6fd03d:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd042:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
  6fd049:	00 
  6fd04a:	ff 15 e8 e6 38 00    	call   *0x38e6e8(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd050:	45 31 ed             	xor    %r13d,%r13d
  6fd053:	48 8d bc 24 a8 08 00 	lea    0x8a8(%rsp),%rdi
  6fd05a:	00 
  6fd05b:	e8 70 f8 00 00       	call   70c8d0 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fd060:	48 8d bc 24 98 06 00 	lea    0x698(%rsp),%rdi
  6fd067:	00 
  6fd068:	e8 f3 f4 00 00       	call   70c560 <<alloc::collections::btree::map::BTreeMap<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize> as core::ops::drop::Drop>::drop>
  6fd06d:	48 8d bc 24 80 06 00 	lea    0x680(%rsp),%rdi
  6fd074:	00 
  6fd075:	e8 e6 f4 00 00       	call   70c560 <<alloc::collections::btree::map::BTreeMap<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize> as core::ops::drop::Drop>::drop>
  6fd07a:	48 8b 84 24 70 06 00 	mov    0x670(%rsp),%rax
  6fd081:	00 
  6fd082:	48 85 c0             	test   %rax,%rax
  6fd085:	74 18                	je     6fd09f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x609f>
  6fd087:	48 c1 e0 03          	shl    $0x3,%rax
  6fd08b:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6fd08f:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd094:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
  6fd099:	ff 15 99 e6 38 00    	call   *0x38e699(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd09f:	48 8b bc 24 10 05 00 	mov    0x510(%rsp),%rdi
  6fd0a6:	00 
  6fd0a7:	48 8b b4 24 00 04 00 	mov    0x400(%rsp),%rsi
  6fd0ae:	00 
  6fd0af:	e8 9c 75 fe ff       	call   6e4650 <core::ptr::drop_glue::<alloc::boxed::Box<[core::option::Option<gpui::element::Handler>]>>>
  6fd0b4:	48 8b b4 24 d8 07 00 	mov    0x7d8(%rsp),%rsi
  6fd0bb:	00 
  6fd0bc:	48 85 f6             	test   %rsi,%rsi
  6fd0bf:	74 17                	je     6fd0d8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x60d8>
  6fd0c1:	48 8b bc 24 e0 07 00 	mov    0x7e0(%rsp),%rdi
  6fd0c8:	00 
  6fd0c9:	48 c1 e6 02          	shl    $0x2,%rsi
  6fd0cd:	ba 04 00 00 00       	mov    $0x4,%edx
  6fd0d2:	ff 15 60 e6 38 00    	call   *0x38e660(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd0d8:	48 8d bc 24 b0 06 00 	lea    0x6b0(%rsp),%rdi
  6fd0df:	00 
  6fd0e0:	e8 bb 92 fe ff       	call   6e63a0 <core::ptr::drop_glue::<gpui::runtime::styles::Styles>>
  6fd0e5:	48 8d bc 24 48 04 00 	lea    0x448(%rsp),%rdi
  6fd0ec:	00 
  6fd0ed:	e8 7e e8 00 00       	call   70b970 <<alloc::collections::btree::map::BTreeMap<gpui::source::FieldId, gpui::shared_text::SharedText> as core::ops::drop::Drop>::drop>
  6fd0f2:	45 84 ff             	test   %r15b,%r15b
  6fd0f5:	74 24                	je     6fd11b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x611b>
  6fd0f7:	48 8b b4 24 78 02 00 	mov    0x278(%rsp),%rsi
  6fd0fe:	00 
  6fd0ff:	48 85 f6             	test   %rsi,%rsi
  6fd102:	74 17                	je     6fd11b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x611b>
  6fd104:	48 8b bc 24 80 02 00 	mov    0x280(%rsp),%rdi
  6fd10b:	00 
  6fd10c:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd110:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd115:	ff 15 1d e6 38 00    	call   *0x38e61d(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd11b:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd120:	48 8b bc 24 d0 02 00 	mov    0x2d0(%rsp),%rdi
  6fd127:	00 
  6fd128:	48 8b b4 24 18 04 00 	mov    0x418(%rsp),%rsi
  6fd12f:	00 
  6fd130:	ff 15 02 e6 38 00    	call   *0x38e602(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd136:	48 8b b4 24 60 02 00 	mov    0x260(%rsp),%rsi
  6fd13d:	00 
  6fd13e:	48 85 f6             	test   %rsi,%rsi
  6fd141:	74 17                	je     6fd15a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x615a>
  6fd143:	48 8b bc 24 68 02 00 	mov    0x268(%rsp),%rdi
  6fd14a:	00 
  6fd14b:	48 c1 e6 02          	shl    $0x2,%rsi
  6fd14f:	ba 04 00 00 00       	mov    $0x4,%edx
  6fd154:	ff 15 de e5 38 00    	call   *0x38e5de(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd15a:	48 8b b4 24 48 02 00 	mov    0x248(%rsp),%rsi
  6fd161:	00 
  6fd162:	48 85 f6             	test   %rsi,%rsi
  6fd165:	74 17                	je     6fd17e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x617e>
  6fd167:	48 8b bc 24 50 02 00 	mov    0x250(%rsp),%rdi
  6fd16e:	00 
  6fd16f:	48 c1 e6 03          	shl    $0x3,%rsi
  6fd173:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd178:	ff 15 ba e5 38 00    	call   *0x38e5ba(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd17e:	48 8b b4 24 d8 02 00 	mov    0x2d8(%rsp),%rsi
  6fd185:	00 
  6fd186:	48 85 f6             	test   %rsi,%rsi
  6fd189:	74 17                	je     6fd1a2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61a2>
  6fd18b:	48 8b bc 24 e0 02 00 	mov    0x2e0(%rsp),%rdi
  6fd192:	00 
  6fd193:	48 c1 e6 03          	shl    $0x3,%rsi
  6fd197:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd19c:	ff 15 96 e5 38 00    	call   *0x38e596(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd1a2:	45 31 e4             	xor    %r12d,%r12d
  6fd1a5:	48 8d bc 24 c0 07 00 	lea    0x7c0(%rsp),%rdi
  6fd1ac:	00 
  6fd1ad:	31 ed                	xor    %ebp,%ebp
  6fd1af:	e8 1c f7 00 00       	call   70c8d0 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fd1b4:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
  6fd1bb:	00 
  6fd1bc:	48 8d bc 24 78 08 00 	lea    0x878(%rsp),%rdi
  6fd1c3:	00 
  6fd1c4:	44 89 fb             	mov    %r15d,%ebx
  6fd1c7:	31 ed                	xor    %ebp,%ebp
  6fd1c9:	45 31 e4             	xor    %r12d,%r12d
  6fd1cc:	e8 7f d9 00 00       	call   70ab50 <<alloc::collections::btree::map::BTreeMap<gpui_reactivity_core::tree::NodeId, fn(cephal::tree::traits::MeasureInput) -> cephal::tree::traits::MeasureOutput> as core::ops::drop::Drop>::drop>
  6fd1d1:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
  6fd1d8:	00 
  6fd1d9:	48 8d bc 24 60 08 00 	lea    0x860(%rsp),%rdi
  6fd1e0:	00 
  6fd1e1:	31 ed                	xor    %ebp,%ebp
  6fd1e3:	45 31 e4             	xor    %r12d,%r12d
  6fd1e6:	44 8b 7c 24 38       	mov    0x38(%rsp),%r15d
  6fd1eb:	e8 e0 f6 00 00       	call   70c8d0 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fd1f0:	45 84 ff             	test   %r15b,%r15b
  6fd1f3:	0f 84 b3 04 00 00    	je     6fd6ac <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x66ac>
  6fd1f9:	48 8d bc 24 e0 04 00 	lea    0x4e0(%rsp),%rdi
  6fd200:	00 
  6fd201:	e8 0a 6e fe ff       	call   6e4010 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::semantic::AnnotationDraft>>>
  6fd206:	e9 a1 04 00 00       	jmp    6fd6ac <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x66ac>
  6fd20b:	4d 85 e4             	test   %r12,%r12
  6fd20e:	0f 84 21 05 00 00    	je     6fd735 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6735>
  6fd214:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
  6fd21b:	00 
  6fd21c:	49 83 bc 24 00 01 00 	cmpq   $0x0,0x100(%r12)
  6fd223:	00 00 
  6fd225:	0f 85 50 ee ff ff    	jne    6fc07b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x507b>
  6fd22b:	e9 d7 f8 ff ff       	jmp    6fcb07 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5b07>
  6fd230:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6fd235:	48 c7 00 1c 00 00 00 	movq   $0x1c,(%rax)
  6fd23c:	48 8b 8c 24 18 02 00 	mov    0x218(%rsp),%rcx
  6fd243:	00 
  6fd244:	48 89 48 08          	mov    %rcx,0x8(%rax)
  6fd248:	41 b4 01             	mov    $0x1,%r12b
  6fd24b:	48 8b 8c 24 60 01 00 	mov    0x160(%rsp),%rcx
  6fd252:	00 
  6fd253:	48 85 c9             	test   %rcx,%rcx
  6fd256:	74 4f                	je     6fd2a7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x62a7>
  6fd258:	48 8b 94 24 68 01 00 	mov    0x168(%rsp),%rdx
  6fd25f:	00 
  6fd260:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  6fd267:	00 
  6fd268:	48 c7 84 24 98 00 00 	movq   $0x0,0x98(%rsp)
  6fd26f:	00 00 00 00 00 
  6fd274:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
  6fd27b:	00 
  6fd27c:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
  6fd283:	00 
  6fd284:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  6fd28b:	00 00 00 00 00 
  6fd290:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
  6fd297:	00 
  6fd298:	48 89 94 24 c8 00 00 	mov    %rdx,0xc8(%rsp)
  6fd29f:	00 
  6fd2a0:	b9 01 00 00 00       	mov    $0x1,%ecx
  6fd2a5:	eb 04                	jmp    6fd2ab <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x62ab>
  6fd2a7:	31 c9                	xor    %ecx,%ecx
  6fd2a9:	31 c0                	xor    %eax,%eax
  6fd2ab:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  6fd2b2:	00 
  6fd2b3:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
  6fd2ba:	00 
  6fd2bb:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  6fd2c2:	00 
  6fd2c3:	48 8d bc 24 20 07 00 	lea    0x720(%rsp),%rdi
  6fd2ca:	00 
  6fd2cb:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6fd2d2:	00 
  6fd2d3:	44 89 64 24 18       	mov    %r12d,0x18(%rsp)
  6fd2d8:	e8 c3 cf 00 00       	call   70a2a0 <<alloc::collections::btree::map::IntoIter<gpui::source::FieldId, gpui::runtime::Fanout>>::dying_next>
  6fd2dd:	48 8b 84 24 20 07 00 	mov    0x720(%rsp),%rax
  6fd2e4:	00 
  6fd2e5:	48 85 c0             	test   %rax,%rax
  6fd2e8:	74 6c                	je     6fd356 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6356>
  6fd2ea:	48 8d 9c 24 20 07 00 	lea    0x720(%rsp),%rbx
  6fd2f1:	00 
  6fd2f2:	4c 8d b4 24 90 00 00 	lea    0x90(%rsp),%r14
  6fd2f9:	00 
  6fd2fa:	4c 8b 3d 37 e4 38 00 	mov    0x38e437(%rip),%r15        # a8b738 <_DYNAMIC+0x250>
  6fd301:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fd308:	0f 1f 84 00 00 00 00 
  6fd30f:	00 
  6fd310:	48 8b 8c 24 30 07 00 	mov    0x730(%rsp),%rcx
  6fd317:	00 
  6fd318:	48 c1 e1 05          	shl    $0x5,%rcx
  6fd31c:	48 8b 34 08          	mov    (%rax,%rcx,1),%rsi
  6fd320:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fd324:	74 18                	je     6fd33e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x633e>
  6fd326:	48 85 f6             	test   %rsi,%rsi
  6fd329:	74 13                	je     6fd33e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x633e>
  6fd32b:	48 01 c8             	add    %rcx,%rax
  6fd32e:	48 8b 78 08          	mov    0x8(%rax),%rdi
  6fd332:	48 c1 e6 02          	shl    $0x2,%rsi
  6fd336:	ba 04 00 00 00       	mov    $0x4,%edx
  6fd33b:	41 ff d7             	call   *%r15
  6fd33e:	48 89 df             	mov    %rbx,%rdi
  6fd341:	4c 89 f6             	mov    %r14,%rsi
  6fd344:	e8 57 cf 00 00       	call   70a2a0 <<alloc::collections::btree::map::IntoIter<gpui::source::FieldId, gpui::runtime::Fanout>>::dying_next>
  6fd349:	48 8b 84 24 20 07 00 	mov    0x720(%rsp),%rax
  6fd350:	00 
  6fd351:	48 85 c0             	test   %rax,%rax
  6fd354:	75 ba                	jne    6fd310 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6310>
  6fd356:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd35b:	48 8b bc 24 d0 02 00 	mov    0x2d0(%rsp),%rdi
  6fd362:	00 
  6fd363:	48 8b b4 24 18 04 00 	mov    0x418(%rsp),%rsi
  6fd36a:	00 
  6fd36b:	ff 15 c7 e3 38 00    	call   *0x38e3c7(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd371:	48 8b b4 24 60 02 00 	mov    0x260(%rsp),%rsi
  6fd378:	00 
  6fd379:	48 85 f6             	test   %rsi,%rsi
  6fd37c:	74 17                	je     6fd395 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6395>
  6fd37e:	48 8b bc 24 68 02 00 	mov    0x268(%rsp),%rdi
  6fd385:	00 
  6fd386:	48 c1 e6 02          	shl    $0x2,%rsi
  6fd38a:	ba 04 00 00 00       	mov    $0x4,%edx
  6fd38f:	ff 15 a3 e3 38 00    	call   *0x38e3a3(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd395:	48 8b b4 24 48 02 00 	mov    0x248(%rsp),%rsi
  6fd39c:	00 
  6fd39d:	48 85 f6             	test   %rsi,%rsi
  6fd3a0:	74 17                	je     6fd3b9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x63b9>
  6fd3a2:	48 8b bc 24 50 02 00 	mov    0x250(%rsp),%rdi
  6fd3a9:	00 
  6fd3aa:	48 c1 e6 03          	shl    $0x3,%rsi
  6fd3ae:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd3b3:	ff 15 7f e3 38 00    	call   *0x38e37f(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd3b9:	48 8b b4 24 d8 02 00 	mov    0x2d8(%rsp),%rsi
  6fd3c0:	00 
  6fd3c1:	48 85 f6             	test   %rsi,%rsi
  6fd3c4:	74 17                	je     6fd3dd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x63dd>
  6fd3c6:	48 8b bc 24 e0 02 00 	mov    0x2e0(%rsp),%rdi
  6fd3cd:	00 
  6fd3ce:	48 c1 e6 03          	shl    $0x3,%rsi
  6fd3d2:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd3d7:	ff 15 5b e3 38 00    	call   *0x38e35b(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd3dd:	41 b7 01             	mov    $0x1,%r15b
  6fd3e0:	48 8d bc 24 c0 07 00 	lea    0x7c0(%rsp),%rdi
  6fd3e7:	00 
  6fd3e8:	40 b5 01             	mov    $0x1,%bpl
  6fd3eb:	e8 e0 f4 00 00       	call   70c8d0 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fd3f0:	48 8b 84 24 c0 04 00 	mov    0x4c0(%rsp),%rax
  6fd3f7:	00 
  6fd3f8:	48 85 c0             	test   %rax,%rax
  6fd3fb:	74 41                	je     6fd43e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x643e>
  6fd3fd:	48 8b 9c 24 b8 04 00 	mov    0x4b8(%rsp),%rbx
  6fd404:	00 
  6fd405:	41 be 01 00 00 00    	mov    $0x1,%r14d
  6fd40b:	49 29 c6             	sub    %rax,%r14
  6fd40e:	4c 8b 3d 8b e3 38 00 	mov    0x38e38b(%rip),%r15        # a8b7a0 <_DYNAMIC+0x2b8>
  6fd415:	eb 16                	jmp    6fd42d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x642d>
  6fd417:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6fd41e:	00 00 
  6fd420:	48 83 c3 08          	add    $0x8,%rbx
  6fd424:	49 ff c6             	inc    %r14
  6fd427:	49 83 fe 01          	cmp    $0x1,%r14
  6fd42b:	74 11                	je     6fd43e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x643e>
  6fd42d:	48 8b 03             	mov    (%rbx),%rax
  6fd430:	f0 48 ff 08          	lock decq (%rax)
  6fd434:	75 ea                	jne    6fd420 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6420>
  6fd436:	48 89 df             	mov    %rbx,%rdi
  6fd439:	41 ff d7             	call   *%r15
  6fd43c:	eb e2                	jmp    6fd420 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6420>
  6fd43e:	48 8b b4 24 b0 04 00 	mov    0x4b0(%rsp),%rsi
  6fd445:	00 
  6fd446:	48 85 f6             	test   %rsi,%rsi
  6fd449:	74 17                	je     6fd462 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6462>
  6fd44b:	48 8b bc 24 b8 04 00 	mov    0x4b8(%rsp),%rdi
  6fd452:	00 
  6fd453:	48 c1 e6 03          	shl    $0x3,%rsi
  6fd457:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd45c:	ff 15 d6 e2 38 00    	call   *0x38e2d6(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd462:	31 ed                	xor    %ebp,%ebp
  6fd464:	b3 01                	mov    $0x1,%bl
  6fd466:	48 8d bc 24 78 08 00 	lea    0x878(%rsp),%rdi
  6fd46d:	00 
  6fd46e:	41 b4 01             	mov    $0x1,%r12b
  6fd471:	e8 da d6 00 00       	call   70ab50 <<alloc::collections::btree::map::BTreeMap<gpui_reactivity_core::tree::NodeId, fn(cephal::tree::traits::MeasureInput) -> cephal::tree::traits::MeasureOutput> as core::ops::drop::Drop>::drop>
  6fd476:	41 b7 01             	mov    $0x1,%r15b
  6fd479:	48 8d bc 24 60 08 00 	lea    0x860(%rsp),%rdi
  6fd480:	00 
  6fd481:	41 b4 01             	mov    $0x1,%r12b
  6fd484:	e8 47 f4 00 00       	call   70c8d0 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fd489:	48 8b 9c 24 f8 05 00 	mov    0x5f8(%rsp),%rbx
  6fd490:	00 
  6fd491:	4c 8b b4 24 00 06 00 	mov    0x600(%rsp),%r14
  6fd498:	00 
  6fd499:	4d 85 f6             	test   %r14,%r14
  6fd49c:	44 8b 6c 24 18       	mov    0x18(%rsp),%r13d
  6fd4a1:	74 5c                	je     6fd4ff <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x64ff>
  6fd4a3:	4c 8d bb 88 00 00 00 	lea    0x88(%rbx),%r15
  6fd4aa:	4c 8b 25 87 e2 38 00 	mov    0x38e287(%rip),%r12        # a8b738 <_DYNAMIC+0x250>
  6fd4b1:	eb 19                	jmp    6fd4cc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x64cc>
  6fd4b3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fd4ba:	84 00 00 00 00 00 
  6fd4c0:	49 81 c7 a8 00 00 00 	add    $0xa8,%r15
  6fd4c7:	49 ff ce             	dec    %r14
  6fd4ca:	74 33                	je     6fd4ff <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x64ff>
  6fd4cc:	49 8b 77 90          	mov    -0x70(%r15),%rsi
  6fd4d0:	48 85 f6             	test   %rsi,%rsi
  6fd4d3:	74 10                	je     6fd4e5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x64e5>
  6fd4d5:	49 8b 7f 98          	mov    -0x68(%r15),%rdi
  6fd4d9:	48 c1 e6 03          	shl    $0x3,%rsi
  6fd4dd:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd4e2:	41 ff d4             	call   *%r12
  6fd4e5:	49 8b 77 f8          	mov    -0x8(%r15),%rsi
  6fd4e9:	48 85 f6             	test   %rsi,%rsi
  6fd4ec:	74 d2                	je     6fd4c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x64c0>
  6fd4ee:	49 8b 3f             	mov    (%r15),%rdi
  6fd4f1:	48 c1 e6 05          	shl    $0x5,%rsi
  6fd4f5:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd4fa:	41 ff d4             	call   *%r12
  6fd4fd:	eb c1                	jmp    6fd4c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x64c0>
  6fd4ff:	48 8b 84 24 f0 05 00 	mov    0x5f0(%rsp),%rax
  6fd506:	00 
  6fd507:	48 85 c0             	test   %rax,%rax
  6fd50a:	74 15                	je     6fd521 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6521>
  6fd50c:	48 69 f0 a8 00 00 00 	imul   $0xa8,%rax,%rsi
  6fd513:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd518:	48 89 df             	mov    %rbx,%rdi
  6fd51b:	ff 15 17 e2 38 00    	call   *0x38e217(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd521:	48 8b b4 24 48 05 00 	mov    0x548(%rsp),%rsi
  6fd528:	00 
  6fd529:	48 85 f6             	test   %rsi,%rsi
  6fd52c:	48 8b 9c 24 28 04 00 	mov    0x428(%rsp),%rbx
  6fd533:	00 
  6fd534:	74 17                	je     6fd54d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x654d>
  6fd536:	48 8b bc 24 50 05 00 	mov    0x550(%rsp),%rdi
  6fd53d:	00 
  6fd53e:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd542:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd547:	ff 15 eb e1 38 00    	call   *0x38e1eb(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd54d:	48 8b 8c 24 20 02 00 	mov    0x220(%rsp),%rcx
  6fd554:	00 
  6fd555:	48 85 c9             	test   %rcx,%rcx
  6fd558:	0f 95 c0             	setne  %al
  6fd55b:	41 84 c5             	test   %al,%r13b
  6fd55e:	74 1b                	je     6fd57b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x657b>
  6fd560:	48 c1 e1 03          	shl    $0x3,%rcx
  6fd564:	48 8d 34 49          	lea    (%rcx,%rcx,2),%rsi
  6fd568:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd56d:	48 8b bc 24 38 02 00 	mov    0x238(%rsp),%rdi
  6fd574:	00 
  6fd575:	ff 15 bd e1 38 00    	call   *0x38e1bd(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd57b:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
  6fd582:	00 
  6fd583:	48 85 f6             	test   %rsi,%rsi
  6fd586:	74 17                	je     6fd59f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x659f>
  6fd588:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd58c:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd591:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  6fd598:	00 
  6fd599:	ff 15 99 e1 38 00    	call   *0x38e199(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd59f:	48 85 db             	test   %rbx,%rbx
  6fd5a2:	0f 95 c0             	setne  %al
  6fd5a5:	40 84 c5             	test   %al,%bpl
  6fd5a8:	74 1b                	je     6fd5c5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x65c5>
  6fd5aa:	48 c1 e3 03          	shl    $0x3,%rbx
  6fd5ae:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
  6fd5b2:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd5b7:	48 8b bc 24 28 05 00 	mov    0x528(%rsp),%rdi
  6fd5be:	00 
  6fd5bf:	ff 15 73 e1 38 00    	call   *0x38e173(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd5c5:	48 8b 9c 24 e8 04 00 	mov    0x4e8(%rsp),%rbx
  6fd5cc:	00 
  6fd5cd:	4c 8b b4 24 f0 04 00 	mov    0x4f0(%rsp),%r14
  6fd5d4:	00 
  6fd5d5:	4d 85 f6             	test   %r14,%r14
  6fd5d8:	74 5a                	je     6fd634 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6634>
  6fd5da:	4c 8d 7b 20          	lea    0x20(%rbx),%r15
  6fd5de:	4c 8b 25 53 e1 38 00 	mov    0x38e153(%rip),%r12        # a8b738 <_DYNAMIC+0x250>
  6fd5e5:	eb 12                	jmp    6fd5f9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x65f9>
  6fd5e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6fd5ee:	00 00 
  6fd5f0:	49 83 c7 38          	add    $0x38,%r15
  6fd5f4:	49 ff ce             	dec    %r14
  6fd5f7:	74 3b                	je     6fd634 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6634>
  6fd5f9:	49 8b 77 e0          	mov    -0x20(%r15),%rsi
  6fd5fd:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fd601:	74 13                	je     6fd616 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6616>
  6fd603:	48 85 f6             	test   %rsi,%rsi
  6fd606:	78 0e                	js     6fd616 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6616>
  6fd608:	74 0c                	je     6fd616 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6616>
  6fd60a:	49 8b 7f e8          	mov    -0x18(%r15),%rdi
  6fd60e:	ba 01 00 00 00       	mov    $0x1,%edx
  6fd613:	41 ff d4             	call   *%r12
  6fd616:	49 8b 77 f8          	mov    -0x8(%r15),%rsi
  6fd61a:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fd61e:	74 d0                	je     6fd5f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x65f0>
  6fd620:	48 85 f6             	test   %rsi,%rsi
  6fd623:	78 cb                	js     6fd5f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x65f0>
  6fd625:	74 c9                	je     6fd5f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x65f0>
  6fd627:	49 8b 3f             	mov    (%r15),%rdi
  6fd62a:	ba 01 00 00 00       	mov    $0x1,%edx
  6fd62f:	41 ff d4             	call   *%r12
  6fd632:	eb bc                	jmp    6fd5f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x65f0>
  6fd634:	48 8b 84 24 e0 04 00 	mov    0x4e0(%rsp),%rax
  6fd63b:	00 
  6fd63c:	48 85 c0             	test   %rax,%rax
  6fd63f:	74 12                	je     6fd653 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6653>
  6fd641:	48 6b f0 38          	imul   $0x38,%rax,%rsi
  6fd645:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd64a:	48 89 df             	mov    %rbx,%rdi
  6fd64d:	ff 15 e5 e0 38 00    	call   *0x38e0e5(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd653:	48 8b 9c 24 38 04 00 	mov    0x438(%rsp),%rbx
  6fd65a:	00 
  6fd65b:	4c 8b bc 24 40 04 00 	mov    0x440(%rsp),%r15
  6fd662:	00 
  6fd663:	49 ff c7             	inc    %r15
  6fd666:	48 89 df             	mov    %rbx,%rdi
  6fd669:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6fd670:	49 83 ff 01          	cmp    $0x1,%r15
  6fd674:	74 14                	je     6fd68a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x668a>
  6fd676:	4c 8d b7 98 00 00 00 	lea    0x98(%rdi),%r14
  6fd67d:	49 ff cf             	dec    %r15
  6fd680:	e8 4b 4d 00 00       	call   7023d0 <core::ptr::drop_glue::<gpui::element::DraftNode>>
  6fd685:	4c 89 f7             	mov    %r14,%rdi
  6fd688:	eb e6                	jmp    6fd670 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6670>
  6fd68a:	48 8b 84 24 30 04 00 	mov    0x430(%rsp),%rax
  6fd691:	00 
  6fd692:	48 85 c0             	test   %rax,%rax
  6fd695:	74 15                	je     6fd6ac <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x66ac>
  6fd697:	48 69 f0 98 00 00 00 	imul   $0x98,%rax,%rsi
  6fd69e:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd6a3:	48 89 df             	mov    %rbx,%rdi
  6fd6a6:	ff 15 8c e0 38 00    	call   *0x38e08c(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd6ac:	48 8d bc 24 90 08 00 	lea    0x890(%rsp),%rdi
  6fd6b3:	00 
  6fd6b4:	e8 b7 df 00 00       	call   70b670 <<alloc::collections::btree::map::BTreeMap<gpui::list::ListId, alloc::collections::btree::set_val::SetValZST> as core::ops::drop::Drop>::drop>
  6fd6b9:	48 81 c4 e8 08 00 00 	add    $0x8e8,%rsp
  6fd6c0:	5b                   	pop    %rbx
  6fd6c1:	41 5c                	pop    %r12
  6fd6c3:	41 5d                	pop    %r13
  6fd6c5:	41 5e                	pop    %r14
  6fd6c7:	41 5f                	pop    %r15
  6fd6c9:	5d                   	pop    %rbp
  6fd6ca:	c3                   	ret
  6fd6cb:	49 83 fc ff          	cmp    $0xffffffffffffffff,%r12
  6fd6cf:	74 16                	je     6fd6e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x66e7>
  6fd6d1:	4d 85 e4             	test   %r12,%r12
  6fd6d4:	7e 11                	jle    6fd6e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x66e7>
  6fd6d6:	ba 01 00 00 00       	mov    $0x1,%edx
  6fd6db:	48 89 df             	mov    %rbx,%rdi
  6fd6de:	4c 89 e6             	mov    %r12,%rsi
  6fd6e1:	ff 15 51 e0 38 00    	call   *0x38e051(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd6e7:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
  6fd6eb:	0f 84 1c e8 ff ff    	je     6fbf0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4f0d>
  6fd6f1:	4d 85 f6             	test   %r14,%r14
  6fd6f4:	0f 8e 13 e8 ff ff    	jle    6fbf0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4f0d>
  6fd6fa:	ba 01 00 00 00       	mov    $0x1,%edx
  6fd6ff:	4c 89 ff             	mov    %r15,%rdi
  6fd702:	4c 89 f6             	mov    %r14,%rsi
  6fd705:	ff 15 2d e0 38 00    	call   *0x38e02d(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd70b:	e9 fd e7 ff ff       	jmp    6fbf0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4f0d>
  6fd710:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  6fd717:	00 
  6fd718:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  6fd71d:	48 c7 02 20 00 00 00 	movq   $0x20,(%rdx)
  6fd724:	48 89 42 08          	mov    %rax,0x8(%rdx)
  6fd728:	48 89 5a 10          	mov    %rbx,0x10(%rdx)
  6fd72c:	48 89 4a 18          	mov    %rcx,0x18(%rdx)
  6fd730:	e9 13 fb ff ff       	jmp    6fd248 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6248>
  6fd735:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
  6fd73c:	00 
  6fd73d:	e9 c5 f3 ff ff       	jmp    6fcb07 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5b07>
  6fd742:	b3 01                	mov    $0x1,%bl
  6fd744:	48 8d 3d c6 d3 95 ff 	lea    -0x6a2c3a(%rip),%rdi        # 5ab11 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2e69>
  6fd74b:	48 8d 15 de 5a 36 00 	lea    0x365ade(%rip),%rdx        # a63230 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xda0>
  6fd752:	be 1b 00 00 00       	mov    $0x1b,%esi
  6fd757:	ff 15 e3 e0 38 00    	call   *0x38e0e3(%rip)        # a8b840 <_DYNAMIC+0x358>
  6fd75d:	e9 1b 06 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fd762:	48 8d 3d 67 5a 36 00 	lea    0x365a67(%rip),%rdi        # a631d0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xd40>
  6fd769:	ff 15 f1 df 38 00    	call   *0x38dff1(%rip)        # a8b760 <_DYNAMIC+0x278>
  6fd76f:	e9 09 06 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fd774:	48 8d 3d 55 65 36 00 	lea    0x366555(%rip),%rdi        # a63cd0 <anon.1a4a1640ff2d1bf549336a1593f98f2a.1.llvm.10670173712625079383>
  6fd77b:	ff 15 df df 38 00    	call   *0x38dfdf(%rip)        # a8b760 <_DYNAMIC+0x278>
  6fd781:	e9 f7 05 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fd786:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6fd78b:	48 c7 00 1f 00 00 00 	movq   $0x1f,(%rax)
  6fd792:	e9 a2 9b ff ff       	jmp    6f7339 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x339>
  6fd797:	48 83 bc 24 50 01 00 	cmpq   $0x0,0x150(%rsp)
  6fd79e:	00 00 
  6fd7a0:	74 1f                	je     6fd7c1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x67c1>
  6fd7a2:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
  6fd7a9:	00 
  6fd7aa:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd7ae:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd7b3:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  6fd7ba:	00 
  6fd7bb:	ff 15 77 df 38 00    	call   *0x38df77(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd7c1:	48 8b 33             	mov    (%rbx),%rsi
  6fd7c4:	48 85 f6             	test   %rsi,%rsi
  6fd7c7:	74 13                	je     6fd7dc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x67dc>
  6fd7c9:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
  6fd7cd:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd7d1:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd7d6:	ff 15 5c df 38 00    	call   *0x38df5c(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd7dc:	48 8d 7b 48          	lea    0x48(%rbx),%rdi
  6fd7e0:	e8 ab f5 00 00       	call   70cd90 <<alloc::collections::btree::map::BTreeMap<u64, gpui::property::Overlay<gpui::property::GeometryStyle>> as core::ops::drop::Drop>::drop>
  6fd7e5:	48 8b 73 18          	mov    0x18(%rbx),%rsi
  6fd7e9:	48 85 f6             	test   %rsi,%rsi
  6fd7ec:	74 13                	je     6fd801 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6801>
  6fd7ee:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
  6fd7f2:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd7f6:	ba 04 00 00 00       	mov    $0x4,%edx
  6fd7fb:	ff 15 37 df 38 00    	call   *0x38df37(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd801:	48 8b 73 30          	mov    0x30(%rbx),%rsi
  6fd805:	48 85 f6             	test   %rsi,%rsi
  6fd808:	7e 13                	jle    6fd81d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x681d>
  6fd80a:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
  6fd80e:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd812:	ba 04 00 00 00       	mov    $0x4,%edx
  6fd817:	ff 15 1b df 38 00    	call   *0x38df1b(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fd81d:	be 60 00 00 00       	mov    $0x60,%esi
  6fd822:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd827:	48 89 df             	mov    %rbx,%rdi
  6fd82a:	e9 f6 f2 ff ff       	jmp    6fcb25 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5b25>
  6fd82f:	48 8d 3d 52 51 36 00 	lea    0x365152(%rip),%rdi        # a62988 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x4f8>
  6fd836:	ff 15 24 df 38 00    	call   *0x38df24(%rip)        # a8b760 <_DYNAMIC+0x278>
  6fd83c:	e9 3c 05 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fd841:	be 2f 00 00 00       	mov    $0x2f,%esi
  6fd846:	48 8d 3d 2b a7 95 ff 	lea    -0x6a58d5(%rip),%rdi        # 57f78 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2d0>
  6fd84d:	48 8d 15 04 4e 36 00 	lea    0x364e04(%rip),%rdx        # a62658 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x1c8>
  6fd854:	eb 13                	jmp    6fd869 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6869>
  6fd856:	be 31 00 00 00       	mov    $0x31,%esi
  6fd85b:	48 8d 3d 0e a8 95 ff 	lea    -0x6a57f2(%rip),%rdi        # 58070 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x3c8>
  6fd862:	48 8d 15 ef 52 36 00 	lea    0x3652ef(%rip),%rdx        # a62b58 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x6c8>
  6fd869:	41 b5 01             	mov    $0x1,%r13b
  6fd86c:	45 31 e4             	xor    %r12d,%r12d
  6fd86f:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
  6fd874:	ff 15 fe de 38 00    	call   *0x38defe(%rip)        # a8b778 <_DYNAMIC+0x290>
  6fd87a:	e9 fe 04 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fd87f:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
  6fd886:	00 00 
  6fd888:	48 8d 3d 55 d2 95 ff 	lea    -0x6a2dab(%rip),%rdi        # 5aae4 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2e3c>
  6fd88f:	48 8d 15 f2 58 36 00 	lea    0x3658f2(%rip),%rdx        # a63188 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xcf8>
  6fd896:	be 16 00 00 00       	mov    $0x16,%esi
  6fd89b:	ff 15 9f df 38 00    	call   *0x38df9f(%rip)        # a8b840 <_DYNAMIC+0x358>
  6fd8a1:	e9 d7 04 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fd8a6:	48 8d 3d 6b 51 36 00 	lea    0x36516b(%rip),%rdi        # a62a18 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x588>
  6fd8ad:	ff 15 ad de 38 00    	call   *0x38dead(%rip)        # a8b760 <_DYNAMIC+0x278>
  6fd8b3:	e9 c5 04 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fd8b8:	48 8d 3d a7 d1 95 ff 	lea    -0x6a2e59(%rip),%rdi        # 5aa66 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2dbe>
  6fd8bf:	48 8d 15 2a 56 36 00 	lea    0x36562a(%rip),%rdx        # a62ef0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa60>
  6fd8c6:	be 83 00 00 00       	mov    $0x83,%esi
  6fd8cb:	ff 15 a7 de 38 00    	call   *0x38dea7(%rip)        # a8b778 <_DYNAMIC+0x290>
  6fd8d1:	e9 a7 04 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fd8d6:	45 31 e4             	xor    %r12d,%r12d
  6fd8d9:	48 8d 3d 5e d1 95 ff 	lea    -0x6a2ea2(%rip),%rdi        # 5aa3e <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2d96>
  6fd8e0:	48 8d 15 f1 55 36 00 	lea    0x3655f1(%rip),%rdx        # a62ed8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa48>
  6fd8e7:	be 51 00 00 00       	mov    $0x51,%esi
  6fd8ec:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
  6fd8f1:	ff 15 81 de 38 00    	call   *0x38de81(%rip)        # a8b778 <_DYNAMIC+0x290>
  6fd8f7:	e9 81 04 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fd8fc:	48 8d 3d 8d 4e 36 00 	lea    0x364e8d(%rip),%rdi        # a62790 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x300>
  6fd903:	ff 15 57 de 38 00    	call   *0x38de57(%rip)        # a8b760 <_DYNAMIC+0x278>
  6fd909:	e9 6f 04 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fd90e:	48 8d 3d eb 5d 36 00 	lea    0x365deb(%rip),%rdi        # a63700 <anon.92a5b798a24d77726913e1a598e97bdf.3.llvm.13561988957598541395>
  6fd915:	ff 15 45 de 38 00    	call   *0x38de45(%rip)        # a8b760 <_DYNAMIC+0x278>
  6fd91b:	e9 5d 04 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fd920:	48 8d 3d 3f d1 95 ff 	lea    -0x6a2ec1(%rip),%rdi        # 5aa66 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2dbe>
  6fd927:	48 8d 15 c2 55 36 00 	lea    0x3655c2(%rip),%rdx        # a62ef0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa60>
  6fd92e:	be 83 00 00 00       	mov    $0x83,%esi
  6fd933:	ff 15 3f de 38 00    	call   *0x38de3f(%rip)        # a8b778 <_DYNAMIC+0x290>
  6fd939:	e9 3f 04 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fd93e:	48 8d 3d 21 d1 95 ff 	lea    -0x6a2edf(%rip),%rdi        # 5aa66 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2dbe>
  6fd945:	48 8d 15 a4 55 36 00 	lea    0x3655a4(%rip),%rdx        # a62ef0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa60>
  6fd94c:	be 83 00 00 00       	mov    $0x83,%esi
  6fd951:	ff 15 21 de 38 00    	call   *0x38de21(%rip)        # a8b778 <_DYNAMIC+0x290>
  6fd957:	e9 21 04 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fd95c:	48 83 fe 15          	cmp    $0x15,%rsi
  6fd960:	0f 83 19 04 00 00    	jae    6fdd7f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7f>
  6fd966:	48 8d 8c 24 90 00 00 	lea    0x90(%rsp),%rcx
  6fd96d:	00 
  6fd96e:	ba 01 00 00 00       	mov    $0x1,%edx
  6fd973:	e8 d8 a3 00 00       	call   707d50 <core::slice::sort::shared::smallsort::insertion_sort_shift_left::<(u64, gpui::property::GeometryStyle), <[(u64, gpui::property::GeometryStyle)]>::sort_unstable_by_key<u64, <gpui::runtime::Runtime<route_columns_cost::Page>>::reconcile_geometry::{closure#2}>::{closure#0}>>
  6fd978:	4c 8b ac 24 08 02 00 	mov    0x208(%rsp),%r13
  6fd97f:	00 
  6fd980:	4c 8b 64 24 40       	mov    0x40(%rsp),%r12
  6fd985:	e9 ef f0 ff ff       	jmp    6fca79 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5a79>
  6fd98a:	bf 08 00 00 00       	mov    $0x8,%edi
  6fd98f:	4c 89 e6             	mov    %r12,%rsi
  6fd992:	ff 15 b8 dd 38 00    	call   *0x38ddb8(%rip)        # a8b750 <_DYNAMIC+0x268>
  6fd998:	e9 e0 03 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fd99d:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
  6fd9a4:	00 
  6fd9a5:	ff 15 55 de 38 00    	call   *0x38de55(%rip)        # a8b800 <_DYNAMIC+0x318>
  6fd9ab:	e9 cd 03 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fd9b0:	48 8b 84 24 c8 02 00 	mov    0x2c8(%rsp),%rax
  6fd9b7:	00 
  6fd9b8:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
  6fd9bf:	00 
  6fd9c0:	48 8d 15 79 57 36 00 	lea    0x365779(%rip),%rdx        # a63140 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xcb0>
  6fd9c7:	ff 15 83 de 38 00    	call   *0x38de83(%rip)        # a8b850 <_DYNAMIC+0x368>
  6fd9cd:	e9 ab 03 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fd9d2:	48 8d 3d 21 d1 95 ff 	lea    -0x6a2edf(%rip),%rdi        # 5aafa <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2e52>
  6fd9d9:	48 8d 15 08 58 36 00 	lea    0x365808(%rip),%rdx        # a631e8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xd58>
  6fd9e0:	be 17 00 00 00       	mov    $0x17,%esi
  6fd9e5:	ff 15 55 de 38 00    	call   *0x38de55(%rip)        # a8b840 <_DYNAMIC+0x358>
  6fd9eb:	e9 8d 03 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fd9f0:	48 8d 3d 21 5d 36 00 	lea    0x365d21(%rip),%rdi        # a63718 <anon.92a5b798a24d77726913e1a598e97bdf.4.llvm.13561988957598541395>
  6fd9f7:	ff 15 63 dd 38 00    	call   *0x38dd63(%rip)        # a8b760 <_DYNAMIC+0x278>
  6fd9fd:	e9 7b 03 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fda02:	48 8d 15 d7 56 36 00 	lea    0x3656d7(%rip),%rdx        # a630e0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xc50>
  6fda09:	be 02 00 00 00       	mov    $0x2,%esi
  6fda0e:	4c 89 ff             	mov    %r15,%rdi
  6fda11:	ff 15 39 de 38 00    	call   *0x38de39(%rip)        # a8b850 <_DYNAMIC+0x368>
  6fda17:	e9 61 03 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fda1c:	48 8d 15 4d 4f 36 00 	lea    0x364f4d(%rip),%rdx        # a62970 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x4e0>
  6fda23:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  6fda28:	ff 15 22 de 38 00    	call   *0x38de22(%rip)        # a8b850 <_DYNAMIC+0x368>
  6fda2e:	e9 4a 03 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fda33:	48 8d 15 d6 56 36 00 	lea    0x3656d6(%rip),%rdx        # a63110 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xc80>
  6fda3a:	ff 15 10 de 38 00    	call   *0x38de10(%rip)        # a8b850 <_DYNAMIC+0x368>
  6fda40:	e9 38 03 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fda45:	48 89 c5             	mov    %rax,%rbp
  6fda48:	4c 8b a4 24 b8 02 00 	mov    0x2b8(%rsp),%r12
  6fda4f:	00 
  6fda50:	48 8d 05 c1 57 36 00 	lea    0x3657c1(%rip),%rax        # a63218 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xd88>
  6fda57:	e9 af 00 00 00       	jmp    6fdb0b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b0b>
  6fda5c:	bf 08 00 00 00       	mov    $0x8,%edi
  6fda61:	48 8b b4 24 18 04 00 	mov    0x418(%rsp),%rsi
  6fda68:	00 
  6fda69:	ff 15 91 dd 38 00    	call   *0x38dd91(%rip)        # a8b800 <_DYNAMIC+0x318>
  6fda6f:	e9 09 03 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fda74:	48 8d 3d eb cf 95 ff 	lea    -0x6a3015(%rip),%rdi        # 5aa66 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2dbe>
  6fda7b:	48 8d 15 6e 54 36 00 	lea    0x36546e(%rip),%rdx        # a62ef0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa60>
  6fda82:	be 83 00 00 00       	mov    $0x83,%esi
  6fda87:	ff 15 eb dc 38 00    	call   *0x38dceb(%rip)        # a8b778 <_DYNAMIC+0x290>
  6fda8d:	e9 eb 02 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fda92:	48 85 ff             	test   %rdi,%rdi
  6fda95:	0f 85 a4 00 00 00    	jne    6fdb3f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b3f>
  6fda9b:	ff 15 9f de 38 00    	call   *0x38de9f(%rip)        # a8b940 <_DYNAMIC+0x458>
  6fdaa1:	e9 d7 02 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdaa6:	4c 89 ac 24 98 03 00 	mov    %r13,0x398(%rsp)
  6fdaad:	00 
  6fdaae:	48 8d 15 73 56 36 00 	lea    0x365673(%rip),%rdx        # a63128 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xc98>
  6fdab5:	48 8b bc 24 98 01 00 	mov    0x198(%rsp),%rdi
  6fdabc:	00 
  6fdabd:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
  6fdac4:	00 
  6fdac5:	ff 15 85 dd 38 00    	call   *0x38dd85(%rip)        # a8b850 <_DYNAMIC+0x368>
  6fdacb:	e9 ad 02 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdad0:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
  6fdad7:	00 00 
  6fdad9:	e9 a0 00 00 00       	jmp    6fdb7e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b7e>
  6fdade:	bf 08 00 00 00       	mov    $0x8,%edi
  6fdae3:	48 89 de             	mov    %rbx,%rsi
  6fdae6:	ff 15 14 dd 38 00    	call   *0x38dd14(%rip)        # a8b800 <_DYNAMIC+0x318>
  6fdaec:	e9 8c 02 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdaf1:	bf 08 00 00 00       	mov    $0x8,%edi
  6fdaf6:	48 89 de             	mov    %rbx,%rsi
  6fdaf9:	ff 15 01 dd 38 00    	call   *0x38dd01(%rip)        # a8b800 <_DYNAMIC+0x318>
  6fdaff:	e9 79 02 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdb04:	48 8d 05 4d 4e 36 00 	lea    0x364e4d(%rip),%rax        # a62958 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x4c8>
  6fdb0b:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6fdb10:	b3 01                	mov    $0x1,%bl
  6fdb12:	48 89 ef             	mov    %rbp,%rdi
  6fdb15:	4c 89 e6             	mov    %r12,%rsi
  6fdb18:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  6fdb1d:	ff 15 2d dd 38 00    	call   *0x38dd2d(%rip)        # a8b850 <_DYNAMIC+0x368>
  6fdb23:	e9 55 02 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdb28:	48 8d 15 d1 56 36 00 	lea    0x3656d1(%rip),%rdx        # a63200 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xd70>
  6fdb2f:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  6fdb34:	ff 15 16 dd 38 00    	call   *0x38dd16(%rip)        # a8b850 <_DYNAMIC+0x368>
  6fdb3a:	e9 3e 02 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdb3f:	48 8b b4 24 a8 01 00 	mov    0x1a8(%rsp),%rsi
  6fdb46:	00 
  6fdb47:	ff 15 03 dc 38 00    	call   *0x38dc03(%rip)        # a8b750 <_DYNAMIC+0x268>
  6fdb4d:	e9 2b 02 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdb52:	48 8d 15 d7 4e 36 00 	lea    0x364ed7(%rip),%rdx        # a62a30 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x5a0>
  6fdb59:	48 8b bc 24 98 01 00 	mov    0x198(%rsp),%rdi
  6fdb60:	00 
  6fdb61:	ff 15 e9 dc 38 00    	call   *0x38dce9(%rip)        # a8b850 <_DYNAMIC+0x368>
  6fdb67:	e9 11 02 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdb6c:	49 89 c6             	mov    %rax,%r14
  6fdb6f:	48 8d 05 4a 53 36 00 	lea    0x36534a(%rip),%rax        # a62ec0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa30>
  6fdb76:	48 89 84 24 68 06 00 	mov    %rax,0x668(%rsp)
  6fdb7d:	00 
  6fdb7e:	4c 89 f7             	mov    %r14,%rdi
  6fdb81:	48 8b 94 24 68 06 00 	mov    0x668(%rsp),%rdx
  6fdb88:	00 
  6fdb89:	ff 15 c1 dc 38 00    	call   *0x38dcc1(%rip)        # a8b850 <_DYNAMIC+0x368>
  6fdb8f:	e9 e9 01 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdb94:	49 89 cf             	mov    %rcx,%r15
  6fdb97:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
  6fdb9e:	00 
  6fdb9f:	48 8d 05 fa 4d 36 00 	lea    0x364dfa(%rip),%rax        # a629a0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x510>
  6fdba6:	e9 b6 00 00 00       	jmp    6fdc61 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c61>
  6fdbab:	48 8b 84 24 b8 02 00 	mov    0x2b8(%rsp),%rax
  6fdbb2:	00 
  6fdbb3:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
  6fdbba:	00 
  6fdbbb:	48 8d 05 ae 55 36 00 	lea    0x3655ae(%rip),%rax        # a63170 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xce0>
  6fdbc2:	e9 9a 00 00 00       	jmp    6fdc61 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c61>
  6fdbc7:	48 8d 15 52 4c 36 00 	lea    0x364c52(%rip),%rdx        # a62820 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x390>
  6fdbce:	ff 15 7c dc 38 00    	call   *0x38dc7c(%rip)        # a8b850 <_DYNAMIC+0x368>
  6fdbd4:	e9 a4 01 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdbd9:	48 8d 15 d8 55 36 00 	lea    0x3655d8(%rip),%rdx        # a631b8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xd28>
  6fdbe0:	4c 89 f7             	mov    %r14,%rdi
  6fdbe3:	ff 15 67 dc 38 00    	call   *0x38dc67(%rip)        # a8b850 <_DYNAMIC+0x368>
  6fdbe9:	e9 8f 01 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdbee:	48 8d 15 d3 54 36 00 	lea    0x3654d3(%rip),%rdx        # a630c8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xc38>
  6fdbf5:	ff 15 55 dc 38 00    	call   *0x38dc55(%rip)        # a8b850 <_DYNAMIC+0x368>
  6fdbfb:	e9 7d 01 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdc00:	41 b5 01             	mov    $0x1,%r13b
  6fdc03:	48 8d 15 3e 4e 36 00 	lea    0x364e3e(%rip),%rdx        # a62a48 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x5b8>
  6fdc0a:	41 b4 01             	mov    $0x1,%r12b
  6fdc0d:	4c 89 f7             	mov    %r14,%rdi
  6fdc10:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
  6fdc15:	ff 15 35 dc 38 00    	call   *0x38dc35(%rip)        # a8b850 <_DYNAMIC+0x368>
  6fdc1b:	e9 5d 01 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdc20:	48 8d 15 d1 54 36 00 	lea    0x3654d1(%rip),%rdx        # a630f8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xc68>
  6fdc27:	be 02 00 00 00       	mov    $0x2,%esi
  6fdc2c:	4c 89 ff             	mov    %r15,%rdi
  6fdc2f:	ff 15 1b dc 38 00    	call   *0x38dc1b(%rip)        # a8b850 <_DYNAMIC+0x368>
  6fdc35:	e9 43 01 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdc3a:	bf 08 00 00 00       	mov    $0x8,%edi
  6fdc3f:	48 89 de             	mov    %rbx,%rsi
  6fdc42:	ff 15 b8 db 38 00    	call   *0x38dbb8(%rip)        # a8b800 <_DYNAMIC+0x318>
  6fdc48:	e9 30 01 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdc4d:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  6fdc52:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
  6fdc59:	00 
  6fdc5a:	48 8d 05 6f 4d 36 00 	lea    0x364d6f(%rip),%rax        # a629d0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x540>
  6fdc61:	48 89 84 24 f0 03 00 	mov    %rax,0x3f0(%rsp)
  6fdc68:	00 
  6fdc69:	4c 89 ff             	mov    %r15,%rdi
  6fdc6c:	48 8b b4 24 f8 03 00 	mov    0x3f8(%rsp),%rsi
  6fdc73:	00 
  6fdc74:	48 8b 94 24 f0 03 00 	mov    0x3f0(%rsp),%rdx
  6fdc7b:	00 
  6fdc7c:	ff 15 ce db 38 00    	call   *0x38dbce(%rip)        # a8b850 <_DYNAMIC+0x368>
  6fdc82:	e9 f6 00 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdc87:	bf 08 00 00 00       	mov    $0x8,%edi
  6fdc8c:	48 89 de             	mov    %rbx,%rsi
  6fdc8f:	ff 15 6b db 38 00    	call   *0x38db6b(%rip)        # a8b800 <_DYNAMIC+0x318>
  6fdc95:	e9 e3 00 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdc9a:	bf 08 00 00 00       	mov    $0x8,%edi
  6fdc9f:	48 89 de             	mov    %rbx,%rsi
  6fdca2:	ff 15 58 db 38 00    	call   *0x38db58(%rip)        # a8b800 <_DYNAMIC+0x318>
  6fdca8:	e9 d0 00 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdcad:	48 85 ff             	test   %rdi,%rdi
  6fdcb0:	75 5b                	jne    6fdd0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d0d>
  6fdcb2:	41 b5 01             	mov    $0x1,%r13b
  6fdcb5:	41 b4 01             	mov    $0x1,%r12b
  6fdcb8:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
  6fdcbd:	ff 15 7d dc 38 00    	call   *0x38dc7d(%rip)        # a8b940 <_DYNAMIC+0x458>
  6fdcc3:	e9 b5 00 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdcc8:	bf 04 00 00 00       	mov    $0x4,%edi
  6fdccd:	48 89 de             	mov    %rbx,%rsi
  6fdcd0:	ff 15 2a db 38 00    	call   *0x38db2a(%rip)        # a8b800 <_DYNAMIC+0x318>
  6fdcd6:	e9 a2 00 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdcdb:	48 89 6c 24 58       	mov    %rbp,0x58(%rsp)
  6fdce0:	4c 89 f7             	mov    %r14,%rdi
  6fdce3:	48 8b 94 24 e8 03 00 	mov    0x3e8(%rsp),%rdx
  6fdcea:	00 
  6fdceb:	ff 15 5f db 38 00    	call   *0x38db5f(%rip)        # a8b850 <_DYNAMIC+0x368>
  6fdcf1:	e9 87 00 00 00       	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdcf6:	31 ed                	xor    %ebp,%ebp
  6fdcf8:	48 8d 15 b1 53 36 00 	lea    0x3653b1(%rip),%rdx        # a630b0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xc20>
  6fdcff:	48 89 c7             	mov    %rax,%rdi
  6fdd02:	4c 89 e6             	mov    %r12,%rsi
  6fdd05:	ff 15 45 db 38 00    	call   *0x38db45(%rip)        # a8b850 <_DYNAMIC+0x368>
  6fdd0b:	eb 70                	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdd0d:	48 8b b4 24 a8 01 00 	mov    0x1a8(%rsp),%rsi
  6fdd14:	00 
  6fdd15:	41 b5 01             	mov    $0x1,%r13b
  6fdd18:	41 b4 01             	mov    $0x1,%r12b
  6fdd1b:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
  6fdd20:	ff 15 2a da 38 00    	call   *0x38da2a(%rip)        # a8b750 <_DYNAMIC+0x268>
  6fdd26:	eb 55                	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdd28:	49 89 c7             	mov    %rax,%r15
  6fdd2b:	48 8b 84 24 00 04 00 	mov    0x400(%rsp),%rax
  6fdd32:	00 
  6fdd33:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6fdd38:	48 8d 05 a9 4c 36 00 	lea    0x364ca9(%rip),%rax        # a629e8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x558>
  6fdd3f:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
  6fdd46:	00 
  6fdd47:	4c 89 ff             	mov    %r15,%rdi
  6fdd4a:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  6fdd4f:	48 8b 94 24 60 06 00 	mov    0x660(%rsp),%rdx
  6fdd56:	00 
  6fdd57:	ff 15 f3 da 38 00    	call   *0x38daf3(%rip)        # a8b850 <_DYNAMIC+0x368>
  6fdd5d:	eb 1e                	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdd5f:	bf 08 00 00 00       	mov    $0x8,%edi
  6fdd64:	4c 89 e6             	mov    %r12,%rsi
  6fdd67:	ff 15 93 da 38 00    	call   *0x38da93(%rip)        # a8b800 <_DYNAMIC+0x318>
  6fdd6d:	eb 0e                	jmp    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d7d>
  6fdd6f:	bf 08 00 00 00       	mov    $0x8,%edi
  6fdd74:	4c 89 f6             	mov    %r14,%rsi
  6fdd77:	ff 15 83 da 38 00    	call   *0x38da83(%rip)        # a8b800 <_DYNAMIC+0x318>
  6fdd7d:	0f 0b                	ud2
  6fdd7f:	48 8d 94 24 90 00 00 	lea    0x90(%rsp),%rdx
  6fdd86:	00 
  6fdd87:	e8 e4 4a 01 00       	call   712870 <core::slice::sort::unstable::ipnsort::<(u64, gpui::property::GeometryStyle), <[(u64, gpui::property::GeometryStyle)]>::sort_unstable_by_key<u64, <gpui::runtime::Runtime<route_columns_cost::Page>>::reconcile_geometry::{closure#2}>::{closure#0}>>
  6fdd8c:	4c 8b ac 24 08 02 00 	mov    0x208(%rsp),%r13
  6fdd93:	00 
  6fdd94:	4c 8b 64 24 40       	mov    0x40(%rsp),%r12
  6fdd99:	e9 db ec ff ff       	jmp    6fca79 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5a79>
  6fdd9e:	48 89 6c 24 58       	mov    %rbp,0x58(%rsp)
  6fdda3:	4d 89 fe             	mov    %r15,%r14
  6fdda6:	48 8d 05 c3 4d 36 00 	lea    0x364dc3(%rip),%rax        # a62b70 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x6e0>
  6fddad:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
  6fddb4:	00 
  6fddb5:	e9 26 ff ff ff       	jmp    6fdce0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6ce0>
  6fddba:	48 89 6c 24 58       	mov    %rbp,0x58(%rsp)
  6fddbf:	4d 89 fe             	mov    %r15,%r14
  6fddc2:	48 8d 05 bf 4d 36 00 	lea    0x364dbf(%rip),%rax        # a62b88 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x6f8>
  6fddc9:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
  6fddd0:	00 
  6fddd1:	e9 0a ff ff ff       	jmp    6fdce0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6ce0>
  6fddd6:	48 89 6c 24 58       	mov    %rbp,0x58(%rsp)
  6fdddb:	49 89 c6             	mov    %rax,%r14
  6fddde:	48 8d 05 bb 4d 36 00 	lea    0x364dbb(%rip),%rax        # a62ba0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x710>
  6fdde5:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
  6fddec:	00 
  6fdded:	e9 ee fe ff ff       	jmp    6fdce0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6ce0>
  6fddf2:	e9 46 08 00 00       	jmp    6fe63d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x763d>
  6fddf7:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fddfc:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
  6fde03:	00 
  6fde04:	e8 07 48 fe ff       	call   6e2610 <core::ptr::drop_glue::<core::option::Option<gpui::runtime::Shaped>>>
  6fde09:	e9 52 05 00 00       	jmp    6fe360 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7360>
  6fde0e:	ff 15 5c d9 38 00    	call   *0x38d95c(%rip)        # a8b770 <_DYNAMIC+0x288>
  6fde14:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fde19:	4e 89 a4 fc 00 05 00 	mov    %r12,0x500(%rsp,%r15,8)
  6fde20:	00 
  6fde21:	e9 5c 07 00 00       	jmp    6fe582 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7582>
  6fde26:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fde2b:	48 8b 73 18          	mov    0x18(%rbx),%rsi
  6fde2f:	48 85 f6             	test   %rsi,%rsi
  6fde32:	74 18                	je     6fde4c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6e4c>
  6fde34:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fde39:	48 8b 78 20          	mov    0x20(%rax),%rdi
  6fde3d:	48 c1 e6 04          	shl    $0x4,%rsi
  6fde41:	ba 04 00 00 00       	mov    $0x4,%edx
  6fde46:	ff 15 ec d8 38 00    	call   *0x38d8ec(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fde4c:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fde51:	48 8b 70 30          	mov    0x30(%rax),%rsi
  6fde55:	48 85 f6             	test   %rsi,%rsi
  6fde58:	7e 18                	jle    6fde72 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6e72>
  6fde5a:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fde5f:	48 8b 78 38          	mov    0x38(%rax),%rdi
  6fde63:	48 c1 e6 04          	shl    $0x4,%rsi
  6fde67:	ba 04 00 00 00       	mov    $0x4,%edx
  6fde6c:	ff 15 c6 d8 38 00    	call   *0x38d8c6(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fde72:	be 60 00 00 00       	mov    $0x60,%esi
  6fde77:	ba 08 00 00 00       	mov    $0x8,%edx
  6fde7c:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  6fde81:	ff 15 b1 d8 38 00    	call   *0x38d8b1(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fde87:	40 b5 01             	mov    $0x1,%bpl
  6fde8a:	e9 cd 0b 00 00       	jmp    6fea5c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a5c>
  6fde8f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fde94:	49 8b 04 24          	mov    (%r12),%rax
  6fde98:	48 c7 80 00 01 00 00 	movq   $0x0,0x100(%rax)
  6fde9f:	00 00 00 00 
  6fdea3:	e9 48 06 00 00       	jmp    6fe4f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x74f0>
  6fdea8:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdead:	48 8b 73 08          	mov    0x8(%rbx),%rsi
  6fdeb1:	b3 01                	mov    $0x1,%bl
  6fdeb3:	48 85 f6             	test   %rsi,%rsi
  6fdeb6:	74 15                	je     6fdecd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6ecd>
  6fdeb8:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  6fdebf:	00 
  6fdec0:	48 8b 50 10          	mov    0x10(%rax),%rdx
  6fdec4:	48 89 ef             	mov    %rbp,%rdi
  6fdec7:	ff 15 6b d8 38 00    	call   *0x38d86b(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fdecd:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
  6fded4:	00 00 
  6fded6:	e9 71 0c 00 00       	jmp    6feb4c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b4c>
  6fdedb:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdee0:	41 b4 01             	mov    $0x1,%r12b
  6fdee3:	b0 01                	mov    $0x1,%al
  6fdee5:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fdee9:	b0 01                	mov    $0x1,%al
  6fdeeb:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fdeef:	41 b6 01             	mov    $0x1,%r14b
  6fdef2:	40 b5 01             	mov    $0x1,%bpl
  6fdef5:	41 b7 01             	mov    $0x1,%r15b
  6fdef8:	b0 01                	mov    $0x1,%al
  6fdefa:	89 44 24 38          	mov    %eax,0x38(%rsp)
  6fdefe:	e9 04 0d 00 00       	jmp    6fec07 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c07>
  6fdf03:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdf08:	b3 01                	mov    $0x1,%bl
  6fdf0a:	e9 8d 07 00 00       	jmp    6fe69c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x769c>
  6fdf0f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdf14:	48 8b bc 24 28 02 00 	mov    0x228(%rsp),%rdi
  6fdf1b:	00 
  6fdf1c:	e8 2f 71 fe ff       	call   6e5050 <core::ptr::drop_glue::<gpui::shared_text::SharedText>>
  6fdf21:	e9 94 04 00 00       	jmp    6fe3ba <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x73ba>
  6fdf26:	ff 15 44 d8 38 00    	call   *0x38d844(%rip)        # a8b770 <_DYNAMIC+0x288>
  6fdf2c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdf31:	48 8b 03             	mov    (%rbx),%rax
  6fdf34:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  6fdf3b:	00 
  6fdf3c:	48 89 88 d0 00 00 00 	mov    %rcx,0xd0(%rax)
  6fdf43:	66 0f 6f 84 24 90 00 	movdqa 0x90(%rsp),%xmm0
  6fdf4a:	00 00 
  6fdf4c:	f3 0f 7f 80 c0 00 00 	movdqu %xmm0,0xc0(%rax)
  6fdf53:	00 
  6fdf54:	e9 bc 06 00 00       	jmp    6fe615 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7615>
  6fdf59:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdf5e:	49 89 9c 24 00 01 00 	mov    %rbx,0x100(%r12)
  6fdf65:	00 
  6fdf66:	31 db                	xor    %ebx,%ebx
  6fdf68:	e9 d7 06 00 00       	jmp    6fe644 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7644>
  6fdf6d:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdf72:	4c 89 f7             	mov    %r14,%rdi
  6fdf75:	48 89 de             	mov    %rbx,%rsi
  6fdf78:	e8 b3 86 fe ff       	call   6e6630 <core::ptr::drop_glue::<gpui::runtime::metadata::Names>>
  6fdf7d:	e9 79 06 00 00       	jmp    6fe5fb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x75fb>
  6fdf82:	ff 15 e8 d7 38 00    	call   *0x38d7e8(%rip)        # a8b770 <_DYNAMIC+0x288>
  6fdf88:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdf8d:	45 31 ed             	xor    %r13d,%r13d
  6fdf90:	31 db                	xor    %ebx,%ebx
  6fdf92:	31 ed                	xor    %ebp,%ebp
  6fdf94:	45 31 f6             	xor    %r14d,%r14d
  6fdf97:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fdf9e:	00 
  6fdf9f:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fdfa6:	00 
  6fdfa7:	45 31 e4             	xor    %r12d,%r12d
  6fdfaa:	e9 00 0e 00 00       	jmp    6fedaf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7daf>
  6fdfaf:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdfb4:	45 31 ed             	xor    %r13d,%r13d
  6fdfb7:	31 db                	xor    %ebx,%ebx
  6fdfb9:	31 ed                	xor    %ebp,%ebp
  6fdfbb:	45 31 f6             	xor    %r14d,%r14d
  6fdfbe:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fdfc5:	00 
  6fdfc6:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fdfcd:	00 
  6fdfce:	45 31 e4             	xor    %r12d,%r12d
  6fdfd1:	e9 9b 0d 00 00       	jmp    6fed71 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d71>
  6fdfd6:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdfdb:	45 31 ed             	xor    %r13d,%r13d
  6fdfde:	31 db                	xor    %ebx,%ebx
  6fdfe0:	31 ed                	xor    %ebp,%ebp
  6fdfe2:	45 31 f6             	xor    %r14d,%r14d
  6fdfe5:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fdfec:	00 
  6fdfed:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fdff4:	00 
  6fdff5:	45 31 e4             	xor    %r12d,%r12d
  6fdff8:	e9 3a 0d 00 00       	jmp    6fed37 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d37>
  6fdffd:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe002:	45 31 ed             	xor    %r13d,%r13d
  6fe005:	31 db                	xor    %ebx,%ebx
  6fe007:	31 ed                	xor    %ebp,%ebp
  6fe009:	45 31 f6             	xor    %r14d,%r14d
  6fe00c:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fe013:	00 
  6fe014:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fe01b:	00 
  6fe01c:	45 31 e4             	xor    %r12d,%r12d
  6fe01f:	e9 06 0d 00 00       	jmp    6fed2a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d2a>
  6fe024:	e9 a8 04 00 00       	jmp    6fe4d1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x74d1>
  6fe029:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe02e:	48 8b 03             	mov    (%rbx),%rax
  6fe031:	48 85 c0             	test   %rax,%rax
  6fe034:	74 1f                	je     6fe055 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7055>
  6fe036:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6fe03b:	48 8b b9 b0 02 00 00 	mov    0x2b0(%rcx),%rdi
  6fe042:	48 c1 e0 04          	shl    $0x4,%rax
  6fe046:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
  6fe04a:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe04f:	ff 15 e3 d6 38 00    	call   *0x38d6e3(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe055:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  6fe05c:	00 
  6fe05d:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fe061:	66 0f 6f 84 24 90 00 	movdqa 0x90(%rsp),%xmm0
  6fe068:	00 00 
  6fe06a:	f3 0f 7f 03          	movdqu %xmm0,(%rbx)
  6fe06e:	b3 01                	mov    $0x1,%bl
  6fe070:	e9 7d 04 00 00       	jmp    6fe4f2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x74f2>
  6fe075:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe07a:	4d 89 b4 24 b0 05 00 	mov    %r14,0x5b0(%r12)
  6fe081:	00 
  6fe082:	49 89 9c 24 b8 05 00 	mov    %rbx,0x5b8(%r12)
  6fe089:	00 
  6fe08a:	31 db                	xor    %ebx,%ebx
  6fe08c:	eb 20                	jmp    6fe0ae <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x70ae>
  6fe08e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe093:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  6fe09a:	00 
  6fe09b:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fe09f:	66 0f 6f 84 24 90 00 	movdqa 0x90(%rsp),%xmm0
  6fe0a6:	00 00 
  6fe0a8:	f3 0f 7f 03          	movdqu %xmm0,(%rbx)
  6fe0ac:	b3 01                	mov    $0x1,%bl
  6fe0ae:	31 ed                	xor    %ebp,%ebp
  6fe0b0:	45 31 f6             	xor    %r14d,%r14d
  6fe0b3:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fe0ba:	00 
  6fe0bb:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fe0c2:	00 
  6fe0c3:	e9 09 0b 00 00       	jmp    6febd1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7bd1>
  6fe0c8:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe0cd:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  6fe0d4:	00 
  6fe0d5:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fe0d9:	66 0f 28 84 24 90 00 	movapd 0x90(%rsp),%xmm0
  6fe0e0:	00 00 
  6fe0e2:	66 0f 11 03          	movupd %xmm0,(%rbx)
  6fe0e6:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fe0ed:	00 
  6fe0ee:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fe0f5:	00 
  6fe0f6:	31 ed                	xor    %ebp,%ebp
  6fe0f8:	e9 6f 09 00 00       	jmp    6fea6c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a6c>
  6fe0fd:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe102:	e9 01 05 00 00       	jmp    6fe608 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7608>
  6fe107:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe10c:	41 b4 01             	mov    $0x1,%r12b
  6fe10f:	b0 01                	mov    $0x1,%al
  6fe111:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe115:	b0 01                	mov    $0x1,%al
  6fe117:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe11b:	41 b6 01             	mov    $0x1,%r14b
  6fe11e:	40 b5 01             	mov    $0x1,%bpl
  6fe121:	41 b7 01             	mov    $0x1,%r15b
  6fe124:	b3 01                	mov    $0x1,%bl
  6fe126:	b0 01                	mov    $0x1,%al
  6fe128:	89 44 24 38          	mov    %eax,0x38(%rsp)
  6fe12c:	e9 c1 0a 00 00       	jmp    6febf2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7bf2>
  6fe131:	e9 c3 09 00 00       	jmp    6feaf9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7af9>
  6fe136:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe13b:	41 b4 01             	mov    $0x1,%r12b
  6fe13e:	b0 01                	mov    $0x1,%al
  6fe140:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe144:	b0 01                	mov    $0x1,%al
  6fe146:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe14a:	41 b6 01             	mov    $0x1,%r14b
  6fe14d:	40 b5 01             	mov    $0x1,%bpl
  6fe150:	b0 01                	mov    $0x1,%al
  6fe152:	89 44 24 38          	mov    %eax,0x38(%rsp)
  6fe156:	e9 7f 0b 00 00       	jmp    6fecda <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7cda>
  6fe15b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe160:	41 b4 01             	mov    $0x1,%r12b
  6fe163:	e9 81 06 00 00       	jmp    6fe7e9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x77e9>
  6fe168:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe16d:	ba 04 00 00 00       	mov    $0x4,%edx
  6fe172:	48 8b bc 24 30 02 00 	mov    0x230(%rsp),%rdi
  6fe179:	00 
  6fe17a:	48 8b b4 24 a0 02 00 	mov    0x2a0(%rsp),%rsi
  6fe181:	00 
  6fe182:	ff 15 b0 d5 38 00    	call   *0x38d5b0(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe188:	45 31 e4             	xor    %r12d,%r12d
  6fe18b:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fe192:	00 
  6fe193:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fe19a:	00 
  6fe19b:	45 31 f6             	xor    %r14d,%r14d
  6fe19e:	31 ed                	xor    %ebp,%ebp
  6fe1a0:	31 db                	xor    %ebx,%ebx
  6fe1a2:	e9 4b 0a 00 00       	jmp    6febf2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7bf2>
  6fe1a7:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe1ac:	b0 01                	mov    $0x1,%al
  6fe1ae:	89 44 24 38          	mov    %eax,0x38(%rsp)
  6fe1b2:	b3 01                	mov    $0x1,%bl
  6fe1b4:	40 b5 01             	mov    $0x1,%bpl
  6fe1b7:	41 b6 01             	mov    $0x1,%r14b
  6fe1ba:	b0 01                	mov    $0x1,%al
  6fe1bc:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe1c0:	b0 01                	mov    $0x1,%al
  6fe1c2:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe1c6:	41 b4 01             	mov    $0x1,%r12b
  6fe1c9:	e9 1b 0b 00 00       	jmp    6fece9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ce9>
  6fe1ce:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe1d3:	b0 01                	mov    $0x1,%al
  6fe1d5:	89 44 24 38          	mov    %eax,0x38(%rsp)
  6fe1d9:	41 b5 01             	mov    $0x1,%r13b
  6fe1dc:	b3 01                	mov    $0x1,%bl
  6fe1de:	40 b5 01             	mov    $0x1,%bpl
  6fe1e1:	41 b6 01             	mov    $0x1,%r14b
  6fe1e4:	b0 01                	mov    $0x1,%al
  6fe1e6:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe1ea:	b0 01                	mov    $0x1,%al
  6fe1ec:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe1f0:	41 b4 01             	mov    $0x1,%r12b
  6fe1f3:	e9 9d 0b 00 00       	jmp    6fed95 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d95>
  6fe1f8:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe1fd:	4c 89 e7             	mov    %r12,%rdi
  6fe200:	e8 7b 43 fe ff       	call   6e2580 <core::ptr::drop_glue::<core::option::Option<gpui::shared_text::SharedText>>>
  6fe205:	e9 78 03 00 00       	jmp    6fe582 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7582>
  6fe20a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe20f:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  6fe216:	00 
  6fe217:	e8 64 45 fe ff       	call   6e2780 <core::ptr::drop_glue::<core::option::Option<gpui::runtime::TextSite>>>
  6fe21c:	e9 7b 01 00 00       	jmp    6fe39c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x739c>
  6fe221:	ff 15 49 d5 38 00    	call   *0x38d549(%rip)        # a8b770 <_DYNAMIC+0x288>
  6fe227:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe22c:	4c 89 ff             	mov    %r15,%rdi
  6fe22f:	4c 89 ee             	mov    %r13,%rsi
  6fe232:	e8 79 43 fe ff       	call   6e25b0 <core::ptr::drop_glue::<core::option::Option<gpui::element::Handler>>>
  6fe237:	41 b5 01             	mov    $0x1,%r13b
  6fe23a:	e9 60 01 00 00       	jmp    6fe39f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x739f>
  6fe23f:	ff 15 2b d5 38 00    	call   *0x38d52b(%rip)        # a8b770 <_DYNAMIC+0x288>
  6fe245:	44 89 7c 24 38       	mov    %r15d,0x38(%rsp)
  6fe24a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe24f:	44 89 eb             	mov    %r13d,%ebx
  6fe252:	44 89 ed             	mov    %r13d,%ebp
  6fe255:	45 89 ee             	mov    %r13d,%r14d
  6fe258:	44 89 e8             	mov    %r13d,%eax
  6fe25b:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe25f:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe263:	45 89 ec             	mov    %r13d,%r12d
  6fe266:	e9 b2 0a 00 00       	jmp    6fed1d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d1d>
  6fe26b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe270:	4c 89 e7             	mov    %r12,%rdi
  6fe273:	e8 d8 6d fe ff       	call   6e5050 <core::ptr::drop_glue::<gpui::shared_text::SharedText>>
  6fe278:	e9 05 03 00 00       	jmp    6fe582 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7582>
  6fe27d:	eb 00                	jmp    6fe27f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x727f>
  6fe27f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe284:	49 83 fc ff          	cmp    $0xffffffffffffffff,%r12
  6fe288:	74 16                	je     6fe2a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x72a0>
  6fe28a:	4d 85 e4             	test   %r12,%r12
  6fe28d:	7e 11                	jle    6fe2a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x72a0>
  6fe28f:	ba 01 00 00 00       	mov    $0x1,%edx
  6fe294:	48 89 df             	mov    %rbx,%rdi
  6fe297:	4c 89 e6             	mov    %r12,%rsi
  6fe29a:	ff 15 98 d4 38 00    	call   *0x38d498(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe2a0:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
  6fe2a4:	0f 84 51 03 00 00    	je     6fe5fb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x75fb>
  6fe2aa:	4d 85 f6             	test   %r14,%r14
  6fe2ad:	0f 8e 48 03 00 00    	jle    6fe5fb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x75fb>
  6fe2b3:	ba 01 00 00 00       	mov    $0x1,%edx
  6fe2b8:	4c 89 ff             	mov    %r15,%rdi
  6fe2bb:	4c 89 f6             	mov    %r14,%rsi
  6fe2be:	ff 15 74 d4 38 00    	call   *0x38d474(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe2c4:	e9 32 03 00 00       	jmp    6fe5fb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x75fb>
  6fe2c9:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe2ce:	b0 01                	mov    $0x1,%al
  6fe2d0:	89 44 24 38          	mov    %eax,0x38(%rsp)
  6fe2d4:	41 b6 01             	mov    $0x1,%r14b
  6fe2d7:	b0 01                	mov    $0x1,%al
  6fe2d9:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe2dd:	b0 01                	mov    $0x1,%al
  6fe2df:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe2e3:	e9 e9 08 00 00       	jmp    6febd1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7bd1>
  6fe2e8:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe2ed:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  6fe2f4:	00 
  6fe2f5:	48 8b 70 08          	mov    0x8(%rax),%rsi
  6fe2f9:	48 85 f6             	test   %rsi,%rsi
  6fe2fc:	74 17                	je     6fe315 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7315>
  6fe2fe:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  6fe305:	00 
  6fe306:	48 8b 50 10          	mov    0x10(%rax),%rdx
  6fe30a:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  6fe30f:	ff 15 23 d4 38 00    	call   *0x38d423(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe315:	41 b5 01             	mov    $0x1,%r13b
  6fe318:	45 31 e4             	xor    %r12d,%r12d
  6fe31b:	b3 01                	mov    $0x1,%bl
  6fe31d:	e9 5f 04 00 00       	jmp    6fe781 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7781>
  6fe322:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe327:	ba 04 00 00 00       	mov    $0x4,%edx
  6fe32c:	48 8b bc 24 30 02 00 	mov    0x230(%rsp),%rdi
  6fe333:	00 
  6fe334:	48 8b b4 24 a0 02 00 	mov    0x2a0(%rsp),%rsi
  6fe33b:	00 
  6fe33c:	ff 15 f6 d3 38 00    	call   *0x38d3f6(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe342:	31 db                	xor    %ebx,%ebx
  6fe344:	e9 c4 01 00 00       	jmp    6fe50d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x750d>
  6fe349:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe34e:	48 89 9c 24 98 03 00 	mov    %rbx,0x398(%rsp)
  6fe355:	00 
  6fe356:	e9 e0 05 00 00       	jmp    6fe93b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x793b>
  6fe35b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe360:	4c 89 bc 24 60 04 00 	mov    %r15,0x460(%rsp)
  6fe367:	00 
  6fe368:	48 8b 84 24 28 02 00 	mov    0x228(%rsp),%rax
  6fe36f:	00 
  6fe370:	48 89 84 24 a0 04 00 	mov    %rax,0x4a0(%rsp)
  6fe377:	00 
  6fe378:	48 8b 84 24 78 06 00 	mov    0x678(%rsp),%rax
  6fe37f:	00 
  6fe380:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
  6fe387:	00 
  6fe388:	eb 30                	jmp    6fe3ba <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x73ba>
  6fe38a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe38f:	48 8d bc 24 90 03 00 	lea    0x390(%rsp),%rdi
  6fe396:	00 
  6fe397:	e8 64 6e fe ff       	call   6e5200 <core::ptr::drop_glue::<gpui::runtime::TextSite>>
  6fe39c:	45 31 ed             	xor    %r13d,%r13d
  6fe39f:	45 31 e4             	xor    %r12d,%r12d
  6fe3a2:	31 db                	xor    %ebx,%ebx
  6fe3a4:	e9 d8 03 00 00       	jmp    6fe781 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7781>
  6fe3a9:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe3ae:	48 c7 84 24 60 04 00 	movq   $0xffffffffffffffff,0x460(%rsp)
  6fe3b5:	00 ff ff ff ff 
  6fe3ba:	41 b5 01             	mov    $0x1,%r13b
  6fe3bd:	41 b4 01             	mov    $0x1,%r12b
  6fe3c0:	b3 01                	mov    $0x1,%bl
  6fe3c2:	e9 ba 03 00 00       	jmp    6fe781 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7781>
  6fe3c7:	e9 1e 07 00 00       	jmp    6feaea <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7aea>
  6fe3cc:	e9 de 03 00 00       	jmp    6fe7af <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x77af>
  6fe3d1:	e9 54 01 00 00       	jmp    6fe52a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x752a>
  6fe3d6:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe3db:	41 b7 01             	mov    $0x1,%r15b
  6fe3de:	b0 01                	mov    $0x1,%al
  6fe3e0:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fe3e4:	40 b5 01             	mov    $0x1,%bpl
  6fe3e7:	41 b6 01             	mov    $0x1,%r14b
  6fe3ea:	b0 01                	mov    $0x1,%al
  6fe3ec:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe3f0:	b0 01                	mov    $0x1,%al
  6fe3f2:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe3f6:	41 b4 01             	mov    $0x1,%r12b
  6fe3f9:	e9 4e 0a 00 00       	jmp    6fee4c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e4c>
  6fe3fe:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe403:	41 b7 01             	mov    $0x1,%r15b
  6fe406:	b0 01                	mov    $0x1,%al
  6fe408:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fe40c:	40 b5 01             	mov    $0x1,%bpl
  6fe40f:	41 b6 01             	mov    $0x1,%r14b
  6fe412:	b0 01                	mov    $0x1,%al
  6fe414:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe418:	b0 01                	mov    $0x1,%al
  6fe41a:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe41e:	41 b4 01             	mov    $0x1,%r12b
  6fe421:	e9 4a 0a 00 00       	jmp    6fee70 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e70>
  6fe426:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe42b:	41 b7 01             	mov    $0x1,%r15b
  6fe42e:	b0 01                	mov    $0x1,%al
  6fe430:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fe434:	40 b5 01             	mov    $0x1,%bpl
  6fe437:	41 b6 01             	mov    $0x1,%r14b
  6fe43a:	b0 01                	mov    $0x1,%al
  6fe43c:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe440:	b0 01                	mov    $0x1,%al
  6fe442:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe446:	41 b4 01             	mov    $0x1,%r12b
  6fe449:	e9 46 0a 00 00       	jmp    6fee94 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e94>
  6fe44e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe453:	e9 52 07 00 00       	jmp    6febaa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7baa>
  6fe458:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe45d:	e9 d9 04 00 00       	jmp    6fe93b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x793b>
  6fe462:	48 89 6c 24 58       	mov    %rbp,0x58(%rsp)
  6fe467:	e9 8d 06 00 00       	jmp    6feaf9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7af9>
  6fe46c:	e9 0c 01 00 00       	jmp    6fe57d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x757d>
  6fe471:	e9 07 01 00 00       	jmp    6fe57d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x757d>
  6fe476:	e9 6f 05 00 00       	jmp    6fe9ea <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x79ea>
  6fe47b:	44 89 64 24 18       	mov    %r12d,0x18(%rsp)
  6fe480:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe485:	41 89 ee             	mov    %ebp,%r14d
  6fe488:	89 e8                	mov    %ebp,%eax
  6fe48a:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe48e:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe492:	41 89 ec             	mov    %ebp,%r12d
  6fe495:	e9 07 0a 00 00       	jmp    6feea1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ea1>
  6fe49a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe49f:	41 b7 01             	mov    $0x1,%r15b
  6fe4a2:	b0 01                	mov    $0x1,%al
  6fe4a4:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fe4a8:	40 b5 01             	mov    $0x1,%bpl
  6fe4ab:	41 b6 01             	mov    $0x1,%r14b
  6fe4ae:	b0 01                	mov    $0x1,%al
  6fe4b0:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe4b4:	b0 01                	mov    $0x1,%al
  6fe4b6:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe4ba:	41 b4 01             	mov    $0x1,%r12b
  6fe4bd:	e9 66 09 00 00       	jmp    6fee28 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e28>
  6fe4c2:	e9 97 00 00 00       	jmp    6fe55e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x755e>
  6fe4c7:	e9 92 00 00 00       	jmp    6fe55e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x755e>
  6fe4cc:	e9 ba 02 00 00       	jmp    6fe78b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x778b>
  6fe4d1:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe4d6:	48 8b 84 24 b0 01 00 	mov    0x1b0(%rsp),%rax
  6fe4dd:	00 
  6fe4de:	49 89 47 10          	mov    %rax,0x10(%r15)
  6fe4e2:	66 0f 6f 84 24 a0 01 	movdqa 0x1a0(%rsp),%xmm0
  6fe4e9:	00 00 
  6fe4eb:	f3 41 0f 7f 07       	movdqu %xmm0,(%r15)
  6fe4f0:	31 db                	xor    %ebx,%ebx
  6fe4f2:	ba 04 00 00 00       	mov    $0x4,%edx
  6fe4f7:	48 8b bc 24 30 02 00 	mov    0x230(%rsp),%rdi
  6fe4fe:	00 
  6fe4ff:	48 8b b4 24 a0 02 00 	mov    0x2a0(%rsp),%rsi
  6fe506:	00 
  6fe507:	ff 15 2b d2 38 00    	call   *0x38d22b(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe50d:	31 ed                	xor    %ebp,%ebp
  6fe50f:	45 31 f6             	xor    %r14d,%r14d
  6fe512:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fe519:	00 
  6fe51a:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fe521:	00 
  6fe522:	45 31 e4             	xor    %r12d,%r12d
  6fe525:	e9 bf 07 00 00       	jmp    6fece9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ce9>
  6fe52a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe52f:	48 83 7c 24 18 00    	cmpq   $0x0,0x18(%rsp)
  6fe535:	0f 84 d6 04 00 00    	je     6fea11 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a11>
  6fe53b:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  6fe540:	48 c1 e6 04          	shl    $0x4,%rsi
  6fe544:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe549:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6fe54e:	ff 15 e4 d1 38 00    	call   *0x38d1e4(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe554:	e9 b8 04 00 00       	jmp    6fea11 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a11>
  6fe559:	e9 8c 05 00 00       	jmp    6feaea <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7aea>
  6fe55e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe563:	b3 01                	mov    $0x1,%bl
  6fe565:	e9 f4 05 00 00       	jmp    6feb5e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b5e>
  6fe56a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe56f:	41 b7 01             	mov    $0x1,%r15b
  6fe572:	b0 01                	mov    $0x1,%al
  6fe574:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fe578:	e9 16 03 00 00       	jmp    6fe893 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7893>
  6fe57d:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe582:	48 8b b4 24 60 04 00 	mov    0x460(%rsp),%rsi
  6fe589:	00 
  6fe58a:	48 85 f6             	test   %rsi,%rsi
  6fe58d:	7e 1a                	jle    6fe5a9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x75a9>
  6fe58f:	48 8b bc 24 68 04 00 	mov    0x468(%rsp),%rdi
  6fe596:	00 
  6fe597:	ba 01 00 00 00       	mov    $0x1,%edx
  6fe59c:	ff 15 96 d1 38 00    	call   *0x38d196(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe5a2:	eb 05                	jmp    6fe5a9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x75a9>
  6fe5a4:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe5a9:	4d 85 f6             	test   %r14,%r14
  6fe5ac:	7e 16                	jle    6fe5c4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x75c4>
  6fe5ae:	48 8b bc 24 e8 06 00 	mov    0x6e8(%rsp),%rdi
  6fe5b5:	00 
  6fe5b6:	ba 01 00 00 00       	mov    $0x1,%edx
  6fe5bb:	4c 89 f6             	mov    %r14,%rsi
  6fe5be:	ff 15 74 d1 38 00    	call   *0x38d174(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe5c4:	48 8b b4 24 f0 02 00 	mov    0x2f0(%rsp),%rsi
  6fe5cb:	00 
  6fe5cc:	48 8b 94 24 f8 02 00 	mov    0x2f8(%rsp),%rdx
  6fe5d3:	00 
  6fe5d4:	48 8d bc 24 00 03 00 	lea    0x300(%rsp),%rdi
  6fe5db:	00 
  6fe5dc:	e8 3f 0c 02 00       	call   71f220 <<[core::mem::maybe_uninit::MaybeUninit<core::option::Option<gpui::source::Text>>; 2] as core::array::iter::iter_inner::PartialDrop>::partial_drop>
  6fe5e1:	48 8b bc 24 08 05 00 	mov    0x508(%rsp),%rdi
  6fe5e8:	00 
  6fe5e9:	e8 92 3f fe ff       	call   6e2580 <core::ptr::drop_glue::<core::option::Option<gpui::shared_text::SharedText>>>
  6fe5ee:	48 8b bc 24 00 05 00 	mov    0x500(%rsp),%rdi
  6fe5f5:	00 
  6fe5f6:	e8 85 3f fe ff       	call   6e2580 <core::ptr::drop_glue::<core::option::Option<gpui::shared_text::SharedText>>>
  6fe5fb:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6fe602:	00 
  6fe603:	e8 58 65 fe ff       	call   6e4b60 <core::ptr::drop_glue::<core::iter::adapters::zip::Zip<alloc::vec::into_iter::IntoIter<gpui::semantic::AnnotationDraft>, alloc::vec::into_iter::IntoIter<[core::option::Option<gpui::source::FieldId>; 2]>>>>
  6fe608:	48 8d bc 24 c8 04 00 	lea    0x4c8(%rsp),%rdi
  6fe60f:	00 
  6fe610:	e8 1b 5d fe ff       	call   6e4330 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::metadata::Declared>>>
  6fe615:	b0 01                	mov    $0x1,%al
  6fe617:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe61b:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fe622:	00 
  6fe623:	40 b5 01             	mov    $0x1,%bpl
  6fe626:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
  6fe62d:	00 
  6fe62e:	e9 39 04 00 00       	jmp    6fea6c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a6c>
  6fe633:	e9 cd 01 00 00       	jmp    6fe805 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7805>
  6fe638:	e9 c8 01 00 00       	jmp    6fe805 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7805>
  6fe63d:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe642:	b3 01                	mov    $0x1,%bl
  6fe644:	48 83 bc 24 50 01 00 	cmpq   $0x0,0x150(%rsp)
  6fe64b:	00 00 
  6fe64d:	74 1f                	je     6fe66e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x766e>
  6fe64f:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
  6fe656:	00 
  6fe657:	48 c1 e6 04          	shl    $0x4,%rsi
  6fe65b:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe660:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  6fe667:	00 
  6fe668:	ff 15 ca d0 38 00    	call   *0x38d0ca(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe66e:	84 db                	test   %bl,%bl
  6fe670:	0f 84 c2 00 00 00    	je     6fe738 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7738>
  6fe676:	48 8b b4 24 f0 02 00 	mov    0x2f0(%rsp),%rsi
  6fe67d:	00 
  6fe67e:	48 85 f6             	test   %rsi,%rsi
  6fe681:	74 17                	je     6fe69a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x769a>
  6fe683:	48 8b bc 24 f8 02 00 	mov    0x2f8(%rsp),%rdi
  6fe68a:	00 
  6fe68b:	48 c1 e6 04          	shl    $0x4,%rsi
  6fe68f:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe694:	ff 15 9e d0 38 00    	call   *0x38d09e(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe69a:	31 db                	xor    %ebx,%ebx
  6fe69c:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fe6a1:	48 8b 30             	mov    (%rax),%rsi
  6fe6a4:	48 85 f6             	test   %rsi,%rsi
  6fe6a7:	74 18                	je     6fe6c1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x76c1>
  6fe6a9:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fe6ae:	48 8b 78 08          	mov    0x8(%rax),%rdi
  6fe6b2:	48 c1 e6 04          	shl    $0x4,%rsi
  6fe6b6:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe6bb:	ff 15 77 d0 38 00    	call   *0x38d077(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe6c1:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fe6c6:	48 8d 78 48          	lea    0x48(%rax),%rdi
  6fe6ca:	e8 c1 e6 00 00       	call   70cd90 <<alloc::collections::btree::map::BTreeMap<u64, gpui::property::Overlay<gpui::property::GeometryStyle>> as core::ops::drop::Drop>::drop>
  6fe6cf:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fe6d4:	48 8b 70 18          	mov    0x18(%rax),%rsi
  6fe6d8:	48 85 f6             	test   %rsi,%rsi
  6fe6db:	74 18                	je     6fe6f5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x76f5>
  6fe6dd:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fe6e2:	48 8b 78 20          	mov    0x20(%rax),%rdi
  6fe6e6:	48 c1 e6 04          	shl    $0x4,%rsi
  6fe6ea:	ba 04 00 00 00       	mov    $0x4,%edx
  6fe6ef:	ff 15 43 d0 38 00    	call   *0x38d043(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe6f5:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fe6fa:	48 8b 70 30          	mov    0x30(%rax),%rsi
  6fe6fe:	48 85 f6             	test   %rsi,%rsi
  6fe701:	7e 18                	jle    6fe71b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x771b>
  6fe703:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fe708:	48 8b 78 38          	mov    0x38(%rax),%rdi
  6fe70c:	48 c1 e6 04          	shl    $0x4,%rsi
  6fe710:	ba 04 00 00 00       	mov    $0x4,%edx
  6fe715:	ff 15 1d d0 38 00    	call   *0x38d01d(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe71b:	be 60 00 00 00       	mov    $0x60,%esi
  6fe720:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe725:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  6fe72a:	ff 15 08 d0 38 00    	call   *0x38d008(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe730:	84 db                	test   %bl,%bl
  6fe732:	0f 85 f7 02 00 00    	jne    6fea2f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a2f>
  6fe738:	40 b5 01             	mov    $0x1,%bpl
  6fe73b:	e9 1c 03 00 00       	jmp    6fea5c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a5c>
  6fe740:	ff 15 2a d0 38 00    	call   *0x38d02a(%rip)        # a8b770 <_DYNAMIC+0x288>
  6fe746:	e9 ed 04 00 00       	jmp    6fec38 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c38>
  6fe74b:	e9 75 02 00 00       	jmp    6fe9c5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x79c5>
  6fe750:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe755:	41 b4 01             	mov    $0x1,%r12b
  6fe758:	b0 01                	mov    $0x1,%al
  6fe75a:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe75e:	40 b5 01             	mov    $0x1,%bpl
  6fe761:	41 b6 01             	mov    $0x1,%r14b
  6fe764:	41 b7 01             	mov    $0x1,%r15b
  6fe767:	48 8b 9c 24 28 04 00 	mov    0x428(%rsp),%rbx
  6fe76e:	00 
  6fe76f:	e9 81 07 00 00       	jmp    6feef5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ef5>
  6fe774:	e9 4c 02 00 00       	jmp    6fe9c5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x79c5>
  6fe779:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe77e:	44 89 e3             	mov    %r12d,%ebx
  6fe781:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
  6fe786:	e9 7f 03 00 00       	jmp    6feb0a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b0a>
  6fe78b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe790:	41 b4 01             	mov    $0x1,%r12b
  6fe793:	b0 01                	mov    $0x1,%al
  6fe795:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe799:	b0 01                	mov    $0x1,%al
  6fe79b:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe79f:	41 b6 01             	mov    $0x1,%r14b
  6fe7a2:	40 b5 01             	mov    $0x1,%bpl
  6fe7a5:	b3 01                	mov    $0x1,%bl
  6fe7a7:	41 b5 01             	mov    $0x1,%r13b
  6fe7aa:	e9 07 06 00 00       	jmp    6fedb6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7db6>
  6fe7af:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe7b4:	41 b4 01             	mov    $0x1,%r12b
  6fe7b7:	48 83 bc 24 20 02 00 	cmpq   $0x0,0x220(%rsp)
  6fe7be:	00 00 
  6fe7c0:	74 27                	je     6fe7e9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x77e9>
  6fe7c2:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
  6fe7c9:	00 
  6fe7ca:	48 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%rax
  6fe7d1:	00 
  6fe7d2:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6fe7d6:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe7db:	48 8b bc 24 38 02 00 	mov    0x238(%rsp),%rdi
  6fe7e2:	00 
  6fe7e3:	ff 15 4f cf 38 00    	call   *0x38cf4f(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe7e9:	b0 01                	mov    $0x1,%al
  6fe7eb:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe7ef:	b0 01                	mov    $0x1,%al
  6fe7f1:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe7f5:	41 b6 01             	mov    $0x1,%r14b
  6fe7f8:	40 b5 01             	mov    $0x1,%bpl
  6fe7fb:	b3 01                	mov    $0x1,%bl
  6fe7fd:	41 b7 01             	mov    $0x1,%r15b
  6fe800:	e9 e2 05 00 00       	jmp    6fede7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7de7>
  6fe805:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe80a:	b0 01                	mov    $0x1,%al
  6fe80c:	89 44 24 38          	mov    %eax,0x38(%rsp)
  6fe810:	41 b5 01             	mov    $0x1,%r13b
  6fe813:	b3 01                	mov    $0x1,%bl
  6fe815:	40 b5 01             	mov    $0x1,%bpl
  6fe818:	41 b6 01             	mov    $0x1,%r14b
  6fe81b:	b0 01                	mov    $0x1,%al
  6fe81d:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe821:	b0 01                	mov    $0x1,%al
  6fe823:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe827:	41 b4 01             	mov    $0x1,%r12b
  6fe82a:	e9 73 05 00 00       	jmp    6feda2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7da2>
  6fe82f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe834:	41 89 df             	mov    %ebx,%r15d
  6fe837:	44 89 e0             	mov    %r12d,%eax
  6fe83a:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe83e:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe842:	45 89 e6             	mov    %r12d,%r14d
  6fe845:	e9 78 06 00 00       	jmp    6feec2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ec2>
  6fe84a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe84f:	44 89 e0             	mov    %r12d,%eax
  6fe852:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe856:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe85a:	45 89 e6             	mov    %r12d,%r14d
  6fe85d:	e9 6d 06 00 00       	jmp    6feecf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ecf>
  6fe862:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe867:	4d 85 f6             	test   %r14,%r14
  6fe86a:	75 3e                	jne    6fe8aa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x78aa>
  6fe86c:	48 8b b4 24 b0 04 00 	mov    0x4b0(%rsp),%rsi
  6fe873:	00 
  6fe874:	41 b7 01             	mov    $0x1,%r15b
  6fe877:	48 85 f6             	test   %rsi,%rsi
  6fe87a:	74 17                	je     6fe893 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7893>
  6fe87c:	48 8b bc 24 b8 04 00 	mov    0x4b8(%rsp),%rdi
  6fe883:	00 
  6fe884:	48 c1 e6 03          	shl    $0x3,%rsi
  6fe888:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe88d:	ff 15 a5 ce 38 00    	call   *0x38cea5(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe893:	41 b6 01             	mov    $0x1,%r14b
  6fe896:	b0 01                	mov    $0x1,%al
  6fe898:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe89c:	b0 01                	mov    $0x1,%al
  6fe89e:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe8a2:	41 b4 01             	mov    $0x1,%r12b
  6fe8a5:	e9 09 06 00 00       	jmp    6feeb3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7eb3>
  6fe8aa:	48 83 c3 08          	add    $0x8,%rbx
  6fe8ae:	49 f7 de             	neg    %r14
  6fe8b1:	eb 16                	jmp    6fe8c9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x78c9>
  6fe8b3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fe8ba:	84 00 00 00 00 00 
  6fe8c0:	48 83 c3 08          	add    $0x8,%rbx
  6fe8c4:	49 ff ce             	dec    %r14
  6fe8c7:	74 a3                	je     6fe86c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x786c>
  6fe8c9:	48 8b 03             	mov    (%rbx),%rax
  6fe8cc:	f0 48 ff 08          	lock decq (%rax)
  6fe8d0:	75 ee                	jne    6fe8c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x78c0>
  6fe8d2:	48 89 df             	mov    %rbx,%rdi
  6fe8d5:	41 ff d7             	call   *%r15
  6fe8d8:	eb e6                	jmp    6fe8c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x78c0>
  6fe8da:	ff 15 90 ce 38 00    	call   *0x38ce90(%rip)        # a8b770 <_DYNAMIC+0x288>
  6fe8e0:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe8e5:	e9 d8 06 00 00       	jmp    6fefc2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7fc2>
  6fe8ea:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe8ef:	eb 15                	jmp    6fe906 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7906>
  6fe8f1:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe8f6:	48 8b 84 24 c8 02 00 	mov    0x2c8(%rsp),%rax
  6fe8fd:	00 
  6fe8fe:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
  6fe905:	00 
  6fe906:	48 83 bc 24 78 01 00 	cmpq   $0x0,0x178(%rsp)
  6fe90d:	00 00 
  6fe90f:	75 0e                	jne    6fe91f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x791f>
  6fe911:	48 c7 84 24 78 01 00 	movq   $0x0,0x178(%rsp)
  6fe918:	00 00 00 00 00 
  6fe91d:	eb 1c                	jmp    6fe93b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x793b>
  6fe91f:	48 8b b4 24 78 01 00 	mov    0x178(%rsp),%rsi
  6fe926:	00 
  6fe927:	48 c1 e6 05          	shl    $0x5,%rsi
  6fe92b:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe930:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  6fe935:	ff 15 fd cd 38 00    	call   *0x38cdfd(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe93b:	48 83 7c 24 58 00    	cmpq   $0x0,0x58(%rsp)
  6fe941:	74 1c                	je     6fe95f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x795f>
  6fe943:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  6fe948:	48 c1 e6 03          	shl    $0x3,%rsi
  6fe94c:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe951:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
  6fe958:	00 
  6fe959:	ff 15 d9 cd 38 00    	call   *0x38cdd9(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe95f:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  6fe966:	00 
  6fe967:	48 39 84 24 98 01 00 	cmp    %rax,0x198(%rsp)
  6fe96e:	00 
  6fe96f:	0f 92 c0             	setb   %al
  6fe972:	48 83 bc 24 78 01 00 	cmpq   $0x0,0x178(%rsp)
  6fe979:	00 00 
  6fe97b:	0f 94 c1             	sete   %cl
  6fe97e:	08 c1                	or     %al,%cl
  6fe980:	75 1c                	jne    6fe99e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x799e>
  6fe982:	48 8b b4 24 78 01 00 	mov    0x178(%rsp),%rsi
  6fe989:	00 
  6fe98a:	48 c1 e6 05          	shl    $0x5,%rsi
  6fe98e:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe993:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  6fe998:	ff 15 9a cd 38 00    	call   *0x38cd9a(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fe99e:	b0 01                	mov    $0x1,%al
  6fe9a0:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe9a4:	48 8d bc 24 90 03 00 	lea    0x390(%rsp),%rdi
  6fe9ab:	00 
  6fe9ac:	e8 cf 08 02 00       	call   71f280 <<alloc::vec::into_iter::IntoIter<gpui::list::ListDraft> as core::ops::drop::Drop>::drop>
  6fe9b1:	b0 01                	mov    $0x1,%al
  6fe9b3:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe9b7:	40 b5 01             	mov    $0x1,%bpl
  6fe9ba:	b0 01                	mov    $0x1,%al
  6fe9bc:	89 44 24 38          	mov    %eax,0x38(%rsp)
  6fe9c0:	e9 a7 00 00 00       	jmp    6fea6c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a6c>
  6fe9c5:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe9ca:	41 b4 01             	mov    $0x1,%r12b
  6fe9cd:	b0 01                	mov    $0x1,%al
  6fe9cf:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe9d3:	b0 01                	mov    $0x1,%al
  6fe9d5:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe9d9:	41 b6 01             	mov    $0x1,%r14b
  6fe9dc:	40 b5 01             	mov    $0x1,%bpl
  6fe9df:	b0 01                	mov    $0x1,%al
  6fe9e1:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fe9e5:	e9 96 02 00 00       	jmp    6fec80 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c80>
  6fe9ea:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe9ef:	41 b4 01             	mov    $0x1,%r12b
  6fe9f2:	b0 01                	mov    $0x1,%al
  6fe9f4:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe9f8:	b0 01                	mov    $0x1,%al
  6fe9fa:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe9fe:	41 b6 01             	mov    $0x1,%r14b
  6fea01:	40 b5 01             	mov    $0x1,%bpl
  6fea04:	41 b7 01             	mov    $0x1,%r15b
  6fea07:	e9 01 04 00 00       	jmp    6fee0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e0d>
  6fea0c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fea11:	b0 01                	mov    $0x1,%al
  6fea13:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fea17:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fea1e:	00 
  6fea1f:	40 b5 01             	mov    $0x1,%bpl
  6fea22:	b0 01                	mov    $0x1,%al
  6fea24:	89 44 24 38          	mov    %eax,0x38(%rsp)
  6fea28:	eb 42                	jmp    6fea6c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a6c>
  6fea2a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fea2f:	40 b5 01             	mov    $0x1,%bpl
  6fea32:	48 83 bc 24 50 01 00 	cmpq   $0x0,0x150(%rsp)
  6fea39:	00 00 
  6fea3b:	74 1f                	je     6fea5c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a5c>
  6fea3d:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
  6fea44:	00 
  6fea45:	48 c1 e6 04          	shl    $0x4,%rsi
  6fea49:	ba 08 00 00 00       	mov    $0x8,%edx
  6fea4e:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  6fea55:	00 
  6fea56:	ff 15 dc cc 38 00    	call   *0x38ccdc(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fea5c:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fea63:	00 
  6fea64:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fea6b:	00 
  6fea6c:	48 8d bc 24 08 07 00 	lea    0x708(%rsp),%rdi
  6fea73:	00 
  6fea74:	e8 e7 da 00 00       	call   70c560 <<alloc::collections::btree::map::BTreeMap<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize> as core::ops::drop::Drop>::drop>
  6fea79:	b3 01                	mov    $0x1,%bl
  6fea7b:	40 84 ed             	test   %bpl,%bpl
  6fea7e:	74 0d                	je     6fea8d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a8d>
  6fea80:	48 8d bc 24 30 05 00 	lea    0x530(%rsp),%rdi
  6fea87:	00 
  6fea88:	e8 63 d7 00 00       	call   70c1f0 <<alloc::collections::btree::map::BTreeMap<gpui::runtime::scroll::ViewportKey, gpui::runtime::scroll::ViewportState> as core::ops::drop::Drop>::drop>
  6fea8d:	31 ed                	xor    %ebp,%ebp
  6fea8f:	45 31 f6             	xor    %r14d,%r14d
  6fea92:	e9 3a 01 00 00       	jmp    6febd1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7bd1>
  6fea97:	0f 0b                	ud2
  6fea99:	0f 0b                	ud2
  6fea9b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6feaa0:	49 ff cf             	dec    %r15
  6feaa3:	74 14                	je     6feab9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ab9>
  6feaa5:	4d 8d a6 98 00 00 00 	lea    0x98(%r14),%r12
  6feaac:	4c 89 f7             	mov    %r14,%rdi
  6feaaf:	e8 1c 39 00 00       	call   7023d0 <core::ptr::drop_glue::<gpui::element::DraftNode>>
  6feab4:	4d 89 e6             	mov    %r12,%r14
  6feab7:	eb e7                	jmp    6feaa0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7aa0>
  6feab9:	48 8b 84 24 30 04 00 	mov    0x430(%rsp),%rax
  6feac0:	00 
  6feac1:	48 85 c0             	test   %rax,%rax
  6feac4:	0f 84 f8 04 00 00    	je     6fefc2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7fc2>
  6feaca:	48 69 f0 98 00 00 00 	imul   $0x98,%rax,%rsi
  6fead1:	ba 08 00 00 00       	mov    $0x8,%edx
  6fead6:	48 89 df             	mov    %rbx,%rdi
  6fead9:	ff 15 59 cc 38 00    	call   *0x38cc59(%rip)        # a8b738 <_DYNAMIC+0x250>
  6feadf:	e9 de 04 00 00       	jmp    6fefc2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7fc2>
  6feae4:	ff 15 86 cc 38 00    	call   *0x38cc86(%rip)        # a8b770 <_DYNAMIC+0x288>
  6feaea:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6feaef:	41 b5 01             	mov    $0x1,%r13b
  6feaf2:	41 b4 01             	mov    $0x1,%r12b
  6feaf5:	b3 01                	mov    $0x1,%bl
  6feaf7:	eb 31                	jmp    6feb2a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b2a>
  6feaf9:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6feafe:	b3 01                	mov    $0x1,%bl
  6feb00:	eb 4a                	jmp    6feb4c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b4c>
  6feb02:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6feb07:	44 89 e3             	mov    %r12d,%ebx
  6feb0a:	49 8d 46 ff          	lea    -0x1(%r14),%rax
  6feb0e:	48 83 f8 fc          	cmp    $0xfffffffffffffffc,%rax
  6feb12:	77 16                	ja     6feb2a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b2a>
  6feb14:	ba 01 00 00 00       	mov    $0x1,%edx
  6feb19:	48 8b bc 24 08 04 00 	mov    0x408(%rsp),%rdi
  6feb20:	00 
  6feb21:	4c 89 f6             	mov    %r14,%rsi
  6feb24:	ff 15 0e cc 38 00    	call   *0x38cc0e(%rip)        # a8b738 <_DYNAMIC+0x250>
  6feb2a:	45 84 ed             	test   %r13b,%r13b
  6feb2d:	74 18                	je     6feb47 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b47>
  6feb2f:	48 83 bc 24 60 04 00 	cmpq   $0xfffffffffffffffe,0x460(%rsp)
  6feb36:	00 fe 
  6feb38:	74 0d                	je     6feb47 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b47>
  6feb3a:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
  6feb41:	00 
  6feb42:	e8 b9 66 fe ff       	call   6e5200 <core::ptr::drop_glue::<gpui::runtime::TextSite>>
  6feb47:	45 84 e4             	test   %r12b,%r12b
  6feb4a:	74 12                	je     6feb5e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b5e>
  6feb4c:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  6feb51:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
  6feb58:	00 
  6feb59:	e8 52 3a fe ff       	call   6e25b0 <core::ptr::drop_glue::<core::option::Option<gpui::element::Handler>>>
  6feb5e:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
  6feb65:	00 
  6feb66:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6feb6a:	74 18                	je     6feb84 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b84>
  6feb6c:	48 85 f6             	test   %rsi,%rsi
  6feb6f:	7e 13                	jle    6feb84 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b84>
  6feb71:	48 8b bc 24 98 00 00 	mov    0x98(%rsp),%rdi
  6feb78:	00 
  6feb79:	ba 01 00 00 00       	mov    $0x1,%edx
  6feb7e:	ff 15 b4 cb 38 00    	call   *0x38cbb4(%rip)        # a8b738 <_DYNAMIC+0x250>
  6feb84:	84 db                	test   %bl,%bl
  6feb86:	74 15                	je     6feb9d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b9d>
  6feb88:	48 8b bc 24 08 01 00 	mov    0x108(%rsp),%rdi
  6feb8f:	00 
  6feb90:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
  6feb97:	00 
  6feb98:	e8 13 3a fe ff       	call   6e25b0 <core::ptr::drop_glue::<core::option::Option<gpui::element::Handler>>>
  6feb9d:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  6feba4:	00 
  6feba5:	e8 d6 64 fe ff       	call   6e5080 <core::ptr::drop_glue::<gpui::element::ComponentBoundaries>>
  6febaa:	b0 01                	mov    $0x1,%al
  6febac:	89 44 24 38          	mov    %eax,0x38(%rsp)
  6febb0:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  6febb7:	00 
  6febb8:	e8 63 08 02 00       	call   71f420 <<alloc::vec::into_iter::IntoIter<gpui::element::DraftNode> as core::ops::drop::Drop>::drop>
  6febbd:	b3 01                	mov    $0x1,%bl
  6febbf:	40 b5 01             	mov    $0x1,%bpl
  6febc2:	41 b6 01             	mov    $0x1,%r14b
  6febc5:	b0 01                	mov    $0x1,%al
  6febc7:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6febcb:	b0 01                	mov    $0x1,%al
  6febcd:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6febd1:	ba 04 00 00 00       	mov    $0x4,%edx
  6febd6:	48 8b bc 24 30 02 00 	mov    0x230(%rsp),%rdi
  6febdd:	00 
  6febde:	48 8b b4 24 a0 02 00 	mov    0x2a0(%rsp),%rsi
  6febe5:	00 
  6febe6:	ff 15 4c cb 38 00    	call   *0x38cb4c(%rip)        # a8b738 <_DYNAMIC+0x250>
  6febec:	41 b7 01             	mov    $0x1,%r15b
  6febef:	45 31 e4             	xor    %r12d,%r12d
  6febf2:	48 8d bc 24 78 05 00 	lea    0x578(%rsp),%rdi
  6febf9:	00 
  6febfa:	e8 b1 4f fe ff       	call   6e3bb0 <core::ptr::drop_glue::<alloc::vec::Vec<core::option::Option<gpui::runtime::TextSite>>>>
  6febff:	84 db                	test   %bl,%bl
  6fec01:	0f 84 cc 00 00 00    	je     6fecd3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7cd3>
  6fec07:	48 8d bc 24 60 05 00 	lea    0x560(%rsp),%rdi
  6fec0e:	00 
  6fec0f:	e8 3c 4f fe ff       	call   6e3b50 <core::ptr::drop_glue::<alloc::vec::Vec<core::option::Option<gpui::element::Handler>>>>
  6fec14:	e9 92 00 00 00       	jmp    6fecab <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7cab>
  6fec19:	eb 1d                	jmp    6fec38 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c38>
  6fec1b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fec20:	ba 08 00 00 00       	mov    $0x8,%edx
  6fec25:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
  6fec2c:	00 
  6fec2d:	48 89 de             	mov    %rbx,%rsi
  6fec30:	ff 15 02 cb 38 00    	call   *0x38cb02(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fec36:	eb 05                	jmp    6fec3d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c3d>
  6fec38:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fec3d:	b0 01                	mov    $0x1,%al
  6fec3f:	89 44 24 38          	mov    %eax,0x38(%rsp)
  6fec43:	41 b5 01             	mov    $0x1,%r13b
  6fec46:	b3 01                	mov    $0x1,%bl
  6fec48:	40 b5 01             	mov    $0x1,%bpl
  6fec4b:	41 b6 01             	mov    $0x1,%r14b
  6fec4e:	b0 01                	mov    $0x1,%al
  6fec50:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fec54:	b0 01                	mov    $0x1,%al
  6fec56:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fec5a:	41 b4 01             	mov    $0x1,%r12b
  6fec5d:	e9 ae 00 00 00       	jmp    6fed10 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d10>
  6fec62:	89 5c 24 18          	mov    %ebx,0x18(%rsp)
  6fec66:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fec6b:	41 b4 01             	mov    $0x1,%r12b
  6fec6e:	b0 01                	mov    $0x1,%al
  6fec70:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fec74:	b0 01                	mov    $0x1,%al
  6fec76:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fec7a:	41 b6 01             	mov    $0x1,%r14b
  6fec7d:	40 b5 01             	mov    $0x1,%bpl
  6fec80:	41 b7 01             	mov    $0x1,%r15b
  6fec83:	e9 78 01 00 00       	jmp    6fee00 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e00>
  6fec88:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fec8d:	41 b4 01             	mov    $0x1,%r12b
  6fec90:	b0 01                	mov    $0x1,%al
  6fec92:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fec96:	b0 01                	mov    $0x1,%al
  6fec98:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fec9c:	41 b6 01             	mov    $0x1,%r14b
  6fec9f:	40 b5 01             	mov    $0x1,%bpl
  6feca2:	41 b7 01             	mov    $0x1,%r15b
  6feca5:	b0 01                	mov    $0x1,%al
  6feca7:	89 44 24 38          	mov    %eax,0x38(%rsp)
  6fecab:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  6fecb2:	00 
  6fecb3:	48 85 c0             	test   %rax,%rax
  6fecb6:	74 1b                	je     6fecd3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7cd3>
  6fecb8:	48 8b bc 24 88 01 00 	mov    0x188(%rsp),%rdi
  6fecbf:	00 
  6fecc0:	48 c1 e0 03          	shl    $0x3,%rax
  6fecc4:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6fecc8:	ba 08 00 00 00       	mov    $0x8,%edx
  6feccd:	ff 15 65 ca 38 00    	call   *0x38ca65(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fecd3:	b3 01                	mov    $0x1,%bl
  6fecd5:	45 84 ff             	test   %r15b,%r15b
  6fecd8:	74 0f                	je     6fece9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ce9>
  6fecda:	b3 01                	mov    $0x1,%bl
  6fecdc:	48 8d bc 24 20 07 00 	lea    0x720(%rsp),%rdi
  6fece3:	00 
  6fece4:	e8 e7 77 fe ff       	call   6e64d0 <core::ptr::drop_glue::<gpui::runtime::styles::Builder>>
  6fece9:	48 8b b4 24 a8 02 00 	mov    0x2a8(%rsp),%rsi
  6fecf0:	00 
  6fecf1:	48 85 f6             	test   %rsi,%rsi
  6fecf4:	74 17                	je     6fed0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d0d>
  6fecf6:	48 c1 e6 03          	shl    $0x3,%rsi
  6fecfa:	ba 08 00 00 00       	mov    $0x8,%edx
  6fecff:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
  6fed06:	00 
  6fed07:	ff 15 2b ca 38 00    	call   *0x38ca2b(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fed0d:	45 31 ed             	xor    %r13d,%r13d
  6fed10:	48 8d bc 24 a8 08 00 	lea    0x8a8(%rsp),%rdi
  6fed17:	00 
  6fed18:	e8 b3 db 00 00       	call   70c8d0 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fed1d:	48 8d bc 24 98 06 00 	lea    0x698(%rsp),%rdi
  6fed24:	00 
  6fed25:	e8 36 d8 00 00       	call   70c560 <<alloc::collections::btree::map::BTreeMap<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize> as core::ops::drop::Drop>::drop>
  6fed2a:	48 8d bc 24 80 06 00 	lea    0x680(%rsp),%rdi
  6fed31:	00 
  6fed32:	e8 29 d8 00 00       	call   70c560 <<alloc::collections::btree::map::BTreeMap<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize> as core::ops::drop::Drop>::drop>
  6fed37:	48 8b 84 24 70 06 00 	mov    0x670(%rsp),%rax
  6fed3e:	00 
  6fed3f:	48 85 c0             	test   %rax,%rax
  6fed42:	74 18                	je     6fed5c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d5c>
  6fed44:	48 c1 e0 03          	shl    $0x3,%rax
  6fed48:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6fed4c:	ba 08 00 00 00       	mov    $0x8,%edx
  6fed51:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
  6fed56:	ff 15 dc c9 38 00    	call   *0x38c9dc(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fed5c:	48 8b bc 24 10 05 00 	mov    0x510(%rsp),%rdi
  6fed63:	00 
  6fed64:	48 8b b4 24 00 04 00 	mov    0x400(%rsp),%rsi
  6fed6b:	00 
  6fed6c:	e8 df 58 fe ff       	call   6e4650 <core::ptr::drop_glue::<alloc::boxed::Box<[core::option::Option<gpui::element::Handler>]>>>
  6fed71:	48 8b b4 24 d8 07 00 	mov    0x7d8(%rsp),%rsi
  6fed78:	00 
  6fed79:	48 85 f6             	test   %rsi,%rsi
  6fed7c:	74 17                	je     6fed95 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d95>
  6fed7e:	48 8b bc 24 e0 07 00 	mov    0x7e0(%rsp),%rdi
  6fed85:	00 
  6fed86:	48 c1 e6 02          	shl    $0x2,%rsi
  6fed8a:	ba 04 00 00 00       	mov    $0x4,%edx
  6fed8f:	ff 15 a3 c9 38 00    	call   *0x38c9a3(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fed95:	48 8d bc 24 b0 06 00 	lea    0x6b0(%rsp),%rdi
  6fed9c:	00 
  6fed9d:	e8 fe 75 fe ff       	call   6e63a0 <core::ptr::drop_glue::<gpui::runtime::styles::Styles>>
  6feda2:	48 8d bc 24 48 04 00 	lea    0x448(%rsp),%rdi
  6feda9:	00 
  6fedaa:	e8 c1 cb 00 00       	call   70b970 <<alloc::collections::btree::map::BTreeMap<gpui::source::FieldId, gpui::shared_text::SharedText> as core::ops::drop::Drop>::drop>
  6fedaf:	80 7c 24 38 00       	cmpb   $0x0,0x38(%rsp)
  6fedb4:	74 29                	je     6feddf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ddf>
  6fedb6:	48 8b b4 24 78 02 00 	mov    0x278(%rsp),%rsi
  6fedbd:	00 
  6fedbe:	41 b7 01             	mov    $0x1,%r15b
  6fedc1:	48 85 f6             	test   %rsi,%rsi
  6fedc4:	74 1c                	je     6fede2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7de2>
  6fedc6:	48 8b bc 24 80 02 00 	mov    0x280(%rsp),%rdi
  6fedcd:	00 
  6fedce:	48 c1 e6 04          	shl    $0x4,%rsi
  6fedd2:	ba 08 00 00 00       	mov    $0x8,%edx
  6fedd7:	ff 15 5b c9 38 00    	call   *0x38c95b(%rip)        # a8b738 <_DYNAMIC+0x250>
  6feddd:	eb 03                	jmp    6fede2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7de2>
  6feddf:	45 31 ff             	xor    %r15d,%r15d
  6fede2:	45 84 ed             	test   %r13b,%r13b
  6fede5:	74 0d                	je     6fedf4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7df4>
  6fede7:	48 8d bc 24 f0 07 00 	lea    0x7f0(%rsp),%rdi
  6fedee:	00 
  6fedef:	e8 2c 85 fe ff       	call   6e7320 <core::ptr::drop_glue::<gpui::runtime::styles::colours::Discovery>>
  6fedf4:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
  6fedfb:	00 
  6fedfc:	84 db                	test   %bl,%bl
  6fedfe:	74 0d                	je     6fee0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e0d>
  6fee00:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  6fee07:	00 
  6fee08:	e8 53 cc 00 00       	call   70ba60 <<alloc::collections::btree::map::BTreeMap<gpui::source::FieldId, gpui::runtime::Fanout> as core::ops::drop::Drop>::drop>
  6fee0d:	ba 08 00 00 00       	mov    $0x8,%edx
  6fee12:	48 8b bc 24 d0 02 00 	mov    0x2d0(%rsp),%rdi
  6fee19:	00 
  6fee1a:	48 8b b4 24 18 04 00 	mov    0x418(%rsp),%rsi
  6fee21:	00 
  6fee22:	ff 15 10 c9 38 00    	call   *0x38c910(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fee28:	48 8b b4 24 60 02 00 	mov    0x260(%rsp),%rsi
  6fee2f:	00 
  6fee30:	48 85 f6             	test   %rsi,%rsi
  6fee33:	74 17                	je     6fee4c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e4c>
  6fee35:	48 8b bc 24 68 02 00 	mov    0x268(%rsp),%rdi
  6fee3c:	00 
  6fee3d:	48 c1 e6 02          	shl    $0x2,%rsi
  6fee41:	ba 04 00 00 00       	mov    $0x4,%edx
  6fee46:	ff 15 ec c8 38 00    	call   *0x38c8ec(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fee4c:	48 8b b4 24 48 02 00 	mov    0x248(%rsp),%rsi
  6fee53:	00 
  6fee54:	48 85 f6             	test   %rsi,%rsi
  6fee57:	74 17                	je     6fee70 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e70>
  6fee59:	48 8b bc 24 50 02 00 	mov    0x250(%rsp),%rdi
  6fee60:	00 
  6fee61:	48 c1 e6 03          	shl    $0x3,%rsi
  6fee65:	ba 08 00 00 00       	mov    $0x8,%edx
  6fee6a:	ff 15 c8 c8 38 00    	call   *0x38c8c8(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fee70:	48 8b b4 24 d8 02 00 	mov    0x2d8(%rsp),%rsi
  6fee77:	00 
  6fee78:	48 85 f6             	test   %rsi,%rsi
  6fee7b:	74 17                	je     6fee94 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e94>
  6fee7d:	48 8b bc 24 e0 02 00 	mov    0x2e0(%rsp),%rdi
  6fee84:	00 
  6fee85:	48 c1 e6 03          	shl    $0x3,%rsi
  6fee89:	ba 08 00 00 00       	mov    $0x8,%edx
  6fee8e:	ff 15 a4 c8 38 00    	call   *0x38c8a4(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fee94:	48 8d bc 24 c0 07 00 	lea    0x7c0(%rsp),%rdi
  6fee9b:	00 
  6fee9c:	e8 2f da 00 00       	call   70c8d0 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6feea1:	40 84 ed             	test   %bpl,%bpl
  6feea4:	74 0d                	je     6feeb3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7eb3>
  6feea6:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
  6feead:	00 
  6feeae:	e8 0d 52 fe ff       	call   6e40c0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui_canvas::image::Image>>>
  6feeb3:	48 8d bc 24 78 08 00 	lea    0x878(%rsp),%rdi
  6feeba:	00 
  6feebb:	e8 90 bc 00 00       	call   70ab50 <<alloc::collections::btree::map::BTreeMap<gpui_reactivity_core::tree::NodeId, fn(cephal::tree::traits::MeasureInput) -> cephal::tree::traits::MeasureOutput> as core::ops::drop::Drop>::drop>
  6feec0:	31 ed                	xor    %ebp,%ebp
  6feec2:	48 8d bc 24 60 08 00 	lea    0x860(%rsp),%rdi
  6feec9:	00 
  6feeca:	e8 01 da 00 00       	call   70c8d0 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6feecf:	45 84 f6             	test   %r14b,%r14b
  6feed2:	48 8b 9c 24 28 04 00 	mov    0x428(%rsp),%rbx
  6feed9:	00 
  6feeda:	74 0d                	je     6feee9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ee9>
  6feedc:	48 8d bc 24 f0 05 00 	lea    0x5f0(%rsp),%rdi
  6feee3:	00 
  6feee4:	e8 27 4e fe ff       	call   6e3d10 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::list::ListDraft>>>
  6feee9:	80 7c 24 08 00       	cmpb   $0x0,0x8(%rsp)
  6feeee:	44 8b 74 24 18       	mov    0x18(%rsp),%r14d
  6feef3:	74 24                	je     6fef19 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7f19>
  6feef5:	48 8b b4 24 48 05 00 	mov    0x548(%rsp),%rsi
  6feefc:	00 
  6feefd:	48 85 f6             	test   %rsi,%rsi
  6fef00:	74 17                	je     6fef19 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7f19>
  6fef02:	48 8b bc 24 50 05 00 	mov    0x550(%rsp),%rdi
  6fef09:	00 
  6fef0a:	48 c1 e6 04          	shl    $0x4,%rsi
  6fef0e:	ba 08 00 00 00       	mov    $0x8,%edx
  6fef13:	ff 15 1f c8 38 00    	call   *0x38c81f(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fef19:	48 8b 8c 24 20 02 00 	mov    0x220(%rsp),%rcx
  6fef20:	00 
  6fef21:	48 85 c9             	test   %rcx,%rcx
  6fef24:	0f 95 c0             	setne  %al
  6fef27:	41 84 c6             	test   %al,%r14b
  6fef2a:	74 1b                	je     6fef47 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7f47>
  6fef2c:	48 c1 e1 03          	shl    $0x3,%rcx
  6fef30:	48 8d 34 49          	lea    (%rcx,%rcx,2),%rsi
  6fef34:	ba 08 00 00 00       	mov    $0x8,%edx
  6fef39:	48 8b bc 24 38 02 00 	mov    0x238(%rsp),%rdi
  6fef40:	00 
  6fef41:	ff 15 f1 c7 38 00    	call   *0x38c7f1(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fef47:	48 83 bc 24 50 01 00 	cmpq   $0x0,0x150(%rsp)
  6fef4e:	00 00 
  6fef50:	74 26                	je     6fef78 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7f78>
  6fef52:	80 7c 24 20 00       	cmpb   $0x0,0x20(%rsp)
  6fef57:	74 1f                	je     6fef78 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7f78>
  6fef59:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
  6fef60:	00 
  6fef61:	48 c1 e6 04          	shl    $0x4,%rsi
  6fef65:	ba 08 00 00 00       	mov    $0x8,%edx
  6fef6a:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  6fef71:	00 
  6fef72:	ff 15 c0 c7 38 00    	call   *0x38c7c0(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fef78:	48 85 db             	test   %rbx,%rbx
  6fef7b:	0f 95 c0             	setne  %al
  6fef7e:	40 84 c5             	test   %al,%bpl
  6fef81:	74 1b                	je     6fef9e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7f9e>
  6fef83:	48 c1 e3 03          	shl    $0x3,%rbx
  6fef87:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
  6fef8b:	ba 08 00 00 00       	mov    $0x8,%edx
  6fef90:	48 8b bc 24 28 05 00 	mov    0x528(%rsp),%rdi
  6fef97:	00 
  6fef98:	ff 15 9a c7 38 00    	call   *0x38c79a(%rip)        # a8b738 <_DYNAMIC+0x250>
  6fef9e:	45 84 ff             	test   %r15b,%r15b
  6fefa1:	74 0d                	je     6fefb0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7fb0>
  6fefa3:	48 8d bc 24 e0 04 00 	lea    0x4e0(%rsp),%rdi
  6fefaa:	00 
  6fefab:	e8 60 50 fe ff       	call   6e4010 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::semantic::AnnotationDraft>>>
  6fefb0:	45 84 e4             	test   %r12b,%r12b
  6fefb3:	74 0d                	je     6fefc2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7fc2>
  6fefb5:	48 8d bc 24 30 04 00 	lea    0x430(%rsp),%rdi
  6fefbc:	00 
  6fefbd:	e8 fe 4d fe ff       	call   6e3dc0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::element::DraftNode>>>
  6fefc2:	48 8d bc 24 90 08 00 	lea    0x890(%rsp),%rdi
  6fefc9:	00 
  6fefca:	e8 a1 c6 00 00       	call   70b670 <<alloc::collections::btree::map::BTreeMap<gpui::list::ListId, alloc::collections::btree::set_val::SetValZST> as core::ops::drop::Drop>::drop>
  6fefcf:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  6fefd4:	e8 87 20 36 00       	call   a61060 <_Unwind_Resume@plt>
  6fefd9:	ff 15 91 c7 38 00    	call   *0x38c791(%rip)        # a8b770 <_DYNAMIC+0x288>
