
/tmp/gpui-route-topology-inline-evidence/bin/topology-inline-cost:     file format elf64-x86-64


Disassembly of section .text:

00000000006f0840 <<gpui::runtime::Win<route_columns_cost::Page>>::activate>:
  6f0840:	55                   	push   %rbp
  6f0841:	41 57                	push   %r15
  6f0843:	41 56                	push   %r14
  6f0845:	41 55                	push   %r13
  6f0847:	41 54                	push   %r12
  6f0849:	53                   	push   %rbx
  6f084a:	48 81 ec 98 00 00 00 	sub    $0x98,%rsp
  6f0851:	48 89 fb             	mov    %rdi,%rbx
  6f0854:	4c 8b 36             	mov    (%rsi),%r14
  6f0857:	4d 85 f6             	test   %r14,%r14
  6f085a:	74 2d                	je     6f0889 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x49>
  6f085c:	48 83 c6 08          	add    $0x8,%rsi
  6f0860:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
  6f0865:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
  6f086a:	48 c7 44 24 78 00 00 	movq   $0x0,0x78(%rsp)
  6f0871:	00 00 
  6f0873:	41 80 be 4e 07 00 00 	cmpb   $0x1,0x74e(%r14)
  6f087a:	01 
  6f087b:	75 20                	jne    6f089d <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x5d>
  6f087d:	48 c7 03 0e 00 00 00 	movq   $0xe,(%rbx)
  6f0884:	e9 61 01 00 00       	jmp    6f09ea <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f0889:	48 c7 03 0d 00 00 00 	movq   $0xd,(%rbx)
  6f0890:	48 c7 43 08 00 00 00 	movq   $0x0,0x8(%rbx)
  6f0897:	00 
  6f0898:	e9 4d 01 00 00       	jmp    6f09ea <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f089d:	49 89 f5             	mov    %rsi,%r13
  6f08a0:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  6f08a5:	4c 89 f6             	mov    %r14,%rsi
  6f08a8:	e8 93 64 00 00       	call   6f6d40 <<gpui::runtime::Runtime<route_columns_cost::Page>>::resolve_index>
  6f08ad:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  6f08b2:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  6f08b7:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6f08bb:	0f 85 fe 00 00 00    	jne    6f09bf <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x17f>
  6f08c1:	49 8b b6 a0 02 00 00 	mov    0x2a0(%r14),%rsi
  6f08c8:	49 39 f4             	cmp    %rsi,%r12
  6f08cb:	0f 83 b6 02 00 00    	jae    6f0b87 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x347>
  6f08d1:	49 8b 86 98 02 00 00 	mov    0x298(%r14),%rax
  6f08d8:	4b 8d 0c 64          	lea    (%r12,%r12,2),%rcx
  6f08dc:	8b 54 c8 10          	mov    0x10(%rax,%rcx,8),%edx
  6f08e0:	83 e2 0f             	and    $0xf,%edx
  6f08e3:	8d 72 fd             	lea    -0x3(%rdx),%esi
  6f08e6:	83 fe 07             	cmp    $0x7,%esi
  6f08e9:	72 09                	jb     6f08f4 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0xb4>
  6f08eb:	83 fa 02             	cmp    $0x2,%edx
  6f08ee:	0f 83 0b 01 00 00    	jae    6f09ff <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1bf>
  6f08f4:	48 8d 04 c8          	lea    (%rax,%rcx,8),%rax
  6f08f8:	48 8b 78 08          	mov    0x8(%rax),%rdi
  6f08fc:	48 c1 ef 22          	shr    $0x22,%rdi
  6f0900:	48 83 ef 01          	sub    $0x1,%rdi
  6f0904:	0f 82 d9 00 00 00    	jb     6f09e3 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1a3>
  6f090a:	49 8b b6 b8 05 00 00 	mov    0x5b8(%r14),%rsi
  6f0911:	48 39 f7             	cmp    %rsi,%rdi
  6f0914:	0f 83 7d 02 00 00    	jae    6f0b97 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x357>
  6f091a:	4d 8b be b0 05 00 00 	mov    0x5b0(%r14),%r15
  6f0921:	48 c1 e7 04          	shl    $0x4,%rdi
  6f0925:	49 83 3c 3f 00       	cmpq   $0x0,(%r15,%rdi,1)
  6f092a:	0f 84 b3 00 00 00    	je     6f09e3 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1a3>
  6f0930:	49 01 ff             	add    %rdi,%r15
  6f0933:	49 8d 96 d0 05 00 00 	lea    0x5d0(%r14),%rdx
  6f093a:	4d 8d 86 28 02 00 00 	lea    0x228(%r14),%r8
  6f0941:	48 8d 0d 40 1d 37 00 	lea    0x371d40(%rip),%rcx        # a62688 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x1f8>
  6f0948:	4c 8d 0d 59 1d 37 00 	lea    0x371d59(%rip),%r9        # a626a8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x218>
  6f094f:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  6f0954:	4c 89 fe             	mov    %r15,%rsi
  6f0957:	ff 15 b3 b0 39 00    	call   *0x39b0b3(%rip)        # a8ba10 <_DYNAMIC+0x528>
  6f095d:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  6f0962:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  6f0967:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  6f096c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6f0971:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  6f0976:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  6f097b:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  6f0980:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6f0984:	0f 84 95 02 00 00    	je     6f0c1f <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x3df>
  6f098a:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f098e:	0f 85 a8 00 00 00    	jne    6f0a3c <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1fc>
  6f0994:	66 85 ed             	test   %bp,%bp
  6f0997:	0f 84 e8 00 00 00    	je     6f0a85 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x245>
  6f099d:	0f b7 c5             	movzwl %bp,%eax
  6f09a0:	83 f8 01             	cmp    $0x1,%eax
  6f09a3:	0f 85 86 01 00 00    	jne    6f0b2f <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x2ef>
  6f09a9:	48 c1 ed 10          	shr    $0x10,%rbp
  6f09ad:	48 89 df             	mov    %rbx,%rdi
  6f09b0:	4c 89 f6             	mov    %r14,%rsi
  6f09b3:	4c 89 ea             	mov    %r13,%rdx
  6f09b6:	89 e9                	mov    %ebp,%ecx
  6f09b8:	e8 c3 d8 ff ff       	call   6ee280 <<gpui::runtime::RuntimeMut<route_columns_cost::Page, ()>>::window_action>
  6f09bd:	eb 2b                	jmp    6f09ea <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f09bf:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  6f09c4:	48 89 4b 30          	mov    %rcx,0x30(%rbx)
  6f09c8:	0f 10 44 24 40       	movups 0x40(%rsp),%xmm0
  6f09cd:	0f 10 4c 24 50       	movups 0x50(%rsp),%xmm1
  6f09d2:	0f 11 4b 20          	movups %xmm1,0x20(%rbx)
  6f09d6:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
  6f09da:	48 89 03             	mov    %rax,(%rbx)
  6f09dd:	4c 89 63 08          	mov    %r12,0x8(%rbx)
  6f09e1:	eb 07                	jmp    6f09ea <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f09e3:	48 c7 03 16 00 00 00 	movq   $0x16,(%rbx)
  6f09ea:	48 89 d8             	mov    %rbx,%rax
  6f09ed:	48 81 c4 98 00 00 00 	add    $0x98,%rsp
  6f09f4:	5b                   	pop    %rbx
  6f09f5:	41 5c                	pop    %r12
  6f09f7:	41 5d                	pop    %r13
  6f09f9:	41 5e                	pop    %r14
  6f09fb:	41 5f                	pop    %r15
  6f09fd:	5d                   	pop    %rbp
  6f09fe:	c3                   	ret
  6f09ff:	0f 85 5d 01 00 00    	jne    6f0b62 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x322>
  6f0a05:	49 c7 86 38 07 00 00 	movq   $0x0,0x738(%r14)
  6f0a0c:	00 00 00 00 
  6f0a10:	41 0f 10 86 90 06 00 	movups 0x690(%r14),%xmm0
  6f0a17:	00 
  6f0a18:	41 0f b6 86 4c 07 00 	movzbl 0x74c(%r14),%eax
  6f0a1f:	00 
  6f0a20:	49 83 be b0 06 00 00 	cmpq   $0x0,0x6b0(%r14)
  6f0a27:	00 
  6f0a28:	74 0e                	je     6f0a38 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1f8>
  6f0a2a:	84 c0                	test   %al,%al
  6f0a2c:	74 28                	je     6f0a56 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x216>
  6f0a2e:	49 83 be 88 05 00 00 	cmpq   $0xffffffffffffffff,0x588(%r14)
  6f0a35:	ff 
  6f0a36:	75 1e                	jne    6f0a56 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x216>
  6f0a38:	31 c9                	xor    %ecx,%ecx
  6f0a3a:	eb 26                	jmp    6f0a62 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x222>
  6f0a3c:	48 c7 03 20 00 00 00 	movq   $0x20,(%rbx)
  6f0a43:	48 89 43 08          	mov    %rax,0x8(%rbx)
  6f0a47:	48 89 6b 10          	mov    %rbp,0x10(%rbx)
  6f0a4b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f0a50:	48 89 43 18          	mov    %rax,0x18(%rbx)
  6f0a54:	eb 94                	jmp    6f09ea <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f0a56:	49 8b 96 c0 06 00 00 	mov    0x6c0(%r14),%rdx
  6f0a5d:	b9 01 00 00 00       	mov    $0x1,%ecx
  6f0a62:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
  6f0a66:	48 89 53 10          	mov    %rdx,0x10(%rbx)
  6f0a6a:	0f 11 43 18          	movups %xmm0,0x18(%rbx)
  6f0a6e:	48 c7 43 28 00 00 00 	movq   $0x0,0x28(%rbx)
  6f0a75:	00 
  6f0a76:	88 43 30             	mov    %al,0x30(%rbx)
  6f0a79:	48 c7 03 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rbx)
  6f0a80:	e9 65 ff ff ff       	jmp    6f09ea <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f0a85:	4d 8b a6 90 06 00 00 	mov    0x690(%r14),%r12
  6f0a8c:	49 ff c4             	inc    %r12
  6f0a8f:	0f 84 e6 00 00 00    	je     6f0b7b <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x33b>
  6f0a95:	48 c7 44 24 30 1f 00 	movq   $0x1f,0x30(%rsp)
  6f0a9c:	00 00 
  6f0a9e:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  6f0aa3:	e8 08 47 ff ff       	call   6e51b0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6f0aa8:	48 8d 0d d9 1b 37 00 	lea    0x371bd9(%rip),%rcx        # a62688 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x1f8>
  6f0aaf:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  6f0ab4:	4c 89 fe             	mov    %r15,%rsi
  6f0ab7:	49 8d 96 d0 05 00 00 	lea    0x5d0(%r14),%rdx
  6f0abe:	ff 15 54 af 39 00    	call   *0x39af54(%rip)        # a8ba18 <_DYNAMIC+0x530>
  6f0ac4:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  6f0ac9:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  6f0ace:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  6f0ad3:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  6f0ad8:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  6f0add:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6f0ae1:	0f 84 d9 00 00 00    	je     6f0bc0 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x380>
  6f0ae7:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f0aeb:	75 5c                	jne    6f0b49 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x309>
  6f0aed:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  6f0af2:	e8 99 23 ff ff       	call   6e2e90 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6f0af7:	4d 89 a6 90 06 00 00 	mov    %r12,0x690(%r14)
  6f0afe:	49 ff 86 e0 06 00 00 	incq   0x6e0(%r14)
  6f0b05:	49 c7 86 38 07 00 00 	movq   $0x0,0x738(%r14)
  6f0b0c:	00 00 00 00 
  6f0b10:	48 8d 74 24 68       	lea    0x68(%rsp),%rsi
  6f0b15:	48 8d 4c 24 78       	lea    0x78(%rsp),%rcx
  6f0b1a:	48 89 df             	mov    %rbx,%rdi
  6f0b1d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6f0b22:	45 31 c0             	xor    %r8d,%r8d
  6f0b25:	e8 d6 83 ff ff       	call   6e8f00 <<gpui::runtime::RuntimeMut<route_columns_cost::Page, ()>>::after_source_changed>
  6f0b2a:	e9 bb fe ff ff       	jmp    6f09ea <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f0b2f:	48 8d 74 24 68       	lea    0x68(%rsp),%rsi
  6f0b34:	48 8d 4c 24 78       	lea    0x78(%rsp),%rcx
  6f0b39:	48 89 df             	mov    %rbx,%rdi
  6f0b3c:	4c 89 e2             	mov    %r12,%rdx
  6f0b3f:	e8 6c 77 ff ff       	call   6e82b0 <<gpui::runtime::RuntimeMut<route_columns_cost::Page, ()>>::activate_property>
  6f0b44:	e9 a1 fe ff ff       	jmp    6f09ea <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f0b49:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
  6f0b4e:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
  6f0b52:	48 c7 03 20 00 00 00 	movq   $0x20,(%rbx)
  6f0b59:	48 89 43 08          	mov    %rax,0x8(%rbx)
  6f0b5d:	e9 88 fe ff ff       	jmp    6f09ea <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f0b62:	48 8d 3d fd 9e 96 ff 	lea    -0x696103(%rip),%rdi        # 5aa66 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2dbe>
  6f0b69:	48 8d 15 80 23 37 00 	lea    0x372380(%rip),%rdx        # a62ef0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa60>
  6f0b70:	be 83 00 00 00       	mov    $0x83,%esi
  6f0b75:	ff 15 fd ab 39 00    	call   *0x39abfd(%rip)        # a8b778 <_DYNAMIC+0x290>
  6f0b7b:	48 c7 03 1f 00 00 00 	movq   $0x1f,(%rbx)
  6f0b82:	e9 63 fe ff ff       	jmp    6f09ea <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f0b87:	48 8d 15 82 1f 37 00 	lea    0x371f82(%rip),%rdx        # a62b10 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x680>
  6f0b8e:	4c 89 e7             	mov    %r12,%rdi
  6f0b91:	ff 15 b9 ac 39 00    	call   *0x39acb9(%rip)        # a8b850 <_DYNAMIC+0x368>
  6f0b97:	48 8d 15 8a 1f 37 00 	lea    0x371f8a(%rip),%rdx        # a62b28 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x698>
  6f0b9e:	ff 15 ac ac 39 00    	call   *0x39acac(%rip)        # a8b850 <_DYNAMIC+0x368>
  6f0ba4:	48 89 c7             	mov    %rax,%rdi
  6f0ba7:	ff 15 d3 ac 39 00    	call   *0x39acd3(%rip)        # a8b880 <_DYNAMIC+0x398>
  6f0bad:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6f0bb2:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
  6f0bb7:	48 c7 44 24 10 fe ff 	movq   $0xfffffffffffffffe,0x10(%rsp)
  6f0bbe:	ff ff 
  6f0bc0:	4c 89 f7             	mov    %r14,%rdi
  6f0bc3:	e8 18 e4 00 00       	call   6fefe0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::poison>
  6f0bc8:	48 c7 03 0f 00 00 00 	movq   $0xf,(%rbx)
  6f0bcf:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  6f0bd4:	e8 b7 22 ff ff       	call   6e2e90 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6f0bd9:	e9 0c fe ff ff       	jmp    6f09ea <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f0bde:	ff 15 a4 ac 39 00    	call   *0x39aca4(%rip)        # a8b888 <_DYNAMIC+0x3a0>
  6f0be4:	48 89 c3             	mov    %rax,%rbx
  6f0be7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  6f0bec:	e8 9f 22 ff ff       	call   6e2e90 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6f0bf1:	e9 a2 00 00 00       	jmp    6f0c98 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x458>
  6f0bf6:	48 89 c7             	mov    %rax,%rdi
  6f0bf9:	ff 15 81 ac 39 00    	call   *0x39ac81(%rip)        # a8b880 <_DYNAMIC+0x398>
  6f0bff:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
  6f0c04:	48 89 c5             	mov    %rax,%rbp
  6f0c07:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6f0c0c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f0c11:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6f0c16:	48 c7 44 24 10 fe ff 	movq   $0xfffffffffffffffe,0x10(%rsp)
  6f0c1d:	ff ff 
  6f0c1f:	4c 89 f7             	mov    %r14,%rdi
  6f0c22:	e8 b9 e3 00 00       	call   6fefe0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::poison>
  6f0c27:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  6f0c2c:	48 c7 03 0f 00 00 00 	movq   $0xf,(%rbx)
  6f0c33:	49 8b 06             	mov    (%r14),%rax
  6f0c36:	48 85 c0             	test   %rax,%rax
  6f0c39:	74 05                	je     6f0c40 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x400>
  6f0c3b:	48 89 ef             	mov    %rbp,%rdi
  6f0c3e:	ff d0                	call   *%rax
  6f0c40:	49 8b 76 08          	mov    0x8(%r14),%rsi
  6f0c44:	48 85 f6             	test   %rsi,%rsi
  6f0c47:	0f 84 9d fd ff ff    	je     6f09ea <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f0c4d:	49 8b 56 10          	mov    0x10(%r14),%rdx
  6f0c51:	48 89 ef             	mov    %rbp,%rdi
  6f0c54:	ff 15 de aa 39 00    	call   *0x39aade(%rip)        # a8b738 <_DYNAMIC+0x250>
  6f0c5a:	e9 8b fd ff ff       	jmp    6f09ea <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f0c5f:	ff 15 23 ac 39 00    	call   *0x39ac23(%rip)        # a8b888 <_DYNAMIC+0x3a0>
  6f0c65:	48 89 c3             	mov    %rax,%rbx
  6f0c68:	49 8b 76 08          	mov    0x8(%r14),%rsi
  6f0c6c:	48 85 f6             	test   %rsi,%rsi
  6f0c6f:	74 27                	je     6f0c98 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x458>
  6f0c71:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f0c76:	48 8b 50 10          	mov    0x10(%rax),%rdx
  6f0c7a:	48 89 ef             	mov    %rbp,%rdi
  6f0c7d:	ff 15 b5 aa 39 00    	call   *0x39aab5(%rip)        # a8b738 <_DYNAMIC+0x250>
  6f0c83:	48 89 df             	mov    %rbx,%rdi
  6f0c86:	e8 d5 03 37 00       	call   a61060 <_Unwind_Resume@plt>
  6f0c8b:	48 89 c3             	mov    %rax,%rbx
  6f0c8e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  6f0c93:	e8 f8 21 ff ff       	call   6e2e90 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6f0c98:	48 89 df             	mov    %rbx,%rdi
  6f0c9b:	e8 c0 03 37 00       	call   a61060 <_Unwind_Resume@plt>
  6f0ca0:	ff 15 ca aa 39 00    	call   *0x39aaca(%rip)        # a8b770 <_DYNAMIC+0x288>
