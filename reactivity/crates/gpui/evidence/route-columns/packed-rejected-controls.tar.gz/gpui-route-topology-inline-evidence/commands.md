Commands for the selected constructor successor (run from the isolated worktree unless stated):

```sh
source /tmp/gpui-native-env.sh
unset RUSTFLAGS CARGO_ENCODED_RUSTFLAGS
CARGO_BUILD_JOBS=2 cargo build --offline --locked -p gpui --no-default-features --release --example route_columns_cost --jobs 2 --message-format=json
```

The JSON compiler-artifact selection requires the example target name, exactly one matching artifact and `fresh=false`, before copying the executable. The baseline/candidate public benchmark fixture SHA is checked equal. `core_lines.py --ref 5135d88bc6` uses the existing inventory-rust helper and tokei paths recorded in core-lines.json; no counter helper rebuild was needed.

The frozen example was run only in these six check configurations (the final repetitions argument is ignored in check mode):

```text
check activate 1000 1000 1
check activate 1000 500 1
check activate 16384 164 1
check equal 16384 0 1
check resize 16384 164 1
check snapshot 16384 164 1
```

Symbols, section sizes, relocations and actual per-symbol disassembly come from the native environment's nm, size and objdump. Source and artifact fingerprints are frozen in preregistered-inputs.json. The runner has been parsed for Python syntax without running its measurement body.

The future capture command, pending the parent's explicit coordinated phase grant, is:

```sh
timeout --signal=KILL 300s /nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3 /tmp/gpui-route-topology-inline-evidence/run_packed_pairs.py --cpu 0 --output /tmp/gpui-route-topology-inline-evidence/quiet-attempt-1
```

That command is registered here, not represented as executed.
