
/tmp/gpui-route-topology-evidence/bin/topology-cost:     file format elf64-x86-64


Disassembly of section .text:

0000000000739fd0 <<gpui::runtime::topology::Topology>::new>:
  739fd0:	50                   	push   %rax
  739fd1:	81 fa a0 86 01 00    	cmp    $0x186a0,%edx
  739fd7:	73 4c                	jae    73a025 <<gpui::runtime::topology::Topology>::new+0x55>
  739fd9:	48 83 ff 01          	cmp    $0x1,%rdi
  739fdd:	75 16                	jne    739ff5 <<gpui::runtime::topology::Topology>::new+0x25>
  739fdf:	48 81 fe a0 86 01 00 	cmp    $0x186a0,%rsi
  739fe6:	73 56                	jae    73a03e <<gpui::runtime::topology::Topology>::new+0x6e>
  739fe8:	48 ff c6             	inc    %rsi
  739feb:	48 83 f9 01          	cmp    $0x1,%rcx
  739fef:	74 0c                	je     739ffd <<gpui::runtime::topology::Topology>::new+0x2d>
  739ff1:	31 c0                	xor    %eax,%eax
  739ff3:	eb 22                	jmp    73a017 <<gpui::runtime::topology::Topology>::new+0x47>
  739ff5:	31 f6                	xor    %esi,%esi
  739ff7:	48 83 f9 01          	cmp    $0x1,%rcx
  739ffb:	75 f4                	jne    739ff1 <<gpui::runtime::topology::Topology>::new+0x21>
  739ffd:	49 81 f8 a0 86 01 00 	cmp    $0x186a0,%r8
  73a004:	73 38                	jae    73a03e <<gpui::runtime::topology::Topology>::new+0x6e>
  73a006:	49 c1 e0 22          	shl    $0x22,%r8
  73a00a:	48 b8 00 00 00 00 04 	movabs $0x400000000,%rax
  73a011:	00 00 00 
  73a014:	4c 01 c0             	add    %r8,%rax
  73a017:	48 01 c6             	add    %rax,%rsi
  73a01a:	89 d0                	mov    %edx,%eax
  73a01c:	48 c1 e0 11          	shl    $0x11,%rax
  73a020:	48 01 f0             	add    %rsi,%rax
  73a023:	59                   	pop    %rcx
  73a024:	c3                   	ret
  73a025:	48 8d 3d 73 2a 92 ff 	lea    -0x6dd58d(%rip),%rdi        # 5ca9f <anon.b9946fe4defe8b854d134b4bf5265d75.25.llvm.10307981152027530048+0x65b>
  73a02c:	48 8d 15 05 b0 32 00 	lea    0x32b005(%rip),%rdx        # a65038 <anon.ea3ba26602279f52731fb70a98baa254.4.llvm.10540171447137239933+0x138>
  73a033:	be 31 00 00 00       	mov    $0x31,%esi
  73a038:	ff 15 6a 17 35 00    	call   *0x35176a(%rip)        # a8b7a8 <_DYNAMIC+0x290>
  73a03e:	48 8d 3d 43 2a 92 ff 	lea    -0x6dd5bd(%rip),%rdi        # 5ca88 <anon.b9946fe4defe8b854d134b4bf5265d75.25.llvm.10307981152027530048+0x644>
  73a045:	48 8d 15 a4 af 32 00 	lea    0x32afa4(%rip),%rdx        # a64ff0 <anon.ea3ba26602279f52731fb70a98baa254.4.llvm.10540171447137239933+0xf0>
  73a04c:	be 2f 00 00 00       	mov    $0x2f,%esi
  73a051:	ff 15 51 17 35 00    	call   *0x351751(%rip)        # a8b7a8 <_DYNAMIC+0x290>
