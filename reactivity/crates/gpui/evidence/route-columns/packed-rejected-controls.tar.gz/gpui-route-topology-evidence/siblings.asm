
/tmp/gpui-route-topology-evidence/bin/topology-cost:     file format elf64-x86-64


Disassembly of section .text:

0000000000731f70 <<gpui::runtime::siblings::Siblings>::new>:
  731f70:	55                   	push   %rbp
  731f71:	41 57                	push   %r15
  731f73:	41 56                	push   %r14
  731f75:	41 55                	push   %r13
  731f77:	41 54                	push   %r12
  731f79:	53                   	push   %rbx
  731f7a:	50                   	push   %rax
  731f7b:	49 89 fe             	mov    %rdi,%r14
  731f7e:	48 85 d2             	test   %rdx,%rdx
  731f81:	0f 84 4f 01 00 00    	je     7320d6 <<gpui::runtime::siblings::Siblings>::new+0x166>
  731f87:	49 89 d7             	mov    %rdx,%r15
  731f8a:	49 89 f4             	mov    %rsi,%r12
  731f8d:	48 8d 04 12          	lea    (%rdx,%rdx,1),%rax
  731f91:	48 8d 1c 85 08 00 00 	lea    0x8(,%rax,4),%rbx
  731f98:	00 
  731f99:	ff 15 b9 97 35 00    	call   *0x3597b9(%rip)        # a8b758 <_DYNAMIC+0x240>
  731f9f:	be 04 00 00 00       	mov    $0x4,%esi
  731fa4:	48 89 df             	mov    %rbx,%rdi
  731fa7:	ff 15 eb 9b 35 00    	call   *0x359beb(%rip)        # a8bb98 <_DYNAMIC+0x680>
  731fad:	48 85 c0             	test   %rax,%rax
  731fb0:	0f 84 5d 01 00 00    	je     732113 <<gpui::runtime::siblings::Siblings>::new+0x1a3>
  731fb6:	4a 8d 0c 7d 02 00 00 	lea    0x2(,%r15,2),%rcx
  731fbd:	00 
  731fbe:	49 8d 77 02          	lea    0x2(%r15),%rsi
  731fc2:	4e 8d 04 b8          	lea    (%rax,%r15,4),%r8
  731fc6:	49 83 c0 08          	add    $0x8,%r8
  731fca:	4a 8d 14 fd 00 00 00 	lea    0x0(,%r15,8),%rdx
  731fd1:	00 
  731fd2:	4c 8d 0c 52          	lea    (%rdx,%rdx,2),%r9
  731fd6:	45 31 d2             	xor    %r10d,%r10d
  731fd9:	48 8d 15 e0 2d 33 00 	lea    0x332de0(%rip),%rdx        # a64dc0 <anon.b9946fe4defe8b854d134b4bf5265d75.26.llvm.10307981152027530048+0x58>
  731fe0:	4f 8b 5c 14 08       	mov    0x8(%r12,%r10,1),%r11
  731fe5:	41 81 e3 ff ff 01 00 	and    $0x1ffff,%r11d
  731fec:	49 8d 7b 01          	lea    0x1(%r11),%rdi
  731ff0:	48 39 f7             	cmp    %rsi,%rdi
  731ff3:	0f 83 01 01 00 00    	jae    7320fa <<gpui::runtime::siblings::Siblings>::new+0x18a>
  731ff9:	42 ff 44 98 04       	incl   0x4(%rax,%r11,4)
  731ffe:	49 83 c2 18          	add    $0x18,%r10
  732002:	4d 39 d1             	cmp    %r10,%r9
  732005:	75 d9                	jne    731fe0 <<gpui::runtime::siblings::Siblings>::new+0x70>
  732007:	8b 10                	mov    (%rax),%edx
  732009:	4d 8d 5f 01          	lea    0x1(%r15),%r11
  73200d:	44 89 df             	mov    %r11d,%edi
  732010:	83 e7 03             	and    $0x3,%edi
  732013:	41 ba 01 00 00 00    	mov    $0x1,%r10d
  732019:	49 83 ff 03          	cmp    $0x3,%r15
  73201d:	72 4a                	jb     732069 <<gpui::runtime::siblings::Siblings>::new+0xf9>
  73201f:	49 ba fc ff ff ff ff 	movabs $0xffffffffffffffc,%r10
  732026:	ff ff 0f 
  732029:	4d 21 d3             	and    %r10,%r11
  73202c:	45 31 d2             	xor    %r10d,%r10d
  73202f:	90                   	nop
  732030:	42 03 54 90 04       	add    0x4(%rax,%r10,4),%edx
  732035:	42 89 54 90 04       	mov    %edx,0x4(%rax,%r10,4)
  73203a:	42 03 54 90 08       	add    0x8(%rax,%r10,4),%edx
  73203f:	42 89 54 90 08       	mov    %edx,0x8(%rax,%r10,4)
  732044:	42 03 54 90 0c       	add    0xc(%rax,%r10,4),%edx
  732049:	42 89 54 90 0c       	mov    %edx,0xc(%rax,%r10,4)
  73204e:	42 03 54 90 10       	add    0x10(%rax,%r10,4),%edx
  732053:	42 89 54 90 10       	mov    %edx,0x10(%rax,%r10,4)
  732058:	49 83 c2 04          	add    $0x4,%r10
  73205c:	4d 39 d3             	cmp    %r10,%r11
  73205f:	75 cf                	jne    732030 <<gpui::runtime::siblings::Siblings>::new+0xc0>
  732061:	48 85 ff             	test   %rdi,%rdi
  732064:	74 1a                	je     732080 <<gpui::runtime::siblings::Siblings>::new+0x110>
  732066:	49 ff c2             	inc    %r10
  732069:	4e 8d 14 90          	lea    (%rax,%r10,4),%r10
  73206d:	45 31 db             	xor    %r11d,%r11d
  732070:	43 03 14 9a          	add    (%r10,%r11,4),%edx
  732074:	43 89 14 9a          	mov    %edx,(%r10,%r11,4)
  732078:	49 ff c3             	inc    %r11
  73207b:	4c 39 df             	cmp    %r11,%rdi
  73207e:	75 f0                	jne    732070 <<gpui::runtime::siblings::Siblings>::new+0x100>
  732080:	45 31 db             	xor    %r11d,%r11d
  732083:	48 8d 15 4e 2d 33 00 	lea    0x332d4e(%rip),%rdx        # a64dd8 <anon.b9946fe4defe8b854d134b4bf5265d75.26.llvm.10307981152027530048+0x70>
  73208a:	4c 8d 15 5f 2d 33 00 	lea    0x332d5f(%rip),%r10        # a64df0 <anon.b9946fe4defe8b854d134b4bf5265d75.26.llvm.10307981152027530048+0x88>
  732091:	45 31 ed             	xor    %r13d,%r13d
  732094:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  73209b:	00 00 00 00 00 
  7320a0:	4b 8b 6c 2c 08       	mov    0x8(%r12,%r13,1),%rbp
  7320a5:	89 ef                	mov    %ebp,%edi
  7320a7:	81 e7 ff ff 01 00    	and    $0x1ffff,%edi
  7320ad:	48 39 f7             	cmp    %rsi,%rdi
  7320b0:	73 48                	jae    7320fa <<gpui::runtime::siblings::Siblings>::new+0x18a>
  7320b2:	48 c1 ed 11          	shr    $0x11,%rbp
  7320b6:	81 e5 ff ff 01 00    	and    $0x1ffff,%ebp
  7320bc:	03 2c b8             	add    (%rax,%rdi,4),%ebp
  7320bf:	49 39 ef             	cmp    %rbp,%r15
  7320c2:	76 3b                	jbe    7320ff <<gpui::runtime::siblings::Siblings>::new+0x18f>
  7320c4:	45 89 1c a8          	mov    %r11d,(%r8,%rbp,4)
  7320c8:	49 83 c5 18          	add    $0x18,%r13
  7320cc:	41 ff c3             	inc    %r11d
  7320cf:	4d 39 e9             	cmp    %r13,%r9
  7320d2:	75 cc                	jne    7320a0 <<gpui::runtime::siblings::Siblings>::new+0x130>
  7320d4:	eb 07                	jmp    7320dd <<gpui::runtime::siblings::Siblings>::new+0x16d>
  7320d6:	b8 04 00 00 00       	mov    $0x4,%eax
  7320db:	31 c9                	xor    %ecx,%ecx
  7320dd:	49 89 0e             	mov    %rcx,(%r14)
  7320e0:	49 89 46 08          	mov    %rax,0x8(%r14)
  7320e4:	49 89 4e 10          	mov    %rcx,0x10(%r14)
  7320e8:	4c 89 f0             	mov    %r14,%rax
  7320eb:	48 83 c4 08          	add    $0x8,%rsp
  7320ef:	5b                   	pop    %rbx
  7320f0:	41 5c                	pop    %r12
  7320f2:	41 5d                	pop    %r13
  7320f4:	41 5e                	pop    %r14
  7320f6:	41 5f                	pop    %r15
  7320f8:	5d                   	pop    %rbp
  7320f9:	c3                   	ret
  7320fa:	49 89 c6             	mov    %rax,%r14
  7320fd:	eb 0c                	jmp    73210b <<gpui::runtime::siblings::Siblings>::new+0x19b>
  7320ff:	49 89 c6             	mov    %rax,%r14
  732102:	48 89 ef             	mov    %rbp,%rdi
  732105:	4c 89 fe             	mov    %r15,%rsi
  732108:	4c 89 d2             	mov    %r10,%rdx
  73210b:	ff 15 6f 97 35 00    	call   *0x35976f(%rip)        # a8b880 <_DYNAMIC+0x368>
  732111:	0f 0b                	ud2
  732113:	bf 04 00 00 00       	mov    $0x4,%edi
  732118:	48 89 de             	mov    %rbx,%rsi
  73211b:	ff 15 0f 97 35 00    	call   *0x35970f(%rip)        # a8b830 <_DYNAMIC+0x318>
  732121:	49 89 c7             	mov    %rax,%r15
  732124:	ba 04 00 00 00       	mov    $0x4,%edx
  732129:	4c 89 f7             	mov    %r14,%rdi
  73212c:	48 89 de             	mov    %rbx,%rsi
  73212f:	ff 15 33 96 35 00    	call   *0x359633(%rip)        # a8b768 <_DYNAMIC+0x250>
  732135:	4c 89 ff             	mov    %r15,%rdi
  732138:	e8 53 ef 32 00       	call   a61090 <_Unwind_Resume@plt>
