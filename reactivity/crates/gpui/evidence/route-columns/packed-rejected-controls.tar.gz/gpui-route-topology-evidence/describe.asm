
/tmp/gpui-route-topology-evidence/bin/topology-cost:     file format elf64-x86-64


Disassembly of section .text:

00000000006f7040 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner>:
  6f7040:	55                   	push   %rbp
  6f7041:	41 57                	push   %r15
  6f7043:	41 56                	push   %r14
  6f7045:	41 55                	push   %r13
  6f7047:	41 54                	push   %r12
  6f7049:	53                   	push   %rbx
  6f704a:	48 81 ec d8 08 00 00 	sub    $0x8d8,%rsp
  6f7051:	4d 89 c7             	mov    %r8,%r15
  6f7054:	48 89 cb             	mov    %rcx,%rbx
  6f7057:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  6f705c:	0f b6 86 4a 07 00 00 	movzbl 0x74a(%rsi),%eax
  6f7063:	88 84 24 60 03 00 00 	mov    %al,0x360(%rsp)
  6f706a:	48 ff 86 d8 06 00 00 	incq   0x6d8(%rsi)
  6f7071:	85 d2                	test   %edx,%edx
  6f7073:	75 07                	jne    6f707c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3c>
  6f7075:	48 ff 86 d0 06 00 00 	incq   0x6d0(%rsi)
  6f707c:	48 c7 84 24 80 08 00 	movq   $0x0,0x880(%rsp)
  6f7083:	00 00 00 00 00 
  6f7088:	48 c7 84 24 90 08 00 	movq   $0x0,0x890(%rsp)
  6f708f:	00 00 00 00 00 
  6f7094:	48 8d 86 d0 05 00 00 	lea    0x5d0(%rsi),%rax
  6f709b:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6f70a0:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  6f70a5:	48 8b 86 40 06 00 00 	mov    0x640(%rsi),%rax
  6f70ac:	48 85 c0             	test   %rax,%rax
  6f70af:	74 09                	je     6f70ba <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a>
  6f70b1:	48 8b 90 d8 00 00 00 	mov    0xd8(%rax),%rdx
  6f70b8:	eb 02                	jmp    6f70bc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c>
  6f70ba:	31 d2                	xor    %edx,%edx
  6f70bc:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  6f70c1:	49 8b 8e a8 06 00 00 	mov    0x6a8(%r14),%rcx
  6f70c8:	66 41 0f 6e 86 40 07 	movd   0x740(%r14),%xmm0
  6f70cf:	00 00 
  6f70d1:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  6f70d8:	00 
  6f70d9:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  6f70de:	e8 8d 93 02 00       	call   720470 <gpui::runtime::inspector::description::<route_columns_cost::Page>>
  6f70e3:	49 8d 8e 28 06 00 00 	lea    0x628(%r14),%rcx
  6f70ea:	49 8d 96 48 06 00 00 	lea    0x648(%r14),%rdx
  6f70f1:	48 8d 84 24 80 08 00 	lea    0x880(%rsp),%rax
  6f70f8:	00 
  6f70f9:	48 89 84 24 d0 02 00 	mov    %rax,0x2d0(%rsp)
  6f7100:	00 
  6f7101:	48 89 8c 24 10 04 00 	mov    %rcx,0x410(%rsp)
  6f7108:	00 
  6f7109:	48 89 8c 24 d8 02 00 	mov    %rcx,0x2d8(%rsp)
  6f7110:	00 
  6f7111:	48 89 94 24 30 02 00 	mov    %rdx,0x230(%rsp)
  6f7118:	00 
  6f7119:	48 89 94 24 e0 02 00 	mov    %rdx,0x2e0(%rsp)
  6f7120:	00 
  6f7121:	48 c7 84 24 e8 02 00 	movq   $0x8,0x2e8(%rsp)
  6f7128:	00 08 00 00 00 
  6f712d:	48 c7 84 24 f0 02 00 	movq   $0x0,0x2f0(%rsp)
  6f7134:	00 00 00 00 00 
  6f7139:	4c 8d 05 a0 b5 36 00 	lea    0x36b5a0(%rip),%r8        # a626e0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x220>
  6f7140:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f7147:	00 
  6f7148:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6f714f:	00 
  6f7150:	4c 8d 8c 24 d0 02 00 	lea    0x2d0(%rsp),%r9
  6f7157:	00 
  6f7158:	ba a0 86 01 00       	mov    $0x186a0,%edx
  6f715d:	48 89 d9             	mov    %rbx,%rcx
  6f7160:	e8 9b 65 01 00       	call   70d700 <<gpui::element::El>::flatten_lists::<<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#1}>>
  6f7165:	48 8b 94 24 10 07 00 	mov    0x710(%rsp),%rdx
  6f716c:	00 
  6f716d:	48 8b 8c 24 18 07 00 	mov    0x718(%rsp),%rcx
  6f7174:	00 
  6f7175:	4c 8b 84 24 20 07 00 	mov    0x720(%rsp),%r8
  6f717c:	00 
  6f717d:	48 8b bc 24 28 07 00 	mov    0x728(%rsp),%rdi
  6f7184:	00 
  6f7185:	48 8b b4 24 30 07 00 	mov    0x730(%rsp),%rsi
  6f718c:	00 
  6f718d:	4c 8b 8c 24 38 07 00 	mov    0x738(%rsp),%r9
  6f7194:	00 
  6f7195:	48 8d 84 24 40 07 00 	lea    0x740(%rsp),%rax
  6f719c:	00 
  6f719d:	48 89 94 24 40 01 00 	mov    %rdx,0x140(%rsp)
  6f71a4:	00 
  6f71a5:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
  6f71a9:	0f 84 d2 01 00 00    	je     6f7381 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x341>
  6f71af:	4c 89 4c 24 60       	mov    %r9,0x60(%rsp)
  6f71b4:	4c 89 7c 24 70       	mov    %r15,0x70(%rsp)
  6f71b9:	4c 89 44 24 78       	mov    %r8,0x78(%rsp)
  6f71be:	48 89 bc 24 f8 01 00 	mov    %rdi,0x1f8(%rsp)
  6f71c5:	00 
  6f71c6:	48 89 b4 24 28 02 00 	mov    %rsi,0x228(%rsp)
  6f71cd:	00 
  6f71ce:	48 89 8c 24 48 01 00 	mov    %rcx,0x148(%rsp)
  6f71d5:	00 
  6f71d6:	48 8b 48 10          	mov    0x10(%rax),%rcx
  6f71da:	48 89 8c 24 f0 07 00 	mov    %rcx,0x7f0(%rsp)
  6f71e1:	00 
  6f71e2:	f3 0f 6f 00          	movdqu (%rax),%xmm0
  6f71e6:	66 0f 7f 84 24 e0 07 	movdqa %xmm0,0x7e0(%rsp)
  6f71ed:	00 00 
  6f71ef:	48 8b 84 24 58 07 00 	mov    0x758(%rsp),%rax
  6f71f6:	00 
  6f71f7:	48 69 94 24 68 07 00 	imul   $0xa8,0x768(%rsp),%rdx
  6f71fe:	00 a8 00 00 00 
  6f7203:	48 8b b4 24 60 07 00 	mov    0x760(%rsp),%rsi
  6f720a:	00 
  6f720b:	48 8b bc 24 80 07 00 	mov    0x780(%rsp),%rdi
  6f7212:	00 
  6f7213:	48 89 bc 24 e0 04 00 	mov    %rdi,0x4e0(%rsp)
  6f721a:	00 
  6f721b:	f3 0f 6f 8c 24 70 07 	movdqu 0x770(%rsp),%xmm1
  6f7222:	00 00 
  6f7224:	66 0f 7f 8c 24 d0 04 	movdqa %xmm1,0x4d0(%rsp)
  6f722b:	00 00 
  6f722d:	48 8b bc 24 88 07 00 	mov    0x788(%rsp),%rdi
  6f7234:	00 
  6f7235:	48 89 bc 24 18 04 00 	mov    %rdi,0x418(%rsp)
  6f723c:	00 
  6f723d:	48 8b bc 24 90 07 00 	mov    0x790(%rsp),%rdi
  6f7244:	00 
  6f7245:	48 89 bc 24 18 05 00 	mov    %rdi,0x518(%rsp)
  6f724c:	00 
  6f724d:	4c 8b ac 24 98 07 00 	mov    0x798(%rsp),%r13
  6f7254:	00 
  6f7255:	48 89 8c 24 30 04 00 	mov    %rcx,0x430(%rsp)
  6f725c:	00 
  6f725d:	66 0f 7f 84 24 20 04 	movdqa %xmm0,0x420(%rsp)
  6f7264:	00 00 
  6f7266:	48 c7 84 24 38 05 00 	movq   $0x0,0x538(%rsp)
  6f726d:	00 00 00 00 00 
  6f7272:	48 c7 84 24 40 05 00 	movq   $0x8,0x540(%rsp)
  6f7279:	00 08 00 00 00 
  6f727e:	48 c7 84 24 48 05 00 	movq   $0x0,0x548(%rsp)
  6f7285:	00 00 00 00 00 
  6f728a:	48 01 f2             	add    %rsi,%rdx
  6f728d:	48 89 b4 24 80 00 00 	mov    %rsi,0x80(%rsp)
  6f7294:	00 
  6f7295:	48 89 b4 24 88 00 00 	mov    %rsi,0x88(%rsp)
  6f729c:	00 
  6f729d:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6f72a4:	00 
  6f72a5:	48 89 94 24 98 00 00 	mov    %rdx,0x98(%rsp)
  6f72ac:	00 
  6f72ad:	48 8d 84 24 38 05 00 	lea    0x538(%rsp),%rax
  6f72b4:	00 
  6f72b5:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6f72bc:	00 
  6f72bd:	48 8d bc 24 e0 05 00 	lea    0x5e0(%rsp),%rdi
  6f72c4:	00 
  6f72c5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6f72cc:	00 
  6f72cd:	e8 7e 75 02 00       	call   71e850 <alloc::vec::in_place_collect::from_iter_in_place::<core::iter::adapters::filter_map::FilterMap<alloc::vec::into_iter::IntoIter<gpui::list::ViewportDraft>, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#2}>, gpui::list::ListDraft>>
  6f72d2:	48 8b 9c 24 e8 05 00 	mov    0x5e8(%rsp),%rbx
  6f72d9:	00 
  6f72da:	4c 69 b4 24 f0 05 00 	imul   $0xa8,0x5f0(%rsp),%r14
  6f72e1:	00 a8 00 00 00 
  6f72e6:	49 01 de             	add    %rbx,%r14
  6f72e9:	41 b4 01             	mov    $0x1,%r12b
  6f72ec:	48 8d bc 24 50 08 00 	lea    0x850(%rsp),%rdi
  6f72f3:	00 
  6f72f4:	b0 01                	mov    $0x1,%al
  6f72f6:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6f72fa:	40 b5 01             	mov    $0x1,%bpl
  6f72fd:	41 b7 01             	mov    $0x1,%r15b
  6f7300:	48 89 de             	mov    %rbx,%rsi
  6f7303:	4c 89 f2             	mov    %r14,%rdx
  6f7306:	e8 85 1a 01 00       	call   708d90 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::iter::traits::collect::FromIterator<(usize, gpui::list::ListId)>>::from_iter::<core::iter::adapters::map::Map<core::slice::iter::Iter<gpui::list::ListDraft>, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#3}>>>
  6f730b:	48 89 9c 24 80 00 00 	mov    %rbx,0x80(%rsp)
  6f7312:	00 
  6f7313:	4c 89 b4 24 88 00 00 	mov    %r14,0x88(%rsp)
  6f731a:	00 
  6f731b:	48 c7 84 24 90 00 00 	movq   $0x0,0x90(%rsp)
  6f7322:	00 00 00 00 00 
  6f7327:	48 c7 84 24 a8 00 00 	movq   $0x0,0xa8(%rsp)
  6f732e:	00 00 00 00 00 
  6f7333:	b3 01                	mov    $0x1,%bl
  6f7335:	48 8d bc 24 68 08 00 	lea    0x868(%rsp),%rdi
  6f733c:	00 
  6f733d:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6f7344:	00 
  6f7345:	b0 01                	mov    $0x1,%al
  6f7347:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6f734b:	40 b5 01             	mov    $0x1,%bpl
  6f734e:	41 b7 01             	mov    $0x1,%r15b
  6f7351:	e8 9a 1c 01 00       	call   708ff0 <<alloc::collections::btree::map::BTreeMap<usize, (gpui::list::ListId, &gpui::list::RowDraft)> as core::iter::traits::collect::FromIterator<(usize, (gpui::list::ListId, &gpui::list::RowDraft))>>::from_iter::<core::iter::adapters::flatten::FlatMap<core::slice::iter::Iter<gpui::list::ListDraft>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui::list::RowDraft>, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#4}::{closure#0}>, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#4}>>>
  6f7356:	4c 8b b4 24 30 04 00 	mov    0x430(%rsp),%r14
  6f735d:	00 
  6f735e:	49 81 fe a0 86 01 00 	cmp    $0x186a0,%r14
  6f7365:	76 50                	jbe    6f73b7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x377>
  6f7367:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f736c:	48 c7 00 1e 00 00 00 	movq   $0x1e,(%rax)
  6f7373:	b0 01                	mov    $0x1,%al
  6f7375:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6f7379:	40 b5 01             	mov    $0x1,%bpl
  6f737c:	e9 c5 60 00 00       	jmp    6fd446 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6406>
  6f7381:	0f 10 00             	movups (%rax),%xmm0
  6f7384:	0f 29 84 24 e0 07 00 	movaps %xmm0,0x7e0(%rsp)
  6f738b:	00 
  6f738c:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f7391:	48 89 08             	mov    %rcx,(%rax)
  6f7394:	4c 89 40 08          	mov    %r8,0x8(%rax)
  6f7398:	48 89 78 10          	mov    %rdi,0x10(%rax)
  6f739c:	48 89 70 18          	mov    %rsi,0x18(%rax)
  6f73a0:	4c 89 48 20          	mov    %r9,0x20(%rax)
  6f73a4:	66 0f 6f 84 24 e0 07 	movdqa 0x7e0(%rsp),%xmm0
  6f73ab:	00 00 
  6f73ad:	f3 0f 7f 40 28       	movdqu %xmm0,0x28(%rax)
  6f73b2:	e9 d5 62 00 00       	jmp    6fd68c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x664c>
  6f73b7:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f73bc:	48 8b 80 10 06 00 00 	mov    0x610(%rax),%rax
  6f73c3:	4c 01 f0             	add    %r14,%rax
  6f73c6:	0f 82 8d 63 00 00    	jb     6fd759 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6719>
  6f73cc:	48 8b 84 24 18 04 00 	mov    0x418(%rsp),%rax
  6f73d3:	00 
  6f73d4:	48 89 84 24 d0 02 00 	mov    %rax,0x2d0(%rsp)
  6f73db:	00 
  6f73dc:	48 8b 84 24 18 05 00 	mov    0x518(%rsp),%rax
  6f73e3:	00 
  6f73e4:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
  6f73eb:	00 
  6f73ec:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
  6f73f3:	00 
  6f73f4:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  6f73fb:	00 
  6f73fc:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
  6f7403:	00 
  6f7404:	ff 15 86 47 39 00    	call   *0x394786(%rip)        # a8bb90 <_DYNAMIC+0x678>
  6f740a:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  6f7411:	00 
  6f7412:	0f 10 84 24 88 00 00 	movups 0x88(%rsp),%xmm0
  6f7419:	00 
  6f741a:	0f 29 84 24 10 07 00 	movaps %xmm0,0x710(%rsp)
  6f7421:	00 
  6f7422:	0f 10 84 24 98 00 00 	movups 0x98(%rsp),%xmm0
  6f7429:	00 
  6f742a:	0f 29 84 24 20 07 00 	movaps %xmm0,0x720(%rsp)
  6f7431:	00 
  6f7432:	0f 10 84 24 a8 00 00 	movups 0xa8(%rsp),%xmm0
  6f7439:	00 
  6f743a:	0f 29 84 24 30 07 00 	movaps %xmm0,0x730(%rsp)
  6f7441:	00 
  6f7442:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6f7446:	0f 85 fd 00 00 00    	jne    6f7549 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x509>
  6f744c:	48 8b 84 24 20 07 00 	mov    0x720(%rsp),%rax
  6f7453:	00 
  6f7454:	48 89 84 24 b0 04 00 	mov    %rax,0x4b0(%rsp)
  6f745b:	00 
  6f745c:	0f 28 84 24 10 07 00 	movaps 0x710(%rsp),%xmm0
  6f7463:	00 
  6f7464:	0f 29 84 24 a0 04 00 	movaps %xmm0,0x4a0(%rsp)
  6f746b:	00 
  6f746c:	48 8b 84 24 38 07 00 	mov    0x738(%rsp),%rax
  6f7473:	00 
  6f7474:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
  6f747b:	00 
  6f747c:	f3 0f 6f 84 24 28 07 	movdqu 0x728(%rsp),%xmm0
  6f7483:	00 00 
  6f7485:	66 0f 7f 84 24 b0 07 	movdqa %xmm0,0x7b0(%rsp)
  6f748c:	00 00 
  6f748e:	4d 85 f6             	test   %r14,%r14
  6f7491:	0f 84 f1 00 00 00    	je     6f7588 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x548>
  6f7497:	4a 8d 1c f5 00 00 00 	lea    0x0(,%r14,8),%rbx
  6f749e:	00 
  6f749f:	ff 15 b3 42 39 00    	call   *0x3942b3(%rip)        # a8b758 <_DYNAMIC+0x240>
  6f74a5:	be 08 00 00 00       	mov    $0x8,%esi
  6f74aa:	48 89 df             	mov    %rbx,%rdi
  6f74ad:	ff 15 ad 42 39 00    	call   *0x3942ad(%rip)        # a8b760 <_DYNAMIC+0x248>
  6f74b3:	48 85 c0             	test   %rax,%rax
  6f74b6:	0f 84 d0 65 00 00    	je     6fda8c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a4c>
  6f74bc:	4c 89 b4 24 b8 02 00 	mov    %r14,0x2b8(%rsp)
  6f74c3:	00 
  6f74c4:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  6f74cb:	00 
  6f74cc:	48 c7 84 24 c8 02 00 	movq   $0x0,0x2c8(%rsp)
  6f74d3:	00 00 00 00 00 
  6f74d8:	ff 15 7a 42 39 00    	call   *0x39427a(%rip)        # a8b758 <_DYNAMIC+0x240>
  6f74de:	be 08 00 00 00       	mov    $0x8,%esi
  6f74e3:	48 89 df             	mov    %rbx,%rdi
  6f74e6:	ff 15 74 42 39 00    	call   *0x394274(%rip)        # a8b760 <_DYNAMIC+0x248>
  6f74ec:	48 85 c0             	test   %rax,%rax
  6f74ef:	0f 84 aa 65 00 00    	je     6fda9f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a5f>
  6f74f5:	4c 89 b4 24 38 02 00 	mov    %r14,0x238(%rsp)
  6f74fc:	00 
  6f74fd:	48 89 84 24 40 02 00 	mov    %rax,0x240(%rsp)
  6f7504:	00 
  6f7505:	48 c7 84 24 48 02 00 	movq   $0x0,0x248(%rsp)
  6f750c:	00 00 00 00 00 
  6f7511:	4a 8d 1c b5 00 00 00 	lea    0x0(,%r14,4),%rbx
  6f7518:	00 
  6f7519:	ff 15 39 42 39 00    	call   *0x394239(%rip)        # a8b758 <_DYNAMIC+0x240>
  6f751f:	be 04 00 00 00       	mov    $0x4,%esi
  6f7524:	48 89 df             	mov    %rbx,%rdi
  6f7527:	ff 15 33 42 39 00    	call   *0x394233(%rip)        # a8b760 <_DYNAMIC+0x248>
  6f752d:	48 85 c0             	test   %rax,%rax
  6f7530:	0f 85 9f 00 00 00    	jne    6f75d5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x595>
  6f7536:	bf 04 00 00 00       	mov    $0x4,%edi
  6f753b:	48 89 de             	mov    %rbx,%rsi
  6f753e:	ff 15 ec 42 39 00    	call   *0x3942ec(%rip)        # a8b830 <_DYNAMIC+0x318>
  6f7544:	e9 d2 67 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6f7549:	66 0f 6f 84 24 10 07 	movdqa 0x710(%rsp),%xmm0
  6f7550:	00 00 
  6f7552:	66 0f 6f 8c 24 20 07 	movdqa 0x720(%rsp),%xmm1
  6f7559:	00 00 
  6f755b:	66 0f 6f 94 24 30 07 	movdqa 0x730(%rsp),%xmm2
  6f7562:	00 00 
  6f7564:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6f7569:	f3 0f 7f 51 28       	movdqu %xmm2,0x28(%rcx)
  6f756e:	f3 0f 7f 49 18       	movdqu %xmm1,0x18(%rcx)
  6f7573:	f3 0f 7f 41 08       	movdqu %xmm0,0x8(%rcx)
  6f7578:	48 89 01             	mov    %rax,(%rcx)
  6f757b:	b0 01                	mov    $0x1,%al
  6f757d:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6f7581:	31 ed                	xor    %ebp,%ebp
  6f7583:	e9 be 5e 00 00       	jmp    6fd446 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6406>
  6f7588:	48 c7 84 24 b8 02 00 	movq   $0x0,0x2b8(%rsp)
  6f758f:	00 00 00 00 00 
  6f7594:	48 c7 84 24 c0 02 00 	movq   $0x8,0x2c0(%rsp)
  6f759b:	00 08 00 00 00 
  6f75a0:	48 c7 84 24 c8 02 00 	movq   $0x0,0x2c8(%rsp)
  6f75a7:	00 00 00 00 00 
  6f75ac:	48 c7 84 24 38 02 00 	movq   $0x0,0x238(%rsp)
  6f75b3:	00 00 00 00 00 
  6f75b8:	48 c7 84 24 40 02 00 	movq   $0x8,0x240(%rsp)
  6f75bf:	00 08 00 00 00 
  6f75c4:	48 c7 84 24 48 02 00 	movq   $0x0,0x248(%rsp)
  6f75cb:	00 00 00 00 00 
  6f75d0:	b8 04 00 00 00       	mov    $0x4,%eax
  6f75d5:	4c 89 b4 24 50 02 00 	mov    %r14,0x250(%rsp)
  6f75dc:	00 
  6f75dd:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
  6f75e4:	00 
  6f75e5:	48 c7 84 24 60 02 00 	movq   $0x0,0x260(%rsp)
  6f75ec:	00 00 00 00 00 
  6f75f1:	4a 8d 1c f5 08 00 00 	lea    0x8(,%r14,8),%rbx
  6f75f8:	00 
  6f75f9:	ff 15 59 41 39 00    	call   *0x394159(%rip)        # a8b758 <_DYNAMIC+0x240>
  6f75ff:	be 08 00 00 00       	mov    $0x8,%esi
  6f7604:	48 89 9c 24 08 04 00 	mov    %rbx,0x408(%rsp)
  6f760b:	00 
  6f760c:	48 89 df             	mov    %rbx,%rdi
  6f760f:	ff 15 83 45 39 00    	call   *0x394583(%rip)        # a8bb98 <_DYNAMIC+0x680>
  6f7615:	48 89 84 24 b0 02 00 	mov    %rax,0x2b0(%rsp)
  6f761c:	00 
  6f761d:	48 85 c0             	test   %rax,%rax
  6f7620:	0f 84 df 63 00 00    	je     6fda05 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x69c5>
  6f7626:	49 8d 46 01          	lea    0x1(%r14),%rax
  6f762a:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
  6f7631:	00 
  6f7632:	4c 8b bc 24 28 04 00 	mov    0x428(%rsp),%r15
  6f7639:	00 
  6f763a:	48 c7 84 24 50 01 00 	movq   $0x0,0x150(%rsp)
  6f7641:	00 00 00 00 00 
  6f7646:	48 c7 84 24 60 01 00 	movq   $0x0,0x160(%rsp)
  6f764d:	00 00 00 00 00 
  6f7652:	4d 85 f6             	test   %r14,%r14
  6f7655:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
  6f765a:	0f 84 df 04 00 00    	je     6f7b3f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xaff>
  6f7660:	49 69 c6 98 00 00 00 	imul   $0x98,%r14,%rax
  6f7667:	4c 01 f8             	add    %r15,%rax
  6f766a:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6f766f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f7674:	48 05 28 02 00 00    	add    $0x228,%rax
  6f767a:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6f767f:	48 c7 84 24 30 01 00 	movq   $0x0,0x130(%rsp)
  6f7686:	00 00 00 00 00 
  6f768b:	48 8d 05 c6 b2 36 00 	lea    0x36b2c6(%rip),%rax        # a62958 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x498>
  6f7692:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  6f7697:	48 b8 01 00 00 00 00 	movabs $0x8000000000000001,%rax
  6f769e:	00 00 80 
  6f76a1:	48 ff c0             	inc    %rax
  6f76a4:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  6f76a9:	48 c7 84 24 f0 01 00 	movq   $0x0,0x1f0(%rsp)
  6f76b0:	00 00 00 00 00 
  6f76b5:	41 0f b6 5f 18       	movzbl 0x18(%r15),%ebx
  6f76ba:	41 8b 6f 1c          	mov    0x1c(%r15),%ebp
  6f76be:	48 8d 45 01          	lea    0x1(%rbp),%rax
  6f76c2:	84 db                	test   %bl,%bl
  6f76c4:	b9 00 00 00 00       	mov    $0x0,%ecx
  6f76c9:	48 0f 45 c8          	cmovne %rax,%rcx
  6f76cd:	48 3b 4c 24 30       	cmp    0x30(%rsp),%rcx
  6f76d2:	0f 87 16 63 00 00    	ja     6fd9ee <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x69ae>
  6f76d8:	48 8b 84 24 b0 02 00 	mov    0x2b0(%rsp),%rax
  6f76df:	00 
  6f76e0:	48 ff 04 c8          	incq   (%rax,%rcx,8)
  6f76e4:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
  6f76eb:	00 
  6f76ec:	4c 8b a4 24 c8 02 00 	mov    0x2c8(%rsp),%r12
  6f76f3:	00 
  6f76f4:	84 db                	test   %bl,%bl
  6f76f6:	74 29                	je     6f7721 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6e1>
  6f76f8:	49 39 ec             	cmp    %rbp,%r12
  6f76fb:	0f 86 bd 63 00 00    	jbe    6fdabe <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a7e>
  6f7701:	4c 8b 34 e8          	mov    (%rax,%rbp,8),%r14
  6f7705:	49 ff c6             	inc    %r14
  6f7708:	49 81 fe 80 00 00 00 	cmp    $0x80,%r14
  6f770f:	0f 87 56 39 00 00    	ja     6fb06b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x402b>
  6f7715:	4c 3b a4 24 b8 02 00 	cmp    0x2b8(%rsp),%r12
  6f771c:	00 
  6f771d:	74 0f                	je     6f772e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6ee>
  6f771f:	eb 23                	jmp    6f7744 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x704>
  6f7721:	45 31 f6             	xor    %r14d,%r14d
  6f7724:	4c 3b a4 24 b8 02 00 	cmp    0x2b8(%rsp),%r12
  6f772b:	00 
  6f772c:	75 16                	jne    6f7744 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x704>
  6f772e:	48 8d bc 24 b8 02 00 	lea    0x2b8(%rsp),%rdi
  6f7735:	00 
  6f7736:	ff 15 64 44 39 00    	call   *0x394464(%rip)        # a8bba0 <_DYNAMIC+0x688>
  6f773c:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
  6f7743:	00 
  6f7744:	4e 89 34 e0          	mov    %r14,(%rax,%r12,8)
  6f7748:	49 ff c4             	inc    %r12
  6f774b:	4c 89 a4 24 c8 02 00 	mov    %r12,0x2c8(%rsp)
  6f7752:	00 
  6f7753:	45 31 f6             	xor    %r14d,%r14d
  6f7756:	84 db                	test   %bl,%bl
  6f7758:	74 1d                	je     6f7777 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x737>
  6f775a:	4c 8b a4 24 60 02 00 	mov    0x260(%rsp),%r12
  6f7761:	00 
  6f7762:	49 39 ec             	cmp    %rbp,%r12
  6f7765:	0f 86 47 63 00 00    	jbe    6fdab2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a72>
  6f776b:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  6f7772:	00 
  6f7773:	44 8b 34 a8          	mov    (%rax,%rbp,4),%r14d
  6f7777:	4d 8b a7 88 00 00 00 	mov    0x88(%r15),%r12
  6f777e:	4d 85 e4             	test   %r12,%r12
  6f7781:	0f 84 a3 00 00 00    	je     6f782a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ea>
  6f7787:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f778e:	00 00 
  6f7790:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
  6f7795:	0f 84 7a 5f 00 00    	je     6fd715 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x66d5>
  6f779b:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
  6f77a0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  6f77a7:	00 
  6f77a8:	4c 89 e6             	mov    %r12,%rsi
  6f77ab:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f77b0:	48 8d 0d e9 ae 36 00 	lea    0x36aee9(%rip),%rcx        # a626a0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x1e0>
  6f77b7:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  6f77bc:	4c 8d 0d fd ae 36 00 	lea    0x36aefd(%rip),%r9        # a626c0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x200>
  6f77c3:	ff 15 df 43 39 00    	call   *0x3943df(%rip)        # a8bba8 <_DYNAMIC+0x690>
  6f77c9:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  6f77d0:	00 
  6f77d1:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f77d5:	0f 85 de 06 00 00    	jne    6f7eb9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xe79>
  6f77db:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  6f77e2:	00 
  6f77e3:	4c 89 e6             	mov    %r12,%rsi
  6f77e6:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f77eb:	48 8d 0d ae ae 36 00 	lea    0x36aeae(%rip),%rcx        # a626a0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x1e0>
  6f77f2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  6f77f7:	4c 8d 0d c2 ae 36 00 	lea    0x36aec2(%rip),%r9        # a626c0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x200>
  6f77fe:	ff 15 ac 43 39 00    	call   *0x3943ac(%rip)        # a8bbb0 <_DYNAMIC+0x698>
  6f7804:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  6f780b:	00 
  6f780c:	44 8b b4 24 88 00 00 	mov    0x88(%rsp),%r14d
  6f7813:	00 
  6f7814:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f7818:	0f 85 bc 06 00 00    	jne    6f7eda <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xe9a>
  6f781e:	49 89 dc             	mov    %rbx,%r12
  6f7821:	48 85 db             	test   %rbx,%rbx
  6f7824:	0f 85 66 ff ff ff    	jne    6f7790 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x750>
  6f782a:	48 8b 9c 24 60 02 00 	mov    0x260(%rsp),%rbx
  6f7831:	00 
  6f7832:	48 3b 9c 24 50 02 00 	cmp    0x250(%rsp),%rbx
  6f7839:	00 
  6f783a:	75 0e                	jne    6f784a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x80a>
  6f783c:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
  6f7843:	00 
  6f7844:	ff 15 6e 43 39 00    	call   *0x39436e(%rip)        # a8bbb8 <_DYNAMIC+0x6a0>
  6f784a:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  6f7851:	00 
  6f7852:	44 89 34 98          	mov    %r14d,(%rax,%rbx,4)
  6f7856:	48 ff c3             	inc    %rbx
  6f7859:	48 89 9c 24 60 02 00 	mov    %rbx,0x260(%rsp)
  6f7860:	00 
  6f7861:	49 83 7f 78 00       	cmpq   $0x0,0x78(%r15)
  6f7866:	74 5a                	je     6f78c2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x882>
  6f7868:	49 8d 77 78          	lea    0x78(%r15),%rsi
  6f786c:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  6f7873:	00 
  6f7874:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f7879:	48 8d 0d 20 ae 36 00 	lea    0x36ae20(%rip),%rcx        # a626a0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x1e0>
  6f7880:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  6f7885:	4c 8d 0d 34 ae 36 00 	lea    0x36ae34(%rip),%r9        # a626c0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x200>
  6f788c:	ff 15 ae 41 39 00    	call   *0x3941ae(%rip)        # a8ba40 <_DYNAMIC+0x528>
  6f7892:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  6f7899:	00 
  6f789a:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f789e:	0f 85 d8 37 00 00    	jne    6fb07c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x403c>
  6f78a4:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
  6f78ab:	00 
  6f78ac:	48 ff c0             	inc    %rax
  6f78af:	4d 8b 27             	mov    (%r15),%r12
  6f78b2:	49 83 fc ff          	cmp    $0xffffffffffffffff,%r12
  6f78b6:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  6f78bd:	00 
  6f78be:	75 1b                	jne    6f78db <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x89b>
  6f78c0:	eb 6d                	jmp    6f792f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x8ef>
  6f78c2:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
  6f78c9:	00 
  6f78ca:	4d 8b 27             	mov    (%r15),%r12
  6f78cd:	49 83 fc ff          	cmp    $0xffffffffffffffff,%r12
  6f78d1:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  6f78d8:	00 
  6f78d9:	74 54                	je     6f792f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x8ef>
  6f78db:	4c 3b 64 24 38       	cmp    0x38(%rsp),%r12
  6f78e0:	75 4d                	jne    6f792f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x8ef>
  6f78e2:	49 8b 4f 08          	mov    0x8(%r15),%rcx
  6f78e6:	4d 8b 47 10          	mov    0x10(%r15),%r8
  6f78ea:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  6f78f1:	00 
  6f78f2:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  6f78f7:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f78fc:	e8 7f 9a 02 00       	call   721380 <<gpui::source::Sources<route_columns_cost::Page>>::resolve>
  6f7901:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  6f7908:	00 
  6f7909:	48 8b 9c 24 88 00 00 	mov    0x88(%rsp),%rbx
  6f7910:	00 
  6f7911:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f7915:	0f 85 d5 5d 00 00    	jne    6fd6f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x66b0>
  6f791b:	41 80 bf 90 00 00 00 	cmpb   $0x4,0x90(%r15)
  6f7922:	04 
  6f7923:	75 16                	jne    6f793b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x8fb>
  6f7925:	48 85 db             	test   %rbx,%rbx
  6f7928:	75 1a                	jne    6f7944 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x904>
  6f792a:	e9 f0 58 00 00       	jmp    6fd21f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61df>
  6f792f:	31 db                	xor    %ebx,%ebx
  6f7931:	41 80 bf 90 00 00 00 	cmpb   $0x4,0x90(%r15)
  6f7938:	04 
  6f7939:	74 ea                	je     6f7925 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x8e5>
  6f793b:	48 85 db             	test   %rbx,%rbx
  6f793e:	0f 84 81 01 00 00    	je     6f7ac5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xa85>
  6f7944:	49 83 fc ff          	cmp    $0xffffffffffffffff,%r12
  6f7948:	0f 84 26 19 00 00    	je     6f9274 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2234>
  6f794e:	4c 89 ff             	mov    %r15,%rdi
  6f7951:	ff 15 69 42 39 00    	call   *0x394269(%rip)        # a8bbc0 <_DYNAMIC+0x6a8>
  6f7957:	48 85 c0             	test   %rax,%rax
  6f795a:	0f 84 14 19 00 00    	je     6f9274 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2234>
  6f7960:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
  6f7967:	00 
  6f7968:	48 85 c9             	test   %rcx,%rcx
  6f796b:	0f 84 81 00 00 00    	je     6f79f2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x9b2>
  6f7971:	48 8b 94 24 58 01 00 	mov    0x158(%rsp),%rdx
  6f7978:	00 
  6f7979:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6f7980:	89 f7                	mov    %esi,%edi
  6f7982:	c1 e7 03             	shl    $0x3,%edi
  6f7985:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
  6f798c:	0f 1f 40 00          	nopl   0x0(%rax)
  6f7990:	48 85 ff             	test   %rdi,%rdi
  6f7993:	74 27                	je     6f79bc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x97c>
  6f7995:	4a 3b 9c e9 70 01 00 	cmp    0x170(%rcx,%r13,8),%rbx
  6f799c:	00 
  6f799d:	41 0f 97 c0          	seta   %r8b
  6f79a1:	41 80 d8 00          	sbb    $0x0,%r8b
  6f79a5:	49 ff c5             	inc    %r13
  6f79a8:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  6f79ac:	41 80 f8 01          	cmp    $0x1,%r8b
  6f79b0:	74 de                	je     6f7990 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x950>
  6f79b2:	41 0f b6 f0          	movzbl %r8b,%esi
  6f79b6:	85 f6                	test   %esi,%esi
  6f79b8:	75 05                	jne    6f79bf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x97f>
  6f79ba:	eb 17                	jmp    6f79d3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x993>
  6f79bc:	49 89 f5             	mov    %rsi,%r13
  6f79bf:	48 83 ea 01          	sub    $0x1,%rdx
  6f79c3:	0f 82 4e 01 00 00    	jb     6f7b17 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xad7>
  6f79c9:	4a 8b 8c e9 c8 01 00 	mov    0x1c8(%rcx,%r13,8),%rcx
  6f79d0:	00 
  6f79d1:	eb a6                	jmp    6f7979 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x939>
  6f79d3:	4c 89 ee             	mov    %r13,%rsi
  6f79d6:	4c 8d ac 24 50 01 00 	lea    0x150(%rsp),%r13
  6f79dd:	00 
  6f79de:	48 89 f7             	mov    %rsi,%rdi
  6f79e1:	48 c1 e7 05          	shl    $0x5,%rdi
  6f79e5:	48 01 cf             	add    %rcx,%rdi
  6f79e8:	48 89 74 24 58       	mov    %rsi,0x58(%rsp)
  6f79ed:	e9 94 00 00 00       	jmp    6f7a86 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xa46>
  6f79f2:	31 d2                	xor    %edx,%edx
  6f79f4:	48 89 9c 24 80 00 00 	mov    %rbx,0x80(%rsp)
  6f79fb:	00 
  6f79fc:	48 8d 8c 24 50 01 00 	lea    0x150(%rsp),%rcx
  6f7a03:	00 
  6f7a04:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
  6f7a0b:	00 
  6f7a0c:	48 89 94 24 90 00 00 	mov    %rdx,0x90(%rsp)
  6f7a13:	00 
  6f7a14:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
  6f7a19:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  6f7a20:	00 
  6f7a21:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
  6f7a28:	00 
  6f7a29:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
  6f7a30:	00 
  6f7a31:	48 c7 84 24 d0 02 00 	movq   $0x0,0x2d0(%rsp)
  6f7a38:	00 00 00 00 00 
  6f7a3d:	48 c7 84 24 d8 02 00 	movq   $0x4,0x2d8(%rsp)
  6f7a44:	00 04 00 00 00 
  6f7a49:	48 c7 84 24 e0 02 00 	movq   $0x0,0x2e0(%rsp)
  6f7a50:	00 00 00 00 00 
  6f7a55:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f7a5c:	00 
  6f7a5d:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6f7a64:	00 
  6f7a65:	48 8d 94 24 d0 02 00 	lea    0x2d0(%rsp),%rdx
  6f7a6c:	00 
  6f7a6d:	e8 ee 9d 01 00       	call   711860 <<alloc::collections::btree::map::entry::VacantEntry<gpui::source::FieldId, gpui::runtime::Fanout>>::insert_entry>
  6f7a72:	48 8b bc 24 20 07 00 	mov    0x720(%rsp),%rdi
  6f7a79:	00 
  6f7a7a:	48 c1 e7 05          	shl    $0x5,%rdi
  6f7a7e:	48 03 bc 24 10 07 00 	add    0x710(%rsp),%rdi
  6f7a85:	00 
  6f7a86:	ff 15 3c 41 39 00    	call   *0x39413c(%rip)        # a8bbc8 <_DYNAMIC+0x6b0>
  6f7a8c:	49 89 c4             	mov    %rax,%r12
  6f7a8f:	48 8b bc 24 f0 01 00 	mov    0x1f0(%rsp),%rdi
  6f7a96:	00 
  6f7a97:	31 f6                	xor    %esi,%esi
  6f7a99:	ff 15 31 41 39 00    	call   *0x394131(%rip)        # a8bbd0 <_DYNAMIC+0x6b8>
  6f7a9f:	89 c5                	mov    %eax,%ebp
  6f7aa1:	4d 8b 74 24 10       	mov    0x10(%r12),%r14
  6f7aa6:	4d 3b 34 24          	cmp    (%r12),%r14
  6f7aaa:	75 08                	jne    6f7ab4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xa74>
  6f7aac:	4c 89 e7             	mov    %r12,%rdi
  6f7aaf:	e8 6c 94 02 00       	call   720f20 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  6f7ab4:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  6f7ab9:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
  6f7abd:	49 ff c6             	inc    %r14
  6f7ac0:	4d 89 74 24 10       	mov    %r14,0x10(%r12)
  6f7ac5:	4c 8b b4 24 48 02 00 	mov    0x248(%rsp),%r14
  6f7acc:	00 
  6f7acd:	4c 3b b4 24 38 02 00 	cmp    0x238(%rsp),%r14
  6f7ad4:	00 
  6f7ad5:	75 0d                	jne    6f7ae4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xaa4>
  6f7ad7:	48 8d bc 24 38 02 00 	lea    0x238(%rsp),%rdi
  6f7ade:	00 
  6f7adf:	e8 4c 90 02 00       	call   720b30 <<alloc::raw_vec::RawVec<core::option::Option<gpui::source::FieldId>>>::grow_one>
  6f7ae4:	49 81 c7 98 00 00 00 	add    $0x98,%r15
  6f7aeb:	48 ff 84 24 f0 01 00 	incq   0x1f0(%rsp)
  6f7af2:	00 
  6f7af3:	48 8b 84 24 40 02 00 	mov    0x240(%rsp),%rax
  6f7afa:	00 
  6f7afb:	4a 89 1c f0          	mov    %rbx,(%rax,%r14,8)
  6f7aff:	49 ff c6             	inc    %r14
  6f7b02:	4c 89 b4 24 48 02 00 	mov    %r14,0x248(%rsp)
  6f7b09:	00 
  6f7b0a:	4c 3b 7c 24 50       	cmp    0x50(%rsp),%r15
  6f7b0f:	0f 85 a0 fb ff ff    	jne    6f76b5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x675>
  6f7b15:	eb 34                	jmp    6f7b4b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xb0b>
  6f7b17:	48 89 ca             	mov    %rcx,%rdx
  6f7b1a:	48 8d 8c 24 50 01 00 	lea    0x150(%rsp),%rcx
  6f7b21:	00 
  6f7b22:	be 00 00 00 00       	mov    $0x0,%esi
  6f7b27:	bf 00 00 00 00       	mov    $0x0,%edi
  6f7b2c:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
  6f7b31:	48 85 db             	test   %rbx,%rbx
  6f7b34:	0f 85 ba fe ff ff    	jne    6f79f4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x9b4>
  6f7b3a:	e9 9f fe ff ff       	jmp    6f79de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x99e>
  6f7b3f:	48 c7 84 24 30 01 00 	movq   $0x0,0x130(%rsp)
  6f7b46:	00 00 00 00 00 
  6f7b4b:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  6f7b50:	48 89 ca             	mov    %rcx,%rdx
  6f7b53:	48 c1 e2 04          	shl    $0x4,%rdx
  6f7b57:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  6f7b5e:	00 
  6f7b5f:	48 89 94 24 40 08 00 	mov    %rdx,0x840(%rsp)
  6f7b66:	00 
  6f7b67:	48 01 d0             	add    %rdx,%rax
  6f7b6a:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
  6f7b71:	00 
  6f7b72:	48 85 c9             	test   %rcx,%rcx
  6f7b75:	74 4a                	je     6f7bc1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xb81>
  6f7b77:	4c 8b 3d a2 3d 39 00 	mov    0x393da2(%rip),%r15        # a8b920 <_DYNAMIC+0x408>
  6f7b7e:	48 8d 9c 24 80 00 00 	lea    0x80(%rsp),%rbx
  6f7b85:	00 
  6f7b86:	4c 8b a4 24 48 01 00 	mov    0x148(%rsp),%r12
  6f7b8d:	00 
  6f7b8e:	66 90                	xchg   %ax,%ax
  6f7b90:	4d 8b 34 24          	mov    (%r12),%r14
  6f7b94:	66 41 0f 6e 44 24 08 	movd   0x8(%r12),%xmm0
  6f7b9b:	66 0f 7e 84 24 80 00 	movd   %xmm0,0x80(%rsp)
  6f7ba2:	00 00 
  6f7ba4:	48 89 df             	mov    %rbx,%rdi
  6f7ba7:	41 ff 57 10          	call   *0x10(%r15)
  6f7bab:	3c ff                	cmp    $0xff,%al
  6f7bad:	0f 85 80 08 00 00    	jne    6f8433 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x13f3>
  6f7bb3:	49 83 c4 10          	add    $0x10,%r12
  6f7bb7:	4c 3b a4 24 f0 01 00 	cmp    0x1f0(%rsp),%r12
  6f7bbe:	00 
  6f7bbf:	75 cf                	jne    6f7b90 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xb50>
  6f7bc1:	48 c7 84 24 e0 07 00 	movq   $0x0,0x7e0(%rsp)
  6f7bc8:	00 00 00 00 00 
  6f7bcd:	48 c7 84 24 e8 07 00 	movq   $0x8,0x7e8(%rsp)
  6f7bd4:	00 08 00 00 00 
  6f7bd9:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6f7bdd:	f3 0f 7f 84 24 f0 07 	movdqu %xmm0,0x7f0(%rsp)
  6f7be4:	00 00 
  6f7be6:	48 c7 84 24 00 08 00 	movq   $0x4,0x800(%rsp)
  6f7bed:	00 04 00 00 00 
  6f7bf2:	48 c7 84 24 38 08 00 	movq   $0x0,0x838(%rsp)
  6f7bf9:	00 00 00 00 00 
  6f7bfe:	f3 0f 7f 84 24 08 08 	movdqu %xmm0,0x808(%rsp)
  6f7c05:	00 00 
  6f7c07:	48 c7 84 24 18 08 00 	movq   $0x4,0x818(%rsp)
  6f7c0e:	00 04 00 00 00 
  6f7c13:	f3 0f 7f 84 24 20 08 	movdqu %xmm0,0x820(%rsp)
  6f7c1a:	00 00 
  6f7c1c:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  6f7c21:	48 85 c0             	test   %rax,%rax
  6f7c24:	0f 84 df 02 00 00    	je     6f7f09 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xec9>
  6f7c2a:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  6f7c2e:	4c 8b ac 24 28 02 00 	mov    0x228(%rsp),%r13
  6f7c35:	00 
  6f7c36:	48 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%rax
  6f7c3d:	00 
  6f7c3e:	4c 01 e8             	add    %r13,%rax
  6f7c41:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6f7c46:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f7c4b:	48 05 28 02 00 00    	add    $0x228,%rax
  6f7c51:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f7c56:	48 8b 84 24 28 04 00 	mov    0x428(%rsp),%rax
  6f7c5d:	00 
  6f7c5e:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  6f7c63:	48 8b 84 24 30 04 00 	mov    0x430(%rsp),%rax
  6f7c6a:	00 
  6f7c6b:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  6f7c70:	eb 1e                	jmp    6f7c90 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xc50>
  6f7c72:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6f7c76:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
  6f7c7a:	49 ff c6             	inc    %r14
  6f7c7d:	4c 89 73 10          	mov    %r14,0x10(%rbx)
  6f7c81:	49 83 c5 18          	add    $0x18,%r13
  6f7c85:	4c 3b 6c 24 50       	cmp    0x50(%rsp),%r13
  6f7c8a:	0f 84 79 02 00 00    	je     6f7f09 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xec9>
  6f7c90:	41 0f b7 6d 14       	movzwl 0x14(%r13),%ebp
  6f7c95:	66 85 ed             	test   %bp,%bp
  6f7c98:	0f 84 6b 02 00 00    	je     6f7f09 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xec9>
  6f7c9e:	49 8b 5d 00          	mov    0x0(%r13),%rbx
  6f7ca2:	4d 8b 75 08          	mov    0x8(%r13),%r14
  6f7ca6:	41 8b 45 10          	mov    0x10(%r13),%eax
  6f7caa:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6f7caf:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  6f7cb6:	00 
  6f7cb7:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  6f7cbc:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f7cc1:	48 89 d9             	mov    %rbx,%rcx
  6f7cc4:	4d 89 f0             	mov    %r14,%r8
  6f7cc7:	e8 b4 96 02 00       	call   721380 <<gpui::source::Sources<route_columns_cost::Page>>::resolve>
  6f7ccc:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  6f7cd3:	00 
  6f7cd4:	4c 8b bc 24 88 00 00 	mov    0x88(%rsp),%r15
  6f7cdb:	00 
  6f7cdc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f7ce0:	0f 85 a8 13 00 00    	jne    6f908e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x204e>
  6f7ce6:	4d 85 ff             	test   %r15,%r15
  6f7ce9:	74 96                	je     6f7c81 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xc41>
  6f7ceb:	89 e8                	mov    %ebp,%eax
  6f7ced:	25 fe ff 00 00       	and    $0xfffe,%eax
  6f7cf2:	66 83 f8 06          	cmp    $0x6,%ax
  6f7cf6:	75 5d                	jne    6f7d55 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd15>
  6f7cf8:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  6f7cfd:	48 39 7c 24 58       	cmp    %rdi,0x58(%rsp)
  6f7d02:	0f 86 ce 5d 00 00    	jbe    6fdad6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a96>
  6f7d08:	48 69 c7 98 00 00 00 	imul   $0x98,%rdi,%rax
  6f7d0f:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  6f7d14:	f3 0f 6f 44 01 3c    	movdqu 0x3c(%rcx,%rax,1),%xmm0
  6f7d1a:	66 0f 7f 84 24 b0 08 	movdqa %xmm0,0x8b0(%rsp)
  6f7d21:	00 00 
  6f7d23:	66 83 fd 06          	cmp    $0x6,%bp
  6f7d27:	74 13                	je     6f7d3c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xcfc>
  6f7d29:	48 03 44 24 48       	add    0x48(%rsp),%rax
  6f7d2e:	f3 0f 6f 40 4c       	movdqu 0x4c(%rax),%xmm0
  6f7d33:	66 0f 7f 84 24 b0 08 	movdqa %xmm0,0x8b0(%rsp)
  6f7d3a:	00 00 
  6f7d3c:	48 8d bc 24 e0 07 00 	lea    0x7e0(%rsp),%rdi
  6f7d43:	00 
  6f7d44:	4c 89 fe             	mov    %r15,%rsi
  6f7d47:	48 8d 94 24 b0 08 00 	lea    0x8b0(%rsp),%rdx
  6f7d4e:	00 
  6f7d4f:	ff 15 83 3e 39 00    	call   *0x393e83(%rip)        # a8bbd8 <_DYNAMIC+0x6c0>
  6f7d55:	48 8b bc 24 50 01 00 	mov    0x150(%rsp),%rdi
  6f7d5c:	00 
  6f7d5d:	48 85 ff             	test   %rdi,%rdi
  6f7d60:	74 7d                	je     6f7ddf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd9f>
  6f7d62:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  6f7d69:	00 
  6f7d6a:	0f b7 8f c2 01 00 00 	movzwl 0x1c2(%rdi),%ecx
  6f7d71:	89 ce                	mov    %ecx,%esi
  6f7d73:	c1 e6 05             	shl    $0x5,%esi
  6f7d76:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
  6f7d7d:	31 d2                	xor    %edx,%edx
  6f7d7f:	90                   	nop
  6f7d80:	49 89 f0             	mov    %rsi,%r8
  6f7d83:	49 01 d0             	add    %rdx,%r8
  6f7d86:	74 27                	je     6f7daf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd6f>
  6f7d88:	4e 3b bc e7 70 01 00 	cmp    0x170(%rdi,%r12,8),%r15
  6f7d8f:	00 
  6f7d90:	41 0f 97 c0          	seta   %r8b
  6f7d94:	41 80 d8 00          	sbb    $0x0,%r8b
  6f7d98:	48 83 c2 e0          	add    $0xffffffffffffffe0,%rdx
  6f7d9c:	49 ff c4             	inc    %r12
  6f7d9f:	41 80 f8 01          	cmp    $0x1,%r8b
  6f7da3:	74 db                	je     6f7d80 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd40>
  6f7da5:	41 0f b6 c8          	movzbl %r8b,%ecx
  6f7da9:	85 c9                	test   %ecx,%ecx
  6f7dab:	75 05                	jne    6f7db2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd72>
  6f7dad:	eb 17                	jmp    6f7dc6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd86>
  6f7daf:	49 89 cc             	mov    %rcx,%r12
  6f7db2:	48 83 e8 01          	sub    $0x1,%rax
  6f7db6:	0f 82 f0 00 00 00    	jb     6f7eac <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xe6c>
  6f7dbc:	4a 8b bc e7 c8 01 00 	mov    0x1c8(%rdi,%r12,8),%rdi
  6f7dc3:	00 
  6f7dc4:	eb a4                	jmp    6f7d6a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xd2a>
  6f7dc6:	48 29 d7             	sub    %rdx,%rdi
  6f7dc9:	48 83 c7 e0          	add    $0xffffffffffffffe0,%rdi
  6f7dcd:	48 8d 84 24 50 01 00 	lea    0x150(%rsp),%rax
  6f7dd4:	00 
  6f7dd5:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  6f7dda:	e9 9b 00 00 00       	jmp    6f7e7a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xe3a>
  6f7ddf:	31 ff                	xor    %edi,%edi
  6f7de1:	4c 89 bc 24 80 00 00 	mov    %r15,0x80(%rsp)
  6f7de8:	00 
  6f7de9:	48 8d 84 24 50 01 00 	lea    0x150(%rsp),%rax
  6f7df0:	00 
  6f7df1:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  6f7df8:	00 
  6f7df9:	48 89 bc 24 90 00 00 	mov    %rdi,0x90(%rsp)
  6f7e00:	00 
  6f7e01:	4c 89 a4 24 98 00 00 	mov    %r12,0x98(%rsp)
  6f7e08:	00 
  6f7e09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6f7e0e:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6f7e15:	00 
  6f7e16:	48 89 df             	mov    %rbx,%rdi
  6f7e19:	41 ff 56 30          	call   *0x30(%r14)
  6f7e1d:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
  6f7e24:	00 
  6f7e25:	48 c7 84 24 d0 02 00 	movq   $0x0,0x2d0(%rsp)
  6f7e2c:	00 00 00 00 00 
  6f7e31:	48 c7 84 24 d8 02 00 	movq   $0x4,0x2d8(%rsp)
  6f7e38:	00 04 00 00 00 
  6f7e3d:	48 c7 84 24 e0 02 00 	movq   $0x0,0x2e0(%rsp)
  6f7e44:	00 00 00 00 00 
  6f7e49:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f7e50:	00 
  6f7e51:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6f7e58:	00 
  6f7e59:	48 8d 94 24 d0 02 00 	lea    0x2d0(%rsp),%rdx
  6f7e60:	00 
  6f7e61:	e8 fa 99 01 00       	call   711860 <<alloc::collections::btree::map::entry::VacantEntry<gpui::source::FieldId, gpui::runtime::Fanout>>::insert_entry>
  6f7e66:	48 8b bc 24 20 07 00 	mov    0x720(%rsp),%rdi
  6f7e6d:	00 
  6f7e6e:	48 c1 e7 05          	shl    $0x5,%rdi
  6f7e72:	48 03 bc 24 10 07 00 	add    0x710(%rsp),%rdi
  6f7e79:	00 
  6f7e7a:	ff 15 48 3d 39 00    	call   *0x393d48(%rip)        # a8bbc8 <_DYNAMIC+0x6b0>
  6f7e80:	48 89 c3             	mov    %rax,%rbx
  6f7e83:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  6f7e88:	89 ee                	mov    %ebp,%esi
  6f7e8a:	ff 15 50 3d 39 00    	call   *0x393d50(%rip)        # a8bbe0 <_DYNAMIC+0x6c8>
  6f7e90:	89 c5                	mov    %eax,%ebp
  6f7e92:	4c 8b 73 10          	mov    0x10(%rbx),%r14
  6f7e96:	4c 3b 33             	cmp    (%rbx),%r14
  6f7e99:	0f 85 d3 fd ff ff    	jne    6f7c72 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xc32>
  6f7e9f:	48 89 df             	mov    %rbx,%rdi
  6f7ea2:	e8 79 90 02 00       	call   720f20 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  6f7ea7:	e9 c6 fd ff ff       	jmp    6f7c72 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xc32>
  6f7eac:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
  6f7eb1:	45 31 e4             	xor    %r12d,%r12d
  6f7eb4:	e9 28 ff ff ff       	jmp    6f7de1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xda1>
  6f7eb9:	0f 10 84 24 88 00 00 	movups 0x88(%rsp),%xmm0
  6f7ec0:	00 
  6f7ec1:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6f7ec6:	48 c7 01 20 00 00 00 	movq   $0x20,(%rcx)
  6f7ecd:	48 89 41 08          	mov    %rax,0x8(%rcx)
  6f7ed1:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
  6f7ed5:	e9 5d 53 00 00       	jmp    6fd237 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61f7>
  6f7eda:	8b 8c 24 94 00 00 00 	mov    0x94(%rsp),%ecx
  6f7ee1:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  6f7ee6:	89 4a 1c             	mov    %ecx,0x1c(%rdx)
  6f7ee9:	48 8b 8c 24 8c 00 00 	mov    0x8c(%rsp),%rcx
  6f7ef0:	00 
  6f7ef1:	48 89 4a 14          	mov    %rcx,0x14(%rdx)
  6f7ef5:	48 c7 02 20 00 00 00 	movq   $0x20,(%rdx)
  6f7efc:	48 89 42 08          	mov    %rax,0x8(%rdx)
  6f7f00:	44 89 72 10          	mov    %r14d,0x10(%rdx)
  6f7f04:	e9 2e 53 00 00       	jmp    6fd237 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61f7>
  6f7f09:	48 8b 84 24 f8 01 00 	mov    0x1f8(%rsp),%rax
  6f7f10:	00 
  6f7f11:	48 85 c0             	test   %rax,%rax
  6f7f14:	74 1f                	je     6f7f35 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xef5>
  6f7f16:	48 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%rax
  6f7f1d:	00 
  6f7f1e:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6f7f22:	ba 08 00 00 00       	mov    $0x8,%edx
  6f7f27:	48 8b bc 24 28 02 00 	mov    0x228(%rsp),%rdi
  6f7f2e:	00 
  6f7f2f:	ff 15 33 38 39 00    	call   *0x393833(%rip)        # a8b768 <_DYNAMIC+0x250>
  6f7f35:	4c 8b bc 24 e0 04 00 	mov    0x4e0(%rsp),%r15
  6f7f3c:	00 
  6f7f3d:	4d 85 ff             	test   %r15,%r15
  6f7f40:	0f 84 1f 05 00 00    	je     6f8465 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1425>
  6f7f46:	4c 89 fb             	mov    %r15,%rbx
  6f7f49:	48 c1 e3 04          	shl    $0x4,%rbx
  6f7f4d:	ff 15 05 38 39 00    	call   *0x393805(%rip)        # a8b758 <_DYNAMIC+0x240>
  6f7f53:	be 08 00 00 00       	mov    $0x8,%esi
  6f7f58:	48 89 df             	mov    %rbx,%rdi
  6f7f5b:	ff 15 ff 37 39 00    	call   *0x3937ff(%rip)        # a8b760 <_DYNAMIC+0x248>
  6f7f61:	48 85 c0             	test   %rax,%rax
  6f7f64:	0f 84 74 5c 00 00    	je     6fdbde <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b9e>
  6f7f6a:	4c 89 bc 24 68 02 00 	mov    %r15,0x268(%rsp)
  6f7f71:	00 
  6f7f72:	48 89 84 24 70 02 00 	mov    %rax,0x270(%rsp)
  6f7f79:	00 
  6f7f7a:	48 c7 84 24 78 02 00 	movq   $0x0,0x278(%rsp)
  6f7f81:	00 00 00 00 00 
  6f7f86:	4c 8b b4 24 d8 04 00 	mov    0x4d8(%rsp),%r14
  6f7f8d:	00 
  6f7f8e:	49 6b c7 38          	imul   $0x38,%r15,%rax
  6f7f92:	4c 01 f0             	add    %r14,%rax
  6f7f95:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6f7f9a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f7f9f:	48 05 28 02 00 00    	add    $0x228,%rax
  6f7fa5:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  6f7faa:	48 b8 01 00 00 00 00 	movabs $0x8000000000000001,%rax
  6f7fb1:	00 00 80 
  6f7fb4:	48 ff c0             	inc    %rax
  6f7fb7:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f7fbc:	eb 44                	jmp    6f8002 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xfc2>
  6f7fbe:	48 8d bc 24 68 02 00 	lea    0x268(%rsp),%rdi
  6f7fc5:	00 
  6f7fc6:	e8 85 8a 02 00       	call   720a50 <<alloc::raw_vec::RawVec<[core::option::Option<gpui::source::FieldId>; 2]>>::grow_one>
  6f7fcb:	49 83 c6 38          	add    $0x38,%r14
  6f7fcf:	48 8b 84 24 70 02 00 	mov    0x270(%rsp),%rax
  6f7fd6:	00 
  6f7fd7:	48 89 d9             	mov    %rbx,%rcx
  6f7fda:	48 c1 e1 04          	shl    $0x4,%rcx
  6f7fde:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  6f7fe3:	48 89 14 08          	mov    %rdx,(%rax,%rcx,1)
  6f7fe7:	4c 89 64 08 08       	mov    %r12,0x8(%rax,%rcx,1)
  6f7fec:	48 ff c3             	inc    %rbx
  6f7fef:	48 89 9c 24 78 02 00 	mov    %rbx,0x278(%rsp)
  6f7ff6:	00 
  6f7ff7:	4c 3b 74 24 50       	cmp    0x50(%rsp),%r14
  6f7ffc:	0f 84 87 04 00 00    	je     6f8489 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1449>
  6f8002:	49 8b 06             	mov    (%r14),%rax
  6f8005:	4d 8b 7e 18          	mov    0x18(%r14),%r15
  6f8009:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f800d:	0f 84 ed 00 00 00    	je     6f8100 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x10c0>
  6f8013:	48 3b 44 24 60       	cmp    0x60(%rsp),%rax
  6f8018:	0f 85 e2 00 00 00    	jne    6f8100 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x10c0>
  6f801e:	49 8b 4e 08          	mov    0x8(%r14),%rcx
  6f8022:	4d 8b 46 10          	mov    0x10(%r14),%r8
  6f8026:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  6f802d:	00 
  6f802e:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  6f8033:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f8038:	e8 43 93 02 00       	call   721380 <<gpui::source::Sources<route_columns_cost::Page>>::resolve>
  6f803d:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  6f8044:	00 
  6f8045:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f8049:	0f 85 02 12 00 00    	jne    6f9251 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2211>
  6f804f:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
  6f8056:	00 
  6f8057:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  6f805c:	48 85 c9             	test   %rcx,%rcx
  6f805f:	0f 84 9b 00 00 00    	je     6f8100 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x10c0>
  6f8065:	4c 89 f7             	mov    %r14,%rdi
  6f8068:	ff 15 52 3b 39 00    	call   *0x393b52(%rip)        # a8bbc0 <_DYNAMIC+0x6a8>
  6f806e:	48 85 c0             	test   %rax,%rax
  6f8071:	0f 84 eb 3c 00 00    	je     6fbd62 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d22>
  6f8077:	48 8b bc 24 50 01 00 	mov    0x150(%rsp),%rdi
  6f807e:	00 
  6f807f:	48 85 ff             	test   %rdi,%rdi
  6f8082:	0f 84 a0 01 00 00    	je     6f8228 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x11e8>
  6f8088:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
  6f808f:	00 
  6f8090:	0f b7 97 c2 01 00 00 	movzwl 0x1c2(%rdi),%edx
  6f8097:	41 89 d0             	mov    %edx,%r8d
  6f809a:	41 c1 e0 05          	shl    $0x5,%r8d
  6f809e:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
  6f80a5:	31 f6                	xor    %esi,%esi
  6f80a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f80ae:	00 00 
  6f80b0:	4d 89 c1             	mov    %r8,%r9
  6f80b3:	49 01 f1             	add    %rsi,%r9
  6f80b6:	74 2f                	je     6f80e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x10a7>
  6f80b8:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
  6f80bd:	4e 3b 8c ef 70 01 00 	cmp    0x170(%rdi,%r13,8),%r9
  6f80c4:	00 
  6f80c5:	41 0f 97 c1          	seta   %r9b
  6f80c9:	41 80 d9 00          	sbb    $0x0,%r9b
  6f80cd:	48 83 c6 e0          	add    $0xffffffffffffffe0,%rsi
  6f80d1:	49 ff c5             	inc    %r13
  6f80d4:	41 80 f9 01          	cmp    $0x1,%r9b
  6f80d8:	74 d6                	je     6f80b0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1070>
  6f80da:	41 0f b6 d1          	movzbl %r9b,%edx
  6f80de:	85 d2                	test   %edx,%edx
  6f80e0:	75 08                	jne    6f80ea <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x10aa>
  6f80e2:	e9 0f 01 00 00       	jmp    6f81f6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x11b6>
  6f80e7:	49 89 d5             	mov    %rdx,%r13
  6f80ea:	48 83 e9 01          	sub    $0x1,%rcx
  6f80ee:	0f 82 23 03 00 00    	jb     6f8417 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x13d7>
  6f80f4:	4a 8b bc ef c8 01 00 	mov    0x1c8(%rdi,%r13,8),%rdi
  6f80fb:	00 
  6f80fc:	eb 92                	jmp    6f8090 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1050>
  6f80fe:	66 90                	xchg   %ax,%ax
  6f8100:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  6f8107:	00 00 
  6f8109:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
  6f810d:	0f 84 fd 01 00 00    	je     6f8310 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x12d0>
  6f8113:	49 8d 5e 18          	lea    0x18(%r14),%rbx
  6f8117:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  6f811c:	48 39 03             	cmp    %rax,(%rbx)
  6f811f:	0f 85 eb 01 00 00    	jne    6f8310 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x12d0>
  6f8125:	49 8b 4e 20          	mov    0x20(%r14),%rcx
  6f8129:	4d 8b 46 28          	mov    0x28(%r14),%r8
  6f812d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  6f8134:	00 
  6f8135:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  6f813a:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f813f:	e8 3c 92 02 00       	call   721380 <<gpui::source::Sources<route_columns_cost::Page>>::resolve>
  6f8144:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  6f814b:	00 
  6f814c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f8150:	0f 85 fb 10 00 00    	jne    6f9251 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2211>
  6f8156:	4c 8b a4 24 88 00 00 	mov    0x88(%rsp),%r12
  6f815d:	00 
  6f815e:	4d 85 e4             	test   %r12,%r12
  6f8161:	0f 84 a9 01 00 00    	je     6f8310 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x12d0>
  6f8167:	48 89 df             	mov    %rbx,%rdi
  6f816a:	ff 15 50 3a 39 00    	call   *0x393a50(%rip)        # a8bbc0 <_DYNAMIC+0x6a8>
  6f8170:	48 85 c0             	test   %rax,%rax
  6f8173:	0f 84 ee 3b 00 00    	je     6fbd67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d27>
  6f8179:	48 8b bc 24 50 01 00 	mov    0x150(%rsp),%rdi
  6f8180:	00 
  6f8181:	48 85 ff             	test   %rdi,%rdi
  6f8184:	0f 84 a4 01 00 00    	je     6f832e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x12ee>
  6f818a:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
  6f8191:	00 
  6f8192:	0f b7 97 c2 01 00 00 	movzwl 0x1c2(%rdi),%edx
  6f8199:	41 89 d0             	mov    %edx,%r8d
  6f819c:	41 c1 e0 05          	shl    $0x5,%r8d
  6f81a0:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
  6f81a7:	31 f6                	xor    %esi,%esi
  6f81a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6f81b0:	4d 89 c1             	mov    %r8,%r9
  6f81b3:	49 01 f1             	add    %rsi,%r9
  6f81b6:	74 27                	je     6f81df <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x119f>
  6f81b8:	4e 3b a4 ef 70 01 00 	cmp    0x170(%rdi,%r13,8),%r12
  6f81bf:	00 
  6f81c0:	41 0f 97 c1          	seta   %r9b
  6f81c4:	41 80 d9 00          	sbb    $0x0,%r9b
  6f81c8:	48 83 c6 e0          	add    $0xffffffffffffffe0,%rsi
  6f81cc:	49 ff c5             	inc    %r13
  6f81cf:	41 80 f9 01          	cmp    $0x1,%r9b
  6f81d3:	74 db                	je     6f81b0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1170>
  6f81d5:	41 0f b6 d1          	movzbl %r9b,%edx
  6f81d9:	85 d2                	test   %edx,%edx
  6f81db:	75 05                	jne    6f81e2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x11a2>
  6f81dd:	eb 30                	jmp    6f820f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x11cf>
  6f81df:	49 89 d5             	mov    %rdx,%r13
  6f81e2:	48 83 e9 01          	sub    $0x1,%rcx
  6f81e6:	0f 82 39 02 00 00    	jb     6f8425 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x13e5>
  6f81ec:	4a 8b bc ef c8 01 00 	mov    0x1c8(%rdi,%r13,8),%rdi
  6f81f3:	00 
  6f81f4:	eb 9c                	jmp    6f8192 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1152>
  6f81f6:	48 29 f7             	sub    %rsi,%rdi
  6f81f9:	48 83 c7 e0          	add    $0xffffffffffffffe0,%rdi
  6f81fd:	4c 89 6c 24 48       	mov    %r13,0x48(%rsp)
  6f8202:	4c 8d ac 24 50 01 00 	lea    0x150(%rsp),%r13
  6f8209:	00 
  6f820a:	e9 b2 00 00 00       	jmp    6f82c1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1281>
  6f820f:	48 29 f7             	sub    %rsi,%rdi
  6f8212:	48 83 c7 e0          	add    $0xffffffffffffffe0,%rdi
  6f8216:	4c 89 6c 24 48       	mov    %r13,0x48(%rsp)
  6f821b:	4c 8d ac 24 50 01 00 	lea    0x150(%rsp),%r13
  6f8222:	00 
  6f8223:	e9 9a 01 00 00       	jmp    6f83c2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1382>
  6f8228:	31 ff                	xor    %edi,%edi
  6f822a:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  6f822f:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  6f8236:	00 
  6f8237:	48 8d 8c 24 50 01 00 	lea    0x150(%rsp),%rcx
  6f823e:	00 
  6f823f:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
  6f8246:	00 
  6f8247:	48 89 bc 24 90 00 00 	mov    %rdi,0x90(%rsp)
  6f824e:	00 
  6f824f:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  6f8254:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  6f825b:	00 
  6f825c:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
  6f8263:	00 
  6f8264:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
  6f826b:	00 
  6f826c:	48 c7 84 24 d0 02 00 	movq   $0x0,0x2d0(%rsp)
  6f8273:	00 00 00 00 00 
  6f8278:	48 c7 84 24 d8 02 00 	movq   $0x4,0x2d8(%rsp)
  6f827f:	00 04 00 00 00 
  6f8284:	48 c7 84 24 e0 02 00 	movq   $0x0,0x2e0(%rsp)
  6f828b:	00 00 00 00 00 
  6f8290:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f8297:	00 
  6f8298:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6f829f:	00 
  6f82a0:	48 8d 94 24 d0 02 00 	lea    0x2d0(%rsp),%rdx
  6f82a7:	00 
  6f82a8:	e8 b3 95 01 00       	call   711860 <<alloc::collections::btree::map::entry::VacantEntry<gpui::source::FieldId, gpui::runtime::Fanout>>::insert_entry>
  6f82ad:	48 8b bc 24 20 07 00 	mov    0x720(%rsp),%rdi
  6f82b4:	00 
  6f82b5:	48 c1 e7 05          	shl    $0x5,%rdi
  6f82b9:	48 03 bc 24 10 07 00 	add    0x710(%rsp),%rdi
  6f82c0:	00 
  6f82c1:	ff 15 01 39 39 00    	call   *0x393901(%rip)        # a8bbc8 <_DYNAMIC+0x6b0>
  6f82c7:	48 89 c3             	mov    %rax,%rbx
  6f82ca:	41 8b 7e 30          	mov    0x30(%r14),%edi
  6f82ce:	be 01 00 00 00       	mov    $0x1,%esi
  6f82d3:	ff 15 f7 38 39 00    	call   *0x3938f7(%rip)        # a8bbd0 <_DYNAMIC+0x6b8>
  6f82d9:	89 c5                	mov    %eax,%ebp
  6f82db:	4c 8b 63 10          	mov    0x10(%rbx),%r12
  6f82df:	4c 3b 23             	cmp    (%rbx),%r12
  6f82e2:	75 08                	jne    6f82ec <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x12ac>
  6f82e4:	48 89 df             	mov    %rbx,%rdi
  6f82e7:	e8 34 8c 02 00       	call   720f20 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  6f82ec:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6f82f0:	42 89 2c a0          	mov    %ebp,(%rax,%r12,4)
  6f82f4:	49 ff c4             	inc    %r12
  6f82f7:	4c 89 63 10          	mov    %r12,0x10(%rbx)
  6f82fb:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
  6f82ff:	0f 85 0e fe ff ff    	jne    6f8113 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x10d3>
  6f8305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6f830c:	00 00 00 00 
  6f8310:	45 31 e4             	xor    %r12d,%r12d
  6f8313:	48 8b 9c 24 78 02 00 	mov    0x278(%rsp),%rbx
  6f831a:	00 
  6f831b:	48 3b 9c 24 68 02 00 	cmp    0x268(%rsp),%rbx
  6f8322:	00 
  6f8323:	0f 85 a2 fc ff ff    	jne    6f7fcb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xf8b>
  6f8329:	e9 90 fc ff ff       	jmp    6f7fbe <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xf7e>
  6f832e:	31 ff                	xor    %edi,%edi
  6f8330:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
  6f8337:	00 
  6f8338:	48 8d 8c 24 50 01 00 	lea    0x150(%rsp),%rcx
  6f833f:	00 
  6f8340:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
  6f8347:	00 
  6f8348:	48 89 bc 24 90 00 00 	mov    %rdi,0x90(%rsp)
  6f834f:	00 
  6f8350:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  6f8355:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  6f835c:	00 
  6f835d:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
  6f8364:	00 
  6f8365:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
  6f836c:	00 
  6f836d:	48 c7 84 24 d0 02 00 	movq   $0x0,0x2d0(%rsp)
  6f8374:	00 00 00 00 00 
  6f8379:	48 c7 84 24 d8 02 00 	movq   $0x4,0x2d8(%rsp)
  6f8380:	00 04 00 00 00 
  6f8385:	48 c7 84 24 e0 02 00 	movq   $0x0,0x2e0(%rsp)
  6f838c:	00 00 00 00 00 
  6f8391:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f8398:	00 
  6f8399:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6f83a0:	00 
  6f83a1:	48 8d 94 24 d0 02 00 	lea    0x2d0(%rsp),%rdx
  6f83a8:	00 
  6f83a9:	e8 b2 94 01 00       	call   711860 <<alloc::collections::btree::map::entry::VacantEntry<gpui::source::FieldId, gpui::runtime::Fanout>>::insert_entry>
  6f83ae:	48 8b bc 24 20 07 00 	mov    0x720(%rsp),%rdi
  6f83b5:	00 
  6f83b6:	48 c1 e7 05          	shl    $0x5,%rdi
  6f83ba:	48 03 bc 24 10 07 00 	add    0x710(%rsp),%rdi
  6f83c1:	00 
  6f83c2:	ff 15 00 38 39 00    	call   *0x393800(%rip)        # a8bbc8 <_DYNAMIC+0x6b0>
  6f83c8:	48 89 c3             	mov    %rax,%rbx
  6f83cb:	41 8b 7e 30          	mov    0x30(%r14),%edi
  6f83cf:	be 02 00 00 00       	mov    $0x2,%esi
  6f83d4:	ff 15 f6 37 39 00    	call   *0x3937f6(%rip)        # a8bbd0 <_DYNAMIC+0x6b8>
  6f83da:	89 c5                	mov    %eax,%ebp
  6f83dc:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
  6f83e0:	4c 3b 3b             	cmp    (%rbx),%r15
  6f83e3:	75 08                	jne    6f83ed <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x13ad>
  6f83e5:	48 89 df             	mov    %rbx,%rdi
  6f83e8:	e8 33 8b 02 00       	call   720f20 <<alloc::raw_vec::RawVec<gpui::runtime::Parent>>::grow_one>
  6f83ed:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6f83f1:	42 89 2c b8          	mov    %ebp,(%rax,%r15,4)
  6f83f5:	49 ff c7             	inc    %r15
  6f83f8:	4c 89 7b 10          	mov    %r15,0x10(%rbx)
  6f83fc:	48 8b 9c 24 78 02 00 	mov    0x278(%rsp),%rbx
  6f8403:	00 
  6f8404:	48 3b 9c 24 68 02 00 	cmp    0x268(%rsp),%rbx
  6f840b:	00 
  6f840c:	0f 85 b9 fb ff ff    	jne    6f7fcb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xf8b>
  6f8412:	e9 a7 fb ff ff       	jmp    6f7fbe <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0xf7e>
  6f8417:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
  6f841e:	00 00 
  6f8420:	e9 05 fe ff ff       	jmp    6f822a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x11ea>
  6f8425:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
  6f842c:	00 00 
  6f842e:	e9 fd fe ff ff       	jmp    6f8330 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x12f0>
  6f8433:	41 0f b7 4f 30       	movzwl 0x30(%r15),%ecx
  6f8438:	25 ff ff ff 00       	and    $0xffffff,%eax
  6f843d:	89 c2                	mov    %eax,%edx
  6f843f:	c1 ea 10             	shr    $0x10,%edx
  6f8442:	48 c1 e0 10          	shl    $0x10,%rax
  6f8446:	48 09 c8             	or     %rcx,%rax
  6f8449:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6f844e:	48 c7 01 25 00 00 00 	movq   $0x25,(%rcx)
  6f8455:	4c 89 71 08          	mov    %r14,0x8(%rcx)
  6f8459:	66 89 51 14          	mov    %dx,0x14(%rcx)
  6f845d:	89 41 10             	mov    %eax,0x10(%rcx)
  6f8460:	e9 d2 4d 00 00       	jmp    6fd237 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61f7>
  6f8465:	48 c7 84 24 68 02 00 	movq   $0x0,0x268(%rsp)
  6f846c:	00 00 00 00 00 
  6f8471:	48 c7 84 24 70 02 00 	movq   $0x8,0x270(%rsp)
  6f8478:	00 08 00 00 00 
  6f847d:	48 c7 84 24 78 02 00 	movq   $0x0,0x278(%rsp)
  6f8484:	00 00 00 00 00 
  6f8489:	48 c7 84 24 38 04 00 	movq   $0x0,0x438(%rsp)
  6f8490:	00 00 00 00 00 
  6f8495:	48 c7 84 24 48 04 00 	movq   $0x0,0x448(%rsp)
  6f849c:	00 00 00 00 00 
  6f84a1:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  6f84a8:	00 
  6f84a9:	4c 8b b4 24 60 01 00 	mov    0x160(%rsp),%r14
  6f84b0:	00 
  6f84b1:	48 85 c0             	test   %rax,%rax
  6f84b4:	0f 95 c1             	setne  %cl
  6f84b7:	4d 85 f6             	test   %r14,%r14
  6f84ba:	0f 95 c2             	setne  %dl
  6f84bd:	20 ca                	and    %cl,%dl
  6f84bf:	80 fa 01             	cmp    $0x1,%dl
  6f84c2:	0f 85 4f 02 00 00    	jne    6f8717 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x16d7>
  6f84c8:	48 8b ac 24 58 01 00 	mov    0x158(%rsp),%rbp
  6f84cf:	00 
  6f84d0:	45 31 ed             	xor    %r13d,%r13d
  6f84d3:	4c 8b 3d ee 36 39 00 	mov    0x3936ee(%rip),%r15        # a8bbc8 <_DYNAMIC+0x6b0>
  6f84da:	4c 8d 64 24 6f       	lea    0x6f(%rsp),%r12
  6f84df:	48 8d 9c 24 80 00 00 	lea    0x80(%rsp),%rbx
  6f84e6:	00 
  6f84e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f84ee:	00 00 
  6f84f0:	4d 85 ed             	test   %r13,%r13
  6f84f3:	74 1c                	je     6f8511 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x14d1>
  6f84f5:	41 0f b7 8d c2 01 00 	movzwl 0x1c2(%r13),%ecx
  6f84fc:	00 
  6f84fd:	48 39 cd             	cmp    %rcx,%rbp
  6f8500:	0f 83 ba 00 00 00    	jae    6f85c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1580>
  6f8506:	4c 89 ef             	mov    %r13,%rdi
  6f8509:	48 89 e9             	mov    %rbp,%rcx
  6f850c:	e9 d6 00 00 00       	jmp    6f85e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x15a7>
  6f8511:	48 85 ed             	test   %rbp,%rbp
  6f8514:	74 37                	je     6f854d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x150d>
  6f8516:	48 89 e9             	mov    %rbp,%rcx
  6f8519:	49 89 c5             	mov    %rax,%r13
  6f851c:	48 83 e1 07          	and    $0x7,%rcx
  6f8520:	74 30                	je     6f8552 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1512>
  6f8522:	31 d2                	xor    %edx,%edx
  6f8524:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f852b:	00 00 00 00 00 
  6f8530:	4d 8b ad c8 01 00 00 	mov    0x1c8(%r13),%r13
  6f8537:	48 ff c2             	inc    %rdx
  6f853a:	48 39 d1             	cmp    %rdx,%rcx
  6f853d:	75 f1                	jne    6f8530 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x14f0>
  6f853f:	48 89 e8             	mov    %rbp,%rax
  6f8542:	48 29 d0             	sub    %rdx,%rax
  6f8545:	48 83 fd 08          	cmp    $0x8,%rbp
  6f8549:	73 15                	jae    6f8560 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1520>
  6f854b:	eb 51                	jmp    6f859e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x155e>
  6f854d:	49 89 c5             	mov    %rax,%r13
  6f8550:	eb 4c                	jmp    6f859e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x155e>
  6f8552:	48 89 e8             	mov    %rbp,%rax
  6f8555:	48 83 fd 08          	cmp    $0x8,%rbp
  6f8559:	72 43                	jb     6f859e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x155e>
  6f855b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6f8560:	49 8b 8d c8 01 00 00 	mov    0x1c8(%r13),%rcx
  6f8567:	48 8b 89 c8 01 00 00 	mov    0x1c8(%rcx),%rcx
  6f856e:	48 8b 89 c8 01 00 00 	mov    0x1c8(%rcx),%rcx
  6f8575:	48 8b 89 c8 01 00 00 	mov    0x1c8(%rcx),%rcx
  6f857c:	48 8b 89 c8 01 00 00 	mov    0x1c8(%rcx),%rcx
  6f8583:	48 8b 89 c8 01 00 00 	mov    0x1c8(%rcx),%rcx
  6f858a:	48 8b 89 c8 01 00 00 	mov    0x1c8(%rcx),%rcx
  6f8591:	4c 8b a9 c8 01 00 00 	mov    0x1c8(%rcx),%r13
  6f8598:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  6f859c:	75 c2                	jne    6f8560 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1520>
  6f859e:	31 c0                	xor    %eax,%eax
  6f85a0:	31 ed                	xor    %ebp,%ebp
  6f85a2:	41 0f b7 8d c2 01 00 	movzwl 0x1c2(%r13),%ecx
  6f85a9:	00 
  6f85aa:	48 39 cd             	cmp    %rcx,%rbp
  6f85ad:	0f 82 53 ff ff ff    	jb     6f8506 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x14c6>
  6f85b3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f85ba:	84 00 00 00 00 00 
  6f85c0:	49 8b bd 60 01 00 00 	mov    0x160(%r13),%rdi
  6f85c7:	48 85 ff             	test   %rdi,%rdi
  6f85ca:	0f 84 c8 52 00 00    	je     6fd898 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6858>
  6f85d0:	48 ff c0             	inc    %rax
  6f85d3:	41 0f b7 8d c0 01 00 	movzwl 0x1c0(%r13),%ecx
  6f85da:	00 
  6f85db:	49 89 fd             	mov    %rdi,%r13
  6f85de:	66 3b 8f c2 01 00 00 	cmp    0x1c2(%rdi),%cx
  6f85e5:	73 d9                	jae    6f85c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1580>
  6f85e7:	48 85 c0             	test   %rax,%rax
  6f85ea:	0f 84 85 00 00 00    	je     6f8675 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1635>
  6f85f0:	48 8d 14 cf          	lea    (%rdi,%rcx,8),%rdx
  6f85f4:	48 81 c2 d0 01 00 00 	add    $0x1d0,%rdx
  6f85fb:	48 89 c6             	mov    %rax,%rsi
  6f85fe:	48 83 e6 07          	and    $0x7,%rsi
  6f8602:	0f 84 a4 00 00 00    	je     6f86ac <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x166c>
  6f8608:	45 31 c0             	xor    %r8d,%r8d
  6f860b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6f8610:	4c 8b 2a             	mov    (%rdx),%r13
  6f8613:	49 8d 95 c8 01 00 00 	lea    0x1c8(%r13),%rdx
  6f861a:	49 ff c0             	inc    %r8
  6f861d:	4c 39 c6             	cmp    %r8,%rsi
  6f8620:	75 ee                	jne    6f8610 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x15d0>
  6f8622:	48 89 c6             	mov    %rax,%rsi
  6f8625:	4c 29 c6             	sub    %r8,%rsi
  6f8628:	48 83 f8 08          	cmp    $0x8,%rax
  6f862c:	72 43                	jb     6f8671 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1631>
  6f862e:	66 90                	xchg   %ax,%ax
  6f8630:	48 8b 02             	mov    (%rdx),%rax
  6f8633:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f863a:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f8641:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f8648:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f864f:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f8656:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f865d:	4c 8b a8 c8 01 00 00 	mov    0x1c8(%rax),%r13
  6f8664:	49 8d 95 c8 01 00 00 	lea    0x1c8(%r13),%rdx
  6f866b:	48 83 c6 f8          	add    $0xfffffffffffffff8,%rsi
  6f866f:	75 bf                	jne    6f8630 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x15f0>
  6f8671:	31 ed                	xor    %ebp,%ebp
  6f8673:	eb 07                	jmp    6f867c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x163c>
  6f8675:	48 8d 69 01          	lea    0x1(%rcx),%rbp
  6f8679:	49 89 fd             	mov    %rdi,%r13
  6f867c:	48 c1 e1 05          	shl    $0x5,%rcx
  6f8680:	48 01 cf             	add    %rcx,%rdi
  6f8683:	41 ff d7             	call   *%r15
  6f8686:	48 8b 78 08          	mov    0x8(%rax),%rdi
  6f868a:	48 8b 70 10          	mov    0x10(%rax),%rsi
  6f868e:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
  6f8695:	00 
  6f8696:	48 83 fe 02          	cmp    $0x2,%rsi
  6f869a:	73 1e                	jae    6f86ba <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x167a>
  6f869c:	b8 00 00 00 00       	mov    $0x0,%eax
  6f86a1:	49 ff ce             	dec    %r14
  6f86a4:	0f 85 46 fe ff ff    	jne    6f84f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x14b0>
  6f86aa:	eb 6b                	jmp    6f8717 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x16d7>
  6f86ac:	48 89 c6             	mov    %rax,%rsi
  6f86af:	48 83 f8 08          	cmp    $0x8,%rax
  6f86b3:	72 bc                	jb     6f8671 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1631>
  6f86b5:	e9 76 ff ff ff       	jmp    6f8630 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x15f0>
  6f86ba:	48 83 fe 15          	cmp    $0x15,%rsi
  6f86be:	73 4d                	jae    6f870d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x16cd>
  6f86c0:	48 8d 04 b7          	lea    (%rdi,%rsi,4),%rax
  6f86c4:	48 8d 4f 04          	lea    0x4(%rdi),%rcx
  6f86c8:	ba 04 00 00 00       	mov    $0x4,%edx
  6f86cd:	eb 13                	jmp    6f86e2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x16a2>
  6f86cf:	49 89 f8             	mov    %rdi,%r8
  6f86d2:	41 89 30             	mov    %esi,(%r8)
  6f86d5:	48 83 c1 04          	add    $0x4,%rcx
  6f86d9:	48 83 c2 04          	add    $0x4,%rdx
  6f86dd:	48 39 c1             	cmp    %rax,%rcx
  6f86e0:	74 ba                	je     6f869c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x165c>
  6f86e2:	44 8b 49 fc          	mov    -0x4(%rcx),%r9d
  6f86e6:	8b 31                	mov    (%rcx),%esi
  6f86e8:	44 39 ce             	cmp    %r9d,%esi
  6f86eb:	73 e8                	jae    6f86d5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1695>
  6f86ed:	49 89 d0             	mov    %rdx,%r8
  6f86f0:	46 89 0c 07          	mov    %r9d,(%rdi,%r8,1)
  6f86f4:	49 83 f8 04          	cmp    $0x4,%r8
  6f86f8:	74 d5                	je     6f86cf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x168f>
  6f86fa:	46 8b 4c 07 f8       	mov    -0x8(%rdi,%r8,1),%r9d
  6f86ff:	49 83 c0 fc          	add    $0xfffffffffffffffc,%r8
  6f8703:	44 39 ce             	cmp    %r9d,%esi
  6f8706:	72 e8                	jb     6f86f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x16b0>
  6f8708:	49 01 f8             	add    %rdi,%r8
  6f870b:	eb c5                	jmp    6f86d2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1692>
  6f870d:	48 89 da             	mov    %rbx,%rdx
  6f8710:	e8 8b 9e 01 00       	call   7125a0 <core::slice::sort::unstable::ipnsort::<gpui::runtime::metadata::Destination, <[gpui::runtime::metadata::Destination]>::sort_unstable_by_key<u32, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#14}>::{closure#0}>>
  6f8715:	eb 85                	jmp    6f869c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x165c>
  6f8717:	48 8d bc 24 e0 07 00 	lea    0x7e0(%rsp),%rdi
  6f871e:	00 
  6f871f:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
  6f8726:	00 
  6f8727:	ff 15 bb 34 39 00    	call   *0x3934bb(%rip)        # a8bbe8 <_DYNAMIC+0x6d0>
  6f872d:	48 8b 84 24 28 08 00 	mov    0x828(%rsp),%rax
  6f8734:	00 
  6f8735:	48 8b 9c 24 38 08 00 	mov    0x838(%rsp),%rbx
  6f873c:	00 
  6f873d:	48 85 c0             	test   %rax,%rax
  6f8740:	0f 95 c1             	setne  %cl
  6f8743:	48 85 db             	test   %rbx,%rbx
  6f8746:	0f 95 c2             	setne  %dl
  6f8749:	20 ca                	and    %cl,%dl
  6f874b:	80 fa 01             	cmp    $0x1,%dl
  6f874e:	0f 85 a5 02 00 00    	jne    6f89f9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x19b9>
  6f8754:	4c 8b a4 24 30 08 00 	mov    0x830(%rsp),%r12
  6f875b:	00 
  6f875c:	45 31 ff             	xor    %r15d,%r15d
  6f875f:	eb 2d                	jmp    6f878e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x174e>
  6f8761:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f8768:	0f 1f 84 00 00 00 00 
  6f876f:	00 
  6f8770:	4b c7 44 35 e0 ff ff 	movq   $0xffffffffffffffff,-0x20(%r13,%r14,1)
  6f8777:	ff ff 
  6f8779:	43 89 6c 35 e8       	mov    %ebp,-0x18(%r13,%r14,1)
  6f877e:	b1 01                	mov    $0x1,%cl
  6f8780:	b8 00 00 00 00       	mov    $0x0,%eax
  6f8785:	48 85 db             	test   %rbx,%rbx
  6f8788:	0f 84 6b 02 00 00    	je     6f89f9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x19b9>
  6f878e:	f6 c1 01             	test   $0x1,%cl
  6f8791:	0f 84 02 52 00 00    	je     6fd999 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6959>
  6f8797:	4d 85 ff             	test   %r15,%r15
  6f879a:	74 1c                	je     6f87b8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1778>
  6f879c:	41 0f b7 8f 8e 00 00 	movzwl 0x8e(%r15),%ecx
  6f87a3:	00 
  6f87a4:	49 39 cc             	cmp    %rcx,%r12
  6f87a7:	0f 83 b3 00 00 00    	jae    6f8860 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1820>
  6f87ad:	4c 89 f9             	mov    %r15,%rcx
  6f87b0:	4c 89 e2             	mov    %r12,%rdx
  6f87b3:	e9 cb 00 00 00       	jmp    6f8883 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1843>
  6f87b8:	4d 85 e4             	test   %r12,%r12
  6f87bb:	74 30                	je     6f87ed <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x17ad>
  6f87bd:	4c 89 e1             	mov    %r12,%rcx
  6f87c0:	49 89 c7             	mov    %rax,%r15
  6f87c3:	48 83 e1 07          	and    $0x7,%rcx
  6f87c7:	74 29                	je     6f87f2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x17b2>
  6f87c9:	31 d2                	xor    %edx,%edx
  6f87cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6f87d0:	4d 8b bf 90 00 00 00 	mov    0x90(%r15),%r15
  6f87d7:	48 ff c2             	inc    %rdx
  6f87da:	48 39 d1             	cmp    %rdx,%rcx
  6f87dd:	75 f1                	jne    6f87d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1790>
  6f87df:	4c 89 e0             	mov    %r12,%rax
  6f87e2:	48 29 d0             	sub    %rdx,%rax
  6f87e5:	49 83 fc 08          	cmp    $0x8,%r12
  6f87e9:	73 15                	jae    6f8800 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x17c0>
  6f87eb:	eb 51                	jmp    6f883e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x17fe>
  6f87ed:	49 89 c7             	mov    %rax,%r15
  6f87f0:	eb 4c                	jmp    6f883e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x17fe>
  6f87f2:	4c 89 e0             	mov    %r12,%rax
  6f87f5:	49 83 fc 08          	cmp    $0x8,%r12
  6f87f9:	72 43                	jb     6f883e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x17fe>
  6f87fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6f8800:	49 8b 8f 90 00 00 00 	mov    0x90(%r15),%rcx
  6f8807:	48 8b 89 90 00 00 00 	mov    0x90(%rcx),%rcx
  6f880e:	48 8b 89 90 00 00 00 	mov    0x90(%rcx),%rcx
  6f8815:	48 8b 89 90 00 00 00 	mov    0x90(%rcx),%rcx
  6f881c:	48 8b 89 90 00 00 00 	mov    0x90(%rcx),%rcx
  6f8823:	48 8b 89 90 00 00 00 	mov    0x90(%rcx),%rcx
  6f882a:	48 8b 89 90 00 00 00 	mov    0x90(%rcx),%rcx
  6f8831:	4c 8b b9 90 00 00 00 	mov    0x90(%rcx),%r15
  6f8838:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  6f883c:	75 c2                	jne    6f8800 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x17c0>
  6f883e:	31 c0                	xor    %eax,%eax
  6f8840:	45 31 e4             	xor    %r12d,%r12d
  6f8843:	41 0f b7 8f 8e 00 00 	movzwl 0x8e(%r15),%ecx
  6f884a:	00 
  6f884b:	49 39 cc             	cmp    %rcx,%r12
  6f884e:	0f 82 59 ff ff ff    	jb     6f87ad <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x176d>
  6f8854:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f885b:	00 00 00 00 00 
  6f8860:	49 8b 0f             	mov    (%r15),%rcx
  6f8863:	48 85 c9             	test   %rcx,%rcx
  6f8866:	0f 84 3e 50 00 00    	je     6fd8aa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x686a>
  6f886c:	48 ff c0             	inc    %rax
  6f886f:	41 0f b7 97 8c 00 00 	movzwl 0x8c(%r15),%edx
  6f8876:	00 
  6f8877:	49 89 cf             	mov    %rcx,%r15
  6f887a:	66 3b 91 8e 00 00 00 	cmp    0x8e(%rcx),%dx
  6f8881:	73 dd                	jae    6f8860 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1820>
  6f8883:	48 85 c0             	test   %rax,%rax
  6f8886:	0f 84 9a 00 00 00    	je     6f8926 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x18e6>
  6f888c:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
  6f8890:	48 81 c6 98 00 00 00 	add    $0x98,%rsi
  6f8897:	48 89 c7             	mov    %rax,%rdi
  6f889a:	48 83 e7 07          	and    $0x7,%rdi
  6f889e:	0f 84 43 01 00 00    	je     6f89e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x19a7>
  6f88a4:	45 31 c0             	xor    %r8d,%r8d
  6f88a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f88ae:	00 00 
  6f88b0:	4c 8b 3e             	mov    (%rsi),%r15
  6f88b3:	49 8d b7 90 00 00 00 	lea    0x90(%r15),%rsi
  6f88ba:	49 ff c0             	inc    %r8
  6f88bd:	4c 39 c7             	cmp    %r8,%rdi
  6f88c0:	75 ee                	jne    6f88b0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1870>
  6f88c2:	48 89 c7             	mov    %rax,%rdi
  6f88c5:	4c 29 c7             	sub    %r8,%rdi
  6f88c8:	48 83 f8 08          	cmp    $0x8,%rax
  6f88cc:	72 43                	jb     6f8911 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x18d1>
  6f88ce:	66 90                	xchg   %ax,%ax
  6f88d0:	48 8b 06             	mov    (%rsi),%rax
  6f88d3:	48 8b 80 90 00 00 00 	mov    0x90(%rax),%rax
  6f88da:	48 8b 80 90 00 00 00 	mov    0x90(%rax),%rax
  6f88e1:	48 8b 80 90 00 00 00 	mov    0x90(%rax),%rax
  6f88e8:	48 8b 80 90 00 00 00 	mov    0x90(%rax),%rax
  6f88ef:	48 8b 80 90 00 00 00 	mov    0x90(%rax),%rax
  6f88f6:	48 8b 80 90 00 00 00 	mov    0x90(%rax),%rax
  6f88fd:	4c 8b b8 90 00 00 00 	mov    0x90(%rax),%r15
  6f8904:	49 8d b7 90 00 00 00 	lea    0x90(%r15),%rsi
  6f890b:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  6f890f:	75 bf                	jne    6f88d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1890>
  6f8911:	45 31 e4             	xor    %r12d,%r12d
  6f8914:	4c 8b ac 24 50 01 00 	mov    0x150(%rsp),%r13
  6f891b:	00 
  6f891c:	4d 85 ed             	test   %r13,%r13
  6f891f:	75 1d                	jne    6f893e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x18fe>
  6f8921:	e9 55 50 00 00       	jmp    6fd97b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x693b>
  6f8926:	4c 8d 62 01          	lea    0x1(%rdx),%r12
  6f892a:	49 89 cf             	mov    %rcx,%r15
  6f892d:	4c 8b ac 24 50 01 00 	mov    0x150(%rsp),%r13
  6f8934:	00 
  6f8935:	4d 85 ed             	test   %r13,%r13
  6f8938:	0f 84 3d 50 00 00    	je     6fd97b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x693b>
  6f893e:	48 ff cb             	dec    %rbx
  6f8941:	48 8b 44 d1 08       	mov    0x8(%rcx,%rdx,8),%rax
  6f8946:	8b 6c 91 60          	mov    0x60(%rcx,%rdx,4),%ebp
  6f894a:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
  6f8951:	00 
  6f8952:	41 0f b7 b5 c2 01 00 	movzwl 0x1c2(%r13),%esi
  6f8959:	00 
  6f895a:	89 f7                	mov    %esi,%edi
  6f895c:	c1 e7 05             	shl    $0x5,%edi
  6f895f:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6f8966:	45 31 f6             	xor    %r14d,%r14d
  6f8969:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6f8970:	4c 39 f7             	cmp    %r14,%rdi
  6f8973:	74 2b                	je     6f89a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1960>
  6f8975:	49 3b 84 d5 70 01 00 	cmp    0x170(%r13,%rdx,8),%rax
  6f897c:	00 
  6f897d:	41 0f 97 c0          	seta   %r8b
  6f8981:	41 80 d8 00          	sbb    $0x0,%r8b
  6f8985:	49 83 c6 20          	add    $0x20,%r14
  6f8989:	48 ff c2             	inc    %rdx
  6f898c:	41 80 f8 01          	cmp    $0x1,%r8b
  6f8990:	74 de                	je     6f8970 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1930>
  6f8992:	41 0f b6 f0          	movzbl %r8b,%esi
  6f8996:	85 f6                	test   %esi,%esi
  6f8998:	75 09                	jne    6f89a3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1963>
  6f899a:	eb 24                	jmp    6f89c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1980>
  6f899c:	0f 1f 40 00          	nopl   0x0(%rax)
  6f89a0:	48 89 f2             	mov    %rsi,%rdx
  6f89a3:	48 83 e9 01          	sub    $0x1,%rcx
  6f89a7:	0f 82 ce 4f 00 00    	jb     6fd97b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x693b>
  6f89ad:	4d 8b ac d5 c8 01 00 	mov    0x1c8(%r13,%rdx,8),%r13
  6f89b4:	00 
  6f89b5:	eb 9b                	jmp    6f8952 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1912>
  6f89b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f89be:	00 00 
  6f89c0:	4b 8b 74 35 e0       	mov    -0x20(%r13,%r14,1),%rsi
  6f89c5:	48 85 f6             	test   %rsi,%rsi
  6f89c8:	0f 8e a2 fd ff ff    	jle    6f8770 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1730>
  6f89ce:	4b 8b 7c 35 e8       	mov    -0x18(%r13,%r14,1),%rdi
  6f89d3:	48 c1 e6 02          	shl    $0x2,%rsi
  6f89d7:	ba 04 00 00 00       	mov    $0x4,%edx
  6f89dc:	ff 15 86 2d 39 00    	call   *0x392d86(%rip)        # a8b768 <_DYNAMIC+0x250>
  6f89e2:	e9 89 fd ff ff       	jmp    6f8770 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1730>
  6f89e7:	48 89 c7             	mov    %rax,%rdi
  6f89ea:	48 83 f8 08          	cmp    $0x8,%rax
  6f89ee:	0f 82 1d ff ff ff    	jb     6f8911 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x18d1>
  6f89f4:	e9 d7 fe ff ff       	jmp    6f88d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1890>
  6f89f9:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
  6f89fe:	48 8b 83 20 02 00 00 	mov    0x220(%rbx),%rax
  6f8a05:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
  6f8a0c:	00 
  6f8a0d:	f3 0f 6f 83 00 02 00 	movdqu 0x200(%rbx),%xmm0
  6f8a14:	00 
  6f8a15:	f3 0f 6f 8b 10 02 00 	movdqu 0x210(%rbx),%xmm1
  6f8a1c:	00 
  6f8a1d:	66 0f 7f 8c 24 b0 06 	movdqa %xmm1,0x6b0(%rsp)
  6f8a24:	00 00 
  6f8a26:	66 0f 7f 84 24 a0 06 	movdqa %xmm0,0x6a0(%rsp)
  6f8a2d:	00 00 
  6f8a2f:	48 c7 83 00 02 00 00 	movq   $0x0,0x200(%rbx)
  6f8a36:	00 00 00 00 
  6f8a3a:	48 8b b3 98 02 00 00 	mov    0x298(%rbx),%rsi
  6f8a41:	48 8b 93 a0 02 00 00 	mov    0x2a0(%rbx),%rdx
  6f8a48:	48 8d bc 24 c8 07 00 	lea    0x7c8(%rsp),%rdi
  6f8a4f:	00 
  6f8a50:	ff 15 9a 31 39 00    	call   *0x39319a(%rip)        # a8bbf0 <_DYNAMIC+0x6d8>
  6f8a56:	48 8b 83 b0 05 00 00 	mov    0x5b0(%rbx),%rax
  6f8a5d:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
  6f8a64:	00 
  6f8a65:	48 8b 83 b8 05 00 00 	mov    0x5b8(%rbx),%rax
  6f8a6c:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
  6f8a73:	00 
  6f8a74:	48 c7 83 b0 05 00 00 	movq   $0x8,0x5b0(%rbx)
  6f8a7b:	08 00 00 00 
  6f8a7f:	48 c7 83 b8 05 00 00 	movq   $0x0,0x5b8(%rbx)
  6f8a86:	00 00 00 00 
  6f8a8a:	48 8b 83 90 02 00 00 	mov    0x290(%rbx),%rax
  6f8a91:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
  6f8a98:	00 
  6f8a99:	48 8b 83 98 02 00 00 	mov    0x298(%rbx),%rax
  6f8aa0:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6f8aa5:	4c 8b b3 a0 02 00 00 	mov    0x2a0(%rbx),%r14
  6f8aac:	48 c7 83 90 02 00 00 	movq   $0x0,0x290(%rbx)
  6f8ab3:	00 00 00 00 
  6f8ab7:	48 c7 83 98 02 00 00 	movq   $0x8,0x298(%rbx)
  6f8abe:	08 00 00 00 
  6f8ac2:	48 c7 83 a0 02 00 00 	movq   $0x0,0x2a0(%rbx)
  6f8ac9:	00 00 00 00 
  6f8acd:	48 c7 84 24 70 06 00 	movq   $0x0,0x670(%rsp)
  6f8ad4:	00 00 00 00 00 
  6f8ad9:	48 c7 84 24 80 06 00 	movq   $0x0,0x680(%rsp)
  6f8ae0:	00 00 00 00 00 
  6f8ae5:	48 c7 84 24 88 06 00 	movq   $0x0,0x688(%rsp)
  6f8aec:	00 00 00 00 00 
  6f8af1:	48 c7 84 24 98 06 00 	movq   $0x0,0x698(%rsp)
  6f8af8:	00 00 00 00 00 
  6f8afd:	48 8b 83 48 06 00 00 	mov    0x648(%rbx),%rax
  6f8b04:	48 8b 8b 50 06 00 00 	mov    0x650(%rbx),%rcx
  6f8b0b:	31 d2                	xor    %edx,%edx
  6f8b0d:	48 89 c6             	mov    %rax,%rsi
  6f8b10:	48 85 c0             	test   %rax,%rax
  6f8b13:	40 0f 95 c7          	setne  %dil
  6f8b17:	74 0c                	je     6f8b25 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ae5>
  6f8b19:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  6f8b1e:	48 8b b6 58 06 00 00 	mov    0x658(%rsi),%rsi
  6f8b25:	40 88 fa             	mov    %dil,%dl
  6f8b28:	48 89 94 24 80 00 00 	mov    %rdx,0x80(%rsp)
  6f8b2f:	00 
  6f8b30:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
  6f8b37:	00 00 00 00 00 
  6f8b3c:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6f8b43:	00 
  6f8b44:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  6f8b4b:	00 
  6f8b4c:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
  6f8b53:	00 
  6f8b54:	48 c7 84 24 a8 00 00 	movq   $0x0,0xa8(%rsp)
  6f8b5b:	00 00 00 00 00 
  6f8b60:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  6f8b67:	00 
  6f8b68:	48 89 8c 24 b8 00 00 	mov    %rcx,0xb8(%rsp)
  6f8b6f:	00 
  6f8b70:	48 89 b4 24 c0 00 00 	mov    %rsi,0xc0(%rsp)
  6f8b77:	00 
  6f8b78:	41 b4 01             	mov    $0x1,%r12b
  6f8b7b:	48 8d bc 24 98 08 00 	lea    0x898(%rsp),%rdi
  6f8b82:	00 
  6f8b83:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6f8b8a:	00 
  6f8b8b:	41 b5 01             	mov    $0x1,%r13b
  6f8b8e:	e8 1d 06 01 00       	call   7091b0 <<alloc::collections::btree::map::BTreeMap<u64, gpui::list::ListId> as core::iter::traits::collect::FromIterator<(u64, gpui::list::ListId)>>::from_iter::<core::iter::adapters::filter_map::FilterMap<alloc::collections::btree::map::Iter<gpui::runtime::scroll::ViewportKey, gpui::runtime::scroll::ViewportState>, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#15}>>>
  6f8b93:	48 8b 9c 24 30 01 00 	mov    0x130(%rsp),%rbx
  6f8b9a:	00 
  6f8b9b:	4d 85 f6             	test   %r14,%r14
  6f8b9e:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
  6f8ba3:	0f 84 3a 05 00 00    	je     6f90e3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x20a3>
  6f8ba9:	4b 8d 04 76          	lea    (%r14,%r14,2),%rax
  6f8bad:	48 8b 6c 24 50       	mov    0x50(%rsp),%rbp
  6f8bb2:	48 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%rax
  6f8bb9:	00 
  6f8bba:	48 01 e8             	add    %rbp,%rax
  6f8bbd:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6f8bc2:	4c 8b a4 24 98 08 00 	mov    0x898(%rsp),%r12
  6f8bc9:	00 
  6f8bca:	48 8b 84 24 a0 08 00 	mov    0x8a0(%rsp),%rax
  6f8bd1:	00 
  6f8bd2:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f8bd7:	31 db                	xor    %ebx,%ebx
  6f8bd9:	eb 2c                	jmp    6f8c07 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1bc7>
  6f8bdb:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  6f8be2:	00 
  6f8be3:	48 89 9c c8 68 01 00 	mov    %rbx,0x168(%rax,%rcx,8)
  6f8bea:	00 
  6f8beb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6f8bf0:	48 83 c5 18          	add    $0x18,%rbp
  6f8bf4:	48 ff c3             	inc    %rbx
  6f8bf7:	48 3b 6c 24 20       	cmp    0x20(%rsp),%rbp
  6f8bfc:	4c 8b 74 24 18       	mov    0x18(%rsp),%r14
  6f8c01:	0f 84 19 04 00 00    	je     6f9020 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1fe0>
  6f8c07:	48 8b 45 00          	mov    0x0(%rbp),%rax
  6f8c0b:	48 85 c0             	test   %rax,%rax
  6f8c0e:	0f 84 21 4b 00 00    	je     6fd735 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x66f5>
  6f8c14:	8b 7d 08             	mov    0x8(%rbp),%edi
  6f8c17:	b9 ff ff 01 00       	mov    $0x1ffff,%ecx
  6f8c1c:	21 cf                	and    %ecx,%edi
  6f8c1e:	74 3d                	je     6f8c5d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1c1d>
  6f8c20:	ff cf                	dec    %edi
  6f8c22:	49 39 fe             	cmp    %rdi,%r14
  6f8c25:	0f 86 9a 4d 00 00    	jbe    6fd9c5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6985>
  6f8c2b:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  6f8c2f:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  6f8c34:	4c 8b 34 ca          	mov    (%rdx,%rcx,8),%r14
  6f8c38:	41 bf 01 00 00 00    	mov    $0x1,%r15d
  6f8c3e:	4d 85 f6             	test   %r14,%r14
  6f8c41:	0f 84 c2 4b 00 00    	je     6fd809 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x67c9>
  6f8c47:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6f8c4c:	48 8b 8a 60 06 00 00 	mov    0x660(%rdx),%rcx
  6f8c53:	48 85 c9             	test   %rcx,%rcx
  6f8c56:	75 1d                	jne    6f8c75 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1c35>
  6f8c58:	e9 f3 01 00 00       	jmp    6f8e50 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e10>
  6f8c5d:	45 31 ff             	xor    %r15d,%r15d
  6f8c60:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6f8c65:	48 8b 8a 60 06 00 00 	mov    0x660(%rdx),%rcx
  6f8c6c:	48 85 c9             	test   %rcx,%rcx
  6f8c6f:	0f 84 db 01 00 00    	je     6f8e50 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e10>
  6f8c75:	48 8b b2 68 06 00 00 	mov    0x668(%rdx),%rsi
  6f8c7c:	44 0f b7 81 c2 01 00 	movzwl 0x1c2(%rcx),%r8d
  6f8c83:	00 
  6f8c84:	45 89 c1             	mov    %r8d,%r9d
  6f8c87:	41 c1 e1 05          	shl    $0x5,%r9d
  6f8c8b:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
  6f8c92:	31 d2                	xor    %edx,%edx
  6f8c94:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f8c9b:	00 00 00 00 00 
  6f8ca0:	49 39 d1             	cmp    %rdx,%r9
  6f8ca3:	74 2b                	je     6f8cd0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1c90>
  6f8ca5:	48 3b 84 f9 70 01 00 	cmp    0x170(%rcx,%rdi,8),%rax
  6f8cac:	00 
  6f8cad:	41 0f 97 c2          	seta   %r10b
  6f8cb1:	41 80 da 00          	sbb    $0x0,%r10b
  6f8cb5:	48 83 c2 20          	add    $0x20,%rdx
  6f8cb9:	48 ff c7             	inc    %rdi
  6f8cbc:	41 80 fa 01          	cmp    $0x1,%r10b
  6f8cc0:	74 de                	je     6f8ca0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1c60>
  6f8cc2:	45 0f b6 c2          	movzbl %r10b,%r8d
  6f8cc6:	45 85 c0             	test   %r8d,%r8d
  6f8cc9:	75 08                	jne    6f8cd3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1c93>
  6f8ccb:	eb 23                	jmp    6f8cf0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1cb0>
  6f8ccd:	0f 1f 00             	nopl   (%rax)
  6f8cd0:	4c 89 c7             	mov    %r8,%rdi
  6f8cd3:	48 83 ee 01          	sub    $0x1,%rsi
  6f8cd7:	0f 82 73 01 00 00    	jb     6f8e50 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e10>
  6f8cdd:	48 8b 8c f9 c8 01 00 	mov    0x1c8(%rcx,%rdi,8),%rcx
  6f8ce4:	00 
  6f8ce5:	eb 95                	jmp    6f8c7c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1c3c>
  6f8ce7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f8cee:	00 00 
  6f8cf0:	80 7c 11 fc 01       	cmpb   $0x1,-0x4(%rcx,%rdx,1)
  6f8cf5:	0f 85 55 01 00 00    	jne    6f8e50 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e10>
  6f8cfb:	8b 45 10             	mov    0x10(%rbp),%eax
  6f8cfe:	83 e0 0f             	and    $0xf,%eax
  6f8d01:	83 f8 09             	cmp    $0x9,%eax
  6f8d04:	0f 87 4f 4b 00 00    	ja     6fd859 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6819>
  6f8d0a:	48 8d 35 33 f0 95 ff 	lea    -0x6a0fcd(%rip),%rsi        # 57d44 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x7c>
  6f8d11:	48 63 04 86          	movslq (%rsi,%rax,4),%rax
  6f8d15:	48 01 f0             	add    %rsi,%rax
  6f8d18:	ff e0                	jmp    *%rax
  6f8d1a:	31 c0                	xor    %eax,%eax
  6f8d1c:	eb 1e                	jmp    6f8d3c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1cfc>
  6f8d1e:	b0 06                	mov    $0x6,%al
  6f8d20:	eb 1a                	jmp    6f8d3c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1cfc>
  6f8d22:	b0 04                	mov    $0x4,%al
  6f8d24:	eb 16                	jmp    6f8d3c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1cfc>
  6f8d26:	b0 05                	mov    $0x5,%al
  6f8d28:	eb 12                	jmp    6f8d3c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1cfc>
  6f8d2a:	b0 09                	mov    $0x9,%al
  6f8d2c:	eb 0e                	jmp    6f8d3c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1cfc>
  6f8d2e:	b0 02                	mov    $0x2,%al
  6f8d30:	eb 0a                	jmp    6f8d3c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1cfc>
  6f8d32:	b0 03                	mov    $0x3,%al
  6f8d34:	eb 06                	jmp    6f8d3c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1cfc>
  6f8d36:	b0 07                	mov    $0x7,%al
  6f8d38:	eb 02                	jmp    6f8d3c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1cfc>
  6f8d3a:	b0 08                	mov    $0x8,%al
  6f8d3c:	4c 8b 6c 11 e8       	mov    -0x18(%rcx,%rdx,1),%r13
  6f8d41:	4c 89 bc 24 d0 02 00 	mov    %r15,0x2d0(%rsp)
  6f8d48:	00 
  6f8d49:	4c 89 b4 24 d8 02 00 	mov    %r14,0x2d8(%rsp)
  6f8d50:	00 
  6f8d51:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
  6f8d58:	00 
  6f8d59:	88 84 24 e8 02 00 00 	mov    %al,0x2e8(%rsp)
  6f8d60:	48 8b b4 24 70 06 00 	mov    0x670(%rsp),%rsi
  6f8d67:	00 
  6f8d68:	48 85 f6             	test   %rsi,%rsi
  6f8d6b:	74 5a                	je     6f8dc7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1d87>
  6f8d6d:	48 8b 94 24 78 06 00 	mov    0x678(%rsp),%rdx
  6f8d74:	00 
  6f8d75:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  6f8d7c:	00 
  6f8d7d:	48 8d 8c 24 d0 02 00 	lea    0x2d0(%rsp),%rcx
  6f8d84:	00 
  6f8d85:	e8 76 6b fe ff       	call   6df900 <<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Mut, (core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize, alloc::collections::btree::node::marker::LeafOrInternal>>::search_tree::<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind)>>
  6f8d8a:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  6f8d91:	00 
  6f8d92:	80 bc 24 80 00 00 00 	cmpb   $0x0,0x80(%rsp)
  6f8d99:	00 
  6f8d9a:	0f 84 9c 00 00 00    	je     6f8e3c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1dfc>
  6f8da0:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f8da7:	00 
  6f8da8:	f3 0f 6f 06          	movdqu (%rsi),%xmm0
  6f8dac:	66 0f 7f 84 24 90 01 	movdqa %xmm0,0x190(%rsp)
  6f8db3:	00 00 
  6f8db5:	48 8b 94 24 d8 02 00 	mov    0x2d8(%rsp),%rdx
  6f8dbc:	00 
  6f8dbd:	48 8b 8c 24 e8 02 00 	mov    0x2e8(%rsp),%rcx
  6f8dc4:	00 
  6f8dc5:	eb 15                	jmp    6f8ddc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1d9c>
  6f8dc7:	48 8b 8c 24 e8 02 00 	mov    0x2e8(%rsp),%rcx
  6f8dce:	00 
  6f8dcf:	4c 89 f2             	mov    %r14,%rdx
  6f8dd2:	31 c0                	xor    %eax,%eax
  6f8dd4:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  6f8ddb:	00 
  6f8ddc:	4c 89 bc 24 80 00 00 	mov    %r15,0x80(%rsp)
  6f8de3:	00 
  6f8de4:	48 89 94 24 88 00 00 	mov    %rdx,0x88(%rsp)
  6f8deb:	00 
  6f8dec:	4c 89 ac 24 90 00 00 	mov    %r13,0x90(%rsp)
  6f8df3:	00 
  6f8df4:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  6f8dfb:	00 
  6f8dfc:	48 8d 8c 24 70 06 00 	lea    0x670(%rsp),%rcx
  6f8e03:	00 
  6f8e04:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
  6f8e0b:	00 
  6f8e0c:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  6f8e13:	00 
  6f8e14:	66 0f 6f 84 24 90 01 	movdqa 0x190(%rsp),%xmm0
  6f8e1b:	00 00 
  6f8e1d:	f3 0f 7f 46 20       	movdqu %xmm0,0x20(%rsi)
  6f8e22:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f8e29:	00 
  6f8e2a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6f8e31:	00 
  6f8e32:	48 89 da             	mov    %rbx,%rdx
  6f8e35:	e8 56 8e 01 00       	call   711c90 <<alloc::collections::btree::map::entry::VacantEntry<(core::option::Option<u64>, gpui::list::ItemKey, gpui::element::NodeKind), usize>>::insert_entry>
  6f8e3a:	eb 10                	jmp    6f8e4c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e0c>
  6f8e3c:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  6f8e43:	00 
  6f8e44:	48 89 9c c8 68 01 00 	mov    %rbx,0x168(%rax,%rcx,8)
  6f8e4b:	00 
  6f8e4c:	48 8b 45 00          	mov    0x0(%rbp),%rax
  6f8e50:	4d 85 e4             	test   %r12,%r12
  6f8e53:	0f 84 97 fd ff ff    	je     6f8bf0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1bb0>
  6f8e59:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  6f8e5e:	4c 89 e1             	mov    %r12,%rcx
  6f8e61:	0f b7 b9 ba 00 00 00 	movzwl 0xba(%rcx),%edi
  6f8e68:	41 89 f8             	mov    %edi,%r8d
  6f8e6b:	41 c1 e0 03          	shl    $0x3,%r8d
  6f8e6f:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6f8e76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6f8e7d:	00 00 00 
  6f8e80:	4d 85 c0             	test   %r8,%r8
  6f8e83:	74 2b                	je     6f8eb0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e70>
  6f8e85:	48 3b 44 d1 10       	cmp    0x10(%rcx,%rdx,8),%rax
  6f8e8a:	41 0f 97 c1          	seta   %r9b
  6f8e8e:	41 80 d9 00          	sbb    $0x0,%r9b
  6f8e92:	48 ff c2             	inc    %rdx
  6f8e95:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  6f8e99:	41 80 f9 01          	cmp    $0x1,%r9b
  6f8e9d:	74 e1                	je     6f8e80 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e40>
  6f8e9f:	41 0f b6 f9          	movzbl %r9b,%edi
  6f8ea3:	85 ff                	test   %edi,%edi
  6f8ea5:	75 0c                	jne    6f8eb3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e73>
  6f8ea7:	eb 27                	jmp    6f8ed0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e90>
  6f8ea9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6f8eb0:	48 89 fa             	mov    %rdi,%rdx
  6f8eb3:	48 83 ee 01          	sub    $0x1,%rsi
  6f8eb7:	0f 82 33 fd ff ff    	jb     6f8bf0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1bb0>
  6f8ebd:	48 8b 8c d1 c0 00 00 	mov    0xc0(%rcx,%rdx,8),%rcx
  6f8ec4:	00 
  6f8ec5:	eb 9a                	jmp    6f8e61 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1e21>
  6f8ec7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f8ece:	00 00 
  6f8ed0:	8b 45 10             	mov    0x10(%rbp),%eax
  6f8ed3:	83 e0 0f             	and    $0xf,%eax
  6f8ed6:	83 f8 09             	cmp    $0x9,%eax
  6f8ed9:	0f 87 7a 49 00 00    	ja     6fd859 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6819>
  6f8edf:	48 8d 35 86 ee 95 ff 	lea    -0x6a117a(%rip),%rsi        # 57d6c <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0xa4>
  6f8ee6:	48 63 04 86          	movslq (%rsi,%rax,4),%rax
  6f8eea:	48 01 f0             	add    %rsi,%rax
  6f8eed:	ff e0                	jmp    *%rax
  6f8eef:	31 c0                	xor    %eax,%eax
  6f8ef1:	eb 2d                	jmp    6f8f20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ee0>
  6f8ef3:	b0 06                	mov    $0x6,%al
  6f8ef5:	eb 29                	jmp    6f8f20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ee0>
  6f8ef7:	b0 04                	mov    $0x4,%al
  6f8ef9:	eb 25                	jmp    6f8f20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ee0>
  6f8efb:	b0 05                	mov    $0x5,%al
  6f8efd:	eb 21                	jmp    6f8f20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ee0>
  6f8eff:	b0 09                	mov    $0x9,%al
  6f8f01:	eb 1d                	jmp    6f8f20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ee0>
  6f8f03:	b0 02                	mov    $0x2,%al
  6f8f05:	eb 19                	jmp    6f8f20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ee0>
  6f8f07:	b0 03                	mov    $0x3,%al
  6f8f09:	eb 15                	jmp    6f8f20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ee0>
  6f8f0b:	b0 07                	mov    $0x7,%al
  6f8f0d:	eb 11                	jmp    6f8f20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1ee0>
  6f8f0f:	b0 08                	mov    $0x8,%al
  6f8f11:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f8f18:	0f 1f 84 00 00 00 00 
  6f8f1f:	00 
  6f8f20:	4c 8b 6c d1 60       	mov    0x60(%rcx,%rdx,8),%r13
  6f8f25:	4c 89 bc 24 d0 02 00 	mov    %r15,0x2d0(%rsp)
  6f8f2c:	00 
  6f8f2d:	4c 89 b4 24 d8 02 00 	mov    %r14,0x2d8(%rsp)
  6f8f34:	00 
  6f8f35:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
  6f8f3c:	00 
  6f8f3d:	88 84 24 e8 02 00 00 	mov    %al,0x2e8(%rsp)
  6f8f44:	48 8b b4 24 88 06 00 	mov    0x688(%rsp),%rsi
  6f8f4b:	00 
  6f8f4c:	48 85 f6             	test   %rsi,%rsi
  6f8f4f:	74 5a                	je     6f8fab <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1f6b>
  6f8f51:	48 8b 94 24 90 06 00 	mov    0x690(%rsp),%rdx
  6f8f58:	00 
  6f8f59:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  6f8f60:	00 
  6f8f61:	48 8d 8c 24 d0 02 00 	lea    0x2d0(%rsp),%rcx
  6f8f68:	00 
  6f8f69:	e8 92 69 fe ff       	call   6df900 <<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Mut, (core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize, alloc::collections::btree::node::marker::LeafOrInternal>>::search_tree::<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind)>>
  6f8f6e:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  6f8f75:	00 
  6f8f76:	80 bc 24 80 00 00 00 	cmpb   $0x0,0x80(%rsp)
  6f8f7d:	00 
  6f8f7e:	0f 84 57 fc ff ff    	je     6f8bdb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1b9b>
  6f8f84:	48 8d 94 24 90 00 00 	lea    0x90(%rsp),%rdx
  6f8f8b:	00 
  6f8f8c:	f3 0f 6f 02          	movdqu (%rdx),%xmm0
  6f8f90:	66 0f 7f 84 24 90 01 	movdqa %xmm0,0x190(%rsp)
  6f8f97:	00 00 
  6f8f99:	4c 8b b4 24 d8 02 00 	mov    0x2d8(%rsp),%r14
  6f8fa0:	00 
  6f8fa1:	48 8b 8c 24 e8 02 00 	mov    0x2e8(%rsp),%rcx
  6f8fa8:	00 
  6f8fa9:	eb 12                	jmp    6f8fbd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1f7d>
  6f8fab:	48 8b 8c 24 e8 02 00 	mov    0x2e8(%rsp),%rcx
  6f8fb2:	00 
  6f8fb3:	31 c0                	xor    %eax,%eax
  6f8fb5:	48 8d 94 24 90 00 00 	lea    0x90(%rsp),%rdx
  6f8fbc:	00 
  6f8fbd:	4c 89 bc 24 80 00 00 	mov    %r15,0x80(%rsp)
  6f8fc4:	00 
  6f8fc5:	4c 89 b4 24 88 00 00 	mov    %r14,0x88(%rsp)
  6f8fcc:	00 
  6f8fcd:	4c 89 ac 24 90 00 00 	mov    %r13,0x90(%rsp)
  6f8fd4:	00 
  6f8fd5:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  6f8fdc:	00 
  6f8fdd:	48 8d 8c 24 88 06 00 	lea    0x688(%rsp),%rcx
  6f8fe4:	00 
  6f8fe5:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
  6f8fec:	00 
  6f8fed:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  6f8ff4:	00 
  6f8ff5:	66 0f 6f 84 24 90 01 	movdqa 0x190(%rsp),%xmm0
  6f8ffc:	00 00 
  6f8ffe:	f3 0f 7f 42 20       	movdqu %xmm0,0x20(%rdx)
  6f9003:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f900a:	00 
  6f900b:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6f9012:	00 
  6f9013:	48 89 da             	mov    %rbx,%rdx
  6f9016:	e8 75 8b 01 00       	call   711b90 <<alloc::collections::btree::map::entry::VacantEntry<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize>>::insert_entry>
  6f901b:	e9 d0 fb ff ff       	jmp    6f8bf0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x1bb0>
  6f9020:	4a 8d 1c f5 00 00 00 	lea    0x0(,%r14,8),%rbx
  6f9027:	00 
  6f9028:	ff 15 2a 27 39 00    	call   *0x39272a(%rip)        # a8b758 <_DYNAMIC+0x240>
  6f902e:	be 08 00 00 00       	mov    $0x8,%esi
  6f9033:	48 89 df             	mov    %rbx,%rdi
  6f9036:	ff 15 24 27 39 00    	call   *0x392724(%rip)        # a8b760 <_DYNAMIC+0x248>
  6f903c:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f9041:	48 85 c0             	test   %rax,%rax
  6f9044:	0f 84 f4 4b 00 00    	je     6fdc3e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6bfe>
  6f904a:	31 c0                	xor    %eax,%eax
  6f904c:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  6f9051:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  6f9056:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6f905d:	00 00 00 
  6f9060:	48 8b 11             	mov    (%rcx),%rdx
  6f9063:	48 85 d2             	test   %rdx,%rdx
  6f9066:	0f 84 db 46 00 00    	je     6fd747 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6707>
  6f906c:	48 89 14 c6          	mov    %rdx,(%rsi,%rax,8)
  6f9070:	48 ff c0             	inc    %rax
  6f9073:	48 83 c1 18          	add    $0x18,%rcx
  6f9077:	49 39 c6             	cmp    %rax,%r14
  6f907a:	75 e4                	jne    6f9060 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2020>
  6f907c:	4c 89 b4 24 88 02 00 	mov    %r14,0x288(%rsp)
  6f9083:	00 
  6f9084:	48 8b 9c 24 30 01 00 	mov    0x130(%rsp),%rbx
  6f908b:	00 
  6f908c:	eb 6b                	jmp    6f90f9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x20b9>
  6f908e:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  6f9095:	00 
  6f9096:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  6f909b:	48 c7 02 20 00 00 00 	movq   $0x20,(%rdx)
  6f90a2:	48 89 42 08          	mov    %rax,0x8(%rdx)
  6f90a6:	4c 89 7a 10          	mov    %r15,0x10(%rdx)
  6f90aa:	48 89 4a 18          	mov    %rcx,0x18(%rdx)
  6f90ae:	48 83 bc 24 f8 01 00 	cmpq   $0x0,0x1f8(%rsp)
  6f90b5:	00 00 
  6f90b7:	0f 84 e6 2c 00 00    	je     6fbda3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d63>
  6f90bd:	48 8b 84 24 f8 01 00 	mov    0x1f8(%rsp),%rax
  6f90c4:	00 
  6f90c5:	48 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%rax
  6f90cc:	00 
  6f90cd:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6f90d1:	ba 08 00 00 00       	mov    $0x8,%edx
  6f90d6:	48 8b bc 24 28 02 00 	mov    0x228(%rsp),%rdi
  6f90dd:	00 
  6f90de:	e9 ba 2c 00 00       	jmp    6fbd9d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d5d>
  6f90e3:	b8 08 00 00 00       	mov    $0x8,%eax
  6f90e8:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f90ed:	48 c7 84 24 88 02 00 	movq   $0x0,0x288(%rsp)
  6f90f4:	00 00 00 00 00 
  6f90f9:	4c 8b b4 24 30 04 00 	mov    0x430(%rsp),%r14
  6f9100:	00 
  6f9101:	0f 10 84 24 30 08 00 	movups 0x830(%rsp),%xmm0
  6f9108:	00 
  6f9109:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
  6f9110:	00 
  6f9111:	0f 10 84 24 20 08 00 	movups 0x820(%rsp),%xmm0
  6f9118:	00 
  6f9119:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  6f9120:	00 
  6f9121:	f3 0f 6f 84 24 e0 07 	movdqu 0x7e0(%rsp),%xmm0
  6f9128:	00 00 
  6f912a:	f3 0f 6f 8c 24 f0 07 	movdqu 0x7f0(%rsp),%xmm1
  6f9131:	00 00 
  6f9133:	f3 0f 6f 94 24 00 08 	movdqu 0x800(%rsp),%xmm2
  6f913a:	00 00 
  6f913c:	0f 10 9c 24 10 08 00 	movups 0x810(%rsp),%xmm3
  6f9143:	00 
  6f9144:	0f 29 9c 24 b0 00 00 	movaps %xmm3,0xb0(%rsp)
  6f914b:	00 
  6f914c:	66 0f 7f 94 24 a0 00 	movdqa %xmm2,0xa0(%rsp)
  6f9153:	00 00 
  6f9155:	66 0f 7f 8c 24 90 00 	movdqa %xmm1,0x90(%rsp)
  6f915c:	00 00 
  6f915e:	66 0f 7f 84 24 80 00 	movdqa %xmm0,0x80(%rsp)
  6f9165:	00 00 
  6f9167:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6f916e:	00 
  6f916f:	48 8d 94 24 80 00 00 	lea    0x80(%rsp),%rdx
  6f9176:	00 
  6f9177:	4c 89 f6             	mov    %r14,%rsi
  6f917a:	ff 15 78 2a 39 00    	call   *0x392a78(%rip)        # a8bbf8 <_DYNAMIC+0x6e0>
  6f9180:	4d 85 f6             	test   %r14,%r14
  6f9183:	74 33                	je     6f91b8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2178>
  6f9185:	4a 8d 04 f5 00 00 00 	lea    0x0(,%r14,8),%rax
  6f918c:	00 
  6f918d:	48 8d 1c 40          	lea    (%rax,%rax,2),%rbx
  6f9191:	ff 15 c1 25 39 00    	call   *0x3925c1(%rip)        # a8b758 <_DYNAMIC+0x240>
  6f9197:	be 08 00 00 00       	mov    $0x8,%esi
  6f919c:	48 89 df             	mov    %rbx,%rdi
  6f919f:	ff 15 bb 25 39 00    	call   *0x3925bb(%rip)        # a8b760 <_DYNAMIC+0x248>
  6f91a5:	48 85 c0             	test   %rax,%rax
  6f91a8:	0f 84 7d 4a 00 00    	je     6fdc2b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6beb>
  6f91ae:	48 8b 9c 24 30 01 00 	mov    0x130(%rsp),%rbx
  6f91b5:	00 
  6f91b6:	eb 05                	jmp    6f91bd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x217d>
  6f91b8:	b8 08 00 00 00       	mov    $0x8,%eax
  6f91bd:	4c 89 b4 24 90 02 00 	mov    %r14,0x290(%rsp)
  6f91c4:	00 
  6f91c5:	4c 89 b4 24 68 01 00 	mov    %r14,0x168(%rsp)
  6f91cc:	00 
  6f91cd:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  6f91d4:	00 
  6f91d5:	48 c7 84 24 78 01 00 	movq   $0x0,0x178(%rsp)
  6f91dc:	00 00 00 00 00 
  6f91e1:	49 89 de             	mov    %rbx,%r14
  6f91e4:	49 c1 e6 04          	shl    $0x4,%r14
  6f91e8:	48 89 d8             	mov    %rbx,%rax
  6f91eb:	48 c1 e8 3c          	shr    $0x3c,%rax
  6f91ef:	0f 95 c0             	setne  %al
  6f91f2:	48 b9 01 00 00 00 00 	movabs $0x8000000000000001,%rcx
  6f91f9:	00 00 80 
  6f91fc:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
  6f9200:	49 39 ce             	cmp    %rcx,%r14
  6f9203:	0f 97 c1             	seta   %cl
  6f9206:	08 c1                	or     %al,%cl
  6f9208:	74 14                	je     6f921e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x21de>
  6f920a:	45 31 ff             	xor    %r15d,%r15d
  6f920d:	4c 89 ff             	mov    %r15,%rdi
  6f9210:	4c 89 f6             	mov    %r14,%rsi
  6f9213:	ff 15 17 26 39 00    	call   *0x392617(%rip)        # a8b830 <_DYNAMIC+0x318>
  6f9219:	e9 fd 4a 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6f921e:	bb 08 00 00 00       	mov    $0x8,%ebx
  6f9223:	4d 85 f6             	test   %r14,%r14
  6f9226:	74 69                	je     6f9291 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2251>
  6f9228:	ff 15 2a 25 39 00    	call   *0x39252a(%rip)        # a8b758 <_DYNAMIC+0x240>
  6f922e:	41 bf 08 00 00 00    	mov    $0x8,%r15d
  6f9234:	be 08 00 00 00       	mov    $0x8,%esi
  6f9239:	4c 89 f7             	mov    %r14,%rdi
  6f923c:	ff 15 1e 25 39 00    	call   *0x39251e(%rip)        # a8b760 <_DYNAMIC+0x248>
  6f9242:	48 85 c0             	test   %rax,%rax
  6f9245:	74 c6                	je     6f920d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x21cd>
  6f9247:	48 8b 8c 24 30 01 00 	mov    0x130(%rsp),%rcx
  6f924e:	00 
  6f924f:	eb 47                	jmp    6f9298 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2258>
  6f9251:	f3 0f 6f 84 24 88 00 	movdqu 0x88(%rsp),%xmm0
  6f9258:	00 00 
  6f925a:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6f925f:	48 c7 01 20 00 00 00 	movq   $0x20,(%rcx)
  6f9266:	48 89 41 08          	mov    %rax,0x8(%rcx)
  6f926a:	f3 0f 7f 41 10       	movdqu %xmm0,0x10(%rcx)
  6f926f:	e9 0b 2b 00 00       	jmp    6fbd7f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d3f>
  6f9274:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f9279:	48 89 58 10          	mov    %rbx,0x10(%rax)
  6f927d:	48 c7 00 20 00 00 00 	movq   $0x20,(%rax)
  6f9284:	48 c7 40 08 0c 00 00 	movq   $0xc,0x8(%rax)
  6f928b:	00 
  6f928c:	e9 a6 3f 00 00       	jmp    6fd237 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61f7>
  6f9291:	31 c9                	xor    %ecx,%ecx
  6f9293:	b8 08 00 00 00       	mov    $0x8,%eax
  6f9298:	48 89 8c 24 50 05 00 	mov    %rcx,0x550(%rsp)
  6f929f:	00 
  6f92a0:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
  6f92a7:	00 
  6f92a8:	48 c7 84 24 60 05 00 	movq   $0x0,0x560(%rsp)
  6f92af:	00 00 00 00 00 
  6f92b4:	48 8b 84 24 28 04 00 	mov    0x428(%rsp),%rax
  6f92bb:	00 
  6f92bc:	4c 8b b4 24 90 02 00 	mov    0x290(%rsp),%r14
  6f92c3:	00 
  6f92c4:	4d 85 f6             	test   %r14,%r14
  6f92c7:	74 13                	je     6f92dc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x229c>
  6f92c9:	44 89 f1             	mov    %r14d,%ecx
  6f92cc:	83 e1 03             	and    $0x3,%ecx
  6f92cf:	49 83 fe 04          	cmp    $0x4,%r14
  6f92d3:	73 0f                	jae    6f92e4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x22a4>
  6f92d5:	31 d2                	xor    %edx,%edx
  6f92d7:	45 31 ff             	xor    %r15d,%r15d
  6f92da:	eb 76                	jmp    6f9352 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2312>
  6f92dc:	49 89 c4             	mov    %rax,%r12
  6f92df:	e9 d8 00 00 00       	jmp    6f93bc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x237c>
  6f92e4:	48 be fc ff ff ff ff 	movabs $0xfffffffffffffc,%rsi
  6f92eb:	ff ff 00 
  6f92ee:	4c 21 f6             	and    %r14,%rsi
  6f92f1:	31 d2                	xor    %edx,%edx
  6f92f3:	48 89 c7             	mov    %rax,%rdi
  6f92f6:	45 31 ff             	xor    %r15d,%r15d
  6f92f9:	45 31 c0             	xor    %r8d,%r8d
  6f92fc:	48 83 3f ff          	cmpq   $0xffffffffffffffff,(%rdi)
  6f9300:	41 0f 95 c0          	setne  %r8b
  6f9304:	4d 01 f8             	add    %r15,%r8
  6f9307:	45 31 c9             	xor    %r9d,%r9d
  6f930a:	48 83 bf 98 00 00 00 	cmpq   $0xffffffffffffffff,0x98(%rdi)
  6f9311:	ff 
  6f9312:	41 0f 95 c1          	setne  %r9b
  6f9316:	45 31 d2             	xor    %r10d,%r10d
  6f9319:	48 83 bf 30 01 00 00 	cmpq   $0xffffffffffffffff,0x130(%rdi)
  6f9320:	ff 
  6f9321:	41 0f 95 c2          	setne  %r10b
  6f9325:	4d 01 ca             	add    %r9,%r10
  6f9328:	4d 01 c2             	add    %r8,%r10
  6f932b:	45 31 ff             	xor    %r15d,%r15d
  6f932e:	48 83 bf c8 01 00 00 	cmpq   $0xffffffffffffffff,0x1c8(%rdi)
  6f9335:	ff 
  6f9336:	41 0f 95 c7          	setne  %r15b
  6f933a:	4d 01 d7             	add    %r10,%r15
  6f933d:	48 83 c2 04          	add    $0x4,%rdx
  6f9341:	48 81 c7 60 02 00 00 	add    $0x260,%rdi
  6f9348:	48 39 d6             	cmp    %rdx,%rsi
  6f934b:	75 ac                	jne    6f92f9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x22b9>
  6f934d:	48 85 c9             	test   %rcx,%rcx
  6f9350:	74 2d                	je     6f937f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x233f>
  6f9352:	48 69 d2 98 00 00 00 	imul   $0x98,%rdx,%rdx
  6f9359:	48 01 c2             	add    %rax,%rdx
  6f935c:	48 69 c9 98 00 00 00 	imul   $0x98,%rcx,%rcx
  6f9363:	31 f6                	xor    %esi,%esi
  6f9365:	31 ff                	xor    %edi,%edi
  6f9367:	48 83 3c 32 ff       	cmpq   $0xffffffffffffffff,(%rdx,%rsi,1)
  6f936c:	40 0f 95 c7          	setne  %dil
  6f9370:	49 01 ff             	add    %rdi,%r15
  6f9373:	48 81 c6 98 00 00 00 	add    $0x98,%rsi
  6f937a:	48 39 f1             	cmp    %rsi,%rcx
  6f937d:	75 e6                	jne    6f9365 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2325>
  6f937f:	49 89 c4             	mov    %rax,%r12
  6f9382:	4d 85 ff             	test   %r15,%r15
  6f9385:	74 35                	je     6f93bc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x237c>
  6f9387:	4c 89 f8             	mov    %r15,%rax
  6f938a:	48 c1 e0 04          	shl    $0x4,%rax
  6f938e:	4c 8d 34 80          	lea    (%rax,%rax,4),%r14
  6f9392:	ff 15 c0 23 39 00    	call   *0x3923c0(%rip)        # a8b758 <_DYNAMIC+0x240>
  6f9398:	be 08 00 00 00       	mov    $0x8,%esi
  6f939d:	4c 89 f7             	mov    %r14,%rdi
  6f93a0:	ff 15 ba 23 39 00    	call   *0x3923ba(%rip)        # a8b760 <_DYNAMIC+0x248>
  6f93a6:	48 85 c0             	test   %rax,%rax
  6f93a9:	0f 84 5e 49 00 00    	je     6fdd0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6ccd>
  6f93af:	48 89 c3             	mov    %rax,%rbx
  6f93b2:	4c 8b b4 24 90 02 00 	mov    0x290(%rsp),%r14
  6f93b9:	00 
  6f93ba:	eb 03                	jmp    6f93bf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x237f>
  6f93bc:	45 31 ff             	xor    %r15d,%r15d
  6f93bf:	4c 89 bc 24 68 05 00 	mov    %r15,0x568(%rsp)
  6f93c6:	00 
  6f93c7:	48 89 9c 24 70 05 00 	mov    %rbx,0x570(%rsp)
  6f93ce:	00 
  6f93cf:	48 c7 84 24 78 05 00 	movq   $0x0,0x578(%rsp)
  6f93d6:	00 00 00 00 00 
  6f93db:	4a 8d 1c b5 04 00 00 	lea    0x4(,%r14,4),%rbx
  6f93e2:	00 
  6f93e3:	ff 15 6f 23 39 00    	call   *0x39236f(%rip)        # a8b758 <_DYNAMIC+0x240>
  6f93e9:	be 04 00 00 00       	mov    $0x4,%esi
  6f93ee:	48 89 df             	mov    %rbx,%rdi
  6f93f1:	ff 15 a1 27 39 00    	call   *0x3927a1(%rip)        # a8bb98 <_DYNAMIC+0x680>
  6f93f7:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
  6f93fe:	00 
  6f93ff:	48 85 c0             	test   %rax,%rax
  6f9402:	0f 84 5f 48 00 00    	je     6fdc67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c27>
  6f9408:	48 89 9c 24 80 02 00 	mov    %rbx,0x280(%rsp)
  6f940f:	00 
  6f9410:	49 69 ce 98 00 00 00 	imul   $0x98,%r14,%rcx
  6f9417:	4c 01 e1             	add    %r12,%rcx
  6f941a:	48 8b 84 24 20 04 00 	mov    0x420(%rsp),%rax
  6f9421:	00 
  6f9422:	4c 89 a4 24 d0 06 00 	mov    %r12,0x6d0(%rsp)
  6f9429:	00 
  6f942a:	4c 89 a4 24 d8 06 00 	mov    %r12,0x6d8(%rsp)
  6f9431:	00 
  6f9432:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
  6f9439:	00 
  6f943a:	48 89 8c 24 48 08 00 	mov    %rcx,0x848(%rsp)
  6f9441:	00 
  6f9442:	48 89 8c 24 e8 06 00 	mov    %rcx,0x6e8(%rsp)
  6f9449:	00 
  6f944a:	48 c7 84 24 f0 06 00 	movq   $0x0,0x6f0(%rsp)
  6f9451:	00 00 00 00 00 
  6f9456:	4d 85 f6             	test   %r14,%r14
  6f9459:	4c 8b 7c 24 78       	mov    0x78(%rsp),%r15
  6f945e:	0f 84 8e 1a 00 00    	je     6faef2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3eb2>
  6f9464:	4c 89 e6             	mov    %r12,%rsi
  6f9467:	49 8d 46 01          	lea    0x1(%r14),%rax
  6f946b:	48 89 84 24 e0 03 00 	mov    %rax,0x3e0(%rsp)
  6f9472:	00 
  6f9473:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f9478:	48 05 78 06 00 00    	add    $0x678,%rax
  6f947e:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  6f9485:	00 
  6f9486:	48 8d 05 cb 9c 36 00 	lea    0x369ccb(%rip),%rax        # a63158 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xc98>
  6f948d:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
  6f9494:	00 
  6f9495:	48 8d 05 34 95 36 00 	lea    0x369534(%rip),%rax        # a629d0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x510>
  6f949c:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
  6f94a3:	00 
  6f94a4:	48 8d 05 f5 9c 36 00 	lea    0x369cf5(%rip),%rax        # a631a0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xce0>
  6f94ab:	48 89 84 24 58 06 00 	mov    %rax,0x658(%rsp)
  6f94b2:	00 
  6f94b3:	48 8d 05 5e 95 36 00 	lea    0x36955e(%rip),%rax        # a62a18 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x558>
  6f94ba:	48 89 84 24 d0 03 00 	mov    %rax,0x3d0(%rsp)
  6f94c1:	00 
  6f94c2:	45 31 f6             	xor    %r14d,%r14d
  6f94c5:	45 31 ed             	xor    %r13d,%r13d
  6f94c8:	48 8d 86 98 00 00 00 	lea    0x98(%rsi),%rax
  6f94cf:	48 89 84 24 d8 06 00 	mov    %rax,0x6d8(%rsp)
  6f94d6:	00 
  6f94d7:	48 8b 1e             	mov    (%rsi),%rbx
  6f94da:	48 83 fb fe          	cmp    $0xfffffffffffffffe,%rbx
  6f94de:	0f 84 11 1a 00 00    	je     6faef5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3eb5>
  6f94e4:	48 89 84 24 a0 02 00 	mov    %rax,0x2a0(%rsp)
  6f94eb:	00 
  6f94ec:	4c 89 ac 24 18 02 00 	mov    %r13,0x218(%rsp)
  6f94f3:	00 
  6f94f4:	48 83 c6 08          	add    $0x8,%rsi
  6f94f8:	ba 90 00 00 00       	mov    $0x90,%edx
  6f94fd:	4c 8d bc 24 d0 02 00 	lea    0x2d0(%rsp),%r15
  6f9504:	00 
  6f9505:	4c 89 ff             	mov    %r15,%rdi
  6f9508:	4c 8b 2d 69 22 39 00 	mov    0x392269(%rip),%r13        # a8b778 <memcpy@GLIBC_2.14>
  6f950f:	41 ff d5             	call   *%r13
  6f9512:	49 8d 46 01          	lea    0x1(%r14),%rax
  6f9516:	48 89 84 24 10 05 00 	mov    %rax,0x510(%rsp)
  6f951d:	00 
  6f951e:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
  6f9525:	00 
  6f9526:	48 89 9c 24 80 00 00 	mov    %rbx,0x80(%rsp)
  6f952d:	00 
  6f952e:	ba 90 00 00 00       	mov    $0x90,%edx
  6f9533:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  6f953a:	00 
  6f953b:	4c 89 fe             	mov    %r15,%rsi
  6f953e:	41 ff d5             	call   *%r13
  6f9541:	8b 94 24 98 00 00 00 	mov    0x98(%rsp),%edx
  6f9548:	8b 84 24 9c 00 00 00 	mov    0x9c(%rsp),%eax
  6f954f:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  6f9554:	4c 8d 68 01          	lea    0x1(%rax),%r13
  6f9558:	48 85 d2             	test   %rdx,%rdx
  6f955b:	4c 89 eb             	mov    %r13,%rbx
  6f955e:	48 0f 44 da          	cmove  %rdx,%rbx
  6f9562:	48 3b 9c 24 90 02 00 	cmp    0x290(%rsp),%rbx
  6f9569:	00 
  6f956a:	0f 87 9d 46 00 00    	ja     6fdc0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6bcd>
  6f9570:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
  6f9577:	00 
  6f9578:	8b 04 99             	mov    (%rcx,%rbx,4),%eax
  6f957b:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
  6f9582:	00 
  6f9583:	ff c0                	inc    %eax
  6f9585:	89 04 99             	mov    %eax,(%rcx,%rbx,4)
  6f9588:	48 89 94 24 20 02 00 	mov    %rdx,0x220(%rsp)
  6f958f:	00 
  6f9590:	84 d2                	test   %dl,%dl
  6f9592:	4c 8b bc 24 88 01 00 	mov    0x188(%rsp),%r15
  6f9599:	00 
  6f959a:	0f 84 d1 00 00 00    	je     6f9671 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2631>
  6f95a0:	48 8b 84 24 78 01 00 	mov    0x178(%rsp),%rax
  6f95a7:	00 
  6f95a8:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  6f95ad:	48 39 c8             	cmp    %rcx,%rax
  6f95b0:	0f 86 a3 45 00 00    	jbe    6fdb59 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b19>
  6f95b6:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  6f95bd:	00 
  6f95be:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  6f95c2:	4c 8b 3c c8          	mov    (%rax,%rcx,8),%r15
  6f95c6:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f95cb:	48 8b 80 e8 01 00 00 	mov    0x1e8(%rax),%rax
  6f95d2:	48 85 c0             	test   %rax,%rax
  6f95d5:	0f 84 d6 00 00 00    	je     6f96b1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2671>
  6f95db:	83 f8 01             	cmp    $0x1,%eax
  6f95de:	0f 85 f2 00 00 00    	jne    6f96d6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2696>
  6f95e4:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f95e9:	48 8b 91 f8 01 00 00 	mov    0x1f8(%rcx),%rdx
  6f95f0:	b8 04 00 00 00       	mov    $0x4,%eax
  6f95f5:	48 85 d2             	test   %rdx,%rdx
  6f95f8:	0f 84 55 01 00 00    	je     6f9753 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2713>
  6f95fe:	48 8b 89 f0 01 00 00 	mov    0x1f0(%rcx),%rcx
  6f9605:	31 f6                	xor    %esi,%esi
  6f9607:	48 83 fa 01          	cmp    $0x1,%rdx
  6f960b:	74 24                	je     6f9631 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x25f1>
  6f960d:	48 89 f7             	mov    %rsi,%rdi
  6f9610:	49 89 d0             	mov    %rdx,%r8
  6f9613:	49 d1 e8             	shr    $1,%r8
  6f9616:	4c 01 c6             	add    %r8,%rsi
  6f9619:	49 89 f1             	mov    %rsi,%r9
  6f961c:	49 c1 e1 04          	shl    $0x4,%r9
  6f9620:	4e 39 3c 09          	cmp    %r15,(%rcx,%r9,1)
  6f9624:	48 0f 47 f7          	cmova  %rdi,%rsi
  6f9628:	4c 29 c2             	sub    %r8,%rdx
  6f962b:	48 83 fa 01          	cmp    $0x1,%rdx
  6f962f:	77 dc                	ja     6f960d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x25cd>
  6f9631:	48 89 f7             	mov    %rsi,%rdi
  6f9634:	48 c1 e7 04          	shl    $0x4,%rdi
  6f9638:	31 d2                	xor    %edx,%edx
  6f963a:	4c 39 3c 39          	cmp    %r15,(%rcx,%rdi,1)
  6f963e:	0f 96 c2             	setbe  %dl
  6f9641:	48 01 f2             	add    %rsi,%rdx
  6f9644:	0f 84 07 01 00 00    	je     6f9751 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2711>
  6f964a:	48 c1 e2 04          	shl    $0x4,%rdx
  6f964e:	4c 89 fe             	mov    %r15,%rsi
  6f9651:	48 2b 74 11 f0       	sub    -0x10(%rcx,%rdx,1),%rsi
  6f9656:	8b 7c 11 fc          	mov    -0x4(%rcx,%rdx,1),%edi
  6f965a:	48 39 fe             	cmp    %rdi,%rsi
  6f965d:	0f 83 ee 00 00 00    	jae    6f9751 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2711>
  6f9663:	48 01 d1             	add    %rdx,%rcx
  6f9666:	8b 41 f8             	mov    -0x8(%rcx),%eax
  6f9669:	48 01 c6             	add    %rax,%rsi
  6f966c:	e9 c3 00 00 00       	jmp    6f9734 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x26f4>
  6f9671:	31 ff                	xor    %edi,%edi
  6f9673:	ff 15 d7 24 39 00    	call   *0x3924d7(%rip)        # a8bb50 <_DYNAMIC+0x638>
  6f9679:	48 8d bc 24 c8 07 00 	lea    0x7c8(%rsp),%rdi
  6f9680:	00 
  6f9681:	89 c6                	mov    %eax,%esi
  6f9683:	ff 15 77 25 39 00    	call   *0x392577(%rip)        # a8bc00 <_DYNAMIC+0x6e8>
  6f9689:	31 c9                	xor    %ecx,%ecx
  6f968b:	80 bc 24 60 03 00 00 	cmpb   $0x0,0x360(%rsp)
  6f9692:	00 
  6f9693:	0f 85 cd 00 00 00    	jne    6f9766 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2726>
  6f9699:	31 f6                	xor    %esi,%esi
  6f969b:	48 8b bc 24 68 08 00 	mov    0x868(%rsp),%rdi
  6f96a2:	00 
  6f96a3:	48 85 ff             	test   %rdi,%rdi
  6f96a6:	0f 85 e6 00 00 00    	jne    6f9792 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2752>
  6f96ac:	e9 ce 01 00 00       	jmp    6f987f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x283f>
  6f96b1:	b8 04 00 00 00       	mov    $0x4,%eax
  6f96b6:	4c 89 fe             	mov    %r15,%rsi
  6f96b9:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f96be:	48 2b b1 f0 01 00 00 	sub    0x1f0(%rcx),%rsi
  6f96c5:	0f 82 86 00 00 00    	jb     6f9751 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2711>
  6f96cb:	48 3b b1 f8 01 00 00 	cmp    0x1f8(%rcx),%rsi
  6f96d2:	73 7d                	jae    6f9751 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2711>
  6f96d4:	eb 5e                	jmp    6f9734 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x26f4>
  6f96d6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f96db:	48 8b 91 f8 01 00 00 	mov    0x1f8(%rcx),%rdx
  6f96e2:	b8 04 00 00 00       	mov    $0x4,%eax
  6f96e7:	48 85 d2             	test   %rdx,%rdx
  6f96ea:	74 67                	je     6f9753 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2713>
  6f96ec:	48 8b 89 f0 01 00 00 	mov    0x1f0(%rcx),%rcx
  6f96f3:	48 83 fa 01          	cmp    $0x1,%rdx
  6f96f7:	75 07                	jne    6f9700 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x26c0>
  6f96f9:	4c 39 39             	cmp    %r15,(%rcx)
  6f96fc:	74 33                	je     6f9731 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x26f1>
  6f96fe:	eb 51                	jmp    6f9751 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2711>
  6f9700:	31 f6                	xor    %esi,%esi
  6f9702:	48 89 f7             	mov    %rsi,%rdi
  6f9705:	49 89 d0             	mov    %rdx,%r8
  6f9708:	49 d1 e8             	shr    $1,%r8
  6f970b:	4c 01 c6             	add    %r8,%rsi
  6f970e:	4c 8d 0c 76          	lea    (%rsi,%rsi,2),%r9
  6f9712:	4e 39 3c 89          	cmp    %r15,(%rcx,%r9,4)
  6f9716:	48 0f 47 f7          	cmova  %rdi,%rsi
  6f971a:	4c 29 c2             	sub    %r8,%rdx
  6f971d:	48 83 fa 01          	cmp    $0x1,%rdx
  6f9721:	77 df                	ja     6f9702 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x26c2>
  6f9723:	48 8d 14 76          	lea    (%rsi,%rsi,2),%rdx
  6f9727:	4c 39 3c 91          	cmp    %r15,(%rcx,%rdx,4)
  6f972b:	75 24                	jne    6f9751 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2711>
  6f972d:	48 8d 0c 91          	lea    (%rcx,%rdx,4),%rcx
  6f9731:	8b 71 08             	mov    0x8(%rcx),%esi
  6f9734:	bf 01 00 00 00       	mov    $0x1,%edi
  6f9739:	ff 15 11 24 39 00    	call   *0x392411(%rip)        # a8bb50 <_DYNAMIC+0x638>
  6f973f:	48 8d bc 24 c8 07 00 	lea    0x7c8(%rsp),%rdi
  6f9746:	00 
  6f9747:	89 c6                	mov    %eax,%esi
  6f9749:	ff 15 b1 24 39 00    	call   *0x3924b1(%rip)        # a8bc00 <_DYNAMIC+0x6e8>
  6f974f:	eb 02                	jmp    6f9753 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2713>
  6f9751:	31 d2                	xor    %edx,%edx
  6f9753:	b9 01 00 00 00       	mov    $0x1,%ecx
  6f9758:	80 bc 24 60 03 00 00 	cmpb   $0x0,0x360(%rsp)
  6f975f:	00 
  6f9760:	0f 84 33 ff ff ff    	je     6f9699 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2659>
  6f9766:	48 3b 5c 24 30       	cmp    0x30(%rsp),%rbx
  6f976b:	0f 87 cc 43 00 00    	ja     6fdb3d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6afd>
  6f9771:	48 8b b4 24 b0 02 00 	mov    0x2b0(%rsp),%rsi
  6f9778:	00 
  6f9779:	48 3b 14 de          	cmp    (%rsi,%rbx,8),%rdx
  6f977d:	40 0f 94 c6          	sete   %sil
  6f9781:	48 8b bc 24 68 08 00 	mov    0x868(%rsp),%rdi
  6f9788:	00 
  6f9789:	48 85 ff             	test   %rdi,%rdi
  6f978c:	0f 84 ed 00 00 00    	je     6f987f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x283f>
  6f9792:	4c 8b 84 24 70 08 00 	mov    0x870(%rsp),%r8
  6f9799:	00 
  6f979a:	44 0f b7 97 12 01 00 	movzwl 0x112(%rdi),%r10d
  6f97a1:	00 
  6f97a2:	44 89 d3             	mov    %r10d,%ebx
  6f97a5:	c1 e3 04             	shl    $0x4,%ebx
  6f97a8:	49 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%r9
  6f97af:	45 31 db             	xor    %r11d,%r11d
  6f97b2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f97b9:	1f 84 00 00 00 00 00 
  6f97c0:	4c 39 db             	cmp    %r11,%rbx
  6f97c3:	74 28                	je     6f97ed <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x27ad>
  6f97c5:	4e 3b b4 cf c0 00 00 	cmp    0xc0(%rdi,%r9,8),%r14
  6f97cc:	00 
  6f97cd:	40 0f 97 c5          	seta   %bpl
  6f97d1:	40 80 dd 00          	sbb    $0x0,%bpl
  6f97d5:	49 83 c3 10          	add    $0x10,%r11
  6f97d9:	49 ff c1             	inc    %r9
  6f97dc:	40 80 fd 01          	cmp    $0x1,%bpl
  6f97e0:	74 de                	je     6f97c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2780>
  6f97e2:	44 0f b6 d5          	movzbl %bpl,%r10d
  6f97e6:	45 85 d2             	test   %r10d,%r10d
  6f97e9:	75 05                	jne    6f97f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x27b0>
  6f97eb:	eb 17                	jmp    6f9804 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x27c4>
  6f97ed:	4d 89 d1             	mov    %r10,%r9
  6f97f0:	49 83 e8 01          	sub    $0x1,%r8
  6f97f4:	0f 82 85 00 00 00    	jb     6f987f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x283f>
  6f97fa:	4a 8b bc cf 18 01 00 	mov    0x118(%rdi,%r9,8),%rdi
  6f9801:	00 
  6f9802:	eb 96                	jmp    6f979a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x275a>
  6f9804:	80 bc 24 60 03 00 00 	cmpb   $0x0,0x360(%rsp)
  6f980b:	00 
  6f980c:	0f 84 97 04 00 00    	je     6f9ca9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c69>
  6f9812:	4a 8b 44 1f f8       	mov    -0x8(%rdi,%r11,1),%rax
  6f9817:	48 8b 40 08          	mov    0x8(%rax),%rax
  6f981b:	8b 94 24 10 01 00 00 	mov    0x110(%rsp),%edx
  6f9822:	80 fa 02             	cmp    $0x2,%dl
  6f9825:	be 00 00 00 00       	mov    $0x0,%esi
  6f982a:	0f 42 d6             	cmovb  %esi,%edx
  6f982d:	48 89 8c 24 70 03 00 	mov    %rcx,0x370(%rsp)
  6f9834:	00 
  6f9835:	4c 89 bc 24 78 03 00 	mov    %r15,0x378(%rsp)
  6f983c:	00 
  6f983d:	48 89 84 24 80 03 00 	mov    %rax,0x380(%rsp)
  6f9844:	00 
  6f9845:	88 94 24 88 03 00 00 	mov    %dl,0x388(%rsp)
  6f984c:	48 8b b4 24 70 06 00 	mov    0x670(%rsp),%rsi
  6f9853:	00 
  6f9854:	48 85 f6             	test   %rsi,%rsi
  6f9857:	0f 84 4c 04 00 00    	je     6f9ca9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c69>
  6f985d:	48 8b 94 24 78 06 00 	mov    0x678(%rsp),%rdx
  6f9864:	00 
  6f9865:	48 8d bc 24 90 01 00 	lea    0x190(%rsp),%rdi
  6f986c:	00 
  6f986d:	48 8d 8c 24 70 03 00 	lea    0x370(%rsp),%rcx
  6f9874:	00 
  6f9875:	e8 86 60 fe ff       	call   6df900 <<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Mut, (core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize, alloc::collections::btree::node::marker::LeafOrInternal>>::search_tree::<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind)>>
  6f987a:	e9 e1 00 00 00       	jmp    6f9960 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2920>
  6f987f:	48 8b bc 24 50 08 00 	mov    0x850(%rsp),%rdi
  6f9886:	00 
  6f9887:	48 85 ff             	test   %rdi,%rdi
  6f988a:	0f 84 7a 01 00 00    	je     6f9a0a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x29ca>
  6f9890:	4c 8b 84 24 58 08 00 	mov    0x858(%rsp),%r8
  6f9897:	00 
  6f9898:	44 0f b7 97 ba 00 00 	movzwl 0xba(%rdi),%r10d
  6f989f:	00 
  6f98a0:	45 89 d3             	mov    %r10d,%r11d
  6f98a3:	41 c1 e3 03          	shl    $0x3,%r11d
  6f98a7:	49 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%r9
  6f98ae:	66 90                	xchg   %ax,%ax
  6f98b0:	4d 85 db             	test   %r11,%r11
  6f98b3:	74 22                	je     6f98d7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2897>
  6f98b5:	4e 3b 74 cf 10       	cmp    0x10(%rdi,%r9,8),%r14
  6f98ba:	0f 97 c3             	seta   %bl
  6f98bd:	80 db 00             	sbb    $0x0,%bl
  6f98c0:	49 ff c1             	inc    %r9
  6f98c3:	49 83 c3 f8          	add    $0xfffffffffffffff8,%r11
  6f98c7:	80 fb 01             	cmp    $0x1,%bl
  6f98ca:	74 e4                	je     6f98b0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2870>
  6f98cc:	44 0f b6 d3          	movzbl %bl,%r10d
  6f98d0:	45 85 d2             	test   %r10d,%r10d
  6f98d3:	75 05                	jne    6f98da <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x289a>
  6f98d5:	eb 17                	jmp    6f98ee <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x28ae>
  6f98d7:	4d 89 d1             	mov    %r10,%r9
  6f98da:	49 83 e8 01          	sub    $0x1,%r8
  6f98de:	0f 82 26 01 00 00    	jb     6f9a0a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x29ca>
  6f98e4:	4a 8b bc cf c0 00 00 	mov    0xc0(%rdi,%r9,8),%rdi
  6f98eb:	00 
  6f98ec:	eb aa                	jmp    6f9898 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2858>
  6f98ee:	80 bc 24 60 03 00 00 	cmpb   $0x0,0x360(%rsp)
  6f98f5:	00 
  6f98f6:	0f 84 ad 03 00 00    	je     6f9ca9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c69>
  6f98fc:	4a 8b 44 cf 60       	mov    0x60(%rdi,%r9,8),%rax
  6f9901:	8b 94 24 10 01 00 00 	mov    0x110(%rsp),%edx
  6f9908:	80 fa 02             	cmp    $0x2,%dl
  6f990b:	be 00 00 00 00       	mov    $0x0,%esi
  6f9910:	0f 42 d6             	cmovb  %esi,%edx
  6f9913:	48 89 8c 24 70 03 00 	mov    %rcx,0x370(%rsp)
  6f991a:	00 
  6f991b:	4c 89 bc 24 78 03 00 	mov    %r15,0x378(%rsp)
  6f9922:	00 
  6f9923:	48 89 84 24 80 03 00 	mov    %rax,0x380(%rsp)
  6f992a:	00 
  6f992b:	88 94 24 88 03 00 00 	mov    %dl,0x388(%rsp)
  6f9932:	48 8b b4 24 88 06 00 	mov    0x688(%rsp),%rsi
  6f9939:	00 
  6f993a:	48 85 f6             	test   %rsi,%rsi
  6f993d:	0f 84 66 03 00 00    	je     6f9ca9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c69>
  6f9943:	48 8b 94 24 90 06 00 	mov    0x690(%rsp),%rdx
  6f994a:	00 
  6f994b:	48 8d bc 24 90 01 00 	lea    0x190(%rsp),%rdi
  6f9952:	00 
  6f9953:	48 8d 8c 24 70 03 00 	lea    0x370(%rsp),%rcx
  6f995a:	00 
  6f995b:	e8 a0 5f fe ff       	call   6df900 <<alloc::collections::btree::node::NodeRef<alloc::collections::btree::node::marker::Mut, (core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize, alloc::collections::btree::node::marker::LeafOrInternal>>::search_tree::<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind)>>
  6f9960:	83 bc 24 90 01 00 00 	cmpl   $0x1,0x190(%rsp)
  6f9967:	01 
  6f9968:	0f 84 3b 03 00 00    	je     6f9ca9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c69>
  6f996e:	48 8b 84 24 98 01 00 	mov    0x198(%rsp),%rax
  6f9975:	00 
  6f9976:	48 8b 8c 24 a8 01 00 	mov    0x1a8(%rsp),%rcx
  6f997d:	00 
  6f997e:	4c 8b ac c8 68 01 00 	mov    0x168(%rax,%rcx,8),%r13
  6f9985:	00 
  6f9986:	4c 3b 6c 24 18       	cmp    0x18(%rsp),%r13
  6f998b:	0f 83 60 42 00 00    	jae    6fdbf1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6bb1>
  6f9991:	4a 8d 04 6d 00 00 00 	lea    0x0(,%r13,2),%rax
  6f9998:	00 
  6f9999:	4c 01 e8             	add    %r13,%rax
  6f999c:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  6f99a1:	48 8b 14 c1          	mov    (%rcx,%rax,8),%rdx
  6f99a5:	4c 8b 44 c1 08       	mov    0x8(%rcx,%rax,8),%r8
  6f99aa:	48 8b 5c c1 10       	mov    0x10(%rcx,%rax,8),%rbx
  6f99af:	48 c7 04 c1 00 00 00 	movq   $0x0,(%rcx,%rax,8)
  6f99b6:	00 
  6f99b7:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
  6f99bc:	48 85 d2             	test   %rdx,%rdx
  6f99bf:	0f 84 e4 02 00 00    	je     6f9ca9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c69>
  6f99c5:	4c 89 c0             	mov    %r8,%rax
  6f99c8:	48 c1 e8 22          	shr    $0x22,%rax
  6f99cc:	0f 84 d4 00 00 00    	je     6f9aa6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2a66>
  6f99d2:	48 ff c8             	dec    %rax
  6f99d5:	48 3b 84 24 e8 03 00 	cmp    0x3e8(%rsp),%rax
  6f99dc:	00 
  6f99dd:	0f 83 df 42 00 00    	jae    6fdcc2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c82>
  6f99e3:	48 c1 e0 04          	shl    $0x4,%rax
  6f99e7:	48 8b 8c 24 08 05 00 	mov    0x508(%rsp),%rcx
  6f99ee:	00 
  6f99ef:	48 8b 14 01          	mov    (%rcx,%rax,1),%rdx
  6f99f3:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
  6f99f8:	4c 8b 64 01 08       	mov    0x8(%rcx,%rax,1),%r12
  6f99fd:	48 c7 04 01 00 00 00 	movq   $0x0,(%rcx,%rax,1)
  6f9a04:	00 
  6f9a05:	e9 a5 00 00 00       	jmp    6f9aaf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2a6f>
  6f9a0a:	40 84 f6             	test   %sil,%sil
  6f9a0d:	0f 84 96 02 00 00    	je     6f9ca9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c69>
  6f9a13:	48 8b 8c 24 a8 02 00 	mov    0x2a8(%rsp),%rcx
  6f9a1a:	00 
  6f9a1b:	48 39 ca             	cmp    %rcx,%rdx
  6f9a1e:	0f 86 85 02 00 00    	jbe    6f9ca9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c69>
  6f9a24:	44 8b 2c 88          	mov    (%rax,%rcx,4),%r13d
  6f9a28:	4c 39 6c 24 18       	cmp    %r13,0x18(%rsp)
  6f9a2d:	0f 86 ae 42 00 00    	jbe    6fdce1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6ca1>
  6f9a33:	4a 8d 04 6d 00 00 00 	lea    0x0(,%r13,2),%rax
  6f9a3a:	00 
  6f9a3b:	4c 01 e8             	add    %r13,%rax
  6f9a3e:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  6f9a43:	48 83 3c c1 00       	cmpq   $0x0,(%rcx,%rax,8)
  6f9a48:	0f 84 5b 02 00 00    	je     6f9ca9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c69>
  6f9a4e:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
  6f9a52:	8b 48 10             	mov    0x10(%rax),%ecx
  6f9a55:	83 e1 0f             	and    $0xf,%ecx
  6f9a58:	83 f9 09             	cmp    $0x9,%ecx
  6f9a5b:	0f 87 bc 3f 00 00    	ja     6fda1d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x69dd>
  6f9a61:	0f b6 84 24 10 01 00 	movzbl 0x110(%rsp),%eax
  6f9a68:	00 
  6f9a69:	48 8d 15 24 e3 95 ff 	lea    -0x6a1cdc(%rip),%rdx        # 57d94 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0xcc>
  6f9a70:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
  6f9a74:	48 01 d1             	add    %rdx,%rcx
  6f9a77:	ff e1                	jmp    *%rcx
  6f9a79:	83 f8 0a             	cmp    $0xa,%eax
  6f9a7c:	0f 87 27 02 00 00    	ja     6f9ca9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c69>
  6f9a82:	b9 03 04 00 00       	mov    $0x403,%ecx
  6f9a87:	0f a3 c1             	bt     %eax,%ecx
  6f9a8a:	0f 83 19 02 00 00    	jae    6f9ca9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c69>
  6f9a90:	3c 02                	cmp    $0x2,%al
  6f9a92:	0f 92 c1             	setb   %cl
  6f9a95:	f6 d0                	not    %al
  6f9a97:	08 c8                	or     %cl,%al
  6f9a99:	a8 01                	test   $0x1,%al
  6f9a9b:	0f 85 e5 fe ff ff    	jne    6f9986 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2946>
  6f9aa1:	e9 03 02 00 00       	jmp    6f9ca9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c69>
  6f9aa6:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  6f9aad:	00 00 
  6f9aaf:	48 8b b4 24 60 02 00 	mov    0x260(%rsp),%rsi
  6f9ab6:	00 
  6f9ab7:	49 39 f6             	cmp    %rsi,%r14
  6f9aba:	0f 83 ba 41 00 00    	jae    6fdc7a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c3a>
  6f9ac0:	48 89 df             	mov    %rbx,%rdi
  6f9ac3:	48 c1 ef 20          	shr    $0x20,%rdi
  6f9ac7:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  6f9ace:	00 
  6f9acf:	42 39 3c b0          	cmp    %edi,(%rax,%r14,4)
  6f9ad3:	75 4e                	jne    6f9b23 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2ae3>
  6f9ad5:	48 8b 84 24 a0 06 00 	mov    0x6a0(%rsp),%rax
  6f9adc:	00 
  6f9add:	48 8d 15 d8 e2 95 ff 	lea    -0x6a1d28(%rip),%rdx        # 57dbc <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0xf4>
  6f9ae4:	48 63 0c 82          	movslq (%rdx,%rax,4),%rcx
  6f9ae8:	48 01 d1             	add    %rdx,%rcx
  6f9aeb:	48 8d 05 4e e4 95 ff 	lea    -0x6a1bb2(%rip),%rax        # 57f40 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x278>
  6f9af2:	48 89 bc 24 80 01 00 	mov    %rdi,0x180(%rsp)
  6f9af9:	00 
  6f9afa:	4c 89 84 24 10 02 00 	mov    %r8,0x210(%rsp)
  6f9b01:	00 
  6f9b02:	ff e1                	jmp    *%rcx
  6f9b04:	48 8b b4 24 b8 06 00 	mov    0x6b8(%rsp),%rsi
  6f9b0b:	00 
  6f9b0c:	49 39 f5             	cmp    %rsi,%r13
  6f9b0f:	0f 83 30 42 00 00    	jae    6fdd45 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d05>
  6f9b15:	49 6b c5 58          	imul   $0x58,%r13,%rax
  6f9b19:	48 03 84 24 b0 06 00 	add    0x6b0(%rsp),%rax
  6f9b20:	00 
  6f9b21:	eb 7a                	jmp    6f9b9d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2b5d>
  6f9b23:	48 83 7c 24 40 00    	cmpq   $0x0,0x40(%rsp)
  6f9b29:	0f 84 7a 01 00 00    	je     6f9ca9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c69>
  6f9b2f:	49 8b 04 24          	mov    (%r12),%rax
  6f9b33:	48 85 c0             	test   %rax,%rax
  6f9b36:	74 07                	je     6f9b3f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2aff>
  6f9b38:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  6f9b3d:	ff d0                	call   *%rax
  6f9b3f:	49 8b 74 24 08       	mov    0x8(%r12),%rsi
  6f9b44:	48 85 f6             	test   %rsi,%rsi
  6f9b47:	0f 84 5c 01 00 00    	je     6f9ca9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c69>
  6f9b4d:	49 8b 54 24 10       	mov    0x10(%r12),%rdx
  6f9b52:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  6f9b57:	ff 15 0b 1c 39 00    	call   *0x391c0b(%rip)        # a8b768 <_DYNAMIC+0x250>
  6f9b5d:	e9 47 01 00 00       	jmp    6f9ca9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c69>
  6f9b62:	48 8b b4 24 c0 06 00 	mov    0x6c0(%rsp),%rsi
  6f9b69:	00 
  6f9b6a:	49 39 f5             	cmp    %rsi,%r13
  6f9b6d:	0f 83 ee 41 00 00    	jae    6fdd61 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d21>
  6f9b73:	48 8b b4 24 b0 06 00 	mov    0x6b0(%rsp),%rsi
  6f9b7a:	00 
  6f9b7b:	48 8b 84 24 b8 06 00 	mov    0x6b8(%rsp),%rax
  6f9b82:	00 
  6f9b83:	42 0f b6 04 28       	movzbl (%rax,%r13,1),%eax
  6f9b88:	48 39 c6             	cmp    %rax,%rsi
  6f9b8b:	0f 86 ec 41 00 00    	jbe    6fdd7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6d3d>
  6f9b91:	48 6b c0 58          	imul   $0x58,%rax,%rax
  6f9b95:	48 03 84 24 a8 06 00 	add    0x6a8(%rsp),%rax
  6f9b9c:	00 
  6f9b9d:	48 8b 48 50          	mov    0x50(%rax),%rcx
  6f9ba1:	48 89 8c 24 d0 05 00 	mov    %rcx,0x5d0(%rsp)
  6f9ba8:	00 
  6f9ba9:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  6f9bad:	0f 29 84 24 c0 05 00 	movaps %xmm0,0x5c0(%rsp)
  6f9bb4:	00 
  6f9bb5:	f3 0f 6f 00          	movdqu (%rax),%xmm0
  6f9bb9:	f3 0f 6f 48 10       	movdqu 0x10(%rax),%xmm1
  6f9bbe:	f3 0f 6f 50 20       	movdqu 0x20(%rax),%xmm2
  6f9bc3:	0f 10 58 30          	movups 0x30(%rax),%xmm3
  6f9bc7:	0f 29 9c 24 b0 05 00 	movaps %xmm3,0x5b0(%rsp)
  6f9bce:	00 
  6f9bcf:	66 0f 7f 94 24 a0 05 	movdqa %xmm2,0x5a0(%rsp)
  6f9bd6:	00 00 
  6f9bd8:	66 0f 7f 8c 24 90 05 	movdqa %xmm1,0x590(%rsp)
  6f9bdf:	00 00 
  6f9be1:	66 0f 7f 84 24 80 05 	movdqa %xmm0,0x580(%rsp)
  6f9be8:	00 00 
  6f9bea:	48 8b 6c 24 40       	mov    0x40(%rsp),%rbp
  6f9bef:	eb 1e                	jmp    6f9c0f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2bcf>
  6f9bf1:	48 8b b4 24 a8 06 00 	mov    0x6a8(%rsp),%rsi
  6f9bf8:	00 
  6f9bf9:	48 8d bc 24 80 05 00 	lea    0x580(%rsp),%rdi
  6f9c00:	00 
  6f9c01:	4c 89 ea             	mov    %r13,%rdx
  6f9c04:	48 8b 6c 24 40       	mov    0x40(%rsp),%rbp
  6f9c09:	ff 15 51 1c 39 00    	call   *0x391c51(%rip)        # a8b860 <_DYNAMIC+0x348>
  6f9c0f:	48 8d bc 24 70 03 00 	lea    0x370(%rsp),%rdi
  6f9c16:	00 
  6f9c17:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
  6f9c1e:	00 
  6f9c1f:	4c 89 ea             	mov    %r13,%rdx
  6f9c22:	ff 15 e0 1f 39 00    	call   *0x391fe0(%rip)        # a8bc08 <_DYNAMIC+0x6f0>
  6f9c28:	48 8d bc 24 90 01 00 	lea    0x190(%rsp),%rdi
  6f9c2f:	00 
  6f9c30:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
  6f9c37:	00 
  6f9c38:	4c 89 f2             	mov    %r14,%rdx
  6f9c3b:	ff 15 cf 1f 39 00    	call   *0x391fcf(%rip)        # a8bc10 <_DYNAMIC+0x6f8>
  6f9c41:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  6f9c48:	00 
  6f9c49:	48 3b 84 24 70 03 00 	cmp    0x370(%rsp),%rax
  6f9c50:	00 
  6f9c51:	75 12                	jne    6f9c65 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c25>
  6f9c53:	48 8b 84 24 98 01 00 	mov    0x198(%rsp),%rax
  6f9c5a:	00 
  6f9c5b:	48 3b 84 24 78 03 00 	cmp    0x378(%rsp),%rax
  6f9c62:	00 
  6f9c63:	74 0c                	je     6f9c71 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c31>
  6f9c65:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f9c6a:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6f9c71:	45 31 ed             	xor    %r13d,%r13d
  6f9c74:	e9 69 01 00 00       	jmp    6f9de2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2da2>
  6f9c79:	b1 04                	mov    $0x4,%cl
  6f9c7b:	eb 1a                	jmp    6f9c97 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c57>
  6f9c7d:	b1 02                	mov    $0x2,%cl
  6f9c7f:	eb 16                	jmp    6f9c97 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c57>
  6f9c81:	b1 03                	mov    $0x3,%cl
  6f9c83:	eb 12                	jmp    6f9c97 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c57>
  6f9c85:	b1 07                	mov    $0x7,%cl
  6f9c87:	eb 0e                	jmp    6f9c97 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c57>
  6f9c89:	31 c9                	xor    %ecx,%ecx
  6f9c8b:	eb 0a                	jmp    6f9c97 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c57>
  6f9c8d:	b1 01                	mov    $0x1,%cl
  6f9c8f:	eb 06                	jmp    6f9c97 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c57>
  6f9c91:	b1 05                	mov    $0x5,%cl
  6f9c93:	eb 02                	jmp    6f9c97 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2c57>
  6f9c95:	b1 06                	mov    $0x6,%cl
  6f9c97:	2c 02                	sub    $0x2,%al
  6f9c99:	0f 93 c2             	setae  %dl
  6f9c9c:	38 c8                	cmp    %cl,%al
  6f9c9e:	0f 94 c0             	sete   %al
  6f9ca1:	84 c2                	test   %al,%dl
  6f9ca3:	0f 85 dd fc ff ff    	jne    6f9986 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2946>
  6f9ca9:	48 8d 8c 24 88 00 00 	lea    0x88(%rsp),%rcx
  6f9cb0:	00 
  6f9cb1:	48 8b 41 68          	mov    0x68(%rcx),%rax
  6f9cb5:	48 89 84 24 d0 05 00 	mov    %rax,0x5d0(%rsp)
  6f9cbc:	00 
  6f9cbd:	0f 10 41 58          	movups 0x58(%rcx),%xmm0
  6f9cc1:	0f 29 84 24 c0 05 00 	movaps %xmm0,0x5c0(%rsp)
  6f9cc8:	00 
  6f9cc9:	f3 0f 6f 41 18       	movdqu 0x18(%rcx),%xmm0
  6f9cce:	f3 0f 6f 49 28       	movdqu 0x28(%rcx),%xmm1
  6f9cd3:	f3 0f 6f 51 38       	movdqu 0x38(%rcx),%xmm2
  6f9cd8:	0f 10 59 48          	movups 0x48(%rcx),%xmm3
  6f9cdc:	0f 29 9c 24 b0 05 00 	movaps %xmm3,0x5b0(%rsp)
  6f9ce3:	00 
  6f9ce4:	66 0f 7f 94 24 a0 05 	movdqa %xmm2,0x5a0(%rsp)
  6f9ceb:	00 00 
  6f9ced:	66 0f 7f 8c 24 90 05 	movdqa %xmm1,0x590(%rsp)
  6f9cf4:	00 00 
  6f9cf6:	66 0f 7f 84 24 80 05 	movdqa %xmm0,0x580(%rsp)
  6f9cfd:	00 00 
  6f9cff:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f9d04:	48 8b b1 10 06 00 00 	mov    0x610(%rcx),%rsi
  6f9d0b:	48 8d 46 01          	lea    0x1(%rsi),%rax
  6f9d0f:	48 89 81 10 06 00 00 	mov    %rax,0x610(%rcx)
  6f9d16:	31 ed                	xor    %ebp,%ebp
  6f9d18:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
  6f9d1f:	00 
  6f9d20:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
  6f9d25:	e8 86 f8 00 00       	call   7095b0 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6f9d2a:	48 83 7c 24 20 00    	cmpq   $0x0,0x20(%rsp)
  6f9d30:	0f 84 e5 3a 00 00    	je     6fd81b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x67db>
  6f9d36:	31 ed                	xor    %ebp,%ebp
  6f9d38:	31 ff                	xor    %edi,%edi
  6f9d3a:	31 d2                	xor    %edx,%edx
  6f9d3c:	31 c9                	xor    %ecx,%ecx
  6f9d3e:	ff 15 d4 1e 39 00    	call   *0x391ed4(%rip)        # a8bc18 <_DYNAMIC+0x700>
  6f9d44:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  6f9d4b:	00 
  6f9d4c:	0f b6 84 24 10 01 00 	movzbl 0x110(%rsp),%eax
  6f9d53:	00 
  6f9d54:	8d 48 fe             	lea    -0x2(%rax),%ecx
  6f9d57:	83 f8 02             	cmp    $0x2,%eax
  6f9d5a:	0f b6 c9             	movzbl %cl,%ecx
  6f9d5d:	ba 08 00 00 00       	mov    $0x8,%edx
  6f9d62:	0f 42 ca             	cmovb  %edx,%ecx
  6f9d65:	0f b6 d9             	movzbl %cl,%ebx
  6f9d68:	48 8d 15 5d e0 95 ff 	lea    -0x6a1fa3(%rip),%rdx        # 57dcc <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x104>
  6f9d6f:	48 63 0c 9a          	movslq (%rdx,%rbx,4),%rcx
  6f9d73:	48 01 d1             	add    %rdx,%rcx
  6f9d76:	ff e1                	jmp    *%rcx
  6f9d78:	bb 01 00 00 00       	mov    $0x1,%ebx
  6f9d7d:	eb 32                	jmp    6f9db1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d71>
  6f9d7f:	bb 04 00 00 00       	mov    $0x4,%ebx
  6f9d84:	eb 2b                	jmp    6f9db1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d71>
  6f9d86:	bb 02 00 00 00       	mov    $0x2,%ebx
  6f9d8b:	eb 24                	jmp    6f9db1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d71>
  6f9d8d:	bb 03 00 00 00       	mov    $0x3,%ebx
  6f9d92:	eb 1d                	jmp    6f9db1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d71>
  6f9d94:	bb 07 00 00 00       	mov    $0x7,%ebx
  6f9d99:	eb 16                	jmp    6f9db1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d71>
  6f9d9b:	bb 05 00 00 00       	mov    $0x5,%ebx
  6f9da0:	eb 0f                	jmp    6f9db1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d71>
  6f9da2:	bb 06 00 00 00       	mov    $0x6,%ebx
  6f9da7:	eb 08                	jmp    6f9db1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2d71>
  6f9da9:	83 e0 01             	and    $0x1,%eax
  6f9dac:	83 c8 08             	or     $0x8,%eax
  6f9daf:	89 c3                	mov    %eax,%ebx
  6f9db1:	48 8b b4 24 60 02 00 	mov    0x260(%rsp),%rsi
  6f9db8:	00 
  6f9db9:	49 39 f6             	cmp    %rsi,%r14
  6f9dbc:	0f 83 b7 3c 00 00    	jae    6fda79 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a39>
  6f9dc2:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  6f9dc9:	00 
  6f9dca:	42 8b 04 b0          	mov    (%rax,%r14,4),%eax
  6f9dce:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  6f9dd5:	00 
  6f9dd6:	41 b5 01             	mov    $0x1,%r13b
  6f9dd9:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  6f9de0:	00 00 
  6f9de2:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
  6f9de7:	89 dd                	mov    %ebx,%ebp
  6f9de9:	83 e5 0f             	and    $0xf,%ebp
  6f9dec:	83 fd 09             	cmp    $0x9,%ebp
  6f9def:	0f 87 c7 3a 00 00    	ja     6fd8bc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x687c>
  6f9df5:	83 fd 06             	cmp    $0x6,%ebp
  6f9df8:	74 7d                	je     6f9e77 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2e37>
  6f9dfa:	89 d8                	mov    %ebx,%eax
  6f9dfc:	c1 e8 04             	shr    $0x4,%eax
  6f9dff:	74 76                	je     6f9e77 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2e37>
  6f9e01:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f9e06:	48 8b b1 b8 02 00 00 	mov    0x2b8(%rcx),%rsi
  6f9e0d:	ff c8                	dec    %eax
  6f9e0f:	48 39 c6             	cmp    %rax,%rsi
  6f9e12:	0f 86 fd 3c 00 00    	jbe    6fdb15 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6ad5>
  6f9e18:	48 8b 89 b0 02 00 00 	mov    0x2b0(%rcx),%rcx
  6f9e1f:	48 8d 04 80          	lea    (%rax,%rax,4),%rax
  6f9e23:	48 c1 e0 04          	shl    $0x4,%rax
  6f9e27:	0f 10 44 01 40       	movups 0x40(%rcx,%rax,1),%xmm0
  6f9e2c:	0f 29 84 24 90 04 00 	movaps %xmm0,0x490(%rsp)
  6f9e33:	00 
  6f9e34:	f3 0f 6f 04 01       	movdqu (%rcx,%rax,1),%xmm0
  6f9e39:	f3 0f 6f 4c 01 10    	movdqu 0x10(%rcx,%rax,1),%xmm1
  6f9e3f:	f3 0f 6f 54 01 20    	movdqu 0x20(%rcx,%rax,1),%xmm2
  6f9e45:	0f 10 5c 01 30       	movups 0x30(%rcx,%rax,1),%xmm3
  6f9e4a:	0f 29 9c 24 80 04 00 	movaps %xmm3,0x480(%rsp)
  6f9e51:	00 
  6f9e52:	66 0f 7f 94 24 70 04 	movdqa %xmm2,0x470(%rsp)
  6f9e59:	00 00 
  6f9e5b:	66 0f 7f 8c 24 60 04 	movdqa %xmm1,0x460(%rsp)
  6f9e62:	00 00 
  6f9e64:	66 0f 7f 84 24 50 04 	movdqa %xmm0,0x450(%rsp)
  6f9e6b:	00 00 
  6f9e6d:	48 c7 04 01 fe ff ff 	movq   $0xfffffffffffffffe,(%rcx,%rax,1)
  6f9e74:	ff 
  6f9e75:	eb 0c                	jmp    6f9e83 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2e43>
  6f9e77:	48 c7 84 24 50 04 00 	movq   $0xfffffffffffffffe,0x450(%rsp)
  6f9e7e:	00 fe ff ff ff 
  6f9e83:	89 df                	mov    %ebx,%edi
  6f9e85:	ff 15 cd 19 39 00    	call   *0x3919cd(%rip)        # a8b858 <_DYNAMIC+0x340>
  6f9e8b:	b1 02                	mov    $0x2,%cl
  6f9e8d:	80 fa 02             	cmp    $0x2,%dl
  6f9e90:	74 35                	je     6f9ec7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2e87>
  6f9e92:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f9e97:	48 8b 89 f0 05 00 00 	mov    0x5f0(%rcx),%rcx
  6f9e9e:	48 85 c9             	test   %rcx,%rcx
  6f9ea1:	0f 84 a0 39 00 00    	je     6fd847 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6807>
  6f9ea7:	89 c7                	mov    %eax,%edi
  6f9ea9:	48 8b 71 10          	mov    0x10(%rcx),%rsi
  6f9ead:	48 39 fe             	cmp    %rdi,%rsi
  6f9eb0:	0f 86 cf 3c 00 00    	jbe    6fdb85 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b45>
  6f9eb6:	48 8b 41 08          	mov    0x8(%rcx),%rax
  6f9eba:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
  6f9ebe:	48 8b 78 28          	mov    0x28(%rax),%rdi
  6f9ec2:	80 e2 01             	and    $0x1,%dl
  6f9ec5:	89 d1                	mov    %edx,%ecx
  6f9ec7:	48 8b 84 24 b0 07 00 	mov    0x7b0(%rsp),%rax
  6f9ece:	00 
  6f9ecf:	48 85 c0             	test   %rax,%rax
  6f9ed2:	0f 84 af 00 00 00    	je     6f9f87 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f47>
  6f9ed8:	48 8b 94 24 b8 07 00 	mov    0x7b8(%rsp),%rdx
  6f9edf:	00 
  6f9ee0:	0f b7 b0 ba 00 00 00 	movzwl 0xba(%rax),%esi
  6f9ee7:	41 89 f1             	mov    %esi,%r9d
  6f9eea:	41 c1 e1 03          	shl    $0x3,%r9d
  6f9eee:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
  6f9ef5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6f9efc:	00 00 00 00 
  6f9f00:	4d 85 c9             	test   %r9,%r9
  6f9f03:	74 24                	je     6f9f29 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2ee9>
  6f9f05:	4e 3b 74 c0 10       	cmp    0x10(%rax,%r8,8),%r14
  6f9f0a:	41 0f 97 c2          	seta   %r10b
  6f9f0e:	41 80 da 00          	sbb    $0x0,%r10b
  6f9f12:	49 ff c0             	inc    %r8
  6f9f15:	49 83 c1 f8          	add    $0xfffffffffffffff8,%r9
  6f9f19:	41 80 fa 01          	cmp    $0x1,%r10b
  6f9f1d:	74 e1                	je     6f9f00 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2ec0>
  6f9f1f:	41 0f b6 f2          	movzbl %r10b,%esi
  6f9f23:	85 f6                	test   %esi,%esi
  6f9f25:	75 05                	jne    6f9f2c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2eec>
  6f9f27:	eb 13                	jmp    6f9f3c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2efc>
  6f9f29:	49 89 f0             	mov    %rsi,%r8
  6f9f2c:	48 83 ea 01          	sub    $0x1,%rdx
  6f9f30:	72 55                	jb     6f9f87 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f47>
  6f9f32:	4a 8b 84 c0 c0 00 00 	mov    0xc0(%rax,%r8,8),%rax
  6f9f39:	00 
  6f9f3a:	eb a4                	jmp    6f9ee0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2ea0>
  6f9f3c:	42 8b 5c c0 60       	mov    0x60(%rax,%r8,8),%ebx
  6f9f41:	48 8b b4 24 b0 04 00 	mov    0x4b0(%rsp),%rsi
  6f9f48:	00 
  6f9f49:	48 39 de             	cmp    %rbx,%rsi
  6f9f4c:	0f 86 ae 3b 00 00    	jbe    6fdb00 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6ac0>
  6f9f52:	42 0f b6 44 c0 64    	movzbl 0x64(%rax,%r8,8),%eax
  6f9f58:	88 84 24 e8 01 00 00 	mov    %al,0x1e8(%rsp)
  6f9f5f:	45 31 e4             	xor    %r12d,%r12d
  6f9f62:	80 f9 02             	cmp    $0x2,%cl
  6f9f65:	74 30                	je     6f9f97 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f57>
  6f9f67:	48 8b 84 24 a8 04 00 	mov    0x4a8(%rsp),%rax
  6f9f6e:	00 
  6f9f6f:	48 8b 04 d8          	mov    (%rax,%rbx,8),%rax
  6f9f73:	48 3b 78 28          	cmp    0x28(%rax),%rdi
  6f9f77:	75 1e                	jne    6f9f97 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f57>
  6f9f79:	32 8c 24 e8 01 00 00 	xor    0x1e8(%rsp),%cl
  6f9f80:	f6 c1 01             	test   $0x1,%cl
  6f9f83:	74 33                	je     6f9fb8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f78>
  6f9f85:	eb 10                	jmp    6f9f97 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f57>
  6f9f87:	c6 84 24 e8 01 00 00 	movb   $0x2,0x1e8(%rsp)
  6f9f8e:	02 
  6f9f8f:	41 b4 01             	mov    $0x1,%r12b
  6f9f92:	80 f9 02             	cmp    $0x2,%cl
  6f9f95:	74 21                	je     6f9fb8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2f78>
  6f9f97:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
  6f9f9e:	00 
  6f9f9f:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  6f9fa4:	e8 07 f6 00 00       	call   7095b0 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6f9fa9:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f9fae:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6f9fb5:	41 b5 01             	mov    $0x1,%r13b
  6f9fb8:	83 fd 09             	cmp    $0x9,%ebp
  6f9fbb:	0f 87 19 39 00 00    	ja     6fd8da <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x689a>
  6f9fc1:	89 e8                	mov    %ebp,%eax
  6f9fc3:	48 8d 0d 26 de 95 ff 	lea    -0x6a21da(%rip),%rcx        # 57df0 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x128>
  6f9fca:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
  6f9fce:	48 01 c8             	add    %rcx,%rax
  6f9fd1:	ff e0                	jmp    *%rax
  6f9fd3:	b0 02                	mov    $0x2,%al
  6f9fd5:	eb 21                	jmp    6f9ff8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fb8>
  6f9fd7:	b0 06                	mov    $0x6,%al
  6f9fd9:	eb 1d                	jmp    6f9ff8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fb8>
  6f9fdb:	b0 01                	mov    $0x1,%al
  6f9fdd:	e9 c1 03 00 00       	jmp    6fa3a3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3363>
  6f9fe2:	b0 04                	mov    $0x4,%al
  6f9fe4:	eb 12                	jmp    6f9ff8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fb8>
  6f9fe6:	b0 05                	mov    $0x5,%al
  6f9fe8:	eb 0e                	jmp    6f9ff8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fb8>
  6f9fea:	b0 09                	mov    $0x9,%al
  6f9fec:	eb 0a                	jmp    6f9ff8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fb8>
  6f9fee:	b0 03                	mov    $0x3,%al
  6f9ff0:	eb 06                	jmp    6f9ff8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fb8>
  6f9ff2:	b0 07                	mov    $0x7,%al
  6f9ff4:	eb 02                	jmp    6f9ff8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fb8>
  6f9ff6:	b0 08                	mov    $0x8,%al
  6f9ff8:	0f b6 8c 24 10 01 00 	movzbl 0x110(%rsp),%ecx
  6f9fff:	00 
  6fa000:	8d 50 fe             	lea    -0x2(%rax),%edx
  6fa003:	89 ce                	mov    %ecx,%esi
  6fa005:	40 80 ee 02          	sub    $0x2,%sil
  6fa009:	40 0f b6 f6          	movzbl %sil,%esi
  6fa00d:	bf 08 00 00 00       	mov    $0x8,%edi
  6fa012:	0f 42 f7             	cmovb  %edi,%esi
  6fa015:	40 38 f2             	cmp    %sil,%dl
  6fa018:	75 0f                	jne    6fa029 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fe9>
  6fa01a:	80 fa 08             	cmp    $0x8,%dl
  6fa01d:	0f 95 c2             	setne  %dl
  6fa020:	38 c8                	cmp    %cl,%al
  6fa022:	0f 94 c0             	sete   %al
  6fa025:	08 d0                	or     %dl,%al
  6fa027:	75 0f                	jne    6fa038 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2ff8>
  6fa029:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fa02e:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6fa035:	41 b5 01             	mov    $0x1,%r13b
  6fa038:	48 83 bc 24 80 00 00 	cmpq   $0xffffffffffffffff,0x80(%rsp)
  6fa03f:	00 ff 
  6fa041:	4c 89 bc 24 88 01 00 	mov    %r15,0x188(%rsp)
  6fa048:	00 
  6fa049:	48 89 9c 24 f8 03 00 	mov    %rbx,0x3f8(%rsp)
  6fa050:	00 
  6fa051:	44 89 a4 24 00 04 00 	mov    %r12d,0x400(%rsp)
  6fa058:	00 
  6fa059:	74 72                	je     6fa0cd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x308d>
  6fa05b:	48 8d bc 24 90 01 00 	lea    0x190(%rsp),%rdi
  6fa062:	00 
  6fa063:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6fa06a:	00 
  6fa06b:	ff 15 af 1b 39 00    	call   *0x391baf(%rip)        # a8bc20 <_DYNAMIC+0x708>
  6fa071:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
  6fa078:	00 
  6fa079:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fa07e:	48 ff 80 f0 06 00 00 	incq   0x6f0(%rax)
  6fa085:	48 8b 84 24 98 01 00 	mov    0x198(%rsp),%rax
  6fa08c:	00 
  6fa08d:	48 89 84 24 f0 03 00 	mov    %rax,0x3f0(%rsp)
  6fa094:	00 
  6fa095:	48 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%rbx
  6fa09c:	00 
  6fa09d:	4c 8b a4 24 50 04 00 	mov    0x450(%rsp),%r12
  6fa0a4:	00 
  6fa0a5:	49 83 fc fe          	cmp    $0xfffffffffffffffe,%r12
  6fa0a9:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
  6fa0ae:	75 47                	jne    6fa0f7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x30b7>
  6fa0b0:	48 83 f9 fe          	cmp    $0xfffffffffffffffe,%rcx
  6fa0b4:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
  6fa0b9:	0f 85 94 00 00 00    	jne    6fa153 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3113>
  6fa0bf:	48 c7 44 24 58 fe ff 	movq   $0xfffffffffffffffe,0x58(%rsp)
  6fa0c6:	ff ff 
  6fa0c8:	e9 02 04 00 00       	jmp    6fa4cf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x348f>
  6fa0cd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fa0d2:	48 ff 80 f0 06 00 00 	incq   0x6f0(%rax)
  6fa0d9:	48 c7 44 24 58 fe ff 	movq   $0xfffffffffffffffe,0x58(%rsp)
  6fa0e0:	ff ff 
  6fa0e2:	48 83 bc 24 50 04 00 	cmpq   $0xfffffffffffffffe,0x450(%rsp)
  6fa0e9:	00 fe 
  6fa0eb:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
  6fa0f0:	75 15                	jne    6fa107 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x30c7>
  6fa0f2:	e9 d8 03 00 00       	jmp    6fa4cf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x348f>
  6fa0f7:	48 83 f9 fe          	cmp    $0xfffffffffffffffe,%rcx
  6fa0fb:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
  6fa100:	75 21                	jne    6fa123 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x30e3>
  6fa102:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fa107:	c6 80 48 07 00 00 01 	movb   $0x1,0x748(%rax)
  6fa10e:	48 c7 c3 fe ff ff ff 	mov    $0xfffffffffffffffe,%rbx
  6fa115:	48 c7 44 24 58 fe ff 	movq   $0xfffffffffffffffe,0x58(%rsp)
  6fa11c:	ff ff 
  6fa11e:	e9 29 03 00 00       	jmp    6fa44c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x340c>
  6fa123:	48 8b bc 24 90 04 00 	mov    0x490(%rsp),%rdi
  6fa12a:	00 
  6fa12b:	48 8b 07             	mov    (%rdi),%rax
  6fa12e:	48 d1 e8             	shr    $1,%rax
  6fa131:	48 39 d8             	cmp    %rbx,%rax
  6fa134:	75 1d                	jne    6fa153 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3113>
  6fa136:	48 83 c7 10          	add    $0x10,%rdi
  6fa13a:	48 8b b4 24 f0 03 00 	mov    0x3f0(%rsp),%rsi
  6fa141:	00 
  6fa142:	48 89 da             	mov    %rbx,%rdx
  6fa145:	ff 15 fd 17 39 00    	call   *0x3917fd(%rip)        # a8b948 <bcmp@GLIBC_2.2.5>
  6fa14b:	85 c0                	test   %eax,%eax
  6fa14d:	0f 84 7c 03 00 00    	je     6fa4cf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x348f>
  6fa153:	49 83 fc fe          	cmp    $0xfffffffffffffffe,%r12
  6fa157:	0f 94 c0             	sete   %al
  6fa15a:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6fa15f:	08 81 48 07 00 00    	or     %al,0x748(%rcx)
  6fa165:	48 8b b4 24 48 02 00 	mov    0x248(%rsp),%rsi
  6fa16c:	00 
  6fa16d:	49 39 f6             	cmp    %rsi,%r14
  6fa170:	0f 83 33 3a 00 00    	jae    6fdba9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b69>
  6fa176:	4c 8b a4 24 40 02 00 	mov    0x240(%rsp),%r12
  6fa17d:	00 
  6fa17e:	4b 8b 04 f4          	mov    (%r12,%r14,8),%rax
  6fa182:	48 85 c0             	test   %rax,%rax
  6fa185:	74 78                	je     6fa1ff <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x31bf>
  6fa187:	48 8b 8c 24 38 04 00 	mov    0x438(%rsp),%rcx
  6fa18e:	00 
  6fa18f:	48 85 c9             	test   %rcx,%rcx
  6fa192:	74 6b                	je     6fa1ff <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x31bf>
  6fa194:	48 8b 94 24 40 04 00 	mov    0x440(%rsp),%rdx
  6fa19b:	00 
  6fa19c:	0f b7 b9 ba 00 00 00 	movzwl 0xba(%rcx),%edi
  6fa1a3:	41 89 f8             	mov    %edi,%r8d
  6fa1a6:	41 c1 e0 03          	shl    $0x3,%r8d
  6fa1aa:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
  6fa1b1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fa1b8:	0f 1f 84 00 00 00 00 
  6fa1bf:	00 
  6fa1c0:	4d 85 c0             	test   %r8,%r8
  6fa1c3:	74 27                	je     6fa1ec <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x31ac>
  6fa1c5:	48 3b 44 f1 10       	cmp    0x10(%rcx,%rsi,8),%rax
  6fa1ca:	41 0f 97 c1          	seta   %r9b
  6fa1ce:	41 80 d9 00          	sbb    $0x0,%r9b
  6fa1d2:	48 ff c6             	inc    %rsi
  6fa1d5:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  6fa1d9:	41 80 f9 01          	cmp    $0x1,%r9b
  6fa1dd:	74 e1                	je     6fa1c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3180>
  6fa1df:	41 0f b6 f9          	movzbl %r9b,%edi
  6fa1e3:	85 ff                	test   %edi,%edi
  6fa1e5:	75 08                	jne    6fa1ef <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x31af>
  6fa1e7:	e9 64 01 00 00       	jmp    6fa350 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3310>
  6fa1ec:	48 89 fe             	mov    %rdi,%rsi
  6fa1ef:	48 83 ea 01          	sub    $0x1,%rdx
  6fa1f3:	72 0a                	jb     6fa1ff <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x31bf>
  6fa1f5:	48 8b 8c f1 c0 00 00 	mov    0xc0(%rcx,%rsi,8),%rcx
  6fa1fc:	00 
  6fa1fd:	eb 9d                	jmp    6fa19c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x315c>
  6fa1ff:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fa204:	f3 0f 6f 80 f8 06 00 	movdqu 0x6f8(%rax),%xmm0
  6fa20b:	00 
  6fa20c:	66 48 0f 6e cb       	movq   %rbx,%xmm1
  6fa211:	66 0f 6f 15 47 cd 95 	movdqa -0x6a32b9(%rip),%xmm2        # 56f60 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x920>
  6fa218:	ff 
  6fa219:	66 0f 6c d1          	punpcklqdq %xmm1,%xmm2
  6fa21d:	66 0f d4 d0          	paddq  %xmm0,%xmm2
  6fa221:	f3 0f 7f 90 f8 06 00 	movdqu %xmm2,0x6f8(%rax)
  6fa228:	00 
  6fa229:	48 8d 05 f0 d4 95 ff 	lea    -0x6a2b10(%rip),%rax        # 57720 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x10e0>
  6fa230:	48 89 84 24 00 02 00 	mov    %rax,0x200(%rsp)
  6fa237:	00 
  6fa238:	48 85 db             	test   %rbx,%rbx
  6fa23b:	74 57                	je     6fa294 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3254>
  6fa23d:	40 b5 01             	mov    $0x1,%bpl
  6fa240:	41 b5 01             	mov    $0x1,%r13b
  6fa243:	48 8d bc 24 90 01 00 	lea    0x190(%rsp),%rdi
  6fa24a:	00 
  6fa24b:	48 89 de             	mov    %rbx,%rsi
  6fa24e:	31 d2                	xor    %edx,%edx
  6fa250:	31 c9                	xor    %ecx,%ecx
  6fa252:	ff 15 f8 16 39 00    	call   *0x3916f8(%rip)        # a8b950 <_DYNAMIC+0x438>
  6fa258:	48 8b bc 24 90 01 00 	mov    0x190(%rsp),%rdi
  6fa25f:	00 
  6fa260:	48 83 ff ff          	cmp    $0xffffffffffffffff,%rdi
  6fa264:	0f 85 e7 39 00 00    	jne    6fdc51 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c11>
  6fa26a:	48 8b 84 24 98 01 00 	mov    0x198(%rsp),%rax
  6fa271:	00 
  6fa272:	48 89 84 24 00 02 00 	mov    %rax,0x200(%rsp)
  6fa279:	00 
  6fa27a:	48 8d 78 10          	lea    0x10(%rax),%rdi
  6fa27e:	48 8b b4 24 f0 03 00 	mov    0x3f0(%rsp),%rsi
  6fa285:	00 
  6fa286:	48 89 da             	mov    %rbx,%rdx
  6fa289:	ff 15 e9 14 39 00    	call   *0x3914e9(%rip)        # a8b778 <memcpy@GLIBC_2.14>
  6fa28f:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
  6fa294:	4b 8b 04 f4          	mov    (%r12,%r14,8),%rax
  6fa298:	48 85 c0             	test   %rax,%rax
  6fa29b:	0f 84 8d 01 00 00    	je     6fa42e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33ee>
  6fa2a1:	4c 8b 94 24 00 02 00 	mov    0x200(%rsp),%r10
  6fa2a8:	00 
  6fa2a9:	41 f6 02 01          	testb  $0x1,(%r10)
  6fa2ad:	75 2f                	jne    6fa2de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x329e>
  6fa2af:	49 8b 4a 08          	mov    0x8(%r10),%rcx
  6fa2b3:	f6 c1 01             	test   $0x1,%cl
  6fa2b6:	75 26                	jne    6fa2de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x329e>
  6fa2b8:	b9 02 00 00 00       	mov    $0x2,%ecx
  6fa2bd:	f0 49 0f c1 4a 08    	lock xadd %rcx,0x8(%r10)
  6fa2c3:	48 ba 01 00 00 00 00 	movabs $0x8000000000000001,%rdx
  6fa2ca:	00 00 80 
  6fa2cd:	48 21 d1             	and    %rdx,%rcx
  6fa2d0:	48 ff ca             	dec    %rdx
  6fa2d3:	48 39 d1             	cmp    %rdx,%rcx
  6fa2d6:	75 06                	jne    6fa2de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x329e>
  6fa2d8:	f0 49 83 4a 08 01    	lock orq $0x1,0x8(%r10)
  6fa2de:	48 8b 8c 24 38 04 00 	mov    0x438(%rsp),%rcx
  6fa2e5:	00 
  6fa2e6:	48 85 c9             	test   %rcx,%rcx
  6fa2e9:	0f 84 f1 00 00 00    	je     6fa3e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33a0>
  6fa2ef:	48 8b 94 24 40 04 00 	mov    0x440(%rsp),%rdx
  6fa2f6:	00 
  6fa2f7:	0f b7 b9 ba 00 00 00 	movzwl 0xba(%rcx),%edi
  6fa2fe:	41 89 f8             	mov    %edi,%r8d
  6fa301:	41 c1 e0 03          	shl    $0x3,%r8d
  6fa305:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
  6fa30c:	0f 1f 40 00          	nopl   0x0(%rax)
  6fa310:	4d 85 c0             	test   %r8,%r8
  6fa313:	74 24                	je     6fa339 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x32f9>
  6fa315:	48 3b 44 f1 10       	cmp    0x10(%rcx,%rsi,8),%rax
  6fa31a:	41 0f 97 c1          	seta   %r9b
  6fa31e:	41 80 d9 00          	sbb    $0x0,%r9b
  6fa322:	48 ff c6             	inc    %rsi
  6fa325:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  6fa329:	41 80 f9 01          	cmp    $0x1,%r9b
  6fa32d:	74 e1                	je     6fa310 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x32d0>
  6fa32f:	41 0f b6 f9          	movzbl %r9b,%edi
  6fa333:	85 ff                	test   %edi,%edi
  6fa335:	75 05                	jne    6fa33c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x32fc>
  6fa337:	eb 79                	jmp    6fa3b2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3372>
  6fa339:	48 89 fe             	mov    %rdi,%rsi
  6fa33c:	48 83 ea 01          	sub    $0x1,%rdx
  6fa340:	0f 82 9c 00 00 00    	jb     6fa3e2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33a2>
  6fa346:	48 8b 8c f1 c0 00 00 	mov    0xc0(%rcx,%rsi,8),%rcx
  6fa34d:	00 
  6fa34e:	eb a7                	jmp    6fa2f7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x32b7>
  6fa350:	48 8b 54 f1 60       	mov    0x60(%rcx,%rsi,8),%rdx
  6fa355:	f6 02 01             	testb  $0x1,(%rdx)
  6fa358:	48 89 94 24 00 02 00 	mov    %rdx,0x200(%rsp)
  6fa35f:	00 
  6fa360:	0f 85 c8 00 00 00    	jne    6fa42e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33ee>
  6fa366:	48 8b 42 08          	mov    0x8(%rdx),%rax
  6fa36a:	a8 01                	test   $0x1,%al
  6fa36c:	0f 85 bc 00 00 00    	jne    6fa42e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33ee>
  6fa372:	b8 02 00 00 00       	mov    $0x2,%eax
  6fa377:	f0 48 0f c1 42 08    	lock xadd %rax,0x8(%rdx)
  6fa37d:	48 b9 01 00 00 00 00 	movabs $0x8000000000000001,%rcx
  6fa384:	00 00 80 
  6fa387:	48 21 c8             	and    %rcx,%rax
  6fa38a:	48 ff c9             	dec    %rcx
  6fa38d:	48 39 c8             	cmp    %rcx,%rax
  6fa390:	0f 85 98 00 00 00    	jne    6fa42e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33ee>
  6fa396:	f0 48 83 4a 08 01    	lock orq $0x1,0x8(%rdx)
  6fa39c:	e9 8d 00 00 00       	jmp    6fa42e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33ee>
  6fa3a1:	31 c0                	xor    %eax,%eax
  6fa3a3:	b2 08                	mov    $0x8,%dl
  6fa3a5:	0f b6 8c 24 10 01 00 	movzbl 0x110(%rsp),%ecx
  6fa3ac:	00 
  6fa3ad:	e9 51 fc ff ff       	jmp    6fa003 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2fc3>
  6fa3b2:	48 8b 7c f1 60       	mov    0x60(%rcx,%rsi,8),%rdi
  6fa3b7:	4c 89 54 f1 60       	mov    %r10,0x60(%rcx,%rsi,8)
  6fa3bc:	f6 07 01             	testb  $0x1,(%rdi)
  6fa3bf:	75 6d                	jne    6fa42e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33ee>
  6fa3c1:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fa3c5:	a8 01                	test   $0x1,%al
  6fa3c7:	75 65                	jne    6fa42e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33ee>
  6fa3c9:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6fa3cd:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6fa3d2:	75 5a                	jne    6fa42e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33ee>
  6fa3d4:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fa3d8:	ff 15 d2 13 39 00    	call   *0x3913d2(%rip)        # a8b7b0 <_DYNAMIC+0x298>
  6fa3de:	eb 4e                	jmp    6fa42e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x33ee>
  6fa3e0:	31 c9                	xor    %ecx,%ecx
  6fa3e2:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  6fa3e9:	00 
  6fa3ea:	48 8d 84 24 38 04 00 	lea    0x438(%rsp),%rax
  6fa3f1:	00 
  6fa3f2:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
  6fa3f9:	00 
  6fa3fa:	48 89 8c 24 a0 01 00 	mov    %rcx,0x1a0(%rsp)
  6fa401:	00 
  6fa402:	48 c7 84 24 a8 01 00 	movq   $0x0,0x1a8(%rsp)
  6fa409:	00 00 00 00 00 
  6fa40e:	48 89 b4 24 b0 01 00 	mov    %rsi,0x1b0(%rsp)
  6fa415:	00 
  6fa416:	48 8d bc 24 70 03 00 	lea    0x370(%rsp),%rdi
  6fa41d:	00 
  6fa41e:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
  6fa425:	00 
  6fa426:	4c 89 d2             	mov    %r10,%rdx
  6fa429:	e8 32 73 01 00       	call   711760 <<alloc::collections::btree::map::entry::VacantEntry<gpui::source::FieldId, gpui::shared_text::SharedText>>::insert_entry>
  6fa42e:	4b 8b 04 f4          	mov    (%r12,%r14,8),%rax
  6fa432:	48 89 84 24 68 06 00 	mov    %rax,0x668(%rsp)
  6fa439:	00 
  6fa43a:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
  6fa441:	48 83 bc 24 50 04 00 	cmpq   $0xfffffffffffffffe,0x450(%rsp)
  6fa448:	00 fe 
  6fa44a:	74 31                	je     6fa47d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x343d>
  6fa44c:	48 8b bc 24 90 04 00 	mov    0x490(%rsp),%rdi
  6fa453:	00 
  6fa454:	f6 07 01             	testb  $0x1,(%rdi)
  6fa457:	75 17                	jne    6fa470 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3430>
  6fa459:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fa45d:	a8 01                	test   $0x1,%al
  6fa45f:	75 0f                	jne    6fa470 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3430>
  6fa461:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6fa465:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6fa46a:	0f 84 73 0a 00 00    	je     6faee3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3ea3>
  6fa470:	48 8d bc 24 50 04 00 	lea    0x450(%rsp),%rdi
  6fa477:	00 
  6fa478:	e8 d3 81 fe ff       	call   6e2650 <core::ptr::drop_glue::<core::option::Option<gpui::runtime::Shaped>>>
  6fa47d:	48 89 9c 24 50 04 00 	mov    %rbx,0x450(%rsp)
  6fa484:	00 
  6fa485:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
  6fa48c:	00 
  6fa48d:	48 89 84 24 90 04 00 	mov    %rax,0x490(%rsp)
  6fa494:	00 
  6fa495:	48 8b 84 24 68 06 00 	mov    0x668(%rsp),%rax
  6fa49c:	00 
  6fa49d:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
  6fa4a4:	00 
  6fa4a5:	40 b5 01             	mov    $0x1,%bpl
  6fa4a8:	41 b5 01             	mov    $0x1,%r13b
  6fa4ab:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
  6fa4b2:	00 
  6fa4b3:	4c 89 fe             	mov    %r15,%rsi
  6fa4b6:	e8 f5 f0 00 00       	call   7095b0 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6fa4bb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fa4c0:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6fa4c7:	41 b5 01             	mov    $0x1,%r13b
  6fa4ca:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
  6fa4cf:	48 8d 8c 24 88 00 00 	lea    0x88(%rsp),%rcx
  6fa4d6:	00 
  6fa4d7:	48 8b 41 68          	mov    0x68(%rcx),%rax
  6fa4db:	48 89 84 24 c0 03 00 	mov    %rax,0x3c0(%rsp)
  6fa4e2:	00 
  6fa4e3:	0f 10 41 58          	movups 0x58(%rcx),%xmm0
  6fa4e7:	0f 29 84 24 b0 03 00 	movaps %xmm0,0x3b0(%rsp)
  6fa4ee:	00 
  6fa4ef:	f3 0f 6f 41 18       	movdqu 0x18(%rcx),%xmm0
  6fa4f4:	f3 0f 6f 49 28       	movdqu 0x28(%rcx),%xmm1
  6fa4f9:	f3 0f 6f 51 38       	movdqu 0x38(%rcx),%xmm2
  6fa4fe:	0f 10 59 48          	movups 0x48(%rcx),%xmm3
  6fa502:	0f 29 9c 24 a0 03 00 	movaps %xmm3,0x3a0(%rsp)
  6fa509:	00 
  6fa50a:	66 0f 7f 94 24 90 03 	movdqa %xmm2,0x390(%rsp)
  6fa511:	00 00 
  6fa513:	66 0f 7f 8c 24 80 03 	movdqa %xmm1,0x380(%rsp)
  6fa51a:	00 00 
  6fa51c:	66 0f 7f 84 24 70 03 	movdqa %xmm0,0x370(%rsp)
  6fa523:	00 00 
  6fa525:	48 8b 84 24 10 04 00 	mov    0x410(%rsp),%rax
  6fa52c:	00 
  6fa52d:	48 8b 18             	mov    (%rax),%rbx
  6fa530:	48 8d 84 24 f8 05 00 	lea    0x5f8(%rsp),%rax
  6fa537:	00 
  6fa538:	48 85 db             	test   %rbx,%rbx
  6fa53b:	0f 84 01 01 00 00    	je     6fa642 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3602>
  6fa541:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fa546:	48 8b 80 30 06 00 00 	mov    0x630(%rax),%rax
  6fa54d:	0f b7 93 32 05 00 00 	movzwl 0x532(%rbx),%edx
  6fa554:	48 6b fa 70          	imul   $0x70,%rdx,%rdi
  6fa558:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
  6fa55f:	31 f6                	xor    %esi,%esi
  6fa561:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fa568:	0f 1f 84 00 00 00 00 
  6fa56f:	00 
  6fa570:	49 89 f8             	mov    %rdi,%r8
  6fa573:	49 01 f0             	add    %rsi,%r8
  6fa576:	74 27                	je     6fa59f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x355f>
  6fa578:	4c 3b bc cb e0 04 00 	cmp    0x4e0(%rbx,%rcx,8),%r15
  6fa57f:	00 
  6fa580:	41 0f 97 c0          	seta   %r8b
  6fa584:	41 80 d8 00          	sbb    $0x0,%r8b
  6fa588:	48 83 c6 90          	add    $0xffffffffffffff90,%rsi
  6fa58c:	48 ff c1             	inc    %rcx
  6fa58f:	41 80 f8 01          	cmp    $0x1,%r8b
  6fa593:	74 db                	je     6fa570 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3530>
  6fa595:	41 0f b6 d0          	movzbl %r8b,%edx
  6fa599:	85 d2                	test   %edx,%edx
  6fa59b:	75 05                	jne    6fa5a2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3562>
  6fa59d:	eb 17                	jmp    6fa5b6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3576>
  6fa59f:	48 89 d1             	mov    %rdx,%rcx
  6fa5a2:	48 83 e8 01          	sub    $0x1,%rax
  6fa5a6:	0f 82 2a 09 00 00    	jb     6faed6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3e96>
  6fa5ac:	48 8b 9c cb 38 05 00 	mov    0x538(%rbx,%rcx,8),%rbx
  6fa5b3:	00 
  6fa5b4:	eb 97                	jmp    6fa54d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x350d>
  6fa5b6:	45 89 ec             	mov    %r13d,%r12d
  6fa5b9:	48 29 f3             	sub    %rsi,%rbx
  6fa5bc:	48 8d 53 e8          	lea    -0x18(%rbx),%rdx
  6fa5c0:	48 8d 8c 24 88 00 00 	lea    0x88(%rsp),%rcx
  6fa5c7:	00 
  6fa5c8:	48 8b 41 68          	mov    0x68(%rcx),%rax
  6fa5cc:	48 89 84 24 e0 01 00 	mov    %rax,0x1e0(%rsp)
  6fa5d3:	00 
  6fa5d4:	0f 10 41 58          	movups 0x58(%rcx),%xmm0
  6fa5d8:	0f 29 84 24 d0 01 00 	movaps %xmm0,0x1d0(%rsp)
  6fa5df:	00 
  6fa5e0:	f3 0f 6f 41 18       	movdqu 0x18(%rcx),%xmm0
  6fa5e5:	f3 0f 6f 49 28       	movdqu 0x28(%rcx),%xmm1
  6fa5ea:	f3 0f 6f 51 38       	movdqu 0x38(%rcx),%xmm2
  6fa5ef:	0f 10 59 48          	movups 0x48(%rcx),%xmm3
  6fa5f3:	0f 29 9c 24 c0 01 00 	movaps %xmm3,0x1c0(%rsp)
  6fa5fa:	00 
  6fa5fb:	66 0f 7f 94 24 b0 01 	movdqa %xmm2,0x1b0(%rsp)
  6fa602:	00 00 
  6fa604:	66 0f 7f 8c 24 a0 01 	movdqa %xmm1,0x1a0(%rsp)
  6fa60b:	00 00 
  6fa60d:	66 0f 7f 84 24 90 01 	movdqa %xmm0,0x190(%rsp)
  6fa614:	00 00 
  6fa616:	40 b5 01             	mov    $0x1,%bpl
  6fa619:	41 b5 01             	mov    $0x1,%r13b
  6fa61c:	48 8d bc 24 f8 05 00 	lea    0x5f8(%rsp),%rdi
  6fa623:	00 
  6fa624:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
  6fa62b:	00 
  6fa62c:	31 c9                	xor    %ecx,%ecx
  6fa62e:	e8 dd 0c 02 00       	call   71b310 <gpui::property::apply_except::<gpui::style::Style>>
  6fa633:	48 83 c3 90          	add    $0xffffffffffffff90,%rbx
  6fa637:	48 89 d8             	mov    %rbx,%rax
  6fa63a:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
  6fa63f:	45 89 e5             	mov    %r12d,%r13d
  6fa642:	48 8b 8c 24 c0 03 00 	mov    0x3c0(%rsp),%rcx
  6fa649:	00 
  6fa64a:	48 89 48 50          	mov    %rcx,0x50(%rax)
  6fa64e:	0f 28 84 24 b0 03 00 	movaps 0x3b0(%rsp),%xmm0
  6fa655:	00 
  6fa656:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  6fa65a:	66 0f 6f 84 24 70 03 	movdqa 0x370(%rsp),%xmm0
  6fa661:	00 00 
  6fa663:	66 0f 6f 8c 24 80 03 	movdqa 0x380(%rsp),%xmm1
  6fa66a:	00 00 
  6fa66c:	66 0f 6f 94 24 90 03 	movdqa 0x390(%rsp),%xmm2
  6fa673:	00 00 
  6fa675:	0f 28 9c 24 a0 03 00 	movaps 0x3a0(%rsp),%xmm3
  6fa67c:	00 
  6fa67d:	0f 11 58 30          	movups %xmm3,0x30(%rax)
  6fa681:	f3 0f 7f 50 20       	movdqu %xmm2,0x20(%rax)
  6fa686:	f3 0f 7f 48 10       	movdqu %xmm1,0x10(%rax)
  6fa68b:	f3 0f 7f 00          	movdqu %xmm0,(%rax)
  6fa68f:	8b ac 24 80 05 00 00 	mov    0x580(%rsp),%ebp
  6fa696:	0f b6 9c 24 f8 05 00 	movzbl 0x5f8(%rsp),%ebx
  6fa69d:	00 
  6fa69e:	83 fd 01             	cmp    $0x1,%ebp
  6fa6a1:	75 1a                	jne    6fa6bd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x367d>
  6fa6a3:	8b 84 24 fc 05 00 00 	mov    0x5fc(%rsp),%eax
  6fa6aa:	39 84 24 84 05 00 00 	cmp    %eax,0x584(%rsp)
  6fa6b1:	0f 94 c0             	sete   %al
  6fa6b4:	84 c3                	test   %al,%bl
  6fa6b6:	75 0e                	jne    6fa6c6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3686>
  6fa6b8:	e9 1c 01 00 00       	jmp    6fa7d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3799>
  6fa6bd:	f6 c3 01             	test   $0x1,%bl
  6fa6c0:	0f 85 13 01 00 00    	jne    6fa7d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3799>
  6fa6c6:	0f b6 84 24 00 06 00 	movzbl 0x600(%rsp),%eax
  6fa6cd:	00 
  6fa6ce:	83 bc 24 88 05 00 00 	cmpl   $0x1,0x588(%rsp)
  6fa6d5:	01 
  6fa6d6:	75 1a                	jne    6fa6f2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x36b2>
  6fa6d8:	8b 8c 24 04 06 00 00 	mov    0x604(%rsp),%ecx
  6fa6df:	39 8c 24 8c 05 00 00 	cmp    %ecx,0x58c(%rsp)
  6fa6e6:	0f 94 c1             	sete   %cl
  6fa6e9:	84 c8                	test   %cl,%al
  6fa6eb:	75 0d                	jne    6fa6fa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x36ba>
  6fa6ed:	e9 e7 00 00 00       	jmp    6fa7d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3799>
  6fa6f2:	a8 01                	test   $0x1,%al
  6fa6f4:	0f 85 df 00 00 00    	jne    6fa7d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3799>
  6fa6fa:	8b 84 24 90 05 00 00 	mov    0x590(%rsp),%eax
  6fa701:	3b 84 24 08 06 00 00 	cmp    0x608(%rsp),%eax
  6fa708:	0f 85 cb 00 00 00    	jne    6fa7d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3799>
  6fa70e:	8b 84 24 94 05 00 00 	mov    0x594(%rsp),%eax
  6fa715:	3b 84 24 0c 06 00 00 	cmp    0x60c(%rsp),%eax
  6fa71c:	0f 85 b7 00 00 00    	jne    6fa7d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3799>
  6fa722:	8b 84 24 98 05 00 00 	mov    0x598(%rsp),%eax
  6fa729:	3b 84 24 10 06 00 00 	cmp    0x610(%rsp),%eax
  6fa730:	0f 85 a3 00 00 00    	jne    6fa7d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3799>
  6fa736:	0f b6 84 24 d4 05 00 	movzbl 0x5d4(%rsp),%eax
  6fa73d:	00 
  6fa73e:	3a 84 24 4c 06 00 00 	cmp    0x64c(%rsp),%al
  6fa745:	0f 85 8e 00 00 00    	jne    6fa7d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3799>
  6fa74b:	0f b6 84 24 d6 05 00 	movzbl 0x5d6(%rsp),%eax
  6fa752:	00 
  6fa753:	3a 84 24 4e 06 00 00 	cmp    0x64e(%rsp),%al
  6fa75a:	75 7d                	jne    6fa7d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3799>
  6fa75c:	0f b6 84 24 d7 05 00 	movzbl 0x5d7(%rsp),%eax
  6fa763:	00 
  6fa764:	3a 84 24 4f 06 00 00 	cmp    0x64f(%rsp),%al
  6fa76b:	75 6c                	jne    6fa7d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3799>
  6fa76d:	0f b6 84 24 d5 05 00 	movzbl 0x5d5(%rsp),%eax
  6fa774:	00 
  6fa775:	3a 84 24 4d 06 00 00 	cmp    0x64d(%rsp),%al
  6fa77c:	75 5b                	jne    6fa7d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3799>
  6fa77e:	48 8d bc 24 bc 05 00 	lea    0x5bc(%rsp),%rdi
  6fa785:	00 
  6fa786:	48 8d b4 24 34 06 00 	lea    0x634(%rsp),%rsi
  6fa78d:	00 
  6fa78e:	e8 1d 63 00 00       	call   700ab0 <<gpui_reactivity_core::geometry::Affine as gpui::property::ExactValue>::same>
  6fa793:	84 c0                	test   %al,%al
  6fa795:	74 42                	je     6fa7d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3799>
  6fa797:	f3 0f 6f 84 24 9c 05 	movdqu 0x59c(%rsp),%xmm0
  6fa79e:	00 00 
  6fa7a0:	f3 0f 6f 8c 24 14 06 	movdqu 0x614(%rsp),%xmm1
  6fa7a7:	00 00 
  6fa7a9:	66 0f 74 c8          	pcmpeqb %xmm0,%xmm1
  6fa7ad:	66 0f d7 c1          	pmovmskb %xmm1,%eax
  6fa7b1:	3d ff ff 00 00       	cmp    $0xffff,%eax
  6fa7b6:	75 21                	jne    6fa7d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3799>
  6fa7b8:	f3 0f 6f 84 24 ac 05 	movdqu 0x5ac(%rsp),%xmm0
  6fa7bf:	00 00 
  6fa7c1:	f3 0f 6f 8c 24 24 06 	movdqu 0x624(%rsp),%xmm1
  6fa7c8:	00 00 
  6fa7ca:	66 0f 74 c8          	pcmpeqb %xmm0,%xmm1
  6fa7ce:	66 0f d7 c1          	pmovmskb %xmm1,%eax
  6fa7d2:	3d ff ff 00 00       	cmp    $0xffff,%eax
  6fa7d7:	74 0f                	je     6fa7e8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x37a8>
  6fa7d9:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fa7de:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6fa7e5:	41 b5 01             	mov    $0x1,%r13b
  6fa7e8:	40 f6 c5 01          	test   $0x1,%bpl
  6fa7ec:	74 28                	je     6fa816 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x37d6>
  6fa7ee:	f6 c3 01             	test   $0x1,%bl
  6fa7f1:	0f 84 f0 00 00 00    	je     6fa8e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38a7>
  6fa7f7:	f3 0f 10 84 24 84 05 	movss  0x584(%rsp),%xmm0
  6fa7fe:	00 00 
  6fa800:	0f 2e 84 24 fc 05 00 	ucomiss 0x5fc(%rsp),%xmm0
  6fa807:	00 
  6fa808:	0f 85 d9 00 00 00    	jne    6fa8e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38a7>
  6fa80e:	0f 8a d3 00 00 00    	jp     6fa8e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38a7>
  6fa814:	eb 09                	jmp    6fa81f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x37df>
  6fa816:	f6 c3 01             	test   $0x1,%bl
  6fa819:	0f 85 c8 00 00 00    	jne    6fa8e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38a7>
  6fa81f:	0f b6 84 24 00 06 00 	movzbl 0x600(%rsp),%eax
  6fa826:	00 
  6fa827:	83 bc 24 88 05 00 00 	cmpl   $0x1,0x588(%rsp)
  6fa82e:	01 
  6fa82f:	75 27                	jne    6fa858 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3818>
  6fa831:	84 c0                	test   %al,%al
  6fa833:	0f 84 ae 00 00 00    	je     6fa8e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38a7>
  6fa839:	f3 0f 10 84 24 8c 05 	movss  0x58c(%rsp),%xmm0
  6fa840:	00 00 
  6fa842:	0f 2e 84 24 04 06 00 	ucomiss 0x604(%rsp),%xmm0
  6fa849:	00 
  6fa84a:	0f 85 97 00 00 00    	jne    6fa8e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38a7>
  6fa850:	0f 8a 91 00 00 00    	jp     6fa8e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38a7>
  6fa856:	eb 08                	jmp    6fa860 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3820>
  6fa858:	84 c0                	test   %al,%al
  6fa85a:	0f 85 87 00 00 00    	jne    6fa8e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38a7>
  6fa860:	f3 0f 10 84 24 90 05 	movss  0x590(%rsp),%xmm0
  6fa867:	00 00 
  6fa869:	0f 2e 84 24 08 06 00 	ucomiss 0x608(%rsp),%xmm0
  6fa870:	00 
  6fa871:	75 74                	jne    6fa8e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38a7>
  6fa873:	7a 72                	jp     6fa8e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38a7>
  6fa875:	f3 0f 10 84 24 94 05 	movss  0x594(%rsp),%xmm0
  6fa87c:	00 00 
  6fa87e:	0f 2e 84 24 0c 06 00 	ucomiss 0x60c(%rsp),%xmm0
  6fa885:	00 
  6fa886:	75 5f                	jne    6fa8e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38a7>
  6fa888:	7a 5d                	jp     6fa8e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38a7>
  6fa88a:	f3 0f 10 84 24 98 05 	movss  0x598(%rsp),%xmm0
  6fa891:	00 00 
  6fa893:	f3 0f 10 8c 24 10 06 	movss  0x610(%rsp),%xmm1
  6fa89a:	00 00 
  6fa89c:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6fa89f:	75 46                	jne    6fa8e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38a7>
  6fa8a1:	7a 44                	jp     6fa8e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38a7>
  6fa8a3:	0f b6 84 24 d4 05 00 	movzbl 0x5d4(%rsp),%eax
  6fa8aa:	00 
  6fa8ab:	3a 84 24 4c 06 00 00 	cmp    0x64c(%rsp),%al
  6fa8b2:	75 33                	jne    6fa8e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38a7>
  6fa8b4:	0f b6 84 24 d6 05 00 	movzbl 0x5d6(%rsp),%eax
  6fa8bb:	00 
  6fa8bc:	3a 84 24 4e 06 00 00 	cmp    0x64e(%rsp),%al
  6fa8c3:	75 22                	jne    6fa8e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38a7>
  6fa8c5:	0f b6 84 24 d7 05 00 	movzbl 0x5d7(%rsp),%eax
  6fa8cc:	00 
  6fa8cd:	3a 84 24 4f 06 00 00 	cmp    0x64f(%rsp),%al
  6fa8d4:	75 11                	jne    6fa8e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38a7>
  6fa8d6:	0f b6 84 24 d5 05 00 	movzbl 0x5d5(%rsp),%eax
  6fa8dd:	00 
  6fa8de:	3a 84 24 4d 06 00 00 	cmp    0x64d(%rsp),%al
  6fa8e5:	74 33                	je     6fa91a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38da>
  6fa8e7:	44 89 eb             	mov    %r13d,%ebx
  6fa8ea:	40 b5 01             	mov    $0x1,%bpl
  6fa8ed:	41 b5 01             	mov    $0x1,%r13b
  6fa8f0:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
  6fa8f7:	00 
  6fa8f8:	4c 89 fe             	mov    %r15,%rsi
  6fa8fb:	e8 b0 ec 00 00       	call   7095b0 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6fa900:	f3 0f 10 84 24 98 05 	movss  0x598(%rsp),%xmm0
  6fa907:	00 00 
  6fa909:	f3 0f 10 8c 24 10 06 	movss  0x610(%rsp),%xmm1
  6fa910:	00 00 
  6fa912:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
  6fa917:	41 89 dd             	mov    %ebx,%r13d
  6fa91a:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6fa91d:	48 8b 9c 24 10 02 00 	mov    0x210(%rsp),%rbx
  6fa924:	00 
  6fa925:	75 02                	jne    6fa929 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x38e9>
  6fa927:	7b 24                	jnp    6fa94d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x390d>
  6fa929:	48 83 bc 24 50 04 00 	cmpq   $0xfffffffffffffffe,0x450(%rsp)
  6fa930:	00 fe 
  6fa932:	74 19                	je     6fa94d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x390d>
  6fa934:	48 8d bc 24 50 04 00 	lea    0x450(%rsp),%rdi
  6fa93b:	00 
  6fa93c:	e8 0f 7d fe ff       	call   6e2650 <core::ptr::drop_glue::<core::option::Option<gpui::runtime::Shaped>>>
  6fa941:	48 c7 84 24 50 04 00 	movq   $0xffffffffffffffff,0x450(%rsp)
  6fa948:	00 ff ff ff ff 
  6fa94d:	48 c1 eb 22          	shr    $0x22,%rbx
  6fa951:	0f 95 c0             	setne  %al
  6fa954:	48 83 bc 24 f8 00 00 	cmpq   $0x0,0xf8(%rsp)
  6fa95b:	00 00 
  6fa95d:	0f 95 c1             	setne  %cl
  6fa960:	38 c8                	cmp    %cl,%al
  6fa962:	74 0f                	je     6fa973 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3933>
  6fa964:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fa969:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6fa970:	41 b5 01             	mov    $0x1,%r13b
  6fa973:	44 89 ac 24 10 02 00 	mov    %r13d,0x210(%rsp)
  6fa97a:	00 
  6fa97b:	40 b5 01             	mov    $0x1,%bpl
  6fa97e:	41 b5 01             	mov    $0x1,%r13b
  6fa981:	48 8d bc 24 70 03 00 	lea    0x370(%rsp),%rdi
  6fa988:	00 
  6fa989:	48 8b b4 24 10 04 00 	mov    0x410(%rsp),%rsi
  6fa990:	00 
  6fa991:	4c 89 fa             	mov    %r15,%rdx
  6fa994:	48 8b 0d 4d 0f 39 00 	mov    0x390f4d(%rip),%rcx        # a8b8e8 <_DYNAMIC+0x3d0>
  6fa99b:	e8 a0 02 02 00       	call   71ac40 <<gpui::property::Overrides>::get::<gpui_canvas::color::Color>>
  6fa9a0:	8b 9c 24 70 03 00 00 	mov    0x370(%rsp),%ebx
  6fa9a7:	40 b5 01             	mov    $0x1,%bpl
  6fa9aa:	41 b5 01             	mov    $0x1,%r13b
  6fa9ad:	48 8d bc 24 90 01 00 	lea    0x190(%rsp),%rdi
  6fa9b4:	00 
  6fa9b5:	48 8b b4 24 10 04 00 	mov    0x410(%rsp),%rsi
  6fa9bc:	00 
  6fa9bd:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6fa9c2:	48 8b 0d 27 0f 39 00 	mov    0x390f27(%rip),%rcx        # a8b8f0 <_DYNAMIC+0x3d8>
  6fa9c9:	e8 72 02 02 00       	call   71ac40 <<gpui::property::Overrides>::get::<gpui_canvas::color::Color>>
  6fa9ce:	0f b6 84 24 90 01 00 	movzbl 0x190(%rsp),%eax
  6fa9d5:	00 
  6fa9d6:	00 c0                	add    %al,%al
  6fa9d8:	08 d8                	or     %bl,%al
  6fa9da:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
  6fa9e1:	00 
  6fa9e2:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
  6fa9e6:	48 89 8c 24 c0 03 00 	mov    %rcx,0x3c0(%rsp)
  6fa9ed:	00 
  6fa9ee:	0f 10 42 58          	movups 0x58(%rdx),%xmm0
  6fa9f2:	0f 29 84 24 b0 03 00 	movaps %xmm0,0x3b0(%rsp)
  6fa9f9:	00 
  6fa9fa:	0f 10 42 18          	movups 0x18(%rdx),%xmm0
  6fa9fe:	0f 10 4a 28          	movups 0x28(%rdx),%xmm1
  6faa02:	0f 10 52 38          	movups 0x38(%rdx),%xmm2
  6faa06:	0f 10 5a 48          	movups 0x48(%rdx),%xmm3
  6faa0a:	0f 29 9c 24 a0 03 00 	movaps %xmm3,0x3a0(%rsp)
  6faa11:	00 
  6faa12:	0f 29 94 24 90 03 00 	movaps %xmm2,0x390(%rsp)
  6faa19:	00 
  6faa1a:	0f 29 8c 24 80 03 00 	movaps %xmm1,0x380(%rsp)
  6faa21:	00 
  6faa22:	0f 29 84 24 70 03 00 	movaps %xmm0,0x370(%rsp)
  6faa29:	00 
  6faa2a:	48 8b 8c 24 48 06 00 	mov    0x648(%rsp),%rcx
  6faa31:	00 
  6faa32:	48 89 8c 24 e0 01 00 	mov    %rcx,0x1e0(%rsp)
  6faa39:	00 
  6faa3a:	0f 10 84 24 38 06 00 	movups 0x638(%rsp),%xmm0
  6faa41:	00 
  6faa42:	0f 29 84 24 d0 01 00 	movaps %xmm0,0x1d0(%rsp)
  6faa49:	00 
  6faa4a:	f3 0f 6f 84 24 f8 05 	movdqu 0x5f8(%rsp),%xmm0
  6faa51:	00 00 
  6faa53:	f3 0f 6f 8c 24 08 06 	movdqu 0x608(%rsp),%xmm1
  6faa5a:	00 00 
  6faa5c:	f3 0f 6f 94 24 18 06 	movdqu 0x618(%rsp),%xmm2
  6faa63:	00 00 
  6faa65:	0f 10 9c 24 28 06 00 	movups 0x628(%rsp),%xmm3
  6faa6c:	00 
  6faa6d:	0f 29 9c 24 c0 01 00 	movaps %xmm3,0x1c0(%rsp)
  6faa74:	00 
  6faa75:	66 0f 7f 94 24 b0 01 	movdqa %xmm2,0x1b0(%rsp)
  6faa7c:	00 00 
  6faa7e:	66 0f 7f 8c 24 a0 01 	movdqa %xmm1,0x1a0(%rsp)
  6faa85:	00 00 
  6faa87:	66 0f 7f 84 24 90 01 	movdqa %xmm0,0x190(%rsp)
  6faa8e:	00 00 
  6faa90:	40 b5 01             	mov    $0x1,%bpl
  6faa93:	44 0f b6 c0          	movzbl %al,%r8d
  6faa97:	41 b5 01             	mov    $0x1,%r13b
  6faa9a:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6faaa1:	00 
  6faaa2:	4c 89 f6             	mov    %r14,%rsi
  6faaa5:	48 8d 94 24 70 03 00 	lea    0x370(%rsp),%rdx
  6faaac:	00 
  6faaad:	48 8d 8c 24 90 01 00 	lea    0x190(%rsp),%rcx
  6faab4:	00 
  6faab5:	ff 15 6d 11 39 00    	call   *0x39116d(%rip)        # a8bc28 <_DYNAMIC+0x710>
  6faabb:	4c 8b 7c 24 40       	mov    0x40(%rsp),%r15
  6faac0:	4d 85 ff             	test   %r15,%r15
  6faac3:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
  6faac8:	4c 8b 64 24 48       	mov    0x48(%rsp),%r12
  6faacd:	74 23                	je     6faaf2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3ab2>
  6faacf:	48 8b 03             	mov    (%rbx),%rax
  6faad2:	48 85 c0             	test   %rax,%rax
  6faad5:	74 05                	je     6faadc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3a9c>
  6faad7:	4c 89 ff             	mov    %r15,%rdi
  6faada:	ff d0                	call   *%rax
  6faadc:	48 8b 73 08          	mov    0x8(%rbx),%rsi
  6faae0:	48 85 f6             	test   %rsi,%rsi
  6faae3:	74 0d                	je     6faaf2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3ab2>
  6faae5:	48 8b 53 10          	mov    0x10(%rbx),%rdx
  6faae9:	4c 89 ff             	mov    %r15,%rdi
  6faaec:	ff 15 76 0c 39 00    	call   *0x390c76(%rip)        # a8b768 <_DYNAMIC+0x250>
  6faaf2:	4c 8b ac 24 f8 00 00 	mov    0xf8(%rsp),%r13
  6faaf9:	00 
  6faafa:	4d 85 ed             	test   %r13,%r13
  6faafd:	74 5a                	je     6fab59 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3b19>
  6faaff:	48 8b ac 24 00 01 00 	mov    0x100(%rsp),%rbp
  6fab06:	00 
  6fab07:	48 8b 9c 24 60 05 00 	mov    0x560(%rsp),%rbx
  6fab0e:	00 
  6fab0f:	48 3b 9c 24 50 05 00 	cmp    0x550(%rsp),%rbx
  6fab16:	00 
  6fab17:	4c 8b bc 24 20 02 00 	mov    0x220(%rsp),%r15
  6fab1e:	00 
  6fab1f:	75 0d                	jne    6fab2e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3aee>
  6fab21:	48 8d bc 24 50 05 00 	lea    0x550(%rsp),%rdi
  6fab28:	00 
  6fab29:	e8 22 5f 02 00       	call   720a50 <<alloc::raw_vec::RawVec<[core::option::Option<gpui::source::FieldId>; 2]>>::grow_one>
  6fab2e:	48 8b 84 24 58 05 00 	mov    0x558(%rsp),%rax
  6fab35:	00 
  6fab36:	48 89 d9             	mov    %rbx,%rcx
  6fab39:	48 c1 e1 04          	shl    $0x4,%rcx
  6fab3d:	4c 89 2c 08          	mov    %r13,(%rax,%rcx,1)
  6fab41:	48 89 6c 08 08       	mov    %rbp,0x8(%rax,%rcx,1)
  6fab46:	48 8d 43 01          	lea    0x1(%rbx),%rax
  6fab4a:	48 89 84 24 60 05 00 	mov    %rax,0x560(%rsp)
  6fab51:	00 
  6fab52:	b9 01 00 00 00       	mov    $0x1,%ecx
  6fab57:	eb 0a                	jmp    6fab63 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3b23>
  6fab59:	31 c9                	xor    %ecx,%ecx
  6fab5b:	4c 8b bc 24 20 02 00 	mov    0x220(%rsp),%r15
  6fab62:	00 
  6fab63:	40 b5 01             	mov    $0x1,%bpl
  6fab66:	45 31 ed             	xor    %r13d,%r13d
  6fab69:	4c 89 ff             	mov    %r15,%rdi
  6fab6c:	4c 89 e6             	mov    %r12,%rsi
  6fab6f:	48 8b 94 24 a8 02 00 	mov    0x2a8(%rsp),%rdx
  6fab76:	00 
  6fab77:	49 89 d8             	mov    %rbx,%r8
  6fab7a:	ff 15 98 10 39 00    	call   *0x391098(%rip)        # a8bc18 <_DYNAMIC+0x700>
  6fab80:	48 89 c3             	mov    %rax,%rbx
  6fab83:	48 83 bc 24 50 04 00 	cmpq   $0xfffffffffffffffe,0x450(%rsp)
  6fab8a:	00 fe 
  6fab8c:	40 0f 94 c5          	sete   %bpl
  6fab90:	41 bd ff ff ff ff    	mov    $0xffffffff,%r13d
  6fab96:	44 8b bc 24 00 04 00 	mov    0x400(%rsp),%r15d
  6fab9d:	00 
  6fab9e:	0f 84 69 01 00 00    	je     6fad0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3ccd>
  6faba4:	0f 28 84 24 90 04 00 	movaps 0x490(%rsp),%xmm0
  6fabab:	00 
  6fabac:	0f 29 84 24 b0 03 00 	movaps %xmm0,0x3b0(%rsp)
  6fabb3:	00 
  6fabb4:	66 0f 6f 84 24 50 04 	movdqa 0x450(%rsp),%xmm0
  6fabbb:	00 00 
  6fabbd:	66 0f 6f 8c 24 60 04 	movdqa 0x460(%rsp),%xmm1
  6fabc4:	00 00 
  6fabc6:	66 0f 6f 94 24 70 04 	movdqa 0x470(%rsp),%xmm2
  6fabcd:	00 00 
  6fabcf:	0f 28 9c 24 80 04 00 	movaps 0x480(%rsp),%xmm3
  6fabd6:	00 
  6fabd7:	0f 29 9c 24 a0 03 00 	movaps %xmm3,0x3a0(%rsp)
  6fabde:	00 
  6fabdf:	66 0f 7f 94 24 90 03 	movdqa %xmm2,0x390(%rsp)
  6fabe6:	00 00 
  6fabe8:	66 0f 7f 8c 24 80 03 	movdqa %xmm1,0x380(%rsp)
  6fabef:	00 00 
  6fabf1:	66 0f 7f 84 24 70 03 	movdqa %xmm0,0x370(%rsp)
  6fabf8:	00 00 
  6fabfa:	48 8b b4 24 48 02 00 	mov    0x248(%rsp),%rsi
  6fac01:	00 
  6fac02:	49 39 f6             	cmp    %rsi,%r14
  6fac05:	0f 83 65 2f 00 00    	jae    6fdb70 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b30>
  6fac0b:	48 8b 84 24 40 02 00 	mov    0x240(%rsp),%rax
  6fac12:	00 
  6fac13:	4a 8b 04 f0          	mov    (%rax,%r14,8),%rax
  6fac17:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
  6fac1e:	00 
  6fac1f:	4c 8b ac 24 78 05 00 	mov    0x578(%rsp),%r13
  6fac26:	00 
  6fac27:	48 8b 84 24 b0 03 00 	mov    0x3b0(%rsp),%rax
  6fac2e:	00 
  6fac2f:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
  6fac36:	00 
  6fac37:	48 8b 84 24 b8 03 00 	mov    0x3b8(%rsp),%rax
  6fac3e:	00 
  6fac3f:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
  6fac46:	00 
  6fac47:	66 0f 6f 84 24 70 03 	movdqa 0x370(%rsp),%xmm0
  6fac4e:	00 00 
  6fac50:	66 0f 6f 8c 24 80 03 	movdqa 0x380(%rsp),%xmm1
  6fac57:	00 00 
  6fac59:	66 0f 6f 94 24 90 03 	movdqa 0x390(%rsp),%xmm2
  6fac60:	00 00 
  6fac62:	0f 28 9c 24 a0 03 00 	movaps 0x3a0(%rsp),%xmm3
  6fac69:	00 
  6fac6a:	0f 29 9c 24 c0 01 00 	movaps %xmm3,0x1c0(%rsp)
  6fac71:	00 
  6fac72:	66 0f 7f 94 24 b0 01 	movdqa %xmm2,0x1b0(%rsp)
  6fac79:	00 00 
  6fac7b:	66 0f 7f 8c 24 a0 01 	movdqa %xmm1,0x1a0(%rsp)
  6fac82:	00 00 
  6fac84:	66 0f 7f 84 24 90 01 	movdqa %xmm0,0x190(%rsp)
  6fac8b:	00 00 
  6fac8d:	4c 3b ac 24 68 05 00 	cmp    0x568(%rsp),%r13
  6fac94:	00 
  6fac95:	75 0d                	jne    6faca4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3c64>
  6fac97:	48 8d bc 24 68 05 00 	lea    0x568(%rsp),%rdi
  6fac9e:	00 
  6fac9f:	e8 fc 5e 02 00       	call   720ba0 <<alloc::raw_vec::RawVec<core::option::Option<gpui::runtime::TextSite>>>::grow_one>
  6faca4:	48 8b 84 24 70 05 00 	mov    0x570(%rsp),%rax
  6facab:	00 
  6facac:	4a 8d 0c ad 00 00 00 	lea    0x0(,%r13,4),%rcx
  6facb3:	00 
  6facb4:	4c 01 e9             	add    %r13,%rcx
  6facb7:	48 c1 e1 04          	shl    $0x4,%rcx
  6facbb:	0f 28 84 24 d0 01 00 	movaps 0x1d0(%rsp),%xmm0
  6facc2:	00 
  6facc3:	0f 11 44 08 40       	movups %xmm0,0x40(%rax,%rcx,1)
  6facc8:	66 0f 6f 84 24 90 01 	movdqa 0x190(%rsp),%xmm0
  6faccf:	00 00 
  6facd1:	66 0f 6f 8c 24 a0 01 	movdqa 0x1a0(%rsp),%xmm1
  6facd8:	00 00 
  6facda:	66 0f 6f 94 24 b0 01 	movdqa 0x1b0(%rsp),%xmm2
  6face1:	00 00 
  6face3:	0f 28 9c 24 c0 01 00 	movaps 0x1c0(%rsp),%xmm3
  6facea:	00 
  6faceb:	0f 11 5c 08 30       	movups %xmm3,0x30(%rax,%rcx,1)
  6facf0:	f3 0f 7f 54 08 20    	movdqu %xmm2,0x20(%rax,%rcx,1)
  6facf6:	f3 0f 7f 4c 08 10    	movdqu %xmm1,0x10(%rax,%rcx,1)
  6facfc:	f3 0f 7f 04 08       	movdqu %xmm0,(%rax,%rcx,1)
  6fad01:	49 8d 45 01          	lea    0x1(%r13),%rax
  6fad05:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
  6fad0c:	00 
  6fad0d:	45 84 ff             	test   %r15b,%r15b
  6fad10:	74 3f                	je     6fad51 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d11>
  6fad12:	0f b6 84 24 10 01 00 	movzbl 0x110(%rsp),%eax
  6fad19:	00 
  6fad1a:	8d 48 fe             	lea    -0x2(%rax),%ecx
  6fad1d:	83 f8 02             	cmp    $0x2,%eax
  6fad20:	0f b6 c9             	movzbl %cl,%ecx
  6fad23:	ba 08 00 00 00       	mov    $0x8,%edx
  6fad28:	0f 42 ca             	cmovb  %edx,%ecx
  6fad2b:	44 0f b6 f1          	movzbl %cl,%r14d
  6fad2f:	48 8d 15 e2 d0 95 ff 	lea    -0x6a2f1e(%rip),%rdx        # 57e18 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x150>
  6fad36:	4a 63 0c b2          	movslq (%rdx,%r14,4),%rcx
  6fad3a:	48 01 d1             	add    %rdx,%rcx
  6fad3d:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  6fad42:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  6fad47:	ff e1                	jmp    *%rcx
  6fad49:	41 be 01 00 00 00    	mov    $0x1,%r14d
  6fad4f:	eb 61                	jmp    6fadb2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d72>
  6fad51:	45 31 ed             	xor    %r13d,%r13d
  6fad54:	0f b6 b4 24 e8 01 00 	movzbl 0x1e8(%rsp),%esi
  6fad5b:	00 
  6fad5c:	48 8b bc 24 f8 03 00 	mov    0x3f8(%rsp),%rdi
  6fad63:	00 
  6fad64:	ff 15 c6 0e 39 00    	call   *0x390ec6(%rip)        # a8bc30 <_DYNAMIC+0x718>
  6fad6a:	41 89 c6             	mov    %eax,%r14d
  6fad6d:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  6fad72:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  6fad77:	eb 57                	jmp    6fadd0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d90>
  6fad79:	41 be 04 00 00 00    	mov    $0x4,%r14d
  6fad7f:	eb 31                	jmp    6fadb2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d72>
  6fad81:	41 be 02 00 00 00    	mov    $0x2,%r14d
  6fad87:	eb 29                	jmp    6fadb2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d72>
  6fad89:	41 be 03 00 00 00    	mov    $0x3,%r14d
  6fad8f:	eb 21                	jmp    6fadb2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d72>
  6fad91:	41 be 07 00 00 00    	mov    $0x7,%r14d
  6fad97:	eb 19                	jmp    6fadb2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d72>
  6fad99:	41 be 05 00 00 00    	mov    $0x5,%r14d
  6fad9f:	eb 11                	jmp    6fadb2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d72>
  6fada1:	41 be 06 00 00 00    	mov    $0x6,%r14d
  6fada7:	eb 09                	jmp    6fadb2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d72>
  6fada9:	83 e0 01             	and    $0x1,%eax
  6fadac:	83 c8 08             	or     $0x8,%eax
  6fadaf:	41 89 c6             	mov    %eax,%r14d
  6fadb2:	41 83 fd ff          	cmp    $0xffffffff,%r13d
  6fadb6:	74 18                	je     6fadd0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3d90>
  6fadb8:	41 81 fd a0 86 01 00 	cmp    $0x186a0,%r13d
  6fadbf:	0f 83 b2 2a 00 00    	jae    6fd877 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6837>
  6fadc5:	41 c1 e5 04          	shl    $0x4,%r13d
  6fadc9:	41 83 c5 10          	add    $0x10,%r13d
  6fadcd:	45 09 ee             	or     %r13d,%r14d
  6fadd0:	48 39 f2             	cmp    %rsi,%rdx
  6fadd3:	b8 00 00 00 00       	mov    $0x0,%eax
  6fadd8:	48 0f 44 d0          	cmove  %rax,%rdx
  6faddc:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
  6fade1:	41 0f 94 c4          	sete   %r12b
  6fade5:	4c 8b bc 24 78 01 00 	mov    0x178(%rsp),%r15
  6fadec:	00 
  6faded:	4c 3b bc 24 68 01 00 	cmp    0x168(%rsp),%r15
  6fadf4:	00 
  6fadf5:	75 10                	jne    6fae07 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3dc7>
  6fadf7:	45 31 ed             	xor    %r13d,%r13d
  6fadfa:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  6fae01:	00 
  6fae02:	e8 e9 5e 02 00       	call   720cf0 <<alloc::raw_vec::RawVec<gpui::style_port::Draft>>::grow_one>
  6fae07:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  6fae0e:	00 
  6fae0f:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
  6fae13:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6fae18:	48 89 14 c8          	mov    %rdx,(%rax,%rcx,8)
  6fae1c:	48 89 5c c8 08       	mov    %rbx,0x8(%rax,%rcx,8)
  6fae21:	44 89 74 c8 10       	mov    %r14d,0x10(%rax,%rcx,8)
  6fae26:	48 8b 94 24 80 01 00 	mov    0x180(%rsp),%rdx
  6fae2d:	00 
  6fae2e:	89 54 c8 14          	mov    %edx,0x14(%rax,%rcx,8)
  6fae32:	49 ff c7             	inc    %r15
  6fae35:	4c 89 bc 24 78 01 00 	mov    %r15,0x178(%rsp)
  6fae3c:	00 
  6fae3d:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  6fae42:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
  6fae46:	48 83 f8 fc          	cmp    $0xfffffffffffffffc,%rax
  6fae4a:	77 13                	ja     6fae5f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3e1f>
  6fae4c:	ba 01 00 00 00       	mov    $0x1,%edx
  6fae51:	48 8b bc 24 f0 03 00 	mov    0x3f0(%rsp),%rdi
  6fae58:	00 
  6fae59:	ff 15 09 09 39 00    	call   *0x390909(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fae5f:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  6fae66:	00 
  6fae67:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fae6b:	4c 8b 7c 24 78       	mov    0x78(%rsp),%r15
  6fae70:	4c 8b ac 24 18 02 00 	mov    0x218(%rsp),%r13
  6fae77:	00 
  6fae78:	74 18                	je     6fae92 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3e52>
  6fae7a:	48 85 f6             	test   %rsi,%rsi
  6fae7d:	7e 13                	jle    6fae92 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3e52>
  6fae7f:	48 8b bc 24 88 00 00 	mov    0x88(%rsp),%rdi
  6fae86:	00 
  6fae87:	ba 01 00 00 00       	mov    $0x1,%edx
  6fae8c:	ff 15 d6 08 39 00    	call   *0x3908d6(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fae92:	48 8d bc 24 08 01 00 	lea    0x108(%rsp),%rdi
  6fae99:	00 
  6fae9a:	e8 21 a2 fe ff       	call   6e50c0 <core::ptr::drop_glue::<gpui::element::ComponentBoundaries>>
  6fae9f:	44 0a a4 24 10 02 00 	or     0x210(%rsp),%r12b
  6faea6:	00 
  6faea7:	41 0f b6 c4          	movzbl %r12b,%eax
  6faeab:	49 01 c5             	add    %rax,%r13
  6faeae:	4c 8b b4 24 10 05 00 	mov    0x510(%rsp),%r14
  6faeb5:	00 
  6faeb6:	48 8b 84 24 a0 02 00 	mov    0x2a0(%rsp),%rax
  6faebd:	00 
  6faebe:	48 89 c6             	mov    %rax,%rsi
  6faec1:	48 3b 84 24 48 08 00 	cmp    0x848(%rsp),%rax
  6faec8:	00 
  6faec9:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  6faece:	0f 85 f4 e5 ff ff    	jne    6f94c8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x2488>
  6faed4:	eb 1f                	jmp    6faef5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3eb5>
  6faed6:	48 8d 84 24 f8 05 00 	lea    0x5f8(%rsp),%rax
  6faedd:	00 
  6faede:	e9 5f f7 ff ff       	jmp    6fa642 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3602>
  6faee3:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6faee7:	ff 15 c3 08 39 00    	call   *0x3908c3(%rip)        # a8b7b0 <_DYNAMIC+0x298>
  6faeed:	e9 7e f5 ff ff       	jmp    6fa470 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3430>
  6faef2:	45 31 ed             	xor    %r13d,%r13d
  6faef5:	b3 01                	mov    $0x1,%bl
  6faef7:	48 8d bc 24 d0 06 00 	lea    0x6d0(%rsp),%rdi
  6faefe:	00 
  6faeff:	40 b5 01             	mov    $0x1,%bpl
  6faf02:	e8 b9 44 02 00       	call   71f3c0 <<alloc::vec::into_iter::IntoIter<gpui::element::DraftNode> as core::ops::drop::Drop>::drop>
  6faf07:	4c 8b 74 24 18       	mov    0x18(%rsp),%r14
  6faf0c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6faf11:	48 8d b8 f0 05 00 00 	lea    0x5f0(%rax),%rdi
  6faf18:	48 8b 84 24 b0 04 00 	mov    0x4b0(%rsp),%rax
  6faf1f:	00 
  6faf20:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6faf27:	00 
  6faf28:	66 0f 6f 84 24 a0 04 	movdqa 0x4a0(%rsp),%xmm0
  6faf2f:	00 00 
  6faf31:	66 0f 7f 84 24 80 00 	movdqa %xmm0,0x80(%rsp)
  6faf38:	00 00 
  6faf3a:	31 ed                	xor    %ebp,%ebp
  6faf3c:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6faf43:	00 
  6faf44:	ff 15 ee 0c 39 00    	call   *0x390cee(%rip)        # a8bc38 <_DYNAMIC+0x720>
  6faf4a:	4d 85 f6             	test   %r14,%r14
  6faf4d:	74 18                	je     6faf67 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3f27>
  6faf4f:	44 89 f0             	mov    %r14d,%eax
  6faf52:	83 e0 03             	and    $0x3,%eax
  6faf55:	49 83 fe 04          	cmp    $0x4,%r14
  6faf59:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
  6faf5e:	73 11                	jae    6faf71 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3f31>
  6faf60:	31 c9                	xor    %ecx,%ecx
  6faf62:	45 31 e4             	xor    %r12d,%r12d
  6faf65:	eb 5a                	jmp    6fafc1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3f81>
  6faf67:	45 31 e4             	xor    %r12d,%r12d
  6faf6a:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
  6faf6f:	eb 78                	jmp    6fafe9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3fa9>
  6faf71:	48 ba 00 00 00 00 00 	movabs $0x800000000000000,%rdx
  6faf78:	00 00 08 
  6faf7b:	48 83 c2 fc          	add    $0xfffffffffffffffc,%rdx
  6faf7f:	4c 21 f2             	and    %r14,%rdx
  6faf82:	31 c9                	xor    %ecx,%ecx
  6faf84:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  6faf89:	45 31 e4             	xor    %r12d,%r12d
  6faf8c:	48 83 3f 01          	cmpq   $0x1,(%rdi)
  6faf90:	49 83 dc ff          	sbb    $0xffffffffffffffff,%r12
  6faf94:	48 83 7f 18 01       	cmpq   $0x1,0x18(%rdi)
  6faf99:	49 83 dc ff          	sbb    $0xffffffffffffffff,%r12
  6faf9d:	48 83 7f 30 01       	cmpq   $0x1,0x30(%rdi)
  6fafa2:	49 83 dc ff          	sbb    $0xffffffffffffffff,%r12
  6fafa6:	48 83 7f 48 01       	cmpq   $0x1,0x48(%rdi)
  6fafab:	49 83 dc ff          	sbb    $0xffffffffffffffff,%r12
  6fafaf:	48 83 c1 04          	add    $0x4,%rcx
  6fafb3:	48 83 c7 60          	add    $0x60,%rdi
  6fafb7:	48 39 ca             	cmp    %rcx,%rdx
  6fafba:	75 d0                	jne    6faf8c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3f4c>
  6fafbc:	48 85 c0             	test   %rax,%rax
  6fafbf:	74 28                	je     6fafe9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3fa9>
  6fafc1:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  6fafc5:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  6fafca:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
  6fafce:	c1 e0 03             	shl    $0x3,%eax
  6fafd1:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  6fafd5:	31 d2                	xor    %edx,%edx
  6fafd7:	48 83 3c 11 01       	cmpq   $0x1,(%rcx,%rdx,1)
  6fafdc:	49 83 dc ff          	sbb    $0xffffffffffffffff,%r12
  6fafe0:	48 83 c2 18          	add    $0x18,%rdx
  6fafe4:	48 39 d0             	cmp    %rdx,%rax
  6fafe7:	75 ee                	jne    6fafd7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3f97>
  6fafe9:	4d 01 ec             	add    %r13,%r12
  6fafec:	48 85 f6             	test   %rsi,%rsi
  6fafef:	74 2e                	je     6fb01f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x3fdf>
  6faff1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6faff6:	48 8d b8 e8 01 00 00 	lea    0x1e8(%rax),%rdi
  6faffd:	31 ed                	xor    %ebp,%ebp
  6fafff:	e8 bc 41 ff ff       	call   6ef1c0 <<gpui::runtime::identity_index::IdentityIndex>::required>
  6fb004:	4c 39 f0             	cmp    %r14,%rax
  6fb007:	0f 83 88 2c 00 00    	jae    6fdc95 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c55>
  6fb00d:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  6fb011:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  6fb016:	48 83 3c c1 01       	cmpq   $0x1,(%rcx,%rax,8)
  6fb01b:	49 83 d4 00          	adc    $0x0,%r12
  6fb01f:	b0 01                	mov    $0x1,%al
  6fb021:	48 8b 8c 24 88 02 00 	mov    0x288(%rsp),%rcx
  6fb028:	00 
  6fb029:	48 3b 8c 24 78 01 00 	cmp    0x178(%rsp),%rcx
  6fb030:	00 
  6fb031:	75 6f                	jne    6fb0a2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4062>
  6fb033:	48 83 bc 24 88 02 00 	cmpq   $0x0,0x288(%rsp)
  6fb03a:	00 00 
  6fb03c:	74 62                	je     6fb0a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4060>
  6fb03e:	48 8b 8c 24 70 01 00 	mov    0x170(%rsp),%rcx
  6fb045:	00 
  6fb046:	49 ff ce             	dec    %r14
  6fb049:	31 d2                	xor    %edx,%edx
  6fb04b:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  6fb050:	48 8b 04 d0          	mov    (%rax,%rdx,8),%rax
  6fb054:	48 3b 01             	cmp    (%rcx),%rax
  6fb057:	0f 95 c0             	setne  %al
  6fb05a:	75 46                	jne    6fb0a2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4062>
  6fb05c:	48 83 c1 18          	add    $0x18,%rcx
  6fb060:	49 39 d6             	cmp    %rdx,%r14
  6fb063:	48 8d 52 01          	lea    0x1(%rdx),%rdx
  6fb067:	75 e2                	jne    6fb04b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x400b>
  6fb069:	eb 37                	jmp    6fb0a2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4062>
  6fb06b:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6fb070:	48 c7 00 1d 00 00 00 	movq   $0x1d,(%rax)
  6fb077:	e9 af 21 00 00       	jmp    6fd22b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61eb>
  6fb07c:	48 8d 8c 24 88 00 00 	lea    0x88(%rsp),%rcx
  6fb083:	00 
  6fb084:	0f 10 01             	movups (%rcx),%xmm0
  6fb087:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6fb08c:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
  6fb090:	48 c7 01 20 00 00 00 	movq   $0x20,(%rcx)
  6fb097:	48 89 41 08          	mov    %rax,0x8(%rcx)
  6fb09b:	e9 97 21 00 00       	jmp    6fd237 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61f7>
  6fb0a0:	31 c0                	xor    %eax,%eax
  6fb0a2:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6fb0a7:	08 81 49 07 00 00    	or     %al,0x749(%rcx)
  6fb0ad:	08 81 4b 07 00 00    	or     %al,0x74b(%rcx)
  6fb0b3:	48 c7 84 24 20 05 00 	movq   $0x0,0x520(%rsp)
  6fb0ba:	00 00 00 00 00 
  6fb0bf:	48 c7 84 24 30 05 00 	movq   $0x0,0x530(%rsp)
  6fb0c6:	00 00 00 00 00 
  6fb0cb:	48 c7 84 24 f8 06 00 	movq   $0x0,0x6f8(%rsp)
  6fb0d2:	00 00 00 00 00 
  6fb0d7:	48 c7 84 24 08 07 00 	movq   $0x0,0x708(%rsp)
  6fb0de:	00 00 00 00 00 
  6fb0e3:	48 8b 94 24 e0 05 00 	mov    0x5e0(%rsp),%rdx
  6fb0ea:	00 
  6fb0eb:	4c 8b ac 24 e8 05 00 	mov    0x5e8(%rsp),%r13
  6fb0f2:	00 
  6fb0f3:	48 8b 84 24 f0 05 00 	mov    0x5f0(%rsp),%rax
  6fb0fa:	00 
  6fb0fb:	48 69 f0 a8 00 00 00 	imul   $0xa8,%rax,%rsi
  6fb102:	4c 01 ee             	add    %r13,%rsi
  6fb105:	4c 89 ac 24 70 03 00 	mov    %r13,0x370(%rsp)
  6fb10c:	00 
  6fb10d:	4c 89 ac 24 78 03 00 	mov    %r13,0x378(%rsp)
  6fb114:	00 
  6fb115:	48 89 94 24 90 02 00 	mov    %rdx,0x290(%rsp)
  6fb11c:	00 
  6fb11d:	48 89 94 24 80 03 00 	mov    %rdx,0x380(%rsp)
  6fb124:	00 
  6fb125:	48 89 b4 24 e8 01 00 	mov    %rsi,0x1e8(%rsp)
  6fb12c:	00 
  6fb12d:	48 89 b4 24 88 03 00 	mov    %rsi,0x388(%rsp)
  6fb134:	00 
  6fb135:	4c 89 ac 24 98 02 00 	mov    %r13,0x298(%rsp)
  6fb13c:	00 
  6fb13d:	48 85 c0             	test   %rax,%rax
  6fb140:	4c 89 a4 24 80 01 00 	mov    %r12,0x180(%rsp)
  6fb147:	00 
  6fb148:	0f 84 98 07 00 00    	je     6fb8e6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x48a6>
  6fb14e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fb153:	48 05 78 06 00 00    	add    $0x678,%rax
  6fb159:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6fb15e:	48 8b 84 24 98 02 00 	mov    0x298(%rsp),%rax
  6fb165:	00 
  6fb166:	48 8b 8c 24 30 02 00 	mov    0x230(%rsp),%rcx
  6fb16d:	00 
  6fb16e:	eb 11                	jmp    6fb181 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4141>
  6fb170:	4c 89 f0             	mov    %r14,%rax
  6fb173:	4c 3b b4 24 e8 01 00 	cmp    0x1e8(%rsp),%r14
  6fb17a:	00 
  6fb17b:	0f 84 55 07 00 00    	je     6fb8d6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4896>
  6fb181:	4c 8d a8 a8 00 00 00 	lea    0xa8(%rax),%r13
  6fb188:	48 8b 10             	mov    (%rax),%rdx
  6fb18b:	48 83 fa 02          	cmp    $0x2,%rdx
  6fb18f:	0f 84 49 07 00 00    	je     6fb8de <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x489e>
  6fb195:	48 89 94 24 10 05 00 	mov    %rdx,0x510(%rsp)
  6fb19c:	00 
  6fb19d:	48 8b 50 18          	mov    0x18(%rax),%rdx
  6fb1a1:	48 89 94 24 18 02 00 	mov    %rdx,0x218(%rsp)
  6fb1a8:	00 
  6fb1a9:	48 8b 50 20          	mov    0x20(%rax),%rdx
  6fb1ad:	48 8b 70 30          	mov    0x30(%rax),%rsi
  6fb1b1:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  6fb1b6:	48 8b 70 38          	mov    0x38(%rax),%rsi
  6fb1ba:	48 89 74 24 48       	mov    %rsi,0x48(%rsp)
  6fb1bf:	48 8b 70 40          	mov    0x40(%rax),%rsi
  6fb1c3:	48 89 74 24 58       	mov    %rsi,0x58(%rsp)
  6fb1c8:	48 8b 70 48          	mov    0x48(%rax),%rsi
  6fb1cc:	48 89 74 24 40       	mov    %rsi,0x40(%rsp)
  6fb1d1:	48 8b 70 50          	mov    0x50(%rax),%rsi
  6fb1d5:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
  6fb1da:	0f 10 40 58          	movups 0x58(%rax),%xmm0
  6fb1de:	0f 29 84 24 60 03 00 	movaps %xmm0,0x360(%rsp)
  6fb1e5:	00 
  6fb1e6:	0f 10 40 68          	movups 0x68(%rax),%xmm0
  6fb1ea:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
  6fb1f1:	00 
  6fb1f2:	48 8b 70 78          	mov    0x78(%rax),%rsi
  6fb1f6:	48 89 b4 24 a8 02 00 	mov    %rsi,0x2a8(%rsp)
  6fb1fd:	00 
  6fb1fe:	48 8b b0 80 00 00 00 	mov    0x80(%rax),%rsi
  6fb205:	48 89 b4 24 88 01 00 	mov    %rsi,0x188(%rsp)
  6fb20c:	00 
  6fb20d:	48 8b b0 88 00 00 00 	mov    0x88(%rax),%rsi
  6fb214:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
  6fb219:	4c 8b b8 90 00 00 00 	mov    0x90(%rax),%r15
  6fb220:	48 8b b0 98 00 00 00 	mov    0x98(%rax),%rsi
  6fb227:	48 8b 98 a0 00 00 00 	mov    0xa0(%rax),%rbx
  6fb22e:	66 0f 10 40 08       	movupd 0x8(%rax),%xmm0
  6fb233:	66 0f 29 84 24 50 04 	movapd %xmm0,0x450(%rsp)
  6fb23a:	00 00 
  6fb23c:	48 8b bc 24 78 01 00 	mov    0x178(%rsp),%rdi
  6fb243:	00 
  6fb244:	48 89 b4 24 20 02 00 	mov    %rsi,0x220(%rsp)
  6fb24b:	00 
  6fb24c:	48 89 bc 24 f8 03 00 	mov    %rdi,0x3f8(%rsp)
  6fb253:	00 
  6fb254:	48 39 fe             	cmp    %rdi,%rsi
  6fb257:	48 89 94 24 00 04 00 	mov    %rdx,0x400(%rsp)
  6fb25e:	00 
  6fb25f:	0f 83 ea 27 00 00    	jae    6fda4f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a0f>
  6fb265:	48 8b 09             	mov    (%rcx),%rcx
  6fb268:	b0 01                	mov    $0x1,%al
  6fb26a:	48 85 c9             	test   %rcx,%rcx
  6fb26d:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
  6fb274:	00 
  6fb275:	0f 84 55 01 00 00    	je     6fb3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4390>
  6fb27b:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6fb280:	48 8b b2 50 06 00 00 	mov    0x650(%rdx),%rsi
  6fb287:	0f b7 b9 8a 05 00 00 	movzwl 0x58a(%rcx),%edi
  6fb28e:	4c 6b c7 70          	imul   $0x70,%rdi,%r8
  6fb292:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
  6fb299:	31 d2                	xor    %edx,%edx
  6fb29b:	45 31 d2             	xor    %r10d,%r10d
  6fb29e:	49 89 cb             	mov    %rcx,%r11
  6fb2a1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fb2a8:	0f 1f 84 00 00 00 00 
  6fb2af:	00 
  6fb2b0:	49 39 d0             	cmp    %rdx,%r8
  6fb2b3:	74 3c                	je     6fb2f1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x42b1>
  6fb2b5:	41 80 3b 00          	cmpb   $0x0,(%r11)
  6fb2b9:	75 33                	jne    6fb2ee <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x42ae>
  6fb2bb:	4d 89 f1             	mov    %r14,%r9
  6fb2be:	49 ff c2             	inc    %r10
  6fb2c1:	49 3b 5b 08          	cmp    0x8(%r11),%rbx
  6fb2c5:	4d 8d 5b 10          	lea    0x10(%r11),%r11
  6fb2c9:	40 0f 97 c5          	seta   %bpl
  6fb2cd:	40 80 dd 00          	sbb    $0x0,%bpl
  6fb2d1:	48 83 c2 70          	add    $0x70,%rdx
  6fb2d5:	49 ff c6             	inc    %r14
  6fb2d8:	40 80 fd 01          	cmp    $0x1,%bpl
  6fb2dc:	74 d2                	je     6fb2b0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4270>
  6fb2de:	40 0f b6 fd          	movzbl %bpl,%edi
  6fb2e2:	85 ff                	test   %edi,%edi
  6fb2e4:	74 1f                	je     6fb305 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x42c5>
  6fb2e6:	49 ff c1             	inc    %r9
  6fb2e9:	4c 89 cf             	mov    %r9,%rdi
  6fb2ec:	eb 03                	jmp    6fb2f1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x42b1>
  6fb2ee:	4c 89 d7             	mov    %r10,%rdi
  6fb2f1:	48 83 ee 01          	sub    $0x1,%rsi
  6fb2f5:	0f 82 d5 00 00 00    	jb     6fb3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4390>
  6fb2fb:	48 8b 8c f9 90 05 00 	mov    0x590(%rcx,%rdi,8),%rcx
  6fb302:	00 
  6fb303:	eb 82                	jmp    6fb287 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4247>
  6fb305:	83 7c 11 40 02       	cmpl   $0x2,0x40(%rcx,%rdx,1)
  6fb30a:	0f 84 c0 00 00 00    	je     6fb3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4390>
  6fb310:	f2 0f 10 84 11 88 00 	movsd  0x88(%rcx,%rdx,1),%xmm0
  6fb317:	00 00 
  6fb319:	66 0f 28 8c 24 60 03 	movapd 0x360(%rsp),%xmm1
  6fb320:	00 00 
  6fb322:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
  6fb326:	0f 85 a4 00 00 00    	jne    6fb3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4390>
  6fb32c:	0f 8a 9e 00 00 00    	jp     6fb3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4390>
  6fb332:	f2 0f 10 84 11 90 00 	movsd  0x90(%rcx,%rdx,1),%xmm0
  6fb339:	00 00 
  6fb33b:	66 0f 15 c9          	unpckhpd %xmm1,%xmm1
  6fb33f:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
  6fb343:	0f 85 87 00 00 00    	jne    6fb3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4390>
  6fb349:	0f 8a 81 00 00 00    	jp     6fb3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4390>
  6fb34f:	f2 0f 10 84 11 98 00 	movsd  0x98(%rcx,%rdx,1),%xmm0
  6fb356:	00 00 
  6fb358:	66 0f 28 8c 24 30 01 	movapd 0x130(%rsp),%xmm1
  6fb35f:	00 00 
  6fb361:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
  6fb365:	75 69                	jne    6fb3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4390>
  6fb367:	7a 67                	jp     6fb3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4390>
  6fb369:	f2 0f 10 84 11 a0 00 	movsd  0xa0(%rcx,%rdx,1),%xmm0
  6fb370:	00 00 
  6fb372:	66 0f 15 c9          	unpckhpd %xmm1,%xmm1
  6fb376:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
  6fb37a:	75 54                	jne    6fb3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4390>
  6fb37c:	7a 52                	jp     6fb3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4390>
  6fb37e:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  6fb383:	48 39 b4 11 80 00 00 	cmp    %rsi,0x80(%rcx,%rdx,1)
  6fb38a:	00 
  6fb38b:	75 43                	jne    6fb3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4390>
  6fb38d:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  6fb392:	48 39 74 11 60       	cmp    %rsi,0x60(%rcx,%rdx,1)
  6fb397:	75 37                	jne    6fb3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4390>
  6fb399:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  6fb39e:	48 39 74 11 68       	cmp    %rsi,0x68(%rcx,%rdx,1)
  6fb3a3:	75 2b                	jne    6fb3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4390>
  6fb3a5:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  6fb3aa:	48 39 74 11 70       	cmp    %rsi,0x70(%rcx,%rdx,1)
  6fb3af:	75 1f                	jne    6fb3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4390>
  6fb3b1:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  6fb3b6:	48 39 74 11 78       	cmp    %rsi,0x78(%rcx,%rdx,1)
  6fb3bb:	75 13                	jne    6fb3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4390>
  6fb3bd:	48 8b 84 24 a8 02 00 	mov    0x2a8(%rsp),%rax
  6fb3c4:	00 
  6fb3c5:	48 39 84 11 a8 00 00 	cmp    %rax,0xa8(%rcx,%rdx,1)
  6fb3cc:	00 
  6fb3cd:	0f 95 c0             	setne  %al
  6fb3d0:	48 8b 8c 24 70 01 00 	mov    0x170(%rsp),%rcx
  6fb3d7:	00 
  6fb3d8:	48 8b 94 24 20 02 00 	mov    0x220(%rsp),%rdx
  6fb3df:	00 
  6fb3e0:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  6fb3e4:	48 8b 0c d1          	mov    (%rcx,%rdx,8),%rcx
  6fb3e8:	48 89 8c 24 10 02 00 	mov    %rcx,0x210(%rsp)
  6fb3ef:	00 
  6fb3f0:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6fb3f5:	08 81 4b 07 00 00    	or     %al,0x74b(%rcx)
  6fb3fb:	4d 85 ff             	test   %r15,%r15
  6fb3fe:	0f 84 74 02 00 00    	je     6fb678 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4638>
  6fb404:	49 c1 e7 05          	shl    $0x5,%r15
  6fb408:	4c 8b 6c 24 70       	mov    0x70(%rsp),%r13
  6fb40d:	4d 01 ef             	add    %r13,%r15
  6fb410:	eb 35                	jmp    6fb447 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4407>
  6fb412:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fb419:	1f 84 00 00 00 00 00 
  6fb420:	0f 10 84 24 90 01 00 	movups 0x190(%rsp),%xmm0
  6fb427:	00 
  6fb428:	0f 10 8c 24 a0 01 00 	movups 0x1a0(%rsp),%xmm1
  6fb42f:	00 
  6fb430:	0f 11 4c 38 f0       	movups %xmm1,-0x10(%rax,%rdi,1)
  6fb435:	0f 11 44 38 e0       	movups %xmm0,-0x20(%rax,%rdi,1)
  6fb43a:	49 83 c5 20          	add    $0x20,%r13
  6fb43e:	4d 39 fd             	cmp    %r15,%r13
  6fb441:	0f 84 31 02 00 00    	je     6fb678 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4638>
  6fb447:	49 8b 7d 00          	mov    0x0(%r13),%rdi
  6fb44b:	48 8b b4 24 78 01 00 	mov    0x178(%rsp),%rsi
  6fb452:	00 
  6fb453:	48 39 f7             	cmp    %rsi,%rdi
  6fb456:	0f 83 fd 24 00 00    	jae    6fd959 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6919>
  6fb45c:	4d 8b 65 08          	mov    0x8(%r13),%r12
  6fb460:	41 8b 6d 10          	mov    0x10(%r13),%ebp
  6fb464:	f2 41 0f 10 45 14    	movsd  0x14(%r13),%xmm0
  6fb46a:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  6fb46f:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  6fb476:	00 
  6fb477:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  6fb47b:	4c 8b 34 c8          	mov    (%rax,%rcx,8),%r14
  6fb47f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fb484:	48 8b 80 60 06 00 00 	mov    0x660(%rax),%rax
  6fb48b:	48 85 c0             	test   %rax,%rax
  6fb48e:	0f 84 b1 00 00 00    	je     6fb545 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4505>
  6fb494:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6fb499:	48 8b 89 68 06 00 00 	mov    0x668(%rcx),%rcx
  6fb4a0:	0f b7 b8 c2 01 00 00 	movzwl 0x1c2(%rax),%edi
  6fb4a7:	41 89 f8             	mov    %edi,%r8d
  6fb4aa:	41 c1 e0 05          	shl    $0x5,%r8d
  6fb4ae:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6fb4b5:	31 f6                	xor    %esi,%esi
  6fb4b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6fb4be:	00 00 
  6fb4c0:	49 39 f0             	cmp    %rsi,%r8
  6fb4c3:	74 3b                	je     6fb500 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x44c0>
  6fb4c5:	4c 3b b4 d0 70 01 00 	cmp    0x170(%rax,%rdx,8),%r14
  6fb4cc:	00 
  6fb4cd:	41 0f 97 c1          	seta   %r9b
  6fb4d1:	41 80 d9 00          	sbb    $0x0,%r9b
  6fb4d5:	48 83 c6 20          	add    $0x20,%rsi
  6fb4d9:	48 ff c2             	inc    %rdx
  6fb4dc:	41 80 f9 01          	cmp    $0x1,%r9b
  6fb4e0:	74 de                	je     6fb4c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4480>
  6fb4e2:	41 0f b6 f9          	movzbl %r9b,%edi
  6fb4e6:	85 ff                	test   %edi,%edi
  6fb4e8:	74 36                	je     6fb520 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x44e0>
  6fb4ea:	48 83 e9 01          	sub    $0x1,%rcx
  6fb4ee:	73 19                	jae    6fb509 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x44c9>
  6fb4f0:	eb 53                	jmp    6fb545 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4505>
  6fb4f2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fb4f9:	1f 84 00 00 00 00 00 
  6fb500:	48 89 fa             	mov    %rdi,%rdx
  6fb503:	48 83 e9 01          	sub    $0x1,%rcx
  6fb507:	72 3c                	jb     6fb545 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4505>
  6fb509:	48 8b 84 d0 c8 01 00 	mov    0x1c8(%rax,%rdx,8),%rax
  6fb510:	00 
  6fb511:	eb 8d                	jmp    6fb4a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4460>
  6fb513:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fb51a:	84 00 00 00 00 00 
  6fb520:	f3 0f 10 44 30 f4    	movss  -0xc(%rax,%rsi,1),%xmm0
  6fb526:	0f 2e 44 24 20       	ucomiss 0x20(%rsp),%xmm0
  6fb52b:	75 18                	jne    6fb545 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4505>
  6fb52d:	7a 16                	jp     6fb545 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4505>
  6fb52f:	f3 0f 10 44 30 f8    	movss  -0x8(%rax,%rsi,1),%xmm0
  6fb535:	0f 28 4c 24 20       	movaps 0x20(%rsp),%xmm1
  6fb53a:	0f c6 c9 55          	shufps $0x55,%xmm1,%xmm1
  6fb53e:	0f 2e c1             	ucomiss %xmm1,%xmm0
  6fb541:	75 02                	jne    6fb545 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4505>
  6fb543:	7b 19                	jnp    6fb55e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x451e>
  6fb545:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  6fb54a:	4c 89 f6             	mov    %r14,%rsi
  6fb54d:	e8 5e e0 00 00       	call   7095b0 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6fb552:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fb557:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6fb55e:	48 89 9c 24 90 01 00 	mov    %rbx,0x190(%rsp)
  6fb565:	00 
  6fb566:	4c 89 a4 24 98 01 00 	mov    %r12,0x198(%rsp)
  6fb56d:	00 
  6fb56e:	89 ac 24 a0 01 00 00 	mov    %ebp,0x1a0(%rsp)
  6fb575:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
  6fb57a:	0f 13 84 24 a4 01 00 	movlps %xmm0,0x1a4(%rsp)
  6fb581:	00 
  6fb582:	c6 84 24 ac 01 00 00 	movb   $0x1,0x1ac(%rsp)
  6fb589:	01 
  6fb58a:	48 8b 84 24 f8 06 00 	mov    0x6f8(%rsp),%rax
  6fb591:	00 
  6fb592:	48 85 c0             	test   %rax,%rax
  6fb595:	0f 84 85 00 00 00    	je     6fb620 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x45e0>
  6fb59b:	48 8b 8c 24 00 07 00 	mov    0x700(%rsp),%rcx
  6fb5a2:	00 
  6fb5a3:	0f b7 b0 c2 01 00 00 	movzwl 0x1c2(%rax),%esi
  6fb5aa:	41 89 f0             	mov    %esi,%r8d
  6fb5ad:	41 c1 e0 05          	shl    $0x5,%r8d
  6fb5b1:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6fb5b8:	31 ff                	xor    %edi,%edi
  6fb5ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  6fb5c0:	49 39 f8             	cmp    %rdi,%r8
  6fb5c3:	74 3b                	je     6fb600 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x45c0>
  6fb5c5:	4c 3b b4 d0 70 01 00 	cmp    0x170(%rax,%rdx,8),%r14
  6fb5cc:	00 
  6fb5cd:	41 0f 97 c1          	seta   %r9b
  6fb5d1:	41 80 d9 00          	sbb    $0x0,%r9b
  6fb5d5:	48 83 c7 20          	add    $0x20,%rdi
  6fb5d9:	48 ff c2             	inc    %rdx
  6fb5dc:	41 80 f9 01          	cmp    $0x1,%r9b
  6fb5e0:	74 de                	je     6fb5c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4580>
  6fb5e2:	41 0f b6 f1          	movzbl %r9b,%esi
  6fb5e6:	85 f6                	test   %esi,%esi
  6fb5e8:	0f 84 32 fe ff ff    	je     6fb420 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43e0>
  6fb5ee:	48 83 e9 01          	sub    $0x1,%rcx
  6fb5f2:	73 15                	jae    6fb609 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x45c9>
  6fb5f4:	eb 2c                	jmp    6fb622 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x45e2>
  6fb5f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6fb5fd:	00 00 00 
  6fb600:	48 89 f2             	mov    %rsi,%rdx
  6fb603:	48 83 e9 01          	sub    $0x1,%rcx
  6fb607:	72 19                	jb     6fb622 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x45e2>
  6fb609:	48 8b 84 d0 c8 01 00 	mov    0x1c8(%rax,%rdx,8),%rax
  6fb610:	00 
  6fb611:	eb 90                	jmp    6fb5a3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4563>
  6fb613:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fb61a:	84 00 00 00 00 00 
  6fb620:	31 c0                	xor    %eax,%eax
  6fb622:	48 8d 8c 24 f8 06 00 	lea    0x6f8(%rsp),%rcx
  6fb629:	00 
  6fb62a:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  6fb631:	00 
  6fb632:	4c 89 b4 24 88 00 00 	mov    %r14,0x88(%rsp)
  6fb639:	00 
  6fb63a:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6fb641:	00 
  6fb642:	48 c7 84 24 98 00 00 	movq   $0x0,0x98(%rsp)
  6fb649:	00 00 00 00 00 
  6fb64e:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
  6fb655:	00 
  6fb656:	48 8d bc 24 d0 02 00 	lea    0x2d0(%rsp),%rdi
  6fb65d:	00 
  6fb65e:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6fb665:	00 
  6fb666:	48 8d 94 24 90 01 00 	lea    0x190(%rsp),%rdx
  6fb66d:	00 
  6fb66e:	e8 1d 67 01 00       	call   711d90 <<alloc::collections::btree::map::entry::VacantEntry<u64, gpui::runtime::list::ListRow>>::insert_entry>
  6fb673:	e9 c2 fd ff ff       	jmp    6fb43a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x43fa>
  6fb678:	48 8b b4 24 88 01 00 	mov    0x188(%rsp),%rsi
  6fb67f:	00 
  6fb680:	48 85 f6             	test   %rsi,%rsi
  6fb683:	74 14                	je     6fb699 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4659>
  6fb685:	48 c1 e6 05          	shl    $0x5,%rsi
  6fb689:	ba 08 00 00 00       	mov    $0x8,%edx
  6fb68e:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
  6fb693:	ff 15 cf 00 39 00    	call   *0x3900cf(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fb699:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6fb69e:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6fb6a5:	00 
  6fb6a6:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  6fb6ab:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  6fb6b2:	00 
  6fb6b3:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  6fb6b8:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  6fb6bf:	00 
  6fb6c0:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  6fb6c5:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  6fb6cc:	00 
  6fb6cd:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  6fb6d2:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  6fb6d9:	00 
  6fb6da:	0f 28 84 24 60 03 00 	movaps 0x360(%rsp),%xmm0
  6fb6e1:	00 
  6fb6e2:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
  6fb6e9:	00 
  6fb6ea:	0f 28 84 24 30 01 00 	movaps 0x130(%rsp),%xmm0
  6fb6f1:	00 
  6fb6f2:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
  6fb6f9:	00 
  6fb6fa:	48 8b 84 24 a8 02 00 	mov    0x2a8(%rsp),%rax
  6fb701:	00 
  6fb702:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
  6fb709:	00 
  6fb70a:	48 8b 84 24 10 05 00 	mov    0x510(%rsp),%rax
  6fb711:	00 
  6fb712:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6fb719:	00 
  6fb71a:	66 0f 28 84 24 50 04 	movapd 0x450(%rsp),%xmm0
  6fb721:	00 00 
  6fb723:	48 8d 84 24 88 00 00 	lea    0x88(%rsp),%rax
  6fb72a:	00 
  6fb72b:	66 0f 11 00          	movupd %xmm0,(%rax)
  6fb72f:	48 8b 84 24 10 02 00 	mov    0x210(%rsp),%rax
  6fb736:	00 
  6fb737:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
  6fb73e:	00 
  6fb73f:	48 8b 84 24 20 05 00 	mov    0x520(%rsp),%rax
  6fb746:	00 
  6fb747:	48 85 c0             	test   %rax,%rax
  6fb74a:	4c 8b 7c 24 78       	mov    0x78(%rsp),%r15
  6fb74f:	4c 8b b4 24 a0 02 00 	mov    0x2a0(%rsp),%r14
  6fb756:	00 
  6fb757:	0f 84 dd 00 00 00    	je     6fb83a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x47fa>
  6fb75d:	48 8b 8c 24 28 05 00 	mov    0x528(%rsp),%rcx
  6fb764:	00 
  6fb765:	0f b7 b8 8a 05 00 00 	movzwl 0x58a(%rax),%edi
  6fb76c:	48 8d 70 40          	lea    0x40(%rax),%rsi
  6fb770:	41 89 f8             	mov    %edi,%r8d
  6fb773:	41 c1 e0 04          	shl    $0x4,%r8d
  6fb777:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6fb77e:	45 31 c9             	xor    %r9d,%r9d
  6fb781:	eb 21                	jmp    6fb7a4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4764>
  6fb783:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fb78a:	84 00 00 00 00 00 
  6fb790:	41 f6 da             	neg    %r10b
  6fb793:	48 83 c6 70          	add    $0x70,%rsi
  6fb797:	48 ff c2             	inc    %rdx
  6fb79a:	49 83 c1 10          	add    $0x10,%r9
  6fb79e:	41 80 fa 01          	cmp    $0x1,%r10b
  6fb7a2:	75 1e                	jne    6fb7c2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4782>
  6fb7a4:	4d 39 c8             	cmp    %r9,%r8
  6fb7a7:	74 23                	je     6fb7cc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x478c>
  6fb7a9:	46 0f b6 14 08       	movzbl (%rax,%r9,1),%r10d
  6fb7ae:	45 84 d2             	test   %r10b,%r10b
  6fb7b1:	75 dd                	jne    6fb790 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4750>
  6fb7b3:	4a 3b 5c 08 08       	cmp    0x8(%rax,%r9,1),%rbx
  6fb7b8:	41 0f 97 c2          	seta   %r10b
  6fb7bc:	41 80 da 00          	sbb    $0x0,%r10b
  6fb7c0:	eb d1                	jmp    6fb793 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4753>
  6fb7c2:	41 0f b6 fa          	movzbl %r10b,%edi
  6fb7c6:	85 ff                	test   %edi,%edi
  6fb7c8:	75 05                	jne    6fb7cf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x478f>
  6fb7ca:	eb 13                	jmp    6fb7df <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x479f>
  6fb7cc:	48 89 fa             	mov    %rdi,%rdx
  6fb7cf:	48 83 e9 01          	sub    $0x1,%rcx
  6fb7d3:	72 67                	jb     6fb83c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x47fc>
  6fb7d5:	48 8b 84 d0 90 05 00 	mov    0x590(%rax,%rdx,8),%rax
  6fb7dc:	00 
  6fb7dd:	eb 86                	jmp    6fb765 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4725>
  6fb7df:	0f 10 84 24 e0 00 00 	movups 0xe0(%rsp),%xmm0
  6fb7e6:	00 
  6fb7e7:	0f 11 46 60          	movups %xmm0,0x60(%rsi)
  6fb7eb:	0f 10 84 24 d0 00 00 	movups 0xd0(%rsp),%xmm0
  6fb7f2:	00 
  6fb7f3:	0f 11 46 50          	movups %xmm0,0x50(%rsi)
  6fb7f7:	0f 10 84 24 c0 00 00 	movups 0xc0(%rsp),%xmm0
  6fb7fe:	00 
  6fb7ff:	0f 11 46 40          	movups %xmm0,0x40(%rsi)
  6fb803:	66 0f 10 84 24 80 00 	movupd 0x80(%rsp),%xmm0
  6fb80a:	00 00 
  6fb80c:	66 0f 10 8c 24 90 00 	movupd 0x90(%rsp),%xmm1
  6fb813:	00 00 
  6fb815:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
  6fb81c:	00 00 
  6fb81e:	0f 10 9c 24 b0 00 00 	movups 0xb0(%rsp),%xmm3
  6fb825:	00 
  6fb826:	0f 11 5e 30          	movups %xmm3,0x30(%rsi)
  6fb82a:	f3 0f 7f 56 20       	movdqu %xmm2,0x20(%rsi)
  6fb82f:	66 0f 11 4e 10       	movupd %xmm1,0x10(%rsi)
  6fb834:	66 0f 11 06          	movupd %xmm0,(%rsi)
  6fb838:	eb 5f                	jmp    6fb899 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4859>
  6fb83a:	31 c0                	xor    %eax,%eax
  6fb83c:	48 c7 84 24 d0 02 00 	movq   $0x0,0x2d0(%rsp)
  6fb843:	00 00 00 00 00 
  6fb848:	48 89 9c 24 d8 02 00 	mov    %rbx,0x2d8(%rsp)
  6fb84f:	00 
  6fb850:	48 8d 8c 24 20 05 00 	lea    0x520(%rsp),%rcx
  6fb857:	00 
  6fb858:	48 89 8c 24 e0 02 00 	mov    %rcx,0x2e0(%rsp)
  6fb85f:	00 
  6fb860:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
  6fb867:	00 
  6fb868:	48 c7 84 24 f0 02 00 	movq   $0x0,0x2f0(%rsp)
  6fb86f:	00 00 00 00 00 
  6fb874:	48 89 94 24 f8 02 00 	mov    %rdx,0x2f8(%rsp)
  6fb87b:	00 
  6fb87c:	48 8d bc 24 90 01 00 	lea    0x190(%rsp),%rdi
  6fb883:	00 
  6fb884:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
  6fb88b:	00 
  6fb88c:	48 8d 94 24 80 00 00 	lea    0x80(%rsp),%rdx
  6fb893:	00 
  6fb894:	e8 b7 61 01 00       	call   711a50 <<alloc::collections::btree::map::entry::VacantEntry<gpui::runtime::scroll::ViewportKey, gpui::runtime::scroll::ViewportState>>::insert_entry>
  6fb899:	48 8b 8c 24 30 02 00 	mov    0x230(%rsp),%rcx
  6fb8a0:	00 
  6fb8a1:	48 8b b4 24 18 02 00 	mov    0x218(%rsp),%rsi
  6fb8a8:	00 
  6fb8a9:	48 85 f6             	test   %rsi,%rsi
  6fb8ac:	0f 84 be f8 ff ff    	je     6fb170 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4130>
  6fb8b2:	48 c1 e6 03          	shl    $0x3,%rsi
  6fb8b6:	ba 08 00 00 00       	mov    $0x8,%edx
  6fb8bb:	48 8b bc 24 00 04 00 	mov    0x400(%rsp),%rdi
  6fb8c2:	00 
  6fb8c3:	ff 15 9f fe 38 00    	call   *0x38fe9f(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fb8c9:	48 8b 8c 24 30 02 00 	mov    0x230(%rsp),%rcx
  6fb8d0:	00 
  6fb8d1:	e9 9a f8 ff ff       	jmp    6fb170 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4130>
  6fb8d6:	4c 8b ac 24 e8 01 00 	mov    0x1e8(%rsp),%r13
  6fb8dd:	00 
  6fb8de:	4c 89 ac 24 78 03 00 	mov    %r13,0x378(%rsp)
  6fb8e5:	00 
  6fb8e6:	48 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%rsi
  6fb8ed:	00 
  6fb8ee:	48 89 f0             	mov    %rsi,%rax
  6fb8f1:	4c 29 e8             	sub    %r13,%rax
  6fb8f4:	48 c1 e8 03          	shr    $0x3,%rax
  6fb8f8:	48 b9 31 0c c3 30 0c 	movabs $0xc30c30c30c30c31,%rcx
  6fb8ff:	c3 30 0c 
  6fb902:	48 f7 e1             	mul    %rcx
  6fb905:	4c 39 ee             	cmp    %r13,%rsi
  6fb908:	4c 8b a4 24 90 02 00 	mov    0x290(%rsp),%r12
  6fb90f:	00 
  6fb910:	74 5e                	je     6fb970 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4930>
  6fb912:	48 89 d3             	mov    %rdx,%rbx
  6fb915:	49 81 c5 88 00 00 00 	add    $0x88,%r13
  6fb91c:	4c 8b 35 45 fe 38 00 	mov    0x38fe45(%rip),%r14        # a8b768 <_DYNAMIC+0x250>
  6fb923:	eb 17                	jmp    6fb93c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x48fc>
  6fb925:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6fb92c:	00 00 00 00 
  6fb930:	49 81 c5 a8 00 00 00 	add    $0xa8,%r13
  6fb937:	48 ff cb             	dec    %rbx
  6fb93a:	74 34                	je     6fb970 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4930>
  6fb93c:	49 8b 75 90          	mov    -0x70(%r13),%rsi
  6fb940:	48 85 f6             	test   %rsi,%rsi
  6fb943:	74 10                	je     6fb955 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4915>
  6fb945:	49 8b 7d 98          	mov    -0x68(%r13),%rdi
  6fb949:	48 c1 e6 03          	shl    $0x3,%rsi
  6fb94d:	ba 08 00 00 00       	mov    $0x8,%edx
  6fb952:	41 ff d6             	call   *%r14
  6fb955:	49 8b 75 f8          	mov    -0x8(%r13),%rsi
  6fb959:	48 85 f6             	test   %rsi,%rsi
  6fb95c:	74 d2                	je     6fb930 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x48f0>
  6fb95e:	49 8b 7d 00          	mov    0x0(%r13),%rdi
  6fb962:	48 c1 e6 05          	shl    $0x5,%rsi
  6fb966:	ba 08 00 00 00       	mov    $0x8,%edx
  6fb96b:	41 ff d6             	call   *%r14
  6fb96e:	eb c0                	jmp    6fb930 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x48f0>
  6fb970:	4d 85 e4             	test   %r12,%r12
  6fb973:	74 1a                	je     6fb98f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x494f>
  6fb975:	49 69 f4 a8 00 00 00 	imul   $0xa8,%r12,%rsi
  6fb97c:	ba 08 00 00 00       	mov    $0x8,%edx
  6fb981:	48 8b bc 24 98 02 00 	mov    0x298(%rsp),%rdi
  6fb988:	00 
  6fb989:	ff 15 d9 fd 38 00    	call   *0x38fdd9(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fb98f:	48 8b 84 24 38 05 00 	mov    0x538(%rsp),%rax
  6fb996:	00 
  6fb997:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6fb99c:	48 8b 84 24 40 05 00 	mov    0x540(%rsp),%rax
  6fb9a3:	00 
  6fb9a4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6fb9a9:	48 8b ac 24 48 05 00 	mov    0x548(%rsp),%rbp
  6fb9b0:	00 
  6fb9b1:	48 85 ed             	test   %rbp,%rbp
  6fb9b4:	0f 84 04 03 00 00    	je     6fbcbe <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c7e>
  6fb9ba:	48 c1 e5 04          	shl    $0x4,%rbp
  6fb9be:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
  6fb9c3:	48 01 dd             	add    %rbx,%rbp
  6fb9c6:	4c 8d ac 24 80 00 00 	lea    0x80(%rsp),%r13
  6fb9cd:	00 
  6fb9ce:	eb 66                	jmp    6fba36 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x49f6>
  6fb9d0:	0f 10 84 24 e0 00 00 	movups 0xe0(%rsp),%xmm0
  6fb9d7:	00 
  6fb9d8:	0f 11 47 60          	movups %xmm0,0x60(%rdi)
  6fb9dc:	0f 10 84 24 d0 00 00 	movups 0xd0(%rsp),%xmm0
  6fb9e3:	00 
  6fb9e4:	0f 11 47 50          	movups %xmm0,0x50(%rdi)
  6fb9e8:	0f 10 84 24 c0 00 00 	movups 0xc0(%rsp),%xmm0
  6fb9ef:	00 
  6fb9f0:	0f 11 47 40          	movups %xmm0,0x40(%rdi)
  6fb9f4:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
  6fb9fb:	00 00 
  6fb9fd:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
  6fba04:	00 00 
  6fba06:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
  6fba0d:	00 00 
  6fba0f:	0f 10 9c 24 b0 00 00 	movups 0xb0(%rsp),%xmm3
  6fba16:	00 
  6fba17:	0f 11 5f 30          	movups %xmm3,0x30(%rdi)
  6fba1b:	f3 0f 7f 57 20       	movdqu %xmm2,0x20(%rdi)
  6fba20:	f3 0f 7f 4f 10       	movdqu %xmm1,0x10(%rdi)
  6fba25:	f3 0f 7f 07          	movdqu %xmm0,(%rdi)
  6fba29:	48 83 c3 10          	add    $0x10,%rbx
  6fba2d:	48 39 eb             	cmp    %rbp,%rbx
  6fba30:	0f 84 88 02 00 00    	je     6fbcbe <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c7e>
  6fba36:	48 8b 3b             	mov    (%rbx),%rdi
  6fba39:	48 8b b4 24 78 01 00 	mov    0x178(%rsp),%rsi
  6fba40:	00 
  6fba41:	48 39 f7             	cmp    %rsi,%rdi
  6fba44:	0f 83 92 1f 00 00    	jae    6fd9dc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x699c>
  6fba4a:	0f b6 4b 08          	movzbl 0x8(%rbx),%ecx
  6fba4e:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  6fba55:	00 
  6fba56:	48 8d 14 7f          	lea    (%rdi,%rdi,2),%rdx
  6fba5a:	48 8b 04 d0          	mov    (%rax,%rdx,8),%rax
  6fba5e:	48 8b 94 24 30 02 00 	mov    0x230(%rsp),%rdx
  6fba65:	00 
  6fba66:	48 8b 12             	mov    (%rdx),%rdx
  6fba69:	48 85 d2             	test   %rdx,%rdx
  6fba6c:	0f 84 2a 01 00 00    	je     6fbb9c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b5c>
  6fba72:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  6fba77:	48 8b b6 50 06 00 00 	mov    0x650(%rsi),%rsi
  6fba7e:	48 89 f7             	mov    %rsi,%rdi
  6fba81:	49 89 d0             	mov    %rdx,%r8
  6fba84:	45 0f b7 b0 8a 05 00 	movzwl 0x58a(%r8),%r14d
  6fba8b:	00 
  6fba8c:	4d 8d 48 48          	lea    0x48(%r8),%r9
  6fba90:	45 89 f3             	mov    %r14d,%r11d
  6fba93:	41 c1 e3 04          	shl    $0x4,%r11d
  6fba97:	49 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%r10
  6fba9e:	45 31 ff             	xor    %r15d,%r15d
  6fbaa1:	eb 2b                	jmp    6fbace <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4a8e>
  6fbaa3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fbaaa:	84 00 00 00 00 00 
  6fbab0:	4b 3b 44 38 08       	cmp    0x8(%r8,%r15,1),%rax
  6fbab5:	41 0f 97 c4          	seta   %r12b
  6fbab9:	41 80 dc 00          	sbb    $0x0,%r12b
  6fbabd:	49 83 c1 70          	add    $0x70,%r9
  6fbac1:	49 ff c2             	inc    %r10
  6fbac4:	49 83 c7 10          	add    $0x10,%r15
  6fbac8:	41 80 fc 01          	cmp    $0x1,%r12b
  6fbacc:	75 12                	jne    6fbae0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4aa0>
  6fbace:	4d 39 fb             	cmp    %r15,%r11
  6fbad1:	74 18                	je     6fbaeb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4aab>
  6fbad3:	4b 83 3c 38 00       	cmpq   $0x0,(%r8,%r15,1)
  6fbad8:	75 d6                	jne    6fbab0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4a70>
  6fbada:	41 b4 01             	mov    $0x1,%r12b
  6fbadd:	eb de                	jmp    6fbabd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4a7d>
  6fbadf:	90                   	nop
  6fbae0:	45 0f b6 dc          	movzbl %r12b,%r11d
  6fbae4:	45 85 db             	test   %r11d,%r11d
  6fbae7:	75 05                	jne    6fbaee <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4aae>
  6fbae9:	eb 17                	jmp    6fbb02 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4ac2>
  6fbaeb:	4d 89 f2             	mov    %r14,%r10
  6fbaee:	48 83 ef 01          	sub    $0x1,%rdi
  6fbaf2:	0f 82 b8 01 00 00    	jb     6fbcb0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c70>
  6fbaf8:	4f 8b 84 d0 90 05 00 	mov    0x590(%r8,%r10,8),%r8
  6fbaff:	00 
  6fbb00:	eb 82                	jmp    6fba84 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4a44>
  6fbb02:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fbb06:	41 83 79 f8 02       	cmpl   $0x2,-0x8(%r9)
  6fbb0b:	4c 8b 7c 24 78       	mov    0x78(%rsp),%r15
  6fbb10:	75 0e                	jne    6fbb20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4ae0>
  6fbb12:	f3 41 0f 6f 01       	movdqu (%r9),%xmm0
  6fbb17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6fbb1e:	00 00 
  6fbb20:	44 0f b7 8a 8a 05 00 	movzwl 0x58a(%rdx),%r9d
  6fbb27:	00 
  6fbb28:	4c 8d 42 40          	lea    0x40(%rdx),%r8
  6fbb2c:	45 89 ca             	mov    %r9d,%r10d
  6fbb2f:	41 c1 e2 04          	shl    $0x4,%r10d
  6fbb33:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
  6fbb3a:	45 31 db             	xor    %r11d,%r11d
  6fbb3d:	eb 1f                	jmp    6fbb5e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b1e>
  6fbb3f:	90                   	nop
  6fbb40:	4a 3b 44 1a 08       	cmp    0x8(%rdx,%r11,1),%rax
  6fbb45:	41 0f 97 c6          	seta   %r14b
  6fbb49:	41 80 de 00          	sbb    $0x0,%r14b
  6fbb4d:	49 83 c0 70          	add    $0x70,%r8
  6fbb51:	48 ff c7             	inc    %rdi
  6fbb54:	49 83 c3 10          	add    $0x10,%r11
  6fbb58:	41 80 fe 01          	cmp    $0x1,%r14b
  6fbb5c:	75 12                	jne    6fbb70 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b30>
  6fbb5e:	4d 39 da             	cmp    %r11,%r10
  6fbb61:	74 18                	je     6fbb7b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b3b>
  6fbb63:	4a 83 3c 1a 00       	cmpq   $0x0,(%rdx,%r11,1)
  6fbb68:	75 d6                	jne    6fbb40 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b00>
  6fbb6a:	41 b6 01             	mov    $0x1,%r14b
  6fbb6d:	eb de                	jmp    6fbb4d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b0d>
  6fbb6f:	90                   	nop
  6fbb70:	45 0f b6 ce          	movzbl %r14b,%r9d
  6fbb74:	45 85 c9             	test   %r9d,%r9d
  6fbb77:	75 05                	jne    6fbb7e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b3e>
  6fbb79:	eb 13                	jmp    6fbb8e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b4e>
  6fbb7b:	4c 89 cf             	mov    %r9,%rdi
  6fbb7e:	48 83 ee 01          	sub    $0x1,%rsi
  6fbb82:	72 1c                	jb     6fbba0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b60>
  6fbb84:	48 8b 94 fa 90 05 00 	mov    0x590(%rdx,%rdi,8),%rdx
  6fbb8b:	00 
  6fbb8c:	eb 92                	jmp    6fbb20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4ae0>
  6fbb8e:	41 83 38 02          	cmpl   $0x2,(%r8)
  6fbb92:	75 0c                	jne    6fbba0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b60>
  6fbb94:	41 38 48 18          	cmp    %cl,0x18(%r8)
  6fbb98:	75 06                	jne    6fbba0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b60>
  6fbb9a:	eb 10                	jmp    6fbbac <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b6c>
  6fbb9c:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fbba0:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6fbba5:	c6 82 4b 07 00 00 01 	movb   $0x1,0x74b(%rdx)
  6fbbac:	f3 0f 7f 84 24 88 00 	movdqu %xmm0,0x88(%rsp)
  6fbbb3:	00 00 
  6fbbb5:	88 8c 24 98 00 00 00 	mov    %cl,0x98(%rsp)
  6fbbbc:	48 c7 84 24 80 00 00 	movq   $0x2,0x80(%rsp)
  6fbbc3:	00 02 00 00 00 
  6fbbc8:	48 8b 8c 24 20 05 00 	mov    0x520(%rsp),%rcx
  6fbbcf:	00 
  6fbbd0:	48 85 c9             	test   %rcx,%rcx
  6fbbd3:	74 7c                	je     6fbc51 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c11>
  6fbbd5:	48 8b 94 24 28 05 00 	mov    0x528(%rsp),%rdx
  6fbbdc:	00 
  6fbbdd:	44 0f b7 81 8a 05 00 	movzwl 0x58a(%rcx),%r8d
  6fbbe4:	00 
  6fbbe5:	48 8d 79 40          	lea    0x40(%rcx),%rdi
  6fbbe9:	45 89 c1             	mov    %r8d,%r9d
  6fbbec:	41 c1 e1 04          	shl    $0x4,%r9d
  6fbbf0:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
  6fbbf7:	45 31 d2             	xor    %r10d,%r10d
  6fbbfa:	eb 22                	jmp    6fbc1e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4bde>
  6fbbfc:	0f 1f 40 00          	nopl   0x0(%rax)
  6fbc00:	4a 3b 44 11 08       	cmp    0x8(%rcx,%r10,1),%rax
  6fbc05:	41 0f 97 c3          	seta   %r11b
  6fbc09:	41 80 db 00          	sbb    $0x0,%r11b
  6fbc0d:	48 83 c7 70          	add    $0x70,%rdi
  6fbc11:	48 ff c6             	inc    %rsi
  6fbc14:	49 83 c2 10          	add    $0x10,%r10
  6fbc18:	41 80 fb 01          	cmp    $0x1,%r11b
  6fbc1c:	75 12                	jne    6fbc30 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4bf0>
  6fbc1e:	4d 39 d1             	cmp    %r10,%r9
  6fbc21:	74 1b                	je     6fbc3e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4bfe>
  6fbc23:	4a 83 3c 11 00       	cmpq   $0x0,(%rcx,%r10,1)
  6fbc28:	75 d6                	jne    6fbc00 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4bc0>
  6fbc2a:	41 b3 01             	mov    $0x1,%r11b
  6fbc2d:	eb de                	jmp    6fbc0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4bcd>
  6fbc2f:	90                   	nop
  6fbc30:	45 0f b6 c3          	movzbl %r11b,%r8d
  6fbc34:	45 85 c0             	test   %r8d,%r8d
  6fbc37:	75 08                	jne    6fbc41 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c01>
  6fbc39:	e9 92 fd ff ff       	jmp    6fb9d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4990>
  6fbc3e:	4c 89 c6             	mov    %r8,%rsi
  6fbc41:	48 83 ea 01          	sub    $0x1,%rdx
  6fbc45:	72 0c                	jb     6fbc53 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c13>
  6fbc47:	48 8b 8c f1 90 05 00 	mov    0x590(%rcx,%rsi,8),%rcx
  6fbc4e:	00 
  6fbc4f:	eb 8c                	jmp    6fbbdd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4b9d>
  6fbc51:	31 c9                	xor    %ecx,%ecx
  6fbc53:	48 c7 84 24 d0 02 00 	movq   $0x1,0x2d0(%rsp)
  6fbc5a:	00 01 00 00 00 
  6fbc5f:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
  6fbc66:	00 
  6fbc67:	48 8d 84 24 20 05 00 	lea    0x520(%rsp),%rax
  6fbc6e:	00 
  6fbc6f:	48 89 84 24 e0 02 00 	mov    %rax,0x2e0(%rsp)
  6fbc76:	00 
  6fbc77:	48 89 8c 24 e8 02 00 	mov    %rcx,0x2e8(%rsp)
  6fbc7e:	00 
  6fbc7f:	48 c7 84 24 f0 02 00 	movq   $0x0,0x2f0(%rsp)
  6fbc86:	00 00 00 00 00 
  6fbc8b:	48 89 b4 24 f8 02 00 	mov    %rsi,0x2f8(%rsp)
  6fbc92:	00 
  6fbc93:	48 8d bc 24 90 01 00 	lea    0x190(%rsp),%rdi
  6fbc9a:	00 
  6fbc9b:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
  6fbca2:	00 
  6fbca3:	4c 89 ea             	mov    %r13,%rdx
  6fbca6:	e8 a5 5d 01 00       	call   711a50 <<alloc::collections::btree::map::entry::VacantEntry<gpui::runtime::scroll::ViewportKey, gpui::runtime::scroll::ViewportState>>::insert_entry>
  6fbcab:	e9 79 fd ff ff       	jmp    6fba29 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x49e9>
  6fbcb0:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fbcb4:	4c 8b 7c 24 78       	mov    0x78(%rsp),%r15
  6fbcb9:	e9 62 fe ff ff       	jmp    6fbb20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4ae0>
  6fbcbe:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  6fbcc3:	48 85 f6             	test   %rsi,%rsi
  6fbcc6:	74 14                	je     6fbcdc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4c9c>
  6fbcc8:	48 c1 e6 04          	shl    $0x4,%rsi
  6fbccc:	ba 08 00 00 00       	mov    $0x8,%edx
  6fbcd1:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6fbcd6:	ff 15 8c fa 38 00    	call   *0x38fa8c(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fbcdc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fbce1:	4c 8d b0 40 06 00 00 	lea    0x640(%rax),%r14
  6fbce8:	48 8b 9c 24 e0 04 00 	mov    0x4e0(%rsp),%rbx
  6fbcef:	00 
  6fbcf0:	48 85 db             	test   %rbx,%rbx
  6fbcf3:	4c 8b ac 24 80 01 00 	mov    0x180(%rsp),%r13
  6fbcfa:	00 
  6fbcfb:	4c 89 b4 24 30 01 00 	mov    %r14,0x130(%rsp)
  6fbd02:	00 
  6fbd03:	75 32                	jne    6fbd37 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4cf7>
  6fbd05:	48 83 bc 24 30 05 00 	cmpq   $0x0,0x530(%rsp)
  6fbd0c:	00 00 
  6fbd0e:	75 27                	jne    6fbd37 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4cf7>
  6fbd10:	49 83 3e 00          	cmpq   $0x0,(%r14)
  6fbd14:	75 21                	jne    6fbd37 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4cf7>
  6fbd16:	40 b5 01             	mov    $0x1,%bpl
  6fbd19:	4d 85 ff             	test   %r15,%r15
  6fbd1c:	0f 84 dc 0d 00 00    	je     6fcafe <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5abe>
  6fbd22:	4c 8b b4 24 70 01 00 	mov    0x170(%rsp),%r14
  6fbd29:	00 
  6fbd2a:	4c 8b bc 24 78 01 00 	mov    0x178(%rsp),%r15
  6fbd31:	00 
  6fbd32:	e9 7f 02 00 00       	jmp    6fbfb6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4f76>
  6fbd37:	4c 89 f7             	mov    %r14,%rdi
  6fbd3a:	e8 f1 58 fe ff       	call   6e1630 <<core::option::Option<alloc::boxed::Box<gpui::runtime::metadata::Metadata>>>::get_or_insert_with::<<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#44}>>
  6fbd3f:	4c 8b ac 24 d8 04 00 	mov    0x4d8(%rsp),%r13
  6fbd46:	00 
  6fbd47:	48 85 db             	test   %rbx,%rbx
  6fbd4a:	74 0f                	je     6fbd5b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d1b>
  6fbd4c:	48 83 fb 01          	cmp    $0x1,%rbx
  6fbd50:	75 68                	jne    6fbdba <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d7a>
  6fbd52:	31 c0                	xor    %eax,%eax
  6fbd54:	31 f6                	xor    %esi,%esi
  6fbd56:	e9 af 00 00 00       	jmp    6fbe0a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4dca>
  6fbd5b:	31 f6                	xor    %esi,%esi
  6fbd5d:	e9 c6 00 00 00       	jmp    6fbe28 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4de8>
  6fbd62:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  6fbd67:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6fbd6c:	4c 89 60 10          	mov    %r12,0x10(%rax)
  6fbd70:	48 c7 00 20 00 00 00 	movq   $0x20,(%rax)
  6fbd77:	48 c7 40 08 0c 00 00 	movq   $0xc,0x8(%rax)
  6fbd7e:	00 
  6fbd7f:	48 8b b4 24 68 02 00 	mov    0x268(%rsp),%rsi
  6fbd86:	00 
  6fbd87:	48 85 f6             	test   %rsi,%rsi
  6fbd8a:	74 17                	je     6fbda3 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d63>
  6fbd8c:	48 8b bc 24 70 02 00 	mov    0x270(%rsp),%rdi
  6fbd93:	00 
  6fbd94:	48 c1 e6 04          	shl    $0x4,%rsi
  6fbd98:	ba 08 00 00 00       	mov    $0x8,%edx
  6fbd9d:	ff 15 c5 f9 38 00    	call   *0x38f9c5(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fbda3:	31 db                	xor    %ebx,%ebx
  6fbda5:	48 8d bc 24 e0 07 00 	lea    0x7e0(%rsp),%rdi
  6fbdac:	00 
  6fbdad:	e8 ae b5 fe ff       	call   6e7360 <core::ptr::drop_glue::<gpui::runtime::styles::colours::Discovery>>
  6fbdb2:	45 31 ed             	xor    %r13d,%r13d
  6fbdb5:	e9 80 14 00 00       	jmp    6fd23a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61fa>
  6fbdba:	48 b9 fe ff ff ff ff 	movabs $0x3fffffffffffffe,%rcx
  6fbdc1:	ff ff 03 
  6fbdc4:	48 21 d9             	and    %rbx,%rcx
  6fbdc7:	31 c0                	xor    %eax,%eax
  6fbdc9:	4c 89 ea             	mov    %r13,%rdx
  6fbdcc:	31 f6                	xor    %esi,%esi
  6fbdce:	48 8b 7a 18          	mov    0x18(%rdx),%rdi
  6fbdd2:	4c 8b 42 50          	mov    0x50(%rdx),%r8
  6fbdd6:	48 23 3a             	and    (%rdx),%rdi
  6fbdd9:	45 31 c9             	xor    %r9d,%r9d
  6fbddc:	48 83 ff ff          	cmp    $0xffffffffffffffff,%rdi
  6fbde0:	41 0f 95 c1          	setne  %r9b
  6fbde4:	4c 23 42 38          	and    0x38(%rdx),%r8
  6fbde8:	49 01 f1             	add    %rsi,%r9
  6fbdeb:	31 f6                	xor    %esi,%esi
  6fbded:	49 83 f8 ff          	cmp    $0xffffffffffffffff,%r8
  6fbdf1:	40 0f 95 c6          	setne  %sil
  6fbdf5:	4c 01 ce             	add    %r9,%rsi
  6fbdf8:	48 83 c0 02          	add    $0x2,%rax
  6fbdfc:	48 83 c2 70          	add    $0x70,%rdx
  6fbe00:	48 39 c1             	cmp    %rax,%rcx
  6fbe03:	75 c9                	jne    6fbdce <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4d8e>
  6fbe05:	f6 c3 01             	test   $0x1,%bl
  6fbe08:	74 1e                	je     6fbe28 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4de8>
  6fbe0a:	48 89 f1             	mov    %rsi,%rcx
  6fbe0d:	48 6b c0 38          	imul   $0x38,%rax,%rax
  6fbe11:	49 8b 54 05 18       	mov    0x18(%r13,%rax,1),%rdx
  6fbe16:	49 23 54 05 00       	and    0x0(%r13,%rax,1),%rdx
  6fbe1b:	31 f6                	xor    %esi,%esi
  6fbe1d:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
  6fbe21:	40 0f 95 c6          	setne  %sil
  6fbe25:	48 01 ce             	add    %rcx,%rsi
  6fbe28:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  6fbe2f:	00 
  6fbe30:	b9 08 00 00 00       	mov    $0x8,%ecx
  6fbe35:	41 b8 18 00 00 00    	mov    $0x18,%r8d
  6fbe3b:	31 d2                	xor    %edx,%edx
  6fbe3d:	e8 4e 53 02 00       	call   721190 <<alloc::raw_vec::RawVecInner>::try_allocate_in>
  6fbe42:	48 8b bc 24 88 00 00 	mov    0x88(%rsp),%rdi
  6fbe49:	00 
  6fbe4a:	83 bc 24 80 00 00 00 	cmpl   $0x1,0x80(%rsp)
  6fbe51:	01 
  6fbe52:	0f 84 ee 1a 00 00    	je     6fd946 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6906>
  6fbe58:	48 6b f3 38          	imul   $0x38,%rbx,%rsi
  6fbe5c:	4c 01 ee             	add    %r13,%rsi
  6fbe5f:	48 8b 8c 24 68 02 00 	mov    0x268(%rsp),%rcx
  6fbe66:	00 
  6fbe67:	48 8b 84 24 70 02 00 	mov    0x270(%rsp),%rax
  6fbe6e:	00 
  6fbe6f:	4c 8b 84 24 78 02 00 	mov    0x278(%rsp),%r8
  6fbe76:	00 
  6fbe77:	49 c1 e0 04          	shl    $0x4,%r8
  6fbe7b:	49 01 c0             	add    %rax,%r8
  6fbe7e:	48 89 bc 24 b8 04 00 	mov    %rdi,0x4b8(%rsp)
  6fbe85:	00 
  6fbe86:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
  6fbe8d:	00 
  6fbe8e:	48 89 94 24 c0 04 00 	mov    %rdx,0x4c0(%rsp)
  6fbe95:	00 
  6fbe96:	48 c7 84 24 c8 04 00 	movq   $0x0,0x4c8(%rsp)
  6fbe9d:	00 00 00 00 00 
  6fbea2:	48 8b 94 24 d0 04 00 	mov    0x4d0(%rsp),%rdx
  6fbea9:	00 
  6fbeaa:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fbeae:	f3 0f 7f 84 24 c0 00 	movdqu %xmm0,0xc0(%rsp)
  6fbeb5:	00 00 
  6fbeb7:	4c 89 ac 24 80 00 00 	mov    %r13,0x80(%rsp)
  6fbebe:	00 
  6fbebf:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
  6fbec6:	00 
  6fbec7:	48 89 94 24 90 00 00 	mov    %rdx,0x90(%rsp)
  6fbece:	00 
  6fbecf:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  6fbed4:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
  6fbedb:	00 
  6fbedc:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6fbee3:	00 
  6fbee4:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  6fbeeb:	00 
  6fbeec:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
  6fbef3:	00 
  6fbef4:	4c 89 44 24 30       	mov    %r8,0x30(%rsp)
  6fbef9:	4c 89 84 24 b8 00 00 	mov    %r8,0xb8(%rsp)
  6fbf00:	00 
  6fbf01:	48 85 db             	test   %rbx,%rbx
  6fbf04:	0f 85 6f 02 00 00    	jne    6fc179 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5139>
  6fbf0a:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  6fbf11:	00 
  6fbf12:	e8 89 8c fe ff       	call   6e4ba0 <core::ptr::drop_glue::<core::iter::adapters::zip::Zip<alloc::vec::into_iter::IntoIter<gpui::semantic::AnnotationDraft>, alloc::vec::into_iter::IntoIter<[core::option::Option<gpui::source::FieldId>; 2]>>>>
  6fbf17:	48 8b bc 24 c0 04 00 	mov    0x4c0(%rsp),%rdi
  6fbf1e:	00 
  6fbf1f:	48 8b b4 24 c8 04 00 	mov    0x4c8(%rsp),%rsi
  6fbf26:	00 
  6fbf27:	e8 b4 55 fe ff       	call   6e14e0 <<[gpui::runtime::metadata::Declared]>::sort_unstable_by_key::<u64, <gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#48}>>
  6fbf2c:	48 8b 84 24 c8 04 00 	mov    0x4c8(%rsp),%rax
  6fbf33:	00 
  6fbf34:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6fbf3b:	00 
  6fbf3c:	0f 10 84 24 b8 04 00 	movups 0x4b8(%rsp),%xmm0
  6fbf43:	00 
  6fbf44:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  6fbf4b:	00 
  6fbf4c:	bf c0 00 00 00       	mov    $0xc0,%edi
  6fbf51:	48 8b 9c 24 30 01 00 	mov    0x130(%rsp),%rbx
  6fbf58:	00 
  6fbf59:	48 03 3b             	add    (%rbx),%rdi
  6fbf5c:	e8 0f 84 fe ff       	call   6e4370 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::metadata::Declared>>>
  6fbf61:	4c 8b ac 24 80 01 00 	mov    0x180(%rsp),%r13
  6fbf68:	00 
  6fbf69:	48 8b 03             	mov    (%rbx),%rax
  6fbf6c:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  6fbf73:	00 
  6fbf74:	48 89 88 d0 00 00 00 	mov    %rcx,0xd0(%rax)
  6fbf7b:	66 0f 6f 84 24 80 00 	movdqa 0x80(%rsp),%xmm0
  6fbf82:	00 00 
  6fbf84:	f3 0f 7f 80 c0 00 00 	movdqu %xmm0,0xc0(%rax)
  6fbf8b:	00 
  6fbf8c:	48 8b 1b             	mov    (%rbx),%rbx
  6fbf8f:	4c 8b b4 24 70 01 00 	mov    0x170(%rsp),%r14
  6fbf96:	00 
  6fbf97:	4c 8b bc 24 78 01 00 	mov    0x178(%rsp),%r15
  6fbf9e:	00 
  6fbf9f:	48 83 7c 24 78 00    	cmpq   $0x0,0x78(%rsp)
  6fbfa5:	0f 84 56 12 00 00    	je     6fd201 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61c1>
  6fbfab:	31 ed                	xor    %ebp,%ebp
  6fbfad:	48 85 db             	test   %rbx,%rbx
  6fbfb0:	0f 85 b6 00 00 00    	jne    6fc06c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x502c>
  6fbfb6:	ff 15 9c f7 38 00    	call   *0x38f79c(%rip)        # a8b758 <_DYNAMIC+0x240>
  6fbfbc:	bb 08 01 00 00       	mov    $0x108,%ebx
  6fbfc1:	bf 08 01 00 00       	mov    $0x108,%edi
  6fbfc6:	be 08 00 00 00       	mov    $0x8,%esi
  6fbfcb:	ff 15 8f f7 38 00    	call   *0x38f78f(%rip)        # a8b760 <_DYNAMIC+0x248>
  6fbfd1:	48 85 c0             	test   %rax,%rax
  6fbfd4:	0f 84 55 19 00 00    	je     6fd92f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x68ef>
  6fbfda:	48 89 c1             	mov    %rax,%rcx
  6fbfdd:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fbfe1:	f3 0f 7f 80 d8 00 00 	movdqu %xmm0,0xd8(%rax)
  6fbfe8:	00 
  6fbfe9:	f3 0f 7f 40 28       	movdqu %xmm0,0x28(%rax)
  6fbfee:	f3 0f 7f 40 40       	movdqu %xmm0,0x40(%rax)
  6fbff3:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  6fbffa:	48 c7 40 18 00 00 00 	movq   $0x0,0x18(%rax)
  6fc001:	00 
  6fc002:	48 c7 40 20 08 00 00 	movq   $0x8,0x20(%rax)
  6fc009:	00 
  6fc00a:	48 c7 40 38 08 00 00 	movq   $0x8,0x38(%rax)
  6fc011:	00 
  6fc012:	48 c7 40 50 08 00 00 	movq   $0x8,0x50(%rax)
  6fc019:	00 
  6fc01a:	48 c7 40 58 00 00 00 	movq   $0x0,0x58(%rax)
  6fc021:	00 
  6fc022:	48 c7 40 60 ff ff ff 	movq   $0xffffffffffffffff,0x60(%rax)
  6fc029:	ff 
  6fc02a:	48 c7 80 c0 00 00 00 	movq   $0x0,0xc0(%rax)
  6fc031:	00 00 00 00 
  6fc035:	48 c7 80 c8 00 00 00 	movq   $0x8,0xc8(%rax)
  6fc03c:	08 00 00 00 
  6fc040:	48 c7 80 d0 00 00 00 	movq   $0x0,0xd0(%rax)
  6fc047:	00 00 00 00 
  6fc04b:	48 c7 80 e8 00 00 00 	movq   $0x0,0xe8(%rax)
  6fc052:	00 00 00 00 
  6fc056:	f3 0f 7f 80 f8 00 00 	movdqu %xmm0,0xf8(%rax)
  6fc05d:	00 
  6fc05e:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
  6fc065:	00 
  6fc066:	48 89 08             	mov    %rcx,(%rax)
  6fc069:	48 89 cb             	mov    %rcx,%rbx
  6fc06c:	4c 8b a3 00 01 00 00 	mov    0x100(%rbx),%r12
  6fc073:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
  6fc07a:	00 00 00 00 
  6fc07e:	4d 85 e4             	test   %r12,%r12
  6fc081:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
  6fc086:	75 6c                	jne    6fc0f4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x50b4>
  6fc088:	ff 15 ca f6 38 00    	call   *0x38f6ca(%rip)        # a8b758 <_DYNAMIC+0x240>
  6fc08e:	bb 60 00 00 00       	mov    $0x60,%ebx
  6fc093:	bf 60 00 00 00       	mov    $0x60,%edi
  6fc098:	be 08 00 00 00       	mov    $0x8,%esi
  6fc09d:	ff 15 bd f6 38 00    	call   *0x38f6bd(%rip)        # a8b760 <_DYNAMIC+0x248>
  6fc0a3:	48 85 c0             	test   %rax,%rax
  6fc0a6:	0f 84 83 18 00 00    	je     6fd92f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x68ef>
  6fc0ac:	49 89 c4             	mov    %rax,%r12
  6fc0af:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fc0b3:	f3 0f 7f 40 10       	movdqu %xmm0,0x10(%rax)
  6fc0b8:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  6fc0bf:	48 c7 40 08 08 00 00 	movq   $0x8,0x8(%rax)
  6fc0c6:	00 
  6fc0c7:	48 c7 40 20 04 00 00 	movq   $0x4,0x20(%rax)
  6fc0ce:	00 
  6fc0cf:	48 c7 40 28 00 00 00 	movq   $0x0,0x28(%rax)
  6fc0d6:	00 
  6fc0d7:	48 c7 40 30 ff ff ff 	movq   $0xffffffffffffffff,0x30(%rax)
  6fc0de:	ff 
  6fc0df:	48 c7 40 48 00 00 00 	movq   $0x0,0x48(%rax)
  6fc0e6:	00 
  6fc0e7:	48 c7 40 58 00 00 00 	movq   $0x0,0x58(%rax)
  6fc0ee:	00 
  6fc0ef:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
  6fc0f4:	48 83 7c 24 78 00    	cmpq   $0x0,0x78(%rsp)
  6fc0fa:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
  6fc0ff:	0f 84 f5 06 00 00    	je     6fc7fa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x57ba>
  6fc105:	ff 15 4d f6 38 00    	call   *0x38f64d(%rip)        # a8b758 <_DYNAMIC+0x240>
  6fc10b:	be 08 00 00 00       	mov    $0x8,%esi
  6fc110:	48 8b 9c 24 40 08 00 	mov    0x840(%rsp),%rbx
  6fc117:	00 
  6fc118:	48 89 df             	mov    %rbx,%rdi
  6fc11b:	ff 15 3f f6 38 00    	call   *0x38f63f(%rip)        # a8b760 <_DYNAMIC+0x248>
  6fc121:	48 85 c0             	test   %rax,%rax
  6fc124:	0f 84 cf 1b 00 00    	je     6fdcf9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cb9>
  6fc12a:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
  6fc12f:	e9 cb 06 00 00       	jmp    6fc7ff <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x57bf>
  6fc134:	48 8b 84 24 c0 04 00 	mov    0x4c0(%rsp),%rax
  6fc13b:	00 
  6fc13c:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
  6fc140:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  6fc145:	48 89 14 c8          	mov    %rdx,(%rax,%rcx,8)
  6fc149:	4c 89 74 c8 08       	mov    %r14,0x8(%rax,%rcx,8)
  6fc14e:	48 89 5c c8 10       	mov    %rbx,0x10(%rax,%rcx,8)
  6fc153:	49 ff c7             	inc    %r15
  6fc156:	4c 89 bc 24 c8 04 00 	mov    %r15,0x4c8(%rsp)
  6fc15d:	00 
  6fc15e:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  6fc163:	49 89 cd             	mov    %rcx,%r13
  6fc166:	48 8b 84 24 60 03 00 	mov    0x360(%rsp),%rax
  6fc16d:	00 
  6fc16e:	48 3b 4c 24 38       	cmp    0x38(%rsp),%rcx
  6fc173:	0f 84 91 fd ff ff    	je     6fbf0a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4eca>
  6fc179:	49 8d 4d 38          	lea    0x38(%r13),%rcx
  6fc17d:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
  6fc184:	00 
  6fc185:	4d 8b 65 00          	mov    0x0(%r13),%r12
  6fc189:	49 83 fc fe          	cmp    $0xfffffffffffffffe,%r12
  6fc18d:	0f 84 77 fd ff ff    	je     6fbf0a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4eca>
  6fc193:	4d 8b 7d 08          	mov    0x8(%r13),%r15
  6fc197:	49 8b 5d 18          	mov    0x18(%r13),%rbx
  6fc19b:	4d 8b 75 20          	mov    0x20(%r13),%r14
  6fc19f:	48 3b 44 24 30       	cmp    0x30(%rsp),%rax
  6fc1a4:	0f 84 01 15 00 00    	je     6fd6ab <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x666b>
  6fc1aa:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  6fc1af:	49 8b 6d 10          	mov    0x10(%r13),%rbp
  6fc1b3:	48 8d 48 10          	lea    0x10(%rax),%rcx
  6fc1b7:	48 89 8c 24 60 03 00 	mov    %rcx,0x360(%rsp)
  6fc1be:	00 
  6fc1bf:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
  6fc1c6:	00 
  6fc1c7:	f3 0f 6f 00          	movdqu (%rax),%xmm0
  6fc1cb:	66 0f 7f 84 24 c0 08 	movdqa %xmm0,0x8c0(%rsp)
  6fc1d2:	00 00 
  6fc1d4:	41 8b 7d 30          	mov    0x30(%r13),%edi
  6fc1d8:	48 8b b4 24 78 01 00 	mov    0x178(%rsp),%rsi
  6fc1df:	00 
  6fc1e0:	48 39 fe             	cmp    %rdi,%rsi
  6fc1e3:	0f 86 ae 19 00 00    	jbe    6fdb97 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b57>
  6fc1e9:	4d 8b 6d 28          	mov    0x28(%r13),%r13
  6fc1ed:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  6fc1f4:	00 
  6fc1f5:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  6fc1f9:	48 8b 34 c8          	mov    (%rax,%rcx,8),%rsi
  6fc1fd:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
  6fc204:	00 
  6fc205:	48 8b 38             	mov    (%rax),%rdi
  6fc208:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
  6fc20d:	ff 15 2d f7 38 00    	call   *0x38f72d(%rip)        # a8b940 <_DYNAMIC+0x428>
  6fc213:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6fc218:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fc21c:	66 0f 7f 84 24 f0 04 	movdqa %xmm0,0x4f0(%rsp)
  6fc223:	00 00 
  6fc225:	4c 89 a4 24 e0 02 00 	mov    %r12,0x2e0(%rsp)
  6fc22c:	00 
  6fc22d:	4c 89 bc 24 e8 02 00 	mov    %r15,0x2e8(%rsp)
  6fc234:	00 
  6fc235:	48 89 ac 24 f0 02 00 	mov    %rbp,0x2f0(%rsp)
  6fc23c:	00 
  6fc23d:	48 89 9c 24 f8 02 00 	mov    %rbx,0x2f8(%rsp)
  6fc244:	00 
  6fc245:	4c 89 b4 24 00 03 00 	mov    %r14,0x300(%rsp)
  6fc24c:	00 
  6fc24d:	4c 89 ac 24 08 03 00 	mov    %r13,0x308(%rsp)
  6fc254:	00 
  6fc255:	48 c7 84 24 d8 02 00 	movq   $0x2,0x2d8(%rsp)
  6fc25c:	00 02 00 00 00 
  6fc261:	48 c7 84 24 10 03 00 	movq   $0x0,0x310(%rsp)
  6fc268:	00 00 00 00 00 
  6fc26d:	41 be 02 00 00 00    	mov    $0x2,%r14d
  6fc273:	31 c9                	xor    %ecx,%ecx
  6fc275:	eb 25                	jmp    6fc29c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x525c>
  6fc277:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6fc27e:	00 00 
  6fc280:	48 8b 84 24 d0 02 00 	mov    0x2d0(%rsp),%rax
  6fc287:	00 
  6fc288:	4c 8b b4 24 d8 02 00 	mov    0x2d8(%rsp),%r14
  6fc28f:	00 
  6fc290:	48 89 c1             	mov    %rax,%rcx
  6fc293:	49 39 c6             	cmp    %rax,%r14
  6fc296:	0f 84 dd 04 00 00    	je     6fc779 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5739>
  6fc29c:	48 8d 41 01          	lea    0x1(%rcx),%rax
  6fc2a0:	48 89 84 24 d0 02 00 	mov    %rax,0x2d0(%rsp)
  6fc2a7:	00 
  6fc2a8:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  6fc2ac:	48 8d 94 24 e0 02 00 	lea    0x2e0(%rsp),%rdx
  6fc2b3:	00 
  6fc2b4:	48 8b 1c ca          	mov    (%rdx,%rcx,8),%rbx
  6fc2b8:	48 83 fb fe          	cmp    $0xfffffffffffffffe,%rbx
  6fc2bc:	0f 84 b2 04 00 00    	je     6fc774 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5734>
  6fc2c2:	4c 8b a4 24 10 03 00 	mov    0x310(%rsp),%r12
  6fc2c9:	00 
  6fc2ca:	49 8d 54 24 01       	lea    0x1(%r12),%rdx
  6fc2cf:	48 89 94 24 10 03 00 	mov    %rdx,0x310(%rsp)
  6fc2d6:	00 
  6fc2d7:	48 83 fb ff          	cmp    $0xffffffffffffffff,%rbx
  6fc2db:	74 b3                	je     6fc290 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5250>
  6fc2dd:	48 8d 84 24 e0 02 00 	lea    0x2e0(%rsp),%rax
  6fc2e4:	00 
  6fc2e5:	48 8d 04 c8          	lea    (%rax,%rcx,8),%rax
  6fc2e9:	48 89 9c 24 d0 06 00 	mov    %rbx,0x6d0(%rsp)
  6fc2f0:	00 
  6fc2f1:	f3 0f 6f 40 08       	movdqu 0x8(%rax),%xmm0
  6fc2f6:	48 8d 84 24 d8 06 00 	lea    0x6d8(%rsp),%rax
  6fc2fd:	00 
  6fc2fe:	f3 0f 7f 00          	movdqu %xmm0,(%rax)
  6fc302:	48 8d bc 24 50 04 00 	lea    0x450(%rsp),%rdi
  6fc309:	00 
  6fc30a:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
  6fc311:	00 
  6fc312:	ff 15 08 f9 38 00    	call   *0x38f908(%rip)        # a8bc20 <_DYNAMIC+0x708>
  6fc318:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  6fc31d:	48 85 f6             	test   %rsi,%rsi
  6fc320:	0f 84 aa 00 00 00    	je     6fc3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5390>
  6fc326:	31 c0                	xor    %eax,%eax
  6fc328:	4d 85 e4             	test   %r12,%r12
  6fc32b:	0f 95 c0             	setne  %al
  6fc32e:	48 83 7c c6 08 00    	cmpq   $0x0,0x8(%rsi,%rax,8)
  6fc334:	0f 84 96 00 00 00    	je     6fc3d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5390>
  6fc33a:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6fc33f:	48 ff 81 f0 06 00 00 	incq   0x6f0(%rcx)
  6fc346:	48 8d 04 c5 08 00 00 	lea    0x8(,%rax,8),%rax
  6fc34d:	00 
  6fc34e:	48 8b 94 24 60 04 00 	mov    0x460(%rsp),%rdx
  6fc355:	00 
  6fc356:	4c 8b 34 06          	mov    (%rsi,%rax,1),%r14
  6fc35a:	4d 8b 3e             	mov    (%r14),%r15
  6fc35d:	4c 89 f8             	mov    %r15,%rax
  6fc360:	48 d1 e8             	shr    $1,%rax
  6fc363:	48 39 d0             	cmp    %rdx,%rax
  6fc366:	75 74                	jne    6fc3dc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x539c>
  6fc368:	48 8b b4 24 58 04 00 	mov    0x458(%rsp),%rsi
  6fc36f:	00 
  6fc370:	49 8d 7e 10          	lea    0x10(%r14),%rdi
  6fc374:	ff 15 ce f5 38 00    	call   *0x38f5ce(%rip)        # a8b948 <bcmp@GLIBC_2.2.5>
  6fc37a:	85 c0                	test   %eax,%eax
  6fc37c:	75 5e                	jne    6fc3dc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x539c>
  6fc37e:	41 f6 c7 01          	test   $0x1,%r15b
  6fc382:	75 2e                	jne    6fc3b2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5372>
  6fc384:	49 8b 46 08          	mov    0x8(%r14),%rax
  6fc388:	a8 01                	test   $0x1,%al
  6fc38a:	75 26                	jne    6fc3b2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5372>
  6fc38c:	b8 02 00 00 00       	mov    $0x2,%eax
  6fc391:	f0 49 0f c1 46 08    	lock xadd %rax,0x8(%r14)
  6fc397:	48 b9 01 00 00 00 00 	movabs $0x8000000000000001,%rcx
  6fc39e:	00 00 80 
  6fc3a1:	48 21 c8             	and    %rcx,%rax
  6fc3a4:	48 ff c9             	dec    %rcx
  6fc3a7:	48 39 c8             	cmp    %rcx,%rax
  6fc3aa:	75 06                	jne    6fc3b2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5372>
  6fc3ac:	f0 49 83 4e 08 01    	lock orq $0x1,0x8(%r14)
  6fc3b2:	49 83 fc 01          	cmp    $0x1,%r12
  6fc3b6:	0f 86 24 03 00 00    	jbe    6fc6e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56a0>
  6fc3bc:	e9 03 18 00 00       	jmp    6fdbc4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6b84>
  6fc3c1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fc3c8:	0f 1f 84 00 00 00 00 
  6fc3cf:	00 
  6fc3d0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fc3d5:	48 ff 80 f0 06 00 00 	incq   0x6f0(%rax)
  6fc3dc:	49 83 fc 02          	cmp    $0x2,%r12
  6fc3e0:	0f 83 c5 15 00 00    	jae    6fd9ab <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x696b>
  6fc3e6:	4e 8b ac e4 c0 08 00 	mov    0x8c0(%rsp,%r12,8),%r13
  6fc3ed:	00 
  6fc3ee:	4d 85 ed             	test   %r13,%r13
  6fc3f1:	74 70                	je     6fc463 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5423>
  6fc3f3:	48 8b 84 24 38 04 00 	mov    0x438(%rsp),%rax
  6fc3fa:	00 
  6fc3fb:	48 85 c0             	test   %rax,%rax
  6fc3fe:	0f 84 37 01 00 00    	je     6fc53b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x54fb>
  6fc404:	48 8b 8c 24 40 04 00 	mov    0x440(%rsp),%rcx
  6fc40b:	00 
  6fc40c:	0f b7 b0 ba 00 00 00 	movzwl 0xba(%rax),%esi
  6fc413:	89 f7                	mov    %esi,%edi
  6fc415:	c1 e7 03             	shl    $0x3,%edi
  6fc418:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6fc41f:	90                   	nop
  6fc420:	48 85 ff             	test   %rdi,%rdi
  6fc423:	74 27                	je     6fc44c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x540c>
  6fc425:	4c 3b 6c d0 10       	cmp    0x10(%rax,%rdx,8),%r13
  6fc42a:	41 0f 97 c0          	seta   %r8b
  6fc42e:	41 80 d8 00          	sbb    $0x0,%r8b
  6fc432:	48 ff c2             	inc    %rdx
  6fc435:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  6fc439:	41 80 f8 01          	cmp    $0x1,%r8b
  6fc43d:	74 e1                	je     6fc420 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x53e0>
  6fc43f:	41 0f b6 f0          	movzbl %r8b,%esi
  6fc443:	85 f6                	test   %esi,%esi
  6fc445:	75 08                	jne    6fc44f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x540f>
  6fc447:	e9 a5 00 00 00       	jmp    6fc4f1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x54b1>
  6fc44c:	48 89 f2             	mov    %rsi,%rdx
  6fc44f:	48 83 e9 01          	sub    $0x1,%rcx
  6fc453:	0f 82 e2 00 00 00    	jb     6fc53b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x54fb>
  6fc459:	48 8b 84 d0 c0 00 00 	mov    0xc0(%rax,%rdx,8),%rax
  6fc460:	00 
  6fc461:	eb a9                	jmp    6fc40c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x53cc>
  6fc463:	4c 8b bc 24 60 04 00 	mov    0x460(%rsp),%r15
  6fc46a:	00 
  6fc46b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fc470:	f3 0f 6f 80 f8 06 00 	movdqu 0x6f8(%rax),%xmm0
  6fc477:	00 
  6fc478:	66 49 0f 6e cf       	movq   %r15,%xmm1
  6fc47d:	66 0f 6f 15 db aa 95 	movdqa -0x6a5525(%rip),%xmm2        # 56f60 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x920>
  6fc484:	ff 
  6fc485:	66 0f 6c d1          	punpcklqdq %xmm1,%xmm2
  6fc489:	66 0f d4 d0          	paddq  %xmm0,%xmm2
  6fc48d:	f3 0f 7f 90 f8 06 00 	movdqu %xmm2,0x6f8(%rax)
  6fc494:	00 
  6fc495:	4c 8d 35 84 b2 95 ff 	lea    -0x6a4d7c(%rip),%r14        # 57720 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x10e0>
  6fc49c:	4d 85 ff             	test   %r15,%r15
  6fc49f:	0f 84 3b 02 00 00    	je     6fc6e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56a0>
  6fc4a5:	48 8b ac 24 58 04 00 	mov    0x458(%rsp),%rbp
  6fc4ac:	00 
  6fc4ad:	48 8d bc 24 90 01 00 	lea    0x190(%rsp),%rdi
  6fc4b4:	00 
  6fc4b5:	4c 89 fe             	mov    %r15,%rsi
  6fc4b8:	31 d2                	xor    %edx,%edx
  6fc4ba:	31 c9                	xor    %ecx,%ecx
  6fc4bc:	ff 15 8e f4 38 00    	call   *0x38f48e(%rip)        # a8b950 <_DYNAMIC+0x438>
  6fc4c2:	48 8b bc 24 90 01 00 	mov    0x190(%rsp),%rdi
  6fc4c9:	00 
  6fc4ca:	48 83 ff ff          	cmp    $0xffffffffffffffff,%rdi
  6fc4ce:	0f 85 67 15 00 00    	jne    6fda3b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x69fb>
  6fc4d4:	4c 8b b4 24 98 01 00 	mov    0x198(%rsp),%r14
  6fc4db:	00 
  6fc4dc:	49 8d 7e 10          	lea    0x10(%r14),%rdi
  6fc4e0:	48 89 ee             	mov    %rbp,%rsi
  6fc4e3:	4c 89 fa             	mov    %r15,%rdx
  6fc4e6:	ff 15 8c f2 38 00    	call   *0x38f28c(%rip)        # a8b778 <memcpy@GLIBC_2.14>
  6fc4ec:	e9 ef 01 00 00       	jmp    6fc6e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56a0>
  6fc4f1:	4c 8b 74 d0 60       	mov    0x60(%rax,%rdx,8),%r14
  6fc4f6:	41 f6 06 01          	testb  $0x1,(%r14)
  6fc4fa:	0f 85 e0 01 00 00    	jne    6fc6e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56a0>
  6fc500:	49 8b 46 08          	mov    0x8(%r14),%rax
  6fc504:	a8 01                	test   $0x1,%al
  6fc506:	0f 85 d4 01 00 00    	jne    6fc6e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56a0>
  6fc50c:	b8 02 00 00 00       	mov    $0x2,%eax
  6fc511:	f0 49 0f c1 46 08    	lock xadd %rax,0x8(%r14)
  6fc517:	48 b9 01 00 00 00 00 	movabs $0x8000000000000001,%rcx
  6fc51e:	00 00 80 
  6fc521:	48 21 c8             	and    %rcx,%rax
  6fc524:	48 ff c9             	dec    %rcx
  6fc527:	48 39 c8             	cmp    %rcx,%rax
  6fc52a:	0f 85 b0 01 00 00    	jne    6fc6e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56a0>
  6fc530:	f0 49 83 4e 08 01    	lock orq $0x1,0x8(%r14)
  6fc536:	e9 a5 01 00 00       	jmp    6fc6e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56a0>
  6fc53b:	4c 8b bc 24 60 04 00 	mov    0x460(%rsp),%r15
  6fc542:	00 
  6fc543:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fc548:	f3 0f 6f 80 f8 06 00 	movdqu 0x6f8(%rax),%xmm0
  6fc54f:	00 
  6fc550:	66 49 0f 6e cf       	movq   %r15,%xmm1
  6fc555:	66 0f 6f 15 03 aa 95 	movdqa -0x6a55fd(%rip),%xmm2        # 56f60 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x920>
  6fc55c:	ff 
  6fc55d:	66 0f 6c d1          	punpcklqdq %xmm1,%xmm2
  6fc561:	66 0f d4 d0          	paddq  %xmm0,%xmm2
  6fc565:	f3 0f 7f 90 f8 06 00 	movdqu %xmm2,0x6f8(%rax)
  6fc56c:	00 
  6fc56d:	4c 8d 35 ac b1 95 ff 	lea    -0x6a4e54(%rip),%r14        # 57720 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x10e0>
  6fc574:	4d 85 ff             	test   %r15,%r15
  6fc577:	74 47                	je     6fc5c0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5580>
  6fc579:	48 8b ac 24 58 04 00 	mov    0x458(%rsp),%rbp
  6fc580:	00 
  6fc581:	48 8d bc 24 90 01 00 	lea    0x190(%rsp),%rdi
  6fc588:	00 
  6fc589:	4c 89 fe             	mov    %r15,%rsi
  6fc58c:	31 d2                	xor    %edx,%edx
  6fc58e:	31 c9                	xor    %ecx,%ecx
  6fc590:	ff 15 ba f3 38 00    	call   *0x38f3ba(%rip)        # a8b950 <_DYNAMIC+0x438>
  6fc596:	48 8b bc 24 90 01 00 	mov    0x190(%rsp),%rdi
  6fc59d:	00 
  6fc59e:	48 83 ff ff          	cmp    $0xffffffffffffffff,%rdi
  6fc5a2:	0f 85 93 14 00 00    	jne    6fda3b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x69fb>
  6fc5a8:	4c 8b b4 24 98 01 00 	mov    0x198(%rsp),%r14
  6fc5af:	00 
  6fc5b0:	49 8d 7e 10          	lea    0x10(%r14),%rdi
  6fc5b4:	48 89 ee             	mov    %rbp,%rsi
  6fc5b7:	4c 89 fa             	mov    %r15,%rdx
  6fc5ba:	ff 15 b8 f1 38 00    	call   *0x38f1b8(%rip)        # a8b778 <memcpy@GLIBC_2.14>
  6fc5c0:	41 f6 06 01          	testb  $0x1,(%r14)
  6fc5c4:	75 2e                	jne    6fc5f4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x55b4>
  6fc5c6:	49 8b 46 08          	mov    0x8(%r14),%rax
  6fc5ca:	a8 01                	test   $0x1,%al
  6fc5cc:	75 26                	jne    6fc5f4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x55b4>
  6fc5ce:	b8 02 00 00 00       	mov    $0x2,%eax
  6fc5d3:	f0 49 0f c1 46 08    	lock xadd %rax,0x8(%r14)
  6fc5d9:	48 b9 01 00 00 00 00 	movabs $0x8000000000000001,%rcx
  6fc5e0:	00 00 80 
  6fc5e3:	48 21 c8             	and    %rcx,%rax
  6fc5e6:	48 ff c9             	dec    %rcx
  6fc5e9:	48 39 c8             	cmp    %rcx,%rax
  6fc5ec:	75 06                	jne    6fc5f4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x55b4>
  6fc5ee:	f0 49 83 4e 08 01    	lock orq $0x1,0x8(%r14)
  6fc5f4:	48 8b 84 24 38 04 00 	mov    0x438(%rsp),%rax
  6fc5fb:	00 
  6fc5fc:	48 85 c0             	test   %rax,%rax
  6fc5ff:	0f 84 85 00 00 00    	je     6fc68a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x564a>
  6fc605:	48 8b 8c 24 40 04 00 	mov    0x440(%rsp),%rcx
  6fc60c:	00 
  6fc60d:	0f b7 b0 ba 00 00 00 	movzwl 0xba(%rax),%esi
  6fc614:	89 f7                	mov    %esi,%edi
  6fc616:	c1 e7 03             	shl    $0x3,%edi
  6fc619:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6fc620:	48 85 ff             	test   %rdi,%rdi
  6fc623:	74 24                	je     6fc649 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5609>
  6fc625:	4c 3b 6c d0 10       	cmp    0x10(%rax,%rdx,8),%r13
  6fc62a:	41 0f 97 c0          	seta   %r8b
  6fc62e:	41 80 d8 00          	sbb    $0x0,%r8b
  6fc632:	48 ff c2             	inc    %rdx
  6fc635:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  6fc639:	41 80 f8 01          	cmp    $0x1,%r8b
  6fc63d:	74 e1                	je     6fc620 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x55e0>
  6fc63f:	41 0f b6 f0          	movzbl %r8b,%esi
  6fc643:	85 f6                	test   %esi,%esi
  6fc645:	75 05                	jne    6fc64c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x560c>
  6fc647:	eb 13                	jmp    6fc65c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x561c>
  6fc649:	48 89 f2             	mov    %rsi,%rdx
  6fc64c:	48 83 e9 01          	sub    $0x1,%rcx
  6fc650:	72 3a                	jb     6fc68c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x564c>
  6fc652:	48 8b 84 d0 c0 00 00 	mov    0xc0(%rax,%rdx,8),%rax
  6fc659:	00 
  6fc65a:	eb b1                	jmp    6fc60d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x55cd>
  6fc65c:	48 8b 7c d0 60       	mov    0x60(%rax,%rdx,8),%rdi
  6fc661:	4c 89 74 d0 60       	mov    %r14,0x60(%rax,%rdx,8)
  6fc666:	f6 07 01             	testb  $0x1,(%rdi)
  6fc669:	75 75                	jne    6fc6e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56a0>
  6fc66b:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fc66f:	a8 01                	test   $0x1,%al
  6fc671:	75 6d                	jne    6fc6e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56a0>
  6fc673:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6fc677:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6fc67c:	75 62                	jne    6fc6e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56a0>
  6fc67e:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fc682:	ff 15 28 f1 38 00    	call   *0x38f128(%rip)        # a8b7b0 <_DYNAMIC+0x298>
  6fc688:	eb 56                	jmp    6fc6e0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56a0>
  6fc68a:	31 c0                	xor    %eax,%eax
  6fc68c:	4c 89 ac 24 90 01 00 	mov    %r13,0x190(%rsp)
  6fc693:	00 
  6fc694:	48 8d 8c 24 38 04 00 	lea    0x438(%rsp),%rcx
  6fc69b:	00 
  6fc69c:	48 89 8c 24 98 01 00 	mov    %rcx,0x198(%rsp)
  6fc6a3:	00 
  6fc6a4:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
  6fc6ab:	00 
  6fc6ac:	48 c7 84 24 a8 01 00 	movq   $0x0,0x1a8(%rsp)
  6fc6b3:	00 00 00 00 00 
  6fc6b8:	48 89 94 24 b0 01 00 	mov    %rdx,0x1b0(%rsp)
  6fc6bf:	00 
  6fc6c0:	48 8d bc 24 70 03 00 	lea    0x370(%rsp),%rdi
  6fc6c7:	00 
  6fc6c8:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
  6fc6cf:	00 
  6fc6d0:	4c 89 f2             	mov    %r14,%rdx
  6fc6d3:	e8 88 50 01 00       	call   711760 <<alloc::collections::btree::map::entry::VacantEntry<gpui::source::FieldId, gpui::shared_text::SharedText>>::insert_entry>
  6fc6d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6fc6df:	00 
  6fc6e0:	4a 8b bc e4 f0 04 00 	mov    0x4f0(%rsp,%r12,8),%rdi
  6fc6e7:	00 
  6fc6e8:	48 85 ff             	test   %rdi,%rdi
  6fc6eb:	74 23                	je     6fc710 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56d0>
  6fc6ed:	f6 07 01             	testb  $0x1,(%rdi)
  6fc6f0:	75 1e                	jne    6fc710 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56d0>
  6fc6f2:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fc6f6:	a8 01                	test   $0x1,%al
  6fc6f8:	75 16                	jne    6fc710 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56d0>
  6fc6fa:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6fc6fe:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6fc703:	74 63                	je     6fc768 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5728>
  6fc705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6fc70c:	00 00 00 00 
  6fc710:	4e 89 b4 e4 f0 04 00 	mov    %r14,0x4f0(%rsp,%r12,8)
  6fc717:	00 
  6fc718:	48 8b b4 24 50 04 00 	mov    0x450(%rsp),%rsi
  6fc71f:	00 
  6fc720:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fc724:	74 18                	je     6fc73e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56fe>
  6fc726:	48 85 f6             	test   %rsi,%rsi
  6fc729:	74 13                	je     6fc73e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56fe>
  6fc72b:	48 8b bc 24 58 04 00 	mov    0x458(%rsp),%rdi
  6fc732:	00 
  6fc733:	ba 01 00 00 00       	mov    $0x1,%edx
  6fc738:	ff 15 2a f0 38 00    	call   *0x38f02a(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fc73e:	48 85 db             	test   %rbx,%rbx
  6fc741:	0f 88 39 fb ff ff    	js     6fc280 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5240>
  6fc747:	0f 84 33 fb ff ff    	je     6fc280 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5240>
  6fc74d:	48 8b bc 24 d8 06 00 	mov    0x6d8(%rsp),%rdi
  6fc754:	00 
  6fc755:	ba 01 00 00 00       	mov    $0x1,%edx
  6fc75a:	48 89 de             	mov    %rbx,%rsi
  6fc75d:	ff 15 05 f0 38 00    	call   *0x38f005(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fc763:	e9 18 fb ff ff       	jmp    6fc280 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5240>
  6fc768:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6fc76c:	ff 15 3e f0 38 00    	call   *0x38f03e(%rip)        # a8b7b0 <_DYNAMIC+0x298>
  6fc772:	eb 9c                	jmp    6fc710 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x56d0>
  6fc774:	49 29 c6             	sub    %rax,%r14
  6fc777:	75 44                	jne    6fc7bd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x577d>
  6fc779:	4c 8b b4 24 f0 04 00 	mov    0x4f0(%rsp),%r14
  6fc780:	00 
  6fc781:	48 8b 9c 24 f8 04 00 	mov    0x4f8(%rsp),%rbx
  6fc788:	00 
  6fc789:	4c 89 f0             	mov    %r14,%rax
  6fc78c:	48 09 d8             	or     %rbx,%rax
  6fc78f:	0f 84 c9 f9 ff ff    	je     6fc15e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x511e>
  6fc795:	4c 8b bc 24 c8 04 00 	mov    0x4c8(%rsp),%r15
  6fc79c:	00 
  6fc79d:	4c 3b bc 24 b8 04 00 	cmp    0x4b8(%rsp),%r15
  6fc7a4:	00 
  6fc7a5:	0f 85 89 f9 ff ff    	jne    6fc134 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x50f4>
  6fc7ab:	48 8d bc 24 b8 04 00 	lea    0x4b8(%rsp),%rdi
  6fc7b2:	00 
  6fc7b3:	e8 38 45 02 00       	call   720cf0 <<alloc::raw_vec::RawVec<gpui::style_port::Draft>>::grow_one>
  6fc7b8:	e9 77 f9 ff ff       	jmp    6fc134 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x50f4>
  6fc7bd:	48 8d 84 24 e0 02 00 	lea    0x2e0(%rsp),%rax
  6fc7c4:	00 
  6fc7c5:	48 8d 1c c8          	lea    (%rax,%rcx,8),%rbx
  6fc7c9:	48 83 c3 20          	add    $0x20,%rbx
  6fc7cd:	eb 0a                	jmp    6fc7d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5799>
  6fc7cf:	90                   	nop
  6fc7d0:	48 83 c3 18          	add    $0x18,%rbx
  6fc7d4:	49 ff ce             	dec    %r14
  6fc7d7:	74 a0                	je     6fc779 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5739>
  6fc7d9:	48 8b 73 f8          	mov    -0x8(%rbx),%rsi
  6fc7dd:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fc7e1:	74 ed                	je     6fc7d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5790>
  6fc7e3:	48 85 f6             	test   %rsi,%rsi
  6fc7e6:	78 e8                	js     6fc7d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5790>
  6fc7e8:	74 e6                	je     6fc7d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5790>
  6fc7ea:	48 8b 3b             	mov    (%rbx),%rdi
  6fc7ed:	ba 01 00 00 00       	mov    $0x1,%edx
  6fc7f2:	ff 15 70 ef 38 00    	call   *0x38ef70(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fc7f8:	eb d6                	jmp    6fc7d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5790>
  6fc7fa:	b8 08 00 00 00       	mov    $0x8,%eax
  6fc7ff:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  6fc804:	48 89 8c 24 d0 02 00 	mov    %rcx,0x2d0(%rsp)
  6fc80b:	00 
  6fc80c:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
  6fc813:	00 
  6fc814:	48 c7 84 24 e0 02 00 	movq   $0x0,0x2e0(%rsp)
  6fc81b:	00 00 00 00 00 
  6fc820:	4d 85 ff             	test   %r15,%r15
  6fc823:	0f 84 45 02 00 00    	je     6fca6e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5a2e>
  6fc829:	89 6c 24 30          	mov    %ebp,0x30(%rsp)
  6fc82d:	4b 8d 04 7f          	lea    (%r15,%r15,2),%rax
  6fc831:	49 8d 04 c6          	lea    (%r14,%rax,8),%rax
  6fc835:	48 89 84 24 60 03 00 	mov    %rax,0x360(%rsp)
  6fc83c:	00 
  6fc83d:	bb 02 00 00 00       	mov    $0x2,%ebx
  6fc842:	45 31 e4             	xor    %r12d,%r12d
  6fc845:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  6fc84c:	00 
  6fc84d:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  6fc852:	eb 47                	jmp    6fc89b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x585b>
  6fc854:	48 8b 84 24 d8 02 00 	mov    0x2d8(%rsp),%rax
  6fc85b:	00 
  6fc85c:	48 89 e9             	mov    %rbp,%rcx
  6fc85f:	48 c1 e1 04          	shl    $0x4,%rcx
  6fc863:	4c 89 2c 08          	mov    %r13,(%rax,%rcx,1)
  6fc867:	66 0f 6e 44 24 20    	movd   0x20(%rsp),%xmm0
  6fc86d:	66 0f 7e 44 08 08    	movd   %xmm0,0x8(%rax,%rcx,1)
  6fc873:	48 ff c5             	inc    %rbp
  6fc876:	48 89 ac 24 e0 02 00 	mov    %rbp,0x2e0(%rsp)
  6fc87d:	00 
  6fc87e:	49 83 c6 18          	add    $0x18,%r14
  6fc882:	49 ff c4             	inc    %r12
  6fc885:	4c 3b b4 24 60 03 00 	cmp    0x360(%rsp),%r14
  6fc88c:	00 
  6fc88d:	4c 8b ac 24 80 01 00 	mov    0x180(%rsp),%r13
  6fc894:	00 
  6fc895:	0f 84 9e 01 00 00    	je     6fca39 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x59f9>
  6fc89b:	48 83 fb 02          	cmp    $0x2,%rbx
  6fc89f:	74 1b                	je     6fc8bc <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x587c>
  6fc8a1:	48 83 fb 01          	cmp    $0x1,%rbx
  6fc8a5:	75 4d                	jne    6fc8f4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x58b4>
  6fc8a7:	4d 39 e7             	cmp    %r12,%r15
  6fc8aa:	75 48                	jne    6fc8f4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x58b4>
  6fc8ac:	bb 02 00 00 00       	mov    $0x2,%ebx
  6fc8b1:	4d 89 e7             	mov    %r12,%r15
  6fc8b4:	66 0f 6e 44 24 70    	movd   0x70(%rsp),%xmm0
  6fc8ba:	eb 3c                	jmp    6fc8f8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x58b8>
  6fc8bc:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
  6fc8c3:	00 
  6fc8c4:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  6fc8c9:	48 39 c1             	cmp    %rax,%rcx
  6fc8cc:	0f 84 52 01 00 00    	je     6fca24 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x59e4>
  6fc8d2:	4c 8b 39             	mov    (%rcx),%r15
  6fc8d5:	66 0f 6e 41 08       	movd   0x8(%rcx),%xmm0
  6fc8da:	66 0f 7e 44 24 70    	movd   %xmm0,0x70(%rsp)
  6fc8e0:	48 8d 41 10          	lea    0x10(%rcx),%rax
  6fc8e4:	bb 01 00 00 00       	mov    $0x1,%ebx
  6fc8e9:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  6fc8ee:	48 83 fb 01          	cmp    $0x1,%rbx
  6fc8f2:	74 b3                	je     6fc8a7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5867>
  6fc8f4:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6fc8f8:	66 0f 7e 44 24 20    	movd   %xmm0,0x20(%rsp)
  6fc8fe:	4d 8b 2e             	mov    (%r14),%r13
  6fc901:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  6fc906:	4c 89 ee             	mov    %r13,%rsi
  6fc909:	ff 15 c1 f1 38 00    	call   *0x38f1c1(%rip)        # a8bad0 <_DYNAMIC+0x5b8>
  6fc90f:	66 0f 7e 84 24 90 01 	movd   %xmm0,0x190(%rsp)
  6fc916:	00 00 
  6fc918:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  6fc91d:	48 8b 41 48          	mov    0x48(%rcx),%rax
  6fc921:	48 85 c0             	test   %rax,%rax
  6fc924:	0f 84 80 00 00 00    	je     6fc9aa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x596a>
  6fc92a:	48 8b 49 50          	mov    0x50(%rcx),%rcx
  6fc92e:	66 0f 6e 44 24 20    	movd   0x20(%rsp),%xmm0
  6fc934:	0f b7 b0 c2 01 00 00 	movzwl 0x1c2(%rax),%esi
  6fc93b:	48 8d 68 e0          	lea    -0x20(%rax),%rbp
  6fc93f:	89 f7                	mov    %esi,%edi
  6fc941:	c1 e7 03             	shl    $0x3,%edi
  6fc944:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6fc94b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6fc950:	48 85 ff             	test   %rdi,%rdi
  6fc953:	74 2b                	je     6fc980 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5940>
  6fc955:	4c 3b ac d0 70 01 00 	cmp    0x170(%rax,%rdx,8),%r13
  6fc95c:	00 
  6fc95d:	41 0f 97 c0          	seta   %r8b
  6fc961:	41 80 d8 00          	sbb    $0x0,%r8b
  6fc965:	48 83 c5 20          	add    $0x20,%rbp
  6fc969:	48 ff c2             	inc    %rdx
  6fc96c:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  6fc970:	41 80 f8 01          	cmp    $0x1,%r8b
  6fc974:	74 da                	je     6fc950 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5910>
  6fc976:	41 0f b6 f0          	movzbl %r8b,%esi
  6fc97a:	85 f6                	test   %esi,%esi
  6fc97c:	75 05                	jne    6fc983 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5943>
  6fc97e:	eb 13                	jmp    6fc993 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5953>
  6fc980:	48 89 f2             	mov    %rsi,%rdx
  6fc983:	48 83 e9 01          	sub    $0x1,%rcx
  6fc987:	72 27                	jb     6fc9b0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5970>
  6fc989:	48 8b 84 d0 c8 01 00 	mov    0x1c8(%rax,%rdx,8),%rax
  6fc990:	00 
  6fc991:	eb a1                	jmp    6fc934 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x58f4>
  6fc993:	48 89 ef             	mov    %rbp,%rdi
  6fc996:	31 f6                	xor    %esi,%esi
  6fc998:	e8 83 e6 01 00       	call   71b020 <gpui::property::apply_except::<gpui::property::GeometryStyle>>
  6fc99d:	66 0f 6e 4c 24 20    	movd   0x20(%rsp),%xmm1
  6fc9a3:	66 0f 7e 4d 18       	movd   %xmm1,0x18(%rbp)
  6fc9a8:	eb 06                	jmp    6fc9b0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5970>
  6fc9aa:	66 0f 6e 44 24 20    	movd   0x20(%rsp),%xmm0
  6fc9b0:	66 0f 7e 44 24 20    	movd   %xmm0,0x20(%rsp)
  6fc9b6:	66 0f 7e 84 24 80 00 	movd   %xmm0,0x80(%rsp)
  6fc9bd:	00 00 
  6fc9bf:	48 8d bc 24 90 01 00 	lea    0x190(%rsp),%rdi
  6fc9c6:	00 
  6fc9c7:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6fc9ce:	00 
  6fc9cf:	48 8b 05 4a ef 38 00 	mov    0x38ef4a(%rip),%rax        # a8b920 <_DYNAMIC+0x408>
  6fc9d6:	ff 50 18             	call   *0x18(%rax)
  6fc9d9:	84 c0                	test   %al,%al
  6fc9db:	75 0c                	jne    6fc9e9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x59a9>
  6fc9dd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fc9e2:	c6 80 4b 07 00 00 01 	movb   $0x1,0x74b(%rax)
  6fc9e9:	66 0f 6e 44 24 20    	movd   0x20(%rsp),%xmm0
  6fc9ef:	66 0f 7e c0          	movd   %xmm0,%eax
  6fc9f3:	85 c0                	test   %eax,%eax
  6fc9f5:	0f 84 83 fe ff ff    	je     6fc87e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x583e>
  6fc9fb:	48 8b ac 24 e0 02 00 	mov    0x2e0(%rsp),%rbp
  6fca02:	00 
  6fca03:	48 3b ac 24 d0 02 00 	cmp    0x2d0(%rsp),%rbp
  6fca0a:	00 
  6fca0b:	0f 85 43 fe ff ff    	jne    6fc854 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5814>
  6fca11:	48 8d bc 24 d0 02 00 	lea    0x2d0(%rsp),%rdi
  6fca18:	00 
  6fca19:	ff 15 21 f2 38 00    	call   *0x38f221(%rip)        # a8bc40 <_DYNAMIC+0x728>
  6fca1f:	e9 30 fe ff ff       	jmp    6fc854 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5814>
  6fca24:	0f 57 c0             	xorps  %xmm0,%xmm0
  6fca27:	f3 0f 11 44 24 20    	movss  %xmm0,0x20(%rsp)
  6fca2d:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  6fca32:	31 db                	xor    %ebx,%ebx
  6fca34:	e9 c5 fe ff ff       	jmp    6fc8fe <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x58be>
  6fca39:	48 8b bc 24 d8 02 00 	mov    0x2d8(%rsp),%rdi
  6fca40:	00 
  6fca41:	48 8b b4 24 e0 02 00 	mov    0x2e0(%rsp),%rsi
  6fca48:	00 
  6fca49:	48 8d 44 24 6f       	lea    0x6f(%rsp),%rax
  6fca4e:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6fca55:	00 
  6fca56:	48 83 fe 02          	cmp    $0x2,%rsi
  6fca5a:	8b 6c 24 30          	mov    0x30(%rsp),%ebp
  6fca5e:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  6fca63:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
  6fca68:	0f 83 8a 0e 00 00    	jae    6fd8f8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x68b8>
  6fca6e:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
  6fca75:	00 
  6fca76:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6fca7d:	00 
  6fca7e:	0f 10 84 24 d0 02 00 	movups 0x2d0(%rsp),%xmm0
  6fca85:	00 
  6fca86:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  6fca8d:	00 
  6fca8e:	49 8b 34 24          	mov    (%r12),%rsi
  6fca92:	48 85 f6             	test   %rsi,%rsi
  6fca95:	74 14                	je     6fcaab <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5a6b>
  6fca97:	49 8b 7c 24 08       	mov    0x8(%r12),%rdi
  6fca9c:	48 c1 e6 04          	shl    $0x4,%rsi
  6fcaa0:	ba 08 00 00 00       	mov    $0x8,%edx
  6fcaa5:	ff 15 bd ec 38 00    	call   *0x38ecbd(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fcaab:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6fcab2:	00 
  6fcab3:	49 89 44 24 10       	mov    %rax,0x10(%r12)
  6fcab8:	66 0f 6f 84 24 80 00 	movdqa 0x80(%rsp),%xmm0
  6fcabf:	00 00 
  6fcac1:	f3 41 0f 7f 04 24    	movdqu %xmm0,(%r12)
  6fcac7:	49 83 7c 24 10 00    	cmpq   $0x0,0x10(%r12)
  6fcacd:	75 1c                	jne    6fcaeb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5aab>
  6fcacf:	49 83 7c 24 58 00    	cmpq   $0x0,0x58(%r12)
  6fcad5:	75 14                	jne    6fcaeb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5aab>
  6fcad7:	49 83 7c 24 28 00    	cmpq   $0x0,0x28(%r12)
  6fcadd:	75 0c                	jne    6fcaeb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5aab>
  6fcadf:	49 83 7c 24 30 ff    	cmpq   $0xffffffffffffffff,0x30(%r12)
  6fcae5:	0f 84 7f 0c 00 00    	je     6fd76a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x672a>
  6fcaeb:	48 8b bb 00 01 00 00 	mov    0x100(%rbx),%rdi
  6fcaf2:	e8 19 59 fe ff       	call   6e2410 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::geometry::Geometry>>>>
  6fcaf7:	4c 89 a3 00 01 00 00 	mov    %r12,0x100(%rbx)
  6fcafe:	48 8b b4 24 40 01 00 	mov    0x140(%rsp),%rsi
  6fcb05:	00 
  6fcb06:	48 85 f6             	test   %rsi,%rsi
  6fcb09:	74 17                	je     6fcb22 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5ae2>
  6fcb0b:	48 c1 e6 04          	shl    $0x4,%rsi
  6fcb0f:	ba 08 00 00 00       	mov    $0x8,%edx
  6fcb14:	48 8b bc 24 48 01 00 	mov    0x148(%rsp),%rdi
  6fcb1b:	00 
  6fcb1c:	ff 15 46 ec 38 00    	call   *0x38ec46(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fcb22:	89 6c 24 30          	mov    %ebp,0x30(%rsp)
  6fcb26:	48 8b 84 24 30 05 00 	mov    0x530(%rsp),%rax
  6fcb2d:	00 
  6fcb2e:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6fcb35:	00 
  6fcb36:	0f 10 84 24 20 05 00 	movups 0x520(%rsp),%xmm0
  6fcb3d:	00 
  6fcb3e:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  6fcb45:	00 
  6fcb46:	48 8b 9c 24 30 02 00 	mov    0x230(%rsp),%rbx
  6fcb4d:	00 
  6fcb4e:	48 89 df             	mov    %rbx,%rdi
  6fcb51:	e8 3a f6 00 00       	call   70c190 <<alloc::collections::btree::map::BTreeMap<gpui::runtime::scroll::ViewportKey, gpui::runtime::scroll::ViewportState> as core::ops::drop::Drop>::drop>
  6fcb56:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6fcb5d:	00 
  6fcb5e:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fcb62:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  6fcb69:	00 
  6fcb6a:	0f 11 03             	movups %xmm0,(%rbx)
  6fcb6d:	48 8b 84 24 08 07 00 	mov    0x708(%rsp),%rax
  6fcb74:	00 
  6fcb75:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6fcb7c:	00 
  6fcb7d:	0f 10 84 24 f8 06 00 	movups 0x6f8(%rsp),%xmm0
  6fcb84:	00 
  6fcb85:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  6fcb8c:	00 
  6fcb8d:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  6fcb92:	49 8d 9f 60 06 00 00 	lea    0x660(%r15),%rbx
  6fcb99:	48 89 df             	mov    %rbx,%rdi
  6fcb9c:	e8 5f f9 00 00       	call   70c500 <<alloc::collections::btree::map::BTreeMap<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize> as core::ops::drop::Drop>::drop>
  6fcba1:	4d 8d b7 90 02 00 00 	lea    0x290(%r15),%r14
  6fcba8:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6fcbaf:	00 
  6fcbb0:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fcbb4:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  6fcbbb:	00 
  6fcbbc:	0f 11 03             	movups %xmm0,(%rbx)
  6fcbbf:	48 8b 84 24 78 01 00 	mov    0x178(%rsp),%rax
  6fcbc6:	00 
  6fcbc7:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6fcbce:	00 
  6fcbcf:	0f 10 84 24 68 01 00 	movups 0x168(%rsp),%xmm0
  6fcbd6:	00 
  6fcbd7:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  6fcbde:	00 
  6fcbdf:	49 8b 06             	mov    (%r14),%rax
  6fcbe2:	48 85 c0             	test   %rax,%rax
  6fcbe5:	74 1a                	je     6fcc01 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5bc1>
  6fcbe7:	49 8b bf 98 02 00 00 	mov    0x298(%r15),%rdi
  6fcbee:	48 c1 e0 03          	shl    $0x3,%rax
  6fcbf2:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6fcbf6:	ba 08 00 00 00       	mov    $0x8,%edx
  6fcbfb:	ff 15 67 eb 38 00    	call   *0x38eb67(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fcc01:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6fcc08:	00 
  6fcc09:	49 89 46 10          	mov    %rax,0x10(%r14)
  6fcc0d:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  6fcc14:	00 
  6fcc15:	41 0f 11 06          	movups %xmm0,(%r14)
  6fcc19:	48 8b 84 24 60 05 00 	mov    0x560(%rsp),%rax
  6fcc20:	00 
  6fcc21:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6fcc28:	00 
  6fcc29:	f3 0f 6f 84 24 50 05 	movdqu 0x550(%rsp),%xmm0
  6fcc30:	00 00 
  6fcc32:	66 0f 7f 84 24 80 00 	movdqa %xmm0,0x80(%rsp)
  6fcc39:	00 00 
  6fcc3b:	41 b4 01             	mov    $0x1,%r12b
  6fcc3e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  6fcc45:	00 
  6fcc46:	e8 85 63 00 00       	call   702fd0 <<alloc::vec::Vec<core::option::Option<gpui::element::Handler>>>::into_boxed_slice>
  6fcc4b:	49 89 c6             	mov    %rax,%r14
  6fcc4e:	48 89 d3             	mov    %rdx,%rbx
  6fcc51:	49 8b bf b0 05 00 00 	mov    0x5b0(%r15),%rdi
  6fcc58:	49 8b b7 b8 05 00 00 	mov    0x5b8(%r15),%rsi
  6fcc5f:	e8 2c 7a fe ff       	call   6e4690 <core::ptr::drop_glue::<alloc::boxed::Box<[core::option::Option<gpui::element::Handler>]>>>
  6fcc64:	4d 89 b7 b0 05 00 00 	mov    %r14,0x5b0(%r15)
  6fcc6b:	49 89 9f b8 05 00 00 	mov    %rbx,0x5b8(%r15)
  6fcc72:	48 8d 9c 24 80 00 00 	lea    0x80(%rsp),%rbx
  6fcc79:	00 
  6fcc7a:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
  6fcc81:	00 
  6fcc82:	ba a0 00 00 00       	mov    $0xa0,%edx
  6fcc87:	48 89 df             	mov    %rbx,%rdi
  6fcc8a:	ff 15 e8 ea 38 00    	call   *0x38eae8(%rip)        # a8b778 <memcpy@GLIBC_2.14>
  6fcc90:	45 31 e4             	xor    %r12d,%r12d
  6fcc93:	48 8d bc 24 d0 02 00 	lea    0x2d0(%rsp),%rdi
  6fcc9a:	00 
  6fcc9b:	48 89 de             	mov    %rbx,%rsi
  6fcc9e:	ff 15 a4 ef 38 00    	call   *0x38efa4(%rip)        # a8bc48 <_DYNAMIC+0x730>
  6fcca4:	49 8d 9f 00 02 00 00 	lea    0x200(%r15),%rbx
  6fccab:	48 89 df             	mov    %rbx,%rdi
  6fccae:	e8 2d 97 fe ff       	call   6e63e0 <core::ptr::drop_glue::<gpui::runtime::styles::Styles>>
  6fccb3:	48 8b 84 24 f0 02 00 	mov    0x2f0(%rsp),%rax
  6fccba:	00 
  6fccbb:	48 89 43 20          	mov    %rax,0x20(%rbx)
  6fccbf:	0f 10 84 24 d0 02 00 	movups 0x2d0(%rsp),%xmm0
  6fccc6:	00 
  6fccc7:	f3 0f 6f 8c 24 e0 02 	movdqu 0x2e0(%rsp),%xmm1
  6fccce:	00 00 
  6fccd0:	f3 0f 7f 4b 10       	movdqu %xmm1,0x10(%rbx)
  6fccd5:	0f 11 03             	movups %xmm0,(%rbx)
  6fccd8:	41 83 bf 00 02 00 00 	cmpl   $0x3,0x200(%r15)
  6fccdf:	03 
  6fcce0:	0f 94 c0             	sete   %al
  6fcce3:	41 08 87 4b 07 00 00 	or     %al,0x74b(%r15)
  6fccea:	48 8b 84 24 78 05 00 	mov    0x578(%rsp),%rax
  6fccf1:	00 
  6fccf2:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6fccf9:	00 
  6fccfa:	0f 10 84 24 68 05 00 	movups 0x568(%rsp),%xmm0
  6fcd01:	00 
  6fcd02:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  6fcd09:	00 
  6fcd0a:	49 8d 9f a8 02 00 00 	lea    0x2a8(%r15),%rbx
  6fcd11:	48 89 df             	mov    %rbx,%rdi
  6fcd14:	e8 c7 72 00 00       	call   703fe0 <<alloc::vec::Vec<core::option::Option<gpui::runtime::TextSite>> as core::ops::drop::Drop>::drop>
  6fcd19:	48 8b 03             	mov    (%rbx),%rax
  6fcd1c:	48 85 c0             	test   %rax,%rax
  6fcd1f:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  6fcd24:	74 1a                	je     6fcd40 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5d00>
  6fcd26:	49 8b be b0 02 00 00 	mov    0x2b0(%r14),%rdi
  6fcd2d:	48 c1 e0 04          	shl    $0x4,%rax
  6fcd31:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
  6fcd35:	ba 08 00 00 00       	mov    $0x8,%edx
  6fcd3a:	ff 15 28 ea 38 00    	call   *0x38ea28(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fcd40:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6fcd47:	00 
  6fcd48:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fcd4c:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  6fcd53:	00 
  6fcd54:	0f 11 03             	movups %xmm0,(%rbx)
  6fcd57:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
  6fcd5e:	00 
  6fcd5f:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
  6fcd66:	00 
  6fcd67:	f3 0f 6f 84 24 50 01 	movdqu 0x150(%rsp),%xmm0
  6fcd6e:	00 00 
  6fcd70:	66 0f 7f 84 24 90 01 	movdqa %xmm0,0x190(%rsp)
  6fcd77:	00 00 
  6fcd79:	49 8b 8e f8 05 00 00 	mov    0x5f8(%r14),%rcx
  6fcd80:	48 85 c9             	test   %rcx,%rcx
  6fcd83:	74 4d                	je     6fcdd2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5d92>
  6fcd85:	49 8b 96 00 06 00 00 	mov    0x600(%r14),%rdx
  6fcd8c:	49 8b 86 08 06 00 00 	mov    0x608(%r14),%rax
  6fcd93:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
  6fcd9a:	00 00 00 00 00 
  6fcd9f:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  6fcda6:	00 
  6fcda7:	48 89 94 24 98 00 00 	mov    %rdx,0x98(%rsp)
  6fcdae:	00 
  6fcdaf:	48 c7 84 24 a8 00 00 	movq   $0x0,0xa8(%rsp)
  6fcdb6:	00 00 00 00 00 
  6fcdbb:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
  6fcdc2:	00 
  6fcdc3:	48 89 94 24 b8 00 00 	mov    %rdx,0xb8(%rsp)
  6fcdca:	00 
  6fcdcb:	b9 01 00 00 00       	mov    $0x1,%ecx
  6fcdd0:	eb 04                	jmp    6fcdd6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5d96>
  6fcdd2:	31 c9                	xor    %ecx,%ecx
  6fcdd4:	31 c0                	xor    %eax,%eax
  6fcdd6:	4d 8d be f8 05 00 00 	lea    0x5f8(%r14),%r15
  6fcddd:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  6fcde4:	00 
  6fcde5:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
  6fcdec:	00 
  6fcded:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  6fcdf4:	00 
  6fcdf5:	48 8d bc 24 d0 02 00 	lea    0x2d0(%rsp),%rdi
  6fcdfc:	00 
  6fcdfd:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6fce04:	00 
  6fce05:	e8 36 d4 00 00       	call   70a240 <<alloc::collections::btree::map::IntoIter<gpui::source::FieldId, gpui::runtime::Fanout>>::dying_next>
  6fce0a:	48 8b 84 24 d0 02 00 	mov    0x2d0(%rsp),%rax
  6fce11:	00 
  6fce12:	48 85 c0             	test   %rax,%rax
  6fce15:	74 5f                	je     6fce76 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5e36>
  6fce17:	48 8d 9c 24 d0 02 00 	lea    0x2d0(%rsp),%rbx
  6fce1e:	00 
  6fce1f:	4c 8d b4 24 80 00 00 	lea    0x80(%rsp),%r14
  6fce26:	00 
  6fce27:	4c 8b 25 3a e9 38 00 	mov    0x38e93a(%rip),%r12        # a8b768 <_DYNAMIC+0x250>
  6fce2e:	66 90                	xchg   %ax,%ax
  6fce30:	48 8b 8c 24 e0 02 00 	mov    0x2e0(%rsp),%rcx
  6fce37:	00 
  6fce38:	48 c1 e1 05          	shl    $0x5,%rcx
  6fce3c:	48 8b 34 08          	mov    (%rax,%rcx,1),%rsi
  6fce40:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fce44:	74 18                	je     6fce5e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5e1e>
  6fce46:	48 85 f6             	test   %rsi,%rsi
  6fce49:	74 13                	je     6fce5e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5e1e>
  6fce4b:	48 01 c8             	add    %rcx,%rax
  6fce4e:	48 8b 78 08          	mov    0x8(%rax),%rdi
  6fce52:	48 c1 e6 02          	shl    $0x2,%rsi
  6fce56:	ba 04 00 00 00       	mov    $0x4,%edx
  6fce5b:	41 ff d4             	call   *%r12
  6fce5e:	48 89 df             	mov    %rbx,%rdi
  6fce61:	4c 89 f6             	mov    %r14,%rsi
  6fce64:	e8 d7 d3 00 00       	call   70a240 <<alloc::collections::btree::map::IntoIter<gpui::source::FieldId, gpui::runtime::Fanout>>::dying_next>
  6fce69:	48 8b 84 24 d0 02 00 	mov    0x2d0(%rsp),%rax
  6fce70:	00 
  6fce71:	48 85 c0             	test   %rax,%rax
  6fce74:	75 ba                	jne    6fce30 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5df0>
  6fce76:	48 8b 84 24 a0 01 00 	mov    0x1a0(%rsp),%rax
  6fce7d:	00 
  6fce7e:	49 89 47 10          	mov    %rax,0x10(%r15)
  6fce82:	66 0f 6f 84 24 90 01 	movdqa 0x190(%rsp),%xmm0
  6fce89:	00 00 
  6fce8b:	f3 41 0f 7f 07       	movdqu %xmm0,(%r15)
  6fce90:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fce95:	48 8b b0 98 02 00 00 	mov    0x298(%rax),%rsi
  6fce9c:	48 8b 80 a0 02 00 00 	mov    0x2a0(%rax),%rax
  6fcea3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  6fcea7:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
  6fceab:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  6fceb2:	00 
  6fceb3:	44 8b 64 24 30       	mov    0x30(%rsp),%r12d
  6fceb8:	e8 e3 bc 01 00       	call   718ba0 <<gpui::runtime::identity_index::IdentityIndex>::from_ids::<core::iter::adapters::map::Map<core::slice::iter::Iter<gpui::runtime::Node>, <gpui::runtime::Node>::identity>>>
  6fcebd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fcec2:	48 8d 98 e8 01 00 00 	lea    0x1e8(%rax),%rbx
  6fcec9:	48 8b 80 e8 01 00 00 	mov    0x1e8(%rax),%rax
  6fced0:	48 85 c0             	test   %rax,%rax
  6fced3:	74 5d                	je     6fcf32 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5ef2>
  6fced5:	83 f8 01             	cmp    $0x1,%eax
  6fced8:	75 28                	jne    6fcf02 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5ec2>
  6fceda:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fcedf:	48 8b b0 f8 01 00 00 	mov    0x1f8(%rax),%rsi
  6fcee6:	48 85 f6             	test   %rsi,%rsi
  6fcee9:	74 47                	je     6fcf32 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5ef2>
  6fceeb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fcef0:	48 8b b8 f0 01 00 00 	mov    0x1f0(%rax),%rdi
  6fcef7:	48 c1 e6 04          	shl    $0x4,%rsi
  6fcefb:	ba 08 00 00 00       	mov    $0x8,%edx
  6fcf00:	eb 2a                	jmp    6fcf2c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5eec>
  6fcf02:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fcf07:	48 8b 80 f8 01 00 00 	mov    0x1f8(%rax),%rax
  6fcf0e:	48 85 c0             	test   %rax,%rax
  6fcf11:	74 1f                	je     6fcf32 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5ef2>
  6fcf13:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6fcf18:	48 8b b9 f0 01 00 00 	mov    0x1f0(%rcx),%rdi
  6fcf1f:	48 c1 e0 02          	shl    $0x2,%rax
  6fcf23:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6fcf27:	ba 04 00 00 00       	mov    $0x4,%edx
  6fcf2c:	ff 15 36 e8 38 00    	call   *0x38e836(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fcf32:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6fcf39:	00 
  6fcf3a:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fcf3e:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
  6fcf45:	00 00 
  6fcf47:	f3 0f 7f 03          	movdqu %xmm0,(%rbx)
  6fcf4b:	48 8b bc 24 10 04 00 	mov    0x410(%rsp),%rdi
  6fcf52:	00 
  6fcf53:	48 89 de             	mov    %rbx,%rsi
  6fcf56:	e8 b5 de 01 00       	call   71ae10 <<gpui::property::Overrides>::retain::<<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#49}>>
  6fcf5b:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
  6fcf62:	00 
  6fcf63:	48 8b 38             	mov    (%rax),%rdi
  6fcf66:	48 85 ff             	test   %rdi,%rdi
  6fcf69:	74 76                	je     6fcfe1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5fa1>
  6fcf6b:	48 81 c7 e8 00 00 00 	add    $0xe8,%rdi
  6fcf72:	48 89 de             	mov    %rbx,%rsi
  6fcf75:	e8 96 48 fe ff       	call   6e1810 <<alloc::collections::btree::map::BTreeMap<u64, [gpui::property::Contribution<core::option::Option<gpui::shared_text::SharedText>>; 2]>>::retain::<<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#50}>>
  6fcf7a:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
  6fcf81:	00 
  6fcf82:	4c 8b 30             	mov    (%rax),%r14
  6fcf85:	49 8b be 00 01 00 00 	mov    0x100(%r14),%rdi
  6fcf8c:	48 85 ff             	test   %rdi,%rdi
  6fcf8f:	74 50                	je     6fcfe1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5fa1>
  6fcf91:	48 83 c7 48          	add    $0x48,%rdi
  6fcf95:	48 89 de             	mov    %rbx,%rsi
  6fcf98:	e8 03 db 01 00       	call   71aaa0 <<gpui::property::Overrides<gpui::property::GeometryStyle>>::retain::<<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner::{closure#51}>>
  6fcf9d:	49 8b 86 00 01 00 00 	mov    0x100(%r14),%rax
  6fcfa4:	48 8b 48 58          	mov    0x58(%rax),%rcx
  6fcfa8:	48 0b 48 10          	or     0x10(%rax),%rcx
  6fcfac:	75 33                	jne    6fcfe1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5fa1>
  6fcfae:	48 83 78 28 00       	cmpq   $0x0,0x28(%rax)
  6fcfb3:	75 2c                	jne    6fcfe1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5fa1>
  6fcfb5:	48 83 78 30 ff       	cmpq   $0xffffffffffffffff,0x30(%rax)
  6fcfba:	75 25                	jne    6fcfe1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5fa1>
  6fcfbc:	48 8b 9c 24 30 01 00 	mov    0x130(%rsp),%rbx
  6fcfc3:	00 
  6fcfc4:	48 8b 03             	mov    (%rbx),%rax
  6fcfc7:	48 8b b8 00 01 00 00 	mov    0x100(%rax),%rdi
  6fcfce:	e8 3d 54 fe ff       	call   6e2410 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::geometry::Geometry>>>>
  6fcfd3:	48 8b 03             	mov    (%rbx),%rax
  6fcfd6:	48 c7 80 00 01 00 00 	movq   $0x0,0x100(%rax)
  6fcfdd:	00 00 00 00 
  6fcfe1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  6fcfe6:	c6 87 4a 07 00 00 01 	movb   $0x1,0x74a(%rdi)
  6fcfed:	e8 be e4 fe ff       	call   6eb4b0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::prune_focus>
  6fcff2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6fcff7:	4c 89 a8 38 07 00 00 	mov    %r13,0x738(%rax)
  6fcffe:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6fd003:	48 c7 00 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rax)
  6fd00a:	ba 04 00 00 00       	mov    $0x4,%edx
  6fd00f:	48 8b bc 24 08 02 00 	mov    0x208(%rsp),%rdi
  6fd016:	00 
  6fd017:	48 8b b4 24 80 02 00 	mov    0x280(%rsp),%rsi
  6fd01e:	00 
  6fd01f:	ff 15 43 e7 38 00    	call   *0x38e743(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd025:	48 8b b4 24 88 02 00 	mov    0x288(%rsp),%rsi
  6fd02c:	00 
  6fd02d:	48 85 f6             	test   %rsi,%rsi
  6fd030:	74 14                	je     6fd046 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6006>
  6fd032:	48 c1 e6 03          	shl    $0x3,%rsi
  6fd036:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd03b:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
  6fd040:	ff 15 22 e7 38 00    	call   *0x38e722(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd046:	45 31 ed             	xor    %r13d,%r13d
  6fd049:	48 8d bc 24 98 08 00 	lea    0x898(%rsp),%rdi
  6fd050:	00 
  6fd051:	e8 1a f8 00 00       	call   70c870 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fd056:	48 8d bc 24 88 06 00 	lea    0x688(%rsp),%rdi
  6fd05d:	00 
  6fd05e:	e8 9d f4 00 00       	call   70c500 <<alloc::collections::btree::map::BTreeMap<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize> as core::ops::drop::Drop>::drop>
  6fd063:	48 8d bc 24 70 06 00 	lea    0x670(%rsp),%rdi
  6fd06a:	00 
  6fd06b:	e8 90 f4 00 00       	call   70c500 <<alloc::collections::btree::map::BTreeMap<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize> as core::ops::drop::Drop>::drop>
  6fd070:	48 8b 84 24 60 06 00 	mov    0x660(%rsp),%rax
  6fd077:	00 
  6fd078:	48 85 c0             	test   %rax,%rax
  6fd07b:	74 18                	je     6fd095 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6055>
  6fd07d:	48 c1 e0 03          	shl    $0x3,%rax
  6fd081:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6fd085:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd08a:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  6fd08f:	ff 15 d3 e6 38 00    	call   *0x38e6d3(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd095:	48 8b bc 24 08 05 00 	mov    0x508(%rsp),%rdi
  6fd09c:	00 
  6fd09d:	48 8b b4 24 e8 03 00 	mov    0x3e8(%rsp),%rsi
  6fd0a4:	00 
  6fd0a5:	e8 e6 75 fe ff       	call   6e4690 <core::ptr::drop_glue::<alloc::boxed::Box<[core::option::Option<gpui::element::Handler>]>>>
  6fd0aa:	48 8b b4 24 c8 07 00 	mov    0x7c8(%rsp),%rsi
  6fd0b1:	00 
  6fd0b2:	48 85 f6             	test   %rsi,%rsi
  6fd0b5:	74 17                	je     6fd0ce <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x608e>
  6fd0b7:	48 8b bc 24 d0 07 00 	mov    0x7d0(%rsp),%rdi
  6fd0be:	00 
  6fd0bf:	48 c1 e6 02          	shl    $0x2,%rsi
  6fd0c3:	ba 04 00 00 00       	mov    $0x4,%edx
  6fd0c8:	ff 15 9a e6 38 00    	call   *0x38e69a(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd0ce:	48 8d bc 24 a0 06 00 	lea    0x6a0(%rsp),%rdi
  6fd0d5:	00 
  6fd0d6:	e8 05 93 fe ff       	call   6e63e0 <core::ptr::drop_glue::<gpui::runtime::styles::Styles>>
  6fd0db:	48 8d bc 24 38 04 00 	lea    0x438(%rsp),%rdi
  6fd0e2:	00 
  6fd0e3:	e8 28 e8 00 00       	call   70b910 <<alloc::collections::btree::map::BTreeMap<gpui::source::FieldId, gpui::shared_text::SharedText> as core::ops::drop::Drop>::drop>
  6fd0e8:	45 84 e4             	test   %r12b,%r12b
  6fd0eb:	74 24                	je     6fd111 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x60d1>
  6fd0ed:	48 8b b4 24 68 02 00 	mov    0x268(%rsp),%rsi
  6fd0f4:	00 
  6fd0f5:	48 85 f6             	test   %rsi,%rsi
  6fd0f8:	74 17                	je     6fd111 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x60d1>
  6fd0fa:	48 8b bc 24 70 02 00 	mov    0x270(%rsp),%rdi
  6fd101:	00 
  6fd102:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd106:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd10b:	ff 15 57 e6 38 00    	call   *0x38e657(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd111:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd116:	48 8b bc 24 b0 02 00 	mov    0x2b0(%rsp),%rdi
  6fd11d:	00 
  6fd11e:	48 8b b4 24 08 04 00 	mov    0x408(%rsp),%rsi
  6fd125:	00 
  6fd126:	ff 15 3c e6 38 00    	call   *0x38e63c(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd12c:	48 8b b4 24 50 02 00 	mov    0x250(%rsp),%rsi
  6fd133:	00 
  6fd134:	48 85 f6             	test   %rsi,%rsi
  6fd137:	74 17                	je     6fd150 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6110>
  6fd139:	48 8b bc 24 58 02 00 	mov    0x258(%rsp),%rdi
  6fd140:	00 
  6fd141:	48 c1 e6 02          	shl    $0x2,%rsi
  6fd145:	ba 04 00 00 00       	mov    $0x4,%edx
  6fd14a:	ff 15 18 e6 38 00    	call   *0x38e618(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd150:	48 8b b4 24 38 02 00 	mov    0x238(%rsp),%rsi
  6fd157:	00 
  6fd158:	48 85 f6             	test   %rsi,%rsi
  6fd15b:	74 17                	je     6fd174 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6134>
  6fd15d:	48 8b bc 24 40 02 00 	mov    0x240(%rsp),%rdi
  6fd164:	00 
  6fd165:	48 c1 e6 03          	shl    $0x3,%rsi
  6fd169:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd16e:	ff 15 f4 e5 38 00    	call   *0x38e5f4(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd174:	48 8b b4 24 b8 02 00 	mov    0x2b8(%rsp),%rsi
  6fd17b:	00 
  6fd17c:	48 85 f6             	test   %rsi,%rsi
  6fd17f:	74 17                	je     6fd198 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6158>
  6fd181:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
  6fd188:	00 
  6fd189:	48 c1 e6 03          	shl    $0x3,%rsi
  6fd18d:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd192:	ff 15 d0 e5 38 00    	call   *0x38e5d0(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd198:	45 31 ed             	xor    %r13d,%r13d
  6fd19b:	48 8d bc 24 b0 07 00 	lea    0x7b0(%rsp),%rdi
  6fd1a2:	00 
  6fd1a3:	31 ed                	xor    %ebp,%ebp
  6fd1a5:	e8 c6 f6 00 00       	call   70c870 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fd1aa:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
  6fd1b1:	00 
  6fd1b2:	48 8d bc 24 68 08 00 	lea    0x868(%rsp),%rdi
  6fd1b9:	00 
  6fd1ba:	44 89 e3             	mov    %r12d,%ebx
  6fd1bd:	31 ed                	xor    %ebp,%ebp
  6fd1bf:	45 31 ff             	xor    %r15d,%r15d
  6fd1c2:	e8 29 d9 00 00       	call   70aaf0 <<alloc::collections::btree::map::BTreeMap<gpui_reactivity_core::tree::NodeId, fn(cephal::tree::traits::MeasureInput) -> cephal::tree::traits::MeasureOutput> as core::ops::drop::Drop>::drop>
  6fd1c7:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
  6fd1ce:	00 
  6fd1cf:	48 8d bc 24 50 08 00 	lea    0x850(%rsp),%rdi
  6fd1d6:	00 
  6fd1d7:	31 ed                	xor    %ebp,%ebp
  6fd1d9:	45 31 ff             	xor    %r15d,%r15d
  6fd1dc:	44 8b 64 24 30       	mov    0x30(%rsp),%r12d
  6fd1e1:	e8 8a f6 00 00       	call   70c870 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fd1e6:	45 84 e4             	test   %r12b,%r12b
  6fd1e9:	0f 84 9d 04 00 00    	je     6fd68c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x664c>
  6fd1ef:	48 8d bc 24 d0 04 00 	lea    0x4d0(%rsp),%rdi
  6fd1f6:	00 
  6fd1f7:	e8 54 6e fe ff       	call   6e4050 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::semantic::AnnotationDraft>>>
  6fd1fc:	e9 8b 04 00 00       	jmp    6fd68c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x664c>
  6fd201:	31 ed                	xor    %ebp,%ebp
  6fd203:	48 85 db             	test   %rbx,%rbx
  6fd206:	0f 84 f2 f8 ff ff    	je     6fcafe <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5abe>
  6fd20c:	48 83 bb 00 01 00 00 	cmpq   $0x0,0x100(%rbx)
  6fd213:	00 
  6fd214:	0f 85 52 ee ff ff    	jne    6fc06c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x502c>
  6fd21a:	e9 df f8 ff ff       	jmp    6fcafe <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5abe>
  6fd21f:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6fd224:	48 c7 00 1c 00 00 00 	movq   $0x1c,(%rax)
  6fd22b:	48 8b 8c 24 f0 01 00 	mov    0x1f0(%rsp),%rcx
  6fd232:	00 
  6fd233:	48 89 48 08          	mov    %rcx,0x8(%rax)
  6fd237:	41 b5 01             	mov    $0x1,%r13b
  6fd23a:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
  6fd241:	00 
  6fd242:	48 85 c9             	test   %rcx,%rcx
  6fd245:	74 4f                	je     6fd296 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6256>
  6fd247:	48 8b 94 24 58 01 00 	mov    0x158(%rsp),%rdx
  6fd24e:	00 
  6fd24f:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
  6fd256:	00 
  6fd257:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
  6fd25e:	00 00 00 00 00 
  6fd263:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  6fd26a:	00 
  6fd26b:	48 89 94 24 98 00 00 	mov    %rdx,0x98(%rsp)
  6fd272:	00 
  6fd273:	48 c7 84 24 a8 00 00 	movq   $0x0,0xa8(%rsp)
  6fd27a:	00 00 00 00 00 
  6fd27f:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
  6fd286:	00 
  6fd287:	48 89 94 24 b8 00 00 	mov    %rdx,0xb8(%rsp)
  6fd28e:	00 
  6fd28f:	b9 01 00 00 00       	mov    $0x1,%ecx
  6fd294:	eb 04                	jmp    6fd29a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x625a>
  6fd296:	31 c9                	xor    %ecx,%ecx
  6fd298:	31 c0                	xor    %eax,%eax
  6fd29a:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  6fd2a1:	00 
  6fd2a2:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
  6fd2a9:	00 
  6fd2aa:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  6fd2b1:	00 
  6fd2b2:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6fd2b9:	00 
  6fd2ba:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  6fd2c1:	00 
  6fd2c2:	44 89 6c 24 18       	mov    %r13d,0x18(%rsp)
  6fd2c7:	e8 74 cf 00 00       	call   70a240 <<alloc::collections::btree::map::IntoIter<gpui::source::FieldId, gpui::runtime::Fanout>>::dying_next>
  6fd2cc:	48 8b 84 24 10 07 00 	mov    0x710(%rsp),%rax
  6fd2d3:	00 
  6fd2d4:	48 85 c0             	test   %rax,%rax
  6fd2d7:	74 5d                	je     6fd336 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x62f6>
  6fd2d9:	48 8d 9c 24 10 07 00 	lea    0x710(%rsp),%rbx
  6fd2e0:	00 
  6fd2e1:	4c 8d b4 24 80 00 00 	lea    0x80(%rsp),%r14
  6fd2e8:	00 
  6fd2e9:	4c 8b 3d 78 e4 38 00 	mov    0x38e478(%rip),%r15        # a8b768 <_DYNAMIC+0x250>
  6fd2f0:	48 8b 8c 24 20 07 00 	mov    0x720(%rsp),%rcx
  6fd2f7:	00 
  6fd2f8:	48 c1 e1 05          	shl    $0x5,%rcx
  6fd2fc:	48 8b 34 08          	mov    (%rax,%rcx,1),%rsi
  6fd300:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fd304:	74 18                	je     6fd31e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x62de>
  6fd306:	48 85 f6             	test   %rsi,%rsi
  6fd309:	74 13                	je     6fd31e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x62de>
  6fd30b:	48 01 c8             	add    %rcx,%rax
  6fd30e:	48 8b 78 08          	mov    0x8(%rax),%rdi
  6fd312:	48 c1 e6 02          	shl    $0x2,%rsi
  6fd316:	ba 04 00 00 00       	mov    $0x4,%edx
  6fd31b:	41 ff d7             	call   *%r15
  6fd31e:	48 89 df             	mov    %rbx,%rdi
  6fd321:	4c 89 f6             	mov    %r14,%rsi
  6fd324:	e8 17 cf 00 00       	call   70a240 <<alloc::collections::btree::map::IntoIter<gpui::source::FieldId, gpui::runtime::Fanout>>::dying_next>
  6fd329:	48 8b 84 24 10 07 00 	mov    0x710(%rsp),%rax
  6fd330:	00 
  6fd331:	48 85 c0             	test   %rax,%rax
  6fd334:	75 ba                	jne    6fd2f0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x62b0>
  6fd336:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd33b:	48 8b bc 24 b0 02 00 	mov    0x2b0(%rsp),%rdi
  6fd342:	00 
  6fd343:	48 8b b4 24 08 04 00 	mov    0x408(%rsp),%rsi
  6fd34a:	00 
  6fd34b:	ff 15 17 e4 38 00    	call   *0x38e417(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd351:	48 8b b4 24 50 02 00 	mov    0x250(%rsp),%rsi
  6fd358:	00 
  6fd359:	48 85 f6             	test   %rsi,%rsi
  6fd35c:	74 17                	je     6fd375 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6335>
  6fd35e:	48 8b bc 24 58 02 00 	mov    0x258(%rsp),%rdi
  6fd365:	00 
  6fd366:	48 c1 e6 02          	shl    $0x2,%rsi
  6fd36a:	ba 04 00 00 00       	mov    $0x4,%edx
  6fd36f:	ff 15 f3 e3 38 00    	call   *0x38e3f3(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd375:	48 8b b4 24 38 02 00 	mov    0x238(%rsp),%rsi
  6fd37c:	00 
  6fd37d:	48 85 f6             	test   %rsi,%rsi
  6fd380:	74 17                	je     6fd399 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6359>
  6fd382:	48 8b bc 24 40 02 00 	mov    0x240(%rsp),%rdi
  6fd389:	00 
  6fd38a:	48 c1 e6 03          	shl    $0x3,%rsi
  6fd38e:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd393:	ff 15 cf e3 38 00    	call   *0x38e3cf(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd399:	48 8b b4 24 b8 02 00 	mov    0x2b8(%rsp),%rsi
  6fd3a0:	00 
  6fd3a1:	48 85 f6             	test   %rsi,%rsi
  6fd3a4:	74 17                	je     6fd3bd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x637d>
  6fd3a6:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
  6fd3ad:	00 
  6fd3ae:	48 c1 e6 03          	shl    $0x3,%rsi
  6fd3b2:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd3b7:	ff 15 ab e3 38 00    	call   *0x38e3ab(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd3bd:	41 b4 01             	mov    $0x1,%r12b
  6fd3c0:	48 8d bc 24 b0 07 00 	lea    0x7b0(%rsp),%rdi
  6fd3c7:	00 
  6fd3c8:	40 b5 01             	mov    $0x1,%bpl
  6fd3cb:	e8 a0 f4 00 00       	call   70c870 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fd3d0:	48 8b 84 24 b0 04 00 	mov    0x4b0(%rsp),%rax
  6fd3d7:	00 
  6fd3d8:	48 85 c0             	test   %rax,%rax
  6fd3db:	74 41                	je     6fd41e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x63de>
  6fd3dd:	48 8b 9c 24 a8 04 00 	mov    0x4a8(%rsp),%rbx
  6fd3e4:	00 
  6fd3e5:	41 be 01 00 00 00    	mov    $0x1,%r14d
  6fd3eb:	49 29 c6             	sub    %rax,%r14
  6fd3ee:	4c 8b 3d db e3 38 00 	mov    0x38e3db(%rip),%r15        # a8b7d0 <_DYNAMIC+0x2b8>
  6fd3f5:	eb 16                	jmp    6fd40d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x63cd>
  6fd3f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6fd3fe:	00 00 
  6fd400:	48 83 c3 08          	add    $0x8,%rbx
  6fd404:	49 ff c6             	inc    %r14
  6fd407:	49 83 fe 01          	cmp    $0x1,%r14
  6fd40b:	74 11                	je     6fd41e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x63de>
  6fd40d:	48 8b 03             	mov    (%rbx),%rax
  6fd410:	f0 48 ff 08          	lock decq (%rax)
  6fd414:	75 ea                	jne    6fd400 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x63c0>
  6fd416:	48 89 df             	mov    %rbx,%rdi
  6fd419:	41 ff d7             	call   *%r15
  6fd41c:	eb e2                	jmp    6fd400 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x63c0>
  6fd41e:	48 8b b4 24 a0 04 00 	mov    0x4a0(%rsp),%rsi
  6fd425:	00 
  6fd426:	48 85 f6             	test   %rsi,%rsi
  6fd429:	74 17                	je     6fd442 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6402>
  6fd42b:	48 8b bc 24 a8 04 00 	mov    0x4a8(%rsp),%rdi
  6fd432:	00 
  6fd433:	48 c1 e6 03          	shl    $0x3,%rsi
  6fd437:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd43c:	ff 15 26 e3 38 00    	call   *0x38e326(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd442:	31 ed                	xor    %ebp,%ebp
  6fd444:	b3 01                	mov    $0x1,%bl
  6fd446:	48 8d bc 24 68 08 00 	lea    0x868(%rsp),%rdi
  6fd44d:	00 
  6fd44e:	41 b7 01             	mov    $0x1,%r15b
  6fd451:	e8 9a d6 00 00       	call   70aaf0 <<alloc::collections::btree::map::BTreeMap<gpui_reactivity_core::tree::NodeId, fn(cephal::tree::traits::MeasureInput) -> cephal::tree::traits::MeasureOutput> as core::ops::drop::Drop>::drop>
  6fd456:	41 b4 01             	mov    $0x1,%r12b
  6fd459:	48 8d bc 24 50 08 00 	lea    0x850(%rsp),%rdi
  6fd460:	00 
  6fd461:	41 b7 01             	mov    $0x1,%r15b
  6fd464:	e8 07 f4 00 00       	call   70c870 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fd469:	48 8b 9c 24 e8 05 00 	mov    0x5e8(%rsp),%rbx
  6fd470:	00 
  6fd471:	4c 8b b4 24 f0 05 00 	mov    0x5f0(%rsp),%r14
  6fd478:	00 
  6fd479:	4d 85 f6             	test   %r14,%r14
  6fd47c:	44 8b 6c 24 18       	mov    0x18(%rsp),%r13d
  6fd481:	74 5c                	je     6fd4df <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x649f>
  6fd483:	4c 8d bb 88 00 00 00 	lea    0x88(%rbx),%r15
  6fd48a:	4c 8b 25 d7 e2 38 00 	mov    0x38e2d7(%rip),%r12        # a8b768 <_DYNAMIC+0x250>
  6fd491:	eb 19                	jmp    6fd4ac <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x646c>
  6fd493:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6fd49a:	84 00 00 00 00 00 
  6fd4a0:	49 81 c7 a8 00 00 00 	add    $0xa8,%r15
  6fd4a7:	49 ff ce             	dec    %r14
  6fd4aa:	74 33                	je     6fd4df <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x649f>
  6fd4ac:	49 8b 77 90          	mov    -0x70(%r15),%rsi
  6fd4b0:	48 85 f6             	test   %rsi,%rsi
  6fd4b3:	74 10                	je     6fd4c5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6485>
  6fd4b5:	49 8b 7f 98          	mov    -0x68(%r15),%rdi
  6fd4b9:	48 c1 e6 03          	shl    $0x3,%rsi
  6fd4bd:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd4c2:	41 ff d4             	call   *%r12
  6fd4c5:	49 8b 77 f8          	mov    -0x8(%r15),%rsi
  6fd4c9:	48 85 f6             	test   %rsi,%rsi
  6fd4cc:	74 d2                	je     6fd4a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6460>
  6fd4ce:	49 8b 3f             	mov    (%r15),%rdi
  6fd4d1:	48 c1 e6 05          	shl    $0x5,%rsi
  6fd4d5:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd4da:	41 ff d4             	call   *%r12
  6fd4dd:	eb c1                	jmp    6fd4a0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6460>
  6fd4df:	48 8b 84 24 e0 05 00 	mov    0x5e0(%rsp),%rax
  6fd4e6:	00 
  6fd4e7:	48 85 c0             	test   %rax,%rax
  6fd4ea:	74 15                	je     6fd501 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x64c1>
  6fd4ec:	48 69 f0 a8 00 00 00 	imul   $0xa8,%rax,%rsi
  6fd4f3:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd4f8:	48 89 df             	mov    %rbx,%rdi
  6fd4fb:	ff 15 67 e2 38 00    	call   *0x38e267(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd501:	48 8b b4 24 38 05 00 	mov    0x538(%rsp),%rsi
  6fd508:	00 
  6fd509:	48 85 f6             	test   %rsi,%rsi
  6fd50c:	48 8b 9c 24 18 04 00 	mov    0x418(%rsp),%rbx
  6fd513:	00 
  6fd514:	74 17                	je     6fd52d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x64ed>
  6fd516:	48 8b bc 24 40 05 00 	mov    0x540(%rsp),%rdi
  6fd51d:	00 
  6fd51e:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd522:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd527:	ff 15 3b e2 38 00    	call   *0x38e23b(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd52d:	48 8b 8c 24 f8 01 00 	mov    0x1f8(%rsp),%rcx
  6fd534:	00 
  6fd535:	48 85 c9             	test   %rcx,%rcx
  6fd538:	0f 95 c0             	setne  %al
  6fd53b:	41 84 c5             	test   %al,%r13b
  6fd53e:	74 1b                	je     6fd55b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x651b>
  6fd540:	48 c1 e1 03          	shl    $0x3,%rcx
  6fd544:	48 8d 34 49          	lea    (%rcx,%rcx,2),%rsi
  6fd548:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd54d:	48 8b bc 24 28 02 00 	mov    0x228(%rsp),%rdi
  6fd554:	00 
  6fd555:	ff 15 0d e2 38 00    	call   *0x38e20d(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd55b:	48 8b b4 24 40 01 00 	mov    0x140(%rsp),%rsi
  6fd562:	00 
  6fd563:	48 85 f6             	test   %rsi,%rsi
  6fd566:	74 17                	je     6fd57f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x653f>
  6fd568:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd56c:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd571:	48 8b bc 24 48 01 00 	mov    0x148(%rsp),%rdi
  6fd578:	00 
  6fd579:	ff 15 e9 e1 38 00    	call   *0x38e1e9(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd57f:	48 85 db             	test   %rbx,%rbx
  6fd582:	0f 95 c0             	setne  %al
  6fd585:	40 84 c5             	test   %al,%bpl
  6fd588:	74 1b                	je     6fd5a5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6565>
  6fd58a:	48 c1 e3 03          	shl    $0x3,%rbx
  6fd58e:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
  6fd592:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd597:	48 8b bc 24 18 05 00 	mov    0x518(%rsp),%rdi
  6fd59e:	00 
  6fd59f:	ff 15 c3 e1 38 00    	call   *0x38e1c3(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd5a5:	48 8b 9c 24 d8 04 00 	mov    0x4d8(%rsp),%rbx
  6fd5ac:	00 
  6fd5ad:	4c 8b b4 24 e0 04 00 	mov    0x4e0(%rsp),%r14
  6fd5b4:	00 
  6fd5b5:	4d 85 f6             	test   %r14,%r14
  6fd5b8:	74 5a                	je     6fd614 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x65d4>
  6fd5ba:	4c 8d 7b 20          	lea    0x20(%rbx),%r15
  6fd5be:	4c 8b 25 a3 e1 38 00 	mov    0x38e1a3(%rip),%r12        # a8b768 <_DYNAMIC+0x250>
  6fd5c5:	eb 12                	jmp    6fd5d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6599>
  6fd5c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6fd5ce:	00 00 
  6fd5d0:	49 83 c7 38          	add    $0x38,%r15
  6fd5d4:	49 ff ce             	dec    %r14
  6fd5d7:	74 3b                	je     6fd614 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x65d4>
  6fd5d9:	49 8b 77 e0          	mov    -0x20(%r15),%rsi
  6fd5dd:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fd5e1:	74 13                	je     6fd5f6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x65b6>
  6fd5e3:	48 85 f6             	test   %rsi,%rsi
  6fd5e6:	78 0e                	js     6fd5f6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x65b6>
  6fd5e8:	74 0c                	je     6fd5f6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x65b6>
  6fd5ea:	49 8b 7f e8          	mov    -0x18(%r15),%rdi
  6fd5ee:	ba 01 00 00 00       	mov    $0x1,%edx
  6fd5f3:	41 ff d4             	call   *%r12
  6fd5f6:	49 8b 77 f8          	mov    -0x8(%r15),%rsi
  6fd5fa:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6fd5fe:	74 d0                	je     6fd5d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6590>
  6fd600:	48 85 f6             	test   %rsi,%rsi
  6fd603:	78 cb                	js     6fd5d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6590>
  6fd605:	74 c9                	je     6fd5d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6590>
  6fd607:	49 8b 3f             	mov    (%r15),%rdi
  6fd60a:	ba 01 00 00 00       	mov    $0x1,%edx
  6fd60f:	41 ff d4             	call   *%r12
  6fd612:	eb bc                	jmp    6fd5d0 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6590>
  6fd614:	48 8b 84 24 d0 04 00 	mov    0x4d0(%rsp),%rax
  6fd61b:	00 
  6fd61c:	48 85 c0             	test   %rax,%rax
  6fd61f:	74 12                	je     6fd633 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x65f3>
  6fd621:	48 6b f0 38          	imul   $0x38,%rax,%rsi
  6fd625:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd62a:	48 89 df             	mov    %rbx,%rdi
  6fd62d:	ff 15 35 e1 38 00    	call   *0x38e135(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd633:	48 8b 9c 24 28 04 00 	mov    0x428(%rsp),%rbx
  6fd63a:	00 
  6fd63b:	4c 8b bc 24 30 04 00 	mov    0x430(%rsp),%r15
  6fd642:	00 
  6fd643:	49 ff c7             	inc    %r15
  6fd646:	48 89 df             	mov    %rbx,%rdi
  6fd649:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6fd650:	49 83 ff 01          	cmp    $0x1,%r15
  6fd654:	74 14                	je     6fd66a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x662a>
  6fd656:	4c 8d b7 98 00 00 00 	lea    0x98(%rdi),%r14
  6fd65d:	49 ff cf             	dec    %r15
  6fd660:	e8 0b 4d 00 00       	call   702370 <core::ptr::drop_glue::<gpui::element::DraftNode>>
  6fd665:	4c 89 f7             	mov    %r14,%rdi
  6fd668:	eb e6                	jmp    6fd650 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6610>
  6fd66a:	48 8b 84 24 20 04 00 	mov    0x420(%rsp),%rax
  6fd671:	00 
  6fd672:	48 85 c0             	test   %rax,%rax
  6fd675:	74 15                	je     6fd68c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x664c>
  6fd677:	48 69 f0 98 00 00 00 	imul   $0x98,%rax,%rsi
  6fd67e:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd683:	48 89 df             	mov    %rbx,%rdi
  6fd686:	ff 15 dc e0 38 00    	call   *0x38e0dc(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd68c:	48 8d bc 24 80 08 00 	lea    0x880(%rsp),%rdi
  6fd693:	00 
  6fd694:	e8 77 df 00 00       	call   70b610 <<alloc::collections::btree::map::BTreeMap<gpui::list::ListId, alloc::collections::btree::set_val::SetValZST> as core::ops::drop::Drop>::drop>
  6fd699:	48 81 c4 d8 08 00 00 	add    $0x8d8,%rsp
  6fd6a0:	5b                   	pop    %rbx
  6fd6a1:	41 5c                	pop    %r12
  6fd6a3:	41 5d                	pop    %r13
  6fd6a5:	41 5e                	pop    %r14
  6fd6a7:	41 5f                	pop    %r15
  6fd6a9:	5d                   	pop    %rbp
  6fd6aa:	c3                   	ret
  6fd6ab:	49 83 fc ff          	cmp    $0xffffffffffffffff,%r12
  6fd6af:	74 16                	je     6fd6c7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6687>
  6fd6b1:	4d 85 e4             	test   %r12,%r12
  6fd6b4:	7e 11                	jle    6fd6c7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6687>
  6fd6b6:	ba 01 00 00 00       	mov    $0x1,%edx
  6fd6bb:	4c 89 ff             	mov    %r15,%rdi
  6fd6be:	4c 89 e6             	mov    %r12,%rsi
  6fd6c1:	ff 15 a1 e0 38 00    	call   *0x38e0a1(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd6c7:	48 83 fb ff          	cmp    $0xffffffffffffffff,%rbx
  6fd6cb:	0f 84 39 e8 ff ff    	je     6fbf0a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4eca>
  6fd6d1:	48 85 db             	test   %rbx,%rbx
  6fd6d4:	0f 8e 30 e8 ff ff    	jle    6fbf0a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4eca>
  6fd6da:	ba 01 00 00 00       	mov    $0x1,%edx
  6fd6df:	4c 89 f7             	mov    %r14,%rdi
  6fd6e2:	48 89 de             	mov    %rbx,%rsi
  6fd6e5:	ff 15 7d e0 38 00    	call   *0x38e07d(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd6eb:	e9 1a e8 ff ff       	jmp    6fbf0a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x4eca>
  6fd6f0:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  6fd6f7:	00 
  6fd6f8:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  6fd6fd:	48 c7 02 20 00 00 00 	movq   $0x20,(%rdx)
  6fd704:	48 89 42 08          	mov    %rax,0x8(%rdx)
  6fd708:	48 89 5a 10          	mov    %rbx,0x10(%rdx)
  6fd70c:	48 89 4a 18          	mov    %rcx,0x18(%rdx)
  6fd710:	e9 22 fb ff ff       	jmp    6fd237 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x61f7>
  6fd715:	b3 01                	mov    $0x1,%bl
  6fd717:	48 8d 3d e3 d3 95 ff 	lea    -0x6a2c1d(%rip),%rdi        # 5ab01 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2e39>
  6fd71e:	48 8d 15 0b 5b 36 00 	lea    0x365b0b(%rip),%rdx        # a63230 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xd70>
  6fd725:	be 1b 00 00 00       	mov    $0x1b,%esi
  6fd72a:	ff 15 40 e1 38 00    	call   *0x38e140(%rip)        # a8b870 <_DYNAMIC+0x358>
  6fd730:	e9 e6 05 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fd735:	48 8d 3d 94 5a 36 00 	lea    0x365a94(%rip),%rdi        # a631d0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xd10>
  6fd73c:	ff 15 4e e0 38 00    	call   *0x38e04e(%rip)        # a8b790 <_DYNAMIC+0x278>
  6fd742:	e9 d4 05 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fd747:	48 8d 3d 82 65 36 00 	lea    0x366582(%rip),%rdi        # a63cd0 <anon.1a4a1640ff2d1bf549336a1593f98f2a.1.llvm.10670173712625079383>
  6fd74e:	ff 15 3c e0 38 00    	call   *0x38e03c(%rip)        # a8b790 <_DYNAMIC+0x278>
  6fd754:	e9 c2 05 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fd759:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6fd75e:	48 c7 00 1f 00 00 00 	movq   $0x1f,(%rax)
  6fd765:	e9 09 9c ff ff       	jmp    6f7373 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x333>
  6fd76a:	48 83 bc 24 40 01 00 	cmpq   $0x0,0x140(%rsp)
  6fd771:	00 00 
  6fd773:	74 1f                	je     6fd794 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6754>
  6fd775:	48 8b b4 24 40 01 00 	mov    0x140(%rsp),%rsi
  6fd77c:	00 
  6fd77d:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd781:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd786:	48 8b bc 24 48 01 00 	mov    0x148(%rsp),%rdi
  6fd78d:	00 
  6fd78e:	ff 15 d4 df 38 00    	call   *0x38dfd4(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd794:	49 8b 34 24          	mov    (%r12),%rsi
  6fd798:	48 85 f6             	test   %rsi,%rsi
  6fd79b:	74 14                	je     6fd7b1 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6771>
  6fd79d:	49 8b 7c 24 08       	mov    0x8(%r12),%rdi
  6fd7a2:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd7a6:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd7ab:	ff 15 b7 df 38 00    	call   *0x38dfb7(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd7b1:	49 8d 7c 24 48       	lea    0x48(%r12),%rdi
  6fd7b6:	e8 75 f5 00 00       	call   70cd30 <<alloc::collections::btree::map::BTreeMap<u64, gpui::property::Overlay<gpui::property::GeometryStyle>> as core::ops::drop::Drop>::drop>
  6fd7bb:	49 8b 74 24 18       	mov    0x18(%r12),%rsi
  6fd7c0:	48 85 f6             	test   %rsi,%rsi
  6fd7c3:	74 14                	je     6fd7d9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6799>
  6fd7c5:	49 8b 7c 24 20       	mov    0x20(%r12),%rdi
  6fd7ca:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd7ce:	ba 04 00 00 00       	mov    $0x4,%edx
  6fd7d3:	ff 15 8f df 38 00    	call   *0x38df8f(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd7d9:	49 8b 74 24 30       	mov    0x30(%r12),%rsi
  6fd7de:	48 85 f6             	test   %rsi,%rsi
  6fd7e1:	7e 14                	jle    6fd7f7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x67b7>
  6fd7e3:	49 8b 7c 24 38       	mov    0x38(%r12),%rdi
  6fd7e8:	48 c1 e6 04          	shl    $0x4,%rsi
  6fd7ec:	ba 04 00 00 00       	mov    $0x4,%edx
  6fd7f1:	ff 15 71 df 38 00    	call   *0x38df71(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fd7f7:	be 60 00 00 00       	mov    $0x60,%esi
  6fd7fc:	ba 08 00 00 00       	mov    $0x8,%edx
  6fd801:	4c 89 e7             	mov    %r12,%rdi
  6fd804:	e9 13 f3 ff ff       	jmp    6fcb1c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5adc>
  6fd809:	48 8d 3d 90 51 36 00 	lea    0x365190(%rip),%rdi        # a629a0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x4e0>
  6fd810:	ff 15 7a df 38 00    	call   *0x38df7a(%rip)        # a8b790 <_DYNAMIC+0x278>
  6fd816:	e9 00 05 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fd81b:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
  6fd820:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  6fd827:	00 00 
  6fd829:	48 8d 3d a4 d2 95 ff 	lea    -0x6a2d5c(%rip),%rdi        # 5aad4 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2e0c>
  6fd830:	48 8d 15 51 59 36 00 	lea    0x365951(%rip),%rdx        # a63188 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xcc8>
  6fd837:	be 16 00 00 00       	mov    $0x16,%esi
  6fd83c:	ff 15 2e e0 38 00    	call   *0x38e02e(%rip)        # a8b870 <_DYNAMIC+0x358>
  6fd842:	e9 d4 04 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fd847:	48 8d 3d e2 51 36 00 	lea    0x3651e2(%rip),%rdi        # a62a30 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x570>
  6fd84e:	ff 15 3c df 38 00    	call   *0x38df3c(%rip)        # a8b790 <_DYNAMIC+0x278>
  6fd854:	e9 c2 04 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fd859:	48 8d 3d f6 d1 95 ff 	lea    -0x6a2e0a(%rip),%rdi        # 5aa56 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2d8e>
  6fd860:	48 8d 15 89 56 36 00 	lea    0x365689(%rip),%rdx        # a62ef0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa30>
  6fd867:	be 83 00 00 00       	mov    $0x83,%esi
  6fd86c:	ff 15 36 df 38 00    	call   *0x38df36(%rip)        # a8b7a8 <_DYNAMIC+0x290>
  6fd872:	e9 a4 04 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fd877:	45 31 ed             	xor    %r13d,%r13d
  6fd87a:	48 8d 3d ad d1 95 ff 	lea    -0x6a2e53(%rip),%rdi        # 5aa2e <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2d66>
  6fd881:	48 8d 15 50 56 36 00 	lea    0x365650(%rip),%rdx        # a62ed8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa18>
  6fd888:	be 51 00 00 00       	mov    $0x51,%esi
  6fd88d:	ff 15 15 df 38 00    	call   *0x38df15(%rip)        # a8b7a8 <_DYNAMIC+0x290>
  6fd893:	e9 83 04 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fd898:	48 8d 3d 09 4f 36 00 	lea    0x364f09(%rip),%rdi        # a627a8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x2e8>
  6fd89f:	ff 15 eb de 38 00    	call   *0x38deeb(%rip)        # a8b790 <_DYNAMIC+0x278>
  6fd8a5:	e9 71 04 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fd8aa:	48 8d 3d 4f 5e 36 00 	lea    0x365e4f(%rip),%rdi        # a63700 <anon.92a5b798a24d77726913e1a598e97bdf.3.llvm.13561988957598541395>
  6fd8b1:	ff 15 d9 de 38 00    	call   *0x38ded9(%rip)        # a8b790 <_DYNAMIC+0x278>
  6fd8b7:	e9 5f 04 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fd8bc:	48 8d 3d 93 d1 95 ff 	lea    -0x6a2e6d(%rip),%rdi        # 5aa56 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2d8e>
  6fd8c3:	48 8d 15 26 56 36 00 	lea    0x365626(%rip),%rdx        # a62ef0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa30>
  6fd8ca:	be 83 00 00 00       	mov    $0x83,%esi
  6fd8cf:	ff 15 d3 de 38 00    	call   *0x38ded3(%rip)        # a8b7a8 <_DYNAMIC+0x290>
  6fd8d5:	e9 41 04 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fd8da:	48 8d 3d 75 d1 95 ff 	lea    -0x6a2e8b(%rip),%rdi        # 5aa56 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2d8e>
  6fd8e1:	48 8d 15 08 56 36 00 	lea    0x365608(%rip),%rdx        # a62ef0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa30>
  6fd8e8:	be 83 00 00 00       	mov    $0x83,%esi
  6fd8ed:	ff 15 b5 de 38 00    	call   *0x38deb5(%rip)        # a8b7a8 <_DYNAMIC+0x290>
  6fd8f3:	e9 23 04 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fd8f8:	48 83 fe 15          	cmp    $0x15,%rsi
  6fd8fc:	0f 83 1b 04 00 00    	jae    6fdd1d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdd>
  6fd902:	48 8d 8c 24 80 00 00 	lea    0x80(%rsp),%rcx
  6fd909:	00 
  6fd90a:	ba 01 00 00 00       	mov    $0x1,%edx
  6fd90f:	e8 dc a3 00 00       	call   707cf0 <core::slice::sort::shared::smallsort::insertion_sort_shift_left::<(u64, gpui::property::GeometryStyle), <[(u64, gpui::property::GeometryStyle)]>::sort_unstable_by_key<u64, <gpui::runtime::Runtime<route_columns_cost::Page>>::reconcile_geometry::{closure#2}>::{closure#0}>>
  6fd914:	8b 6c 24 30          	mov    0x30(%rsp),%ebp
  6fd918:	4c 8b ac 24 80 01 00 	mov    0x180(%rsp),%r13
  6fd91f:	00 
  6fd920:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  6fd925:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
  6fd92a:	e9 3f f1 ff ff       	jmp    6fca6e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5a2e>
  6fd92f:	89 6c 24 30          	mov    %ebp,0x30(%rsp)
  6fd933:	bf 08 00 00 00       	mov    $0x8,%edi
  6fd938:	48 89 de             	mov    %rbx,%rsi
  6fd93b:	ff 15 3f de 38 00    	call   *0x38de3f(%rip)        # a8b780 <_DYNAMIC+0x268>
  6fd941:	e9 d5 03 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fd946:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
  6fd94d:	00 
  6fd94e:	ff 15 dc de 38 00    	call   *0x38dedc(%rip)        # a8b830 <_DYNAMIC+0x318>
  6fd954:	e9 c2 03 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fd959:	48 8b 84 24 a0 02 00 	mov    0x2a0(%rsp),%rax
  6fd960:	00 
  6fd961:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
  6fd968:	00 
  6fd969:	48 8d 15 d0 57 36 00 	lea    0x3657d0(%rip),%rdx        # a63140 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xc80>
  6fd970:	ff 15 0a df 38 00    	call   *0x38df0a(%rip)        # a8b880 <_DYNAMIC+0x368>
  6fd976:	e9 a0 03 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fd97b:	48 8d 3d 68 d1 95 ff 	lea    -0x6a2e98(%rip),%rdi        # 5aaea <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2e22>
  6fd982:	48 8d 15 5f 58 36 00 	lea    0x36585f(%rip),%rdx        # a631e8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xd28>
  6fd989:	be 17 00 00 00       	mov    $0x17,%esi
  6fd98e:	ff 15 dc de 38 00    	call   *0x38dedc(%rip)        # a8b870 <_DYNAMIC+0x358>
  6fd994:	e9 82 03 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fd999:	48 8d 3d 78 5d 36 00 	lea    0x365d78(%rip),%rdi        # a63718 <anon.92a5b798a24d77726913e1a598e97bdf.4.llvm.13561988957598541395>
  6fd9a0:	ff 15 ea dd 38 00    	call   *0x38ddea(%rip)        # a8b790 <_DYNAMIC+0x278>
  6fd9a6:	e9 70 03 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fd9ab:	48 8d 15 2e 57 36 00 	lea    0x36572e(%rip),%rdx        # a630e0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xc20>
  6fd9b2:	be 02 00 00 00       	mov    $0x2,%esi
  6fd9b7:	4c 89 e7             	mov    %r12,%rdi
  6fd9ba:	ff 15 c0 de 38 00    	call   *0x38dec0(%rip)        # a8b880 <_DYNAMIC+0x368>
  6fd9c0:	e9 56 03 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fd9c5:	48 8d 15 bc 4f 36 00 	lea    0x364fbc(%rip),%rdx        # a62988 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x4c8>
  6fd9cc:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  6fd9d1:	ff 15 a9 de 38 00    	call   *0x38dea9(%rip)        # a8b880 <_DYNAMIC+0x368>
  6fd9d7:	e9 3f 03 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fd9dc:	48 8d 15 2d 57 36 00 	lea    0x36572d(%rip),%rdx        # a63110 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xc50>
  6fd9e3:	ff 15 97 de 38 00    	call   *0x38de97(%rip)        # a8b880 <_DYNAMIC+0x368>
  6fd9e9:	e9 2d 03 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fd9ee:	48 89 c5             	mov    %rax,%rbp
  6fd9f1:	4c 8b a4 24 98 02 00 	mov    0x298(%rsp),%r12
  6fd9f8:	00 
  6fd9f9:	48 8d 05 18 58 36 00 	lea    0x365818(%rip),%rax        # a63218 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xd58>
  6fda00:	e9 b4 00 00 00       	jmp    6fdab9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6a79>
  6fda05:	bf 08 00 00 00       	mov    $0x8,%edi
  6fda0a:	48 8b b4 24 08 04 00 	mov    0x408(%rsp),%rsi
  6fda11:	00 
  6fda12:	ff 15 18 de 38 00    	call   *0x38de18(%rip)        # a8b830 <_DYNAMIC+0x318>
  6fda18:	e9 fe 02 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fda1d:	48 8d 3d 32 d0 95 ff 	lea    -0x6a2fce(%rip),%rdi        # 5aa56 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2d8e>
  6fda24:	48 8d 15 c5 54 36 00 	lea    0x3654c5(%rip),%rdx        # a62ef0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa30>
  6fda2b:	be 83 00 00 00       	mov    $0x83,%esi
  6fda30:	ff 15 72 dd 38 00    	call   *0x38dd72(%rip)        # a8b7a8 <_DYNAMIC+0x290>
  6fda36:	e9 e0 02 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fda3b:	48 85 ff             	test   %rdi,%rdi
  6fda3e:	0f 85 a9 00 00 00    	jne    6fdaed <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6aad>
  6fda44:	ff 15 26 df 38 00    	call   *0x38df26(%rip)        # a8b970 <_DYNAMIC+0x458>
  6fda4a:	e9 cc 02 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fda4f:	4c 89 ac 24 78 03 00 	mov    %r13,0x378(%rsp)
  6fda56:	00 
  6fda57:	48 8d 15 ca 56 36 00 	lea    0x3656ca(%rip),%rdx        # a63128 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xc68>
  6fda5e:	48 8b bc 24 20 02 00 	mov    0x220(%rsp),%rdi
  6fda65:	00 
  6fda66:	48 8b b4 24 f8 03 00 	mov    0x3f8(%rsp),%rsi
  6fda6d:	00 
  6fda6e:	ff 15 0c de 38 00    	call   *0x38de0c(%rip)        # a8b880 <_DYNAMIC+0x368>
  6fda74:	e9 a2 02 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fda79:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
  6fda7e:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  6fda85:	00 00 
  6fda87:	e9 9b 00 00 00       	jmp    6fdb27 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6ae7>
  6fda8c:	bf 08 00 00 00       	mov    $0x8,%edi
  6fda91:	48 89 de             	mov    %rbx,%rsi
  6fda94:	ff 15 96 dd 38 00    	call   *0x38dd96(%rip)        # a8b830 <_DYNAMIC+0x318>
  6fda9a:	e9 7c 02 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fda9f:	bf 08 00 00 00       	mov    $0x8,%edi
  6fdaa4:	48 89 de             	mov    %rbx,%rsi
  6fdaa7:	ff 15 83 dd 38 00    	call   *0x38dd83(%rip)        # a8b830 <_DYNAMIC+0x318>
  6fdaad:	e9 69 02 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdab2:	48 8d 05 b7 4e 36 00 	lea    0x364eb7(%rip),%rax        # a62970 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x4b0>
  6fdab9:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  6fdabe:	b3 01                	mov    $0x1,%bl
  6fdac0:	48 89 ef             	mov    %rbp,%rdi
  6fdac3:	4c 89 e6             	mov    %r12,%rsi
  6fdac6:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
  6fdacb:	ff 15 af dd 38 00    	call   *0x38ddaf(%rip)        # a8b880 <_DYNAMIC+0x368>
  6fdad1:	e9 45 02 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdad6:	48 8d 15 23 57 36 00 	lea    0x365723(%rip),%rdx        # a63200 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xd40>
  6fdadd:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  6fdae2:	ff 15 98 dd 38 00    	call   *0x38dd98(%rip)        # a8b880 <_DYNAMIC+0x368>
  6fdae8:	e9 2e 02 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdaed:	48 8b b4 24 98 01 00 	mov    0x198(%rsp),%rsi
  6fdaf4:	00 
  6fdaf5:	ff 15 85 dc 38 00    	call   *0x38dc85(%rip)        # a8b780 <_DYNAMIC+0x268>
  6fdafb:	e9 1b 02 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdb00:	48 8d 15 41 4f 36 00 	lea    0x364f41(%rip),%rdx        # a62a48 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x588>
  6fdb07:	48 89 df             	mov    %rbx,%rdi
  6fdb0a:	ff 15 70 dd 38 00    	call   *0x38dd70(%rip)        # a8b880 <_DYNAMIC+0x368>
  6fdb10:	e9 06 02 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdb15:	49 89 c6             	mov    %rax,%r14
  6fdb18:	48 8d 05 a1 53 36 00 	lea    0x3653a1(%rip),%rax        # a62ec0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa00>
  6fdb1f:	48 89 84 24 58 06 00 	mov    %rax,0x658(%rsp)
  6fdb26:	00 
  6fdb27:	4c 89 f7             	mov    %r14,%rdi
  6fdb2a:	48 8b 94 24 58 06 00 	mov    0x658(%rsp),%rdx
  6fdb31:	00 
  6fdb32:	ff 15 48 dd 38 00    	call   *0x38dd48(%rip)        # a8b880 <_DYNAMIC+0x368>
  6fdb38:	e9 de 01 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdb3d:	48 8b 84 24 98 02 00 	mov    0x298(%rsp),%rax
  6fdb44:	00 
  6fdb45:	48 89 84 24 e0 03 00 	mov    %rax,0x3e0(%rsp)
  6fdb4c:	00 
  6fdb4d:	48 8d 05 1c 56 36 00 	lea    0x36561c(%rip),%rax        # a63170 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xcb0>
  6fdb54:	e9 ac 00 00 00       	jmp    6fdc05 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6bc5>
  6fdb59:	49 89 cd             	mov    %rcx,%r13
  6fdb5c:	48 89 84 24 e0 03 00 	mov    %rax,0x3e0(%rsp)
  6fdb63:	00 
  6fdb64:	48 8d 05 4d 4e 36 00 	lea    0x364e4d(%rip),%rax        # a629b8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x4f8>
  6fdb6b:	e9 95 00 00 00       	jmp    6fdc05 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6bc5>
  6fdb70:	48 8d 15 41 56 36 00 	lea    0x365641(%rip),%rdx        # a631b8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xcf8>
  6fdb77:	4c 89 f7             	mov    %r14,%rdi
  6fdb7a:	ff 15 00 dd 38 00    	call   *0x38dd00(%rip)        # a8b880 <_DYNAMIC+0x368>
  6fdb80:	e9 96 01 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdb85:	48 8d 15 ac 4c 36 00 	lea    0x364cac(%rip),%rdx        # a62838 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x378>
  6fdb8c:	ff 15 ee dc 38 00    	call   *0x38dcee(%rip)        # a8b880 <_DYNAMIC+0x368>
  6fdb92:	e9 84 01 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdb97:	48 8d 15 2a 55 36 00 	lea    0x36552a(%rip),%rdx        # a630c8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xc08>
  6fdb9e:	ff 15 dc dc 38 00    	call   *0x38dcdc(%rip)        # a8b880 <_DYNAMIC+0x368>
  6fdba4:	e9 72 01 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdba9:	40 b5 01             	mov    $0x1,%bpl
  6fdbac:	48 8d 15 ad 4e 36 00 	lea    0x364ead(%rip),%rdx        # a62a60 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x5a0>
  6fdbb3:	41 b5 01             	mov    $0x1,%r13b
  6fdbb6:	4c 89 f7             	mov    %r14,%rdi
  6fdbb9:	ff 15 c1 dc 38 00    	call   *0x38dcc1(%rip)        # a8b880 <_DYNAMIC+0x368>
  6fdbbf:	e9 57 01 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdbc4:	48 8d 15 2d 55 36 00 	lea    0x36552d(%rip),%rdx        # a630f8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xc38>
  6fdbcb:	be 02 00 00 00       	mov    $0x2,%esi
  6fdbd0:	4c 89 e7             	mov    %r12,%rdi
  6fdbd3:	ff 15 a7 dc 38 00    	call   *0x38dca7(%rip)        # a8b880 <_DYNAMIC+0x368>
  6fdbd9:	e9 3d 01 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdbde:	bf 08 00 00 00       	mov    $0x8,%edi
  6fdbe3:	48 89 de             	mov    %rbx,%rsi
  6fdbe6:	ff 15 44 dc 38 00    	call   *0x38dc44(%rip)        # a8b830 <_DYNAMIC+0x318>
  6fdbec:	e9 2a 01 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdbf1:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fdbf6:	48 89 84 24 e0 03 00 	mov    %rax,0x3e0(%rsp)
  6fdbfd:	00 
  6fdbfe:	48 8d 05 e3 4d 36 00 	lea    0x364de3(%rip),%rax        # a629e8 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x528>
  6fdc05:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
  6fdc0c:	00 
  6fdc0d:	4c 89 ef             	mov    %r13,%rdi
  6fdc10:	48 8b b4 24 e0 03 00 	mov    0x3e0(%rsp),%rsi
  6fdc17:	00 
  6fdc18:	48 8b 94 24 d8 03 00 	mov    0x3d8(%rsp),%rdx
  6fdc1f:	00 
  6fdc20:	ff 15 5a dc 38 00    	call   *0x38dc5a(%rip)        # a8b880 <_DYNAMIC+0x368>
  6fdc26:	e9 f0 00 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdc2b:	bf 08 00 00 00       	mov    $0x8,%edi
  6fdc30:	48 89 de             	mov    %rbx,%rsi
  6fdc33:	ff 15 f7 db 38 00    	call   *0x38dbf7(%rip)        # a8b830 <_DYNAMIC+0x318>
  6fdc39:	e9 dd 00 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdc3e:	bf 08 00 00 00       	mov    $0x8,%edi
  6fdc43:	48 89 de             	mov    %rbx,%rsi
  6fdc46:	ff 15 e4 db 38 00    	call   *0x38dbe4(%rip)        # a8b830 <_DYNAMIC+0x318>
  6fdc4c:	e9 ca 00 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdc51:	48 85 ff             	test   %rdi,%rdi
  6fdc54:	75 56                	jne    6fdcac <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c6c>
  6fdc56:	40 b5 01             	mov    $0x1,%bpl
  6fdc59:	41 b5 01             	mov    $0x1,%r13b
  6fdc5c:	ff 15 0e dd 38 00    	call   *0x38dd0e(%rip)        # a8b970 <_DYNAMIC+0x458>
  6fdc62:	e9 b4 00 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdc67:	bf 04 00 00 00       	mov    $0x4,%edi
  6fdc6c:	48 89 de             	mov    %rbx,%rsi
  6fdc6f:	ff 15 bb db 38 00    	call   *0x38dbbb(%rip)        # a8b830 <_DYNAMIC+0x318>
  6fdc75:	e9 a1 00 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdc7a:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
  6fdc7f:	4c 89 f7             	mov    %r14,%rdi
  6fdc82:	48 8b 94 24 d0 03 00 	mov    0x3d0(%rsp),%rdx
  6fdc89:	00 
  6fdc8a:	ff 15 f0 db 38 00    	call   *0x38dbf0(%rip)        # a8b880 <_DYNAMIC+0x368>
  6fdc90:	e9 86 00 00 00       	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdc95:	31 ed                	xor    %ebp,%ebp
  6fdc97:	48 8d 15 12 54 36 00 	lea    0x365412(%rip),%rdx        # a630b0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xbf0>
  6fdc9e:	48 89 c7             	mov    %rax,%rdi
  6fdca1:	4c 89 f6             	mov    %r14,%rsi
  6fdca4:	ff 15 d6 db 38 00    	call   *0x38dbd6(%rip)        # a8b880 <_DYNAMIC+0x368>
  6fdcaa:	eb 6f                	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdcac:	48 8b b4 24 98 01 00 	mov    0x198(%rsp),%rsi
  6fdcb3:	00 
  6fdcb4:	40 b5 01             	mov    $0x1,%bpl
  6fdcb7:	41 b5 01             	mov    $0x1,%r13b
  6fdcba:	ff 15 c0 da 38 00    	call   *0x38dac0(%rip)        # a8b780 <_DYNAMIC+0x268>
  6fdcc0:	eb 59                	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdcc2:	49 89 c5             	mov    %rax,%r13
  6fdcc5:	48 8b 84 24 e8 03 00 	mov    0x3e8(%rsp),%rax
  6fdccc:	00 
  6fdccd:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6fdcd2:	48 8d 05 27 4d 36 00 	lea    0x364d27(%rip),%rax        # a62a00 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x540>
  6fdcd9:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
  6fdce0:	00 
  6fdce1:	4c 89 ef             	mov    %r13,%rdi
  6fdce4:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  6fdce9:	48 8b 94 24 50 06 00 	mov    0x650(%rsp),%rdx
  6fdcf0:	00 
  6fdcf1:	ff 15 89 db 38 00    	call   *0x38db89(%rip)        # a8b880 <_DYNAMIC+0x368>
  6fdcf7:	eb 22                	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdcf9:	89 6c 24 30          	mov    %ebp,0x30(%rsp)
  6fdcfd:	bf 08 00 00 00       	mov    $0x8,%edi
  6fdd02:	48 89 de             	mov    %rbx,%rsi
  6fdd05:	ff 15 25 db 38 00    	call   *0x38db25(%rip)        # a8b830 <_DYNAMIC+0x318>
  6fdd0b:	eb 0e                	jmp    6fdd1b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6cdb>
  6fdd0d:	bf 08 00 00 00       	mov    $0x8,%edi
  6fdd12:	4c 89 f6             	mov    %r14,%rsi
  6fdd15:	ff 15 15 db 38 00    	call   *0x38db15(%rip)        # a8b830 <_DYNAMIC+0x318>
  6fdd1b:	0f 0b                	ud2
  6fdd1d:	48 8d 94 24 80 00 00 	lea    0x80(%rsp),%rdx
  6fdd24:	00 
  6fdd25:	8b 6c 24 30          	mov    0x30(%rsp),%ebp
  6fdd29:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  6fdd2e:	e8 dd 4a 01 00       	call   712810 <core::slice::sort::unstable::ipnsort::<(u64, gpui::property::GeometryStyle), <[(u64, gpui::property::GeometryStyle)]>::sort_unstable_by_key<u64, <gpui::runtime::Runtime<route_columns_cost::Page>>::reconcile_geometry::{closure#2}>::{closure#0}>>
  6fdd33:	4c 8b ac 24 80 01 00 	mov    0x180(%rsp),%r13
  6fdd3a:	00 
  6fdd3b:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
  6fdd40:	e9 29 ed ff ff       	jmp    6fca6e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x5a2e>
  6fdd45:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
  6fdd4a:	4d 89 ee             	mov    %r13,%r14
  6fdd4d:	48 8d 05 1c 4e 36 00 	lea    0x364e1c(%rip),%rax        # a62b70 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x6b0>
  6fdd54:	48 89 84 24 d0 03 00 	mov    %rax,0x3d0(%rsp)
  6fdd5b:	00 
  6fdd5c:	e9 1e ff ff ff       	jmp    6fdc7f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c3f>
  6fdd61:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
  6fdd66:	4d 89 ee             	mov    %r13,%r14
  6fdd69:	48 8d 05 18 4e 36 00 	lea    0x364e18(%rip),%rax        # a62b88 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x6c8>
  6fdd70:	48 89 84 24 d0 03 00 	mov    %rax,0x3d0(%rsp)
  6fdd77:	00 
  6fdd78:	e9 02 ff ff ff       	jmp    6fdc7f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c3f>
  6fdd7d:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
  6fdd82:	49 89 c6             	mov    %rax,%r14
  6fdd85:	48 8d 05 14 4e 36 00 	lea    0x364e14(%rip),%rax        # a62ba0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x6e0>
  6fdd8c:	48 89 84 24 d0 03 00 	mov    %rax,0x3d0(%rsp)
  6fdd93:	00 
  6fdd94:	e9 e6 fe ff ff       	jmp    6fdc7f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6c3f>
  6fdd99:	e9 49 08 00 00       	jmp    6fe5e7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x75a7>
  6fdd9e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdda3:	48 8d bc 24 50 04 00 	lea    0x450(%rsp),%rdi
  6fddaa:	00 
  6fddab:	e8 a0 48 fe ff       	call   6e2650 <core::ptr::drop_glue::<core::option::Option<gpui::runtime::Shaped>>>
  6fddb0:	e9 51 05 00 00       	jmp    6fe306 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x72c6>
  6fddb5:	ff 15 e5 d9 38 00    	call   *0x38d9e5(%rip)        # a8b7a0 <_DYNAMIC+0x288>
  6fddbb:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fddc0:	4e 89 b4 e4 f0 04 00 	mov    %r14,0x4f0(%rsp,%r12,8)
  6fddc7:	00 
  6fddc8:	e9 5f 07 00 00       	jmp    6fe52c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x74ec>
  6fddcd:	89 6c 24 30          	mov    %ebp,0x30(%rsp)
  6fddd1:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fddd6:	49 8b 74 24 18       	mov    0x18(%r12),%rsi
  6fdddb:	48 85 f6             	test   %rsi,%rsi
  6fddde:	74 18                	je     6fddf8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6db8>
  6fdde0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fdde5:	48 8b 78 20          	mov    0x20(%rax),%rdi
  6fdde9:	48 c1 e6 04          	shl    $0x4,%rsi
  6fdded:	ba 04 00 00 00       	mov    $0x4,%edx
  6fddf2:	ff 15 70 d9 38 00    	call   *0x38d970(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fddf8:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fddfd:	48 8b 70 30          	mov    0x30(%rax),%rsi
  6fde01:	48 85 f6             	test   %rsi,%rsi
  6fde04:	7e 18                	jle    6fde1e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6dde>
  6fde06:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fde0b:	48 8b 78 38          	mov    0x38(%rax),%rdi
  6fde0f:	48 c1 e6 04          	shl    $0x4,%rsi
  6fde13:	ba 04 00 00 00       	mov    $0x4,%edx
  6fde18:	ff 15 4a d9 38 00    	call   *0x38d94a(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fde1e:	be 60 00 00 00       	mov    $0x60,%esi
  6fde23:	ba 08 00 00 00       	mov    $0x8,%edx
  6fde28:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  6fde2d:	ff 15 35 d9 38 00    	call   *0x38d935(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fde33:	40 b5 01             	mov    $0x1,%bpl
  6fde36:	e9 b7 0b 00 00       	jmp    6fe9f2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x79b2>
  6fde3b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fde40:	48 8b 03             	mov    (%rbx),%rax
  6fde43:	48 c7 80 00 01 00 00 	movq   $0x0,0x100(%rax)
  6fde4a:	00 00 00 00 
  6fde4e:	e9 47 06 00 00       	jmp    6fe49a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x745a>
  6fde53:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fde58:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
  6fde5d:	49 8b 74 24 08       	mov    0x8(%r12),%rsi
  6fde62:	b3 01                	mov    $0x1,%bl
  6fde64:	48 85 f6             	test   %rsi,%rsi
  6fde67:	74 14                	je     6fde7d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6e3d>
  6fde69:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6fde6e:	48 8b 50 10          	mov    0x10(%rax),%rdx
  6fde72:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  6fde77:	ff 15 eb d8 38 00    	call   *0x38d8eb(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fde7d:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  6fde84:	00 00 
  6fde86:	e9 67 0c 00 00       	jmp    6feaf2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ab2>
  6fde8b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fde90:	41 b7 01             	mov    $0x1,%r15b
  6fde93:	b0 01                	mov    $0x1,%al
  6fde95:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fde99:	b0 01                	mov    $0x1,%al
  6fde9b:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fde9f:	41 b6 01             	mov    $0x1,%r14b
  6fdea2:	40 b5 01             	mov    $0x1,%bpl
  6fdea5:	41 b4 01             	mov    $0x1,%r12b
  6fdea8:	b0 01                	mov    $0x1,%al
  6fdeaa:	89 44 24 30          	mov    %eax,0x30(%rsp)
  6fdeae:	e9 f7 0c 00 00       	jmp    6febaa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b6a>
  6fdeb3:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdeb8:	b3 01                	mov    $0x1,%bl
  6fdeba:	e9 87 07 00 00       	jmp    6fe646 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7606>
  6fdebf:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdec4:	48 8b bc 24 00 02 00 	mov    0x200(%rsp),%rdi
  6fdecb:	00 
  6fdecc:	e8 bf 71 fe ff       	call   6e5090 <core::ptr::drop_glue::<gpui::shared_text::SharedText>>
  6fded1:	e9 89 04 00 00       	jmp    6fe35f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x731f>
  6fded6:	ff 15 c4 d8 38 00    	call   *0x38d8c4(%rip)        # a8b7a0 <_DYNAMIC+0x288>
  6fdedc:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdee1:	48 8b 03             	mov    (%rbx),%rax
  6fdee4:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  6fdeeb:	00 
  6fdeec:	48 89 88 d0 00 00 00 	mov    %rcx,0xd0(%rax)
  6fdef3:	66 0f 6f 84 24 80 00 	movdqa 0x80(%rsp),%xmm0
  6fdefa:	00 00 
  6fdefc:	f3 0f 7f 80 c0 00 00 	movdqu %xmm0,0xc0(%rax)
  6fdf03:	00 
  6fdf04:	e9 b6 06 00 00       	jmp    6fe5bf <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x757f>
  6fdf09:	89 6c 24 30          	mov    %ebp,0x30(%rsp)
  6fdf0d:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdf12:	4c 89 a3 00 01 00 00 	mov    %r12,0x100(%rbx)
  6fdf19:	31 db                	xor    %ebx,%ebx
  6fdf1b:	e9 ce 06 00 00       	jmp    6fe5ee <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x75ae>
  6fdf20:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdf25:	4c 89 f7             	mov    %r14,%rdi
  6fdf28:	48 89 de             	mov    %rbx,%rsi
  6fdf2b:	e8 40 87 fe ff       	call   6e6670 <core::ptr::drop_glue::<gpui::runtime::metadata::Names>>
  6fdf30:	e9 70 06 00 00       	jmp    6fe5a5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7565>
  6fdf35:	ff 15 65 d8 38 00    	call   *0x38d865(%rip)        # a8b7a0 <_DYNAMIC+0x288>
  6fdf3b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdf40:	45 31 ed             	xor    %r13d,%r13d
  6fdf43:	31 db                	xor    %ebx,%ebx
  6fdf45:	31 ed                	xor    %ebp,%ebp
  6fdf47:	45 31 f6             	xor    %r14d,%r14d
  6fdf4a:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fdf51:	00 
  6fdf52:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fdf59:	00 
  6fdf5a:	45 31 ff             	xor    %r15d,%r15d
  6fdf5d:	e9 ea 0d 00 00       	jmp    6fed4c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d0c>
  6fdf62:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdf67:	45 31 ed             	xor    %r13d,%r13d
  6fdf6a:	31 db                	xor    %ebx,%ebx
  6fdf6c:	31 ed                	xor    %ebp,%ebp
  6fdf6e:	45 31 f6             	xor    %r14d,%r14d
  6fdf71:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fdf78:	00 
  6fdf79:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fdf80:	00 
  6fdf81:	45 31 ff             	xor    %r15d,%r15d
  6fdf84:	e9 85 0d 00 00       	jmp    6fed0e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7cce>
  6fdf89:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdf8e:	45 31 ed             	xor    %r13d,%r13d
  6fdf91:	31 db                	xor    %ebx,%ebx
  6fdf93:	31 ed                	xor    %ebp,%ebp
  6fdf95:	45 31 f6             	xor    %r14d,%r14d
  6fdf98:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fdf9f:	00 
  6fdfa0:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fdfa7:	00 
  6fdfa8:	45 31 ff             	xor    %r15d,%r15d
  6fdfab:	e9 24 0d 00 00       	jmp    6fecd4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c94>
  6fdfb0:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdfb5:	45 31 ed             	xor    %r13d,%r13d
  6fdfb8:	31 db                	xor    %ebx,%ebx
  6fdfba:	31 ed                	xor    %ebp,%ebp
  6fdfbc:	45 31 f6             	xor    %r14d,%r14d
  6fdfbf:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fdfc6:	00 
  6fdfc7:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fdfce:	00 
  6fdfcf:	45 31 ff             	xor    %r15d,%r15d
  6fdfd2:	e9 f0 0c 00 00       	jmp    6fecc7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c87>
  6fdfd7:	e9 9f 04 00 00       	jmp    6fe47b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x743b>
  6fdfdc:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fdfe1:	48 8b 03             	mov    (%rbx),%rax
  6fdfe4:	48 85 c0             	test   %rax,%rax
  6fdfe7:	74 1f                	je     6fe008 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x6fc8>
  6fdfe9:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6fdfee:	48 8b b9 b0 02 00 00 	mov    0x2b0(%rcx),%rdi
  6fdff5:	48 c1 e0 04          	shl    $0x4,%rax
  6fdff9:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
  6fdffd:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe002:	ff 15 60 d7 38 00    	call   *0x38d760(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe008:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6fe00f:	00 
  6fe010:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fe014:	66 0f 6f 84 24 80 00 	movdqa 0x80(%rsp),%xmm0
  6fe01b:	00 00 
  6fe01d:	f3 0f 7f 03          	movdqu %xmm0,(%rbx)
  6fe021:	b3 01                	mov    $0x1,%bl
  6fe023:	e9 74 04 00 00       	jmp    6fe49c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x745c>
  6fe028:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe02d:	4d 89 b7 b0 05 00 00 	mov    %r14,0x5b0(%r15)
  6fe034:	49 89 9f b8 05 00 00 	mov    %rbx,0x5b8(%r15)
  6fe03b:	31 db                	xor    %ebx,%ebx
  6fe03d:	eb 20                	jmp    6fe05f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x701f>
  6fe03f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe044:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6fe04b:	00 
  6fe04c:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fe050:	66 0f 6f 84 24 80 00 	movdqa 0x80(%rsp),%xmm0
  6fe057:	00 00 
  6fe059:	f3 0f 7f 03          	movdqu %xmm0,(%rbx)
  6fe05d:	b3 01                	mov    $0x1,%bl
  6fe05f:	31 ed                	xor    %ebp,%ebp
  6fe061:	45 31 f6             	xor    %r14d,%r14d
  6fe064:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fe06b:	00 
  6fe06c:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fe073:	00 
  6fe074:	e9 fb 0a 00 00       	jmp    6feb74 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b34>
  6fe079:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe07e:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6fe085:	00 
  6fe086:	48 89 43 10          	mov    %rax,0x10(%rbx)
  6fe08a:	66 0f 28 84 24 80 00 	movapd 0x80(%rsp),%xmm0
  6fe091:	00 00 
  6fe093:	66 0f 11 03          	movupd %xmm0,(%rbx)
  6fe097:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fe09e:	00 
  6fe09f:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fe0a6:	00 
  6fe0a7:	31 ed                	xor    %ebp,%ebp
  6fe0a9:	e9 54 09 00 00       	jmp    6fea02 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x79c2>
  6fe0ae:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe0b3:	e9 fa 04 00 00       	jmp    6fe5b2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7572>
  6fe0b8:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe0bd:	41 b7 01             	mov    $0x1,%r15b
  6fe0c0:	b0 01                	mov    $0x1,%al
  6fe0c2:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe0c6:	b0 01                	mov    $0x1,%al
  6fe0c8:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe0cc:	41 b6 01             	mov    $0x1,%r14b
  6fe0cf:	40 b5 01             	mov    $0x1,%bpl
  6fe0d2:	41 b4 01             	mov    $0x1,%r12b
  6fe0d5:	b3 01                	mov    $0x1,%bl
  6fe0d7:	b0 01                	mov    $0x1,%al
  6fe0d9:	89 44 24 30          	mov    %eax,0x30(%rsp)
  6fe0dd:	e9 b3 0a 00 00       	jmp    6feb95 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b55>
  6fe0e2:	e9 04 0a 00 00       	jmp    6feaeb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7aab>
  6fe0e7:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe0ec:	41 b7 01             	mov    $0x1,%r15b
  6fe0ef:	b0 01                	mov    $0x1,%al
  6fe0f1:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe0f5:	b0 01                	mov    $0x1,%al
  6fe0f7:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe0fb:	41 b6 01             	mov    $0x1,%r14b
  6fe0fe:	40 b5 01             	mov    $0x1,%bpl
  6fe101:	b0 01                	mov    $0x1,%al
  6fe103:	89 44 24 30          	mov    %eax,0x30(%rsp)
  6fe107:	e9 6e 0b 00 00       	jmp    6fec7a <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c3a>
  6fe10c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe111:	41 b7 01             	mov    $0x1,%r15b
  6fe114:	e9 6d 06 00 00       	jmp    6fe786 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7746>
  6fe119:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe11e:	ba 04 00 00 00       	mov    $0x4,%edx
  6fe123:	48 8b bc 24 08 02 00 	mov    0x208(%rsp),%rdi
  6fe12a:	00 
  6fe12b:	48 8b b4 24 80 02 00 	mov    0x280(%rsp),%rsi
  6fe132:	00 
  6fe133:	ff 15 2f d6 38 00    	call   *0x38d62f(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe139:	45 31 ff             	xor    %r15d,%r15d
  6fe13c:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fe143:	00 
  6fe144:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fe14b:	00 
  6fe14c:	45 31 f6             	xor    %r14d,%r14d
  6fe14f:	31 ed                	xor    %ebp,%ebp
  6fe151:	31 db                	xor    %ebx,%ebx
  6fe153:	e9 3d 0a 00 00       	jmp    6feb95 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b55>
  6fe158:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe15d:	b0 01                	mov    $0x1,%al
  6fe15f:	89 44 24 30          	mov    %eax,0x30(%rsp)
  6fe163:	b3 01                	mov    $0x1,%bl
  6fe165:	40 b5 01             	mov    $0x1,%bpl
  6fe168:	41 b6 01             	mov    $0x1,%r14b
  6fe16b:	b0 01                	mov    $0x1,%al
  6fe16d:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe171:	b0 01                	mov    $0x1,%al
  6fe173:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe177:	41 b7 01             	mov    $0x1,%r15b
  6fe17a:	e9 0a 0b 00 00       	jmp    6fec89 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c49>
  6fe17f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe184:	b0 01                	mov    $0x1,%al
  6fe186:	89 44 24 30          	mov    %eax,0x30(%rsp)
  6fe18a:	41 b5 01             	mov    $0x1,%r13b
  6fe18d:	b3 01                	mov    $0x1,%bl
  6fe18f:	40 b5 01             	mov    $0x1,%bpl
  6fe192:	41 b6 01             	mov    $0x1,%r14b
  6fe195:	b0 01                	mov    $0x1,%al
  6fe197:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe19b:	b0 01                	mov    $0x1,%al
  6fe19d:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe1a1:	41 b7 01             	mov    $0x1,%r15b
  6fe1a4:	e9 89 0b 00 00       	jmp    6fed32 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7cf2>
  6fe1a9:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe1ae:	4c 89 f7             	mov    %r14,%rdi
  6fe1b1:	e8 0a 44 fe ff       	call   6e25c0 <core::ptr::drop_glue::<core::option::Option<gpui::shared_text::SharedText>>>
  6fe1b6:	e9 71 03 00 00       	jmp    6fe52c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x74ec>
  6fe1bb:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe1c0:	48 8d bc 24 90 01 00 	lea    0x190(%rsp),%rdi
  6fe1c7:	00 
  6fe1c8:	e8 f3 45 fe ff       	call   6e27c0 <core::ptr::drop_glue::<core::option::Option<gpui::runtime::TextSite>>>
  6fe1cd:	e9 70 01 00 00       	jmp    6fe342 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7302>
  6fe1d2:	ff 15 c8 d5 38 00    	call   *0x38d5c8(%rip)        # a8b7a0 <_DYNAMIC+0x288>
  6fe1d8:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe1dd:	4c 89 ef             	mov    %r13,%rdi
  6fe1e0:	48 89 ee             	mov    %rbp,%rsi
  6fe1e3:	e8 08 44 fe ff       	call   6e25f0 <core::ptr::drop_glue::<core::option::Option<gpui::element::Handler>>>
  6fe1e8:	40 b5 01             	mov    $0x1,%bpl
  6fe1eb:	e9 54 01 00 00       	jmp    6fe344 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7304>
  6fe1f0:	ff 15 aa d5 38 00    	call   *0x38d5aa(%rip)        # a8b7a0 <_DYNAMIC+0x288>
  6fe1f6:	44 89 64 24 30       	mov    %r12d,0x30(%rsp)
  6fe1fb:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe200:	44 89 eb             	mov    %r13d,%ebx
  6fe203:	44 89 ed             	mov    %r13d,%ebp
  6fe206:	45 89 ee             	mov    %r13d,%r14d
  6fe209:	44 89 e8             	mov    %r13d,%eax
  6fe20c:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe210:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe214:	45 89 ef             	mov    %r13d,%r15d
  6fe217:	e9 9e 0a 00 00       	jmp    6fecba <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c7a>
  6fe21c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe221:	4c 89 f7             	mov    %r14,%rdi
  6fe224:	e8 67 6e fe ff       	call   6e5090 <core::ptr::drop_glue::<gpui::shared_text::SharedText>>
  6fe229:	e9 fe 02 00 00       	jmp    6fe52c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x74ec>
  6fe22e:	eb 00                	jmp    6fe230 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x71f0>
  6fe230:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe235:	49 83 fc ff          	cmp    $0xffffffffffffffff,%r12
  6fe239:	74 16                	je     6fe251 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7211>
  6fe23b:	4d 85 e4             	test   %r12,%r12
  6fe23e:	7e 11                	jle    6fe251 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7211>
  6fe240:	ba 01 00 00 00       	mov    $0x1,%edx
  6fe245:	4c 89 ff             	mov    %r15,%rdi
  6fe248:	4c 89 e6             	mov    %r12,%rsi
  6fe24b:	ff 15 17 d5 38 00    	call   *0x38d517(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe251:	48 83 fb ff          	cmp    $0xffffffffffffffff,%rbx
  6fe255:	0f 84 4a 03 00 00    	je     6fe5a5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7565>
  6fe25b:	48 85 db             	test   %rbx,%rbx
  6fe25e:	0f 8e 41 03 00 00    	jle    6fe5a5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7565>
  6fe264:	ba 01 00 00 00       	mov    $0x1,%edx
  6fe269:	4c 89 f7             	mov    %r14,%rdi
  6fe26c:	48 89 de             	mov    %rbx,%rsi
  6fe26f:	ff 15 f3 d4 38 00    	call   *0x38d4f3(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe275:	e9 2b 03 00 00       	jmp    6fe5a5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7565>
  6fe27a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe27f:	b0 01                	mov    $0x1,%al
  6fe281:	89 44 24 30          	mov    %eax,0x30(%rsp)
  6fe285:	41 b6 01             	mov    $0x1,%r14b
  6fe288:	b0 01                	mov    $0x1,%al
  6fe28a:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe28e:	b0 01                	mov    $0x1,%al
  6fe290:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe294:	e9 db 08 00 00       	jmp    6feb74 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b34>
  6fe299:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe29e:	48 8b 73 08          	mov    0x8(%rbx),%rsi
  6fe2a2:	48 85 f6             	test   %rsi,%rsi
  6fe2a5:	74 14                	je     6fe2bb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x727b>
  6fe2a7:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6fe2ac:	48 8b 50 10          	mov    0x10(%rax),%rdx
  6fe2b0:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  6fe2b5:	ff 15 ad d4 38 00    	call   *0x38d4ad(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe2bb:	40 b5 01             	mov    $0x1,%bpl
  6fe2be:	45 31 ed             	xor    %r13d,%r13d
  6fe2c1:	b3 01                	mov    $0x1,%bl
  6fe2c3:	e9 71 07 00 00       	jmp    6fea39 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x79f9>
  6fe2c8:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe2cd:	ba 04 00 00 00       	mov    $0x4,%edx
  6fe2d2:	48 8b bc 24 08 02 00 	mov    0x208(%rsp),%rdi
  6fe2d9:	00 
  6fe2da:	48 8b b4 24 80 02 00 	mov    0x280(%rsp),%rsi
  6fe2e1:	00 
  6fe2e2:	ff 15 80 d4 38 00    	call   *0x38d480(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe2e8:	31 db                	xor    %ebx,%ebx
  6fe2ea:	e9 c8 01 00 00       	jmp    6fe4b7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7477>
  6fe2ef:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe2f4:	4c 89 b4 24 78 03 00 	mov    %r14,0x378(%rsp)
  6fe2fb:	00 
  6fe2fc:	e9 ca 05 00 00       	jmp    6fe8cb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x788b>
  6fe301:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe306:	48 89 9c 24 50 04 00 	mov    %rbx,0x450(%rsp)
  6fe30d:	00 
  6fe30e:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
  6fe315:	00 
  6fe316:	48 89 84 24 90 04 00 	mov    %rax,0x490(%rsp)
  6fe31d:	00 
  6fe31e:	48 8b 84 24 68 06 00 	mov    0x668(%rsp),%rax
  6fe325:	00 
  6fe326:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
  6fe32d:	00 
  6fe32e:	eb 2f                	jmp    6fe35f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x731f>
  6fe330:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe335:	48 8d bc 24 70 03 00 	lea    0x370(%rsp),%rdi
  6fe33c:	00 
  6fe33d:	e8 fe 6e fe ff       	call   6e5240 <core::ptr::drop_glue::<gpui::runtime::TextSite>>
  6fe342:	31 ed                	xor    %ebp,%ebp
  6fe344:	45 31 ed             	xor    %r13d,%r13d
  6fe347:	31 db                	xor    %ebx,%ebx
  6fe349:	e9 eb 06 00 00       	jmp    6fea39 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x79f9>
  6fe34e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe353:	48 c7 84 24 50 04 00 	movq   $0xffffffffffffffff,0x450(%rsp)
  6fe35a:	00 ff ff ff ff 
  6fe35f:	40 b5 01             	mov    $0x1,%bpl
  6fe362:	41 b5 01             	mov    $0x1,%r13b
  6fe365:	b3 01                	mov    $0x1,%bl
  6fe367:	e9 cd 06 00 00       	jmp    6fea39 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x79f9>
  6fe36c:	e9 49 07 00 00       	jmp    6feaba <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a7a>
  6fe371:	e9 d6 03 00 00       	jmp    6fe74c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x770c>
  6fe376:	e9 59 01 00 00       	jmp    6fe4d4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7494>
  6fe37b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe380:	41 b4 01             	mov    $0x1,%r12b
  6fe383:	b0 01                	mov    $0x1,%al
  6fe385:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fe389:	40 b5 01             	mov    $0x1,%bpl
  6fe38c:	41 b6 01             	mov    $0x1,%r14b
  6fe38f:	b0 01                	mov    $0x1,%al
  6fe391:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe395:	b0 01                	mov    $0x1,%al
  6fe397:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe39b:	41 b7 01             	mov    $0x1,%r15b
  6fe39e:	e9 46 0a 00 00       	jmp    6fede9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7da9>
  6fe3a3:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe3a8:	41 b4 01             	mov    $0x1,%r12b
  6fe3ab:	b0 01                	mov    $0x1,%al
  6fe3ad:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fe3b1:	40 b5 01             	mov    $0x1,%bpl
  6fe3b4:	41 b6 01             	mov    $0x1,%r14b
  6fe3b7:	b0 01                	mov    $0x1,%al
  6fe3b9:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe3bd:	b0 01                	mov    $0x1,%al
  6fe3bf:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe3c3:	41 b7 01             	mov    $0x1,%r15b
  6fe3c6:	e9 42 0a 00 00       	jmp    6fee0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7dcd>
  6fe3cb:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe3d0:	41 b4 01             	mov    $0x1,%r12b
  6fe3d3:	b0 01                	mov    $0x1,%al
  6fe3d5:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fe3d9:	40 b5 01             	mov    $0x1,%bpl
  6fe3dc:	41 b6 01             	mov    $0x1,%r14b
  6fe3df:	b0 01                	mov    $0x1,%al
  6fe3e1:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe3e5:	b0 01                	mov    $0x1,%al
  6fe3e7:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe3eb:	41 b7 01             	mov    $0x1,%r15b
  6fe3ee:	e9 3e 0a 00 00       	jmp    6fee31 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7df1>
  6fe3f3:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe3f8:	e9 50 07 00 00       	jmp    6feb4d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b0d>
  6fe3fd:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe402:	e9 c4 04 00 00       	jmp    6fe8cb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x788b>
  6fe407:	e9 1b 01 00 00       	jmp    6fe527 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x74e7>
  6fe40c:	e9 16 01 00 00       	jmp    6fe527 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x74e7>
  6fe411:	e9 6a 05 00 00       	jmp    6fe980 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7940>
  6fe416:	44 89 6c 24 18       	mov    %r13d,0x18(%rsp)
  6fe41b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe420:	41 89 ee             	mov    %ebp,%r14d
  6fe423:	89 e8                	mov    %ebp,%eax
  6fe425:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe429:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe42d:	41 89 ef             	mov    %ebp,%r15d
  6fe430:	e9 09 0a 00 00       	jmp    6fee3e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7dfe>
  6fe435:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe43a:	41 b4 01             	mov    $0x1,%r12b
  6fe43d:	b0 01                	mov    $0x1,%al
  6fe43f:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fe443:	40 b5 01             	mov    $0x1,%bpl
  6fe446:	41 b6 01             	mov    $0x1,%r14b
  6fe449:	b0 01                	mov    $0x1,%al
  6fe44b:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe44f:	b0 01                	mov    $0x1,%al
  6fe451:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe455:	41 b7 01             	mov    $0x1,%r15b
  6fe458:	e9 68 09 00 00       	jmp    6fedc5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d85>
  6fe45d:	e9 a6 00 00 00       	jmp    6fe508 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x74c8>
  6fe462:	e9 a1 00 00 00       	jmp    6fe508 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x74c8>
  6fe467:	e9 b7 02 00 00       	jmp    6fe723 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x76e3>
  6fe46c:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
  6fe471:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
  6fe476:	e9 70 06 00 00       	jmp    6feaeb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7aab>
  6fe47b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe480:	48 8b 84 24 a0 01 00 	mov    0x1a0(%rsp),%rax
  6fe487:	00 
  6fe488:	49 89 47 10          	mov    %rax,0x10(%r15)
  6fe48c:	66 0f 6f 84 24 90 01 	movdqa 0x190(%rsp),%xmm0
  6fe493:	00 00 
  6fe495:	f3 41 0f 7f 07       	movdqu %xmm0,(%r15)
  6fe49a:	31 db                	xor    %ebx,%ebx
  6fe49c:	ba 04 00 00 00       	mov    $0x4,%edx
  6fe4a1:	48 8b bc 24 08 02 00 	mov    0x208(%rsp),%rdi
  6fe4a8:	00 
  6fe4a9:	48 8b b4 24 80 02 00 	mov    0x280(%rsp),%rsi
  6fe4b0:	00 
  6fe4b1:	ff 15 b1 d2 38 00    	call   *0x38d2b1(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe4b7:	31 ed                	xor    %ebp,%ebp
  6fe4b9:	45 31 f6             	xor    %r14d,%r14d
  6fe4bc:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fe4c3:	00 
  6fe4c4:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fe4cb:	00 
  6fe4cc:	45 31 ff             	xor    %r15d,%r15d
  6fe4cf:	e9 b5 07 00 00       	jmp    6fec89 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c49>
  6fe4d4:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe4d9:	48 83 7c 24 18 00    	cmpq   $0x0,0x18(%rsp)
  6fe4df:	0f 84 c2 04 00 00    	je     6fe9a7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7967>
  6fe4e5:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  6fe4ea:	48 c1 e6 04          	shl    $0x4,%rsi
  6fe4ee:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe4f3:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6fe4f8:	ff 15 6a d2 38 00    	call   *0x38d26a(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe4fe:	e9 a4 04 00 00       	jmp    6fe9a7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7967>
  6fe503:	e9 b2 05 00 00       	jmp    6feaba <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a7a>
  6fe508:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe50d:	b3 01                	mov    $0x1,%bl
  6fe50f:	e9 ed 05 00 00       	jmp    6feb01 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ac1>
  6fe514:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe519:	41 b4 01             	mov    $0x1,%r12b
  6fe51c:	b0 01                	mov    $0x1,%al
  6fe51e:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fe522:	e9 09 03 00 00       	jmp    6fe830 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x77f0>
  6fe527:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe52c:	48 8b b4 24 50 04 00 	mov    0x450(%rsp),%rsi
  6fe533:	00 
  6fe534:	48 85 f6             	test   %rsi,%rsi
  6fe537:	7e 1a                	jle    6fe553 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7513>
  6fe539:	48 8b bc 24 58 04 00 	mov    0x458(%rsp),%rdi
  6fe540:	00 
  6fe541:	ba 01 00 00 00       	mov    $0x1,%edx
  6fe546:	ff 15 1c d2 38 00    	call   *0x38d21c(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe54c:	eb 05                	jmp    6fe553 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7513>
  6fe54e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe553:	48 85 db             	test   %rbx,%rbx
  6fe556:	7e 16                	jle    6fe56e <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x752e>
  6fe558:	48 8b bc 24 d8 06 00 	mov    0x6d8(%rsp),%rdi
  6fe55f:	00 
  6fe560:	ba 01 00 00 00       	mov    $0x1,%edx
  6fe565:	48 89 de             	mov    %rbx,%rsi
  6fe568:	ff 15 fa d1 38 00    	call   *0x38d1fa(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe56e:	48 8b b4 24 d0 02 00 	mov    0x2d0(%rsp),%rsi
  6fe575:	00 
  6fe576:	48 8b 94 24 d8 02 00 	mov    0x2d8(%rsp),%rdx
  6fe57d:	00 
  6fe57e:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
  6fe585:	00 
  6fe586:	e8 35 0c 02 00       	call   71f1c0 <<[core::mem::maybe_uninit::MaybeUninit<core::option::Option<gpui::source::Text>>; 2] as core::array::iter::iter_inner::PartialDrop>::partial_drop>
  6fe58b:	48 8b bc 24 f8 04 00 	mov    0x4f8(%rsp),%rdi
  6fe592:	00 
  6fe593:	e8 28 40 fe ff       	call   6e25c0 <core::ptr::drop_glue::<core::option::Option<gpui::shared_text::SharedText>>>
  6fe598:	48 8b bc 24 f0 04 00 	mov    0x4f0(%rsp),%rdi
  6fe59f:	00 
  6fe5a0:	e8 1b 40 fe ff       	call   6e25c0 <core::ptr::drop_glue::<core::option::Option<gpui::shared_text::SharedText>>>
  6fe5a5:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  6fe5ac:	00 
  6fe5ad:	e8 ee 65 fe ff       	call   6e4ba0 <core::ptr::drop_glue::<core::iter::adapters::zip::Zip<alloc::vec::into_iter::IntoIter<gpui::semantic::AnnotationDraft>, alloc::vec::into_iter::IntoIter<[core::option::Option<gpui::source::FieldId>; 2]>>>>
  6fe5b2:	48 8d bc 24 b8 04 00 	lea    0x4b8(%rsp),%rdi
  6fe5b9:	00 
  6fe5ba:	e8 b1 5d fe ff       	call   6e4370 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::metadata::Declared>>>
  6fe5bf:	b0 01                	mov    $0x1,%al
  6fe5c1:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe5c5:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fe5cc:	00 
  6fe5cd:	40 b5 01             	mov    $0x1,%bpl
  6fe5d0:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
  6fe5d7:	00 
  6fe5d8:	e9 25 04 00 00       	jmp    6fea02 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x79c2>
  6fe5dd:	e9 c0 01 00 00       	jmp    6fe7a2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7762>
  6fe5e2:	e9 bb 01 00 00       	jmp    6fe7a2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7762>
  6fe5e7:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe5ec:	b3 01                	mov    $0x1,%bl
  6fe5ee:	48 83 bc 24 40 01 00 	cmpq   $0x0,0x140(%rsp)
  6fe5f5:	00 00 
  6fe5f7:	74 1f                	je     6fe618 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x75d8>
  6fe5f9:	48 8b b4 24 40 01 00 	mov    0x140(%rsp),%rsi
  6fe600:	00 
  6fe601:	48 c1 e6 04          	shl    $0x4,%rsi
  6fe605:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe60a:	48 8b bc 24 48 01 00 	mov    0x148(%rsp),%rdi
  6fe611:	00 
  6fe612:	ff 15 50 d1 38 00    	call   *0x38d150(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe618:	84 db                	test   %bl,%bl
  6fe61a:	0f 84 c2 00 00 00    	je     6fe6e2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x76a2>
  6fe620:	48 8b b4 24 d0 02 00 	mov    0x2d0(%rsp),%rsi
  6fe627:	00 
  6fe628:	48 85 f6             	test   %rsi,%rsi
  6fe62b:	74 17                	je     6fe644 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7604>
  6fe62d:	48 8b bc 24 d8 02 00 	mov    0x2d8(%rsp),%rdi
  6fe634:	00 
  6fe635:	48 c1 e6 04          	shl    $0x4,%rsi
  6fe639:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe63e:	ff 15 24 d1 38 00    	call   *0x38d124(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe644:	31 db                	xor    %ebx,%ebx
  6fe646:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fe64b:	48 8b 30             	mov    (%rax),%rsi
  6fe64e:	48 85 f6             	test   %rsi,%rsi
  6fe651:	74 18                	je     6fe66b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x762b>
  6fe653:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fe658:	48 8b 78 08          	mov    0x8(%rax),%rdi
  6fe65c:	48 c1 e6 04          	shl    $0x4,%rsi
  6fe660:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe665:	ff 15 fd d0 38 00    	call   *0x38d0fd(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe66b:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fe670:	48 8d 78 48          	lea    0x48(%rax),%rdi
  6fe674:	e8 b7 e6 00 00       	call   70cd30 <<alloc::collections::btree::map::BTreeMap<u64, gpui::property::Overlay<gpui::property::GeometryStyle>> as core::ops::drop::Drop>::drop>
  6fe679:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fe67e:	48 8b 70 18          	mov    0x18(%rax),%rsi
  6fe682:	48 85 f6             	test   %rsi,%rsi
  6fe685:	74 18                	je     6fe69f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x765f>
  6fe687:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fe68c:	48 8b 78 20          	mov    0x20(%rax),%rdi
  6fe690:	48 c1 e6 04          	shl    $0x4,%rsi
  6fe694:	ba 04 00 00 00       	mov    $0x4,%edx
  6fe699:	ff 15 c9 d0 38 00    	call   *0x38d0c9(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe69f:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fe6a4:	48 8b 70 30          	mov    0x30(%rax),%rsi
  6fe6a8:	48 85 f6             	test   %rsi,%rsi
  6fe6ab:	7e 18                	jle    6fe6c5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7685>
  6fe6ad:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6fe6b2:	48 8b 78 38          	mov    0x38(%rax),%rdi
  6fe6b6:	48 c1 e6 04          	shl    $0x4,%rsi
  6fe6ba:	ba 04 00 00 00       	mov    $0x4,%edx
  6fe6bf:	ff 15 a3 d0 38 00    	call   *0x38d0a3(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe6c5:	be 60 00 00 00       	mov    $0x60,%esi
  6fe6ca:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe6cf:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  6fe6d4:	ff 15 8e d0 38 00    	call   *0x38d08e(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe6da:	84 db                	test   %bl,%bl
  6fe6dc:	0f 85 e3 02 00 00    	jne    6fe9c5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7985>
  6fe6e2:	40 b5 01             	mov    $0x1,%bpl
  6fe6e5:	e9 08 03 00 00       	jmp    6fe9f2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x79b2>
  6fe6ea:	ff 15 b0 d0 38 00    	call   *0x38d0b0(%rip)        # a8b7a0 <_DYNAMIC+0x288>
  6fe6f0:	e9 e3 04 00 00       	jmp    6febd8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b98>
  6fe6f5:	e9 61 02 00 00       	jmp    6fe95b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x791b>
  6fe6fa:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe6ff:	41 b7 01             	mov    $0x1,%r15b
  6fe702:	b0 01                	mov    $0x1,%al
  6fe704:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe708:	40 b5 01             	mov    $0x1,%bpl
  6fe70b:	41 b6 01             	mov    $0x1,%r14b
  6fe70e:	41 b4 01             	mov    $0x1,%r12b
  6fe711:	48 8b 9c 24 18 04 00 	mov    0x418(%rsp),%rbx
  6fe718:	00 
  6fe719:	e9 74 07 00 00       	jmp    6fee92 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e52>
  6fe71e:	e9 38 02 00 00       	jmp    6fe95b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x791b>
  6fe723:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe728:	41 b7 01             	mov    $0x1,%r15b
  6fe72b:	b0 01                	mov    $0x1,%al
  6fe72d:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe731:	b0 01                	mov    $0x1,%al
  6fe733:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe737:	41 b6 01             	mov    $0x1,%r14b
  6fe73a:	40 b5 01             	mov    $0x1,%bpl
  6fe73d:	b3 01                	mov    $0x1,%bl
  6fe73f:	41 b5 01             	mov    $0x1,%r13b
  6fe742:	e9 0c 06 00 00       	jmp    6fed53 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d13>
  6fe747:	e9 e5 02 00 00       	jmp    6fea31 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x79f1>
  6fe74c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe751:	41 b7 01             	mov    $0x1,%r15b
  6fe754:	48 83 bc 24 f8 01 00 	cmpq   $0x0,0x1f8(%rsp)
  6fe75b:	00 00 
  6fe75d:	74 27                	je     6fe786 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7746>
  6fe75f:	48 8b 84 24 f8 01 00 	mov    0x1f8(%rsp),%rax
  6fe766:	00 
  6fe767:	48 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%rax
  6fe76e:	00 
  6fe76f:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6fe773:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe778:	48 8b bc 24 28 02 00 	mov    0x228(%rsp),%rdi
  6fe77f:	00 
  6fe780:	ff 15 e2 cf 38 00    	call   *0x38cfe2(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe786:	b0 01                	mov    $0x1,%al
  6fe788:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe78c:	b0 01                	mov    $0x1,%al
  6fe78e:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe792:	41 b6 01             	mov    $0x1,%r14b
  6fe795:	40 b5 01             	mov    $0x1,%bpl
  6fe798:	b3 01                	mov    $0x1,%bl
  6fe79a:	41 b4 01             	mov    $0x1,%r12b
  6fe79d:	e9 e2 05 00 00       	jmp    6fed84 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d44>
  6fe7a2:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe7a7:	b0 01                	mov    $0x1,%al
  6fe7a9:	89 44 24 30          	mov    %eax,0x30(%rsp)
  6fe7ad:	41 b5 01             	mov    $0x1,%r13b
  6fe7b0:	b3 01                	mov    $0x1,%bl
  6fe7b2:	40 b5 01             	mov    $0x1,%bpl
  6fe7b5:	41 b6 01             	mov    $0x1,%r14b
  6fe7b8:	b0 01                	mov    $0x1,%al
  6fe7ba:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe7be:	b0 01                	mov    $0x1,%al
  6fe7c0:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe7c4:	41 b7 01             	mov    $0x1,%r15b
  6fe7c7:	e9 73 05 00 00       	jmp    6fed3f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7cff>
  6fe7cc:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe7d1:	41 89 dc             	mov    %ebx,%r12d
  6fe7d4:	44 89 f8             	mov    %r15d,%eax
  6fe7d7:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe7db:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe7df:	45 89 fe             	mov    %r15d,%r14d
  6fe7e2:	e9 78 06 00 00       	jmp    6fee5f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e1f>
  6fe7e7:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe7ec:	44 89 f8             	mov    %r15d,%eax
  6fe7ef:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe7f3:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe7f7:	45 89 fe             	mov    %r15d,%r14d
  6fe7fa:	e9 6d 06 00 00       	jmp    6fee6c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e2c>
  6fe7ff:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe804:	4d 85 f6             	test   %r14,%r14
  6fe807:	75 3e                	jne    6fe847 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7807>
  6fe809:	48 8b b4 24 a0 04 00 	mov    0x4a0(%rsp),%rsi
  6fe810:	00 
  6fe811:	41 b4 01             	mov    $0x1,%r12b
  6fe814:	48 85 f6             	test   %rsi,%rsi
  6fe817:	74 17                	je     6fe830 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x77f0>
  6fe819:	48 8b bc 24 a8 04 00 	mov    0x4a8(%rsp),%rdi
  6fe820:	00 
  6fe821:	48 c1 e6 03          	shl    $0x3,%rsi
  6fe825:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe82a:	ff 15 38 cf 38 00    	call   *0x38cf38(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe830:	41 b6 01             	mov    $0x1,%r14b
  6fe833:	b0 01                	mov    $0x1,%al
  6fe835:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe839:	b0 01                	mov    $0x1,%al
  6fe83b:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe83f:	41 b7 01             	mov    $0x1,%r15b
  6fe842:	e9 09 06 00 00       	jmp    6fee50 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e10>
  6fe847:	48 83 c3 08          	add    $0x8,%rbx
  6fe84b:	49 f7 de             	neg    %r14
  6fe84e:	eb 09                	jmp    6fe859 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7819>
  6fe850:	48 83 c3 08          	add    $0x8,%rbx
  6fe854:	49 ff ce             	dec    %r14
  6fe857:	74 b0                	je     6fe809 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x77c9>
  6fe859:	48 8b 03             	mov    (%rbx),%rax
  6fe85c:	f0 48 ff 08          	lock decq (%rax)
  6fe860:	75 ee                	jne    6fe850 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7810>
  6fe862:	48 89 df             	mov    %rbx,%rdi
  6fe865:	41 ff d7             	call   *%r15
  6fe868:	eb e6                	jmp    6fe850 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7810>
  6fe86a:	ff 15 30 cf 38 00    	call   *0x38cf30(%rip)        # a8b7a0 <_DYNAMIC+0x288>
  6fe870:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe875:	e9 e5 06 00 00       	jmp    6fef5f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7f1f>
  6fe87a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe87f:	eb 15                	jmp    6fe896 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7856>
  6fe881:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe886:	48 8b 84 24 a0 02 00 	mov    0x2a0(%rsp),%rax
  6fe88d:	00 
  6fe88e:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
  6fe895:	00 
  6fe896:	48 83 bc 24 88 01 00 	cmpq   $0x0,0x188(%rsp)
  6fe89d:	00 00 
  6fe89f:	75 0e                	jne    6fe8af <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x786f>
  6fe8a1:	48 c7 84 24 88 01 00 	movq   $0x0,0x188(%rsp)
  6fe8a8:	00 00 00 00 00 
  6fe8ad:	eb 1c                	jmp    6fe8cb <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x788b>
  6fe8af:	48 8b b4 24 88 01 00 	mov    0x188(%rsp),%rsi
  6fe8b6:	00 
  6fe8b7:	48 c1 e6 05          	shl    $0x5,%rsi
  6fe8bb:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe8c0:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
  6fe8c5:	ff 15 9d ce 38 00    	call   *0x38ce9d(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe8cb:	48 83 bc 24 18 02 00 	cmpq   $0x0,0x218(%rsp)
  6fe8d2:	00 00 
  6fe8d4:	74 1f                	je     6fe8f5 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x78b5>
  6fe8d6:	48 8b b4 24 18 02 00 	mov    0x218(%rsp),%rsi
  6fe8dd:	00 
  6fe8de:	48 c1 e6 03          	shl    $0x3,%rsi
  6fe8e2:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe8e7:	48 8b bc 24 00 04 00 	mov    0x400(%rsp),%rdi
  6fe8ee:	00 
  6fe8ef:	ff 15 73 ce 38 00    	call   *0x38ce73(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe8f5:	48 8b 84 24 f8 03 00 	mov    0x3f8(%rsp),%rax
  6fe8fc:	00 
  6fe8fd:	48 39 84 24 20 02 00 	cmp    %rax,0x220(%rsp)
  6fe904:	00 
  6fe905:	0f 92 c0             	setb   %al
  6fe908:	48 83 bc 24 88 01 00 	cmpq   $0x0,0x188(%rsp)
  6fe90f:	00 00 
  6fe911:	0f 94 c1             	sete   %cl
  6fe914:	08 c1                	or     %al,%cl
  6fe916:	75 1c                	jne    6fe934 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x78f4>
  6fe918:	48 8b b4 24 88 01 00 	mov    0x188(%rsp),%rsi
  6fe91f:	00 
  6fe920:	48 c1 e6 05          	shl    $0x5,%rsi
  6fe924:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe929:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
  6fe92e:	ff 15 34 ce 38 00    	call   *0x38ce34(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe934:	b0 01                	mov    $0x1,%al
  6fe936:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe93a:	48 8d bc 24 70 03 00 	lea    0x370(%rsp),%rdi
  6fe941:	00 
  6fe942:	e8 d9 08 02 00       	call   71f220 <<alloc::vec::into_iter::IntoIter<gpui::list::ListDraft> as core::ops::drop::Drop>::drop>
  6fe947:	b0 01                	mov    $0x1,%al
  6fe949:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe94d:	40 b5 01             	mov    $0x1,%bpl
  6fe950:	b0 01                	mov    $0x1,%al
  6fe952:	89 44 24 30          	mov    %eax,0x30(%rsp)
  6fe956:	e9 a7 00 00 00       	jmp    6fea02 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x79c2>
  6fe95b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe960:	41 b7 01             	mov    $0x1,%r15b
  6fe963:	b0 01                	mov    $0x1,%al
  6fe965:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe969:	b0 01                	mov    $0x1,%al
  6fe96b:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe96f:	41 b6 01             	mov    $0x1,%r14b
  6fe972:	40 b5 01             	mov    $0x1,%bpl
  6fe975:	b0 01                	mov    $0x1,%al
  6fe977:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6fe97b:	e9 a0 02 00 00       	jmp    6fec20 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7be0>
  6fe980:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe985:	41 b7 01             	mov    $0x1,%r15b
  6fe988:	b0 01                	mov    $0x1,%al
  6fe98a:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe98e:	b0 01                	mov    $0x1,%al
  6fe990:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fe994:	41 b6 01             	mov    $0x1,%r14b
  6fe997:	40 b5 01             	mov    $0x1,%bpl
  6fe99a:	41 b4 01             	mov    $0x1,%r12b
  6fe99d:	e9 08 04 00 00       	jmp    6fedaa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d6a>
  6fe9a2:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe9a7:	b0 01                	mov    $0x1,%al
  6fe9a9:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fe9ad:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fe9b4:	00 
  6fe9b5:	40 b5 01             	mov    $0x1,%bpl
  6fe9b8:	b0 01                	mov    $0x1,%al
  6fe9ba:	89 44 24 30          	mov    %eax,0x30(%rsp)
  6fe9be:	eb 42                	jmp    6fea02 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x79c2>
  6fe9c0:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fe9c5:	40 b5 01             	mov    $0x1,%bpl
  6fe9c8:	48 83 bc 24 40 01 00 	cmpq   $0x0,0x140(%rsp)
  6fe9cf:	00 00 
  6fe9d1:	74 1f                	je     6fe9f2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x79b2>
  6fe9d3:	48 8b b4 24 40 01 00 	mov    0x140(%rsp),%rsi
  6fe9da:	00 
  6fe9db:	48 c1 e6 04          	shl    $0x4,%rsi
  6fe9df:	ba 08 00 00 00       	mov    $0x8,%edx
  6fe9e4:	48 8b bc 24 48 01 00 	mov    0x148(%rsp),%rdi
  6fe9eb:	00 
  6fe9ec:	ff 15 76 cd 38 00    	call   *0x38cd76(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fe9f2:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  6fe9f9:	00 
  6fe9fa:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
  6fea01:	00 
  6fea02:	48 8d bc 24 f8 06 00 	lea    0x6f8(%rsp),%rdi
  6fea09:	00 
  6fea0a:	e8 f1 da 00 00       	call   70c500 <<alloc::collections::btree::map::BTreeMap<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize> as core::ops::drop::Drop>::drop>
  6fea0f:	b3 01                	mov    $0x1,%bl
  6fea11:	40 84 ed             	test   %bpl,%bpl
  6fea14:	74 0d                	je     6fea23 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x79e3>
  6fea16:	48 8d bc 24 20 05 00 	lea    0x520(%rsp),%rdi
  6fea1d:	00 
  6fea1e:	e8 6d d7 00 00       	call   70c190 <<alloc::collections::btree::map::BTreeMap<gpui::runtime::scroll::ViewportKey, gpui::runtime::scroll::ViewportState> as core::ops::drop::Drop>::drop>
  6fea23:	31 ed                	xor    %ebp,%ebp
  6fea25:	45 31 f6             	xor    %r14d,%r14d
  6fea28:	e9 47 01 00 00       	jmp    6feb74 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b34>
  6fea2d:	0f 0b                	ud2
  6fea2f:	0f 0b                	ud2
  6fea31:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fea36:	44 89 eb             	mov    %r13d,%ebx
  6fea39:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  6fea3e:	48 ff c8             	dec    %rax
  6fea41:	48 83 f8 fc          	cmp    $0xfffffffffffffffc,%rax
  6fea45:	0f 87 7c 00 00 00    	ja     6feac7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a87>
  6fea4b:	ba 01 00 00 00       	mov    $0x1,%edx
  6fea50:	48 8b bc 24 f0 03 00 	mov    0x3f0(%rsp),%rdi
  6fea57:	00 
  6fea58:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  6fea5d:	ff 15 05 cd 38 00    	call   *0x38cd05(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fea63:	eb 62                	jmp    6feac7 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a87>
  6fea65:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fea6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  6fea70:	49 ff cf             	dec    %r15
  6fea73:	74 14                	je     6fea89 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a49>
  6fea75:	4d 8d a6 98 00 00 00 	lea    0x98(%r14),%r12
  6fea7c:	4c 89 f7             	mov    %r14,%rdi
  6fea7f:	e8 ec 38 00 00       	call   702370 <core::ptr::drop_glue::<gpui::element::DraftNode>>
  6fea84:	4d 89 e6             	mov    %r12,%r14
  6fea87:	eb e7                	jmp    6fea70 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7a30>
  6fea89:	48 8b 84 24 20 04 00 	mov    0x420(%rsp),%rax
  6fea90:	00 
  6fea91:	48 85 c0             	test   %rax,%rax
  6fea94:	0f 84 c5 04 00 00    	je     6fef5f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7f1f>
  6fea9a:	48 69 f0 98 00 00 00 	imul   $0x98,%rax,%rsi
  6feaa1:	ba 08 00 00 00       	mov    $0x8,%edx
  6feaa6:	48 89 df             	mov    %rbx,%rdi
  6feaa9:	ff 15 b9 cc 38 00    	call   *0x38ccb9(%rip)        # a8b768 <_DYNAMIC+0x250>
  6feaaf:	e9 ab 04 00 00       	jmp    6fef5f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7f1f>
  6feab4:	ff 15 e6 cc 38 00    	call   *0x38cce6(%rip)        # a8b7a0 <_DYNAMIC+0x288>
  6feaba:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6feabf:	40 b5 01             	mov    $0x1,%bpl
  6feac2:	41 b5 01             	mov    $0x1,%r13b
  6feac5:	b3 01                	mov    $0x1,%bl
  6feac7:	40 84 ed             	test   %bpl,%bpl
  6feaca:	74 18                	je     6feae4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7aa4>
  6feacc:	48 83 bc 24 50 04 00 	cmpq   $0xfffffffffffffffe,0x450(%rsp)
  6fead3:	00 fe 
  6fead5:	74 0d                	je     6feae4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7aa4>
  6fead7:	48 8d bc 24 50 04 00 	lea    0x450(%rsp),%rdi
  6feade:	00 
  6feadf:	e8 5c 67 fe ff       	call   6e5240 <core::ptr::drop_glue::<gpui::runtime::TextSite>>
  6feae4:	45 84 ed             	test   %r13b,%r13b
  6feae7:	75 09                	jne    6feaf2 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ab2>
  6feae9:	eb 16                	jmp    6feb01 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ac1>
  6feaeb:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6feaf0:	b3 01                	mov    $0x1,%bl
  6feaf2:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  6feaf7:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  6feafc:	e8 ef 3a fe ff       	call   6e25f0 <core::ptr::drop_glue::<core::option::Option<gpui::element::Handler>>>
  6feb01:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  6feb08:	00 
  6feb09:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  6feb0d:	74 18                	je     6feb27 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ae7>
  6feb0f:	48 85 f6             	test   %rsi,%rsi
  6feb12:	7e 13                	jle    6feb27 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ae7>
  6feb14:	48 8b bc 24 88 00 00 	mov    0x88(%rsp),%rdi
  6feb1b:	00 
  6feb1c:	ba 01 00 00 00       	mov    $0x1,%edx
  6feb21:	ff 15 41 cc 38 00    	call   *0x38cc41(%rip)        # a8b768 <_DYNAMIC+0x250>
  6feb27:	84 db                	test   %bl,%bl
  6feb29:	74 15                	je     6feb40 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b00>
  6feb2b:	48 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%rdi
  6feb32:	00 
  6feb33:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  6feb3a:	00 
  6feb3b:	e8 b0 3a fe ff       	call   6e25f0 <core::ptr::drop_glue::<core::option::Option<gpui::element::Handler>>>
  6feb40:	48 8d bc 24 08 01 00 	lea    0x108(%rsp),%rdi
  6feb47:	00 
  6feb48:	e8 73 65 fe ff       	call   6e50c0 <core::ptr::drop_glue::<gpui::element::ComponentBoundaries>>
  6feb4d:	b0 01                	mov    $0x1,%al
  6feb4f:	89 44 24 30          	mov    %eax,0x30(%rsp)
  6feb53:	48 8d bc 24 d0 06 00 	lea    0x6d0(%rsp),%rdi
  6feb5a:	00 
  6feb5b:	e8 60 08 02 00       	call   71f3c0 <<alloc::vec::into_iter::IntoIter<gpui::element::DraftNode> as core::ops::drop::Drop>::drop>
  6feb60:	b3 01                	mov    $0x1,%bl
  6feb62:	40 b5 01             	mov    $0x1,%bpl
  6feb65:	41 b6 01             	mov    $0x1,%r14b
  6feb68:	b0 01                	mov    $0x1,%al
  6feb6a:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6feb6e:	b0 01                	mov    $0x1,%al
  6feb70:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6feb74:	ba 04 00 00 00       	mov    $0x4,%edx
  6feb79:	48 8b bc 24 08 02 00 	mov    0x208(%rsp),%rdi
  6feb80:	00 
  6feb81:	48 8b b4 24 80 02 00 	mov    0x280(%rsp),%rsi
  6feb88:	00 
  6feb89:	ff 15 d9 cb 38 00    	call   *0x38cbd9(%rip)        # a8b768 <_DYNAMIC+0x250>
  6feb8f:	41 b4 01             	mov    $0x1,%r12b
  6feb92:	45 31 ff             	xor    %r15d,%r15d
  6feb95:	48 8d bc 24 68 05 00 	lea    0x568(%rsp),%rdi
  6feb9c:	00 
  6feb9d:	e8 4e 50 fe ff       	call   6e3bf0 <core::ptr::drop_glue::<alloc::vec::Vec<core::option::Option<gpui::runtime::TextSite>>>>
  6feba2:	84 db                	test   %bl,%bl
  6feba4:	0f 84 c9 00 00 00    	je     6fec73 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c33>
  6febaa:	48 8d bc 24 50 05 00 	lea    0x550(%rsp),%rdi
  6febb1:	00 
  6febb2:	e8 d9 4f fe ff       	call   6e3b90 <core::ptr::drop_glue::<alloc::vec::Vec<core::option::Option<gpui::element::Handler>>>>
  6febb7:	e9 8f 00 00 00       	jmp    6fec4b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c0b>
  6febbc:	eb 1a                	jmp    6febd8 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b98>
  6febbe:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6febc3:	ba 08 00 00 00       	mov    $0x8,%edx
  6febc8:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
  6febcd:	48 89 de             	mov    %rbx,%rsi
  6febd0:	ff 15 92 cb 38 00    	call   *0x38cb92(%rip)        # a8b768 <_DYNAMIC+0x250>
  6febd6:	eb 05                	jmp    6febdd <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7b9d>
  6febd8:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6febdd:	b0 01                	mov    $0x1,%al
  6febdf:	89 44 24 30          	mov    %eax,0x30(%rsp)
  6febe3:	41 b5 01             	mov    $0x1,%r13b
  6febe6:	b3 01                	mov    $0x1,%bl
  6febe8:	40 b5 01             	mov    $0x1,%bpl
  6febeb:	41 b6 01             	mov    $0x1,%r14b
  6febee:	b0 01                	mov    $0x1,%al
  6febf0:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6febf4:	b0 01                	mov    $0x1,%al
  6febf6:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6febfa:	41 b7 01             	mov    $0x1,%r15b
  6febfd:	e9 ab 00 00 00       	jmp    6fecad <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c6d>
  6fec02:	89 5c 24 18          	mov    %ebx,0x18(%rsp)
  6fec06:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fec0b:	41 b7 01             	mov    $0x1,%r15b
  6fec0e:	b0 01                	mov    $0x1,%al
  6fec10:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fec14:	b0 01                	mov    $0x1,%al
  6fec16:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fec1a:	41 b6 01             	mov    $0x1,%r14b
  6fec1d:	40 b5 01             	mov    $0x1,%bpl
  6fec20:	41 b4 01             	mov    $0x1,%r12b
  6fec23:	e9 75 01 00 00       	jmp    6fed9d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d5d>
  6fec28:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6fec2d:	41 b7 01             	mov    $0x1,%r15b
  6fec30:	b0 01                	mov    $0x1,%al
  6fec32:	89 44 24 20          	mov    %eax,0x20(%rsp)
  6fec36:	b0 01                	mov    $0x1,%al
  6fec38:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6fec3c:	41 b6 01             	mov    $0x1,%r14b
  6fec3f:	40 b5 01             	mov    $0x1,%bpl
  6fec42:	41 b4 01             	mov    $0x1,%r12b
  6fec45:	b0 01                	mov    $0x1,%al
  6fec47:	89 44 24 30          	mov    %eax,0x30(%rsp)
  6fec4b:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  6fec52:	00 
  6fec53:	48 85 c0             	test   %rax,%rax
  6fec56:	74 1b                	je     6fec73 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c33>
  6fec58:	48 8b bc 24 70 01 00 	mov    0x170(%rsp),%rdi
  6fec5f:	00 
  6fec60:	48 c1 e0 03          	shl    $0x3,%rax
  6fec64:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6fec68:	ba 08 00 00 00       	mov    $0x8,%edx
  6fec6d:	ff 15 f5 ca 38 00    	call   *0x38caf5(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fec73:	b3 01                	mov    $0x1,%bl
  6fec75:	45 84 e4             	test   %r12b,%r12b
  6fec78:	74 0f                	je     6fec89 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c49>
  6fec7a:	b3 01                	mov    $0x1,%bl
  6fec7c:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6fec83:	00 
  6fec84:	e8 87 78 fe ff       	call   6e6510 <core::ptr::drop_glue::<gpui::runtime::styles::Builder>>
  6fec89:	48 8b b4 24 88 02 00 	mov    0x288(%rsp),%rsi
  6fec90:	00 
  6fec91:	48 85 f6             	test   %rsi,%rsi
  6fec94:	74 14                	je     6fecaa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7c6a>
  6fec96:	48 c1 e6 03          	shl    $0x3,%rsi
  6fec9a:	ba 08 00 00 00       	mov    $0x8,%edx
  6fec9f:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
  6feca4:	ff 15 be ca 38 00    	call   *0x38cabe(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fecaa:	45 31 ed             	xor    %r13d,%r13d
  6fecad:	48 8d bc 24 98 08 00 	lea    0x898(%rsp),%rdi
  6fecb4:	00 
  6fecb5:	e8 b6 db 00 00       	call   70c870 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fecba:	48 8d bc 24 88 06 00 	lea    0x688(%rsp),%rdi
  6fecc1:	00 
  6fecc2:	e8 39 d8 00 00       	call   70c500 <<alloc::collections::btree::map::BTreeMap<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize> as core::ops::drop::Drop>::drop>
  6fecc7:	48 8d bc 24 70 06 00 	lea    0x670(%rsp),%rdi
  6fecce:	00 
  6feccf:	e8 2c d8 00 00       	call   70c500 <<alloc::collections::btree::map::BTreeMap<(core::option::Option<u64>, gpui::list::ListId, gpui::element::NodeKind), usize> as core::ops::drop::Drop>::drop>
  6fecd4:	48 8b 84 24 60 06 00 	mov    0x660(%rsp),%rax
  6fecdb:	00 
  6fecdc:	48 85 c0             	test   %rax,%rax
  6fecdf:	74 18                	je     6fecf9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7cb9>
  6fece1:	48 c1 e0 03          	shl    $0x3,%rax
  6fece5:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6fece9:	ba 08 00 00 00       	mov    $0x8,%edx
  6fecee:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  6fecf3:	ff 15 6f ca 38 00    	call   *0x38ca6f(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fecf9:	48 8b bc 24 08 05 00 	mov    0x508(%rsp),%rdi
  6fed00:	00 
  6fed01:	48 8b b4 24 e8 03 00 	mov    0x3e8(%rsp),%rsi
  6fed08:	00 
  6fed09:	e8 82 59 fe ff       	call   6e4690 <core::ptr::drop_glue::<alloc::boxed::Box<[core::option::Option<gpui::element::Handler>]>>>
  6fed0e:	48 8b b4 24 c8 07 00 	mov    0x7c8(%rsp),%rsi
  6fed15:	00 
  6fed16:	48 85 f6             	test   %rsi,%rsi
  6fed19:	74 17                	je     6fed32 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7cf2>
  6fed1b:	48 8b bc 24 d0 07 00 	mov    0x7d0(%rsp),%rdi
  6fed22:	00 
  6fed23:	48 c1 e6 02          	shl    $0x2,%rsi
  6fed27:	ba 04 00 00 00       	mov    $0x4,%edx
  6fed2c:	ff 15 36 ca 38 00    	call   *0x38ca36(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fed32:	48 8d bc 24 a0 06 00 	lea    0x6a0(%rsp),%rdi
  6fed39:	00 
  6fed3a:	e8 a1 76 fe ff       	call   6e63e0 <core::ptr::drop_glue::<gpui::runtime::styles::Styles>>
  6fed3f:	48 8d bc 24 38 04 00 	lea    0x438(%rsp),%rdi
  6fed46:	00 
  6fed47:	e8 c4 cb 00 00       	call   70b910 <<alloc::collections::btree::map::BTreeMap<gpui::source::FieldId, gpui::shared_text::SharedText> as core::ops::drop::Drop>::drop>
  6fed4c:	80 7c 24 30 00       	cmpb   $0x0,0x30(%rsp)
  6fed51:	74 29                	je     6fed7c <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d3c>
  6fed53:	48 8b b4 24 68 02 00 	mov    0x268(%rsp),%rsi
  6fed5a:	00 
  6fed5b:	41 b4 01             	mov    $0x1,%r12b
  6fed5e:	48 85 f6             	test   %rsi,%rsi
  6fed61:	74 1c                	je     6fed7f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d3f>
  6fed63:	48 8b bc 24 70 02 00 	mov    0x270(%rsp),%rdi
  6fed6a:	00 
  6fed6b:	48 c1 e6 04          	shl    $0x4,%rsi
  6fed6f:	ba 08 00 00 00       	mov    $0x8,%edx
  6fed74:	ff 15 ee c9 38 00    	call   *0x38c9ee(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fed7a:	eb 03                	jmp    6fed7f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d3f>
  6fed7c:	45 31 e4             	xor    %r12d,%r12d
  6fed7f:	45 84 ed             	test   %r13b,%r13b
  6fed82:	74 0d                	je     6fed91 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d51>
  6fed84:	48 8d bc 24 e0 07 00 	lea    0x7e0(%rsp),%rdi
  6fed8b:	00 
  6fed8c:	e8 cf 85 fe ff       	call   6e7360 <core::ptr::drop_glue::<gpui::runtime::styles::colours::Discovery>>
  6fed91:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
  6fed98:	00 
  6fed99:	84 db                	test   %bl,%bl
  6fed9b:	74 0d                	je     6fedaa <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7d6a>
  6fed9d:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  6feda4:	00 
  6feda5:	e8 56 cc 00 00       	call   70ba00 <<alloc::collections::btree::map::BTreeMap<gpui::source::FieldId, gpui::runtime::Fanout> as core::ops::drop::Drop>::drop>
  6fedaa:	ba 08 00 00 00       	mov    $0x8,%edx
  6fedaf:	48 8b bc 24 b0 02 00 	mov    0x2b0(%rsp),%rdi
  6fedb6:	00 
  6fedb7:	48 8b b4 24 08 04 00 	mov    0x408(%rsp),%rsi
  6fedbe:	00 
  6fedbf:	ff 15 a3 c9 38 00    	call   *0x38c9a3(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fedc5:	48 8b b4 24 50 02 00 	mov    0x250(%rsp),%rsi
  6fedcc:	00 
  6fedcd:	48 85 f6             	test   %rsi,%rsi
  6fedd0:	74 17                	je     6fede9 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7da9>
  6fedd2:	48 8b bc 24 58 02 00 	mov    0x258(%rsp),%rdi
  6fedd9:	00 
  6fedda:	48 c1 e6 02          	shl    $0x2,%rsi
  6fedde:	ba 04 00 00 00       	mov    $0x4,%edx
  6fede3:	ff 15 7f c9 38 00    	call   *0x38c97f(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fede9:	48 8b b4 24 38 02 00 	mov    0x238(%rsp),%rsi
  6fedf0:	00 
  6fedf1:	48 85 f6             	test   %rsi,%rsi
  6fedf4:	74 17                	je     6fee0d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7dcd>
  6fedf6:	48 8b bc 24 40 02 00 	mov    0x240(%rsp),%rdi
  6fedfd:	00 
  6fedfe:	48 c1 e6 03          	shl    $0x3,%rsi
  6fee02:	ba 08 00 00 00       	mov    $0x8,%edx
  6fee07:	ff 15 5b c9 38 00    	call   *0x38c95b(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fee0d:	48 8b b4 24 b8 02 00 	mov    0x2b8(%rsp),%rsi
  6fee14:	00 
  6fee15:	48 85 f6             	test   %rsi,%rsi
  6fee18:	74 17                	je     6fee31 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7df1>
  6fee1a:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
  6fee21:	00 
  6fee22:	48 c1 e6 03          	shl    $0x3,%rsi
  6fee26:	ba 08 00 00 00       	mov    $0x8,%edx
  6fee2b:	ff 15 37 c9 38 00    	call   *0x38c937(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fee31:	48 8d bc 24 b0 07 00 	lea    0x7b0(%rsp),%rdi
  6fee38:	00 
  6fee39:	e8 32 da 00 00       	call   70c870 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fee3e:	40 84 ed             	test   %bpl,%bpl
  6fee41:	74 0d                	je     6fee50 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e10>
  6fee43:	48 8d bc 24 a0 04 00 	lea    0x4a0(%rsp),%rdi
  6fee4a:	00 
  6fee4b:	e8 b0 52 fe ff       	call   6e4100 <core::ptr::drop_glue::<alloc::vec::Vec<gpui_canvas::image::Image>>>
  6fee50:	48 8d bc 24 68 08 00 	lea    0x868(%rsp),%rdi
  6fee57:	00 
  6fee58:	e8 93 bc 00 00       	call   70aaf0 <<alloc::collections::btree::map::BTreeMap<gpui_reactivity_core::tree::NodeId, fn(cephal::tree::traits::MeasureInput) -> cephal::tree::traits::MeasureOutput> as core::ops::drop::Drop>::drop>
  6fee5d:	31 ed                	xor    %ebp,%ebp
  6fee5f:	48 8d bc 24 50 08 00 	lea    0x850(%rsp),%rdi
  6fee66:	00 
  6fee67:	e8 04 da 00 00       	call   70c870 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId> as core::ops::drop::Drop>::drop>
  6fee6c:	45 84 f6             	test   %r14b,%r14b
  6fee6f:	48 8b 9c 24 18 04 00 	mov    0x418(%rsp),%rbx
  6fee76:	00 
  6fee77:	74 0d                	je     6fee86 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e46>
  6fee79:	48 8d bc 24 e0 05 00 	lea    0x5e0(%rsp),%rdi
  6fee80:	00 
  6fee81:	e8 ca 4e fe ff       	call   6e3d50 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::list::ListDraft>>>
  6fee86:	80 7c 24 08 00       	cmpb   $0x0,0x8(%rsp)
  6fee8b:	44 8b 74 24 18       	mov    0x18(%rsp),%r14d
  6fee90:	74 24                	je     6feeb6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e76>
  6fee92:	48 8b b4 24 38 05 00 	mov    0x538(%rsp),%rsi
  6fee99:	00 
  6fee9a:	48 85 f6             	test   %rsi,%rsi
  6fee9d:	74 17                	je     6feeb6 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7e76>
  6fee9f:	48 8b bc 24 40 05 00 	mov    0x540(%rsp),%rdi
  6feea6:	00 
  6feea7:	48 c1 e6 04          	shl    $0x4,%rsi
  6feeab:	ba 08 00 00 00       	mov    $0x8,%edx
  6feeb0:	ff 15 b2 c8 38 00    	call   *0x38c8b2(%rip)        # a8b768 <_DYNAMIC+0x250>
  6feeb6:	48 8b 8c 24 f8 01 00 	mov    0x1f8(%rsp),%rcx
  6feebd:	00 
  6feebe:	48 85 c9             	test   %rcx,%rcx
  6feec1:	0f 95 c0             	setne  %al
  6feec4:	41 84 c6             	test   %al,%r14b
  6feec7:	74 1b                	je     6feee4 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ea4>
  6feec9:	48 c1 e1 03          	shl    $0x3,%rcx
  6feecd:	48 8d 34 49          	lea    (%rcx,%rcx,2),%rsi
  6feed1:	ba 08 00 00 00       	mov    $0x8,%edx
  6feed6:	48 8b bc 24 28 02 00 	mov    0x228(%rsp),%rdi
  6feedd:	00 
  6feede:	ff 15 84 c8 38 00    	call   *0x38c884(%rip)        # a8b768 <_DYNAMIC+0x250>
  6feee4:	48 83 bc 24 40 01 00 	cmpq   $0x0,0x140(%rsp)
  6feeeb:	00 00 
  6feeed:	74 26                	je     6fef15 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ed5>
  6feeef:	80 7c 24 20 00       	cmpb   $0x0,0x20(%rsp)
  6feef4:	74 1f                	je     6fef15 <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7ed5>
  6feef6:	48 8b b4 24 40 01 00 	mov    0x140(%rsp),%rsi
  6feefd:	00 
  6feefe:	48 c1 e6 04          	shl    $0x4,%rsi
  6fef02:	ba 08 00 00 00       	mov    $0x8,%edx
  6fef07:	48 8b bc 24 48 01 00 	mov    0x148(%rsp),%rdi
  6fef0e:	00 
  6fef0f:	ff 15 53 c8 38 00    	call   *0x38c853(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fef15:	48 85 db             	test   %rbx,%rbx
  6fef18:	0f 95 c0             	setne  %al
  6fef1b:	40 84 c5             	test   %al,%bpl
  6fef1e:	74 1b                	je     6fef3b <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7efb>
  6fef20:	48 c1 e3 03          	shl    $0x3,%rbx
  6fef24:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
  6fef28:	ba 08 00 00 00       	mov    $0x8,%edx
  6fef2d:	48 8b bc 24 18 05 00 	mov    0x518(%rsp),%rdi
  6fef34:	00 
  6fef35:	ff 15 2d c8 38 00    	call   *0x38c82d(%rip)        # a8b768 <_DYNAMIC+0x250>
  6fef3b:	45 84 e4             	test   %r12b,%r12b
  6fef3e:	74 0d                	je     6fef4d <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7f0d>
  6fef40:	48 8d bc 24 d0 04 00 	lea    0x4d0(%rsp),%rdi
  6fef47:	00 
  6fef48:	e8 03 51 fe ff       	call   6e4050 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::semantic::AnnotationDraft>>>
  6fef4d:	45 84 ff             	test   %r15b,%r15b
  6fef50:	74 0d                	je     6fef5f <<gpui::runtime::Runtime<route_columns_cost::Page>>::describe_inner+0x7f1f>
  6fef52:	48 8d bc 24 20 04 00 	lea    0x420(%rsp),%rdi
  6fef59:	00 
  6fef5a:	e8 a1 4e fe ff       	call   6e3e00 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::element::DraftNode>>>
  6fef5f:	48 8d bc 24 80 08 00 	lea    0x880(%rsp),%rdi
  6fef66:	00 
  6fef67:	e8 a4 c6 00 00       	call   70b610 <<alloc::collections::btree::map::BTreeMap<gpui::list::ListId, alloc::collections::btree::set_val::SetValZST> as core::ops::drop::Drop>::drop>
  6fef6c:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  6fef71:	e8 1a 21 36 00       	call   a61090 <_Unwind_Resume@plt>
  6fef76:	ff 15 24 c8 38 00    	call   *0x38c824(%rip)        # a8b7a0 <_DYNAMIC+0x288>
