
/tmp/gpui-route-topology-evidence/bin/topology-cost:     file format elf64-x86-64


Disassembly of section .text:

0000000000725430 <route_columns_cost::main::{closure#1}>:
  725430:	55                   	push   %rbp
  725431:	41 57                	push   %r15
  725433:	41 56                	push   %r14
  725435:	41 55                	push   %r13
  725437:	41 54                	push   %r12
  725439:	53                   	push   %rbx
  72543a:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
  725441:	48 8b 07             	mov    (%rdi),%rax
  725444:	48 8b 18             	mov    (%rax),%rbx
  725447:	48 85 db             	test   %rbx,%rbx
  72544a:	0f 84 81 04 00 00    	je     7258d1 <route_columns_cost::main::{closure#1}+0x4a1>
  725450:	48 8b 6f 08          	mov    0x8(%rdi),%rbp
  725454:	48 8b 47 10          	mov    0x10(%rdi),%rax
  725458:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  72545f:	00 
  725460:	4c 8b 6f 18          	mov    0x18(%rdi),%r13
  725464:	49 8d 45 08          	lea    0x8(%r13),%rax
  725468:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  72546f:	00 
  725470:	48 c7 84 24 98 00 00 	movq   $0x0,0x98(%rsp)
  725477:	00 00 00 00 00 
  72547c:	4c 8b 3d e5 62 36 00 	mov    0x3662e5(%rip),%r15        # a8b768 <_DYNAMIC+0x250>
  725483:	45 31 e4             	xor    %r12d,%r12d
  725486:	48 89 9c 24 c8 00 00 	mov    %rbx,0xc8(%rsp)
  72548d:	00 
  72548e:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
  725495:	00 
  725496:	eb 41                	jmp    7254d9 <route_columns_cost::main::{closure#1}+0xa9>
  725498:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  72549f:	00 
  7254a0:	48 8d 44 24 08       	lea    0x8(%rsp),%rax
  7254a5:	0f 10 00             	movups (%rax),%xmm0
  7254a8:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  7254ac:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  7254b0:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
  7254b5:	0f 29 4c 24 50       	movaps %xmm1,0x50(%rsp)
  7254ba:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  7254bf:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
  7254c4:	49 8b 7d 00          	mov    0x0(%r13),%rdi
  7254c8:	e8 03 06 00 00       	call   725ad0 <route_columns_cost::acknowledge>
  7254cd:	49 ff c4             	inc    %r12
  7254d0:	49 39 dc             	cmp    %rbx,%r12
  7254d3:	0f 84 04 04 00 00    	je     7258dd <route_columns_cost::main::{closure#1}+0x4ad>
  7254d9:	48 8b 45 08          	mov    0x8(%rbp),%rax
  7254dd:	48 83 f8 05          	cmp    $0x5,%rax
  7254e1:	0f 84 19 01 00 00    	je     725600 <route_columns_cost::main::{closure#1}+0x1d0>
  7254e7:	48 83 f8 06          	cmp    $0x6,%rax
  7254eb:	0f 84 bf 00 00 00    	je     7255b0 <route_columns_cost::main::{closure#1}+0x180>
  7254f1:	48 83 f8 08          	cmp    $0x8,%rax
  7254f5:	0f 85 bc 04 00 00    	jne    7259b7 <route_columns_cost::main::{closure#1}+0x587>
  7254fb:	48 8b 45 00          	mov    0x0(%rbp),%rax
  7254ff:	48 b9 61 63 74 69 76 	movabs $0x6574617669746361,%rcx
  725506:	61 74 65 
  725509:	48 39 08             	cmp    %rcx,(%rax)
  72550c:	0f 84 be 01 00 00    	je     7256d0 <route_columns_cost::main::{closure#1}+0x2a0>
  725512:	48 b9 73 6e 61 70 73 	movabs $0x746f687370616e73,%rcx
  725519:	68 6f 74 
  72551c:	48 39 08             	cmp    %rcx,(%rax)
  72551f:	0f 85 92 04 00 00    	jne    7259b7 <route_columns_cost::main::{closure#1}+0x587>
  725525:	48 8d 5c 24 40       	lea    0x40(%rsp),%rbx
  72552a:	48 89 df             	mov    %rbx,%rdi
  72552d:	4c 89 ee             	mov    %r13,%rsi
  725530:	31 d2                	xor    %edx,%edx
  725532:	e8 e9 a8 fc ff       	call   6efe20 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets>
  725537:	83 7c 24 40 02       	cmpl   $0x2,0x40(%rsp)
  72553c:	0f 84 8e 04 00 00    	je     7259d0 <route_columns_cost::main::{closure#1}+0x5a0>
  725542:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  725547:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  72554e:	00 
  72554f:	0f 10 44 24 40       	movups 0x40(%rsp),%xmm0
  725554:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  72555b:	00 
  72555c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  725561:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  725566:	48 8d 54 24 68       	lea    0x68(%rsp),%rdx
  72556b:	0f 10 02             	movups (%rdx),%xmm0
  72556e:	0f 10 4a 10          	movups 0x10(%rdx),%xmm1
  725572:	0f 10 52 20          	movups 0x20(%rdx),%xmm2
  725576:	0f 29 04 24          	movaps %xmm0,(%rsp)
  72557a:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
  72557f:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
  725584:	48 85 c9             	test   %rcx,%rcx
  725587:	0f 84 7d 01 00 00    	je     72570a <route_columns_cost::main::{closure#1}+0x2da>
  72558d:	89 ca                	mov    %ecx,%edx
  72558f:	83 e2 03             	and    $0x3,%edx
  725592:	48 83 f9 04          	cmp    $0x4,%rcx
  725596:	0f 83 76 01 00 00    	jae    725712 <route_columns_cost::main::{closure#1}+0x2e2>
  72559c:	31 f6                	xor    %esi,%esi
  72559e:	45 31 ed             	xor    %r13d,%r13d
  7255a1:	e9 cb 01 00 00       	jmp    725771 <route_columns_cost::main::{closure#1}+0x341>
  7255a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  7255ad:	00 00 00 
  7255b0:	48 8b 45 00          	mov    0x0(%rbp),%rax
  7255b4:	8b 08                	mov    (%rax),%ecx
  7255b6:	ba 72 65 73 69       	mov    $0x69736572,%edx
  7255bb:	31 d1                	xor    %edx,%ecx
  7255bd:	0f b7 40 04          	movzwl 0x4(%rax),%eax
  7255c1:	35 7a 65 00 00       	xor    $0x657a,%eax
  7255c6:	09 c8                	or     %ecx,%eax
  7255c8:	0f 85 e9 03 00 00    	jne    7259b7 <route_columns_cost::main::{closure#1}+0x587>
  7255ce:	44 89 e2             	mov    %r12d,%edx
  7255d1:	83 e2 01             	and    $0x1,%edx
  7255d4:	48 b8 21 00 00 00 20 	movabs $0x2000000021,%rax
  7255db:	00 00 00 
  7255de:	48 01 c2             	add    %rax,%rdx
  7255e1:	48 89 e7             	mov    %rsp,%rdi
  7255e4:	4c 89 ee             	mov    %r13,%rsi
  7255e7:	e8 b4 af fc ff       	call   6f05a0 <<gpui::runtime::Win<route_columns_cost::Page>>::resize>
  7255ec:	83 3c 24 fe          	cmpl   $0xfffffffe,(%rsp)
  7255f0:	0f 84 aa fe ff ff    	je     7254a0 <route_columns_cost::main::{closure#1}+0x70>
  7255f6:	e9 0b 03 00 00       	jmp    725906 <route_columns_cost::main::{closure#1}+0x4d6>
  7255fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  725600:	48 8b 45 00          	mov    0x0(%rbp),%rax
  725604:	8b 08                	mov    (%rax),%ecx
  725606:	ba 65 71 75 61       	mov    $0x61757165,%edx
  72560b:	31 d1                	xor    %edx,%ecx
  72560d:	0f b6 40 04          	movzbl 0x4(%rax),%eax
  725611:	83 f0 6c             	xor    $0x6c,%eax
  725614:	09 c8                	or     %ecx,%eax
  725616:	0f 85 9b 03 00 00    	jne    7259b7 <route_columns_cost::main::{closure#1}+0x587>
  72561c:	49 8b 45 00          	mov    0x0(%r13),%rax
  725620:	48 85 c0             	test   %rax,%rax
  725623:	0f 84 6a 04 00 00    	je     725a93 <route_columns_cost::main::{closure#1}+0x663>
  725629:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  725630:	00 
  725631:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
  725638:	00 
  725639:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
  725640:	00 
  725641:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  725648:	00 00 
  72564a:	80 b8 4e 07 00 00 00 	cmpb   $0x0,0x74e(%rax)
  725651:	0f 85 32 04 00 00    	jne    725a89 <route_columns_cost::main::{closure#1}+0x659>
  725657:	48 8b 88 90 06 00 00 	mov    0x690(%rax),%rcx
  72565e:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
  725662:	0f 84 f2 02 00 00    	je     72595a <route_columns_cost::main::{closure#1}+0x52a>
  725668:	48 ff c1             	inc    %rcx
  72566b:	48 89 88 90 06 00 00 	mov    %rcx,0x690(%rax)
  725672:	48 ff 80 e0 06 00 00 	incq   0x6e0(%rax)
  725679:	48 c7 80 38 07 00 00 	movq   $0x0,0x738(%rax)
  725680:	00 00 00 00 
  725684:	48 89 e7             	mov    %rsp,%rdi
  725687:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
  72568e:	00 
  72568f:	31 d2                	xor    %edx,%edx
  725691:	4c 8d 74 24 40       	lea    0x40(%rsp),%r14
  725696:	4c 89 f1             	mov    %r14,%rcx
  725699:	45 31 c0             	xor    %r8d,%r8d
  72569c:	e8 9f 38 fc ff       	call   6e8f40 <<gpui::runtime::RuntimeMut<route_columns_cost::Page, ()>>::after_source_changed>
  7256a1:	48 83 3c 24 fe       	cmpq   $0xfffffffffffffffe,(%rsp)
  7256a6:	0f 85 b7 02 00 00    	jne    725963 <route_columns_cost::main::{closure#1}+0x533>
  7256ac:	48 8d 44 24 08       	lea    0x8(%rsp),%rax
  7256b1:	0f 10 00             	movups (%rax),%xmm0
  7256b4:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  7256b8:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  7256bc:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
  7256c1:	0f 29 4c 24 50       	movaps %xmm1,0x50(%rsp)
  7256c6:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  7256cb:	e9 f4 fd ff ff       	jmp    7254c4 <route_columns_cost::main::{closure#1}+0x94>
  7256d0:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  7256d7:	00 
  7256d8:	48 8b 70 10          	mov    0x10(%rax),%rsi
  7256dc:	48 85 f6             	test   %rsi,%rsi
  7256df:	0f 84 3a 03 00 00    	je     725a1f <route_columns_cost::main::{closure#1}+0x5ef>
  7256e5:	48 8b 48 08          	mov    0x8(%rax),%rcx
  7256e9:	49 69 c4 ef 1e 00 00 	imul   $0x1eef,%r12,%rax
  7256f0:	48 89 c2             	mov    %rax,%rdx
  7256f3:	48 09 f2             	or     %rsi,%rdx
  7256f6:	48 c1 ea 20          	shr    $0x20,%rdx
  7256fa:	0f 84 7f 01 00 00    	je     72587f <route_columns_cost::main::{closure#1}+0x44f>
  725700:	31 d2                	xor    %edx,%edx
  725702:	48 f7 f6             	div    %rsi
  725705:	e9 79 01 00 00       	jmp    725883 <route_columns_cost::main::{closure#1}+0x453>
  72570a:	45 31 ed             	xor    %r13d,%r13d
  72570d:	e9 93 00 00 00       	jmp    7257a5 <route_columns_cost::main::{closure#1}+0x375>
  725712:	48 89 cf             	mov    %rcx,%rdi
  725715:	48 83 e7 fc          	and    $0xfffffffffffffffc,%rdi
  725719:	4c 8d 80 f0 01 00 00 	lea    0x1f0(%rax),%r8
  725720:	31 f6                	xor    %esi,%esi
  725722:	45 31 ed             	xor    %r13d,%r13d
  725725:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  72572c:	00 00 00 00 
  725730:	49 83 b8 68 fe ff ff 	cmpq   $0x1,-0x198(%r8)
  725737:	01 
  725738:	49 83 dd ff          	sbb    $0xffffffffffffffff,%r13
  72573c:	49 83 b8 f0 fe ff ff 	cmpq   $0x1,-0x110(%r8)
  725743:	01 
  725744:	49 83 dd ff          	sbb    $0xffffffffffffffff,%r13
  725748:	49 83 b8 78 ff ff ff 	cmpq   $0x1,-0x88(%r8)
  72574f:	01 
  725750:	49 83 dd ff          	sbb    $0xffffffffffffffff,%r13
  725754:	49 83 38 01          	cmpq   $0x1,(%r8)
  725758:	49 83 dd ff          	sbb    $0xffffffffffffffff,%r13
  72575c:	48 83 c6 04          	add    $0x4,%rsi
  725760:	49 81 c0 20 02 00 00 	add    $0x220,%r8
  725767:	48 39 f7             	cmp    %rsi,%rdi
  72576a:	75 c4                	jne    725730 <route_columns_cost::main::{closure#1}+0x300>
  72576c:	48 85 d2             	test   %rdx,%rdx
  72576f:	74 34                	je     7257a5 <route_columns_cost::main::{closure#1}+0x375>
  725771:	48 89 f7             	mov    %rsi,%rdi
  725774:	48 c1 e7 07          	shl    $0x7,%rdi
  725778:	48 8d 34 f7          	lea    (%rdi,%rsi,8),%rsi
  72577c:	48 01 c6             	add    %rax,%rsi
  72577f:	48 83 c6 58          	add    $0x58,%rsi
  725783:	89 d7                	mov    %edx,%edi
  725785:	c1 e2 07             	shl    $0x7,%edx
  725788:	8d 14 fa             	lea    (%rdx,%rdi,8),%edx
  72578b:	31 ff                	xor    %edi,%edi
  72578d:	0f 1f 00             	nopl   (%rax)
  725790:	48 83 3c 3e 01       	cmpq   $0x1,(%rsi,%rdi,1)
  725795:	49 83 dd ff          	sbb    $0xffffffffffffffff,%r13
  725799:	48 81 c7 88 00 00 00 	add    $0x88,%rdi
  7257a0:	48 39 fa             	cmp    %rdi,%rdx
  7257a3:	75 eb                	jne    725790 <route_columns_cost::main::{closure#1}+0x360>
  7257a5:	48 8b 94 24 b0 00 00 	mov    0xb0(%rsp),%rdx
  7257ac:	00 
  7257ad:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  7257b2:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
  7257b9:	00 
  7257ba:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  7257bf:	0f 28 04 24          	movaps (%rsp),%xmm0
  7257c3:	0f 28 4c 24 10       	movaps 0x10(%rsp),%xmm1
  7257c8:	0f 28 54 24 20       	movaps 0x20(%rsp),%xmm2
  7257cd:	48 8d 54 24 68       	lea    0x68(%rsp),%rdx
  7257d2:	0f 11 52 20          	movups %xmm2,0x20(%rdx)
  7257d6:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  7257da:	0f 11 02             	movups %xmm0,(%rdx)
  7257dd:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  7257e2:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  7257e7:	4c 8b 74 24 60       	mov    0x60(%rsp),%r14
  7257ec:	4d 85 f6             	test   %r14,%r14
  7257ef:	74 4f                	je     725840 <route_columns_cost::main::{closure#1}+0x410>
  7257f1:	48 8b 5c 24 58       	mov    0x58(%rsp),%rbx
  7257f6:	48 83 c3 30          	add    $0x30,%rbx
  7257fa:	eb 10                	jmp    72580c <route_columns_cost::main::{closure#1}+0x3dc>
  7257fc:	0f 1f 40 00          	nopl   0x0(%rax)
  725800:	48 81 c3 88 00 00 00 	add    $0x88,%rbx
  725807:	49 ff ce             	dec    %r14
  72580a:	74 34                	je     725840 <route_columns_cost::main::{closure#1}+0x410>
  72580c:	48 8b 73 e0          	mov    -0x20(%rbx),%rsi
  725810:	48 85 f6             	test   %rsi,%rsi
  725813:	74 0c                	je     725821 <route_columns_cost::main::{closure#1}+0x3f1>
  725815:	48 8b 7b e8          	mov    -0x18(%rbx),%rdi
  725819:	ba 01 00 00 00       	mov    $0x1,%edx
  72581e:	41 ff d7             	call   *%r15
  725821:	48 8b 73 f8          	mov    -0x8(%rbx),%rsi
  725825:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  725829:	74 d5                	je     725800 <route_columns_cost::main::{closure#1}+0x3d0>
  72582b:	48 85 f6             	test   %rsi,%rsi
  72582e:	74 d0                	je     725800 <route_columns_cost::main::{closure#1}+0x3d0>
  725830:	48 8b 3b             	mov    (%rbx),%rdi
  725833:	ba 01 00 00 00       	mov    $0x1,%edx
  725838:	41 ff d7             	call   *%r15
  72583b:	eb c3                	jmp    725800 <route_columns_cost::main::{closure#1}+0x3d0>
  72583d:	0f 1f 00             	nopl   (%rax)
  725840:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  725845:	48 85 c0             	test   %rax,%rax
  725848:	74 18                	je     725862 <route_columns_cost::main::{closure#1}+0x432>
  72584a:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  72584f:	48 89 c1             	mov    %rax,%rcx
  725852:	48 c1 e1 07          	shl    $0x7,%rcx
  725856:	48 8d 34 c1          	lea    (%rcx,%rax,8),%rsi
  72585a:	ba 08 00 00 00       	mov    $0x8,%edx
  72585f:	41 ff d7             	call   *%r15
  725862:	4c 01 ac 24 98 00 00 	add    %r13,0x98(%rsp)
  725869:	00 
  72586a:	48 8b 9c 24 c8 00 00 	mov    0xc8(%rsp),%rbx
  725871:	00 
  725872:	4c 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%r13
  725879:	00 
  72587a:	e9 4e fc ff ff       	jmp    7254cd <route_columns_cost::main::{closure#1}+0x9d>
  72587f:	31 d2                	xor    %edx,%edx
  725881:	f7 f6                	div    %esi
  725883:	48 c1 e2 04          	shl    $0x4,%rdx
  725887:	48 8b 04 11          	mov    (%rcx,%rdx,1),%rax
  72588b:	48 8b 4c 11 08       	mov    0x8(%rcx,%rdx,1),%rcx
  725890:	48 89 e7             	mov    %rsp,%rdi
  725893:	4c 89 ee             	mov    %r13,%rsi
  725896:	48 89 c2             	mov    %rax,%rdx
  725899:	e8 e2 af fc ff       	call   6f0880 <<gpui::runtime::Win<route_columns_cost::Page>>::activate>
  72589e:	83 3c 24 fe          	cmpl   $0xfffffffe,(%rsp)
  7258a2:	0f 85 90 01 00 00    	jne    725a38 <route_columns_cost::main::{closure#1}+0x608>
  7258a8:	48 8d 44 24 08       	lea    0x8(%rsp),%rax
  7258ad:	0f 10 00             	movups (%rax),%xmm0
  7258b0:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  7258b4:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  7258b8:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
  7258bd:	0f 29 4c 24 50       	movaps %xmm1,0x50(%rsp)
  7258c2:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  7258c7:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
  7258cc:	e9 fc fb ff ff       	jmp    7254cd <route_columns_cost::main::{closure#1}+0x9d>
  7258d1:	48 c7 84 24 98 00 00 	movq   $0x0,0x98(%rsp)
  7258d8:	00 00 00 00 00 
  7258dd:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  7258e4:	00 
  7258e5:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  7258ea:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
  7258ef:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  7258f4:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
  7258fb:	5b                   	pop    %rbx
  7258fc:	41 5c                	pop    %r12
  7258fe:	41 5d                	pop    %r13
  725900:	41 5e                	pop    %r14
  725902:	41 5f                	pop    %r15
  725904:	5d                   	pop    %rbp
  725905:	c3                   	ret
  725906:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  72590b:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  725910:	0f 10 04 24          	movups (%rsp),%xmm0
  725914:	0f 10 4c 24 10       	movups 0x10(%rsp),%xmm1
  725919:	0f 10 54 24 20       	movups 0x20(%rsp),%xmm2
  72591e:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
  725923:	0f 29 4c 24 50       	movaps %xmm1,0x50(%rsp)
  725928:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  72592d:	48 8d 3d 24 63 93 ff 	lea    -0x6c9cdc(%rip),%rdi        # 5bc58 <anon.f51c161c438ed3940b44c2d972769b2a.46.llvm.15107684175208838276+0x5>
  725934:	48 8d 0d 5d e9 33 00 	lea    0x33e95d(%rip),%rcx        # a64298 <anon.f51c161c438ed3940b44c2d972769b2a.47.llvm.15107684175208838276+0x28>
  72593b:	4c 8d 05 d6 e6 33 00 	lea    0x33e6d6(%rip),%r8        # a64018 <anon.88c98cabe1613f52270ff63fa18b1f54.58.llvm.6454285737220088098+0x80>
  725942:	48 8d 5c 24 40       	lea    0x40(%rsp),%rbx
  725947:	be 2b 00 00 00       	mov    $0x2b,%esi
  72594c:	48 89 da             	mov    %rbx,%rdx
  72594f:	ff 15 23 5f 36 00    	call   *0x365f23(%rip)        # a8b878 <_DYNAMIC+0x360>
  725955:	e9 2d 01 00 00       	jmp    725a87 <route_columns_cost::main::{closure#1}+0x657>
  72595a:	b8 1f 00 00 00       	mov    $0x1f,%eax
  72595f:	48 89 04 24          	mov    %rax,(%rsp)
  725963:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  725968:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  72596d:	0f 10 04 24          	movups (%rsp),%xmm0
  725971:	0f 10 4c 24 10       	movups 0x10(%rsp),%xmm1
  725976:	0f 10 54 24 20       	movups 0x20(%rsp),%xmm2
  72597b:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
  725980:	0f 29 4c 24 50       	movaps %xmm1,0x50(%rsp)
  725985:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  72598a:	48 8d 3d c7 62 93 ff 	lea    -0x6c9d39(%rip),%rdi        # 5bc58 <anon.f51c161c438ed3940b44c2d972769b2a.46.llvm.15107684175208838276+0x5>
  725991:	48 8d 0d 00 e9 33 00 	lea    0x33e900(%rip),%rcx        # a64298 <anon.f51c161c438ed3940b44c2d972769b2a.47.llvm.15107684175208838276+0x28>
  725998:	4c 8d 05 91 e6 33 00 	lea    0x33e691(%rip),%r8        # a64030 <anon.88c98cabe1613f52270ff63fa18b1f54.58.llvm.6454285737220088098+0x98>
  72599f:	48 8d 5c 24 40       	lea    0x40(%rsp),%rbx
  7259a4:	be 2b 00 00 00       	mov    $0x2b,%esi
  7259a9:	48 89 da             	mov    %rbx,%rdx
  7259ac:	ff 15 c6 5e 36 00    	call   *0x365ec6(%rip)        # a8b878 <_DYNAMIC+0x360>
  7259b2:	e9 d0 00 00 00       	jmp    725a87 <route_columns_cost::main::{closure#1}+0x657>
  7259b7:	48 8d 3d 96 61 93 ff 	lea    -0x6c9e6a(%rip),%rdi        # 5bb54 <anon.88c98cabe1613f52270ff63fa18b1f54.4.llvm.6454285737220088098+0x370>
  7259be:	48 8d 15 23 e6 33 00 	lea    0x33e623(%rip),%rdx        # a63fe8 <anon.88c98cabe1613f52270ff63fa18b1f54.58.llvm.6454285737220088098+0x50>
  7259c5:	be 13 00 00 00       	mov    $0x13,%esi
  7259ca:	ff 15 d8 5d 36 00    	call   *0x365dd8(%rip)        # a8b7a8 <_DYNAMIC+0x290>
  7259d0:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  7259d5:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  7259da:	0f 10 44 24 48       	movups 0x48(%rsp),%xmm0
  7259df:	0f 10 4c 24 58       	movups 0x58(%rsp),%xmm1
  7259e4:	0f 10 54 24 68       	movups 0x68(%rsp),%xmm2
  7259e9:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
  7259ee:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
  7259f3:	0f 29 04 24          	movaps %xmm0,(%rsp)
  7259f7:	48 8d 3d 5a 62 93 ff 	lea    -0x6c9da6(%rip),%rdi        # 5bc58 <anon.f51c161c438ed3940b44c2d972769b2a.46.llvm.15107684175208838276+0x5>
  7259fe:	48 8d 0d 93 e8 33 00 	lea    0x33e893(%rip),%rcx        # a64298 <anon.f51c161c438ed3940b44c2d972769b2a.47.llvm.15107684175208838276+0x28>
  725a05:	4c 8d 05 f4 e5 33 00 	lea    0x33e5f4(%rip),%r8        # a64000 <anon.88c98cabe1613f52270ff63fa18b1f54.58.llvm.6454285737220088098+0x68>
  725a0c:	48 89 e3             	mov    %rsp,%rbx
  725a0f:	be 2b 00 00 00       	mov    $0x2b,%esi
  725a14:	48 89 da             	mov    %rbx,%rdx
  725a17:	ff 15 5b 5e 36 00    	call   *0x365e5b(%rip)        # a8b878 <_DYNAMIC+0x360>
  725a1d:	eb 68                	jmp    725a87 <route_columns_cost::main::{closure#1}+0x657>
  725a1f:	48 8d 3d 37 61 93 ff 	lea    -0x6c9ec9(%rip),%rdi        # 5bb5d <anon.88c98cabe1613f52270ff63fa18b1f54.4.llvm.6454285737220088098+0x379>
  725a26:	48 8d 15 1b e6 33 00 	lea    0x33e61b(%rip),%rdx        # a64048 <anon.88c98cabe1613f52270ff63fa18b1f54.58.llvm.6454285737220088098+0xb0>
  725a2d:	be 25 00 00 00       	mov    $0x25,%esi
  725a32:	ff 15 50 5d 36 00    	call   *0x365d50(%rip)        # a8b788 <_DYNAMIC+0x270>
  725a38:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  725a3d:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  725a42:	0f 10 04 24          	movups (%rsp),%xmm0
  725a46:	0f 10 4c 24 10       	movups 0x10(%rsp),%xmm1
  725a4b:	0f 10 54 24 20       	movups 0x20(%rsp),%xmm2
  725a50:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
  725a55:	0f 29 4c 24 50       	movaps %xmm1,0x50(%rsp)
  725a5a:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  725a5f:	48 8d 3d f2 61 93 ff 	lea    -0x6c9e0e(%rip),%rdi        # 5bc58 <anon.f51c161c438ed3940b44c2d972769b2a.46.llvm.15107684175208838276+0x5>
  725a66:	48 8d 0d 2b e8 33 00 	lea    0x33e82b(%rip),%rcx        # a64298 <anon.f51c161c438ed3940b44c2d972769b2a.47.llvm.15107684175208838276+0x28>
  725a6d:	4c 8d 05 ec e5 33 00 	lea    0x33e5ec(%rip),%r8        # a64060 <anon.88c98cabe1613f52270ff63fa18b1f54.58.llvm.6454285737220088098+0xc8>
  725a74:	48 8d 5c 24 40       	lea    0x40(%rsp),%rbx
  725a79:	be 2b 00 00 00       	mov    $0x2b,%esi
  725a7e:	48 89 da             	mov    %rbx,%rdx
  725a81:	ff 15 f1 5d 36 00    	call   *0x365df1(%rip)        # a8b878 <_DYNAMIC+0x360>
  725a87:	0f 0b                	ud2
  725a89:	b8 0e 00 00 00       	mov    $0xe,%eax
  725a8e:	e9 cc fe ff ff       	jmp    72595f <route_columns_cost::main::{closure#1}+0x52f>
  725a93:	48 c7 04 24 0d 00 00 	movq   $0xd,(%rsp)
  725a9a:	00 
  725a9b:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
  725aa2:	00 00 
  725aa4:	e9 ba fe ff ff       	jmp    725963 <route_columns_cost::main::{closure#1}+0x533>
  725aa9:	eb 04                	jmp    725aaf <route_columns_cost::main::{closure#1}+0x67f>
  725aab:	eb 02                	jmp    725aaf <route_columns_cost::main::{closure#1}+0x67f>
  725aad:	eb 00                	jmp    725aaf <route_columns_cost::main::{closure#1}+0x67f>
  725aaf:	49 89 c6             	mov    %rax,%r14
  725ab2:	48 89 df             	mov    %rbx,%rdi
  725ab5:	e8 d6 ea ff ff       	call   724590 <core::ptr::drop_glue::<gpui::runtime::Error>>
  725aba:	4c 89 f7             	mov    %r14,%rdi
  725abd:	e8 ce b5 33 00       	call   a61090 <_Unwind_Resume@plt>
