
/tmp/gpui-route-topology-evidence/bin/topology-cost:     file format elf64-x86-64


Disassembly of section .text:

00000000006f0880 <<gpui::runtime::Win<route_columns_cost::Page>>::activate>:
  6f0880:	55                   	push   %rbp
  6f0881:	41 57                	push   %r15
  6f0883:	41 56                	push   %r14
  6f0885:	41 55                	push   %r13
  6f0887:	41 54                	push   %r12
  6f0889:	53                   	push   %rbx
  6f088a:	48 81 ec 98 00 00 00 	sub    $0x98,%rsp
  6f0891:	48 89 fb             	mov    %rdi,%rbx
  6f0894:	4c 8b 36             	mov    (%rsi),%r14
  6f0897:	4d 85 f6             	test   %r14,%r14
  6f089a:	74 2d                	je     6f08c9 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x49>
  6f089c:	48 83 c6 08          	add    $0x8,%rsi
  6f08a0:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
  6f08a5:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
  6f08aa:	48 c7 44 24 78 00 00 	movq   $0x0,0x78(%rsp)
  6f08b1:	00 00 
  6f08b3:	41 80 be 4e 07 00 00 	cmpb   $0x1,0x74e(%r14)
  6f08ba:	01 
  6f08bb:	75 20                	jne    6f08dd <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x5d>
  6f08bd:	48 c7 03 0e 00 00 00 	movq   $0xe,(%rbx)
  6f08c4:	e9 61 01 00 00       	jmp    6f0a2a <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f08c9:	48 c7 03 0d 00 00 00 	movq   $0xd,(%rbx)
  6f08d0:	48 c7 43 08 00 00 00 	movq   $0x0,0x8(%rbx)
  6f08d7:	00 
  6f08d8:	e9 4d 01 00 00       	jmp    6f0a2a <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f08dd:	49 89 f5             	mov    %rsi,%r13
  6f08e0:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  6f08e5:	4c 89 f6             	mov    %r14,%rsi
  6f08e8:	e8 93 64 00 00       	call   6f6d80 <<gpui::runtime::Runtime<route_columns_cost::Page>>::resolve_index>
  6f08ed:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  6f08f2:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  6f08f7:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6f08fb:	0f 85 fe 00 00 00    	jne    6f09ff <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x17f>
  6f0901:	49 8b b6 a0 02 00 00 	mov    0x2a0(%r14),%rsi
  6f0908:	49 39 f4             	cmp    %rsi,%r12
  6f090b:	0f 83 b6 02 00 00    	jae    6f0bc7 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x347>
  6f0911:	49 8b 86 98 02 00 00 	mov    0x298(%r14),%rax
  6f0918:	4b 8d 0c 64          	lea    (%r12,%r12,2),%rcx
  6f091c:	8b 54 c8 10          	mov    0x10(%rax,%rcx,8),%edx
  6f0920:	83 e2 0f             	and    $0xf,%edx
  6f0923:	8d 72 fd             	lea    -0x3(%rdx),%esi
  6f0926:	83 fe 07             	cmp    $0x7,%esi
  6f0929:	72 09                	jb     6f0934 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0xb4>
  6f092b:	83 fa 02             	cmp    $0x2,%edx
  6f092e:	0f 83 0b 01 00 00    	jae    6f0a3f <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1bf>
  6f0934:	48 8d 04 c8          	lea    (%rax,%rcx,8),%rax
  6f0938:	48 8b 78 08          	mov    0x8(%rax),%rdi
  6f093c:	48 c1 ef 22          	shr    $0x22,%rdi
  6f0940:	48 83 ef 01          	sub    $0x1,%rdi
  6f0944:	0f 82 d9 00 00 00    	jb     6f0a23 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1a3>
  6f094a:	49 8b b6 b8 05 00 00 	mov    0x5b8(%r14),%rsi
  6f0951:	48 39 f7             	cmp    %rsi,%rdi
  6f0954:	0f 83 7d 02 00 00    	jae    6f0bd7 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x357>
  6f095a:	4d 8b be b0 05 00 00 	mov    0x5b0(%r14),%r15
  6f0961:	48 c1 e7 04          	shl    $0x4,%rdi
  6f0965:	49 83 3c 3f 00       	cmpq   $0x0,(%r15,%rdi,1)
  6f096a:	0f 84 b3 00 00 00    	je     6f0a23 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1a3>
  6f0970:	49 01 ff             	add    %rdi,%r15
  6f0973:	49 8d 96 d0 05 00 00 	lea    0x5d0(%r14),%rdx
  6f097a:	4d 8d 86 28 02 00 00 	lea    0x228(%r14),%r8
  6f0981:	48 8d 0d 18 1d 37 00 	lea    0x371d18(%rip),%rcx        # a626a0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x1e0>
  6f0988:	4c 8d 0d 31 1d 37 00 	lea    0x371d31(%rip),%r9        # a626c0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x200>
  6f098f:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  6f0994:	4c 89 fe             	mov    %r15,%rsi
  6f0997:	ff 15 a3 b0 39 00    	call   *0x39b0a3(%rip)        # a8ba40 <_DYNAMIC+0x528>
  6f099d:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  6f09a2:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  6f09a7:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  6f09ac:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6f09b1:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  6f09b6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  6f09bb:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  6f09c0:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6f09c4:	0f 84 95 02 00 00    	je     6f0c5f <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x3df>
  6f09ca:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f09ce:	0f 85 a8 00 00 00    	jne    6f0a7c <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1fc>
  6f09d4:	66 85 ed             	test   %bp,%bp
  6f09d7:	0f 84 e8 00 00 00    	je     6f0ac5 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x245>
  6f09dd:	0f b7 c5             	movzwl %bp,%eax
  6f09e0:	83 f8 01             	cmp    $0x1,%eax
  6f09e3:	0f 85 86 01 00 00    	jne    6f0b6f <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x2ef>
  6f09e9:	48 c1 ed 10          	shr    $0x10,%rbp
  6f09ed:	48 89 df             	mov    %rbx,%rdi
  6f09f0:	4c 89 f6             	mov    %r14,%rsi
  6f09f3:	4c 89 ea             	mov    %r13,%rdx
  6f09f6:	89 e9                	mov    %ebp,%ecx
  6f09f8:	e8 c3 d8 ff ff       	call   6ee2c0 <<gpui::runtime::RuntimeMut<route_columns_cost::Page, ()>>::window_action>
  6f09fd:	eb 2b                	jmp    6f0a2a <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f09ff:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  6f0a04:	48 89 4b 30          	mov    %rcx,0x30(%rbx)
  6f0a08:	0f 10 44 24 40       	movups 0x40(%rsp),%xmm0
  6f0a0d:	0f 10 4c 24 50       	movups 0x50(%rsp),%xmm1
  6f0a12:	0f 11 4b 20          	movups %xmm1,0x20(%rbx)
  6f0a16:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
  6f0a1a:	48 89 03             	mov    %rax,(%rbx)
  6f0a1d:	4c 89 63 08          	mov    %r12,0x8(%rbx)
  6f0a21:	eb 07                	jmp    6f0a2a <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f0a23:	48 c7 03 16 00 00 00 	movq   $0x16,(%rbx)
  6f0a2a:	48 89 d8             	mov    %rbx,%rax
  6f0a2d:	48 81 c4 98 00 00 00 	add    $0x98,%rsp
  6f0a34:	5b                   	pop    %rbx
  6f0a35:	41 5c                	pop    %r12
  6f0a37:	41 5d                	pop    %r13
  6f0a39:	41 5e                	pop    %r14
  6f0a3b:	41 5f                	pop    %r15
  6f0a3d:	5d                   	pop    %rbp
  6f0a3e:	c3                   	ret
  6f0a3f:	0f 85 5d 01 00 00    	jne    6f0ba2 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x322>
  6f0a45:	49 c7 86 38 07 00 00 	movq   $0x0,0x738(%r14)
  6f0a4c:	00 00 00 00 
  6f0a50:	41 0f 10 86 90 06 00 	movups 0x690(%r14),%xmm0
  6f0a57:	00 
  6f0a58:	41 0f b6 86 4c 07 00 	movzbl 0x74c(%r14),%eax
  6f0a5f:	00 
  6f0a60:	49 83 be b0 06 00 00 	cmpq   $0x0,0x6b0(%r14)
  6f0a67:	00 
  6f0a68:	74 0e                	je     6f0a78 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1f8>
  6f0a6a:	84 c0                	test   %al,%al
  6f0a6c:	74 28                	je     6f0a96 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x216>
  6f0a6e:	49 83 be 88 05 00 00 	cmpq   $0xffffffffffffffff,0x588(%r14)
  6f0a75:	ff 
  6f0a76:	75 1e                	jne    6f0a96 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x216>
  6f0a78:	31 c9                	xor    %ecx,%ecx
  6f0a7a:	eb 26                	jmp    6f0aa2 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x222>
  6f0a7c:	48 c7 03 20 00 00 00 	movq   $0x20,(%rbx)
  6f0a83:	48 89 43 08          	mov    %rax,0x8(%rbx)
  6f0a87:	48 89 6b 10          	mov    %rbp,0x10(%rbx)
  6f0a8b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f0a90:	48 89 43 18          	mov    %rax,0x18(%rbx)
  6f0a94:	eb 94                	jmp    6f0a2a <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f0a96:	49 8b 96 c0 06 00 00 	mov    0x6c0(%r14),%rdx
  6f0a9d:	b9 01 00 00 00       	mov    $0x1,%ecx
  6f0aa2:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
  6f0aa6:	48 89 53 10          	mov    %rdx,0x10(%rbx)
  6f0aaa:	0f 11 43 18          	movups %xmm0,0x18(%rbx)
  6f0aae:	48 c7 43 28 00 00 00 	movq   $0x0,0x28(%rbx)
  6f0ab5:	00 
  6f0ab6:	88 43 30             	mov    %al,0x30(%rbx)
  6f0ab9:	48 c7 03 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rbx)
  6f0ac0:	e9 65 ff ff ff       	jmp    6f0a2a <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f0ac5:	4d 8b a6 90 06 00 00 	mov    0x690(%r14),%r12
  6f0acc:	49 ff c4             	inc    %r12
  6f0acf:	0f 84 e6 00 00 00    	je     6f0bbb <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x33b>
  6f0ad5:	48 c7 44 24 30 1f 00 	movq   $0x1f,0x30(%rsp)
  6f0adc:	00 00 
  6f0ade:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  6f0ae3:	e8 08 47 ff ff       	call   6e51f0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6f0ae8:	48 8d 0d b1 1b 37 00 	lea    0x371bb1(%rip),%rcx        # a626a0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x1e0>
  6f0aef:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  6f0af4:	4c 89 fe             	mov    %r15,%rsi
  6f0af7:	49 8d 96 d0 05 00 00 	lea    0x5d0(%r14),%rdx
  6f0afe:	ff 15 44 af 39 00    	call   *0x39af44(%rip)        # a8ba48 <_DYNAMIC+0x530>
  6f0b04:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  6f0b09:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  6f0b0e:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  6f0b13:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  6f0b18:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  6f0b1d:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6f0b21:	0f 84 d9 00 00 00    	je     6f0c00 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x380>
  6f0b27:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6f0b2b:	75 5c                	jne    6f0b89 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x309>
  6f0b2d:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  6f0b32:	e8 99 23 ff ff       	call   6e2ed0 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6f0b37:	4d 89 a6 90 06 00 00 	mov    %r12,0x690(%r14)
  6f0b3e:	49 ff 86 e0 06 00 00 	incq   0x6e0(%r14)
  6f0b45:	49 c7 86 38 07 00 00 	movq   $0x0,0x738(%r14)
  6f0b4c:	00 00 00 00 
  6f0b50:	48 8d 74 24 68       	lea    0x68(%rsp),%rsi
  6f0b55:	48 8d 4c 24 78       	lea    0x78(%rsp),%rcx
  6f0b5a:	48 89 df             	mov    %rbx,%rdi
  6f0b5d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6f0b62:	45 31 c0             	xor    %r8d,%r8d
  6f0b65:	e8 d6 83 ff ff       	call   6e8f40 <<gpui::runtime::RuntimeMut<route_columns_cost::Page, ()>>::after_source_changed>
  6f0b6a:	e9 bb fe ff ff       	jmp    6f0a2a <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f0b6f:	48 8d 74 24 68       	lea    0x68(%rsp),%rsi
  6f0b74:	48 8d 4c 24 78       	lea    0x78(%rsp),%rcx
  6f0b79:	48 89 df             	mov    %rbx,%rdi
  6f0b7c:	4c 89 e2             	mov    %r12,%rdx
  6f0b7f:	e8 6c 77 ff ff       	call   6e82f0 <<gpui::runtime::RuntimeMut<route_columns_cost::Page, ()>>::activate_property>
  6f0b84:	e9 a1 fe ff ff       	jmp    6f0a2a <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f0b89:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
  6f0b8e:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
  6f0b92:	48 c7 03 20 00 00 00 	movq   $0x20,(%rbx)
  6f0b99:	48 89 43 08          	mov    %rax,0x8(%rbx)
  6f0b9d:	e9 88 fe ff ff       	jmp    6f0a2a <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f0ba2:	48 8d 3d ad 9e 96 ff 	lea    -0x696153(%rip),%rdi        # 5aa56 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2d8e>
  6f0ba9:	48 8d 15 40 23 37 00 	lea    0x372340(%rip),%rdx        # a62ef0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa30>
  6f0bb0:	be 83 00 00 00       	mov    $0x83,%esi
  6f0bb5:	ff 15 ed ab 39 00    	call   *0x39abed(%rip)        # a8b7a8 <_DYNAMIC+0x290>
  6f0bbb:	48 c7 03 1f 00 00 00 	movq   $0x1f,(%rbx)
  6f0bc2:	e9 63 fe ff ff       	jmp    6f0a2a <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f0bc7:	48 8d 15 5a 1f 37 00 	lea    0x371f5a(%rip),%rdx        # a62b28 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x668>
  6f0bce:	4c 89 e7             	mov    %r12,%rdi
  6f0bd1:	ff 15 a9 ac 39 00    	call   *0x39aca9(%rip)        # a8b880 <_DYNAMIC+0x368>
  6f0bd7:	48 8d 15 62 1f 37 00 	lea    0x371f62(%rip),%rdx        # a62b40 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0x680>
  6f0bde:	ff 15 9c ac 39 00    	call   *0x39ac9c(%rip)        # a8b880 <_DYNAMIC+0x368>
  6f0be4:	48 89 c7             	mov    %rax,%rdi
  6f0be7:	ff 15 c3 ac 39 00    	call   *0x39acc3(%rip)        # a8b8b0 <_DYNAMIC+0x398>
  6f0bed:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6f0bf2:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
  6f0bf7:	48 c7 44 24 10 fe ff 	movq   $0xfffffffffffffffe,0x10(%rsp)
  6f0bfe:	ff ff 
  6f0c00:	4c 89 f7             	mov    %r14,%rdi
  6f0c03:	e8 78 e3 00 00       	call   6fef80 <<gpui::runtime::Runtime<route_columns_cost::Page>>::poison>
  6f0c08:	48 c7 03 0f 00 00 00 	movq   $0xf,(%rbx)
  6f0c0f:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  6f0c14:	e8 b7 22 ff ff       	call   6e2ed0 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6f0c19:	e9 0c fe ff ff       	jmp    6f0a2a <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f0c1e:	ff 15 94 ac 39 00    	call   *0x39ac94(%rip)        # a8b8b8 <_DYNAMIC+0x3a0>
  6f0c24:	48 89 c3             	mov    %rax,%rbx
  6f0c27:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  6f0c2c:	e8 9f 22 ff ff       	call   6e2ed0 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6f0c31:	e9 a2 00 00 00       	jmp    6f0cd8 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x458>
  6f0c36:	48 89 c7             	mov    %rax,%rdi
  6f0c39:	ff 15 71 ac 39 00    	call   *0x39ac71(%rip)        # a8b8b0 <_DYNAMIC+0x398>
  6f0c3f:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
  6f0c44:	48 89 c5             	mov    %rax,%rbp
  6f0c47:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6f0c4c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f0c51:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6f0c56:	48 c7 44 24 10 fe ff 	movq   $0xfffffffffffffffe,0x10(%rsp)
  6f0c5d:	ff ff 
  6f0c5f:	4c 89 f7             	mov    %r14,%rdi
  6f0c62:	e8 19 e3 00 00       	call   6fef80 <<gpui::runtime::Runtime<route_columns_cost::Page>>::poison>
  6f0c67:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  6f0c6c:	48 c7 03 0f 00 00 00 	movq   $0xf,(%rbx)
  6f0c73:	49 8b 06             	mov    (%r14),%rax
  6f0c76:	48 85 c0             	test   %rax,%rax
  6f0c79:	74 05                	je     6f0c80 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x400>
  6f0c7b:	48 89 ef             	mov    %rbp,%rdi
  6f0c7e:	ff d0                	call   *%rax
  6f0c80:	49 8b 76 08          	mov    0x8(%r14),%rsi
  6f0c84:	48 85 f6             	test   %rsi,%rsi
  6f0c87:	0f 84 9d fd ff ff    	je     6f0a2a <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f0c8d:	49 8b 56 10          	mov    0x10(%r14),%rdx
  6f0c91:	48 89 ef             	mov    %rbp,%rdi
  6f0c94:	ff 15 ce aa 39 00    	call   *0x39aace(%rip)        # a8b768 <_DYNAMIC+0x250>
  6f0c9a:	e9 8b fd ff ff       	jmp    6f0a2a <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x1aa>
  6f0c9f:	ff 15 13 ac 39 00    	call   *0x39ac13(%rip)        # a8b8b8 <_DYNAMIC+0x3a0>
  6f0ca5:	48 89 c3             	mov    %rax,%rbx
  6f0ca8:	49 8b 76 08          	mov    0x8(%r14),%rsi
  6f0cac:	48 85 f6             	test   %rsi,%rsi
  6f0caf:	74 27                	je     6f0cd8 <<gpui::runtime::Win<route_columns_cost::Page>>::activate+0x458>
  6f0cb1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f0cb6:	48 8b 50 10          	mov    0x10(%rax),%rdx
  6f0cba:	48 89 ef             	mov    %rbp,%rdi
  6f0cbd:	ff 15 a5 aa 39 00    	call   *0x39aaa5(%rip)        # a8b768 <_DYNAMIC+0x250>
  6f0cc3:	48 89 df             	mov    %rbx,%rdi
  6f0cc6:	e8 c5 03 37 00       	call   a61090 <_Unwind_Resume@plt>
  6f0ccb:	48 89 c3             	mov    %rax,%rbx
  6f0cce:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  6f0cd3:	e8 f8 21 ff ff       	call   6e2ed0 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6f0cd8:	48 89 df             	mov    %rbx,%rdi
  6f0cdb:	e8 b0 03 37 00       	call   a61090 <_Unwind_Resume@plt>
  6f0ce0:	ff 15 ba aa 39 00    	call   *0x39aaba(%rip)        # a8b7a0 <_DYNAMIC+0x288>
