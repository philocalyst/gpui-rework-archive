
/tmp/gpui-route-topology-evidence/bin/topology-cost:     file format elf64-x86-64


Disassembly of section .text:

0000000000732b00 <<gpui::runtime::Node>::focusable>:
  732b00:	8b 4f 10             	mov    0x10(%rdi),%ecx
  732b03:	83 e1 0f             	and    $0xf,%ecx
  732b06:	83 f9 0a             	cmp    $0xa,%ecx
  732b09:	73 17                	jae    732b22 <<gpui::runtime::Node>::focusable+0x22>
  732b0b:	ba 0c 00 00 00       	mov    $0xc,%edx
  732b10:	d3 ea                	shr    %cl,%edx
  732b12:	48 8b 47 08          	mov    0x8(%rdi),%rax
  732b16:	48 c1 e8 22          	shr    $0x22,%rax
  732b1a:	0f 95 c0             	setne  %al
  732b1d:	08 d0                	or     %dl,%al
  732b1f:	24 01                	and    $0x1,%al
  732b21:	c3                   	ret
  732b22:	50                   	push   %rax
  732b23:	48 8d 3d 15 9b 92 ff 	lea    -0x6d64eb(%rip),%rdi        # 5c63f <anon.b9946fe4defe8b854d134b4bf5265d75.25.llvm.10307981152027530048+0x1fb>
  732b2a:	48 8d 15 27 23 33 00 	lea    0x332327(%rip),%rdx        # a64e58 <anon.b9946fe4defe8b854d134b4bf5265d75.26.llvm.10307981152027530048+0xf0>
  732b31:	be 83 00 00 00       	mov    $0x83,%esi
  732b36:	ff 15 6c 8c 35 00    	call   *0x358c6c(%rip)        # a8b7a8 <_DYNAMIC+0x290>
