
/tmp/gpui-route-topology-evidence/bin/topology-cost:     file format elf64-x86-64


Disassembly of section .text:

00000000006efe20 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets>:
  6efe20:	55                   	push   %rbp
  6efe21:	41 57                	push   %r15
  6efe23:	41 56                	push   %r14
  6efe25:	41 55                	push   %r13
  6efe27:	41 54                	push   %r12
  6efe29:	53                   	push   %rbx
  6efe2a:	48 81 ec 78 01 00 00 	sub    $0x178,%rsp
  6efe31:	89 54 24 34          	mov    %edx,0x34(%rsp)
  6efe35:	48 8b 2e             	mov    (%rsi),%rbp
  6efe38:	48 85 ed             	test   %rbp,%rbp
  6efe3b:	74 35                	je     6efe72 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x52>
  6efe3d:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
  6efe42:	4c 8b bd 80 05 00 00 	mov    0x580(%rbp),%r15
  6efe49:	4c 89 f8             	mov    %r15,%rax
  6efe4c:	48 c1 e0 07          	shl    $0x7,%rax
  6efe50:	4a 8d 1c f8          	lea    (%rax,%r15,8),%rbx
  6efe54:	48 b8 f0 f0 f0 f0 f0 	movabs $0xf0f0f0f0f0f0f0,%rax
  6efe5b:	f0 f0 00 
  6efe5e:	49 39 c7             	cmp    %rax,%r15
  6efe61:	76 23                	jbe    6efe86 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x66>
  6efe63:	45 31 f6             	xor    %r14d,%r14d
  6efe66:	4c 89 f7             	mov    %r14,%rdi
  6efe69:	48 89 de             	mov    %rbx,%rsi
  6efe6c:	ff 15 be b9 39 00    	call   *0x39b9be(%rip)        # a8b830 <_DYNAMIC+0x318>
  6efe72:	48 c7 47 08 0d 00 00 	movq   $0xd,0x8(%rdi)
  6efe79:	00 
  6efe7a:	48 c7 07 02 00 00 00 	movq   $0x2,(%rdi)
  6efe81:	e9 25 06 00 00       	jmp    6f04ab <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x68b>
  6efe86:	48 85 db             	test   %rbx,%rbx
  6efe89:	74 21                	je     6efeac <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x8c>
  6efe8b:	ff 15 c7 b8 39 00    	call   *0x39b8c7(%rip)        # a8b758 <_DYNAMIC+0x240>
  6efe91:	41 be 08 00 00 00    	mov    $0x8,%r14d
  6efe97:	be 08 00 00 00       	mov    $0x8,%esi
  6efe9c:	48 89 df             	mov    %rbx,%rdi
  6efe9f:	ff 15 bb b8 39 00    	call   *0x39b8bb(%rip)        # a8b760 <_DYNAMIC+0x248>
  6efea5:	48 85 c0             	test   %rax,%rax
  6efea8:	75 0a                	jne    6efeb4 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x94>
  6efeaa:	eb ba                	jmp    6efe66 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x46>
  6efeac:	b8 08 00 00 00       	mov    $0x8,%eax
  6efeb1:	45 31 ff             	xor    %r15d,%r15d
  6efeb4:	4c 89 7c 24 38       	mov    %r15,0x38(%rsp)
  6efeb9:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6efebe:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
  6efec5:	00 00 
  6efec7:	48 8b 85 40 06 00 00 	mov    0x640(%rbp),%rax
  6efece:	48 85 c0             	test   %rax,%rax
  6efed1:	74 33                	je     6eff06 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0xe6>
  6efed3:	48 8b b0 00 01 00 00 	mov    0x100(%rax),%rsi
  6efeda:	48 85 f6             	test   %rsi,%rsi
  6efedd:	74 27                	je     6eff06 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0xe6>
  6efedf:	48 8d bc 24 38 01 00 	lea    0x138(%rsp),%rdi
  6efee6:	00 
  6efee7:	ff 15 33 bb 39 00    	call   *0x39bb33(%rip)        # a8ba20 <_DYNAMIC+0x508>
  6efeed:	48 8b 85 80 05 00 00 	mov    0x580(%rbp),%rax
  6efef4:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6efefb:	00 
  6efefc:	48 85 c0             	test   %rax,%rax
  6efeff:	75 34                	jne    6eff35 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x115>
  6eff01:	e9 1b 05 00 00       	jmp    6f0421 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x601>
  6eff06:	48 c7 84 24 38 01 00 	movq   $0x4,0x138(%rsp)
  6eff0d:	00 04 00 00 00 
  6eff12:	0f 57 c0             	xorps  %xmm0,%xmm0
  6eff15:	0f 11 84 24 40 01 00 	movups %xmm0,0x140(%rsp)
  6eff1c:	00 
  6eff1d:	48 8b 85 80 05 00 00 	mov    0x580(%rbp),%rax
  6eff24:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6eff2b:	00 
  6eff2c:	48 85 c0             	test   %rax,%rax
  6eff2f:	0f 84 ec 04 00 00    	je     6f0421 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x601>
  6eff35:	48 8d 85 c0 05 00 00 	lea    0x5c0(%rbp),%rax
  6eff3c:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  6eff41:	45 31 e4             	xor    %r12d,%r12d
  6eff44:	48 8d 05 bd 2f 37 00 	lea    0x372fbd(%rip),%rax        # a62f08 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa48>
  6eff4b:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6eff50:	48 89 6c 24 78       	mov    %rbp,0x78(%rsp)
  6eff55:	eb 52                	jmp    6effa9 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x189>
  6eff57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6eff5e:	00 00 
  6eff60:	4c 8b a4 24 98 00 00 	mov    0x98(%rsp),%r12
  6eff67:	00 
  6eff68:	49 ff c4             	inc    %r12
  6eff6b:	48 89 d8             	mov    %rbx,%rax
  6eff6e:	48 c1 e0 07          	shl    $0x7,%rax
  6eff72:	48 8d 3c d8          	lea    (%rax,%rbx,8),%rdi
  6eff76:	48 03 7c 24 40       	add    0x40(%rsp),%rdi
  6eff7b:	ba 88 00 00 00       	mov    $0x88,%edx
  6eff80:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
  6eff87:	00 
  6eff88:	ff 15 ea b7 39 00    	call   *0x39b7ea(%rip)        # a8b778 <memcpy@GLIBC_2.14>
  6eff8e:	48 ff c3             	inc    %rbx
  6eff91:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
  6eff96:	4c 3b a4 24 80 00 00 	cmp    0x80(%rsp),%r12
  6eff9d:	00 
  6eff9e:	48 8b 6c 24 78       	mov    0x78(%rsp),%rbp
  6effa3:	0f 84 78 04 00 00    	je     6f0421 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x601>
  6effa9:	48 8b b5 80 05 00 00 	mov    0x580(%rbp),%rsi
  6effb0:	49 39 f4             	cmp    %rsi,%r12
  6effb3:	0f 83 07 05 00 00    	jae    6f04c0 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6a0>
  6effb9:	48 8b 9d 78 05 00 00 	mov    0x578(%rbp),%rbx
  6effc0:	4c 89 a4 24 98 00 00 	mov    %r12,0x98(%rsp)
  6effc7:	00 
  6effc8:	49 c1 e4 06          	shl    $0x6,%r12
  6effcc:	4e 8b 44 23 20       	mov    0x20(%rbx,%r12,1),%r8
  6effd1:	80 bd 4a 07 00 00 00 	cmpb   $0x0,0x74a(%rbp)
  6effd8:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
  6effdd:	4c 89 44 24 68       	mov    %r8,0x68(%rsp)
  6effe2:	74 0d                	je     6efff1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6effe4:	80 bd 4e 07 00 00 00 	cmpb   $0x0,0x74e(%rbp)
  6effeb:	0f 84 0f 01 00 00    	je     6f0100 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x2e0>
  6efff1:	45 31 ff             	xor    %r15d,%r15d
  6efff4:	4c 01 e3             	add    %r12,%rbx
  6efff7:	44 8b 63 38          	mov    0x38(%rbx),%r12d
  6efffb:	41 81 e4 ff ff 01 00 	and    $0x1ffff,%r12d
  6f0002:	45 31 ed             	xor    %r13d,%r13d
  6f0005:	49 81 fc ff ff 01 00 	cmp    $0x1ffff,%r12
  6f000c:	0f 95 44 24 0e       	setne  0xe(%rsp)
  6f0011:	0f b6 43 3d          	movzbl 0x3d(%rbx),%eax
  6f0015:	2c 02                	sub    $0x2,%al
  6f0017:	0f b6 c0             	movzbl %al,%eax
  6f001a:	b9 08 00 00 00       	mov    $0x8,%ecx
  6f001f:	0f 42 c1             	cmovb  %ecx,%eax
  6f0022:	88 44 24 0f          	mov    %al,0xf(%rsp)
  6f0026:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
  6f002b:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6f0032:	00 
  6f0033:	48 8d 05 c6 0a 01 00 	lea    0x10ac6(%rip),%rax        # 700b00 <<gpui::element::Role as core::fmt::Debug>::fmt>
  6f003a:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  6f0041:	00 
  6f0042:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  6f0049:	00 
  6f004a:	48 8d 35 be e9 95 ff 	lea    -0x6a1642(%rip),%rsi        # 4ea0f <anon.5558d0fc2e5366f92fec9016dadbf867.4.llvm.9438347653228867760>
  6f0051:	48 8d 94 24 a0 00 00 	lea    0xa0(%rsp),%rdx
  6f0058:	00 
  6f0059:	ff 15 c9 b9 39 00    	call   *0x39b9c9(%rip)        # a8ba28 <_DYNAMIC+0x510>
  6f005f:	4c 8b b4 24 b0 00 00 	mov    0xb0(%rsp),%r14
  6f0066:	00 
  6f0067:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  6f006e:	00 
  6f006f:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
  6f0076:	00 
  6f0077:	48 8b 6b 28          	mov    0x28(%rbx),%rbp
  6f007b:	48 85 ed             	test   %rbp,%rbp
  6f007e:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f0083:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  6f008a:	00 
  6f008b:	74 63                	je     6f00f0 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x2d0>
  6f008d:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
  6f0092:	4c 8b 75 00          	mov    0x0(%rbp),%r14
  6f0096:	49 d1 ee             	shr    $1,%r14
  6f0099:	0f 84 11 01 00 00    	je     6f01b0 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x390>
  6f009f:	ff 15 b3 b6 39 00    	call   *0x39b6b3(%rip)        # a8b758 <_DYNAMIC+0x240>
  6f00a5:	be 01 00 00 00       	mov    $0x1,%esi
  6f00aa:	4c 89 f7             	mov    %r14,%rdi
  6f00ad:	ff 15 ad b6 39 00    	call   *0x39b6ad(%rip)        # a8b760 <_DYNAMIC+0x248>
  6f00b3:	48 85 c0             	test   %rax,%rax
  6f00b6:	0f 84 2f 04 00 00    	je     6f04eb <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6cb>
  6f00bc:	48 83 c5 10          	add    $0x10,%rbp
  6f00c0:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6f00c5:	48 89 c7             	mov    %rax,%rdi
  6f00c8:	48 89 ee             	mov    %rbp,%rsi
  6f00cb:	4c 89 f2             	mov    %r14,%rdx
  6f00ce:	ff 15 a4 b6 39 00    	call   *0x39b6a4(%rip)        # a8b778 <memcpy@GLIBC_2.14>
  6f00d4:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
  6f00d9:	4c 89 f5             	mov    %r14,%rbp
  6f00dc:	e9 e4 00 00 00       	jmp    6f01c5 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x3a5>
  6f00e1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f00e8:	0f 1f 84 00 00 00 00 
  6f00ef:	00 
  6f00f0:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
  6f00f7:	e9 ce 00 00 00       	jmp    6f01ca <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x3aa>
  6f00fc:	0f 1f 40 00          	nopl   0x0(%rax)
  6f0100:	48 8b 85 e8 01 00 00 	mov    0x1e8(%rbp),%rax
  6f0107:	48 85 c0             	test   %rax,%rax
  6f010a:	0f 84 f3 01 00 00    	je     6f0303 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x4e3>
  6f0110:	83 f8 01             	cmp    $0x1,%eax
  6f0113:	0f 85 17 02 00 00    	jne    6f0330 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x510>
  6f0119:	4c 8b bd f8 01 00 00 	mov    0x1f8(%rbp),%r15
  6f0120:	4d 85 ff             	test   %r15,%r15
  6f0123:	0f 84 38 02 00 00    	je     6f0361 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x541>
  6f0129:	48 8b 85 f0 01 00 00 	mov    0x1f0(%rbp),%rax
  6f0130:	31 c9                	xor    %ecx,%ecx
  6f0132:	49 83 ff 01          	cmp    $0x1,%r15
  6f0136:	74 2c                	je     6f0164 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x344>
  6f0138:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6f013f:	00 
  6f0140:	48 89 ca             	mov    %rcx,%rdx
  6f0143:	4c 89 fe             	mov    %r15,%rsi
  6f0146:	48 d1 ee             	shr    $1,%rsi
  6f0149:	48 01 f1             	add    %rsi,%rcx
  6f014c:	48 89 cf             	mov    %rcx,%rdi
  6f014f:	48 c1 e7 04          	shl    $0x4,%rdi
  6f0153:	4c 39 04 38          	cmp    %r8,(%rax,%rdi,1)
  6f0157:	48 0f 47 ca          	cmova  %rdx,%rcx
  6f015b:	49 29 f7             	sub    %rsi,%r15
  6f015e:	49 83 ff 01          	cmp    $0x1,%r15
  6f0162:	77 dc                	ja     6f0140 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x320>
  6f0164:	48 89 ce             	mov    %rcx,%rsi
  6f0167:	48 c1 e6 04          	shl    $0x4,%rsi
  6f016b:	31 d2                	xor    %edx,%edx
  6f016d:	4c 39 04 30          	cmp    %r8,(%rax,%rsi,1)
  6f0171:	0f 96 c2             	setbe  %dl
  6f0174:	48 01 ca             	add    %rcx,%rdx
  6f0177:	0f 84 74 fe ff ff    	je     6efff1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f017d:	48 c1 e2 04          	shl    $0x4,%rdx
  6f0181:	4c 89 c1             	mov    %r8,%rcx
  6f0184:	48 2b 4c 10 f0       	sub    -0x10(%rax,%rdx,1),%rcx
  6f0189:	8b 74 10 fc          	mov    -0x4(%rax,%rdx,1),%esi
  6f018d:	48 39 f1             	cmp    %rsi,%rcx
  6f0190:	0f 83 5b fe ff ff    	jae    6efff1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f0196:	48 01 d0             	add    %rdx,%rax
  6f0199:	8b 40 f8             	mov    -0x8(%rax),%eax
  6f019c:	48 01 c1             	add    %rax,%rcx
  6f019f:	80 7c 24 34 00       	cmpb   $0x0,0x34(%rsp)
  6f01a4:	0f 84 03 02 00 00    	je     6f03ad <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x58d>
  6f01aa:	e9 54 02 00 00       	jmp    6f0403 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5e3>
  6f01af:	90                   	nop
  6f01b0:	b8 01 00 00 00       	mov    $0x1,%eax
  6f01b5:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6f01ba:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
  6f01c1:	00 00 
  6f01c3:	31 ed                	xor    %ebp,%ebp
  6f01c5:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
  6f01ca:	0f 10 43 10          	movups 0x10(%rbx),%xmm0
  6f01ce:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  6f01d3:	48 8d bc 24 38 01 00 	lea    0x138(%rsp),%rdi
  6f01da:	00 
  6f01db:	ff 15 4f b8 39 00    	call   *0x39b84f(%rip)        # a8ba30 <_DYNAMIC+0x518>
  6f01e1:	48 89 d1             	mov    %rdx,%rcx
  6f01e4:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  6f01eb:	00 
  6f01ec:	48 89 de             	mov    %rbx,%rsi
  6f01ef:	48 89 c2             	mov    %rax,%rdx
  6f01f2:	ff 15 40 b8 39 00    	call   *0x39b840(%rip)        # a8ba38 <_DYNAMIC+0x520>
  6f01f8:	8b 84 24 b0 00 00 00 	mov    0xb0(%rsp),%eax
  6f01ff:	85 c0                	test   %eax,%eax
  6f0201:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  6f0206:	75 18                	jne    6f0220 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x400>
  6f0208:	0f 28 84 24 60 01 00 	movaps 0x160(%rsp),%xmm0
  6f020f:	00 
  6f0210:	0f 28 8c 24 50 01 00 	movaps 0x150(%rsp),%xmm1
  6f0217:	00 
  6f0218:	eb 17                	jmp    6f0231 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x411>
  6f021a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  6f0220:	0f 10 84 24 b4 00 00 	movups 0xb4(%rsp),%xmm0
  6f0227:	00 
  6f0228:	f2 0f 10 8c 24 c4 00 	movsd  0xc4(%rsp),%xmm1
  6f022f:	00 00 
  6f0231:	0f b6 4c 24 0e       	movzbl 0xe(%rsp),%ecx
  6f0236:	41 88 cd             	mov    %cl,%r13b
  6f0239:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  6f023e:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
  6f0245:	00 
  6f0246:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
  6f024d:	00 
  6f024e:	4c 89 a4 24 b8 00 00 	mov    %r12,0xb8(%rsp)
  6f0255:	00 
  6f0256:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
  6f025d:	00 
  6f025e:	48 89 94 24 c8 00 00 	mov    %rdx,0xc8(%rsp)
  6f0265:	00 
  6f0266:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  6f026d:	00 
  6f026e:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
  6f0275:	00 
  6f0276:	48 89 ac 24 d8 00 00 	mov    %rbp,0xd8(%rsp)
  6f027d:	00 
  6f027e:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  6f0283:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
  6f028a:	00 
  6f028b:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
  6f0290:	4c 89 b4 24 e8 00 00 	mov    %r14,0xe8(%rsp)
  6f0297:	00 
  6f0298:	0f 28 54 24 10       	movaps 0x10(%rsp),%xmm2
  6f029d:	0f 11 94 24 f8 00 00 	movups %xmm2,0xf8(%rsp)
  6f02a4:	00 
  6f02a5:	89 84 24 18 01 00 00 	mov    %eax,0x118(%rsp)
  6f02ac:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  6f02b3:	00 
  6f02b4:	0f 11 84 24 1c 01 00 	movups %xmm0,0x11c(%rsp)
  6f02bb:	00 
  6f02bc:	0f 29 8c 24 50 01 00 	movaps %xmm1,0x150(%rsp)
  6f02c3:	00 
  6f02c4:	0f 13 8c 24 2c 01 00 	movlps %xmm1,0x12c(%rsp)
  6f02cb:	00 
  6f02cc:	4c 89 bc 24 08 01 00 	mov    %r15,0x108(%rsp)
  6f02d3:	00 
  6f02d4:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  6f02db:	00 
  6f02dc:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
  6f02e3:	00 
  6f02e4:	48 8b 5c 24 48       	mov    0x48(%rsp),%rbx
  6f02e9:	48 3b 5c 24 38       	cmp    0x38(%rsp),%rbx
  6f02ee:	0f 85 6c fc ff ff    	jne    6eff60 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x140>
  6f02f4:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  6f02f9:	e8 b2 0b 03 00       	call   720eb0 <<alloc::raw_vec::RawVec<gpui::runtime::SnapshotNode>>::grow_one>
  6f02fe:	e9 5d fc ff ff       	jmp    6eff60 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x140>
  6f0303:	4c 89 c1             	mov    %r8,%rcx
  6f0306:	48 2b 8d f0 01 00 00 	sub    0x1f0(%rbp),%rcx
  6f030d:	0f 82 de fc ff ff    	jb     6efff1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f0313:	48 3b 8d f8 01 00 00 	cmp    0x1f8(%rbp),%rcx
  6f031a:	0f 83 d1 fc ff ff    	jae    6efff1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f0320:	80 7c 24 34 00       	cmpb   $0x0,0x34(%rsp)
  6f0325:	0f 84 82 00 00 00    	je     6f03ad <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x58d>
  6f032b:	e9 d3 00 00 00       	jmp    6f0403 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5e3>
  6f0330:	4c 8b bd f8 01 00 00 	mov    0x1f8(%rbp),%r15
  6f0337:	4d 85 ff             	test   %r15,%r15
  6f033a:	74 25                	je     6f0361 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x541>
  6f033c:	48 8b 85 f0 01 00 00 	mov    0x1f0(%rbp),%rax
  6f0343:	49 83 ff 01          	cmp    $0x1,%r15
  6f0347:	75 1d                	jne    6f0366 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x546>
  6f0349:	4c 39 00             	cmp    %r8,(%rax)
  6f034c:	0f 85 9f fc ff ff    	jne    6efff1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f0352:	8b 48 08             	mov    0x8(%rax),%ecx
  6f0355:	80 7c 24 34 00       	cmpb   $0x0,0x34(%rsp)
  6f035a:	74 51                	je     6f03ad <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x58d>
  6f035c:	e9 a2 00 00 00       	jmp    6f0403 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5e3>
  6f0361:	e9 8e fc ff ff       	jmp    6efff4 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d4>
  6f0366:	31 c9                	xor    %ecx,%ecx
  6f0368:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6f036f:	00 
  6f0370:	48 89 ca             	mov    %rcx,%rdx
  6f0373:	4c 89 fe             	mov    %r15,%rsi
  6f0376:	48 d1 ee             	shr    $1,%rsi
  6f0379:	48 01 f1             	add    %rsi,%rcx
  6f037c:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
  6f0380:	4c 39 04 b8          	cmp    %r8,(%rax,%rdi,4)
  6f0384:	48 0f 47 ca          	cmova  %rdx,%rcx
  6f0388:	49 29 f7             	sub    %rsi,%r15
  6f038b:	49 83 ff 01          	cmp    $0x1,%r15
  6f038f:	77 df                	ja     6f0370 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x550>
  6f0391:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  6f0395:	4c 39 04 88          	cmp    %r8,(%rax,%rcx,4)
  6f0399:	0f 85 52 fc ff ff    	jne    6efff1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f039f:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
  6f03a3:	8b 48 08             	mov    0x8(%rax),%ecx
  6f03a6:	80 7c 24 34 00       	cmpb   $0x0,0x34(%rsp)
  6f03ab:	75 56                	jne    6f0403 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5e3>
  6f03ad:	48 8b b5 a0 02 00 00 	mov    0x2a0(%rbp),%rsi
  6f03b4:	48 39 f1             	cmp    %rsi,%rcx
  6f03b7:	0f 83 3e 01 00 00    	jae    6f04fb <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6db>
  6f03bd:	48 8b 85 98 02 00 00 	mov    0x298(%rbp),%rax
  6f03c4:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  6f03c8:	48 8b 54 c8 08       	mov    0x8(%rax,%rcx,8),%rdx
  6f03cd:	48 c1 ea 22          	shr    $0x22,%rdx
  6f03d1:	75 30                	jne    6f0403 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5e3>
  6f03d3:	48 8d 04 c8          	lea    (%rax,%rcx,8),%rax
  6f03d7:	8b 40 10             	mov    0x10(%rax),%eax
  6f03da:	83 e0 0f             	and    $0xf,%eax
  6f03dd:	8d 48 fd             	lea    -0x3(%rax),%ecx
  6f03e0:	83 f9 07             	cmp    $0x7,%ecx
  6f03e3:	0f 82 08 fc ff ff    	jb     6efff1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f03e9:	41 bf 00 00 00 00    	mov    $0x0,%r15d
  6f03ef:	83 f8 02             	cmp    $0x2,%eax
  6f03f2:	0f 82 fc fb ff ff    	jb     6efff4 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d4>
  6f03f8:	4c 8b 44 24 68       	mov    0x68(%rsp),%r8
  6f03fd:	0f 85 cd 00 00 00    	jne    6f04d0 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6b0>
  6f0403:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
  6f0408:	4c 89 c6             	mov    %r8,%rsi
  6f040b:	ff 15 7f b4 39 00    	call   *0x39b47f(%rip)        # a8b890 <_DYNAMIC+0x378>
  6f0411:	48 89 94 24 88 00 00 	mov    %rdx,0x88(%rsp)
  6f0418:	00 
  6f0419:	49 89 c7             	mov    %rax,%r15
  6f041c:	e9 d3 fb ff ff       	jmp    6efff4 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d4>
  6f0421:	0f 10 85 90 06 00 00 	movups 0x690(%rbp),%xmm0
  6f0428:	0f b6 85 4c 07 00 00 	movzbl 0x74c(%rbp),%eax
  6f042f:	48 83 bd b0 06 00 00 	cmpq   $0x0,0x6b0(%rbp)
  6f0436:	00 
  6f0437:	74 21                	je     6f045a <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x63a>
  6f0439:	84 c0                	test   %al,%al
  6f043b:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  6f0440:	74 0a                	je     6f044c <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x62c>
  6f0442:	48 83 bd 88 05 00 00 	cmpq   $0xffffffffffffffff,0x588(%rbp)
  6f0449:	ff 
  6f044a:	74 17                	je     6f0463 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x643>
  6f044c:	48 8b 95 c0 06 00 00 	mov    0x6c0(%rbp),%rdx
  6f0453:	b9 01 00 00 00       	mov    $0x1,%ecx
  6f0458:	eb 0b                	jmp    6f0465 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x645>
  6f045a:	31 c9                	xor    %ecx,%ecx
  6f045c:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  6f0461:	eb 02                	jmp    6f0465 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x645>
  6f0463:	31 c9                	xor    %ecx,%ecx
  6f0465:	0f b6 b5 4e 07 00 00 	movzbl 0x74e(%rbp),%esi
  6f046c:	4c 8b 44 24 48       	mov    0x48(%rsp),%r8
  6f0471:	4c 89 47 20          	mov    %r8,0x20(%rdi)
  6f0475:	0f 10 4c 24 38       	movups 0x38(%rsp),%xmm1
  6f047a:	0f 11 4f 10          	movups %xmm1,0x10(%rdi)
  6f047e:	48 89 0f             	mov    %rcx,(%rdi)
  6f0481:	48 89 57 08          	mov    %rdx,0x8(%rdi)
  6f0485:	0f 11 47 28          	movups %xmm0,0x28(%rdi)
  6f0489:	0f 10 85 a0 06 00 00 	movups 0x6a0(%rbp),%xmm0
  6f0490:	0f 11 47 38          	movups %xmm0,0x38(%rdi)
  6f0494:	f2 0f 10 85 40 07 00 	movsd  0x740(%rbp),%xmm0
  6f049b:	00 
  6f049c:	0f c6 c0 e1          	shufps $0xe1,%xmm0,%xmm0
  6f04a0:	0f 13 47 48          	movlps %xmm0,0x48(%rdi)
  6f04a4:	88 47 50             	mov    %al,0x50(%rdi)
  6f04a7:	40 88 77 51          	mov    %sil,0x51(%rdi)
  6f04ab:	48 89 f8             	mov    %rdi,%rax
  6f04ae:	48 81 c4 78 01 00 00 	add    $0x178,%rsp
  6f04b5:	5b                   	pop    %rbx
  6f04b6:	41 5c                	pop    %r12
  6f04b8:	41 5d                	pop    %r13
  6f04ba:	41 5e                	pop    %r14
  6f04bc:	41 5f                	pop    %r15
  6f04be:	5d                   	pop    %rbp
  6f04bf:	c3                   	ret
  6f04c0:	4c 89 e7             	mov    %r12,%rdi
  6f04c3:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  6f04c8:	ff 15 b2 b3 39 00    	call   *0x39b3b2(%rip)        # a8b880 <_DYNAMIC+0x368>
  6f04ce:	eb 29                	jmp    6f04f9 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6d9>
  6f04d0:	48 8d 3d 7f a5 96 ff 	lea    -0x695a81(%rip),%rdi        # 5aa56 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2d8e>
  6f04d7:	48 8d 15 12 2a 37 00 	lea    0x372a12(%rip),%rdx        # a62ef0 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa30>
  6f04de:	be 83 00 00 00       	mov    $0x83,%esi
  6f04e3:	ff 15 bf b2 39 00    	call   *0x39b2bf(%rip)        # a8b7a8 <_DYNAMIC+0x290>
  6f04e9:	eb 0e                	jmp    6f04f9 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6d9>
  6f04eb:	bf 01 00 00 00       	mov    $0x1,%edi
  6f04f0:	4c 89 f6             	mov    %r14,%rsi
  6f04f3:	ff 15 37 b3 39 00    	call   *0x39b337(%rip)        # a8b830 <_DYNAMIC+0x318>
  6f04f9:	0f 0b                	ud2
  6f04fb:	48 89 cf             	mov    %rcx,%rdi
  6f04fe:	48 8d 05 1b 2a 37 00 	lea    0x372a1b(%rip),%rax        # a62f20 <anon.11e2b9481e9b91b563f8fe9d0c88072a.10.llvm.12864665140496245092+0xa60>
  6f0505:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6f050a:	eb b7                	jmp    6f04c3 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6a3>
  6f050c:	48 89 c3             	mov    %rax,%rbx
  6f050f:	eb 59                	jmp    6f056a <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x74a>
  6f0511:	48 89 c3             	mov    %rax,%rbx
  6f0514:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  6f051b:	00 
  6f051c:	e8 8f 4c ff ff       	call   6e51b0 <core::ptr::drop_glue::<gpui::runtime::SnapshotNode>>
  6f0521:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  6f0526:	e8 a5 39 ff ff       	call   6e3ed0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::SnapshotNode>>>
  6f052b:	48 89 df             	mov    %rbx,%rdi
  6f052e:	e8 5d 0b 37 00       	call   a61090 <_Unwind_Resume@plt>
  6f0533:	eb 00                	jmp    6f0535 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x715>
  6f0535:	48 89 c3             	mov    %rax,%rbx
  6f0538:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  6f053d:	e8 8e 39 ff ff       	call   6e3ed0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::SnapshotNode>>>
  6f0542:	48 89 df             	mov    %rbx,%rdi
  6f0545:	e8 46 0b 37 00       	call   a61090 <_Unwind_Resume@plt>
  6f054a:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
  6f054f:	48 89 c3             	mov    %rax,%rbx
  6f0552:	48 85 ed             	test   %rbp,%rbp
  6f0555:	7e 13                	jle    6f056a <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x74a>
  6f0557:	ba 01 00 00 00       	mov    $0x1,%edx
  6f055c:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6f0561:	48 89 ee             	mov    %rbp,%rsi
  6f0564:	ff 15 fe b1 39 00    	call   *0x39b1fe(%rip)        # a8b768 <_DYNAMIC+0x250>
  6f056a:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
  6f0570:	74 15                	je     6f0587 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x767>
  6f0572:	ba 01 00 00 00       	mov    $0x1,%edx
  6f0577:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
  6f057c:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  6f0581:	ff 15 e1 b1 39 00    	call   *0x39b1e1(%rip)        # a8b768 <_DYNAMIC+0x250>
  6f0587:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  6f058c:	e8 3f 39 ff ff       	call   6e3ed0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::SnapshotNode>>>
  6f0591:	48 89 df             	mov    %rbx,%rdi
  6f0594:	e8 f7 0a 37 00       	call   a61090 <_Unwind_Resume@plt>
