# Packed retained route column: review control

This is an unadopted structural experiment based on `89aeabd53942c3a4643bcb6fd978e6a24703f6d2`. Source is frozen at `8095615af6` in an isolated sparse worktree. No timing, default-feature, native-feature, strict, or foreign-target result is claimed for this control.

`Node` changes from 40 to 24 bytes. Its former parent/ordinal word becomes a bounded topology word holding parent+1, ordinal, and route-slot+1. Each field uses 17 bits with the present admission limit of 100,000 nodes. Identity remains 64 bits and component owner scope remains 32 bits. A single boxed slice owns the handlers, with 16 bytes of header and 16 bytes per routed node. There is no sparse key column, density policy, route-presence bit in Content, temporary ordinal scratch phase, or binary search. Empty routes allocate no handler slice storage. The Runtime header still grows by 16 bytes.

The source bill is 30,601 shipping core lines, versus 30,513 at the base: +88. This excludes tests, examples, comments, vendor and support sources under the established counter. Public Handler/Route interfaces, El (176 bytes), Draft (152 bytes), and Win (8 bytes) remain unchanged on this 64-bit control.

## Focused correctness

The selected public route, property action, property selection, component, inspector and list suites pass 70 tests. The no-default library suite passes 152 with 6 ignored. New private tests exercise all admitted topology indices, boundary rejection, full-width identity and scope, and direct compact slots in an actual mounted owner. Existing parent tests and the complete-owner allocation ledger pass. These are correctness results, not timing samples. Handler replacement and filter rejection retire captured handlers at the corresponding reconciliation point; temporary property takes restore the same persistent slot. Backing allocation deallocation order changes because routes now have separate storage; no allocator-operation trace equivalence is claimed.

## Complete-owner allocation evidence

The fixture uses actual Win/Runtime owners and reports allocator requested bytes and calls, not usable classes or RSS. Node capacities, Draft capacities, actual owner size and captured payloads are in `owner.log`. The 44 baseline/candidate rows, including density transitions, are in `owner-delta.csv`. A public empty div is N=1, not N=0; Runtime<()> grows from 1,824 to 1,840 bytes. The owner with model state in the fixture is 1,880 bytes, and that actual owner allocation is charged.

| Actual mounted owner | Retained byte delta | Mount peak delta | Mount request delta |
| --- | ---: | ---: | ---: |
| N=1, H=0 | 0 | 0 | 0 |
| N=1, H=1, no capture | +16 | +16 | +1 |
| N=100, H=1, no capture | -1,568 | +16 | +1 |
| N=100, H=66, no capture | -528 | +16 | +1 |
| N=100, H=100, no capture | +16 | +16 | +1 |
| N=16,384, H=0 | -262,128 | -262,128 | 0 |
| N=16,384, H=164 | -259,504 | +16 | +1 |
| N=16,384, H=8,192 | -131,056 | +16 | +1 |
| Workspace N=32, H=7 | -384 | -384 | +1 |

The no-route N=1 mount has exactly equal total requests, requested bytes, retained bytes and peak. After an equal update its cumulative requested bytes are 16 lower, while retained bytes and peak remain equal. N=100 H=0 mount peak depends on the actual retained view state in the fixture: the first static cohort saves 1,584 bytes, while the later empty-capture cohort has a description-dominated peak 16 bytes higher. Equal-update peaks save 1,584 bytes in both. All rows are retained; no broad peak-per-node claim is made. Captured handlers retain the same 1,024-byte payload per site. Mount and update overlap measurements already include Draft, old nodes, old routes, next nodes, and next routes where live; these are not summed again.

## Actual release codegen

The frozen release example is an artifact selected from Cargo JSON with `fresh=false`, copied before any source switch and hashed. It is run only in check mode for output oracles. Linked `.text` is 3,729,719 bytes, 432 fewer than the frozen baseline. Read-only data is 152 bytes larger. These are executable section counts, not a forecast of another application's binary.

All Node getters inline. Activation computes the 24-byte row address, shifts topology by 34, subtracts one with a no-route branch, checks the boxed slice bound and indexes a 16-byte handler slot. It has no search or outlined lookup. Snapshot presence loads topology and shifts by 34; the prior cached Content-bit control instead used a 32-bit load and sign-bit test. This comparison does not establish isolated latency.

LLVM already cancels parent decode/re-encode in both Siblings builder passes: the encoded low 17 bits directly select the virtual-root prefix slot. The ordinal pass shifts by 17 and masks 17 bits. Adding a parent_slot helper has no demonstrated benefit.

One issue remains for review: Topology::new is outlined as a 135-byte function. Actual describe code calls it both for a constant empty fresh-node initializer and for final topology. A focused constructor inline/constant-initializer change may remove the first call and inline the second. No result from such a change is included here.

## Frozen inputs

- Source patch SHA-256: `af240c40b52a9829e52ce99aecbf6fe3cd2c60622a51859137bf0413d20990ca`.
- Release executable SHA-256: `a7d51e45d197917a7961f92f2be47ff6e1cbe52d72564575f79e44f204940fca`.
- Baseline executable remains the independently frozen original control, SHA-256 `2b183734b499446cbda49ab5ee86357c89d9cbd45b1bc4e4166bfb41cffcb193`.

Raw selected artifact JSON, compiler environment, source hashes, section counts, symbols, disassembly and correctness logs accompany this report. Earlier AoS/SoA timing losses remain archived separately and are not superseded or discarded by this hypothesis.
