
/tmp/gpui-route-columns-evidence/bin/aos-cost:     file format elf64-x86-64


Disassembly of section .text:

00000000006f0150 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets>:
  6f0150:	55                   	push   %rbp
  6f0151:	41 57                	push   %r15
  6f0153:	41 56                	push   %r14
  6f0155:	41 55                	push   %r13
  6f0157:	41 54                	push   %r12
  6f0159:	53                   	push   %rbx
  6f015a:	48 81 ec 78 01 00 00 	sub    $0x178,%rsp
  6f0161:	89 54 24 34          	mov    %edx,0x34(%rsp)
  6f0165:	48 8b 2e             	mov    (%rsi),%rbp
  6f0168:	48 85 ed             	test   %rbp,%rbp
  6f016b:	74 35                	je     6f01a2 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x52>
  6f016d:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
  6f0172:	4c 8b bd 98 05 00 00 	mov    0x598(%rbp),%r15
  6f0179:	4c 89 f8             	mov    %r15,%rax
  6f017c:	48 c1 e0 07          	shl    $0x7,%rax
  6f0180:	4a 8d 1c f8          	lea    (%rax,%r15,8),%rbx
  6f0184:	48 b8 f0 f0 f0 f0 f0 	movabs $0xf0f0f0f0f0f0f0,%rax
  6f018b:	f0 f0 00 
  6f018e:	49 39 c7             	cmp    %rax,%r15
  6f0191:	76 23                	jbe    6f01b6 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x66>
  6f0193:	45 31 f6             	xor    %r14d,%r14d
  6f0196:	4c 89 f7             	mov    %r14,%rdi
  6f0199:	48 89 de             	mov    %rbx,%rsi
  6f019c:	ff 15 a6 c2 39 00    	call   *0x39c2a6(%rip)        # a8c448 <_DYNAMIC+0x318>
  6f01a2:	48 c7 47 08 0d 00 00 	movq   $0xd,0x8(%rdi)
  6f01a9:	00 
  6f01aa:	48 c7 07 02 00 00 00 	movq   $0x2,(%rdi)
  6f01b1:	e9 1b 06 00 00       	jmp    6f07d1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x681>
  6f01b6:	48 85 db             	test   %rbx,%rbx
  6f01b9:	74 21                	je     6f01dc <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x8c>
  6f01bb:	ff 15 af c1 39 00    	call   *0x39c1af(%rip)        # a8c370 <_DYNAMIC+0x240>
  6f01c1:	41 be 08 00 00 00    	mov    $0x8,%r14d
  6f01c7:	be 08 00 00 00       	mov    $0x8,%esi
  6f01cc:	48 89 df             	mov    %rbx,%rdi
  6f01cf:	ff 15 a3 c1 39 00    	call   *0x39c1a3(%rip)        # a8c378 <_DYNAMIC+0x248>
  6f01d5:	48 85 c0             	test   %rax,%rax
  6f01d8:	75 0a                	jne    6f01e4 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x94>
  6f01da:	eb ba                	jmp    6f0196 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x46>
  6f01dc:	b8 08 00 00 00       	mov    $0x8,%eax
  6f01e1:	45 31 ff             	xor    %r15d,%r15d
  6f01e4:	4c 89 7c 24 38       	mov    %r15,0x38(%rsp)
  6f01e9:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6f01ee:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
  6f01f5:	00 00 
  6f01f7:	48 8b 85 48 06 00 00 	mov    0x648(%rbp),%rax
  6f01fe:	48 85 c0             	test   %rax,%rax
  6f0201:	74 33                	je     6f0236 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0xe6>
  6f0203:	48 8b b0 00 01 00 00 	mov    0x100(%rax),%rsi
  6f020a:	48 85 f6             	test   %rsi,%rsi
  6f020d:	74 27                	je     6f0236 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0xe6>
  6f020f:	48 8d bc 24 38 01 00 	lea    0x138(%rsp),%rdi
  6f0216:	00 
  6f0217:	ff 15 23 c4 39 00    	call   *0x39c423(%rip)        # a8c640 <_DYNAMIC+0x510>
  6f021d:	48 8b 85 98 05 00 00 	mov    0x598(%rbp),%rax
  6f0224:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  6f022b:	00 
  6f022c:	48 85 c0             	test   %rax,%rax
  6f022f:	75 34                	jne    6f0265 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x115>
  6f0231:	e9 11 05 00 00       	jmp    6f0747 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5f7>
  6f0236:	48 c7 84 24 38 01 00 	movq   $0x4,0x138(%rsp)
  6f023d:	00 04 00 00 00 
  6f0242:	0f 57 c0             	xorps  %xmm0,%xmm0
  6f0245:	0f 11 84 24 40 01 00 	movups %xmm0,0x140(%rsp)
  6f024c:	00 
  6f024d:	48 8b 85 98 05 00 00 	mov    0x598(%rbp),%rax
  6f0254:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  6f025b:	00 
  6f025c:	48 85 c0             	test   %rax,%rax
  6f025f:	0f 84 e2 04 00 00    	je     6f0747 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5f7>
  6f0265:	48 8d 85 c8 05 00 00 	lea    0x5c8(%rbp),%rax
  6f026c:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  6f0271:	45 31 e4             	xor    %r12d,%r12d
  6f0274:	48 8d 05 55 38 37 00 	lea    0x373855(%rip),%rax        # a63ad0 <anon.3861ea6aeffee15cc06a319996c1c02a.10.llvm.17720431731494121588+0x9a0>
  6f027b:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6f0280:	48 89 6c 24 78       	mov    %rbp,0x78(%rsp)
  6f0285:	eb 52                	jmp    6f02d9 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x189>
  6f0287:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f028e:	00 00 
  6f0290:	4c 8b a4 24 98 00 00 	mov    0x98(%rsp),%r12
  6f0297:	00 
  6f0298:	49 ff c4             	inc    %r12
  6f029b:	48 89 d8             	mov    %rbx,%rax
  6f029e:	48 c1 e0 07          	shl    $0x7,%rax
  6f02a2:	48 8d 3c d8          	lea    (%rax,%rbx,8),%rdi
  6f02a6:	48 03 7c 24 40       	add    0x40(%rsp),%rdi
  6f02ab:	ba 88 00 00 00       	mov    $0x88,%edx
  6f02b0:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
  6f02b7:	00 
  6f02b8:	ff 15 d2 c0 39 00    	call   *0x39c0d2(%rip)        # a8c390 <memcpy@GLIBC_2.14>
  6f02be:	48 ff c3             	inc    %rbx
  6f02c1:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
  6f02c6:	4c 3b a4 24 88 00 00 	cmp    0x88(%rsp),%r12
  6f02cd:	00 
  6f02ce:	48 8b 6c 24 78       	mov    0x78(%rsp),%rbp
  6f02d3:	0f 84 6e 04 00 00    	je     6f0747 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5f7>
  6f02d9:	48 8b b5 98 05 00 00 	mov    0x598(%rbp),%rsi
  6f02e0:	49 39 f4             	cmp    %rsi,%r12
  6f02e3:	0f 83 18 05 00 00    	jae    6f0801 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6b1>
  6f02e9:	48 8b 9d 90 05 00 00 	mov    0x590(%rbp),%rbx
  6f02f0:	4c 89 a4 24 98 00 00 	mov    %r12,0x98(%rsp)
  6f02f7:	00 
  6f02f8:	49 c1 e4 06          	shl    $0x6,%r12
  6f02fc:	4e 8b 44 23 20       	mov    0x20(%rbx,%r12,1),%r8
  6f0301:	80 bd 52 07 00 00 00 	cmpb   $0x0,0x752(%rbp)
  6f0308:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
  6f030d:	4c 89 44 24 68       	mov    %r8,0x68(%rsp)
  6f0312:	74 0d                	je     6f0321 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f0314:	80 bd 56 07 00 00 00 	cmpb   $0x0,0x756(%rbp)
  6f031b:	0f 84 0f 01 00 00    	je     6f0430 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x2e0>
  6f0321:	45 31 ff             	xor    %r15d,%r15d
  6f0324:	4c 01 e3             	add    %r12,%rbx
  6f0327:	44 8b 63 38          	mov    0x38(%rbx),%r12d
  6f032b:	41 81 e4 ff ff 01 00 	and    $0x1ffff,%r12d
  6f0332:	45 31 ed             	xor    %r13d,%r13d
  6f0335:	49 81 fc ff ff 01 00 	cmp    $0x1ffff,%r12
  6f033c:	0f 95 44 24 0e       	setne  0xe(%rsp)
  6f0341:	0f b6 43 3d          	movzbl 0x3d(%rbx),%eax
  6f0345:	2c 02                	sub    $0x2,%al
  6f0347:	0f b6 c0             	movzbl %al,%eax
  6f034a:	b9 08 00 00 00       	mov    $0x8,%ecx
  6f034f:	0f 42 c1             	cmovb  %ecx,%eax
  6f0352:	88 44 24 0f          	mov    %al,0xf(%rsp)
  6f0356:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
  6f035b:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6f0362:	00 
  6f0363:	48 8d 05 56 0a 01 00 	lea    0x10a56(%rip),%rax        # 700dc0 <<gpui::element::Role as core::fmt::Debug>::fmt>
  6f036a:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  6f0371:	00 
  6f0372:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  6f0379:	00 
  6f037a:	48 8d 35 8a e7 95 ff 	lea    -0x6a1876(%rip),%rsi        # 4eb0b <anon.5558d0fc2e5366f92fec9016dadbf867.4.llvm.9438347653228867760>
  6f0381:	48 8d 94 24 a0 00 00 	lea    0xa0(%rsp),%rdx
  6f0388:	00 
  6f0389:	ff 15 b9 c2 39 00    	call   *0x39c2b9(%rip)        # a8c648 <_DYNAMIC+0x518>
  6f038f:	4c 8b b4 24 b0 00 00 	mov    0xb0(%rsp),%r14
  6f0396:	00 
  6f0397:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  6f039e:	00 
  6f039f:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f03a4:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  6f03ab:	00 
  6f03ac:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6f03b3:	00 
  6f03b4:	48 8b 6b 28          	mov    0x28(%rbx),%rbp
  6f03b8:	48 85 ed             	test   %rbp,%rbp
  6f03bb:	74 63                	je     6f0420 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x2d0>
  6f03bd:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
  6f03c2:	4c 8b 75 00          	mov    0x0(%rbp),%r14
  6f03c6:	49 d1 ee             	shr    $1,%r14
  6f03c9:	0f 84 11 01 00 00    	je     6f04e0 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x390>
  6f03cf:	ff 15 9b bf 39 00    	call   *0x39bf9b(%rip)        # a8c370 <_DYNAMIC+0x240>
  6f03d5:	be 01 00 00 00       	mov    $0x1,%esi
  6f03da:	4c 89 f7             	mov    %r14,%rdi
  6f03dd:	ff 15 95 bf 39 00    	call   *0x39bf95(%rip)        # a8c378 <_DYNAMIC+0x248>
  6f03e3:	48 85 c0             	test   %rax,%rax
  6f03e6:	0f 84 25 04 00 00    	je     6f0811 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6c1>
  6f03ec:	48 83 c5 10          	add    $0x10,%rbp
  6f03f0:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6f03f5:	48 89 c7             	mov    %rax,%rdi
  6f03f8:	48 89 ee             	mov    %rbp,%rsi
  6f03fb:	4c 89 f2             	mov    %r14,%rdx
  6f03fe:	ff 15 8c bf 39 00    	call   *0x39bf8c(%rip)        # a8c390 <memcpy@GLIBC_2.14>
  6f0404:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
  6f0409:	4c 89 f5             	mov    %r14,%rbp
  6f040c:	e9 e4 00 00 00       	jmp    6f04f5 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x3a5>
  6f0411:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f0418:	0f 1f 84 00 00 00 00 
  6f041f:	00 
  6f0420:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
  6f0427:	e9 ce 00 00 00       	jmp    6f04fa <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x3aa>
  6f042c:	0f 1f 40 00          	nopl   0x0(%rax)
  6f0430:	48 8b 85 00 02 00 00 	mov    0x200(%rbp),%rax
  6f0437:	48 85 c0             	test   %rax,%rax
  6f043a:	0f 84 f8 01 00 00    	je     6f0638 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x4e8>
  6f0440:	83 f8 01             	cmp    $0x1,%eax
  6f0443:	0f 85 1c 02 00 00    	jne    6f0665 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x515>
  6f0449:	4c 8b bd 10 02 00 00 	mov    0x210(%rbp),%r15
  6f0450:	4d 85 ff             	test   %r15,%r15
  6f0453:	0f 84 3d 02 00 00    	je     6f0696 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x546>
  6f0459:	48 8b 85 08 02 00 00 	mov    0x208(%rbp),%rax
  6f0460:	31 c9                	xor    %ecx,%ecx
  6f0462:	49 83 ff 01          	cmp    $0x1,%r15
  6f0466:	74 2c                	je     6f0494 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x344>
  6f0468:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6f046f:	00 
  6f0470:	48 89 ca             	mov    %rcx,%rdx
  6f0473:	4c 89 fe             	mov    %r15,%rsi
  6f0476:	48 d1 ee             	shr    $1,%rsi
  6f0479:	48 01 f1             	add    %rsi,%rcx
  6f047c:	48 89 cf             	mov    %rcx,%rdi
  6f047f:	48 c1 e7 04          	shl    $0x4,%rdi
  6f0483:	4c 39 04 38          	cmp    %r8,(%rax,%rdi,1)
  6f0487:	48 0f 47 ca          	cmova  %rdx,%rcx
  6f048b:	49 29 f7             	sub    %rsi,%r15
  6f048e:	49 83 ff 01          	cmp    $0x1,%r15
  6f0492:	77 dc                	ja     6f0470 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x320>
  6f0494:	48 89 ce             	mov    %rcx,%rsi
  6f0497:	48 c1 e6 04          	shl    $0x4,%rsi
  6f049b:	31 d2                	xor    %edx,%edx
  6f049d:	4c 39 04 30          	cmp    %r8,(%rax,%rsi,1)
  6f04a1:	0f 96 c2             	setbe  %dl
  6f04a4:	48 01 ca             	add    %rcx,%rdx
  6f04a7:	0f 84 74 fe ff ff    	je     6f0321 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f04ad:	48 c1 e2 04          	shl    $0x4,%rdx
  6f04b1:	4c 89 c1             	mov    %r8,%rcx
  6f04b4:	48 2b 4c 10 f0       	sub    -0x10(%rax,%rdx,1),%rcx
  6f04b9:	8b 74 10 fc          	mov    -0x4(%rax,%rdx,1),%esi
  6f04bd:	48 39 f1             	cmp    %rsi,%rcx
  6f04c0:	0f 83 5b fe ff ff    	jae    6f0321 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f04c6:	48 01 d0             	add    %rdx,%rax
  6f04c9:	8b 40 f8             	mov    -0x8(%rax),%eax
  6f04cc:	48 01 c1             	add    %rax,%rcx
  6f04cf:	80 7c 24 34 00       	cmpb   $0x0,0x34(%rsp)
  6f04d4:	0f 84 03 02 00 00    	je     6f06dd <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x58d>
  6f04da:	e9 4a 02 00 00       	jmp    6f0729 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5d9>
  6f04df:	90                   	nop
  6f04e0:	b8 01 00 00 00       	mov    $0x1,%eax
  6f04e5:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6f04ea:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
  6f04f1:	00 00 
  6f04f3:	31 ed                	xor    %ebp,%ebp
  6f04f5:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
  6f04fa:	0f 10 43 10          	movups 0x10(%rbx),%xmm0
  6f04fe:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  6f0503:	48 8d bc 24 38 01 00 	lea    0x138(%rsp),%rdi
  6f050a:	00 
  6f050b:	ff 15 3f c1 39 00    	call   *0x39c13f(%rip)        # a8c650 <_DYNAMIC+0x520>
  6f0511:	48 89 d1             	mov    %rdx,%rcx
  6f0514:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  6f051b:	00 
  6f051c:	48 89 de             	mov    %rbx,%rsi
  6f051f:	48 89 c2             	mov    %rax,%rdx
  6f0522:	ff 15 30 c1 39 00    	call   *0x39c130(%rip)        # a8c658 <_DYNAMIC+0x528>
  6f0528:	8b 84 24 b0 00 00 00 	mov    0xb0(%rsp),%eax
  6f052f:	85 c0                	test   %eax,%eax
  6f0531:	75 1d                	jne    6f0550 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x400>
  6f0533:	0f 28 84 24 60 01 00 	movaps 0x160(%rsp),%xmm0
  6f053a:	00 
  6f053b:	0f 28 8c 24 50 01 00 	movaps 0x150(%rsp),%xmm1
  6f0542:	00 
  6f0543:	eb 1c                	jmp    6f0561 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x411>
  6f0545:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6f054c:	00 00 00 00 
  6f0550:	0f 10 84 24 b4 00 00 	movups 0xb4(%rsp),%xmm0
  6f0557:	00 
  6f0558:	f2 0f 10 8c 24 c4 00 	movsd  0xc4(%rsp),%xmm1
  6f055f:	00 00 
  6f0561:	0f b6 4c 24 0e       	movzbl 0xe(%rsp),%ecx
  6f0566:	41 88 cd             	mov    %cl,%r13b
  6f0569:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  6f056e:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
  6f0575:	00 
  6f0576:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
  6f057d:	00 
  6f057e:	4c 89 a4 24 b8 00 00 	mov    %r12,0xb8(%rsp)
  6f0585:	00 
  6f0586:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
  6f058d:	00 
  6f058e:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  6f0593:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
  6f059a:	00 
  6f059b:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  6f05a2:	00 
  6f05a3:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
  6f05aa:	00 
  6f05ab:	48 89 ac 24 d8 00 00 	mov    %rbp,0xd8(%rsp)
  6f05b2:	00 
  6f05b3:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  6f05b8:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
  6f05bf:	00 
  6f05c0:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
  6f05c5:	4c 89 b4 24 e8 00 00 	mov    %r14,0xe8(%rsp)
  6f05cc:	00 
  6f05cd:	0f 28 54 24 10       	movaps 0x10(%rsp),%xmm2
  6f05d2:	0f 11 94 24 f8 00 00 	movups %xmm2,0xf8(%rsp)
  6f05d9:	00 
  6f05da:	89 84 24 18 01 00 00 	mov    %eax,0x118(%rsp)
  6f05e1:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  6f05e8:	00 
  6f05e9:	0f 11 84 24 1c 01 00 	movups %xmm0,0x11c(%rsp)
  6f05f0:	00 
  6f05f1:	0f 29 8c 24 50 01 00 	movaps %xmm1,0x150(%rsp)
  6f05f8:	00 
  6f05f9:	0f 13 8c 24 2c 01 00 	movlps %xmm1,0x12c(%rsp)
  6f0600:	00 
  6f0601:	4c 89 bc 24 08 01 00 	mov    %r15,0x108(%rsp)
  6f0608:	00 
  6f0609:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  6f0610:	00 
  6f0611:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
  6f0618:	00 
  6f0619:	48 8b 5c 24 48       	mov    0x48(%rsp),%rbx
  6f061e:	48 3b 5c 24 38       	cmp    0x38(%rsp),%rbx
  6f0623:	0f 85 67 fc ff ff    	jne    6f0290 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x140>
  6f0629:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  6f062e:	e8 dd 5c 03 00       	call   726310 <<alloc::raw_vec::RawVec<gpui::runtime::SnapshotNode>>::grow_one>
  6f0633:	e9 58 fc ff ff       	jmp    6f0290 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x140>
  6f0638:	4c 89 c1             	mov    %r8,%rcx
  6f063b:	48 2b 8d 08 02 00 00 	sub    0x208(%rbp),%rcx
  6f0642:	0f 82 d9 fc ff ff    	jb     6f0321 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f0648:	48 3b 8d 10 02 00 00 	cmp    0x210(%rbp),%rcx
  6f064f:	0f 83 cc fc ff ff    	jae    6f0321 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f0655:	80 7c 24 34 00       	cmpb   $0x0,0x34(%rsp)
  6f065a:	0f 84 7d 00 00 00    	je     6f06dd <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x58d>
  6f0660:	e9 c4 00 00 00       	jmp    6f0729 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5d9>
  6f0665:	4c 8b bd 10 02 00 00 	mov    0x210(%rbp),%r15
  6f066c:	4d 85 ff             	test   %r15,%r15
  6f066f:	74 25                	je     6f0696 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x546>
  6f0671:	48 8b 85 08 02 00 00 	mov    0x208(%rbp),%rax
  6f0678:	49 83 ff 01          	cmp    $0x1,%r15
  6f067c:	75 1d                	jne    6f069b <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x54b>
  6f067e:	4c 39 00             	cmp    %r8,(%rax)
  6f0681:	0f 85 9a fc ff ff    	jne    6f0321 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f0687:	8b 48 08             	mov    0x8(%rax),%ecx
  6f068a:	80 7c 24 34 00       	cmpb   $0x0,0x34(%rsp)
  6f068f:	74 4c                	je     6f06dd <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x58d>
  6f0691:	e9 93 00 00 00       	jmp    6f0729 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5d9>
  6f0696:	e9 89 fc ff ff       	jmp    6f0324 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d4>
  6f069b:	31 c9                	xor    %ecx,%ecx
  6f069d:	0f 1f 00             	nopl   (%rax)
  6f06a0:	48 89 ca             	mov    %rcx,%rdx
  6f06a3:	4c 89 fe             	mov    %r15,%rsi
  6f06a6:	48 d1 ee             	shr    $1,%rsi
  6f06a9:	48 01 f1             	add    %rsi,%rcx
  6f06ac:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
  6f06b0:	4c 39 04 b8          	cmp    %r8,(%rax,%rdi,4)
  6f06b4:	48 0f 47 ca          	cmova  %rdx,%rcx
  6f06b8:	49 29 f7             	sub    %rsi,%r15
  6f06bb:	49 83 ff 01          	cmp    $0x1,%r15
  6f06bf:	77 df                	ja     6f06a0 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x550>
  6f06c1:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  6f06c5:	4c 39 04 88          	cmp    %r8,(%rax,%rcx,4)
  6f06c9:	0f 85 52 fc ff ff    	jne    6f0321 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f06cf:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
  6f06d3:	8b 48 08             	mov    0x8(%rax),%ecx
  6f06d6:	80 7c 24 34 00       	cmpb   $0x0,0x34(%rsp)
  6f06db:	75 4c                	jne    6f0729 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5d9>
  6f06dd:	48 8b b5 b8 02 00 00 	mov    0x2b8(%rbp),%rsi
  6f06e4:	48 39 f1             	cmp    %rsi,%rcx
  6f06e7:	0f 83 34 01 00 00    	jae    6f0821 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6d1>
  6f06ed:	48 8b 85 b0 02 00 00 	mov    0x2b0(%rbp),%rax
  6f06f4:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  6f06f8:	8b 44 c8 10          	mov    0x10(%rax,%rcx,8),%eax
  6f06fc:	85 c0                	test   %eax,%eax
  6f06fe:	78 29                	js     6f0729 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5d9>
  6f0700:	83 e0 0f             	and    $0xf,%eax
  6f0703:	8d 48 fd             	lea    -0x3(%rax),%ecx
  6f0706:	83 f9 07             	cmp    $0x7,%ecx
  6f0709:	0f 82 12 fc ff ff    	jb     6f0321 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f070f:	41 bf 00 00 00 00    	mov    $0x0,%r15d
  6f0715:	83 f8 02             	cmp    $0x2,%eax
  6f0718:	0f 82 06 fc ff ff    	jb     6f0324 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d4>
  6f071e:	4c 8b 44 24 68       	mov    0x68(%rsp),%r8
  6f0723:	0f 85 bd 00 00 00    	jne    6f07e6 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x696>
  6f0729:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
  6f072e:	4c 89 c6             	mov    %r8,%rsi
  6f0731:	ff 15 79 bd 39 00    	call   *0x39bd79(%rip)        # a8c4b0 <_DYNAMIC+0x380>
  6f0737:	48 89 94 24 80 00 00 	mov    %rdx,0x80(%rsp)
  6f073e:	00 
  6f073f:	49 89 c7             	mov    %rax,%r15
  6f0742:	e9 dd fb ff ff       	jmp    6f0324 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d4>
  6f0747:	0f 10 85 98 06 00 00 	movups 0x698(%rbp),%xmm0
  6f074e:	0f b6 85 54 07 00 00 	movzbl 0x754(%rbp),%eax
  6f0755:	48 83 bd b8 06 00 00 	cmpq   $0x0,0x6b8(%rbp)
  6f075c:	00 
  6f075d:	74 21                	je     6f0780 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x630>
  6f075f:	84 c0                	test   %al,%al
  6f0761:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  6f0766:	74 0a                	je     6f0772 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x622>
  6f0768:	48 83 bd a0 05 00 00 	cmpq   $0xffffffffffffffff,0x5a0(%rbp)
  6f076f:	ff 
  6f0770:	74 17                	je     6f0789 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x639>
  6f0772:	48 8b 95 c8 06 00 00 	mov    0x6c8(%rbp),%rdx
  6f0779:	b9 01 00 00 00       	mov    $0x1,%ecx
  6f077e:	eb 0b                	jmp    6f078b <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x63b>
  6f0780:	31 c9                	xor    %ecx,%ecx
  6f0782:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  6f0787:	eb 02                	jmp    6f078b <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x63b>
  6f0789:	31 c9                	xor    %ecx,%ecx
  6f078b:	0f b6 b5 56 07 00 00 	movzbl 0x756(%rbp),%esi
  6f0792:	4c 8b 44 24 48       	mov    0x48(%rsp),%r8
  6f0797:	4c 89 47 20          	mov    %r8,0x20(%rdi)
  6f079b:	0f 10 4c 24 38       	movups 0x38(%rsp),%xmm1
  6f07a0:	0f 11 4f 10          	movups %xmm1,0x10(%rdi)
  6f07a4:	48 89 0f             	mov    %rcx,(%rdi)
  6f07a7:	48 89 57 08          	mov    %rdx,0x8(%rdi)
  6f07ab:	0f 11 47 28          	movups %xmm0,0x28(%rdi)
  6f07af:	0f 10 85 a8 06 00 00 	movups 0x6a8(%rbp),%xmm0
  6f07b6:	0f 11 47 38          	movups %xmm0,0x38(%rdi)
  6f07ba:	f2 0f 10 85 48 07 00 	movsd  0x748(%rbp),%xmm0
  6f07c1:	00 
  6f07c2:	0f c6 c0 e1          	shufps $0xe1,%xmm0,%xmm0
  6f07c6:	0f 13 47 48          	movlps %xmm0,0x48(%rdi)
  6f07ca:	88 47 50             	mov    %al,0x50(%rdi)
  6f07cd:	40 88 77 51          	mov    %sil,0x51(%rdi)
  6f07d1:	48 89 f8             	mov    %rdi,%rax
  6f07d4:	48 81 c4 78 01 00 00 	add    $0x178,%rsp
  6f07db:	5b                   	pop    %rbx
  6f07dc:	41 5c                	pop    %r12
  6f07de:	41 5d                	pop    %r13
  6f07e0:	41 5e                	pop    %r14
  6f07e2:	41 5f                	pop    %r15
  6f07e4:	5d                   	pop    %rbp
  6f07e5:	c3                   	ret
  6f07e6:	48 8d 3d 7a a3 96 ff 	lea    -0x695c86(%rip),%rdi        # 5ab67 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2d7f>
  6f07ed:	48 8d 15 c4 32 37 00 	lea    0x3732c4(%rip),%rdx        # a63ab8 <anon.3861ea6aeffee15cc06a319996c1c02a.10.llvm.17720431731494121588+0x988>
  6f07f4:	be 83 00 00 00       	mov    $0x83,%esi
  6f07f9:	ff 15 c1 bb 39 00    	call   *0x39bbc1(%rip)        # a8c3c0 <_DYNAMIC+0x290>
  6f07ff:	eb 1e                	jmp    6f081f <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6cf>
  6f0801:	4c 89 e7             	mov    %r12,%rdi
  6f0804:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  6f0809:	ff 15 89 bc 39 00    	call   *0x39bc89(%rip)        # a8c498 <_DYNAMIC+0x368>
  6f080f:	eb 0e                	jmp    6f081f <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6cf>
  6f0811:	bf 01 00 00 00       	mov    $0x1,%edi
  6f0816:	4c 89 f6             	mov    %r14,%rsi
  6f0819:	ff 15 29 bc 39 00    	call   *0x39bc29(%rip)        # a8c448 <_DYNAMIC+0x318>
  6f081f:	0f 0b                	ud2
  6f0821:	48 89 cf             	mov    %rcx,%rdi
  6f0824:	48 8d 05 bd 32 37 00 	lea    0x3732bd(%rip),%rax        # a63ae8 <anon.3861ea6aeffee15cc06a319996c1c02a.10.llvm.17720431731494121588+0x9b8>
  6f082b:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6f0830:	eb d2                	jmp    6f0804 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6b4>
  6f0832:	48 89 c3             	mov    %rax,%rbx
  6f0835:	eb 44                	jmp    6f087b <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x72b>
  6f0837:	48 89 c3             	mov    %rax,%rbx
  6f083a:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  6f0841:	00 
  6f0842:	e8 09 4c ff ff       	call   6e5450 <core::ptr::drop_glue::<gpui::runtime::SnapshotNode>>
  6f0847:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  6f084c:	e8 1f 3a ff ff       	call   6e4270 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::SnapshotNode>>>
  6f0851:	48 89 df             	mov    %rbx,%rdi
  6f0854:	e8 a7 14 37 00       	call   a61d00 <_Unwind_Resume@plt>
  6f0859:	eb 4f                	jmp    6f08aa <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x75a>
  6f085b:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
  6f0860:	48 89 c3             	mov    %rax,%rbx
  6f0863:	48 85 ed             	test   %rbp,%rbp
  6f0866:	7e 13                	jle    6f087b <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x72b>
  6f0868:	ba 01 00 00 00       	mov    $0x1,%edx
  6f086d:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6f0872:	48 89 ee             	mov    %rbp,%rsi
  6f0875:	ff 15 05 bb 39 00    	call   *0x39bb05(%rip)        # a8c380 <_DYNAMIC+0x250>
  6f087b:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
  6f0881:	74 2a                	je     6f08ad <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x75d>
  6f0883:	ba 01 00 00 00       	mov    $0x1,%edx
  6f0888:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
  6f088d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  6f0892:	ff 15 e8 ba 39 00    	call   *0x39bae8(%rip)        # a8c380 <_DYNAMIC+0x250>
  6f0898:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  6f089d:	e8 ce 39 ff ff       	call   6e4270 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::SnapshotNode>>>
  6f08a2:	48 89 df             	mov    %rbx,%rdi
  6f08a5:	e8 56 14 37 00       	call   a61d00 <_Unwind_Resume@plt>
  6f08aa:	48 89 c3             	mov    %rax,%rbx
  6f08ad:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  6f08b2:	e8 b9 39 ff ff       	call   6e4270 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::SnapshotNode>>>
  6f08b7:	48 89 df             	mov    %rbx,%rdi
  6f08ba:	e8 41 14 37 00       	call   a61d00 <_Unwind_Resume@plt>
