
/tmp/gpui-route-columns-evidence/bin/baseline-cost:     file format elf64-x86-64


Disassembly of section .text:

00000000006efbc0 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets>:
  6efbc0:	55                   	push   %rbp
  6efbc1:	41 57                	push   %r15
  6efbc3:	41 56                	push   %r14
  6efbc5:	41 55                	push   %r13
  6efbc7:	41 54                	push   %r12
  6efbc9:	53                   	push   %rbx
  6efbca:	48 81 ec 78 01 00 00 	sub    $0x178,%rsp
  6efbd1:	89 54 24 34          	mov    %edx,0x34(%rsp)
  6efbd5:	48 8b 2e             	mov    (%rsi),%rbp
  6efbd8:	48 85 ed             	test   %rbp,%rbp
  6efbdb:	74 35                	je     6efc12 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x52>
  6efbdd:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
  6efbe2:	4c 8b bd 80 05 00 00 	mov    0x580(%rbp),%r15
  6efbe9:	4c 89 f8             	mov    %r15,%rax
  6efbec:	48 c1 e0 07          	shl    $0x7,%rax
  6efbf0:	4a 8d 1c f8          	lea    (%rax,%r15,8),%rbx
  6efbf4:	48 b8 f0 f0 f0 f0 f0 	movabs $0xf0f0f0f0f0f0f0,%rax
  6efbfb:	f0 f0 00 
  6efbfe:	49 39 c7             	cmp    %rax,%r15
  6efc01:	76 23                	jbe    6efc26 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x66>
  6efc03:	45 31 f6             	xor    %r14d,%r14d
  6efc06:	4c 89 f7             	mov    %r14,%rdi
  6efc09:	48 89 de             	mov    %rbx,%rsi
  6efc0c:	ff 15 be bc 39 00    	call   *0x39bcbe(%rip)        # a8b8d0 <_DYNAMIC+0x318>
  6efc12:	48 c7 47 08 0d 00 00 	movq   $0xd,0x8(%rdi)
  6efc19:	00 
  6efc1a:	48 c7 07 02 00 00 00 	movq   $0x2,(%rdi)
  6efc21:	e9 3c 06 00 00       	jmp    6f0262 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6a2>
  6efc26:	48 85 db             	test   %rbx,%rbx
  6efc29:	74 21                	je     6efc4c <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x8c>
  6efc2b:	ff 15 c7 bb 39 00    	call   *0x39bbc7(%rip)        # a8b7f8 <_DYNAMIC+0x240>
  6efc31:	41 be 08 00 00 00    	mov    $0x8,%r14d
  6efc37:	be 08 00 00 00       	mov    $0x8,%esi
  6efc3c:	48 89 df             	mov    %rbx,%rdi
  6efc3f:	ff 15 bb bb 39 00    	call   *0x39bbbb(%rip)        # a8b800 <_DYNAMIC+0x248>
  6efc45:	48 85 c0             	test   %rax,%rax
  6efc48:	75 0a                	jne    6efc54 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x94>
  6efc4a:	eb ba                	jmp    6efc06 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x46>
  6efc4c:	b8 08 00 00 00       	mov    $0x8,%eax
  6efc51:	45 31 ff             	xor    %r15d,%r15d
  6efc54:	4c 89 7c 24 38       	mov    %r15,0x38(%rsp)
  6efc59:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6efc5e:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
  6efc65:	00 00 
  6efc67:	48 8b 85 30 06 00 00 	mov    0x630(%rbp),%rax
  6efc6e:	48 85 c0             	test   %rax,%rax
  6efc71:	74 33                	je     6efca6 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0xe6>
  6efc73:	48 8b b0 00 01 00 00 	mov    0x100(%rax),%rsi
  6efc7a:	48 85 f6             	test   %rsi,%rsi
  6efc7d:	74 27                	je     6efca6 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0xe6>
  6efc7f:	48 8d bc 24 38 01 00 	lea    0x138(%rsp),%rdi
  6efc86:	00 
  6efc87:	ff 15 33 be 39 00    	call   *0x39be33(%rip)        # a8bac0 <_DYNAMIC+0x508>
  6efc8d:	48 8b 85 80 05 00 00 	mov    0x580(%rbp),%rax
  6efc94:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6efc9b:	00 
  6efc9c:	48 85 c0             	test   %rax,%rax
  6efc9f:	75 34                	jne    6efcd5 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x115>
  6efca1:	e9 32 05 00 00       	jmp    6f01d8 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x618>
  6efca6:	48 c7 84 24 38 01 00 	movq   $0x4,0x138(%rsp)
  6efcad:	00 04 00 00 00 
  6efcb2:	0f 57 c0             	xorps  %xmm0,%xmm0
  6efcb5:	0f 11 84 24 40 01 00 	movups %xmm0,0x140(%rsp)
  6efcbc:	00 
  6efcbd:	48 8b 85 80 05 00 00 	mov    0x580(%rbp),%rax
  6efcc4:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6efccb:	00 
  6efccc:	48 85 c0             	test   %rax,%rax
  6efccf:	0f 84 03 05 00 00    	je     6f01d8 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x618>
  6efcd5:	48 8d 85 b0 05 00 00 	lea    0x5b0(%rbp),%rax
  6efcdc:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  6efce1:	45 31 e4             	xor    %r12d,%r12d
  6efce4:	48 8d 05 ed 32 37 00 	lea    0x3732ed(%rip),%rax        # a62fd8 <anon.1c5b0003e3ef994ff4b4ae0ed5827262.10.llvm.7005437559848114461+0x9b8>
  6efceb:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6efcf0:	48 89 6c 24 78       	mov    %rbp,0x78(%rsp)
  6efcf5:	eb 52                	jmp    6efd49 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x189>
  6efcf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6efcfe:	00 00 
  6efd00:	4c 8b a4 24 98 00 00 	mov    0x98(%rsp),%r12
  6efd07:	00 
  6efd08:	49 ff c4             	inc    %r12
  6efd0b:	48 89 d8             	mov    %rbx,%rax
  6efd0e:	48 c1 e0 07          	shl    $0x7,%rax
  6efd12:	48 8d 3c d8          	lea    (%rax,%rbx,8),%rdi
  6efd16:	48 03 7c 24 40       	add    0x40(%rsp),%rdi
  6efd1b:	ba 88 00 00 00       	mov    $0x88,%edx
  6efd20:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
  6efd27:	00 
  6efd28:	ff 15 ea ba 39 00    	call   *0x39baea(%rip)        # a8b818 <memcpy@GLIBC_2.14>
  6efd2e:	48 ff c3             	inc    %rbx
  6efd31:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
  6efd36:	4c 3b a4 24 80 00 00 	cmp    0x80(%rsp),%r12
  6efd3d:	00 
  6efd3e:	48 8b 6c 24 78       	mov    0x78(%rsp),%rbp
  6efd43:	0f 84 8f 04 00 00    	je     6f01d8 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x618>
  6efd49:	48 8b b5 80 05 00 00 	mov    0x580(%rbp),%rsi
  6efd50:	49 39 f4             	cmp    %rsi,%r12
  6efd53:	0f 83 1e 05 00 00    	jae    6f0277 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6b7>
  6efd59:	48 8b 9d 78 05 00 00 	mov    0x578(%rbp),%rbx
  6efd60:	4c 89 a4 24 98 00 00 	mov    %r12,0x98(%rsp)
  6efd67:	00 
  6efd68:	49 c1 e4 06          	shl    $0x6,%r12
  6efd6c:	4e 8b 44 23 20       	mov    0x20(%rbx,%r12,1),%r8
  6efd71:	80 bd 3a 07 00 00 00 	cmpb   $0x0,0x73a(%rbp)
  6efd78:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
  6efd7d:	4c 89 44 24 68       	mov    %r8,0x68(%rsp)
  6efd82:	74 0d                	je     6efd91 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6efd84:	80 bd 3e 07 00 00 00 	cmpb   $0x0,0x73e(%rbp)
  6efd8b:	0f 84 0f 01 00 00    	je     6efea0 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x2e0>
  6efd91:	45 31 ff             	xor    %r15d,%r15d
  6efd94:	4c 01 e3             	add    %r12,%rbx
  6efd97:	44 8b 63 38          	mov    0x38(%rbx),%r12d
  6efd9b:	41 81 e4 ff ff 01 00 	and    $0x1ffff,%r12d
  6efda2:	45 31 ed             	xor    %r13d,%r13d
  6efda5:	49 81 fc ff ff 01 00 	cmp    $0x1ffff,%r12
  6efdac:	0f 95 44 24 0e       	setne  0xe(%rsp)
  6efdb1:	0f b6 43 3d          	movzbl 0x3d(%rbx),%eax
  6efdb5:	2c 02                	sub    $0x2,%al
  6efdb7:	0f b6 c0             	movzbl %al,%eax
  6efdba:	b9 08 00 00 00       	mov    $0x8,%ecx
  6efdbf:	0f 42 c1             	cmovb  %ecx,%eax
  6efdc2:	88 44 24 0f          	mov    %al,0xf(%rsp)
  6efdc6:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
  6efdcb:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6efdd2:	00 
  6efdd3:	48 8d 05 d6 08 01 00 	lea    0x108d6(%rip),%rax        # 7006b0 <<gpui::element::Role as core::fmt::Debug>::fmt>
  6efdda:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  6efde1:	00 
  6efde2:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  6efde9:	00 
  6efdea:	48 8d 35 ca eb 95 ff 	lea    -0x6a1436(%rip),%rsi        # 4e9bb <anon.5558d0fc2e5366f92fec9016dadbf867.4.llvm.9438347653228867760>
  6efdf1:	48 8d 94 24 a0 00 00 	lea    0xa0(%rsp),%rdx
  6efdf8:	00 
  6efdf9:	ff 15 c9 bc 39 00    	call   *0x39bcc9(%rip)        # a8bac8 <_DYNAMIC+0x510>
  6efdff:	4c 8b b4 24 b0 00 00 	mov    0xb0(%rsp),%r14
  6efe06:	00 
  6efe07:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  6efe0e:	00 
  6efe0f:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
  6efe16:	00 
  6efe17:	48 8b 6b 28          	mov    0x28(%rbx),%rbp
  6efe1b:	48 85 ed             	test   %rbp,%rbp
  6efe1e:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6efe23:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  6efe2a:	00 
  6efe2b:	74 63                	je     6efe90 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x2d0>
  6efe2d:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
  6efe32:	4c 8b 75 00          	mov    0x0(%rbp),%r14
  6efe36:	49 d1 ee             	shr    $1,%r14
  6efe39:	0f 84 11 01 00 00    	je     6eff50 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x390>
  6efe3f:	ff 15 b3 b9 39 00    	call   *0x39b9b3(%rip)        # a8b7f8 <_DYNAMIC+0x240>
  6efe45:	be 01 00 00 00       	mov    $0x1,%esi
  6efe4a:	4c 89 f7             	mov    %r14,%rdi
  6efe4d:	ff 15 ad b9 39 00    	call   *0x39b9ad(%rip)        # a8b800 <_DYNAMIC+0x248>
  6efe53:	48 85 c0             	test   %rax,%rax
  6efe56:	0f 84 2b 04 00 00    	je     6f0287 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6c7>
  6efe5c:	48 83 c5 10          	add    $0x10,%rbp
  6efe60:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6efe65:	48 89 c7             	mov    %rax,%rdi
  6efe68:	48 89 ee             	mov    %rbp,%rsi
  6efe6b:	4c 89 f2             	mov    %r14,%rdx
  6efe6e:	ff 15 a4 b9 39 00    	call   *0x39b9a4(%rip)        # a8b818 <memcpy@GLIBC_2.14>
  6efe74:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
  6efe79:	4c 89 f5             	mov    %r14,%rbp
  6efe7c:	e9 e4 00 00 00       	jmp    6eff65 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x3a5>
  6efe81:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6efe88:	0f 1f 84 00 00 00 00 
  6efe8f:	00 
  6efe90:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
  6efe97:	e9 ce 00 00 00       	jmp    6eff6a <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x3aa>
  6efe9c:	0f 1f 40 00          	nopl   0x0(%rax)
  6efea0:	48 8b 85 e8 01 00 00 	mov    0x1e8(%rbp),%rax
  6efea7:	48 85 c0             	test   %rax,%rax
  6efeaa:	0f 84 f3 01 00 00    	je     6f00a3 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x4e3>
  6efeb0:	83 f8 01             	cmp    $0x1,%eax
  6efeb3:	0f 85 17 02 00 00    	jne    6f00d0 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x510>
  6efeb9:	4c 8b bd f8 01 00 00 	mov    0x1f8(%rbp),%r15
  6efec0:	4d 85 ff             	test   %r15,%r15
  6efec3:	0f 84 35 02 00 00    	je     6f00fe <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x53e>
  6efec9:	48 8b 85 f0 01 00 00 	mov    0x1f0(%rbp),%rax
  6efed0:	31 c9                	xor    %ecx,%ecx
  6efed2:	49 83 ff 01          	cmp    $0x1,%r15
  6efed6:	74 2c                	je     6eff04 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x344>
  6efed8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6efedf:	00 
  6efee0:	48 89 ca             	mov    %rcx,%rdx
  6efee3:	4c 89 fe             	mov    %r15,%rsi
  6efee6:	48 d1 ee             	shr    $1,%rsi
  6efee9:	48 01 f1             	add    %rsi,%rcx
  6efeec:	48 89 cf             	mov    %rcx,%rdi
  6efeef:	48 c1 e7 04          	shl    $0x4,%rdi
  6efef3:	4c 39 04 38          	cmp    %r8,(%rax,%rdi,1)
  6efef7:	48 0f 47 ca          	cmova  %rdx,%rcx
  6efefb:	49 29 f7             	sub    %rsi,%r15
  6efefe:	49 83 ff 01          	cmp    $0x1,%r15
  6eff02:	77 dc                	ja     6efee0 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x320>
  6eff04:	48 89 ce             	mov    %rcx,%rsi
  6eff07:	48 c1 e6 04          	shl    $0x4,%rsi
  6eff0b:	31 d2                	xor    %edx,%edx
  6eff0d:	4c 39 04 30          	cmp    %r8,(%rax,%rsi,1)
  6eff11:	0f 96 c2             	setbe  %dl
  6eff14:	48 01 ca             	add    %rcx,%rdx
  6eff17:	0f 84 74 fe ff ff    	je     6efd91 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6eff1d:	48 c1 e2 04          	shl    $0x4,%rdx
  6eff21:	4c 89 c1             	mov    %r8,%rcx
  6eff24:	48 2b 4c 10 f0       	sub    -0x10(%rax,%rdx,1),%rcx
  6eff29:	8b 74 10 fc          	mov    -0x4(%rax,%rdx,1),%esi
  6eff2d:	48 39 f1             	cmp    %rsi,%rcx
  6eff30:	0f 83 5b fe ff ff    	jae    6efd91 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6eff36:	48 01 d0             	add    %rdx,%rax
  6eff39:	8b 40 f8             	mov    -0x8(%rax),%eax
  6eff3c:	48 01 c1             	add    %rax,%rcx
  6eff3f:	80 7c 24 34 00       	cmpb   $0x0,0x34(%rsp)
  6eff44:	0f 84 03 02 00 00    	je     6f014d <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x58d>
  6eff4a:	e9 21 02 00 00       	jmp    6f0170 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5b0>
  6eff4f:	90                   	nop
  6eff50:	b8 01 00 00 00       	mov    $0x1,%eax
  6eff55:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6eff5a:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
  6eff61:	00 00 
  6eff63:	31 ed                	xor    %ebp,%ebp
  6eff65:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
  6eff6a:	0f 10 43 10          	movups 0x10(%rbx),%xmm0
  6eff6e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  6eff73:	48 8d bc 24 38 01 00 	lea    0x138(%rsp),%rdi
  6eff7a:	00 
  6eff7b:	ff 15 4f bb 39 00    	call   *0x39bb4f(%rip)        # a8bad0 <_DYNAMIC+0x518>
  6eff81:	48 89 d1             	mov    %rdx,%rcx
  6eff84:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  6eff8b:	00 
  6eff8c:	48 89 de             	mov    %rbx,%rsi
  6eff8f:	48 89 c2             	mov    %rax,%rdx
  6eff92:	ff 15 40 bb 39 00    	call   *0x39bb40(%rip)        # a8bad8 <_DYNAMIC+0x520>
  6eff98:	8b 84 24 b0 00 00 00 	mov    0xb0(%rsp),%eax
  6eff9f:	85 c0                	test   %eax,%eax
  6effa1:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  6effa6:	75 18                	jne    6effc0 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x400>
  6effa8:	0f 28 84 24 60 01 00 	movaps 0x160(%rsp),%xmm0
  6effaf:	00 
  6effb0:	0f 28 8c 24 50 01 00 	movaps 0x150(%rsp),%xmm1
  6effb7:	00 
  6effb8:	eb 17                	jmp    6effd1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x411>
  6effba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  6effc0:	0f 10 84 24 b4 00 00 	movups 0xb4(%rsp),%xmm0
  6effc7:	00 
  6effc8:	f2 0f 10 8c 24 c4 00 	movsd  0xc4(%rsp),%xmm1
  6effcf:	00 00 
  6effd1:	0f b6 4c 24 0e       	movzbl 0xe(%rsp),%ecx
  6effd6:	41 88 cd             	mov    %cl,%r13b
  6effd9:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  6effde:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
  6effe5:	00 
  6effe6:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
  6effed:	00 
  6effee:	4c 89 a4 24 b8 00 00 	mov    %r12,0xb8(%rsp)
  6efff5:	00 
  6efff6:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
  6efffd:	00 
  6efffe:	48 89 94 24 c8 00 00 	mov    %rdx,0xc8(%rsp)
  6f0005:	00 
  6f0006:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  6f000d:	00 
  6f000e:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
  6f0015:	00 
  6f0016:	48 89 ac 24 d8 00 00 	mov    %rbp,0xd8(%rsp)
  6f001d:	00 
  6f001e:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  6f0023:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
  6f002a:	00 
  6f002b:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
  6f0030:	4c 89 b4 24 e8 00 00 	mov    %r14,0xe8(%rsp)
  6f0037:	00 
  6f0038:	0f 28 54 24 10       	movaps 0x10(%rsp),%xmm2
  6f003d:	0f 11 94 24 f8 00 00 	movups %xmm2,0xf8(%rsp)
  6f0044:	00 
  6f0045:	89 84 24 18 01 00 00 	mov    %eax,0x118(%rsp)
  6f004c:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  6f0053:	00 
  6f0054:	0f 11 84 24 1c 01 00 	movups %xmm0,0x11c(%rsp)
  6f005b:	00 
  6f005c:	0f 29 8c 24 50 01 00 	movaps %xmm1,0x150(%rsp)
  6f0063:	00 
  6f0064:	0f 13 8c 24 2c 01 00 	movlps %xmm1,0x12c(%rsp)
  6f006b:	00 
  6f006c:	4c 89 bc 24 08 01 00 	mov    %r15,0x108(%rsp)
  6f0073:	00 
  6f0074:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  6f007b:	00 
  6f007c:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
  6f0083:	00 
  6f0084:	48 8b 5c 24 48       	mov    0x48(%rsp),%rbx
  6f0089:	48 3b 5c 24 38       	cmp    0x38(%rsp),%rbx
  6f008e:	0f 85 6c fc ff ff    	jne    6efd00 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x140>
  6f0094:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  6f0099:	e8 b2 3b 02 00       	call   713c50 <<alloc::raw_vec::RawVec<gpui::runtime::SnapshotNode>>::grow_one>
  6f009e:	e9 5d fc ff ff       	jmp    6efd00 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x140>
  6f00a3:	4c 89 c1             	mov    %r8,%rcx
  6f00a6:	48 2b 8d f0 01 00 00 	sub    0x1f0(%rbp),%rcx
  6f00ad:	0f 82 de fc ff ff    	jb     6efd91 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f00b3:	48 3b 8d f8 01 00 00 	cmp    0x1f8(%rbp),%rcx
  6f00ba:	0f 83 d1 fc ff ff    	jae    6efd91 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f00c0:	80 7c 24 34 00       	cmpb   $0x0,0x34(%rsp)
  6f00c5:	0f 84 82 00 00 00    	je     6f014d <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x58d>
  6f00cb:	e9 a0 00 00 00       	jmp    6f0170 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5b0>
  6f00d0:	4c 8b bd f8 01 00 00 	mov    0x1f8(%rbp),%r15
  6f00d7:	4d 85 ff             	test   %r15,%r15
  6f00da:	74 22                	je     6f00fe <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x53e>
  6f00dc:	48 8b 85 f0 01 00 00 	mov    0x1f0(%rbp),%rax
  6f00e3:	49 83 ff 01          	cmp    $0x1,%r15
  6f00e7:	75 1a                	jne    6f0103 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x543>
  6f00e9:	4c 39 00             	cmp    %r8,(%rax)
  6f00ec:	0f 85 9f fc ff ff    	jne    6efd91 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f00f2:	8b 48 08             	mov    0x8(%rax),%ecx
  6f00f5:	80 7c 24 34 00       	cmpb   $0x0,0x34(%rsp)
  6f00fa:	74 51                	je     6f014d <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x58d>
  6f00fc:	eb 72                	jmp    6f0170 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5b0>
  6f00fe:	e9 91 fc ff ff       	jmp    6efd94 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d4>
  6f0103:	31 c9                	xor    %ecx,%ecx
  6f0105:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6f010c:	00 00 00 00 
  6f0110:	48 89 ca             	mov    %rcx,%rdx
  6f0113:	4c 89 fe             	mov    %r15,%rsi
  6f0116:	48 d1 ee             	shr    $1,%rsi
  6f0119:	48 01 f1             	add    %rsi,%rcx
  6f011c:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
  6f0120:	4c 39 04 b8          	cmp    %r8,(%rax,%rdi,4)
  6f0124:	48 0f 47 ca          	cmova  %rdx,%rcx
  6f0128:	49 29 f7             	sub    %rsi,%r15
  6f012b:	49 83 ff 01          	cmp    $0x1,%r15
  6f012f:	77 df                	ja     6f0110 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x550>
  6f0131:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  6f0135:	4c 39 04 88          	cmp    %r8,(%rax,%rcx,4)
  6f0139:	0f 85 52 fc ff ff    	jne    6efd91 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f013f:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
  6f0143:	8b 48 08             	mov    0x8(%rax),%ecx
  6f0146:	80 7c 24 34 00       	cmpb   $0x0,0x34(%rsp)
  6f014b:	75 23                	jne    6f0170 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5b0>
  6f014d:	48 8b b5 a0 02 00 00 	mov    0x2a0(%rbp),%rsi
  6f0154:	48 39 f1             	cmp    %rsi,%rcx
  6f0157:	0f 83 3a 01 00 00    	jae    6f0297 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6d7>
  6f015d:	48 8b 85 98 02 00 00 	mov    0x298(%rbp),%rax
  6f0164:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
  6f0168:	48 83 7c c8 08 00    	cmpq   $0x0,0x8(%rax,%rcx,8)
  6f016e:	74 1e                	je     6f018e <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5ce>
  6f0170:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
  6f0175:	4c 89 c6             	mov    %r8,%rsi
  6f0178:	ff 15 b2 b7 39 00    	call   *0x39b7b2(%rip)        # a8b930 <_DYNAMIC+0x378>
  6f017e:	48 89 94 24 88 00 00 	mov    %rdx,0x88(%rsp)
  6f0185:	00 
  6f0186:	49 89 c7             	mov    %rax,%r15
  6f0189:	e9 06 fc ff ff       	jmp    6efd94 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d4>
  6f018e:	48 8d 04 c8          	lea    (%rax,%rcx,8),%rax
  6f0192:	8b 40 20             	mov    0x20(%rax),%eax
  6f0195:	83 e0 0f             	and    $0xf,%eax
  6f0198:	8d 48 fd             	lea    -0x3(%rax),%ecx
  6f019b:	83 f9 07             	cmp    $0x7,%ecx
  6f019e:	0f 82 ed fb ff ff    	jb     6efd91 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d1>
  6f01a4:	41 bf 00 00 00 00    	mov    $0x0,%r15d
  6f01aa:	83 f8 02             	cmp    $0x2,%eax
  6f01ad:	0f 82 e1 fb ff ff    	jb     6efd94 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x1d4>
  6f01b3:	4c 8b 44 24 68       	mov    0x68(%rsp),%r8
  6f01b8:	74 b6                	je     6f0170 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x5b0>
  6f01ba:	48 8d 3d 26 a8 96 ff 	lea    -0x6957da(%rip),%rdi        # 5a9e7 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2d7f>
  6f01c1:	48 8d 15 f8 2d 37 00 	lea    0x372df8(%rip),%rdx        # a62fc0 <anon.1c5b0003e3ef994ff4b4ae0ed5827262.10.llvm.7005437559848114461+0x9a0>
  6f01c8:	be 83 00 00 00       	mov    $0x83,%esi
  6f01cd:	ff 15 75 b6 39 00    	call   *0x39b675(%rip)        # a8b848 <_DYNAMIC+0x290>
  6f01d3:	e9 bd 00 00 00       	jmp    6f0295 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6d5>
  6f01d8:	0f 10 85 80 06 00 00 	movups 0x680(%rbp),%xmm0
  6f01df:	0f b6 85 3c 07 00 00 	movzbl 0x73c(%rbp),%eax
  6f01e6:	48 83 bd a0 06 00 00 	cmpq   $0x0,0x6a0(%rbp)
  6f01ed:	00 
  6f01ee:	74 21                	je     6f0211 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x651>
  6f01f0:	84 c0                	test   %al,%al
  6f01f2:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  6f01f7:	74 0a                	je     6f0203 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x643>
  6f01f9:	48 83 bd 88 05 00 00 	cmpq   $0xffffffffffffffff,0x588(%rbp)
  6f0200:	ff 
  6f0201:	74 17                	je     6f021a <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x65a>
  6f0203:	48 8b 95 b0 06 00 00 	mov    0x6b0(%rbp),%rdx
  6f020a:	b9 01 00 00 00       	mov    $0x1,%ecx
  6f020f:	eb 0b                	jmp    6f021c <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x65c>
  6f0211:	31 c9                	xor    %ecx,%ecx
  6f0213:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  6f0218:	eb 02                	jmp    6f021c <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x65c>
  6f021a:	31 c9                	xor    %ecx,%ecx
  6f021c:	0f b6 b5 3e 07 00 00 	movzbl 0x73e(%rbp),%esi
  6f0223:	4c 8b 44 24 48       	mov    0x48(%rsp),%r8
  6f0228:	4c 89 47 20          	mov    %r8,0x20(%rdi)
  6f022c:	0f 10 4c 24 38       	movups 0x38(%rsp),%xmm1
  6f0231:	0f 11 4f 10          	movups %xmm1,0x10(%rdi)
  6f0235:	48 89 0f             	mov    %rcx,(%rdi)
  6f0238:	48 89 57 08          	mov    %rdx,0x8(%rdi)
  6f023c:	0f 11 47 28          	movups %xmm0,0x28(%rdi)
  6f0240:	0f 10 85 90 06 00 00 	movups 0x690(%rbp),%xmm0
  6f0247:	0f 11 47 38          	movups %xmm0,0x38(%rdi)
  6f024b:	f2 0f 10 85 30 07 00 	movsd  0x730(%rbp),%xmm0
  6f0252:	00 
  6f0253:	0f c6 c0 e1          	shufps $0xe1,%xmm0,%xmm0
  6f0257:	0f 13 47 48          	movlps %xmm0,0x48(%rdi)
  6f025b:	88 47 50             	mov    %al,0x50(%rdi)
  6f025e:	40 88 77 51          	mov    %sil,0x51(%rdi)
  6f0262:	48 89 f8             	mov    %rdi,%rax
  6f0265:	48 81 c4 78 01 00 00 	add    $0x178,%rsp
  6f026c:	5b                   	pop    %rbx
  6f026d:	41 5c                	pop    %r12
  6f026f:	41 5d                	pop    %r13
  6f0271:	41 5e                	pop    %r14
  6f0273:	41 5f                	pop    %r15
  6f0275:	5d                   	pop    %rbp
  6f0276:	c3                   	ret
  6f0277:	4c 89 e7             	mov    %r12,%rdi
  6f027a:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  6f027f:	ff 15 9b b6 39 00    	call   *0x39b69b(%rip)        # a8b920 <_DYNAMIC+0x368>
  6f0285:	eb 0e                	jmp    6f0295 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6d5>
  6f0287:	bf 01 00 00 00       	mov    $0x1,%edi
  6f028c:	4c 89 f6             	mov    %r14,%rsi
  6f028f:	ff 15 3b b6 39 00    	call   *0x39b63b(%rip)        # a8b8d0 <_DYNAMIC+0x318>
  6f0295:	0f 0b                	ud2
  6f0297:	48 89 cf             	mov    %rcx,%rdi
  6f029a:	48 8d 05 4f 2d 37 00 	lea    0x372d4f(%rip),%rax        # a62ff0 <anon.1c5b0003e3ef994ff4b4ae0ed5827262.10.llvm.7005437559848114461+0x9d0>
  6f02a1:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6f02a6:	eb d2                	jmp    6f027a <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x6ba>
  6f02a8:	48 89 c3             	mov    %rax,%rbx
  6f02ab:	eb 59                	jmp    6f0306 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x746>
  6f02ad:	48 89 c3             	mov    %rax,%rbx
  6f02b0:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  6f02b7:	00 
  6f02b8:	e8 13 4e ff ff       	call   6e50d0 <core::ptr::drop_glue::<gpui::runtime::SnapshotNode>>
  6f02bd:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  6f02c2:	e8 b9 3b ff ff       	call   6e3e80 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::SnapshotNode>>>
  6f02c7:	48 89 df             	mov    %rbx,%rdi
  6f02ca:	e8 21 0f 37 00       	call   a611f0 <_Unwind_Resume@plt>
  6f02cf:	eb 00                	jmp    6f02d1 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x711>
  6f02d1:	48 89 c3             	mov    %rax,%rbx
  6f02d4:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  6f02d9:	e8 a2 3b ff ff       	call   6e3e80 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::SnapshotNode>>>
  6f02de:	48 89 df             	mov    %rbx,%rdi
  6f02e1:	e8 0a 0f 37 00       	call   a611f0 <_Unwind_Resume@plt>
  6f02e6:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
  6f02eb:	48 89 c3             	mov    %rax,%rbx
  6f02ee:	48 85 ed             	test   %rbp,%rbp
  6f02f1:	7e 13                	jle    6f0306 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x746>
  6f02f3:	ba 01 00 00 00       	mov    $0x1,%edx
  6f02f8:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6f02fd:	48 89 ee             	mov    %rbp,%rsi
  6f0300:	ff 15 02 b5 39 00    	call   *0x39b502(%rip)        # a8b808 <_DYNAMIC+0x250>
  6f0306:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
  6f030c:	74 15                	je     6f0323 <<gpui::runtime::Win<route_columns_cost::Page>>::snapshot_with_targets+0x763>
  6f030e:	ba 01 00 00 00       	mov    $0x1,%edx
  6f0313:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
  6f0318:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  6f031d:	ff 15 e5 b4 39 00    	call   *0x39b4e5(%rip)        # a8b808 <_DYNAMIC+0x250>
  6f0323:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  6f0328:	e8 53 3b ff ff       	call   6e3e80 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::runtime::SnapshotNode>>>
  6f032d:	48 89 df             	mov    %rbx,%rdi
  6f0330:	e8 bb 0e 37 00       	call   a611f0 <_Unwind_Resume@plt>
