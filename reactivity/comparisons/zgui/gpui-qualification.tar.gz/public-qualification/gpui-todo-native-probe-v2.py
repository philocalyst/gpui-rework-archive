from pathlib import Path
import ctypes as C,hashlib,json,os,signal,struct,subprocess,tempfile,threading,time,zlib
out=Path('/tmp/gpui-todo-native-probe-v2');out.mkdir(exist_ok=False)
xd='/nix/store/qvckv6m6ycsa8f26w0f20mzk5w4v9ciq-xdotool-4.20260303.1/bin/xdotool'
xv='/nix/store/iw8dx6lhrkdc5wzszjzqzl677y68y88r-xvfb-21.1.24/bin/Xvfb'
bin=Path('/tmp/gpui-todo-comparison-qualified/gpui-todo-frozen')
assert not Path('/tmp/.X11-unix/X242').exists() and not Path('/tmp/.X242-lock').exists()
env={**os.environ,'DISPLAY':':242','TODO_BENCH_RENDERER':'gpu','TODO_BENCH_MODE':'idle','TODO_BENCH_SECONDS':'120','LP_NUM_THREADS':'4'}
env.pop('WAYLAND_DISPLAY',None)
lines=[];first=threading.Event();owned=[]
def xdo(*args):return subprocess.check_output([xd,*map(str,args)],env=env,text=True).strip()
def close_normal(window):
 class Data(C.Union):
  _fields_=[('b',C.c_char*20),('s',C.c_short*10),('l',C.c_long*5)]
 class Client(C.Structure):
  _fields_=[('type',C.c_int),('serial',C.c_ulong),('send_event',C.c_int),('display',C.c_void_p),('window',C.c_ulong),('message_type',C.c_ulong),('format',C.c_int),('data',Data)]
 class Event(C.Union):
  _fields_=[('client',Client),('pad',C.c_long*24)]
 lib=C.CDLL('libX11.so.6');lib.XOpenDisplay.argtypes=[C.c_char_p];lib.XOpenDisplay.restype=C.c_void_p
 lib.XInternAtom.argtypes=[C.c_void_p,C.c_char_p,C.c_int];lib.XInternAtom.restype=C.c_ulong
 lib.XSendEvent.argtypes=[C.c_void_p,C.c_ulong,C.c_int,C.c_long,C.POINTER(Event)];lib.XSendEvent.restype=C.c_int
 lib.XFlush.argtypes=[C.c_void_p];lib.XCloseDisplay.argtypes=[C.c_void_p]
 d=lib.XOpenDisplay(b':242');assert d
 event=Event();event.client.type=33;event.client.display=d;event.client.window=int(window)
 event.client.message_type=lib.XInternAtom(d,b'WM_PROTOCOLS',0);event.client.format=32
 event.client.data.l[0]=lib.XInternAtom(d,b'WM_DELETE_WINDOW',0);event.client.data.l[1]=0
 assert lib.XSendEvent(d,int(window),0,0,C.byref(event))!=0
 lib.XFlush(d);lib.XCloseDisplay(d)

def capture(window,name):
 lib=C.CDLL('libX11.so.6');lib.XOpenDisplay.argtypes=[C.c_char_p];lib.XOpenDisplay.restype=C.c_void_p
 lib.XGetImage.argtypes=[C.c_void_p,C.c_ulong,C.c_int,C.c_int,C.c_uint,C.c_uint,C.c_ulong,C.c_int];lib.XGetImage.restype=C.c_void_p
 lib.XGetPixel.argtypes=[C.c_void_p,C.c_int,C.c_int];lib.XGetPixel.restype=C.c_ulong
 lib.XDestroyImage.argtypes=[C.c_void_p];lib.XCloseDisplay.argtypes=[C.c_void_p]
 d=lib.XOpenDisplay(b':242');assert d
 image=lib.XGetImage(d,int(window),0,0,540,620,C.c_ulong(-1).value,2);assert image
 raw=bytearray()
 for y in range(620):
  raw.append(0)
  for x in range(540):
   p=lib.XGetPixel(image,x,y);raw.extend(((p>>16)&255,(p>>8)&255,p&255))
 lib.XDestroyImage(image);lib.XCloseDisplay(d)
 def chunk(t,b):return struct.pack('>I',len(b))+t+b+struct.pack('>I',zlib.crc32(t+b)&0xffffffff)
 png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',540,620,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(raw))+chunk(b'IEND',b'')
 (out/name).write_bytes(png)
 assert len(set(raw))>16,'blank framebuffer'
with tempfile.TemporaryDirectory(prefix='gpui-todo-native-runtime-') as runtime:
 os.chmod(runtime,0o700);env['XDG_RUNTIME_DIR']=runtime
 with (out/'xvfb.log').open('w') as xlog:
  try:
   server=subprocess.Popen([xv,':242','-screen','0','1024x800x24','-nolisten','tcp'],env=env,stdout=xlog,stderr=xlog);owned.append(server)
   deadline=time.monotonic()+10
   while not Path('/tmp/.X11-unix/X242').exists():
    assert time.monotonic()<deadline;time.sleep(.05)
   app=subprocess.Popen([str(bin)],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1);owned.append(app)
   def read():
    for line in app.stdout:
     lines.append(line)
     if line.startswith('TODO_FIRST_PRESENT,'):first.set()
   reader=threading.Thread(target=read);reader.start()
   assert first.wait(40),'first frame missing'
   window=xdo('search','--onlyvisible','--pid',app.pid).splitlines()[0]
   geom=xdo('getwindowgeometry','--shell',window);assert 'WIDTH=540' in geom and 'HEIGHT=620' in geom
   xdo('windowfocus','--sync',window);time.sleep(.1);capture(window,'initial.png')
   events=[]
   def click(name,x,y):
    xdo('mousemove','--sync','--window',window,x,y,'click',1);time.sleep(.15);events.append(name)
   click('input',160,90);xdo('type','--clearmodifiers','--delay',1,'bench-000');time.sleep(.15)
   for name,x,y in [('Add',340,90),('Complete',74,147),('Active',150,518),('Done',216,518),('All',98,518)]:click(name,x,y)
   capture(window,'done.png')
   click('Delete',392,147);capture(window,'deleted.png')
   click('Undo',200,568);capture(window,'undo.png')
   close_normal(window)
   app.wait(timeout=10);reader.join(timeout=3);assert not reader.is_alive()
   (out/'native.log').write_text(''.join(lines))
   model=json.loads(next(l.split(',',1)[1] for l in lines if l.startswith('TODO_MODEL,')))
   assert app.returncode==0,app.returncode
   assert model['callbacks']==7 and model['rows']==1 and model['done']==1 and model['draft']=='' and model['deleted'] is None,model
   assert model['filter']=='All' and model['next_id']==1 and model['first_task']=={'id':0,'title':'bench-000','done':True},model
   frames=json.loads(next(l.split(',',1)[1] for l in lines if l.startswith('TODO_FRAMES,')));assert frames['observer_overflow']==0
   assert any(l.startswith('TODO_RENDERER,Gpu') for l in lines)
   (out/'result.json').write_text(json.dumps({'binary_sha256':hashlib.sha256(bin.read_bytes()).hexdigest(),'events':events,'geometry':geom,'exit':app.returncode,'model':model,'frames':len(frames['elapsed_ns']),'renderer':'Gpu via llvmpipe software Vulkan'},indent=2)+'\n')
   print(json.dumps({'exit':app.returncode,'callbacks':model['callbacks'],'frames':len(frames['elapsed_ns']),'screenshots':4}),flush=True)
  finally:
   (out/'native.log').write_text(''.join(lines))
   for p in reversed(owned):
    if p.poll() is None:
     p.terminate()
     try:p.wait(timeout=5)
     except subprocess.TimeoutExpired:p.kill();p.wait()
