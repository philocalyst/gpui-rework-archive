# Five native Todo applications

All values belong to the frozen adapters and rendering paths in manifest.json. Failed work remains raw overload evidence; it is excluded from passing medians. CPU includes software renderer workers and excludes Xvfb and the observer. 100% means one occupied logical core. Readback overhead is recorded per input action.

Startup is warm page cache, external spawn to the first host drawing/submission receipt. Internal boundaries differ by backend and are recorded. No cache drop or true cold-start claim is made.

| Application | Mode | Passing / captured | CPU % | Peak PSS KiB | Host interval p95 µs |
| --- | --- | ---: | ---: | ---: | ---: |
| gpui | idle | 1 / 1 | 0.00 | 130637.00 | unavailable |
| gpui | busy | 1 / 1 | 60.83 | 133942.00 | 282300.00 |
| gpui | heavy | 0 / 1 | unavailable | unavailable | unavailable |
| gpui | animation | 0 / 1 | unavailable | unavailable | unavailable |
| gpui | startup | 1 / 1 | unavailable | unavailable | unavailable |
| zeronsh-zgui | idle | 1 / 1 | 0.50 | 105283.00 | unavailable |
| zeronsh-zgui | busy | 1 / 1 | 5.49 | 109195.00 | 211830.00 |
| zeronsh-zgui | heavy | 0 / 1 | unavailable | unavailable | unavailable |
| zeronsh-zgui | animation | 1 / 1 | 72.99 | 138036.00 | 18825.00 |
| zeronsh-zgui | startup | 1 / 1 | unavailable | unavailable | unavailable |
| zortax-zgui | idle | 1 / 1 | 0.00 | 184676.00 | unavailable |
| zortax-zgui | busy | 1 / 1 | 16.45 | 188117.00 | 225328.00 |
| zortax-zgui | heavy | 0 / 1 | unavailable | unavailable | unavailable |
| zortax-zgui | animation | 0 / 1 | unavailable | unavailable | unavailable |
| zortax-zgui | startup | 1 / 1 | unavailable | unavailable | unavailable |
| nanoui | idle | 1 / 1 | 0.00 | 148412.00 | unavailable |
| nanoui | busy | 1 / 1 | 70.80 | 148565.00 | 185281.00 |
| nanoui | heavy | 0 / 1 | unavailable | unavailable | unavailable |
| nanoui | animation | 1 / 1 | 184.79 | 151797.00 | 17843.00 |
| nanoui | startup | 1 / 1 | unavailable | unavailable | unavailable |
| mygo | idle | 1 / 1 | 0.50 | 166832.00 | unavailable |
| mygo | busy | 1 / 1 | 15.95 | 168992.00 | 205983.00 |
| mygo | heavy | 0 / 1 | unavailable | unavailable | unavailable |
| mygo | animation | 0 / 1 | unavailable | unavailable | unavailable |
| mygo | startup | 1 / 1 | unavailable | unavailable | unavailable |

Hardware GPU utilization and physical display smoothness are unsupported unless separately demonstrated by hardware identity, an appropriate hardware counter and a real display. Software GL/Vulkan activity is not hardware GPU utilization.

Failure and unsupported reasons:

- gpui/heavy/r1: failed contract: interactive_work_matched; drawable acknowledged=False.
- zeronsh-zgui/heavy/r1: failed contract: interactive_work_matched; drawable acknowledged=False.
- zortax-zgui/heavy/r1: failed contract: interactive_work_matched; drawable acknowledged=False.
- nanoui/heavy/r1: failed contract: required evidence missing; drawable acknowledged=False.
- mygo/heavy/r1: failed contract: required evidence missing; drawable acknowledged=False.
- gpui/animation/r1: failed contract: animation_work_matched; drawable acknowledged=True.
- zortax-zgui/animation/r1: failed contract: animation_work_matched; drawable acknowledged=True.
- mygo/animation/r1: failed contract: animation_work_matched; drawable acknowledged=True.
