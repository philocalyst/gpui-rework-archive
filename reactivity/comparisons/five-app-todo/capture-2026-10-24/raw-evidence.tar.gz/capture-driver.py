import datetime,hashlib,json,os,signal,subprocess,sys,time,traceback
from pathlib import Path
T=Path('/home/miles/gpui-ce3-compute-20261024');D=T/'evidence/five-app';R=T/'src/five-app/runner';sys.path.insert(0,str(R));import run,fault_controls
status={'pid':os.getpid(),'process_group':os.getpgrp(),'state':'starting','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fault_output':str(D/'fault-controls-quiet'),'capture_output':str(D/'capture-20261024'),'source_edits_during_capture':False}
def save(): (D/'capture-supervisor.json').write_text(json.dumps(status,indent=2)+'\n')
def stop(signum,frame): raise KeyboardInterrupt(f'supervisor received signal {signum}')
for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGALRM):signal.signal(sig,stop)
signal.alarm(3600)
os.environ.update(DISPLAY=':271',XDG_RUNTIME_DIR=str(T/'runtime/five-app'),LIBGL_DRIVERS_PATH='/nix/store/dv3gad7cjnnnzbfsv7jslvj9fmn5420j-mesa-26.1.4/lib/dri',LIBGL_ALWAYS_SOFTWARE='1',GALLIUM_DRIVER='llvmpipe',TODO_X11_LIBRARY='/nix/store/rck9w8gj3r2w2z1xpw15g1fvpzi8iz9h-libx11-1.8.13/lib/libX11.so.6')
status['harness_sha256']={p.name:run.core.file_sha256(p) for p in (R/'run.py',R/'todo_core.py',R/'fault_controls.py',Path(__file__))};save();display=None
try:
 if run.active_builds():raise RuntimeError('build processes remain before capture supervisor')
 display=subprocess.Popen(['/nix/store/iw8dx6lhrkdc5wzszjzqzl677y68y88r-xvfb-21.1.24/bin/Xvfb',':271','-screen','0','1280x1024x24','-nolisten','tcp'],stdout=(D/'xvfb-capture.log').open('wb'),stderr=subprocess.STDOUT,start_new_session=True)
 status['xvfb_pid']=display.pid;save();time.sleep(1)
 if display.poll() is not None:raise RuntimeError('owned Xvfb did not start')
 common=['--manifest',str(D/'manifest.json'),'--lease',str(T/'host.lock'),'--historical-archive',str(D/'historical/results-20261023.jsonl')]
 status['state']='actual-negative-controls';save();original_wait=run.core.wait_first_present
 try:
  sys.argv=['fault_controls.py',*common,'--output',str(D/'fault-controls-quiet')];code=fault_controls.main()
 finally:run.core.wait_first_present=original_wait
 status['fault_return_code']=code;save()
 if code:raise RuntimeError('actual native fault controls did not all pass; no performance campaign started')
 status['state']='measuring-exclusive-serial-matrix';status['measurement_started_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 sys.argv=['run.py',*common,'--output',str(D/'capture-20261024'),'--qualification',str(D/'qualification.json')]
 code=run.main();status['capture_return_code']=code
 result=json.loads((D/'capture-20261024/campaign-status.json').read_text());status['campaign_status']=result
 status['state']='complete' if result['capture_complete'] else 'incomplete'
except BaseException as error:
 status['state']='failed';status['error']=repr(error);status['traceback']=traceback.format_exc();traceback.print_exc()
finally:
 run.core.close_active_children()
 if display and display.poll() is None:
  os.killpg(display.pid,signal.SIGTERM)
  try:display.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(display.pid,signal.SIGKILL);display.wait()
 status['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();status['harness_unchanged']=all(run.core.file_sha256(R/name if name!='capture-driver.py' else Path(__file__))==digest for name,digest in status['harness_sha256'].items());save()
