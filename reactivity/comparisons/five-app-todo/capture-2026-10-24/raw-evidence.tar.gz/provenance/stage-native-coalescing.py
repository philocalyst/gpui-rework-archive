from pathlib import Path
import shutil,hashlib,json
T=Path('/home/miles/gpui-ce3-compute-20261024');src=T/'src/five-app/zeronsh-zgui';dst=T/'src/five-app/zeronsh-native-present-control-v1'
assert not dst.exists();shutil.copytree(src,dst,symlinks=True)
p=dst/'crates/zgui-desktop/src/todo_bench.rs';s=p.read_text();s=s.replace('    overflow: u64,','    overflow: u64,\n    native_interval: Option<Duration>,\n    native_deferred_draws: u64,')
s=s.replace('        r.overflow = 0;','        r.overflow = 0;\n        r.native_interval = std::env::var("TODO_TEST_NATIVE_PRESENT_INTERVAL_MS").ok().map(|v| Duration::from_millis(v.parse().expect("positive native interval")));\n        r.native_deferred_draws = 0;')
s=s.replace('    eprintln!(\n        "TODO_FRAMES,','    eprintln!("TODO_NATIVE_PRESENT_CONTROL,{{\\\"interval_ms\\\":{},\\\"deferred_native_draws\\\":{}}}", r.native_interval.map(|v|v.as_millis()).unwrap_or(0), r.native_deferred_draws);\n    eprintln!(\n        "TODO_FRAMES,')
s+='''
/// Fault-control only: defer actual backend render/present while keeping UI/model work.
/// First successful presentation is never suppressed. The normal observer is unchanged.
pub(crate) fn test_defer_native_draw() -> bool {
    let Ok(mut r) = receipts().lock() else { return false };
    let (Some(interval), Some(start), Some(last)) = (r.native_interval, r.started, r.elapsed_ns.last().copied()) else { return false };
    if start.elapsed() < Duration::from_nanos(last) + interval {
        r.native_deferred_draws += 1;
        true
    } else { false }
}
''';p.write_text(s)
p=dst/'crates/zgui-desktop/src/application.rs';s=p.read_text();needle='''        // Native views: split this frame's paint into the planes under and''';assert s.count(needle)==1;s=s.replace(needle,'''        // Actual native-present starvation control, outside the sealed primary source.
        // Retain damage after flushing scene/model updates; no observer receipt is hidden.
        if !damage.is_empty() && crate::todo_bench::test_defer_native_draw() {
            self.force = true;
            return Ok(());
        }
'''+needle);p.write_text(s)
print(dst)
