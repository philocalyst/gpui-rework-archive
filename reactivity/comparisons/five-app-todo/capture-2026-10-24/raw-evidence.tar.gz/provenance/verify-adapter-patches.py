from pathlib import Path
import subprocess,json,tempfile,hashlib
R=Path('/tmp/gpui-four-framework-benchmark-sol/reactivity/comparisons/five-app-todo');D=Path('/tmp/gpui-four-framework-benchmark-sol-build/final-evidence/build-inputs/peer-exports');roots={'zeronsh-zgui':'/tmp/gpui-zeronsh-current-todo-luna','zortax-zgui':'/tmp/gpui-zortax-todo-luna','nanoui':'/tmp/gpui-current-nanoui-sol','mygo':'/tmp/gpui-current-mygo-sol'};results={}
for name,root in roots.items():
 manifest=json.loads((D/f'{name}-full-source-manifest.json').read_text());changed={f['path']:f for f in manifest['files'] if f['adapter_changed'] or f['upstream'] is None};patch=R/f'{name}.patch';reported={line.split('\t')[2] for line in subprocess.check_output(['git','apply','--numstat',str(patch)],text=True).splitlines()};assert changed.keys()==reported,(name,changed.keys()-reported,reported-changed.keys())
 with tempfile.TemporaryDirectory() as temp:
  t=Path(temp)
  for path,f in changed.items():
   if f['upstream'] is not None:
    p=t/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','-C',root,'show',manifest['upstream_commit']+':'+path]))
  subprocess.run(['git','apply',str(patch)],cwd=t,check=True)
  for path,f in changed.items():assert hashlib.sha256((t/path).read_bytes()).hexdigest()==f['sha256'],(name,path)
 results[name]={'patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),'changed_file_set_exact':True,'applied_changed_files_sha256_match_complete_export':True,'files':len(changed)}
print(json.dumps(results,indent=2));Path('/tmp/gpui-four-framework-benchmark-sol-build/final-evidence/adapter-patch-reconstruction.json').write_text(json.dumps(results,indent=2)+'\n')
