from pathlib import Path
import subprocess,json,hashlib,tarfile,io,os
out=Path('/tmp/gpui-four-framework-benchmark-sol-build/peer-exports');out.mkdir(exist_ok=True)
apps={'mygo':'/tmp/gpui-current-mygo-sol','nanoui':'/tmp/gpui-current-nanoui-sol','zeronsh-zgui':'/tmp/gpui-zeronsh-current-todo-luna','zortax-zgui':'/tmp/gpui-zortax-todo-luna'}
for app,root in apps.items():
 if os.environ.get('APP_FILTER') and app != os.environ['APP_FILTER']:continue
 root=Path(root)
 def git(*args):return subprocess.check_output(['git','-C',str(root),*args])
 pin=git('rev-parse','HEAD').decode().strip();raw=git('cat-file','commit',pin);assert hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==pin
 base={};gitlinks={}
 for rec in git('ls-tree','-rz','--full-tree',pin).split(b'\0'):
  if not rec:continue
  info,name=rec.split(b'\t',1);mode,kind,oid=info.decode().split()
  if kind=='commit':gitlinks[name.decode()]=oid;continue
  assert kind=='blob',(app,name,kind);base[name.decode()]={'mode':mode,'git_blob':oid}
 tracked=set(git('ls-files','-z').decode().rstrip('\0').split('\0'));assert set(base)|set(gitlinks)<=tracked
 tracked-=set(gitlinks)
 overlay=(tracked-set(base))|set(filter(None,git('ls-files','--others','--exclude-standard','-z').decode().split('\0')))
 names=tracked|overlay;entries=[];archive=out/f'{app}-full-build-source.tar.gz'
 with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
  for name in sorted(names):
   p=root/name;data=os.readlink(p).encode() if p.is_symlink() else p.read_bytes();actual_blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
   entry={'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'symlink':p.is_symlink(),'upstream':base.get(name),'adapter_changed':name not in base or base[name]['git_blob']!=actual_blob}
   entries.append(entry);tar.add(p,arcname=name,recursive=False)
 with tarfile.open(archive) as tar:assert set(tar.getnames())==names
 manifest={'application':app,'coverage':'complete upstream tracked blob set plus explicit visible untracked adapter files; no build-product path exclusions','upstream_commit':pin,'upstream_tree':git('rev-parse','HEAD^{tree}').decode().strip(),'raw_commit':raw.decode(),'gitlinks_without_expanded_source':gitlinks,'upstream_tracked_files':len(base),'adapter_untracked_files':sorted(overlay),'files':entries,'archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
 (out/f'{app}-full-source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(app,len(tracked),len(overlay),archive.stat().st_size,flush=True)
