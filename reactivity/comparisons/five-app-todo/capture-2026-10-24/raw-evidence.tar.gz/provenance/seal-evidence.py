from pathlib import Path
import gzip,hashlib,io,json,tarfile
D=Path('/tmp/gpui-four-framework-benchmark-sol-build/final-evidence');O=Path('/tmp/gpui-four-framework-benchmark-sol/reactivity/comparisons/five-app-todo/capture-2026-10-24');files=[];excluded=[]
for p in sorted(D.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(D).as_posix()
 if '__pycache__' in p.parts:continue
 with p.open('rb') as f:magic=f.read(4)
 data={'path':rel,'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()}
 if magic==b'\x7fELF' or rel.endswith('.previous-binary'):excluded.append({**data,'reason':'executable copy omitted; exact byte SHA256/build/source receipts retained and native frozen binaries remain on measurement host'});continue
 files.append(data)
inventory={'schema':1,'original_primary_rows':75,'files':files,'excluded_executable_copies':excluded,'source_coverage':'exact frozen complete peer tracked-file manifests and final adapter patches; GPUI explicitly anchored build scope','archive_contains':'all raw results, native logs, screenshots, historical regression, initialfailedbuilds/preflights, postcapture successors, actualnativefaults,Auto wrapperfailure/retry, source/build/ELF/loader inventories and scripts','all_original_observations_preserved':True}
encoded=(json.dumps(inventory,indent=2)+'\n').encode();(O/'evidence-inventory.json').write_bytes(encoded)
archive=O/'raw-evidence.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as compressed:
  with tarfile.open(fileobj=compressed,mode='w|') as tar:
   def add(rel,data):
    i=tarfile.TarInfo(rel);i.size=len(data);i.mode=0o644;i.mtime=0;tar.addfile(i,io.BytesIO(data))
   add('evidence-inventory.json',encoded)
   for f in files:
    data=(D/f['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==f['sha256'];add(f['path'],data)
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert {m.name for m in members}=={'evidence-inventory.json'}|{f['path'] for f in files}
 bypath={f['path']:f for f in files}
 for m in members:
  data=tar.extractfile(m).read()
  if m.name=='evidence-inventory.json':assert data==encoded
  else:assert len(data)==bypath[m.name]['bytes'] and hashlib.sha256(data).hexdigest()==bypath[m.name]['sha256']
receipt={'archive':'raw-evidence.tar.gz','sha256':hashlib.file_digest(archive.open('rb'),'sha256').hexdigest(),'bytes':archive.stat().st_size,'members':len(files)+1,'every_member_sha256_verified_after_write':True,'inventory_sha256':hashlib.sha256(encoded).hexdigest()};(O/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
