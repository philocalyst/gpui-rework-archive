from pathlib import Path
import hashlib,json,subprocess,tarfile
repo=Path('/tmp/gpui-four-framework-benchmark-sol');out=Path('/tmp/gpui-four-framework-benchmark-sol-build/export-gpui');out.mkdir(exist_ok=True)
base=Path('/tmp/gpui-four-framework-benchmark-sol-build');pin=subprocess.check_output(['git','-C',str(repo),'rev-parse','63e0a521f4'],text=True).strip()
scopes=['.cargo','clippy.toml','reactivity/Cargo.toml','reactivity/Cargo.lock','reactivity/rust-toolchain.toml','reactivity/crates','reactivity/vendor']
rawcommit=subprocess.check_output(['git','-C',str(repo),'cat-file','commit',pin]);assert hashlib.sha1(b'commit '+str(len(rawcommit)).encode()+b'\0'+rawcommit).hexdigest()==pin
listing=subprocess.check_output(['git','-C',str(repo),'ls-tree','-rz',pin,'--',*scopes]);expected={}
for entry in listing.split(b'\0'):
 if not entry:continue
 header,name=entry.split(b'\t',1);mode,kind,oid=header.decode().split();assert kind=='blob';expected[name.decode()]={'mode':mode,'git_blob':oid}
archive=base/'gpui-63e0a-build-source.tar'
with archive.open('wb') as f:subprocess.run(['git','-C',str(repo),'archive',pin,'--',*scopes],stdout=f,check=True)
seen=set()
with tarfile.open(archive) as tar:
 for member in tar.getmembers():
  if not (member.isfile() or member.issym()):continue
  payload=member.linkname.encode() if member.issym() else tar.extractfile(member).read()
  assert member.name in expected
  assert hashlib.sha1(b'blob '+str(len(payload)).encode()+b'\0'+payload).hexdigest()==expected[member.name]['git_blob']
  expected[member.name].update(sha256=hashlib.sha256(payload).hexdigest(),bytes=len(payload));seen.add(member.name)
 assert seen==set(expected)
 tar.extractall(out,filter='data')
paths=['reactivity/crates/gpui/Cargo.toml','reactivity/crates/gpui/examples/todo_comparison_five.rs','reactivity/crates/gpui/examples/support/todo_five.rs']
patch=base/'gpui-runtime-adapter.patch';patch.write_bytes(subprocess.check_output(['git','-C',str(repo),'diff','--binary','HEAD','--',*paths]))
subprocess.run(['git','apply','--unsafe-paths',str(patch)],cwd=out,check=True)
metadata={'pin':pin,'tree':subprocess.check_output(['git','-C',str(repo),'rev-parse',pin+'^{tree}'],text=True).strip(),'scope':scopes,'source_tar_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'adapter_patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),'commit_object':rawcommit.decode(),'files':expected,'status':'pre-accessibility-close-patch GPUI; benchmark adapter only'}
(out/'.benchmark-upstream.json').write_text(json.dumps(metadata,indent=2)+'\n');(base/'gpui-build-source-manifest.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps({'pin':pin,'files':len(expected),'archive_bytes':archive.stat().st_size,'archive_sha256':metadata['source_tar_sha256'],'overlay_sha256':metadata['adapter_patch_sha256']}))
