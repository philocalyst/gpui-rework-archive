from pathlib import Path
import hashlib,json,tarfile,gzip,io
B=Path('/tmp/gpui-four-framework-benchmark-sol-build');D=B/'final-evidence';O=Path('/tmp/gpui-four-framework-benchmark-sol/reactivity/comparisons/five-app-todo/capture-2026-10-24');selected=[];sources={}
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
for name in ('mygo','nanoui','zeronsh-zgui','zortax-zgui'):
 p=B/'peer-exports'/f'{name}-full-source-manifest.json';m=json.loads(p.read_text());archive=p.with_name(m['archive']);assert sha(archive)==m['archive_sha256']
 with tarfile.open(archive) as tar:
  members={f.name:f for f in tar.getmembers() if f.isfile() or f.issym()};assert members.keys()=={f['path'] for f in m['files']}
  for f in m['files']:
   entry=members[f['path']];data=entry.linkname.encode() if entry.issym() else tar.extractfile(entry).read();assert len(data)==f['bytes'] and hashlib.sha256(data).hexdigest()==f['sha256'],(name,f['path'])
 sources[name]={'archive_sha256':sha(archive),'members_verified':len(m['files']),'set_equality':True};selected += [(f'sources/{name}/{p.name}',p),(f'sources/{name}/{archive.name}',archive)]
gpui=json.loads((B/'gpui-build-source-manifest.json').read_text());assert sha(B/'gpui-63e0a-build-source.tar')==gpui['source_tar_sha256'];assert sha(B/'gpui-runtime-adapter.patch')==gpui['adapter_patch_sha256']
selected += [('sources/gpui/'+n,B/n) for n in ('gpui-63e0a-build-source.tar','gpui-build-source-manifest.json','gpui-runtime-adapter.patch','gpui-benchmark-overlay.patch')]
elfpaths={'gpui/release/examples/todo_comparison_five':'gpui-receipt.json','rust-peers/dist/examples/benchmark_todo':'zeronsh-zgui-retry4-receipt.json','rust-peers/release/examples/benchmark_todo':'zortax-zgui-qualified2-receipt.json','nanoui/bin/benchmark-todo':'nanoui-receipt.json','bin/mygo':'mygo-final-receipt.json','native-present-control/dist/examples/benchmark_todo':'native-present-control-v1-receipt.json'};elfs={}
with tarfile.open(B/'frozen-native-elfs.tar.gz') as tar:
 assert {m.name for m in tar.getmembers()}==elfpaths.keys()
 for name,receiptname in elfpaths.items():
  m=tar.getmember(name);data=tar.extractfile(m).read();r=json.loads((D/'builds'/receiptname).read_text());assert data.startswith(b'\x7fELF') and hashlib.sha256(data).hexdigest()==r['binary_sha256'] and len(data)==r['binary_bytes'];elfs[name]={'sha256':r['binary_sha256'],'bytes':len(data),'matching_build_receipt':receiptname}
selected += [('elfs/frozen-native-elfs.tar.gz',B/'frozen-native-elfs.tar.gz'),('controls/native-present-control-v1.patch',D/'native-present-control-v1.patch'),('controls/stage-native-coalescing.py',D/'stage-native-coalescing.py')]
manifest={'sources':sources,'gpui_scope':gpui['scope'],'gpui_full_repository_claim':False,'gpui_upstream_archive_sha256':gpui['source_tar_sha256'],'gpui_overlay_sha256':gpui['adapter_patch_sha256'],'elfs':elfs,'runtime':'ELFs require the pinned coherent Linux loader and dependency paths recorded in raw evidence; this is an artifact seal, not a portable app package','files':[{'path':n,'sha256':sha(p),'bytes':p.stat().st_size} for n,p in selected]}
outer=B/'five-app-frozen-sources-and-elfs-20261024.tar.gz';encoded=(json.dumps(manifest,indent=2)+'\n').encode()
with outer.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as z:
  with tarfile.open(fileobj=z,mode='w|') as tar:
   info=tarfile.TarInfo('artifact-inventory.json');info.size=len(encoded);info.mode=0o644;tar.addfile(info,io.BytesIO(encoded))
   for name,p in selected:
    info=tarfile.TarInfo(name);info.size=p.stat().st_size;info.mode=0o644
    with p.open('rb') as f:tar.addfile(info,f)
with tarfile.open(outer) as tar:
 assert {m.name for m in tar.getmembers()}=={'artifact-inventory.json'}|{n for n,p in selected}
 for f in manifest['files']:assert hashlib.file_digest(tar.extractfile(f['path']),'sha256').hexdigest()==f['sha256']
receipt={'artifact_path':str(outer),'bytes':outer.stat().st_size,'sha256':sha(outer),'every_outer_member_sha256_verified':True,'six_elfs_match_frozen_build_receipts':True,'four_peer_source_archives_complete_set_and_every_byte_hash_verified':True,'inventory':manifest};(O/'source-elf-artifact-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='inventory'},indent=2))
