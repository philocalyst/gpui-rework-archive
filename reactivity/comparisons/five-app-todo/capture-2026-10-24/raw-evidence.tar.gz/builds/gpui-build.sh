#!/usr/bin/env bash
set -euo pipefail
source /home/miles/gpui-ce3-compute-20261024/env.sh
export CARGO_HOME=/home/miles/.cargo CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0
export CARGO_TARGET_DIR=/home/miles/gpui-ce3-compute-20261024/targets/five-app/gpui
cd /home/miles/gpui-ce3-compute-20261024/src/five-app/gpui/reactivity
cargo build --offline --locked --release -p gpui --example todo_comparison_five --features x11
/nix/store/if2h609psbpg1ysf1m27dpshjk2wzpk4-patchelf-0.15.2/bin/patchelf --set-interpreter /nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib/ld-linux-x86-64.so.2 /home/miles/gpui-ce3-compute-20261024/targets/five-app/gpui/release/examples/todo_comparison_five
