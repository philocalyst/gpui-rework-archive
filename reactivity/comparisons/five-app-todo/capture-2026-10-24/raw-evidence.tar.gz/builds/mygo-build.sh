#!/usr/bin/env bash
set -euo pipefail
source /home/miles/gpui-ce3-compute-20261024/env.sh
export GOMAXPROCS=2 GOTOOLCHAIN=local GOFLAGS=-mod=readonly
export GOCACHE=/home/miles/gpui-ce3-compute-20261024/cache/five-app/go-build
export GOMODCACHE=/home/miles/gpui-ce3-compute-20261024/cache/five-app/go-mod
/home/miles/gpui-ce3-compute-20261024/toolchains/go/bin/go build -p 2 -trimpath -o /home/miles/gpui-ce3-compute-20261024/targets/five-app/bin/mygo ./examples/benchmark-todo
/nix/store/if2h609psbpg1ysf1m27dpshjk2wzpk4-patchelf-0.15.2/bin/patchelf --set-interpreter /nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib/ld-linux-x86-64.so.2 /home/miles/gpui-ce3-compute-20261024/targets/five-app/bin/mygo
