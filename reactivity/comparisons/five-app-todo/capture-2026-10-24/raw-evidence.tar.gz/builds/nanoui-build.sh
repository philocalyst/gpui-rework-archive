#!/usr/bin/env bash
set -euo pipefail
source /home/miles/gpui-ce3-compute-20261024/env.sh
export ZIG_GLOBAL_CACHE_DIR=/home/miles/gpui-ce3-compute-20261024/cache/five-app/zig-global
export ZIG_LOCAL_CACHE_DIR=/home/miles/gpui-ce3-compute-20261024/cache/five-app/zig-local
/home/miles/gpui-ce3-compute-20261024/toolchains/zig/zig build -j2 -Doptimize=ReleaseFast --prefix /home/miles/gpui-ce3-compute-20261024/targets/five-app/nanoui
/nix/store/if2h609psbpg1ysf1m27dpshjk2wzpk4-patchelf-0.15.2/bin/patchelf --set-interpreter /nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib/ld-linux-x86-64.so.2 /home/miles/gpui-ce3-compute-20261024/targets/five-app/nanoui/bin/benchmark-todo
