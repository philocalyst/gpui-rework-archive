import fcntl,json,os,subprocess,sys,time
from pathlib import Path
root=Path('/home/miles/gpui-ce3-compute-20261024');base=root/'evidence/five-app/builds'
with (base/'driver.lock').open('a+') as lane:
 fcntl.flock(lane,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for name in ('mygo','nanoui'):
  binary=root/'targets/five-app/bin/mygo' if name=='mygo' else root/'targets/five-app/nanoui/bin/benchmark-todo'
  status={'pid':os.getpid(),'state':'building','application':name,'jobs':2,'started_unix':time.time()};(base/'driver-status.json').write_text(json.dumps(status)+'\n')
  command=[sys.executable,str(root/'src/five-app/runner/build_one.py'),'--source',str(root/'src/five-app'/name),'--binary',str(binary),'--lease',str(root/'host.lock'),'--receipt',str(base/f'{name}-receipt.json'),'--log',str(base/f'{name}-build.log'),'--command-json',str(base/f'{name}-command.json'),'--compiler-version-json',str(root/'evidence/five-app/compiler-versions.json'),'--disk-floor-gib','8','--timeout','1800']
  result=subprocess.run(command)
  status.update(state='built' if result.returncode==0 else 'failed',exit_code=result.returncode,finished_unix=time.time());(base/'driver-status.json').write_text(json.dumps(status)+'\n')
  if result.returncode:sys.exit(result.returncode)
 (base/'driver-status.json').write_text(json.dumps({'pid':os.getpid(),'state':'complete','finished_unix':time.time()})+'\n')
