import json,os,subprocess,time
from pathlib import Path
T=Path('/home/miles/gpui-ce3-compute-20261024');D=T/'evidence/five-app/builds'
status={'pid':os.getpid(),'state':'running','applications':[]}
def write(): (D/'rust-peers-retry2-supervisor.json').write_text(json.dumps(status,indent=2))
write()
for app,profile in [('zeronsh-zgui','dist'),('zortax-zgui','release')]:
 cmd=['python3',str(T/'src/five-app/runner/build_one.py'),'--source',str(T/'src/five-app'/app),'--binary',str(T/'targets/five-app/rust-peers'/profile/'examples/benchmark_todo'),'--lease',str(T/'host.lock'),'--receipt',str(D/f'{app}-retry2-receipt.json'),'--log',str(D/f'{app}-retry2-build.log'),'--command-json',str(D/f'{app}-command.json'),'--timeout','2700']
 r=subprocess.run(cmd);status['applications'].append({'app':app,'exit_code':r.returncode});write()
status['state']='complete';write()
