#!/usr/bin/env bash
set -euo pipefail
source /home/miles/gpui-ce3-compute-20261024/env.sh
export CARGO_HOME=/home/miles/.cargo CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0 CARGO_PROFILE_DIST_DEBUG=0
export CARGO_TARGET_DIR=/home/miles/gpui-ce3-compute-20261024/targets/five-app/native-present-control
export PKG_CONFIG_PATH=/home/miles/gpui-ce3-compute-20261024/build-inputs/five-app/pkg-config
export PATH=/nix/store/sn8r7j6q1js540y5briylnb62203zxq5-pkg-config-wrapper-0.29.2/bin:$PATH
cd /home/miles/gpui-ce3-compute-20261024/src/five-app/zeronsh-native-present-control-v1
cargo build --offline --locked --profile dist -p zgui-desktop --example benchmark_todo
/nix/store/if2h609psbpg1ysf1m27dpshjk2wzpk4-patchelf-0.15.2/bin/patchelf --set-interpreter /nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib/ld-linux-x86-64.so.2 /home/miles/gpui-ce3-compute-20261024/targets/five-app/native-present-control/dist/examples/benchmark_todo
