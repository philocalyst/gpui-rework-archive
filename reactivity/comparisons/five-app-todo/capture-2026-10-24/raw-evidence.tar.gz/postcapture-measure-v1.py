"""Separate corrected-Heavy and visible-client-UI startup successors; no original edits."""
import datetime,fcntl,json,os,signal,subprocess,sys,time,traceback,ctypes
from pathlib import Path
T=Path('/home/miles/gpui-ce3-compute-20261024');D=T/'evidence/five-app';sys.path.insert(0,str(T/'src/five-app/runner'));import run as r
out=D/'postcapture-measure-v1';out.mkdir(exist_ok=False);manifest=json.loads((D/'manifest.json').read_text());r.core.XDOTOOL=manifest['xdotool'];r.core.EXPECTED_WINDOW_TITLES.update({n:a['title'] for n,a in manifest['apps'].items()})
status={'pid':os.getpid(),'pgid':os.getpgrp(),'state':'starting','original_capture_modified':False}
def save():(out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def stop(s,f):raise KeyboardInterrupt(s)
for s in(signal.SIGTERM,signal.SIGINT,signal.SIGALRM):signal.signal(s,stop)
signal.alarm(900);save();os.environ.update(DISPLAY=':273',XDG_RUNTIME_DIR=str(T/'runtime/five-app'),TODO_X11_LIBRARY='/nix/store/rck9w8gj3r2w2z1xpw15g1fvpzi8iz9h-libx11-1.8.13/lib/libX11.so.6');x=None

def anchors(draw,w):
 im=draw.x.XGetImage(draw.display,w,0,0,540,128,ctypes.c_ulong(-1).value,2)
 if not im:raise RuntimeError('anchor readback failed')
 try:
  a=im.contents;raw=ctypes.string_at(a.data,a.bytes_per_line*a.height)
  def ps(x0,y0,x1,y1):return [raw[y*a.bytes_per_line+x*4:y*a.bytes_per_line+x*4+3] for y in range(y0,y1) for x in range(x0,x1)]
  title=ps(24,24,115,62);field=ps(24,82,300,112);margin=ps(8,8,20,65)
  ink=sum(max(p)<180 for p in title);light=sum(min(p)>220 for p in title);tint=sum(min(p)>220 and max(p)-min(p)>=3 for p in field);background=sum(min(p)>220 for p in margin)
  return {'heading_dark_pixels':ink,'heading_light_pixels':light,'field_tinted_light_pixels':tint,'margin_light_pixels':background,'pass':ink>=40 and light>=1500 and tint>=500 and background>=500}
 finally:draw.x.XDestroyImage(im)
try:
 with (T/'host.lock').open('a+') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  if r.active_builds():raise RuntimeError('builds active')
  frozen=r.fingerprint(manifest);(out/'freeze.json').write_text(json.dumps(frozen,indent=2));(out/'anchor-policy.json').write_text(json.dumps({'scope':'visible known Todo chrome, not semantic OCR, frame cadence or scanout','zones':{'title':[24,24,115,62],'field':[24,82,300,112],'margin':[8,8,20,65]},'criteria':'title>=40 dark(maxRGB<180) and >=1500 light(minRGB>220); field>=500 light tinted(max-min>=3); margin>=500 light; marker valid revision0; no input/focus event sent before visible readback'},indent=2))
  x=subprocess.Popen(['/nix/store/iw8dx6lhrkdc5wzszjzqzl677y68y88r-xvfb-21.1.24/bin/Xvfb',':273','-screen','0','1280x1024x24','-nolisten','tcp'],stdout=(out/'xvfb.log').open('wb'),stderr=subprocess.STDOUT,start_new_session=True);time.sleep(1)
  app=manifest['apps']['zeronsh-zgui'];corrected={**app,'controls':{**app['controls'],'all':[118,519],'active':[177,519],'done':[247,519]}}
  (out/'heavy-control-delta.json').write_text(json.dumps({'original':app['controls'],'successor':corrected['controls'],'reason':'16px remaining-count text shifts filter buttons at10000rows; originalAll98 andDone216 outsidebuttonrectangles; onlycoordinateschanged, no app/source/binary/tolerances/workload changes'},indent=2))
  for rep in (1,2,3):
   status.update(state='corrected-heavy',repeat=rep);save()
   row=r.run_cell('zeronsh-zgui',corrected,'heavy',rep,out,30,5);row['source_and_binary_unchanged']=r.fingerprint(manifest)==frozen;row['original_runner_accepted']=r.accepted(row);row['successor_profile']='mode-specific-heavy-controls-v1';(out/'heavy-results.jsonl').open('a').write(json.dumps(row)+'\n');print('heavy',rep,row['original_runner_accepted'],flush=True)
  for rep in (1,2,3):
   for name in (r.APPS if rep%2 else reversed(r.APPS)):
    status.update(state='visible-ui-startup',variant=name,repeat=rep);save();app=manifest['apps'][name];child=None;draw=r.Drawable();row={'variant':name,'repeat':rep,'profile':'exec-to-visible-client-ui-v1','performance_pool':'separate-from-host-receipt-startup','sample_poll_interval_s':.01,'timeout_s':8,'screenshots':[]}
    try:
     env=r.core.comparison_environment();env.update(app['environment']);env.update(TODO_BENCH_MODE='idle',TODO_BENCH_ROWS='0',TODO_BENCH_ANIMATE='0',TODO_BENCH_TICK_HZ='60',TODO_BENCH_PRESENT_MARKER='1',TODO_BENCH_PRESENT_TRACE='1',TODO_BENCH_RENDERER='gpu',TODO_BENCH_SECONDS='120')
     log=out/f'{name}-visible-r{rep}.log';child=r.core.Child(Path(app['binary']),env,log);host=r.core.wait_first_present(child);w,*_=r.core.wait_window(child.proc.pid,app['title']);child.window_id=w
     deadline=time.monotonic()+8;first=True
     while True:
      seen=time.monotonic_ns();a=anchors(draw,w);m=draw.marker(w)
      if first:row['first_readback']={'monotonic_ns':seen,'anchors':a,'marker':m};row['screenshots'].append(draw.save(w,out/'screenshots'/f'{name}-visible-r{rep}-first.ppm'));first=False
      if a['pass'] and m.get('valid') and m.get('revision')==0:row.update(visible_ui_observed=True,exec_to_visible_ui_ms=(seen-child.started_ns)/1e6,visible_sample_monotonic_ns=seen,visible_anchor=a);break
      if time.monotonic()>=deadline:row.update(visible_ui_observed=False,exec_to_visible_ui_ms=None,failure='no visible Todo chrome anchors before8sdeadline',last_anchor=a);break
      time.sleep(.01)
     row['screenshots'].append(draw.save(w,out/'screenshots'/f'{name}-visible-r{rep}-last.ppm'));row.update(exec_to_host_receipt_ms=(host-child.started_ns)/1e6,started_monotonic_ns=child.started_ns,first_host_receipt_monotonic_ns=host);child.close_window(w);row.update(graceful_close=child.graceful_close,close_escalated=child.close_escalated,child_exit_code=child.proc.returncode)
    except BaseException as e:row.update(visible_ui_observed=False,error=repr(e),traceback=traceback.format_exc())
    finally:r.core.close_active_children();draw.close()
    row['source_and_binary_unchanged']=r.fingerprint(manifest)==frozen;(out/'visible-ui-results.jsonl').open('a').write(json.dumps(row)+'\n');print(name,rep,row.get('visible_ui_observed'),row.get('exec_to_visible_ui_ms'),flush=True)
  status['state']='complete'
except BaseException as e:status.update(state='failed',error=repr(e),traceback=traceback.format_exc())
finally:
 r.core.close_active_children()
 if x and x.poll() is None:os.killpg(x.pid,signal.SIGTERM);x.wait(timeout=10)
 status['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
