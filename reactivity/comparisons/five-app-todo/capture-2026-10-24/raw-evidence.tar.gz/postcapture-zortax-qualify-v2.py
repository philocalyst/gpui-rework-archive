"""Versioned, untimed Heavy input/visible-UI qualification; primary files untouched."""
import datetime,fcntl,json,os,signal,subprocess,sys,time,traceback
from pathlib import Path
T=Path('/home/miles/gpui-ce3-compute-20261024');D=T/'evidence/five-app';sys.path.insert(0,str(T/'src/five-app/runner'));import run as r
out=D/'postcapture-zortax-input-qualification-v2';out.mkdir(exist_ok=False)
status={'pid':os.getpid(),'pgid':os.getpgrp(),'state':'starting','performance_eligible':False}
def save():(out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def stop(s,f):raise KeyboardInterrupt(s)
for s in(signal.SIGINT,signal.SIGTERM,signal.SIGALRM):signal.signal(s,stop)
signal.alarm(900);save()
os.environ.update(DISPLAY=':272',XDG_RUNTIME_DIR=str(T/'runtime/five-app'),TODO_X11_LIBRARY='/nix/store/rck9w8gj3r2w2z1xpw15g1fvpzi8iz9h-libx11-1.8.13/lib/libX11.so.6')
manifest=json.loads((D/'manifest.json').read_text());r.core.XDOTOOL=manifest['xdotool'];x=None;results=[]
def command(*args):return subprocess.run([r.core.XDOTOOL,*map(str,args)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
def visible(path):
 raw=path.read_bytes().split(b'\n',3)[3]; pixels=[raw[(y*540+x)*3:(y*540+x)*3+3] for y in range(24,120) for x in range(24,280)]
 return {'nonblack_pixels':sum(any(c>31 for c in p) for p in pixels),'distinct_rgb':len(set(pixels)),'visible_ui_anchor':sum(any(c>31 for c in p) for p in pixels)>20000 and len(set(pixels))>16,'scope':'known Todo header/input region; nonblack and text/background diversity, not semantic OCR'}
try:
 with (T/'host.lock').open('a+') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  if r.active_builds():raise RuntimeError('builds active')
  frozen=r.fingerprint(manifest);(out/'freeze.json').write_text(json.dumps(frozen,indent=2))
  x=subprocess.Popen(['/nix/store/iw8dx6lhrkdc5wzszjzqzl677y68y88r-xvfb-21.1.24/bin/Xvfb',':272','-screen','0','1280x1024x24','-nolisten','tcp'],stdout=(out/'xvfb.log').open('wb'),stderr=subprocess.STDOUT,start_new_session=True);time.sleep(1)
  for name in ('zortax-zgui',):
   app=manifest['apps'][name];aout=out/name;aout.mkdir();child=None;draw=r.Drawable();row={'variant':name,'performance_eligible':False,'actions':[],'source_and_binary_before':frozen[name]}
   controls={**app['controls']}
   if name=='zeronsh-zgui':controls.update(all=[118,519],active=[177,519],done=[247,519])
   row['controls']=controls;row['changed_from_primary_controls']={k:v for k,v in controls.items() if v!=app['controls'][k]}
   try:
    receipt=json.loads(Path(app['build_receipt']).read_text());assert receipt['successful'] and receipt['source_after']==frozen[name]['source'] and receipt['binary_sha256']==frozen[name]['binary']
    env=r.core.comparison_environment();env.update(app['environment']);env.update(TODO_BENCH_MODE='heavy',TODO_BENCH_ROWS='10000',TODO_BENCH_ANIMATE='0',TODO_BENCH_TICK_HZ='60',TODO_BENCH_PRESENT_MARKER='1',TODO_BENCH_PRESENT_TRACE='1',TODO_BENCH_RENDERER='gpu',TODO_BENCH_SECONDS='120')
    child=r.core.Child(Path(app['binary']),env,aout/'app.log');r.core.wait_first_present(child);w,title,_,_,width,height=r.core.wait_window(child.proc.pid,app['title']);child.window_id=w;assert(width,height)==(540,620);command('windowfocus','--sync',w);time.sleep(5)
    draw.save(w,aout/'settled.ppm');row['settled_anchor']=visible(aout/'settled.ppm')
    callbacks=0
    for slot,kind in enumerate(r.core.BUSY_MACRO):
     point=controls['input' if kind=='type' else kind];assert command('mousemove','--sync','--window',w,*point);time.sleep(.05)
     if kind=='type':assert command('click','1');time.sleep(.05)
     region=(24,82,280,42) if kind in ('type','add') else (24,500,300,38) if kind in ('active','done','all') else (24,128,492,360)
     before=draw.digest(w,region);marker=draw.marker(w);draw.save(w,aout/f'{slot}-{kind}-before.ppm');start=time.monotonic()
     injected=command('type','--clearmodifiers','--delay','1','bench-000') if kind=='type' else command('click','1')
     if kind!='type':callbacks+=1
     deadline=start+12;expected_revision=callbacks
     while True:
      after=draw.digest(w,region);m=draw.marker(w);events=[json.loads(line[12:]) for line in child.log_lines() if line.startswith('TODO_ACTION,')]
      callback_ok=len(events)==callbacks and (kind=='type' or events[-1].get('action')==kind)
      ok=injected and before!=after and m.get('valid') and m.get('revision')==expected_revision and callback_ok
      if ok or time.monotonic()>=deadline:break
      time.sleep(.02)
     draw.save(w,aout/f'{slot}-{kind}-after.ppm');row['actions'].append({'action':kind,'passed':ok,'elapsed_seconds_diagnostic_only':time.monotonic()-start,'region':region,'before':before,'after':after,'marker_before':marker,'marker_after':m,'expected_revision':expected_revision,'callbacks_seen':events})
     if not ok:raise RuntimeError(f'{kind} did not qualify in 12s')
    child.close_window(w);row.update(r.semantic_receipts(aout/'app.log','heavy',2));row.update(graceful_close=child.graceful_close,close_escalated=child.close_escalated,child_exit_code=child.proc.returncode);row['qualified']=row['full_model_matched'] and row['ordered_callbacks_matched'] and row['graceful_close'] and all(a['passed'] for a in row['actions'])
   except BaseException as e:row.update(qualified=False,error=repr(e),traceback=traceback.format_exc())
   finally:
    r.core.close_active_children();draw.close();row['source_and_binary_unchanged']=r.fingerprint(manifest)==frozen;(aout/'result.json').write_text(json.dumps(row,indent=2)+'\n');results.append({'variant':name,'qualified':row['qualified'],'error':row.get('error'),'actions':[(a['action'],a['passed']) for a in row['actions']]});status.update(state='qualifying',results=results);save();print(json.dumps(results[-1]),flush=True)
  status['state']='complete';status['all_qualified']=all(v['qualified'] for v in results)
except BaseException as e:status.update(state='failed',error=repr(e),traceback=traceback.format_exc())
finally:
 r.core.close_active_children()
 if x and x.poll() is None:
  os.killpg(x.pid,signal.SIGTERM);x.wait(timeout=10)
 status['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
