#!/usr/bin/env bash
set -euo pipefail
T=/home/miles/gpui-ce3-compute-20261024
source "$T/env.sh"
exec 8>"$T/host.lock"
flock -s 8
D="$T/evidence/five-app"
python3 "$D/stage-native-coalescing.py"
cp -a --reflink=auto "$T/targets/five-app/rust-peers" "$T/targets/five-app/native-present-control"
python3 - <<'PY'
from pathlib import Path
import json
T=Path('/home/miles/gpui-ce3-compute-20261024');D=T/'evidence/five-app';s=(D/'builds/zeronsh-zgui-build.sh').read_text().replace('targets/five-app/rust-peers','targets/five-app/native-present-control').replace('src/five-app/zeronsh-zgui','src/five-app/zeronsh-native-present-control-v1')
(D/'builds/native-present-control-v1-build.sh').write_text(s);(D/'builds/native-present-control-v1-command.json').write_text(json.dumps(['bash',str(D/'builds/native-present-control-v1-build.sh')]))
PY
python3 "$T/src/five-app/runner/build_one.py" --source "$T/src/five-app/zeronsh-native-present-control-v1" --binary "$T/targets/five-app/native-present-control/dist/examples/benchmark_todo" --lease "$T/host.lock" --receipt "$D/builds/native-present-control-v1-receipt.json" --log "$D/builds/native-present-control-v1-build.log" --command-json "$D/builds/native-present-control-v1-command.json" --timeout 900
