"""Same frozen GPUI binary, ordinary Auto renderer policy, separate resource/startup profile."""
import datetime,fcntl,json,os,signal,subprocess,sys,time,traceback
from pathlib import Path
T=Path('/home/miles/gpui-ce3-compute-20261024');D=T/'evidence/five-app';sys.path.insert(0,str(T/'src/five-app/runner'));import run as r
out=D/'gpui-auto-profile-v1';out.mkdir(exist_ok=False);status={'pid':os.getpid(),'pgid':os.getpgrp(),'state':'starting','pooled_with_primary_gpu_profile':False}
def save():(out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def stop(s,f):raise KeyboardInterrupt(s)
for s in(signal.SIGINT,signal.SIGTERM,signal.SIGALRM):signal.signal(s,stop)
signal.alarm(300);save();os.environ.update(DISPLAY=':275',XDG_RUNTIME_DIR=str(T/'runtime/five-app'),TODO_X11_LIBRARY='/nix/store/rck9w8gj3r2w2z1xpw15g1fvpzi8iz9h-libx11-1.8.13/lib/libX11.so.6');x=None;original=r.core.Child
try:
 with (T/'host.lock').open('a+') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  if r.active_builds():raise RuntimeError('builds active')
  manifest=json.loads((D/'manifest.json').read_text());frozen=r.fingerprint(manifest);(out/'freeze.json').write_text(json.dumps(frozen,indent=2));app=manifest['apps']['gpui'];r.core.XDOTOOL=manifest['xdotool'];r.core.EXPECTED_WINDOW_TITLES['gpui']=app['title']
  def auto_child(binary,env,log):return original(binary,{**env,'TODO_BENCH_RENDERER':'auto'},log)
  r.core.Child=auto_child
  x=subprocess.Popen(['/nix/store/iw8dx6lhrkdc5wzszjzqzl677y68y88r-xvfb-21.1.24/bin/Xvfb',':275','-screen','0','1280x1024x24','-nolisten','tcp'],stdout=(out/'xvfb.log').open('wb'),stderr=subprocess.STDOUT,start_new_session=True);time.sleep(1)
  for mode in ('idle','startup'):
   for rep in (1,2,3):
    status.update(state='measuring',mode=mode,repeat=rep);save();row=r.run_cell('gpui',app,mode,rep,out,30,5);row['source_and_binary_unchanged']=r.fingerprint(manifest)==frozen;row['original_runner_accepted']=r.accepted(row);row['profile']='ordinary-auto-renderer-policy-v1';row['actual_spawn_environment_override']={'TODO_BENCH_RENDERER':'auto'};row['pooled_with_primary_gpu_profile']=False;(out/'results.jsonl').open('a').write(json.dumps(row)+'\n');print(mode,rep,row['original_runner_accepted'],row.get('renderer_info'),flush=True)
  status['state']='complete'
except BaseException as e:status.update(state='failed',error=repr(e),traceback=traceback.format_exc())
finally:
 r.core.close_active_children();r.core.Child=original
 if x and x.poll() is None:os.killpg(x.pid,signal.SIGTERM);x.wait(timeout=10)
 status['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
