# Five native Todo applications

All values belong to the frozen adapters and rendering paths in manifest.json. Failed work remains raw overload evidence; it is excluded from passing medians. CPU includes software renderer workers and excludes Xvfb and the observer. 100% means one occupied logical core. Readback overhead is recorded per input action.

Startup is warm page cache, external spawn to the first host drawing/submission receipt. Internal boundaries differ by backend and are recorded. No cache drop or true cold-start claim is made.

| Application | Mode | Passing / captured | CPU % | Peak PSS KiB | Host interval p95 µs |
| --- | --- | ---: | ---: | ---: | ---: |
| gpui | idle | 3 / 3 | 0.03 | 131002.00 | unavailable |
| gpui | busy | 3 / 3 | 120.36 | 133803.00 | 300127.00 |
| gpui | heavy | 0 / 3 | unavailable | unavailable | unavailable |
| gpui | animation | 0 / 3 | unavailable | unavailable | unavailable |
| gpui | startup | 3 / 3 | unavailable | unavailable | unavailable |
| zeronsh-zgui | idle | 3 / 3 | 0.00 | 104866.00 | unavailable |
| zeronsh-zgui | busy | 3 / 3 | 6.27 | 112146.00 | 222923.00 |
| zeronsh-zgui | heavy | 0 / 3 | unavailable | unavailable | unavailable |
| zeronsh-zgui | animation | 3 / 3 | 82.67 | 136924.00 | 18199.00 |
| zeronsh-zgui | startup | 3 / 3 | unavailable | unavailable | unavailable |
| zortax-zgui | idle | 3 / 3 | 0.00 | 184836.00 | unavailable |
| zortax-zgui | busy | 3 / 3 | 23.73 | 192877.00 | 220296.00 |
| zortax-zgui | heavy | 0 / 3 | unavailable | unavailable | unavailable |
| zortax-zgui | animation | 0 / 3 | unavailable | unavailable | unavailable |
| zortax-zgui | startup | 3 / 3 | unavailable | unavailable | unavailable |
| nanoui | idle | 3 / 3 | 0.00 | 148404.00 | unavailable |
| nanoui | busy | 3 / 3 | 61.23 | 148613.00 | 211899.00 |
| nanoui | heavy | 0 / 3 | unavailable | unavailable | unavailable |
| nanoui | animation | 0 / 3 | unavailable | unavailable | unavailable |
| nanoui | startup | 3 / 3 | unavailable | unavailable | unavailable |
| mygo | idle | 3 / 3 | 0.00 | 166511.00 | unavailable |
| mygo | busy | 3 / 3 | 14.67 | 171643.00 | 220487.00 |
| mygo | heavy | 0 / 3 | unavailable | unavailable | unavailable |
| mygo | animation | 0 / 3 | unavailable | unavailable | unavailable |
| mygo | startup | 3 / 3 | unavailable | unavailable | unavailable |

Hardware GPU utilization and physical display smoothness are unsupported unless separately demonstrated by hardware identity, an appropriate hardware counter and a real display. Software GL/Vulkan activity is not hardware GPU utilization.

Failure and unsupported reasons:

- gpui/heavy/r1: failed contract: interactive_work_matched; drawable acknowledged=False.
- zeronsh-zgui/heavy/r1: failed contract: interactive_work_matched; drawable acknowledged=False.
- zortax-zgui/heavy/r1: failed contract: interactive_work_matched; drawable acknowledged=False.
- nanoui/heavy/r1: failed contract: required evidence missing; drawable acknowledged=False.
- mygo/heavy/r1: failed contract: required evidence missing; drawable acknowledged=False.
- gpui/heavy/r2: failed contract: interactive_work_matched; drawable acknowledged=False.
- mygo/heavy/r2: failed contract: required evidence missing; drawable acknowledged=False.
- nanoui/heavy/r2: failed contract: required evidence missing; drawable acknowledged=False.
- zortax-zgui/heavy/r2: failed contract: interactive_work_matched; drawable acknowledged=False.
- zeronsh-zgui/heavy/r2: failed contract: interactive_work_matched; drawable acknowledged=False.
- zortax-zgui/heavy/r3: failed contract: interactive_work_matched; drawable acknowledged=False.
- nanoui/heavy/r3: failed contract: required evidence missing; drawable acknowledged=False.
- mygo/heavy/r3: failed contract: required evidence missing; drawable acknowledged=False.
- gpui/heavy/r3: failed contract: interactive_work_matched; drawable acknowledged=False.
- zeronsh-zgui/heavy/r3: failed contract: interactive_work_matched; drawable acknowledged=False.
- gpui/animation/r1: failed contract: animation_work_matched; drawable acknowledged=True.
- zortax-zgui/animation/r1: failed contract: animation_work_matched; drawable acknowledged=True.
- nanoui/animation/r1: failed contract: animation_work_matched; drawable acknowledged=True.
- mygo/animation/r1: failed contract: animation_work_matched; drawable acknowledged=True.
- gpui/animation/r2: failed contract: animation_work_matched; drawable acknowledged=True.
- mygo/animation/r2: failed contract: animation_work_matched; drawable acknowledged=True.
- nanoui/animation/r2: failed contract: animation_work_matched; drawable acknowledged=True.
- zortax-zgui/animation/r2: failed contract: animation_work_matched; drawable acknowledged=True.
- zortax-zgui/animation/r3: failed contract: animation_work_matched; drawable acknowledged=True.
- nanoui/animation/r3: failed contract: animation_work_matched; drawable acknowledged=True.
- mygo/animation/r3: failed contract: animation_work_matched; drawable acknowledged=True.
- gpui/animation/r3: failed contract: animation_work_matched; drawable acknowledged=True.
