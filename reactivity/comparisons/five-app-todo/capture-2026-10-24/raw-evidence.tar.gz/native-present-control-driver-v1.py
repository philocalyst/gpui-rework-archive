"""Actual native backend starvation, never an observer-only filter."""
import datetime,fcntl,json,os,signal,subprocess,sys,time,traceback
from pathlib import Path
T=Path('/home/miles/gpui-ce3-compute-20261024');D=T/'evidence/five-app';sys.path.insert(0,str(T/'src/five-app/runner'));import run as r
sys.path.insert(0,str(D));import presentation_audit
out=D/'native-present-control-v1';out.mkdir(exist_ok=False);status={'pid':os.getpid(),'pgid':os.getpgrp(),'state':'starting','performance_eligible':False}
def save():(out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def stop(s,f):raise KeyboardInterrupt(s)
for s in(signal.SIGINT,signal.SIGTERM,signal.SIGALRM):signal.signal(s,stop)
signal.alarm(180);save();os.environ.update(DISPLAY=':274',XDG_RUNTIME_DIR=str(T/'runtime/five-app'),TODO_X11_LIBRARY='/nix/store/rck9w8gj3r2w2z1xpw15g1fvpzi8iz9h-libx11-1.8.13/lib/libX11.so.6');x=None
try:
 with (T/'host.lock').open('a+') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  if r.active_builds():raise RuntimeError('builds active')
  manifest=json.loads((D/'manifest.json').read_text());r.core.XDOTOOL=manifest['xdotool'];app=manifest['apps']['zeronsh-zgui'];app={**app,'binary':str(T/'targets/five-app/native-present-control/dist/examples/benchmark_todo'),'source':str(T/'src/five-app/zeronsh-native-present-control-v1')};r.core.EXPECTED_WINDOW_TITLES['zeronsh-zgui']=app['title']
  frozen={'primary':r.fingerprint(manifest),'control':r.fingerprint({'apps':{'control':app}})};(out/'freeze.json').write_text(json.dumps(frozen,indent=2))
  x=subprocess.Popen(['/nix/store/iw8dx6lhrkdc5wzszjzqzl677y68y88r-xvfb-21.1.24/bin/Xvfb',':274','-screen','0','1280x1024x24','-nolisten','tcp'],stdout=(out/'xvfb.log').open('wb'),stderr=subprocess.STDOUT,start_new_session=True);time.sleep(1)
  cases=[]
  for name,fault in [('positive',{}),('actual-native-starvation',{'TODO_TEST_NATIVE_PRESENT_INTERVAL_MS':'200'})]:
   case=out/name;case.mkdir();a={**app,'environment':{**app['environment'],**fault}}
   row=r.run_cell('zeronsh-zgui',a,'animation',1,case,6,2);row['source_and_binary_unchanged']=r.fingerprint(manifest)==frozen['primary'] and r.fingerprint({'apps':{'control':app}})==frozen['control'];row['original_runner_accepted']=r.accepted(row);row['independent_host_audit']=presentation_audit.audit_animation(row);row['performance_eligible']=False;row['fault_environment']=fault
   controls=[json.loads(line.split(',',1)[1]) for line in Path(row['log_path']).read_text().splitlines() if line.startswith('TODO_NATIVE_PRESENT_CONTROL,')];row['native_control_receipt']=controls
   good=(row['original_runner_accepted'] and row['independent_host_audit']['eligible']) if name=='positive' else (row['original_runner_accepted'] and not row['independent_host_audit']['eligible'] and len(controls)==1 and controls[0]['deferred_native_draws']>100 and controls[0]['interval_ms']==200 and row['present_frame_count']<60)
   row['control_passed']=good;(case/'result.json').write_text(json.dumps(row,indent=2)+'\n');cases.append({'case':name,'passed':good,'original_runner_accepted':row['original_runner_accepted'],'host_audit_eligible':row['independent_host_audit']['eligible'],'host_receipts':row['present_frame_count'],'ticks':row.get('animation_ticks'),'native_control':controls});print(json.dumps(cases[-1]),flush=True)
  status.update(state='complete',controls=cases,all_controls_passed=all(v['passed'] for v in cases))
except BaseException as e:status.update(state='failed',error=repr(e),traceback=traceback.format_exc())
finally:
 r.core.close_active_children()
 if x and x.poll() is None:os.killpg(x.pid,signal.SIGTERM);x.wait(timeout=10)
 status['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
