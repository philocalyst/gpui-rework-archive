import json,os,sys,time,subprocess,traceback
from pathlib import Path
T=Path('/home/miles/gpui-ce3-compute-20261024');sys.path.insert(0,str(T/'src/five-app/runner'));import run as runner
out=T/'evidence/five-app/fault-controls-attempt2';out.mkdir(parents=True,exist_ok=True)
mesa='/nix/store/dv3gad7cjnnnzbfsv7jslvj9fmn5420j-mesa-26.1.4'
roots=['/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57','/nix/store/c4q6wnp14xf0npalyiqsfp1c99y4qhcx-cairo-1.18.4','/nix/store/1fl4qsghsryd5f764m5v64vlxdz9d8qx-gtk+3-3.24.52',mesa,'/nix/store/8pr51y4c1a72yr4fd7g561g1vk5m5k1p-dbus-1.16.2-lib']
paths=roots+subprocess.check_output(['nix-store','-qR',*roots],text=True).splitlines();dirs=list(dict.fromkeys(str(Path(p)/'lib') for p in paths if (Path(p)/'lib').is_dir()))
env={'LD_LIBRARY_PATH':':'.join(dirs),'GDK_BACKEND':'x11','MYGO_GPU':'1','NANOUI_GTK':'3','LIBGL_ALWAYS_SOFTWARE':'1','GALLIUM_DRIVER':'llvmpipe','LIBGL_DRIVERS_PATH':mesa+'/lib/dri','__EGL_VENDOR_LIBRARY_FILENAMES':mesa+'/share/glvnd/egl_vendor.d/50_mesa.json','VK_DRIVER_FILES':mesa+'/share/vulkan/icd.d/lvp_icd.x86_64.json','LP_NUM_THREADS':'4','GDK_GL':'always','LIBGL_DEBUG':'verbose','GDK_SCALE':'1','GDK_DPI_SCALE':'1'}
os.environ['TODO_X11_LIBRARY']='/nix/store/rck9w8gj3r2w2z1xpw15g1fvpzi8iz9h-libx11-1.8.13/lib/libX11.so.6'
controls={'input':[164,95],'add':[340,95],'complete':[74,147],'active':[150,519],'done':[216,519],'all':[98,519],'delete':[392,147],'undo':[202,568]}
apps={'mygo':{'binary':str(T/'targets/five-app/bin/mygo'),'title':'MyGo Todo comparison'},'nanoui':{'binary':str(T/'targets/five-app/nanoui/bin/benchmark-todo'),'title':'NanoUI Todo comparison'}}
runner.core.EXPECTED_WINDOW_TITLES.update({n:a['title'] for n,a in apps.items()})
runner.core.wait_first_present_original=runner.core.wait_first_present
runner.core.wait_first_present=lambda child,timeout=90:runner.core.wait_first_present_original(child,10)
for case,mode,extra in [('positive','busy',{}),('duplicate-ticks','animation',{'TODO_TEST_DUPLICATE_TICKS':'1'}),('hover-only-suppressed-callback','busy',{'TODO_TEST_SUPPRESS_COMPLETE':'1','TODO_TEST_HOVER_ONLY':'1'}),('stale-marker','busy',{'TODO_TEST_STALE_MARKER':'1'}),('observer-overflow','busy',{'TODO_TEST_OBSERVER_CAP':'1'}),('term-handled-zero','idle',{'TODO_TEST_TERM_HANDLED_ZERO':'1'}),('missing-present','idle',{'TODO_TEST_SUPPRESS_PRESENT':'1'})]:
 n='mygo';a=apps[n].copy();a.update(environment={**env,**extra},controls=controls)
 caseout=out/case;caseout.mkdir(parents=True,exist_ok=True);before=runner.core.source_fingerprint(T/'src/five-app/mygo')
 print(case,flush=True)
 try:
  row=runner.run_cell(n,a,mode,1,caseout,2,0)
  after=runner.core.source_fingerprint(T/'src/five-app/mygo');row['source_and_binary_unchanged']=before==after
  row['accepted']=runner.accepted(row)
 except Exception as e:row={'variant':n,'mode':mode,'accepted':False,'error':repr(e),'traceback':traceback.format_exc()}
 row['purpose']='untimed negative controls while builds may run';row['performance_eligible']=False;row['fault_environment']=extra
 (caseout/'result.json').write_text(json.dumps(row,indent=2));print(json.dumps({k:row.get(k) for k in ['variant','mode','accepted','error','full_model_matched','ordered_callbacks_matched','drawable_work_acknowledged','graceful_close','close_escalated','present_observer_overflow']}),flush=True)
