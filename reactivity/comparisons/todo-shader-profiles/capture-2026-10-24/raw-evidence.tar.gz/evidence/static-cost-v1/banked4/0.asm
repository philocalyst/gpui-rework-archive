
/home/miles/gpui-ce3-compute-20261024/evidence/todo-shader-profiles/attempt2/builds/banked4/todo_comparison_mapped:     file format elf64-x86-64


Disassembly of section .text:

0000000000521380 <<gpui_gpu::renderer::RendererState>::render>:
  521380:	55                   	push   %rbp
  521381:	41 57                	push   %r15
  521383:	41 56                	push   %r14
  521385:	41 55                	push   %r13
  521387:	41 54                	push   %r12
  521389:	53                   	push   %rbx
  52138a:	48 81 ec b8 04 00 00 	sub    $0x4b8,%rsp
  521391:	48 8b 86 28 02 00 00 	mov    0x228(%rsi),%rax
  521398:	4c 8b 4a 18          	mov    0x18(%rdx),%r9
  52139c:	4c 39 c8             	cmp    %r9,%rax
  52139f:	74 1c                	je     5213bd <<gpui_gpu::renderer::RendererState>::render+0x3d>
  5213a1:	4c 8b 50 10          	mov    0x10(%rax),%r10
  5213a5:	4d 3b 51 10          	cmp    0x10(%r9),%r10
  5213a9:	0f 85 dc 00 00 00    	jne    52148b <<gpui_gpu::renderer::RendererState>::render+0x10b>
  5213af:	48 8b 40 18          	mov    0x18(%rax),%rax
  5213b3:	49 3b 41 18          	cmp    0x18(%r9),%rax
  5213b7:	0f 85 ce 00 00 00    	jne    52148b <<gpui_gpu::renderer::RendererState>::render+0x10b>
  5213bd:	48 8d 9e 30 03 00 00 	lea    0x330(%rsi),%rbx
  5213c4:	48 8b 86 30 03 00 00 	mov    0x330(%rsi),%rax
  5213cb:	48 85 c0             	test   %rax,%rax
  5213ce:	74 2d                	je     5213fd <<gpui_gpu::renderer::RendererState>::render+0x7d>
  5213d0:	f0 48 ff 08          	lock decq (%rax)
  5213d4:	75 27                	jne    5213fd <<gpui_gpu::renderer::RendererState>::render+0x7d>
  5213d6:	49 89 fe             	mov    %rdi,%r14
  5213d9:	48 89 df             	mov    %rbx,%rdi
  5213dc:	49 89 f4             	mov    %rsi,%r12
  5213df:	4d 89 c5             	mov    %r8,%r13
  5213e2:	49 89 d7             	mov    %rdx,%r15
  5213e5:	48 89 cd             	mov    %rcx,%rbp
  5213e8:	ff 15 e2 5e da 00    	call   *0xda5ee2(%rip)        # 12c72d0 <_GLOBAL_OFFSET_TABLE_+0x3490>
  5213ee:	48 89 e9             	mov    %rbp,%rcx
  5213f1:	4c 89 fa             	mov    %r15,%rdx
  5213f4:	4d 89 e8             	mov    %r13,%r8
  5213f7:	4c 89 e6             	mov    %r12,%rsi
  5213fa:	4c 89 f7             	mov    %r14,%rdi
  5213fd:	48 c7 86 30 03 00 00 	movq   $0x0,0x330(%rsi)
  521404:	00 00 00 00 
  521408:	44 8b 39             	mov    (%rcx),%r15d
  52140b:	44 8b 49 08          	mov    0x8(%rcx),%r9d
  52140f:	0f b6 41 0d          	movzbl 0xd(%rcx),%eax
  521413:	45 85 c9             	test   %r9d,%r9d
  521416:	41 0f 98 c2          	sets   %r10b
  52141a:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  521421:	45 8d 99 00 00 80 ff 	lea    -0x800000(%r9),%r11d
  521428:	41 81 fb 00 00 00 7f 	cmp    $0x7f000000,%r11d
  52142f:	41 0f 92 c3          	setb   %r11b
  521433:	45 20 d3             	and    %r10b,%r11b
  521436:	41 8d 69 ff          	lea    -0x1(%r9),%ebp
  52143a:	81 fd ff ff 7f 00    	cmp    $0x7fffff,%ebp
  521440:	40 0f 92 c5          	setb   %bpl
  521444:	44 20 d5             	and    %r10b,%bpl
  521447:	45 85 c9             	test   %r9d,%r9d
  52144a:	41 0f 94 c2          	sete   %r10b
  52144e:	41 81 f9 00 00 80 7f 	cmp    $0x7f800000,%r9d
  521455:	41 0f 94 c6          	sete   %r14b
  521459:	45 08 d6             	or     %r10b,%r14b
  52145c:	41 81 f9 01 00 80 7f 	cmp    $0x7f800001,%r9d
  521463:	41 0f 9d c1          	setge  %r9b
  521467:	45 08 f1             	or     %r14b,%r9b
  52146a:	41 08 e9             	or     %bpl,%r9b
  52146d:	45 85 ff             	test   %r15d,%r15d
  521470:	41 0f 95 c2          	setne  %r10b
  521474:	41 20 c2             	and    %al,%r10b
  521477:	45 08 da             	or     %r11b,%r10b
  52147a:	45 08 ca             	or     %r9b,%r10b
  52147d:	41 f6 c2 01          	test   $0x1,%r10b
  521481:	74 23                	je     5214a6 <<gpui_gpu::renderer::RendererState>::render+0x126>
  521483:	c7 07 03 00 00 00    	movl   $0x3,(%rdi)
  521489:	eb 06                	jmp    521491 <<gpui_gpu::renderer::RendererState>::render+0x111>
  52148b:	c7 07 04 00 00 00    	movl   $0x4,(%rdi)
  521491:	48 89 f8             	mov    %rdi,%rax
  521494:	48 81 c4 b8 04 00 00 	add    $0x4b8,%rsp
  52149b:	5b                   	pop    %rbx
  52149c:	41 5c                	pop    %r12
  52149e:	41 5d                	pop    %r13
  5214a0:	41 5e                	pop    %r14
  5214a2:	41 5f                	pop    %r15
  5214a4:	5d                   	pop    %rbp
  5214a5:	c3                   	ret
  5214a6:	66 0f 6e 51 04       	movd   0x4(%rcx),%xmm2
  5214ab:	44 0f b6 69 0c       	movzbl 0xc(%rcx),%r13d
  5214b0:	41 f6 c7 01          	test   $0x1,%r15b
  5214b4:	74 75                	je     52152b <<gpui_gpu::renderer::RendererState>::render+0x1ab>
  5214b6:	66 41 0f 7e d1       	movd   %xmm2,%r9d
  5214bb:	45 85 c9             	test   %r9d,%r9d
  5214be:	41 0f 98 c2          	sets   %r10b
  5214c2:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  5214c9:	45 8d 99 00 00 80 ff 	lea    -0x800000(%r9),%r11d
  5214d0:	41 81 fb 00 00 00 7f 	cmp    $0x7f000000,%r11d
  5214d7:	41 0f 92 c3          	setb   %r11b
  5214db:	45 20 d3             	and    %r10b,%r11b
  5214de:	41 8d 69 ff          	lea    -0x1(%r9),%ebp
  5214e2:	81 fd ff ff 7f 00    	cmp    $0x7fffff,%ebp
  5214e8:	40 0f 92 c5          	setb   %bpl
  5214ec:	44 20 d5             	and    %r10b,%bpl
  5214ef:	45 85 c9             	test   %r9d,%r9d
  5214f2:	41 0f 94 c2          	sete   %r10b
  5214f6:	41 81 f9 00 00 80 7f 	cmp    $0x7f800000,%r9d
  5214fd:	41 0f 94 c6          	sete   %r14b
  521501:	45 08 d6             	or     %r10b,%r14b
  521504:	41 81 f9 01 00 80 7f 	cmp    $0x7f800001,%r9d
  52150b:	41 0f 9d c1          	setge  %r9b
  52150f:	45 08 f1             	or     %r14b,%r9b
  521512:	41 08 e9             	or     %bpl,%r9b
  521515:	45 08 d9             	or     %r11b,%r9b
  521518:	0f 85 65 ff ff ff    	jne    521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  52151e:	0f 2e 15 37 42 60 00 	ucomiss 0x604237(%rip),%xmm2        # b2575c <anon.9adf6b51329d0e8f0ba7a07edbf8a285.69.llvm.2988996700849332186+0x8>
  521525:	0f 87 58 ff ff ff    	ja     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  52152b:	44 8b 71 28          	mov    0x28(%rcx),%r14d
  52152f:	45 3b 70 20          	cmp    0x20(%r8),%r14d
  521533:	0f 85 4a ff ff ff    	jne    521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  521539:	8b 69 2c             	mov    0x2c(%rcx),%ebp
  52153c:	41 3b 68 24          	cmp    0x24(%r8),%ebp
  521540:	0f 85 3d ff ff ff    	jne    521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  521546:	45 8b 60 38          	mov    0x38(%r8),%r12d
  52154a:	44 3b 62 20          	cmp    0x20(%rdx),%r12d
  52154e:	0f 85 2f ff ff ff    	jne    521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  521554:	41 83 fc 4c          	cmp    $0x4c,%r12d
  521558:	75 23                	jne    52157d <<gpui_gpu::renderer::RendererState>::render+0x1fd>
  52155a:	f3 41 0f 7e 40 3c    	movq   0x3c(%r8),%xmm0
  521560:	f3 0f 7e 4a 24       	movq   0x24(%rdx),%xmm1
  521565:	66 0f 76 c8          	pcmpeqd %xmm0,%xmm1
  521569:	66 0f 70 c1 50       	pshufd $0x50,%xmm1,%xmm0
  52156e:	66 44 0f 50 c8       	movmskpd %xmm0,%r9d
  521573:	41 83 f9 03          	cmp    $0x3,%r9d
  521577:	0f 85 06 ff ff ff    	jne    521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  52157d:	81 fd 00 40 00 00    	cmp    $0x4000,%ebp
  521583:	77 34                	ja     5215b9 <<gpui_gpu::renderer::RendererState>::render+0x239>
  521585:	41 81 fe 00 40 00 00 	cmp    $0x4000,%r14d
  52158c:	77 2b                	ja     5215b9 <<gpui_gpu::renderer::RendererState>::render+0x239>
  52158e:	41 89 ea             	mov    %ebp,%r10d
  521591:	4d 89 d1             	mov    %r10,%r9
  521594:	4d 0f af ce          	imul   %r14,%r9
  521598:	49 81 c1 ff ff ff fe 	add    $0xfffffffffeffffff,%r9
  52159f:	49 81 f9 00 00 00 ff 	cmp    $0xffffffffff000000,%r9
  5215a6:	72 11                	jb     5215b9 <<gpui_gpu::renderer::RendererState>::render+0x239>
  5215a8:	4c 8b 59 10          	mov    0x10(%rcx),%r11
  5215ac:	49 81 bb 80 00 00 00 	cmpq   $0x10000,0x80(%r11)
  5215b3:	00 00 01 00 
  5215b7:	76 0b                	jbe    5215c4 <<gpui_gpu::renderer::RendererState>::render+0x244>
  5215b9:	c7 07 06 00 00 00    	movl   $0x6,(%rdi)
  5215bf:	e9 cd fe ff ff       	jmp    521491 <<gpui_gpu::renderer::RendererState>::render+0x111>
  5215c4:	66 0f 6e 41 18       	movd   0x18(%rcx),%xmm0
  5215c9:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  5215ce:	45 01 c9             	add    %r9d,%r9d
  5215d1:	41 81 f9 ff ff ff fe 	cmp    $0xfeffffff,%r9d
  5215d8:	0f 87 a5 fe ff ff    	ja     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  5215de:	66 0f db 05 7a d3 5f 	pand   0x5fd37a(%rip),%xmm0        # b1e960 <anon.53de480418173883b8e15d81740454e2.346.llvm.622318203107919755+0x488>
  5215e5:	00 
  5215e6:	0f 2e 05 73 41 60 00 	ucomiss 0x604173(%rip),%xmm0        # b25760 <anon.9adf6b51329d0e8f0ba7a07edbf8a285.69.llvm.2988996700849332186+0xc>
  5215ed:	0f 87 90 fe ff ff    	ja     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  5215f3:	66 0f 6e 41 1c       	movd   0x1c(%rcx),%xmm0
  5215f8:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  5215fd:	45 01 c9             	add    %r9d,%r9d
  521600:	41 81 f9 ff ff ff fe 	cmp    $0xfeffffff,%r9d
  521607:	0f 87 76 fe ff ff    	ja     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  52160d:	66 0f db 05 4b d3 5f 	pand   0x5fd34b(%rip),%xmm0        # b1e960 <anon.53de480418173883b8e15d81740454e2.346.llvm.622318203107919755+0x488>
  521614:	00 
  521615:	0f 2e 05 44 41 60 00 	ucomiss 0x604144(%rip),%xmm0        # b25760 <anon.9adf6b51329d0e8f0ba7a07edbf8a285.69.llvm.2988996700849332186+0xc>
  52161c:	0f 87 61 fe ff ff    	ja     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  521622:	66 0f 6e 41 20       	movd   0x20(%rcx),%xmm0
  521627:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  52162c:	45 01 c9             	add    %r9d,%r9d
  52162f:	41 81 f9 ff ff ff fe 	cmp    $0xfeffffff,%r9d
  521636:	0f 87 47 fe ff ff    	ja     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  52163c:	66 0f db 05 1c d3 5f 	pand   0x5fd31c(%rip),%xmm0        # b1e960 <anon.53de480418173883b8e15d81740454e2.346.llvm.622318203107919755+0x488>
  521643:	00 
  521644:	0f 2e 05 15 41 60 00 	ucomiss 0x604115(%rip),%xmm0        # b25760 <anon.9adf6b51329d0e8f0ba7a07edbf8a285.69.llvm.2988996700849332186+0xc>
  52164b:	0f 87 32 fe ff ff    	ja     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  521651:	66 0f 6e 41 24       	movd   0x24(%rcx),%xmm0
  521656:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  52165b:	45 01 c9             	add    %r9d,%r9d
  52165e:	41 81 f9 ff ff ff fe 	cmp    $0xfeffffff,%r9d
  521665:	0f 87 18 fe ff ff    	ja     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  52166b:	66 0f 6f 0d ed d2 5f 	movdqa 0x5fd2ed(%rip),%xmm1        # b1e960 <anon.53de480418173883b8e15d81740454e2.346.llvm.622318203107919755+0x488>
  521672:	00 
  521673:	66 0f db c8          	pand   %xmm0,%xmm1
  521677:	0f 2e 0d e2 40 60 00 	ucomiss 0x6040e2(%rip),%xmm1        # b25760 <anon.9adf6b51329d0e8f0ba7a07edbf8a285.69.llvm.2988996700849332186+0xc>
  52167e:	0f 87 ff fd ff ff    	ja     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  521684:	0f 57 c9             	xorps  %xmm1,%xmm1
  521687:	0f 2e c1             	ucomiss %xmm1,%xmm0
  52168a:	0f 82 f3 fd ff ff    	jb     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  521690:	f3 0f 10 0d 04 40 60 	movss  0x604004(%rip),%xmm1        # b2569c <anon.65fa6619250d5a71bfd5ef20e1dfbaf0.11.llvm.7726090819372637783+0x8>
  521697:	00 
  521698:	0f 2e c8             	ucomiss %xmm0,%xmm1
  52169b:	0f 82 e2 fd ff ff    	jb     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  5216a1:	44 8b 49 30          	mov    0x30(%rcx),%r9d
  5216a5:	41 83 fc 28          	cmp    $0x28,%r12d
  5216a9:	75 0a                	jne    5216b5 <<gpui_gpu::renderer::RendererState>::render+0x335>
  5216ab:	a8 01                	test   $0x1,%al
  5216ad:	0f 84 d0 fd ff ff    	je     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  5216b3:	eb 1b                	jmp    5216d0 <<gpui_gpu::renderer::RendererState>::render+0x350>
  5216b5:	a8 01                	test   $0x1,%al
  5216b7:	0f 85 c6 fd ff ff    	jne    521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  5216bd:	0f 2e 05 d8 3f 60 00 	ucomiss 0x603fd8(%rip),%xmm0        # b2569c <anon.65fa6619250d5a71bfd5ef20e1dfbaf0.11.llvm.7726090819372637783+0x8>
  5216c4:	0f 85 b9 fd ff ff    	jne    521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  5216ca:	0f 8a b3 fd ff ff    	jp     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  5216d0:	44 89 4c 24 28       	mov    %r9d,0x28(%rsp)
  5216d5:	4c 89 9c 24 b8 00 00 	mov    %r11,0xb8(%rsp)
  5216dc:	00 
  5216dd:	f3 0f 11 8c 24 14 01 	movss  %xmm1,0x114(%rsp)
  5216e4:	00 00 
  5216e6:	66 0f 7e 94 24 4c 03 	movd   %xmm2,0x34c(%rsp)
  5216ed:	00 00 
  5216ef:	4c 89 94 24 08 01 00 	mov    %r10,0x108(%rsp)
  5216f6:	00 
  5216f7:	48 89 94 24 98 01 00 	mov    %rdx,0x198(%rsp)
  5216fe:	00 
  5216ff:	4c 89 84 24 e8 03 00 	mov    %r8,0x3e8(%rsp)
  521706:	00 
  521707:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
  52170c:	49 8d 46 0f          	lea    0xf(%r14),%rax
  521710:	48 c1 e8 04          	shr    $0x4,%rax
  521714:	8d 55 0f             	lea    0xf(%rbp),%edx
  521717:	c1 ea 04             	shr    $0x4,%edx
  52171a:	48 8d 7e 18          	lea    0x18(%rsi),%rdi
  52171e:	48 c7 46 28 00 00 00 	movq   $0x0,0x28(%rsi)
  521725:	00 
  521726:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  52172b:	0f af d0             	imul   %eax,%edx
  52172e:	48 89 bc 24 b0 00 00 	mov    %rdi,0xb0(%rsp)
  521735:	00 
  521736:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  52173b:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
  521740:	48 89 d6             	mov    %rdx,%rsi
  521743:	31 d2                	xor    %edx,%edx
  521745:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
  52174c:	00 
  52174d:	e8 ae 46 00 00       	call   525e00 <<alloc::vec::Vec<[u32; 2]>>::resize>
  521752:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  521757:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
  52175e:	00 
  52175f:	48 8b bc 24 a8 00 00 	mov    0xa8(%rsp),%rdi
  521766:	00 
  521767:	ff 15 43 43 da 00    	call   *0xda4343(%rip)        # 12c5ab0 <_GLOBAL_OFFSET_TABLE_+0x1c70>
  52176d:	48 89 d1             	mov    %rdx,%rcx
  521770:	48 29 c1             	sub    %rax,%rcx
  521773:	48 81 f9 00 00 30 00 	cmp    $0x300000,%rcx
  52177a:	76 10                	jbe    52178c <<gpui_gpu::renderer::RendererState>::render+0x40c>
  52177c:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  521781:	c7 07 06 00 00 00    	movl   $0x6,(%rdi)
  521787:	e9 05 fd ff ff       	jmp    521491 <<gpui_gpu::renderer::RendererState>::render+0x111>
  52178c:	48 89 ce             	mov    %rcx,%rsi
  52178f:	48 c1 e9 03          	shr    $0x3,%rcx
  521793:	48 bf ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rdi
  52179a:	aa aa aa 
  52179d:	48 0f af f9          	imul   %rcx,%rdi
  5217a1:	48 89 bc 24 90 00 00 	mov    %rdi,0x90(%rsp)
  5217a8:	00 
  5217a9:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
  5217b0:	00 
  5217b1:	48 89 94 24 70 03 00 	mov    %rdx,0x370(%rsp)
  5217b8:	00 
  5217b9:	48 39 c2             	cmp    %rax,%rdx
  5217bc:	74 32                	je     5217f0 <<gpui_gpu::renderer::RendererState>::render+0x470>
  5217be:	b8 ab aa aa aa       	mov    $0xaaaaaaab,%eax
  5217c3:	48 0f af f0          	imul   %rax,%rsi
  5217c7:	48 c1 ee 2a          	shr    $0x2a,%rsi
  5217cb:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  5217d2:	00 
  5217d3:	89 c8                	mov    %ecx,%eax
  5217d5:	83 e0 3f             	and    $0x3f,%eax
  5217d8:	48 01 ce             	add    %rcx,%rsi
  5217db:	48 83 f8 01          	cmp    $0x1,%rax
  5217df:	48 83 de ff          	sbb    $0xffffffffffffffff,%rsi
  5217e3:	48 ff c6             	inc    %rsi
  5217e6:	48 89 b4 24 d8 00 00 	mov    %rsi,0xd8(%rsp)
  5217ed:	00 
  5217ee:	eb 0c                	jmp    5217fc <<gpui_gpu::renderer::RendererState>::render+0x47c>
  5217f0:	48 c7 84 24 d8 00 00 	movq   $0x0,0xd8(%rsp)
  5217f7:	00 00 00 00 00 
  5217fc:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
  521803:	00 
  521804:	48 8b 82 80 00 00 00 	mov    0x80(%rdx),%rax
  52180b:	48 8b 8a 98 00 00 00 	mov    0x98(%rdx),%rcx
  521812:	48 03 8a b0 00 00 00 	add    0xb0(%rdx),%rcx
  521819:	48 89 94 24 c0 01 00 	mov    %rdx,0x1c0(%rsp)
  521820:	00 
  521821:	8b 54 24 28          	mov    0x28(%rsp),%edx
  521825:	89 94 24 e0 01 00 00 	mov    %edx,0x1e0(%rsp)
  52182c:	48 c7 84 24 c8 01 00 	movq   $0x0,0x1c8(%rsp)
  521833:	00 00 00 00 00 
  521838:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
  52183f:	00 
  521840:	48 89 8c 24 d8 01 00 	mov    %rcx,0x1d8(%rsp)
  521847:	00 
  521848:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  52184d:	0f b6 90 41 03 00 00 	movzbl 0x341(%rax),%edx
  521854:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  52185b:	00 
  52185c:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
  521863:	00 
  521864:	e8 77 de ff ff       	call   51f6e0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>
  521869:	8b 84 24 18 01 00 00 	mov    0x118(%rsp),%eax
  521870:	83 f8 ff             	cmp    $0xffffffff,%eax
  521873:	74 2e                	je     5218a3 <<gpui_gpu::renderer::RendererState>::render+0x523>
  521875:	8b 8c 24 1c 01 00 00 	mov    0x11c(%rsp),%ecx
  52187c:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
  521883:	00 
  521884:	0f 10 84 24 28 01 00 	movups 0x128(%rsp),%xmm0
  52188b:	00 
  52188c:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  521891:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
  521895:	89 07                	mov    %eax,(%rdi)
  521897:	89 4f 04             	mov    %ecx,0x4(%rdi)
  52189a:	48 89 57 08          	mov    %rdx,0x8(%rdi)
  52189e:	e9 ee fb ff ff       	jmp    521491 <<gpui_gpu::renderer::RendererState>::render+0x111>
  5218a3:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
  5218aa:	00 
  5218ab:	48 03 94 24 d8 00 00 	add    0xd8(%rsp),%rdx
  5218b2:	00 
  5218b3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  5218b8:	48 8b 77 10          	mov    0x10(%rdi),%rsi
  5218bc:	b9 04 00 00 00       	mov    $0x4,%ecx
  5218c1:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  5218c7:	e8 a4 6d 00 00       	call   528670 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  5218cc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  5218d0:	0f 85 a6 fe ff ff    	jne    52177c <<gpui_gpu::renderer::RendererState>::render+0x3fc>
  5218d6:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  5218db:	48 8b b4 24 a8 00 00 	mov    0xa8(%rsp),%rsi
  5218e2:	00 
  5218e3:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
  5218ea:	00 
  5218eb:	e8 50 6e 00 00       	call   528740 <gpui_gpu::renderer::slots::write_prefix>
  5218f0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  5218f5:	48 8d 78 48          	lea    0x48(%rax),%rdi
  5218f9:	48 c7 40 58 00 00 00 	movq   $0x0,0x58(%rax)
  521900:	00 
  521901:	48 89 bc 24 f0 03 00 	mov    %rdi,0x3f0(%rsp)
  521908:	00 
  521909:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  52190e:	31 d2                	xor    %edx,%edx
  521910:	e8 0b 46 00 00       	call   525f20 <<alloc::vec::Vec<u32>>::resize>
  521915:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  52191a:	48 c7 40 70 00 00 00 	movq   $0x0,0x70(%rax)
  521921:	00 
  521922:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
  521927:	75 0f                	jne    521938 <<gpui_gpu::renderer::RendererState>::render+0x5b8>
  521929:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  52192e:	48 8d 78 60          	lea    0x60(%rax),%rdi
  521932:	ff 15 58 82 da 00    	call   *0xda8258(%rip)        # 12c9b90 <_GLOBAL_OFFSET_TABLE_+0x5d50>
  521938:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  52193d:	48 8b 48 68          	mov    0x68(%rax),%rcx
  521941:	0f 57 c0             	xorps  %xmm0,%xmm0
  521944:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
  521948:	0f 11 01             	movups %xmm0,(%rcx)
  52194b:	48 c7 40 70 01 00 00 	movq   $0x1,0x70(%rax)
  521952:	00 
  521953:	48 8d b8 f8 02 00 00 	lea    0x2f8(%rax),%rdi
  52195a:	e8 f1 3e 00 00       	call   525850 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  52195f:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
  521966:	00 
  521967:	48 8b 82 80 00 00 00 	mov    0x80(%rdx),%rax
  52196e:	48 8b 8a 98 00 00 00 	mov    0x98(%rdx),%rcx
  521975:	48 03 8a b0 00 00 00 	add    0xb0(%rdx),%rcx
  52197c:	48 89 94 24 d0 02 00 	mov    %rdx,0x2d0(%rsp)
  521983:	00 
  521984:	48 c7 84 24 d8 02 00 	movq   $0x0,0x2d8(%rsp)
  52198b:	00 00 00 00 00 
  521990:	48 89 84 24 e0 02 00 	mov    %rax,0x2e0(%rsp)
  521997:	00 
  521998:	48 89 8c 24 e8 02 00 	mov    %rcx,0x2e8(%rsp)
  52199f:	00 
  5219a0:	8b 44 24 28          	mov    0x28(%rsp),%eax
  5219a4:	89 84 24 f0 02 00 00 	mov    %eax,0x2f0(%rsp)
  5219ab:	48 c1 a4 24 08 01 00 	shlq   $0x20,0x108(%rsp)
  5219b2:	00 20 
  5219b4:	48 8d bc 24 f8 03 00 	lea    0x3f8(%rsp),%rdi
  5219bb:	00 
  5219bc:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
  5219c3:	00 
  5219c4:	ff 15 a6 5f da 00    	call   *0xda5fa6(%rip)        # 12c7970 <_GLOBAL_OFFSET_TABLE_+0x3b30>
  5219ca:	48 8b 84 24 f8 03 00 	mov    0x3f8(%rsp),%rax
  5219d1:	00 
  5219d2:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  5219d7:	48 85 c0             	test   %rax,%rax
  5219da:	0f 84 65 0f 00 00    	je     522945 <<gpui_gpu::renderer::RendererState>::render+0x15c5>
  5219e0:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
  5219e7:	00 
  5219e8:	4c 01 f0             	add    %r14,%rax
  5219eb:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
  5219f2:	00 
  5219f3:	48 c7 44 24 60 00 00 	movq   $0x0,0x60(%rsp)
  5219fa:	00 00 
  5219fc:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
  521a03:	00 00 00 00 00 
  521a08:	48 c7 84 24 30 03 00 	movq   $0x0,0x330(%rsp)
  521a0f:	00 00 00 00 00 
  521a14:	48 c7 84 24 38 03 00 	movq   $0x0,0x338(%rsp)
  521a1b:	00 00 00 00 00 
  521a20:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
  521a27:	00 00 00 00 00 
  521a2c:	48 8b 94 24 00 04 00 	mov    0x400(%rsp),%rdx
  521a33:	00 
  521a34:	4c 8b 84 24 08 04 00 	mov    0x408(%rsp),%r8
  521a3b:	00 
  521a3c:	48 8b bc 24 10 04 00 	mov    0x410(%rsp),%rdi
  521a43:	00 
  521a44:	0f 10 94 24 18 04 00 	movups 0x418(%rsp),%xmm2
  521a4b:	00 
  521a4c:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
  521a51:	48 8d 8c 24 28 04 00 	lea    0x428(%rsp),%rcx
  521a58:	00 
  521a59:	48 8b 41 20          	mov    0x20(%rcx),%rax
  521a5d:	48 89 84 24 a0 03 00 	mov    %rax,0x3a0(%rsp)
  521a64:	00 
  521a65:	0f 10 01             	movups (%rcx),%xmm0
  521a68:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
  521a6c:	0f 29 8c 24 90 03 00 	movaps %xmm1,0x390(%rsp)
  521a73:	00 
  521a74:	0f 29 84 24 80 03 00 	movaps %xmm0,0x380(%rsp)
  521a7b:	00 
  521a7c:	0f 10 41 28          	movups 0x28(%rcx),%xmm0
  521a80:	0f 29 84 24 50 03 00 	movaps %xmm0,0x350(%rsp)
  521a87:	00 
  521a88:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  521a8d:	0f b6 b0 41 03 00 00 	movzbl 0x341(%rax),%esi
  521a94:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  521a99:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
  521aa0:	00 
  521aa1:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
  521aa6:	48 89 94 24 c8 01 00 	mov    %rdx,0x1c8(%rsp)
  521aad:	00 
  521aae:	4c 89 84 24 c0 00 00 	mov    %r8,0xc0(%rsp)
  521ab5:	00 
  521ab6:	4c 89 84 24 d0 01 00 	mov    %r8,0x1d0(%rsp)
  521abd:	00 
  521abe:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
  521ac3:	48 89 bc 24 d8 01 00 	mov    %rdi,0x1d8(%rsp)
  521aca:	00 
  521acb:	0f 11 94 24 e0 01 00 	movups %xmm2,0x1e0(%rsp)
  521ad2:	00 
  521ad3:	48 8b 41 20          	mov    0x20(%rcx),%rax
  521ad7:	48 8d 94 24 f0 01 00 	lea    0x1f0(%rsp),%rdx
  521ade:	00 
  521adf:	48 89 42 20          	mov    %rax,0x20(%rdx)
  521ae3:	0f 10 01             	movups (%rcx),%xmm0
  521ae6:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
  521aea:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  521aee:	0f 11 02             	movups %xmm0,(%rdx)
  521af1:	66 0f 10 41 28       	movupd 0x28(%rcx),%xmm0
  521af6:	48 8d 84 24 18 02 00 	lea    0x218(%rsp),%rax
  521afd:	00 
  521afe:	66 0f 11 00          	movupd %xmm0,(%rax)
  521b02:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
  521b09:	00 
  521b0a:	e8 c1 32 00 00       	call   524dd0 <gpui_gpu::renderer::compact_group>
  521b0f:	88 84 24 e0 00 00 00 	mov    %al,0xe0(%rsp)
  521b16:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
  521b1a:	66 0f 28 4c 24 40    	movapd 0x40(%rsp),%xmm1
  521b20:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
  521b24:	0f 85 a5 00 00 00    	jne    521bcf <<gpui_gpu::renderer::RendererState>::render+0x84f>
  521b2a:	0f 8a 9f 00 00 00    	jp     521bcf <<gpui_gpu::renderer::RendererState>::render+0x84f>
  521b30:	66 0f 28 44 24 40    	movapd 0x40(%rsp),%xmm0
  521b36:	66 0f 15 c0          	unpckhpd %xmm0,%xmm0
  521b3a:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
  521b3e:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
  521b42:	0f 85 87 00 00 00    	jne    521bcf <<gpui_gpu::renderer::RendererState>::render+0x84f>
  521b48:	0f 8a 81 00 00 00    	jp     521bcf <<gpui_gpu::renderer::RendererState>::render+0x84f>
  521b4e:	b0 01                	mov    $0x1,%al
  521b50:	89 84 24 00 01 00 00 	mov    %eax,0x100(%rsp)
  521b57:	c7 84 24 8c 00 00 00 	movl   $0x40000000,0x8c(%rsp)
  521b5e:	00 00 00 40 
  521b62:	48 83 bc 24 c0 00 00 	cmpq   $0x0,0xc0(%rsp)
  521b69:	00 00 
  521b6b:	0f 84 c5 00 00 00    	je     521c36 <<gpui_gpu::renderer::RendererState>::render+0x8b6>
  521b71:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  521b78:	00 
  521b79:	48 8d 04 85 00 00 00 	lea    0x0(,%rax,4),%rax
  521b80:	00 
  521b81:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  521b86:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  521b8d:	00 00 
  521b8f:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  521b94:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  521b99:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  521b9c:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
  521ba3:	00 
  521ba4:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  521ba9:	e8 82 dc ff ff       	call   51f830 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  521bae:	80 bc 24 c0 01 00 00 	cmpb   $0x0,0x1c0(%rsp)
  521bb5:	00 
  521bb6:	75 17                	jne    521bcf <<gpui_gpu::renderer::RendererState>::render+0x84f>
  521bb8:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  521bbd:	48 83 c1 04          	add    $0x4,%rcx
  521bc1:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  521bc6:	48 39 4c 24 70       	cmp    %rcx,0x70(%rsp)
  521bcb:	75 c2                	jne    521b8f <<gpui_gpu::renderer::RendererState>::render+0x80f>
  521bcd:	eb 67                	jmp    521c36 <<gpui_gpu::renderer::RendererState>::render+0x8b6>
  521bcf:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  521bd4:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
  521bdb:	00 
  521bdc:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
  521be1:	0f 11 84 24 c8 01 00 	movups %xmm0,0x1c8(%rsp)
  521be8:	00 
  521be9:	48 8d 94 24 28 04 00 	lea    0x428(%rsp),%rdx
  521bf0:	00 
  521bf1:	48 8b 42 10          	mov    0x10(%rdx),%rax
  521bf5:	48 8d 8c 24 18 02 00 	lea    0x218(%rsp),%rcx
  521bfc:	00 
  521bfd:	48 89 41 d0          	mov    %rax,-0x30(%rcx)
  521c01:	66 0f 10 02          	movupd (%rdx),%xmm0
  521c05:	66 0f 11 41 c0       	movupd %xmm0,-0x40(%rcx)
  521c0a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  521c0f:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
  521c16:	00 
  521c17:	48 8d 94 24 40 04 00 	lea    0x440(%rsp),%rdx
  521c1e:	00 
  521c1f:	e8 6c e9 ff ff       	call   520590 <<gpui_gpu::renderer::RendererState>::correction>
  521c24:	89 84 24 8c 00 00 00 	mov    %eax,0x8c(%rsp)
  521c2b:	c7 84 24 00 01 00 00 	movl   $0x0,0x100(%rsp)
  521c32:	00 00 00 00 
  521c36:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  521c3d:	00 
  521c3e:	48 8d 04 85 00 00 00 	lea    0x0(,%rax,4),%rax
  521c45:	00 
  521c46:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
  521c4d:	00 
  521c4e:	80 bc 24 e0 00 00 00 	cmpb   $0x0,0xe0(%rsp)
  521c55:	00 
  521c56:	0f 84 ae 01 00 00    	je     521e0a <<gpui_gpu::renderer::RendererState>::render+0xa8a>
  521c5c:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  521c61:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  521c68:	00 
  521c69:	48 8d 04 81          	lea    (%rcx,%rax,4),%rax
  521c6d:	48 89 8c 24 a0 01 00 	mov    %rcx,0x1a0(%rsp)
  521c74:	00 
  521c75:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
  521c7c:	00 
  521c7d:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  521c82:	48 89 84 24 b0 01 00 	mov    %rax,0x1b0(%rsp)
  521c89:	00 
  521c8a:	48 c7 84 24 b8 01 00 	movq   $0x0,0x1b8(%rsp)
  521c91:	00 00 00 00 00 
  521c96:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  521c9d:	00 
  521c9e:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
  521ca5:	00 
  521ca6:	e8 c5 39 00 00       	call   525670 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  521cab:	80 bc 24 20 01 00 00 	cmpb   $0xff,0x120(%rsp)
  521cb2:	ff 
  521cb3:	0f 84 1b 07 00 00    	je     5223d4 <<gpui_gpu::renderer::RendererState>::render+0x1054>
  521cb9:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
  521cbd:	66 0f 29 44 24 70    	movapd %xmm0,0x70(%rsp)
  521cc3:	48 8b 94 24 18 01 00 	mov    0x118(%rsp),%rdx
  521cca:	00 
  521ccb:	48 03 94 24 a0 00 00 	add    0xa0(%rsp),%rdx
  521cd2:	00 
  521cd3:	48 8d b4 24 19 01 00 	lea    0x119(%rsp),%rsi
  521cda:	00 
  521cdb:	0f 10 46 3f          	movups 0x3f(%rsi),%xmm0
  521cdf:	48 8d 8c 24 18 02 00 	lea    0x218(%rsp),%rcx
  521ce6:	00 
  521ce7:	0f 11 41 e0          	movups %xmm0,-0x20(%rcx)
  521ceb:	0f 10 46 4f          	movups 0x4f(%rsi),%xmm0
  521cef:	0f 11 41 30          	movups %xmm0,0x30(%rcx)
  521cf3:	48 8b 46 37          	mov    0x37(%rsi),%rax
  521cf7:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
  521cfe:	00 
  521cff:	0f 10 46 07          	movups 0x7(%rsi),%xmm0
  521d03:	0f 10 4e 17          	movups 0x17(%rsi),%xmm1
  521d07:	0f 10 56 27          	movups 0x27(%rsi),%xmm2
  521d0b:	0f 29 94 24 e0 01 00 	movaps %xmm2,0x1e0(%rsp)
  521d12:	00 
  521d13:	0f 29 8c 24 d0 01 00 	movaps %xmm1,0x1d0(%rsp)
  521d1a:	00 
  521d1b:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
  521d22:	00 
  521d23:	48 8d b4 24 28 04 00 	lea    0x428(%rsp),%rsi
  521d2a:	00 
  521d2b:	48 8b 46 10          	mov    0x10(%rsi),%rax
  521d2f:	48 8d bc 24 f0 01 00 	lea    0x1f0(%rsp),%rdi
  521d36:	00 
  521d37:	48 89 47 40          	mov    %rax,0x40(%rdi)
  521d3b:	0f 10 06             	movups (%rsi),%xmm0
  521d3e:	0f 11 47 30          	movups %xmm0,0x30(%rdi)
  521d42:	48 8d 84 24 40 04 00 	lea    0x440(%rsp),%rax
  521d49:	00 
  521d4a:	0f 10 00             	movups (%rax),%xmm0
  521d4d:	0f 11 41 20          	movups %xmm0,0x20(%rcx)
  521d51:	0f 10 46 28          	movups 0x28(%rsi),%xmm0
  521d55:	0f 11 41 40          	movups %xmm0,0x40(%rcx)
  521d59:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  521d5e:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
  521d65:	00 
  521d66:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
  521d6b:	0f 29 84 24 10 02 00 	movaps %xmm0,0x210(%rsp)
  521d72:	00 
  521d73:	48 8d bc 24 08 03 00 	lea    0x308(%rsp),%rdi
  521d7a:	00 
  521d7b:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
  521d82:	00 
  521d83:	44 89 f1             	mov    %r14d,%ecx
  521d86:	41 89 e8             	mov    %ebp,%r8d
  521d89:	e8 92 30 00 00       	call   524e20 <gpui_gpu::renderer::validate_draw>
  521d8e:	8b 8c 24 08 03 00 00 	mov    0x308(%rsp),%ecx
  521d95:	48 8b 84 24 0c 03 00 	mov    0x30c(%rsp),%rax
  521d9c:	00 
  521d9d:	83 f9 ff             	cmp    $0xffffffff,%ecx
  521da0:	0f 85 5a 0c 00 00    	jne    522a00 <<gpui_gpu::renderer::RendererState>::render+0x1680>
  521da6:	48 89 c1             	mov    %rax,%rcx
  521da9:	48 c1 e9 20          	shr    $0x20,%rcx
  521dad:	66 0f 6e c0          	movd   %eax,%xmm0
  521db1:	66 0f 6e d1          	movd   %ecx,%xmm2
  521db5:	66 0f 62 d0          	punpckldq %xmm0,%xmm2
  521db9:	0f 28 4c 24 70       	movaps 0x70(%rsp),%xmm1
  521dbe:	0f 28 c1             	movaps %xmm1,%xmm0
  521dc1:	0f 5f c2             	maxps  %xmm2,%xmm0
  521dc4:	0f c2 d2 03          	cmpunordps %xmm2,%xmm2
  521dc8:	0f 54 ca             	andps  %xmm2,%xmm1
  521dcb:	0f 55 d0             	andnps %xmm0,%xmm2
  521dce:	0f 56 d1             	orps   %xmm1,%xmm2
  521dd1:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
  521dd6:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  521ddd:	00 
  521dde:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
  521de5:	00 
  521de6:	e8 85 38 00 00       	call   525670 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  521deb:	80 bc 24 20 01 00 00 	cmpb   $0xff,0x120(%rsp)
  521df2:	ff 
  521df3:	66 0f 28 44 24 30    	movapd 0x30(%rsp),%xmm0
  521df9:	66 0f 29 44 24 70    	movapd %xmm0,0x70(%rsp)
  521dff:	0f 85 be fe ff ff    	jne    521cc3 <<gpui_gpu::renderer::RendererState>::render+0x943>
  521e05:	e9 d4 05 00 00       	jmp    5223de <<gpui_gpu::renderer::RendererState>::render+0x105e>
  521e0a:	48 83 bc 24 c0 00 00 	cmpq   $0x0,0xc0(%rsp)
  521e11:	00 00 
  521e13:	0f 84 d6 0a 00 00    	je     5228ef <<gpui_gpu::renderer::RendererState>::render+0x156f>
  521e19:	0f 28 4c 24 40       	movaps 0x40(%rsp),%xmm1
  521e1e:	0f 57 c0             	xorps  %xmm0,%xmm0
  521e21:	f2 0f 5a c1          	cvtsd2ss %xmm1,%xmm0
  521e25:	f3 0f 11 84 24 44 03 	movss  %xmm0,0x344(%rsp)
  521e2c:	00 00 
  521e2e:	8b 84 24 8c 00 00 00 	mov    0x8c(%rsp),%eax
  521e35:	0d 00 00 00 80       	or     $0x80000000,%eax
  521e3a:	89 84 24 40 03 00 00 	mov    %eax,0x340(%rsp)
  521e41:	f2 0f 10 44 24 18    	movsd  0x18(%rsp),%xmm0
  521e47:	0f c6 c1 e4          	shufps $0xe4,%xmm1,%xmm0
  521e4b:	66 0f 5a c0          	cvtpd2ps %xmm0,%xmm0
  521e4f:	66 0f 29 84 24 70 04 	movapd %xmm0,0x470(%rsp)
  521e56:	00 00 
  521e58:	48 c7 84 24 80 01 00 	movq   $0x0,0x180(%rsp)
  521e5f:	00 00 00 00 00 
  521e64:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  521e69:	48 8b 8c 24 80 01 00 	mov    0x180(%rsp),%rcx
  521e70:	00 
  521e71:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  521e74:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  521e7b:	00 
  521e7c:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  521e81:	e8 aa d9 ff ff       	call   51f830 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  521e86:	0f b6 bc 24 18 01 00 	movzbl 0x118(%rsp),%edi
  521e8d:	00 
  521e8e:	48 8d b4 24 19 01 00 	lea    0x119(%rsp),%rsi
  521e95:	00 
  521e96:	8b 06                	mov    (%rsi),%eax
  521e98:	8b 4e 03             	mov    0x3(%rsi),%ecx
  521e9b:	48 8d 94 24 f0 01 00 	lea    0x1f0(%rsp),%rdx
  521ea2:	00 
  521ea3:	89 4a d4             	mov    %ecx,-0x2c(%rdx)
  521ea6:	89 42 d1             	mov    %eax,-0x2f(%rdx)
  521ea9:	4c 8b 84 24 20 01 00 	mov    0x120(%rsp),%r8
  521eb0:	00 
  521eb1:	48 8b 46 2f          	mov    0x2f(%rsi),%rax
  521eb5:	48 89 02             	mov    %rax,(%rdx)
  521eb8:	0f 10 46 0f          	movups 0xf(%rsi),%xmm0
  521ebc:	0f 10 4e 1f          	movups 0x1f(%rsi),%xmm1
  521ec0:	0f 11 4a f0          	movups %xmm1,-0x10(%rdx)
  521ec4:	0f 11 42 e0          	movups %xmm0,-0x20(%rdx)
  521ec8:	0f 10 46 37          	movups 0x37(%rsi),%xmm0
  521ecc:	48 8d 8c 24 18 02 00 	lea    0x218(%rsp),%rcx
  521ed3:	00 
  521ed4:	0f 11 41 e0          	movups %xmm0,-0x20(%rcx)
  521ed8:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
  521edf:	00 
  521ee0:	0f 10 00             	movups (%rax),%xmm0
  521ee3:	0f 11 41 30          	movups %xmm0,0x30(%rcx)
  521ee7:	48 8b 84 24 90 03 00 	mov    0x390(%rsp),%rax
  521eee:	00 
  521eef:	48 89 42 40          	mov    %rax,0x40(%rdx)
  521ef3:	0f 28 84 24 80 03 00 	movaps 0x380(%rsp),%xmm0
  521efa:	00 
  521efb:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
  521eff:	48 8d 84 24 98 03 00 	lea    0x398(%rsp),%rax
  521f06:	00 
  521f07:	0f 10 00             	movups (%rax),%xmm0
  521f0a:	0f 11 41 20          	movups %xmm0,0x20(%rcx)
  521f0e:	0f 28 84 24 50 03 00 	movaps 0x350(%rsp),%xmm0
  521f15:	00 
  521f16:	0f 11 41 40          	movups %xmm0,0x40(%rcx)
  521f1a:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  521f1f:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
  521f26:	00 
  521f27:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
  521f2c:	0f 11 84 24 10 02 00 	movups %xmm0,0x210(%rsp)
  521f33:	00 
  521f34:	40 88 bc 24 f0 00 00 	mov    %dil,0xf0(%rsp)
  521f3b:	00 
  521f3c:	40 88 bc 24 c0 01 00 	mov    %dil,0x1c0(%rsp)
  521f43:	00 
  521f44:	4c 89 44 24 30       	mov    %r8,0x30(%rsp)
  521f49:	4c 89 84 24 c8 01 00 	mov    %r8,0x1c8(%rsp)
  521f50:	00 
  521f51:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  521f58:	00 
  521f59:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
  521f60:	00 
  521f61:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
  521f68:	00 
  521f69:	44 89 f1             	mov    %r14d,%ecx
  521f6c:	41 89 e8             	mov    %ebp,%r8d
  521f6f:	e8 ac 2e 00 00       	call   524e20 <gpui_gpu::renderer::validate_draw>
  521f74:	8b 84 24 18 01 00 00 	mov    0x118(%rsp),%eax
  521f7b:	48 8b 8c 24 1c 01 00 	mov    0x11c(%rsp),%rcx
  521f82:	00 
  521f83:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  521f8a:	00 
  521f8b:	83 f8 ff             	cmp    $0xffffffff,%eax
  521f8e:	0f 85 e6 0a 00 00    	jne    522a7a <<gpui_gpu::renderer::RendererState>::render+0x16fa>
  521f94:	80 bc 24 f0 00 00 00 	cmpb   $0x2,0xf0(%rsp)
  521f9b:	02 
  521f9c:	0f 94 44 24 2f       	sete   0x2f(%rsp)
  521fa1:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
  521fa7:	0f 95 44 24 2e       	setne  0x2e(%rsp)
  521fac:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  521fb1:	8b 48 10             	mov    0x10(%rax),%ecx
  521fb4:	b8 00 00 00 80       	mov    $0x80000000,%eax
  521fb9:	09 c1                	or     %eax,%ecx
  521fbb:	89 8c 24 48 03 00 00 	mov    %ecx,0x348(%rsp)
  521fc2:	f3 0f 10 84 24 c4 01 	movss  0x1c4(%rsp),%xmm0
  521fc9:	00 00 
  521fcb:	0f 29 84 24 b0 02 00 	movaps %xmm0,0x2b0(%rsp)
  521fd2:	00 
  521fd3:	0f 10 84 24 20 02 00 	movups 0x220(%rsp),%xmm0
  521fda:	00 
  521fdb:	0f 29 84 24 90 04 00 	movaps %xmm0,0x490(%rsp)
  521fe2:	00 
  521fe3:	f2 0f 10 84 24 28 02 	movsd  0x228(%rsp),%xmm0
  521fea:	00 00 
  521fec:	f2 0f 11 84 24 e0 03 	movsd  %xmm0,0x3e0(%rsp)
  521ff3:	00 00 
  521ff5:	f2 0f 10 84 24 30 02 	movsd  0x230(%rsp),%xmm0
  521ffc:	00 00 
  521ffe:	0f 29 84 24 80 04 00 	movaps %xmm0,0x480(%rsp)
  522005:	00 
  522006:	0f 10 84 24 38 02 00 	movups 0x238(%rsp),%xmm0
  52200d:	00 
  52200e:	0f 29 84 24 a0 04 00 	movaps %xmm0,0x4a0(%rsp)
  522015:	00 
  522016:	8b 84 24 58 02 00 00 	mov    0x258(%rsp),%eax
  52201d:	89 44 24 30          	mov    %eax,0x30(%rsp)
  522021:	8b 84 24 5c 02 00 00 	mov    0x25c(%rsp),%eax
  522028:	89 44 24 70          	mov    %eax,0x70(%rsp)
  52202c:	f2 0f 10 84 24 60 02 	movsd  0x260(%rsp),%xmm0
  522033:	00 00 
  522035:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
  52203c:	00 
  52203d:	80 bc 24 00 01 00 00 	cmpb   $0x0,0x100(%rsp)
  522044:	00 
  522045:	74 36                	je     52207d <<gpui_gpu::renderer::RendererState>::render+0xcfd>
  522047:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  52204e:	00 
  52204f:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
  522056:	00 
  522057:	48 8b 94 24 68 03 00 	mov    0x368(%rsp),%rdx
  52205e:	00 
  52205f:	ff 15 93 3d da 00    	call   *0xda3d93(%rip)        # 12c5df8 <_GLOBAL_OFFSET_TABLE_+0x1fb8>
  522065:	83 bc 24 18 01 00 00 	cmpl   $0x1,0x118(%rsp)
  52206c:	01 
  52206d:	0f 84 64 19 00 00    	je     5239d7 <<gpui_gpu::renderer::RendererState>::render+0x2657>
  522073:	0f 10 84 24 1c 01 00 	movups 0x11c(%rsp),%xmm0
  52207a:	00 
  52207b:	eb 08                	jmp    522085 <<gpui_gpu::renderer::RendererState>::render+0xd05>
  52207d:	0f 10 84 24 f8 01 00 	movups 0x1f8(%rsp),%xmm0
  522084:	00 
  522085:	0f 29 84 24 c0 02 00 	movaps %xmm0,0x2c0(%rsp)
  52208c:	00 
  52208d:	80 bc 24 f0 00 00 00 	cmpb   $0x3,0xf0(%rsp)
  522094:	03 
  522095:	0f 85 97 00 00 00    	jne    522132 <<gpui_gpu::renderer::RendererState>::render+0xdb2>
  52209b:	0f 57 c0             	xorps  %xmm0,%xmm0
  52209e:	0f 28 8c 24 b0 02 00 	movaps 0x2b0(%rsp),%xmm1
  5220a5:	00 
  5220a6:	0f 2e c8             	ucomiss %xmm0,%xmm1
  5220a9:	75 06                	jne    5220b1 <<gpui_gpu::renderer::RendererState>::render+0xd31>
  5220ab:	0f 8b 81 00 00 00    	jnp    522132 <<gpui_gpu::renderer::RendererState>::render+0xdb2>
  5220b1:	0f 28 a4 24 c0 02 00 	movaps 0x2c0(%rsp),%xmm4
  5220b8:	00 
  5220b9:	0f 28 c4             	movaps %xmm4,%xmm0
  5220bc:	66 0f 15 c4          	unpckhpd %xmm4,%xmm0
  5220c0:	f3 0f 10 1d 9c 36 60 	movss  0x60369c(%rip),%xmm3        # b25764 <anon.9adf6b51329d0e8f0ba7a07edbf8a285.69.llvm.2988996700849332186+0x10>
  5220c7:	00 
  5220c8:	f3 0f 59 c3          	mulss  %xmm3,%xmm0
  5220cc:	0f 28 ac 24 b0 02 00 	movaps 0x2b0(%rsp),%xmm5
  5220d3:	00 
  5220d4:	0f 28 cd             	movaps %xmm5,%xmm1
  5220d7:	f3 0f 5d c8          	minss  %xmm0,%xmm1
  5220db:	f3 0f c2 c0 03       	cmpunordss %xmm0,%xmm0
  5220e0:	0f 28 d0             	movaps %xmm0,%xmm2
  5220e3:	0f 55 d1             	andnps %xmm1,%xmm2
  5220e6:	0f 54 c5             	andps  %xmm5,%xmm0
  5220e9:	0f 56 c2             	orps   %xmm2,%xmm0
  5220ec:	0f 28 cc             	movaps %xmm4,%xmm1
  5220ef:	0f c6 cc ff          	shufps $0xff,%xmm4,%xmm1
  5220f3:	f3 0f 59 cb          	mulss  %xmm3,%xmm1
  5220f7:	0f 28 d1             	movaps %xmm1,%xmm2
  5220fa:	f3 0f c2 d1 03       	cmpunordss %xmm1,%xmm2
  5220ff:	0f 28 da             	movaps %xmm2,%xmm3
  522102:	0f 54 d8             	andps  %xmm0,%xmm3
  522105:	f3 0f 5d c1          	minss  %xmm1,%xmm0
  522109:	0f 55 d0             	andnps %xmm0,%xmm2
  52210c:	0f 56 d3             	orps   %xmm3,%xmm2
  52210f:	66 0f 7e d0          	movd   %xmm2,%eax
  522113:	89 44 24 30          	mov    %eax,0x30(%rsp)
  522117:	25 00 00 80 ff       	and    $0xff800000,%eax
  52211c:	b9 00 00 00 7f       	mov    $0x7f000000,%ecx
  522121:	29 c1                	sub    %eax,%ecx
  522123:	89 4c 24 70          	mov    %ecx,0x70(%rsp)
  522127:	0f 57 c0             	xorps  %xmm0,%xmm0
  52212a:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
  522131:	00 
  522132:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  522137:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
  52213e:	00 
  52213f:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  522144:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
  52214b:	00 
  52214c:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  522153:	00 
  522154:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
  52215b:	00 
  52215c:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  522161:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  522168:	00 
  522169:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
  52216e:	0f 11 84 24 38 01 00 	movups %xmm0,0x138(%rsp)
  522175:	00 
  522176:	48 8b 84 24 a0 03 00 	mov    0x3a0(%rsp),%rax
  52217d:	00 
  52217e:	48 8d 8c 24 19 01 00 	lea    0x119(%rsp),%rcx
  522185:	00 
  522186:	48 89 41 4f          	mov    %rax,0x4f(%rcx)
  52218a:	0f 28 84 24 80 03 00 	movaps 0x380(%rsp),%xmm0
  522191:	00 
  522192:	0f 28 8c 24 90 03 00 	movaps 0x390(%rsp),%xmm1
  522199:	00 
  52219a:	0f 11 49 3f          	movups %xmm1,0x3f(%rcx)
  52219e:	0f 11 41 2f          	movups %xmm0,0x2f(%rcx)
  5221a2:	0f 28 84 24 50 03 00 	movaps 0x350(%rsp),%xmm0
  5221a9:	00 
  5221aa:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
  5221b1:	00 
  5221b2:	0f 11 40 10          	movups %xmm0,0x10(%rax)
  5221b6:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  5221bd:	00 
  5221be:	ff 15 bc 40 da 00    	call   *0xda40bc(%rip)        # 12c6280 <_GLOBAL_OFFSET_TABLE_+0x2440>
  5221c4:	8b 8c 24 8c 00 00 00 	mov    0x8c(%rsp),%ecx
  5221cb:	89 8c 24 f0 00 00 00 	mov    %ecx,0xf0(%rsp)
  5221d2:	85 c0                	test   %eax,%eax
  5221d4:	74 34                	je     52220a <<gpui_gpu::renderer::RendererState>::render+0xe8a>
  5221d6:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  5221dd:	00 
  5221de:	89 c6                	mov    %eax,%esi
  5221e0:	e8 1b 65 00 00       	call   528700 <gpui_gpu::renderer::slots::color_word>
  5221e5:	89 44 24 30          	mov    %eax,0x30(%rsp)
  5221e9:	0f 57 c0             	xorps  %xmm0,%xmm0
  5221ec:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
  5221f3:	00 
  5221f4:	c7 44 24 70 00 00 00 	movl   $0x0,0x70(%rsp)
  5221fb:	00 
  5221fc:	8b 84 24 40 03 00 00 	mov    0x340(%rsp),%eax
  522203:	89 84 24 f0 00 00 00 	mov    %eax,0xf0(%rsp)
  52220a:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  522211:	00 
  522212:	48 c1 e8 20          	shr    $0x20,%rax
  522216:	48 89 84 24 b0 02 00 	mov    %rax,0x2b0(%rsp)
  52221d:	00 
  52221e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  522223:	48 8b 08             	mov    (%rax),%rcx
  522226:	48 8b 70 10          	mov    0x10(%rax),%rsi
  52222a:	48 29 f1             	sub    %rsi,%rcx
  52222d:	48 83 f9 05          	cmp    $0x5,%rcx
  522231:	0f 86 75 01 00 00    	jbe    5223ac <<gpui_gpu::renderer::RendererState>::render+0x102c>
  522237:	f2 0f 10 84 24 e0 03 	movsd  0x3e0(%rsp),%xmm0
  52223e:	00 00 
  522240:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  522244:	66 0f 28 8c 24 90 04 	movapd 0x490(%rsp),%xmm1
  52224b:	00 00 
  52224d:	66 0f 14 8c 24 80 04 	unpcklpd 0x480(%rsp),%xmm1
  522254:	00 00 
  522256:	66 0f 5a c9          	cvtpd2ps %xmm1,%xmm1
  52225a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  52225f:	48 8b 50 08          	mov    0x8(%rax),%rdx
  522263:	48 c1 e6 04          	shl    $0x4,%rsi
  522267:	0f 28 94 24 c0 02 00 	movaps 0x2c0(%rsp),%xmm2
  52226e:	00 
  52226f:	0f 11 14 32          	movups %xmm2,(%rdx,%rsi,1)
  522273:	66 0f 6f 94 24 70 04 	movdqa 0x470(%rsp),%xmm2
  52227a:	00 00 
  52227c:	66 0f d6 54 32 10    	movq   %xmm2,0x10(%rdx,%rsi,1)
  522282:	f3 0f 11 44 32 18    	movss  %xmm0,0x18(%rdx,%rsi,1)
  522288:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  52228f:	00 
  522290:	89 4c 32 1c          	mov    %ecx,0x1c(%rdx,%rsi,1)
  522294:	f3 0f 10 84 24 44 03 	movss  0x344(%rsp),%xmm0
  52229b:	00 00 
  52229d:	f3 0f 11 44 32 20    	movss  %xmm0,0x20(%rdx,%rsi,1)
  5222a3:	66 0f 13 4c 32 24    	movlpd %xmm1,0x24(%rdx,%rsi,1)
  5222a9:	48 8b bc 24 b0 02 00 	mov    0x2b0(%rsp),%rdi
  5222b0:	00 
  5222b1:	89 7c 32 2c          	mov    %edi,0x2c(%rdx,%rsi,1)
  5222b5:	0f 28 84 24 a0 04 00 	movaps 0x4a0(%rsp),%xmm0
  5222bc:	00 
  5222bd:	0f 11 44 32 30       	movups %xmm0,0x30(%rdx,%rsi,1)
  5222c2:	8b 7c 24 30          	mov    0x30(%rsp),%edi
  5222c6:	89 7c 32 40          	mov    %edi,0x40(%rdx,%rsi,1)
  5222ca:	8b 7c 24 70          	mov    0x70(%rsp),%edi
  5222ce:	89 7c 32 44          	mov    %edi,0x44(%rdx,%rsi,1)
  5222d2:	0f 28 84 24 e0 00 00 	movaps 0xe0(%rsp),%xmm0
  5222d9:	00 
  5222da:	0f 13 44 32 48       	movlps %xmm0,0x48(%rdx,%rsi,1)
  5222df:	48 c7 44 32 50 00 00 	movq   $0x0,0x50(%rdx,%rsi,1)
  5222e6:	00 00 
  5222e8:	c7 44 32 58 00 00 00 	movl   $0x0,0x58(%rdx,%rsi,1)
  5222ef:	00 
  5222f0:	8b bc 24 f0 00 00 00 	mov    0xf0(%rsp),%edi
  5222f7:	89 7c 32 5c          	mov    %edi,0x5c(%rdx,%rsi,1)
  5222fb:	48 83 40 10 06       	addq   $0x6,0x10(%rax)
  522300:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  522307:	00 
  522308:	48 89 c6             	mov    %rax,%rsi
  52230b:	48 8d 94 24 c0 01 00 	lea    0x1c0(%rsp),%rdx
  522312:	00 
  522313:	44 8b 84 24 48 03 00 	mov    0x348(%rsp),%r8d
  52231a:	00 
  52231b:	4c 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%r9
  522322:	00 
  522323:	ff b4 24 d0 00 00 00 	push   0xd0(%rsp)
  52232a:	55                   	push   %rbp
  52232b:	41 56                	push   %r14
  52232d:	ff b4 24 80 00 00 00 	push   0x80(%rsp)
  522334:	e8 77 17 00 00       	call   523ab0 <<gpui_gpu::renderer::RendererState>::bin_draw>
  522339:	48 83 c4 20          	add    $0x20,%rsp
  52233d:	8b 84 24 18 01 00 00 	mov    0x118(%rsp),%eax
  522344:	83 f8 ff             	cmp    $0xffffffff,%eax
  522347:	0f 85 28 f5 ff ff    	jne    521875 <<gpui_gpu::renderer::RendererState>::render+0x4f5>
  52234d:	0f b6 4c 24 2f       	movzbl 0x2f(%rsp),%ecx
  522352:	22 4c 24 2e          	and    0x2e(%rsp),%cl
  522356:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  52235b:	08 c8                	or     %cl,%al
  52235d:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  522362:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
  522369:	00 
  52236a:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  522371:	00 
  522372:	48 ff 84 24 a0 00 00 	incq   0xa0(%rsp)
  522379:	00 
  52237a:	48 8b 94 24 80 01 00 	mov    0x180(%rsp),%rdx
  522381:	00 
  522382:	48 83 c2 04          	add    $0x4,%rdx
  522386:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  52238d:	00 
  52238e:	48 8d 04 85 00 00 00 	lea    0x0(,%rax,4),%rax
  522395:	00 
  522396:	48 89 94 24 80 01 00 	mov    %rdx,0x180(%rsp)
  52239d:	00 
  52239e:	48 39 d0             	cmp    %rdx,%rax
  5223a1:	0f 85 bd fa ff ff    	jne    521e64 <<gpui_gpu::renderer::RendererState>::render+0xae4>
  5223a7:	e9 43 05 00 00       	jmp    5228ef <<gpui_gpu::renderer::RendererState>::render+0x156f>
  5223ac:	ba 06 00 00 00       	mov    $0x6,%edx
  5223b1:	b9 04 00 00 00       	mov    $0x4,%ecx
  5223b6:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  5223bc:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  5223c1:	e8 3a 25 b8 ff       	call   a4900 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  5223c6:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  5223cb:	48 8b 70 10          	mov    0x10(%rax),%rsi
  5223cf:	e9 63 fe ff ff       	jmp    522237 <<gpui_gpu::renderer::RendererState>::render+0xeb7>
  5223d4:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
  5223d8:	66 0f 29 44 24 30    	movapd %xmm0,0x30(%rsp)
  5223de:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  5223e3:	8b 40 10             	mov    0x10(%rax),%eax
  5223e6:	89 84 24 c0 02 00 00 	mov    %eax,0x2c0(%rsp)
  5223ed:	f2 0f 10 84 24 30 04 	movsd  0x430(%rsp),%xmm0
  5223f4:	00 00 
  5223f6:	f2 0f 11 84 24 80 01 	movsd  %xmm0,0x180(%rsp)
  5223fd:	00 00 
  5223ff:	f2 0f 10 84 24 38 04 	movsd  0x438(%rsp),%xmm0
  522406:	00 00 
  522408:	f2 0f 11 84 24 98 00 	movsd  %xmm0,0x98(%rsp)
  52240f:	00 00 
  522411:	0f 10 84 24 40 04 00 	movups 0x440(%rsp),%xmm0
  522418:	00 
  522419:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
  522420:	00 
  522421:	0f 10 84 24 50 04 00 	movups 0x450(%rsp),%xmm0
  522428:	00 
  522429:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
  52242e:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
  522433:	0f 28 c8             	movaps %xmm0,%xmm1
  522436:	0f 16 8c 24 28 04 00 	movhps 0x428(%rsp),%xmm1
  52243d:	00 
  52243e:	0f 29 8c 24 f0 00 00 	movaps %xmm1,0xf0(%rsp)
  522445:	00 
  522446:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  52244b:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
  522452:	00 
  522453:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  522458:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
  52245f:	00 
  522460:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  522467:	00 
  522468:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
  52246f:	00 
  522470:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  522475:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
  52247c:	00 
  52247d:	0f 11 84 24 e0 01 00 	movups %xmm0,0x1e0(%rsp)
  522484:	00 
  522485:	48 8d 8c 24 28 04 00 	lea    0x428(%rsp),%rcx
  52248c:	00 
  52248d:	48 8b 41 20          	mov    0x20(%rcx),%rax
  522491:	48 8d 94 24 f0 01 00 	lea    0x1f0(%rsp),%rdx
  522498:	00 
  522499:	48 89 42 20          	mov    %rax,0x20(%rdx)
  52249d:	0f 10 01             	movups (%rcx),%xmm0
  5224a0:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
  5224a4:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  5224a8:	0f 11 02             	movups %xmm0,(%rdx)
  5224ab:	f3 0f 6f 41 28       	movdqu 0x28(%rcx),%xmm0
  5224b0:	48 8d 84 24 18 02 00 	lea    0x218(%rsp),%rax
  5224b7:	00 
  5224b8:	f3 0f 7f 00          	movdqu %xmm0,(%rax)
  5224bc:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
  5224c3:	00 
  5224c4:	ff 15 b6 3d da 00    	call   *0xda3db6(%rip)        # 12c6280 <_GLOBAL_OFFSET_TABLE_+0x2440>
  5224ca:	85 c0                	test   %eax,%eax
  5224cc:	74 24                	je     5224f2 <<gpui_gpu::renderer::RendererState>::render+0x1172>
  5224ce:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  5224d5:	00 
  5224d6:	89 c6                	mov    %eax,%esi
  5224d8:	e8 23 62 00 00       	call   528700 <gpui_gpu::renderer::slots::color_word>
  5224dd:	81 8c 24 8c 00 00 00 	orl    $0x80000000,0x8c(%rsp)
  5224e4:	00 00 00 80 
  5224e8:	66 0f 6e c0          	movd   %eax,%xmm0
  5224ec:	66 0f 7f 44 24 70    	movdqa %xmm0,0x70(%rsp)
  5224f2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  5224f7:	48 8b 08             	mov    (%rax),%rcx
  5224fa:	48 8b 70 10          	mov    0x10(%rax),%rsi
  5224fe:	48 29 f1             	sub    %rsi,%rcx
  522501:	48 83 f9 04          	cmp    $0x4,%rcx
  522505:	0f 86 12 04 00 00    	jbe    52291d <<gpui_gpu::renderer::RendererState>::render+0x159d>
  52250b:	0f 28 6c 24 30       	movaps 0x30(%rsp),%xmm5
  522510:	0f 28 c5             	movaps %xmm5,%xmm0
  522513:	0f c6 c5 55          	shufps $0x55,%xmm5,%xmm0
  522517:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
  52251d:	66 0f c6 4c 24 40 02 	shufpd $0x2,0x40(%rsp),%xmm1
  522524:	66 0f 5a c9          	cvtpd2ps %xmm1,%xmm1
  522528:	66 0f 5a 94 24 f0 00 	cvtpd2ps 0xf0(%rsp),%xmm2
  52252f:	00 00 
  522531:	f2 0f 10 9c 24 80 01 	movsd  0x180(%rsp),%xmm3
  522538:	00 00 
  52253a:	f2 0f 5a db          	cvtsd2ss %xmm3,%xmm3
  52253e:	f2 0f 10 a4 24 98 00 	movsd  0x98(%rsp),%xmm4
  522545:	00 00 
  522547:	f2 0f 5a e4          	cvtsd2ss %xmm4,%xmm4
  52254b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  522550:	48 8b 48 08          	mov    0x8(%rax),%rcx
  522554:	48 c1 e6 04          	shl    $0x4,%rsi
  522558:	66 0f 13 0c 31       	movlpd %xmm1,(%rcx,%rsi,1)
  52255d:	f3 0f 11 5c 31 08    	movss  %xmm3,0x8(%rcx,%rsi,1)
  522563:	f3 0f 11 44 31 0c    	movss  %xmm0,0xc(%rcx,%rsi,1)
  522569:	66 0f 13 54 31 10    	movlpd %xmm2,0x10(%rcx,%rsi,1)
  52256f:	f3 0f 11 64 31 18    	movss  %xmm4,0x18(%rcx,%rsi,1)
  522575:	f3 0f 11 6c 31 1c    	movss  %xmm5,0x1c(%rcx,%rsi,1)
  52257b:	0f 28 8c 24 e0 00 00 	movaps 0xe0(%rsp),%xmm1
  522582:	00 
  522583:	0f 11 4c 31 20       	movups %xmm1,0x20(%rcx,%rsi,1)
  522588:	66 0f 28 4c 24 70    	movapd 0x70(%rsp),%xmm1
  52258e:	66 0f 11 4c 31 30    	movupd %xmm1,0x30(%rcx,%rsi,1)
  522594:	8b 94 24 8c 00 00 00 	mov    0x8c(%rsp),%edx
  52259b:	89 54 31 40          	mov    %edx,0x40(%rcx,%rsi,1)
  52259f:	48 c7 44 31 44 00 00 	movq   $0x0,0x44(%rcx,%rsi,1)
  5225a6:	00 00 
  5225a8:	c7 44 31 4c 00 00 00 	movl   $0x0,0x4c(%rcx,%rsi,1)
  5225af:	00 
  5225b0:	48 83 40 10 05       	addq   $0x5,0x10(%rax)
  5225b5:	48 ff 84 24 30 03 00 	incq   0x330(%rsp)
  5225bc:	00 
  5225bd:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  5225c4:	00 
  5225c5:	48 01 84 24 38 03 00 	add    %rax,0x338(%rsp)
  5225cc:	00 
  5225cd:	48 85 c0             	test   %rax,%rax
  5225d0:	0f 84 19 03 00 00    	je     5228ef <<gpui_gpu::renderer::RendererState>::render+0x156f>
  5225d6:	66 0f 7e c1          	movd   %xmm0,%ecx
  5225da:	66 0f 6f 44 24 30    	movdqa 0x30(%rsp),%xmm0
  5225e0:	66 0f 7e c0          	movd   %xmm0,%eax
  5225e4:	48 c1 e0 20          	shl    $0x20,%rax
  5225e8:	48 09 c1             	or     %rax,%rcx
  5225eb:	48 89 8c 24 b0 02 00 	mov    %rcx,0x2b0(%rsp)
  5225f2:	00 
  5225f3:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  5225fa:	00 00 
  5225fc:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  522601:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  522606:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  522609:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  522610:	00 
  522611:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  522616:	e8 15 d2 ff ff       	call   51f830 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  52261b:	0f b6 84 24 18 01 00 	movzbl 0x118(%rsp),%eax
  522622:	00 
  522623:	4c 8d 84 24 19 01 00 	lea    0x119(%rsp),%r8
  52262a:	00 
  52262b:	41 8b 08             	mov    (%r8),%ecx
  52262e:	41 8b 50 03          	mov    0x3(%r8),%edx
  522632:	48 8d bc 24 f0 01 00 	lea    0x1f0(%rsp),%rdi
  522639:	00 
  52263a:	89 57 d4             	mov    %edx,-0x2c(%rdi)
  52263d:	89 4f d1             	mov    %ecx,-0x2f(%rdi)
  522640:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
  522647:	00 
  522648:	41 0f 10 40 0f       	movups 0xf(%r8),%xmm0
  52264d:	41 0f 10 48 1f       	movups 0x1f(%r8),%xmm1
  522652:	0f 11 4f f0          	movups %xmm1,-0x10(%rdi)
  522656:	49 8b 50 2f          	mov    0x2f(%r8),%rdx
  52265a:	48 89 17             	mov    %rdx,(%rdi)
  52265d:	0f 11 47 e0          	movups %xmm0,-0x20(%rdi)
  522661:	f3 0f 10 9c 24 50 01 	movss  0x150(%rsp),%xmm3
  522668:	00 00 
  52266a:	f3 0f 7e 94 24 54 01 	movq   0x154(%rsp),%xmm2
  522671:	00 00 
  522673:	f3 0f 10 8c 24 5c 01 	movss  0x15c(%rsp),%xmm1
  52267a:	00 00 
  52267c:	48 8d 94 24 60 01 00 	lea    0x160(%rsp),%rdx
  522683:	00 
  522684:	0f 10 02             	movups (%rdx),%xmm0
  522687:	48 8d b4 24 18 02 00 	lea    0x218(%rsp),%rsi
  52268e:	00 
  52268f:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
  522693:	48 8b 94 24 90 03 00 	mov    0x390(%rsp),%rdx
  52269a:	00 
  52269b:	48 89 57 40          	mov    %rdx,0x40(%rdi)
  52269f:	0f 28 84 24 80 03 00 	movaps 0x380(%rsp),%xmm0
  5226a6:	00 
  5226a7:	0f 11 47 30          	movups %xmm0,0x30(%rdi)
  5226ab:	48 8d 94 24 98 03 00 	lea    0x398(%rsp),%rdx
  5226b2:	00 
  5226b3:	0f 10 02             	movups (%rdx),%xmm0
  5226b6:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
  5226ba:	0f 28 84 24 50 03 00 	movaps 0x350(%rsp),%xmm0
  5226c1:	00 
  5226c2:	0f 11 46 40          	movups %xmm0,0x40(%rsi)
  5226c6:	f3 0f 11 9c 24 e0 00 	movss  %xmm3,0xe0(%rsp)
  5226cd:	00 00 
  5226cf:	f3 0f 11 9c 24 f8 01 	movss  %xmm3,0x1f8(%rsp)
  5226d6:	00 00 
  5226d8:	66 0f 7f 94 24 c0 00 	movdqa %xmm2,0xc0(%rsp)
  5226df:	00 00 
  5226e1:	66 0f d6 94 24 fc 01 	movq   %xmm2,0x1fc(%rsp)
  5226e8:	00 00 
  5226ea:	f3 0f 11 4c 24 70    	movss  %xmm1,0x70(%rsp)
  5226f0:	f3 0f 11 8c 24 04 02 	movss  %xmm1,0x204(%rsp)
  5226f7:	00 00 
  5226f9:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  5226fe:	48 89 94 24 08 02 00 	mov    %rdx,0x208(%rsp)
  522705:	00 
  522706:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
  52270b:	0f 11 84 24 10 02 00 	movups %xmm0,0x210(%rsp)
  522712:	00 
  522713:	88 84 24 c0 01 00 00 	mov    %al,0x1c0(%rsp)
  52271a:	48 89 8c 24 c8 01 00 	mov    %rcx,0x1c8(%rsp)
  522721:	00 
  522722:	3c 02                	cmp    $0x2,%al
  522724:	0f 94 84 24 98 00 00 	sete   0x98(%rsp)
  52272b:	00 
  52272c:	48 85 c9             	test   %rcx,%rcx
  52272f:	0f 95 84 24 f0 00 00 	setne  0xf0(%rsp)
  522736:	00 
  522737:	80 bc 24 00 01 00 00 	cmpb   $0x0,0x100(%rsp)
  52273e:	00 
  52273f:	74 65                	je     5227a6 <<gpui_gpu::renderer::RendererState>::render+0x1426>
  522741:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  522748:	00 
  522749:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
  522750:	00 
  522751:	48 8b 94 24 68 03 00 	mov    0x368(%rsp),%rdx
  522758:	00 
  522759:	ff 15 99 36 da 00    	call   *0xda3699(%rip)        # 12c5df8 <_GLOBAL_OFFSET_TABLE_+0x1fb8>
  52275f:	80 bc 24 18 01 00 00 	cmpb   $0x0,0x118(%rsp)
  522766:	00 
  522767:	0f 85 08 08 00 00    	jne    522f75 <<gpui_gpu::renderer::RendererState>::render+0x1bf5>
  52276d:	f3 0f 10 84 24 28 01 	movss  0x128(%rsp),%xmm0
  522774:	00 00 
  522776:	f3 0f 11 44 24 70    	movss  %xmm0,0x70(%rsp)
  52277c:	0f 10 84 24 1c 01 00 	movups 0x11c(%rsp),%xmm0
  522783:	00 
  522784:	f2 0f 10 8c 24 20 01 	movsd  0x120(%rsp),%xmm1
  52278b:	00 00 
  52278d:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
  522794:	00 
  522795:	0f 29 84 24 60 04 00 	movaps %xmm0,0x460(%rsp)
  52279c:	00 
  52279d:	f3 0f 11 84 24 e0 00 	movss  %xmm0,0xe0(%rsp)
  5227a4:	00 00 
  5227a6:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  5227ab:	48 8b 08             	mov    (%rax),%rcx
  5227ae:	48 8b 40 10          	mov    0x10(%rax),%rax
  5227b2:	48 29 c1             	sub    %rax,%rcx
  5227b5:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  5227bc:	00 
  5227bd:	48 83 f9 01          	cmp    $0x1,%rcx
  5227c1:	0f 86 f8 00 00 00    	jbe    5228bf <<gpui_gpu::renderer::RendererState>::render+0x153f>
  5227c7:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  5227cc:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
  5227d0:	48 c1 e0 04          	shl    $0x4,%rax
  5227d4:	f3 0f 10 84 24 e0 00 	movss  0xe0(%rsp),%xmm0
  5227db:	00 00 
  5227dd:	f3 0f 11 04 01       	movss  %xmm0,(%rcx,%rax,1)
  5227e2:	0f 28 84 24 c0 00 00 	movaps 0xc0(%rsp),%xmm0
  5227e9:	00 
  5227ea:	0f 13 44 01 04       	movlps %xmm0,0x4(%rcx,%rax,1)
  5227ef:	f3 0f 10 44 24 70    	movss  0x70(%rsp),%xmm0
  5227f5:	f3 0f 11 44 01 0c    	movss  %xmm0,0xc(%rcx,%rax,1)
  5227fb:	48 c7 44 01 10 00 00 	movq   $0x0,0x10(%rcx,%rax,1)
  522802:	00 00 
  522804:	c7 44 01 18 00 00 00 	movl   $0x0,0x18(%rcx,%rax,1)
  52280b:	00 
  52280c:	8b 94 24 c0 02 00 00 	mov    0x2c0(%rsp),%edx
  522813:	89 54 01 1c          	mov    %edx,0x1c(%rcx,%rax,1)
  522817:	48 83 46 10 02       	addq   $0x2,0x10(%rsi)
  52281c:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  522823:	00 
  522824:	48 8d 94 24 c0 01 00 	lea    0x1c0(%rsp),%rdx
  52282b:	00 
  52282c:	48 8b 8c 24 b0 02 00 	mov    0x2b0(%rsp),%rcx
  522833:	00 
  522834:	4c 8b 84 24 80 01 00 	mov    0x180(%rsp),%r8
  52283b:	00 
  52283c:	4c 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%r9
  522843:	00 
  522844:	ff b4 24 d0 00 00 00 	push   0xd0(%rsp)
  52284b:	55                   	push   %rbp
  52284c:	41 56                	push   %r14
  52284e:	ff b4 24 80 00 00 00 	push   0x80(%rsp)
  522855:	e8 56 12 00 00       	call   523ab0 <<gpui_gpu::renderer::RendererState>::bin_draw>
  52285a:	48 83 c4 20          	add    $0x20,%rsp
  52285e:	8b 84 24 18 01 00 00 	mov    0x118(%rsp),%eax
  522865:	83 f8 ff             	cmp    $0xffffffff,%eax
  522868:	0f 85 07 f0 ff ff    	jne    521875 <<gpui_gpu::renderer::RendererState>::render+0x4f5>
  52286e:	0f b6 8c 24 98 00 00 	movzbl 0x98(%rsp),%ecx
  522875:	00 
  522876:	22 8c 24 f0 00 00 00 	and    0xf0(%rsp),%cl
  52287d:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  522882:	08 c8                	or     %cl,%al
  522884:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  522889:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
  522890:	00 
  522891:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  522898:	00 
  522899:	48 ff 84 24 a0 00 00 	incq   0xa0(%rsp)
  5228a0:	00 
  5228a1:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  5228a6:	48 83 c1 04          	add    $0x4,%rcx
  5228aa:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  5228af:	48 39 8c 24 d8 03 00 	cmp    %rcx,0x3d8(%rsp)
  5228b6:	00 
  5228b7:	0f 85 3f fd ff ff    	jne    5225fc <<gpui_gpu::renderer::RendererState>::render+0x127c>
  5228bd:	eb 30                	jmp    5228ef <<gpui_gpu::renderer::RendererState>::render+0x156f>
  5228bf:	ba 02 00 00 00       	mov    $0x2,%edx
  5228c4:	b9 04 00 00 00       	mov    $0x4,%ecx
  5228c9:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  5228cf:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  5228d4:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
  5228db:	00 
  5228dc:	e8 1f 20 b8 ff       	call   a4900 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  5228e1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  5228e6:	48 8b 40 10          	mov    0x10(%rax),%rax
  5228ea:	e9 d8 fe ff ff       	jmp    5227c7 <<gpui_gpu::renderer::RendererState>::render+0x1447>
  5228ef:	48 8d bc 24 f8 03 00 	lea    0x3f8(%rsp),%rdi
  5228f6:	00 
  5228f7:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
  5228fe:	00 
  5228ff:	ff 15 6b 50 da 00    	call   *0xda506b(%rip)        # 12c7970 <_GLOBAL_OFFSET_TABLE_+0x3b30>
  522905:	48 8b 84 24 f8 03 00 	mov    0x3f8(%rsp),%rax
  52290c:	00 
  52290d:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  522912:	48 85 c0             	test   %rax,%rax
  522915:	0f 85 11 f1 ff ff    	jne    521a2c <<gpui_gpu::renderer::RendererState>::render+0x6ac>
  52291b:	eb 61                	jmp    52297e <<gpui_gpu::renderer::RendererState>::render+0x15fe>
  52291d:	ba 05 00 00 00       	mov    $0x5,%edx
  522922:	b9 04 00 00 00       	mov    $0x4,%ecx
  522927:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  52292d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  522932:	e8 c9 1f b8 ff       	call   a4900 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  522937:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  52293c:	48 8b 70 10          	mov    0x10(%rax),%rsi
  522940:	e9 c6 fb ff ff       	jmp    52250b <<gpui_gpu::renderer::RendererState>::render+0x118b>
  522945:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
  52294c:	00 00 00 00 00 
  522951:	48 c7 84 24 38 03 00 	movq   $0x0,0x338(%rsp)
  522958:	00 00 00 00 00 
  52295d:	48 c7 84 24 30 03 00 	movq   $0x0,0x330(%rsp)
  522964:	00 00 00 00 00 
  522969:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
  522970:	00 00 00 00 00 
  522975:	48 c7 44 24 60 00 00 	movq   $0x0,0x60(%rsp)
  52297c:	00 00 
  52297e:	48 8b b4 24 98 01 00 	mov    0x198(%rsp),%rsi
  522985:	00 
  522986:	48 8d 56 08          	lea    0x8(%rsi),%rdx
  52298a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  52298f:	48 8d 88 58 02 00 00 	lea    0x258(%rax),%rcx
  522996:	4c 8d 80 28 03 00 00 	lea    0x328(%rax),%r8
  52299d:	4c 8b 48 10          	mov    0x10(%rax),%r9
  5229a1:	48 83 ec 08          	sub    $0x8,%rsp
  5229a5:	48 8d bc 24 c8 01 00 	lea    0x1c8(%rsp),%rdi
  5229ac:	00 
  5229ad:	48 89 94 24 08 01 00 	mov    %rdx,0x108(%rsp)
  5229b4:	00 
  5229b5:	48 89 8c 24 c8 02 00 	mov    %rcx,0x2c8(%rsp)
  5229bc:	00 
  5229bd:	4c 89 84 24 a0 00 00 	mov    %r8,0xa0(%rsp)
  5229c4:	00 
  5229c5:	ff b4 24 b0 00 00 00 	push   0xb0(%rsp)
  5229cc:	e8 9f 36 00 00       	call   526070 <gpui_gpu::renderer::images::prepare>
  5229d1:	48 83 c4 10          	add    $0x10,%rsp
  5229d5:	83 bc 24 c0 01 00 00 	cmpl   $0xffffffff,0x1c0(%rsp)
  5229dc:	ff 
  5229dd:	74 47                	je     522a26 <<gpui_gpu::renderer::RendererState>::render+0x16a6>
  5229df:	0f 10 84 24 c0 01 00 	movups 0x1c0(%rsp),%xmm0
  5229e6:	00 
  5229e7:	0f 10 8c 24 d0 01 00 	movups 0x1d0(%rsp),%xmm1
  5229ee:	00 
  5229ef:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  5229f4:	0f 11 4f 10          	movups %xmm1,0x10(%rdi)
  5229f8:	0f 11 07             	movups %xmm0,(%rdi)
  5229fb:	e9 91 ea ff ff       	jmp    521491 <<gpui_gpu::renderer::RendererState>::render+0x111>
  522a00:	8b 94 24 24 03 00 00 	mov    0x324(%rsp),%edx
  522a07:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  522a0c:	89 57 1c             	mov    %edx,0x1c(%rdi)
  522a0f:	0f 10 84 24 14 03 00 	movups 0x314(%rsp),%xmm0
  522a16:	00 
  522a17:	0f 11 47 0c          	movups %xmm0,0xc(%rdi)
  522a1b:	89 0f                	mov    %ecx,(%rdi)
  522a1d:	48 89 47 04          	mov    %rax,0x4(%rdi)
  522a21:	e9 6b ea ff ff       	jmp    521491 <<gpui_gpu::renderer::RendererState>::render+0x111>
  522a26:	44 0f b6 44 24 60    	movzbl 0x60(%rsp),%r8d
  522a2c:	41 83 e0 01          	and    $0x1,%r8d
  522a30:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
  522a37:	00 
  522a38:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  522a3d:	48 8b 94 24 98 01 00 	mov    0x198(%rsp),%rdx
  522a44:	00 
  522a45:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  522a4c:	00 
  522a4d:	e8 fe de ff ff       	call   520950 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  522a52:	8b 84 24 c0 01 00 00 	mov    0x1c0(%rsp),%eax
  522a59:	83 f8 ff             	cmp    $0xffffffff,%eax
  522a5c:	74 4a                	je     522aa8 <<gpui_gpu::renderer::RendererState>::render+0x1728>
  522a5e:	8b 8c 24 c4 01 00 00 	mov    0x1c4(%rsp),%ecx
  522a65:	48 8b 94 24 c8 01 00 	mov    0x1c8(%rsp),%rdx
  522a6c:	00 
  522a6d:	0f 10 84 24 d0 01 00 	movups 0x1d0(%rsp),%xmm0
  522a74:	00 
  522a75:	e9 12 ee ff ff       	jmp    52188c <<gpui_gpu::renderer::RendererState>::render+0x50c>
  522a7a:	8b 8c 24 34 01 00 00 	mov    0x134(%rsp),%ecx
  522a81:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  522a86:	89 4f 1c             	mov    %ecx,0x1c(%rdi)
  522a89:	0f 10 84 24 24 01 00 	movups 0x124(%rsp),%xmm0
  522a90:	00 
  522a91:	0f 11 47 0c          	movups %xmm0,0xc(%rdi)
  522a95:	89 07                	mov    %eax,(%rdi)
  522a97:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  522a9e:	00 
  522a9f:	48 89 47 04          	mov    %rax,0x4(%rdi)
  522aa3:	e9 e9 e9 ff ff       	jmp    521491 <<gpui_gpu::renderer::RendererState>::render+0x111>
  522aa8:	48 8b 84 24 c8 01 00 	mov    0x1c8(%rsp),%rax
  522aaf:	00 
  522ab0:	48 89 84 24 b0 02 00 	mov    %rax,0x2b0(%rsp)
  522ab7:	00 
  522ab8:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
  522abf:	00 
  522ac0:	48 8b 82 80 00 00 00 	mov    0x80(%rdx),%rax
  522ac7:	48 8b 8a 98 00 00 00 	mov    0x98(%rdx),%rcx
  522ace:	48 03 8a b0 00 00 00 	add    0xb0(%rdx),%rcx
  522ad5:	48 89 94 24 80 03 00 	mov    %rdx,0x380(%rsp)
  522adc:	00 
  522add:	48 c7 84 24 88 03 00 	movq   $0x0,0x388(%rsp)
  522ae4:	00 00 00 00 00 
  522ae9:	48 89 84 24 90 03 00 	mov    %rax,0x390(%rsp)
  522af0:	00 
  522af1:	48 89 8c 24 98 03 00 	mov    %rcx,0x398(%rsp)
  522af8:	00 
  522af9:	8b 44 24 28          	mov    0x28(%rsp),%eax
  522afd:	89 84 24 a0 03 00 00 	mov    %eax,0x3a0(%rsp)
  522b04:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  522b0b:	00 
  522b0c:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
  522b13:	00 
  522b14:	ff 15 56 4e da 00    	call   *0xda4e56(%rip)        # 12c7970 <_GLOBAL_OFFSET_TABLE_+0x3b30>
  522b1a:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
  522b21:	00 
  522b22:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  522b27:	48 85 c0             	test   %rax,%rax
  522b2a:	0f 84 cb 03 00 00    	je     522efb <<gpui_gpu::renderer::RendererState>::render+0x1b7b>
  522b30:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  522b35:	48 05 20 01 00 00    	add    $0x120,%rax
  522b3b:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  522b42:	00 
  522b43:	eb 39                	jmp    522b7e <<gpui_gpu::renderer::RendererState>::render+0x17fe>
  522b45:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  522b4c:	00 
  522b4d:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
  522b54:	00 
  522b55:	ff 15 15 4e da 00    	call   *0xda4e15(%rip)        # 12c7970 <_GLOBAL_OFFSET_TABLE_+0x3b30>
  522b5b:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
  522b62:	00 
  522b63:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  522b68:	48 89 8c 24 d8 00 00 	mov    %rcx,0xd8(%rsp)
  522b6f:	00 
  522b70:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  522b75:	48 85 c0             	test   %rax,%rax
  522b78:	0f 84 7d 03 00 00    	je     522efb <<gpui_gpu::renderer::RendererState>::render+0x1b7b>
  522b7e:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
  522b85:	00 
  522b86:	48 8b bc 24 28 01 00 	mov    0x128(%rsp),%rdi
  522b8d:	00 
  522b8e:	48 89 bc 24 90 00 00 	mov    %rdi,0x90(%rsp)
  522b95:	00 
  522b96:	48 8d 8c 24 30 01 00 	lea    0x130(%rsp),%rcx
  522b9d:	00 
  522b9e:	0f 10 41 40          	movups 0x40(%rcx),%xmm0
  522ba2:	48 8d 84 24 18 02 00 	lea    0x218(%rsp),%rax
  522ba9:	00 
  522baa:	0f 11 00             	movups %xmm0,(%rax)
  522bad:	0f 10 01             	movups (%rcx),%xmm0
  522bb0:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
  522bb4:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
  522bb8:	0f 10 59 30          	movups 0x30(%rcx),%xmm3
  522bbc:	0f 11 58 f0          	movups %xmm3,-0x10(%rax)
  522bc0:	0f 11 50 e0          	movups %xmm2,-0x20(%rax)
  522bc4:	0f 11 48 d0          	movups %xmm1,-0x30(%rax)
  522bc8:	0f 11 40 c0          	movups %xmm0,-0x40(%rax)
  522bcc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  522bd1:	0f b6 b0 41 03 00 00 	movzbl 0x341(%rax),%esi
  522bd8:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  522bdd:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
  522be4:	00 
  522be5:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
  522bea:	48 89 94 24 c8 01 00 	mov    %rdx,0x1c8(%rsp)
  522bf1:	00 
  522bf2:	48 89 bc 24 d0 01 00 	mov    %rdi,0x1d0(%rsp)
  522bf9:	00 
  522bfa:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
  522c01:	00 
  522c02:	e8 c9 21 00 00       	call   524dd0 <gpui_gpu::renderer::compact_group>
  522c07:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
  522c0e:	00 
  522c0f:	48 8d 51 05          	lea    0x5(%rcx),%rdx
  522c13:	84 c0                	test   %al,%al
  522c15:	48 0f 44 d1          	cmove  %rcx,%rdx
  522c19:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
  522c1e:	48 83 bc 24 90 00 00 	cmpq   $0x0,0x90(%rsp)
  522c25:	00 00 
  522c27:	0f 84 18 ff ff ff    	je     522b45 <<gpui_gpu::renderer::RendererState>::render+0x17c5>
  522c2d:	48 c1 a4 24 90 00 00 	shlq   $0x2,0x90(%rsp)
  522c34:	00 02 
  522c36:	34 01                	xor    $0x1,%al
  522c38:	0f b6 c8             	movzbl %al,%ecx
  522c3b:	c1 e1 02             	shl    $0x2,%ecx
  522c3e:	48 8d 41 01          	lea    0x1(%rcx),%rax
  522c42:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  522c49:	00 
  522c4a:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  522c4f:	4c 8d 04 08          	lea    (%rax,%rcx,1),%r8
  522c53:	49 ff c0             	inc    %r8
  522c56:	48 83 c9 02          	or     $0x2,%rcx
  522c5a:	49 c1 e0 04          	shl    $0x4,%r8
  522c5e:	48 89 8c 24 d8 00 00 	mov    %rcx,0xd8(%rsp)
  522c65:	00 
  522c66:	c1 e1 04             	shl    $0x4,%ecx
  522c69:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
  522c70:	00 
  522c71:	31 c9                	xor    %ecx,%ecx
  522c73:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
  522c78:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  522c7d:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  522c82:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  522c85:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
  522c8c:	00 
  522c8d:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  522c92:	e8 99 cb ff ff       	call   51f830 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  522c97:	0f b6 8c 24 c0 01 00 	movzbl 0x1c0(%rsp),%ecx
  522c9e:	00 
  522c9f:	0f b6 84 24 c1 01 00 	movzbl 0x1c1(%rsp),%eax
  522ca6:	00 
  522ca7:	f3 0f 10 a4 24 c4 01 	movss  0x1c4(%rsp),%xmm4
  522cae:	00 00 
  522cb0:	48 8d b4 24 c8 01 00 	lea    0x1c8(%rsp),%rsi
  522cb7:	00 
  522cb8:	48 8b 56 10          	mov    0x10(%rsi),%rdx
  522cbc:	48 89 94 24 e0 02 00 	mov    %rdx,0x2e0(%rsp)
  522cc3:	00 
  522cc4:	0f 10 06             	movups (%rsi),%xmm0
  522cc7:	0f 29 84 24 d0 02 00 	movaps %xmm0,0x2d0(%rsp)
  522cce:	00 
  522ccf:	83 f9 01             	cmp    $0x1,%ecx
  522cd2:	0f 84 8f 00 00 00    	je     522d67 <<gpui_gpu::renderer::RendererState>::render+0x19e7>
  522cd8:	0f 29 a4 24 80 01 00 	movaps %xmm4,0x180(%rsp)
  522cdf:	00 
  522ce0:	48 8b b4 24 e0 01 00 	mov    0x1e0(%rsp),%rsi
  522ce7:	00 
  522ce8:	8b 94 24 e8 01 00 00 	mov    0x1e8(%rsp),%edx
  522cef:	89 54 24 30          	mov    %edx,0x30(%rsp)
  522cf3:	8b 94 24 ec 01 00 00 	mov    0x1ec(%rsp),%edx
  522cfa:	89 54 24 20          	mov    %edx,0x20(%rsp)
  522cfe:	83 f9 03             	cmp    $0x3,%ecx
  522d01:	0f 85 e2 00 00 00    	jne    522de9 <<gpui_gpu::renderer::RendererState>::render+0x1a69>
  522d07:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  522d0e:	00 
  522d0f:	48 8b 39             	mov    (%rcx),%rdi
  522d12:	48 85 ff             	test   %rdi,%rdi
  522d15:	0f 84 0c 0d 00 00    	je     523a27 <<gpui_gpu::renderer::RendererState>::render+0x26a7>
  522d1b:	0f b6 d0             	movzbl %al,%edx
  522d1e:	e8 dd 2f 00 00       	call   525d00 <<gpui_gpu::renderer::images::Images>::metadata>
  522d23:	89 c1                	mov    %eax,%ecx
  522d25:	48 c1 e8 20          	shr    $0x20,%rax
  522d29:	89 c2                	mov    %eax,%edx
  522d2b:	83 ca 10             	or     $0x10,%edx
  522d2e:	0f 57 c0             	xorps  %xmm0,%xmm0
  522d31:	0f 28 8c 24 80 01 00 	movaps 0x180(%rsp),%xmm1
  522d38:	00 
  522d39:	0f 2e c8             	ucomiss %xmm0,%xmm1
  522d3c:	0f 45 c2             	cmovne %edx,%eax
  522d3f:	0f 4a c2             	cmovp  %edx,%eax
  522d42:	8b 54 24 20          	mov    0x20(%rsp),%edx
  522d46:	c1 e2 10             	shl    $0x10,%edx
  522d49:	0b 54 24 30          	or     0x30(%rsp),%edx
  522d4d:	89 8c 24 a0 01 00 00 	mov    %ecx,0x1a0(%rsp)
  522d54:	89 84 24 a4 01 00 00 	mov    %eax,0x1a4(%rsp)
  522d5b:	89 94 24 a8 01 00 00 	mov    %edx,0x1a8(%rsp)
  522d62:	e9 1f 01 00 00       	jmp    522e86 <<gpui_gpu::renderer::RendererState>::render+0x1b06>
  522d67:	f3 0f 10 84 24 00 02 	movss  0x200(%rsp),%xmm0
  522d6e:	00 00 
  522d70:	f3 0f 10 1d ec 29 60 	movss  0x6029ec(%rip),%xmm3        # b25764 <anon.9adf6b51329d0e8f0ba7a07edbf8a285.69.llvm.2988996700849332186+0x10>
  522d77:	00 
  522d78:	f3 0f 59 c3          	mulss  %xmm3,%xmm0
  522d7c:	0f 28 cc             	movaps %xmm4,%xmm1
  522d7f:	f3 0f 5d c8          	minss  %xmm0,%xmm1
  522d83:	f3 0f c2 c0 03       	cmpunordss %xmm0,%xmm0
  522d88:	0f 28 d0             	movaps %xmm0,%xmm2
  522d8b:	0f 55 d1             	andnps %xmm1,%xmm2
  522d8e:	0f 54 c4             	andps  %xmm4,%xmm0
  522d91:	0f 56 c2             	orps   %xmm2,%xmm0
  522d94:	f3 0f 10 8c 24 04 02 	movss  0x204(%rsp),%xmm1
  522d9b:	00 00 
  522d9d:	f3 0f 59 cb          	mulss  %xmm3,%xmm1
  522da1:	0f 28 d1             	movaps %xmm1,%xmm2
  522da4:	f3 0f c2 d1 03       	cmpunordss %xmm1,%xmm2
  522da9:	0f 28 da             	movaps %xmm2,%xmm3
  522dac:	0f 54 d8             	andps  %xmm0,%xmm3
  522daf:	f3 0f 5d c1          	minss  %xmm1,%xmm0
  522db3:	0f 55 d0             	andnps %xmm0,%xmm2
  522db6:	0f 56 d3             	orps   %xmm3,%xmm2
  522db9:	66 0f 7e d0          	movd   %xmm2,%eax
  522dbd:	25 00 00 80 ff       	and    $0xff800000,%eax
  522dc2:	b9 00 00 00 7f       	mov    $0x7f000000,%ecx
  522dc7:	29 c1                	sub    %eax,%ecx
  522dc9:	c7 84 24 a0 01 00 00 	movl   $0x40000000,0x1a0(%rsp)
  522dd0:	00 00 00 40 
  522dd4:	f3 0f 11 94 24 a4 01 	movss  %xmm2,0x1a4(%rsp)
  522ddb:	00 00 
  522ddd:	89 8c 24 a8 01 00 00 	mov    %ecx,0x1a8(%rsp)
  522de4:	e9 9d 00 00 00       	jmp    522e86 <<gpui_gpu::renderer::RendererState>::render+0x1b06>
  522de9:	80 f9 02             	cmp    $0x2,%cl
  522dec:	75 50                	jne    522e3e <<gpui_gpu::renderer::RendererState>::render+0x1abe>
  522dee:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
  522df5:	00 
  522df6:	48 8b 8c 24 e0 02 00 	mov    0x2e0(%rsp),%rcx
  522dfd:	00 
  522dfe:	48 89 8c 24 d0 01 00 	mov    %rcx,0x1d0(%rsp)
  522e05:	00 
  522e06:	0f 28 84 24 d0 02 00 	movaps 0x2d0(%rsp),%xmm0
  522e0d:	00 
  522e0e:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
  522e15:	00 
  522e16:	48 89 b4 24 d8 01 00 	mov    %rsi,0x1d8(%rsp)
  522e1d:	00 
  522e1e:	8b 4c 24 30          	mov    0x30(%rsp),%ecx
  522e22:	89 8c 24 e0 01 00 00 	mov    %ecx,0x1e0(%rsp)
  522e29:	8b 4c 24 20          	mov    0x20(%rsp),%ecx
  522e2d:	89 8c 24 e4 01 00 00 	mov    %ecx,0x1e4(%rsp)
  522e34:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
  522e3b:	00 
  522e3c:	eb 0c                	jmp    522e4a <<gpui_gpu::renderer::RendererState>::render+0x1aca>
  522e3e:	48 c7 84 24 c0 01 00 	movq   $0x0,0x1c0(%rsp)
  522e45:	00 00 00 00 00 
  522e4a:	c7 84 24 10 03 00 00 	movl   $0x0,0x310(%rsp)
  522e51:	00 00 00 00 
  522e55:	48 c7 84 24 08 03 00 	movq   $0x0,0x308(%rsp)
  522e5c:	00 00 00 00 00 
  522e61:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  522e68:	00 
  522e69:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
  522e70:	00 
  522e71:	48 8d 94 24 08 03 00 	lea    0x308(%rsp),%rdx
  522e78:	00 
  522e79:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
  522e80:	00 
  522e81:	e8 6a b7 ff ff       	call   51e5f0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  522e86:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
  522e8b:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  522e92:	00 
  522e93:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
  522e97:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  522e9c:	48 8b 70 10          	mov    0x10(%rax),%rsi
  522ea0:	48 39 f7             	cmp    %rsi,%rdi
  522ea3:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  522ea8:	0f 83 86 0b 00 00    	jae    523a34 <<gpui_gpu::renderer::RendererState>::render+0x26b4>
  522eae:	48 8b 40 08          	mov    0x8(%rax),%rax
  522eb2:	8b 8c 24 a8 01 00 00 	mov    0x1a8(%rsp),%ecx
  522eb9:	42 89 4c 00 08       	mov    %ecx,0x8(%rax,%r8,1)
  522ebe:	48 8b 8c 24 a0 01 00 	mov    0x1a0(%rsp),%rcx
  522ec5:	00 
  522ec6:	4a 89 0c 00          	mov    %rcx,(%rax,%r8,1)
  522eca:	48 03 94 24 d8 00 00 	add    0xd8(%rsp),%rdx
  522ed1:	00 
  522ed2:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
  522ed7:	4c 03 84 24 e0 00 00 	add    0xe0(%rsp),%r8
  522ede:	00 
  522edf:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  522ee4:	48 83 c1 04          	add    $0x4,%rcx
  522ee8:	48 39 8c 24 90 00 00 	cmp    %rcx,0x90(%rsp)
  522eef:	00 
  522ef0:	0f 85 7d fd ff ff    	jne    522c73 <<gpui_gpu::renderer::RendererState>::render+0x18f3>
  522ef6:	e9 4a fc ff ff       	jmp    522b45 <<gpui_gpu::renderer::RendererState>::render+0x17c5>
  522efb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  522f00:	48 8b 40 28          	mov    0x28(%rax),%rax
  522f04:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
  522f0b:	00 00 
  522f0d:	48 85 c0             	test   %rax,%rax
  522f10:	0f 84 87 00 00 00    	je     522f9d <<gpui_gpu::renderer::RendererState>::render+0x1c1d>
  522f16:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  522f1b:	48 8b 49 20          	mov    0x20(%rcx),%rcx
  522f1f:	48 c1 e0 03          	shl    $0x3,%rax
  522f23:	31 ff                	xor    %edi,%edi
  522f25:	eb 1c                	jmp    522f43 <<gpui_gpu::renderer::RendererState>::render+0x1bc3>
  522f27:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  522f2c:	01 f2                	add    %esi,%edx
  522f2e:	89 14 f9             	mov    %edx,(%rcx,%rdi,8)
  522f31:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
  522f36:	89 54 f9 04          	mov    %edx,0x4(%rcx,%rdi,8)
  522f3a:	48 ff c7             	inc    %rdi
  522f3d:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  522f41:	74 4e                	je     522f91 <<gpui_gpu::renderer::RendererState>::render+0x1c11>
  522f43:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  522f48:	48 8b 72 58          	mov    0x58(%rdx),%rsi
  522f4c:	48 39 f7             	cmp    %rsi,%rdi
  522f4f:	0f 83 ec 0a 00 00    	jae    523a41 <<gpui_gpu::renderer::RendererState>::render+0x26c1>
  522f55:	8b 74 f9 04          	mov    0x4(%rcx,%rdi,8),%esi
  522f59:	83 fe 01             	cmp    $0x1,%esi
  522f5c:	75 c9                	jne    522f27 <<gpui_gpu::renderer::RendererState>::render+0x1ba7>
  522f5e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  522f63:	4c 8b 42 50          	mov    0x50(%rdx),%r8
  522f67:	ba 00 00 00 80       	mov    $0x80000000,%edx
  522f6c:	41 83 3c b8 00       	cmpl   $0x0,(%r8,%rdi,4)
  522f71:	75 c3                	jne    522f36 <<gpui_gpu::renderer::RendererState>::render+0x1bb6>
  522f73:	eb b2                	jmp    522f27 <<gpui_gpu::renderer::RendererState>::render+0x1ba7>
  522f75:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  522f7a:	c7 07 03 00 00 00    	movl   $0x3,(%rdi)
  522f80:	0f 28 84 24 60 04 00 	movaps 0x460(%rsp),%xmm0
  522f87:	00 
  522f88:	0f 11 47 04          	movups %xmm0,0x4(%rdi)
  522f8c:	e9 00 e5 ff ff       	jmp    521491 <<gpui_gpu::renderer::RendererState>::render+0x111>
  522f91:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  522f96:	89 c0                	mov    %eax,%eax
  522f98:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  522f9d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  522fa2:	48 8d 78 30          	lea    0x30(%rax),%rdi
  522fa6:	48 c7 40 40 00 00 00 	movq   $0x0,0x40(%rax)
  522fad:	00 
  522fae:	48 89 7c 24 60       	mov    %rdi,0x60(%rsp)
  522fb3:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
  522fb8:	31 d2                	xor    %edx,%edx
  522fba:	e8 61 2f 00 00       	call   525f20 <<alloc::vec::Vec<u32>>::resize>
  522fbf:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  522fc4:	48 8b 40 10          	mov    0x10(%rax),%rax
  522fc8:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  522fcd:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  522fd4:	00 
  522fd5:	48 89 84 24 50 03 00 	mov    %rax,0x350(%rsp)
  522fdc:	00 
  522fdd:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
  522fe4:	00 
  522fe5:	48 8b 82 80 00 00 00 	mov    0x80(%rdx),%rax
  522fec:	48 8b 8a 98 00 00 00 	mov    0x98(%rdx),%rcx
  522ff3:	48 03 8a b0 00 00 00 	add    0xb0(%rdx),%rcx
  522ffa:	48 89 94 24 08 03 00 	mov    %rdx,0x308(%rsp)
  523001:	00 
  523002:	48 c7 84 24 10 03 00 	movq   $0x0,0x310(%rsp)
  523009:	00 00 00 00 00 
  52300e:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
  523015:	00 
  523016:	48 89 8c 24 20 03 00 	mov    %rcx,0x320(%rsp)
  52301d:	00 
  52301e:	8b 44 24 28          	mov    0x28(%rsp),%eax
  523022:	89 84 24 28 03 00 00 	mov    %eax,0x328(%rsp)
  523029:	eb 17                	jmp    523042 <<gpui_gpu::renderer::RendererState>::render+0x1cc2>
  52302b:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  523030:	48 8d 41 fb          	lea    -0x5(%rcx),%rax
  523034:	80 7c 24 28 00       	cmpb   $0x0,0x28(%rsp)
  523039:	48 0f 45 c8          	cmovne %rax,%rcx
  52303d:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  523042:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  523049:	00 
  52304a:	48 8d b4 24 08 03 00 	lea    0x308(%rsp),%rsi
  523051:	00 
  523052:	ff 15 d0 6a da 00    	call   *0xda6ad0(%rip)        # 12c9b28 <_GLOBAL_OFFSET_TABLE_+0x5ce8>
  523058:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
  52305f:	00 
  523060:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  523065:	48 85 c0             	test   %rax,%rax
  523068:	0f 84 54 02 00 00    	je     5232c2 <<gpui_gpu::renderer::RendererState>::render+0x1f42>
  52306e:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
  523075:	00 
  523076:	48 8b 94 24 28 01 00 	mov    0x128(%rsp),%rdx
  52307d:	00 
  52307e:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  523083:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  523088:	0f b6 b0 41 03 00 00 	movzbl 0x341(%rax),%esi
  52308f:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  523094:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
  52309b:	00 
  52309c:	48 89 8c 24 b8 00 00 	mov    %rcx,0xb8(%rsp)
  5230a3:	00 
  5230a4:	48 89 8c 24 c8 01 00 	mov    %rcx,0x1c8(%rsp)
  5230ab:	00 
  5230ac:	48 89 94 24 d0 01 00 	mov    %rdx,0x1d0(%rsp)
  5230b3:	00 
  5230b4:	48 8d 84 24 30 01 00 	lea    0x130(%rsp),%rax
  5230bb:	00 
  5230bc:	0f 10 00             	movups (%rax),%xmm0
  5230bf:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  5230c3:	f3 0f 6f 50 20       	movdqu 0x20(%rax),%xmm2
  5230c8:	48 8d 84 24 18 02 00 	lea    0x218(%rsp),%rax
  5230cf:	00 
  5230d0:	f3 0f 7f 50 e0       	movdqu %xmm2,-0x20(%rax)
  5230d5:	0f 11 48 d0          	movups %xmm1,-0x30(%rax)
  5230d9:	0f 11 40 c0          	movups %xmm0,-0x40(%rax)
  5230dd:	48 8d 8c 24 60 01 00 	lea    0x160(%rsp),%rcx
  5230e4:	00 
  5230e5:	0f 10 01             	movups (%rcx),%xmm0
  5230e8:	48 8d 94 24 08 02 00 	lea    0x208(%rsp),%rdx
  5230ef:	00 
  5230f0:	0f 11 02             	movups %xmm0,(%rdx)
  5230f3:	66 0f 10 41 10       	movupd 0x10(%rcx),%xmm0
  5230f8:	66 0f 11 00          	movupd %xmm0,(%rax)
  5230fc:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
  523103:	00 
  523104:	e8 c7 1c 00 00       	call   524dd0 <gpui_gpu::renderer::compact_group>
  523109:	88 44 24 28          	mov    %al,0x28(%rsp)
  52310d:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  523112:	48 85 c0             	test   %rax,%rax
  523115:	0f 84 10 ff ff ff    	je     52302b <<gpui_gpu::renderer::RendererState>::render+0x1cab>
  52311b:	48 89 c1             	mov    %rax,%rcx
  52311e:	48 c1 e1 02          	shl    $0x2,%rcx
  523122:	0f b6 44 24 28       	movzbl 0x28(%rsp),%eax
  523127:	8d 14 85 00 00 00 00 	lea    0x0(,%rax,4),%edx
  52312e:	48 83 ca fa          	or     $0xfffffffffffffffa,%rdx
  523132:	31 f6                	xor    %esi,%esi
  523134:	84 c0                	test   %al,%al
  523136:	40 0f 94 c6          	sete   %sil
  52313a:	c1 e6 1f             	shl    $0x1f,%esi
  52313d:	89 b4 24 90 00 00 00 	mov    %esi,0x90(%rsp)
  523144:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
  523149:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  52314e:	01 d0                	add    %edx,%eax
  523150:	89 44 24 40          	mov    %eax,0x40(%rsp)
  523154:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  523159:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  523160:	00 
  523161:	8b 54 08 fc          	mov    -0x4(%rax,%rcx,1),%edx
  523165:	48 8d bc 24 80 03 00 	lea    0x380(%rsp),%rdi
  52316c:	00 
  52316d:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  523172:	e8 b9 c6 ff ff       	call   51f830 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  523177:	48 ff 8c 24 50 03 00 	decq   0x350(%rsp)
  52317e:	00 
  52317f:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  523184:	48 01 44 24 20       	add    %rax,0x20(%rsp)
  523189:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
  523190:	0b 44 24 40          	or     0x40(%rsp),%eax
  523194:	89 84 24 a0 01 00 00 	mov    %eax,0x1a0(%rsp)
  52319b:	48 8d 84 24 30 01 00 	lea    0x130(%rsp),%rax
  5231a2:	00 
  5231a3:	0f 10 00             	movups (%rax),%xmm0
  5231a6:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  5231aa:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  5231ae:	48 8d 84 24 08 02 00 	lea    0x208(%rsp),%rax
  5231b5:	00 
  5231b6:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  5231ba:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  5231be:	0f 11 00             	movups %xmm0,(%rax)
  5231c1:	48 8d 8c 24 60 01 00 	lea    0x160(%rsp),%rcx
  5231c8:	00 
  5231c9:	0f 10 01             	movups (%rcx),%xmm0
  5231cc:	48 8d 84 24 18 02 00 	lea    0x218(%rsp),%rax
  5231d3:	00 
  5231d4:	0f 11 40 20          	movups %xmm0,0x20(%rax)
  5231d8:	0f 10 41 10          	movups 0x10(%rcx),%xmm0
  5231dc:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  5231e0:	48 8d 8c 24 b8 03 00 	lea    0x3b8(%rsp),%rcx
  5231e7:	00 
  5231e8:	0f 10 01             	movups (%rcx),%xmm0
  5231eb:	0f 11 40 e0          	movups %xmm0,-0x20(%rax)
  5231ef:	0f 10 41 10          	movups 0x10(%rcx),%xmm0
  5231f3:	0f 11 40 30          	movups %xmm0,0x30(%rax)
  5231f7:	48 8b 84 24 b0 03 00 	mov    0x3b0(%rsp),%rax
  5231fe:	00 
  5231ff:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
  523206:	00 
  523207:	66 0f 10 84 24 80 03 	movupd 0x380(%rsp),%xmm0
  52320e:	00 00 
  523210:	0f 10 8c 24 90 03 00 	movups 0x390(%rsp),%xmm1
  523217:	00 
  523218:	f3 0f 6f 94 24 a0 03 	movdqu 0x3a0(%rsp),%xmm2
  52321f:	00 00 
  523221:	66 0f 7f 94 24 e0 01 	movdqa %xmm2,0x1e0(%rsp)
  523228:	00 00 
  52322a:	0f 29 8c 24 d0 01 00 	movaps %xmm1,0x1d0(%rsp)
  523231:	00 
  523232:	66 0f 29 84 24 c0 01 	movapd %xmm0,0x1c0(%rsp)
  523239:	00 00 
  52323b:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  523242:	00 
  523243:	48 89 84 24 d0 02 00 	mov    %rax,0x2d0(%rsp)
  52324a:	00 
  52324b:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  523250:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
  523257:	00 
  523258:	48 8b 84 24 f0 03 00 	mov    0x3f0(%rsp),%rax
  52325f:	00 
  523260:	48 89 84 24 e0 02 00 	mov    %rax,0x2e0(%rsp)
  523267:	00 
  523268:	48 8d 84 24 50 03 00 	lea    0x350(%rsp),%rax
  52326f:	00 
  523270:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
  523277:	00 
  523278:	48 8d 84 24 a0 01 00 	lea    0x1a0(%rsp),%rax
  52327f:	00 
  523280:	48 89 84 24 f0 02 00 	mov    %rax,0x2f0(%rsp)
  523287:	00 
  523288:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
  52328f:	00 
  523290:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  523295:	48 8d 94 24 d0 02 00 	lea    0x2d0(%rsp),%rdx
  52329c:	00 
  52329d:	e8 1e c2 ff ff       	call   51f4c0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#6}>>
  5232a2:	8b 44 24 40          	mov    0x40(%rsp),%eax
  5232a6:	03 44 24 18          	add    0x18(%rsp),%eax
  5232aa:	89 44 24 40          	mov    %eax,0x40(%rsp)
  5232ae:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  5232b3:	48 83 c1 fc          	add    $0xfffffffffffffffc,%rcx
  5232b7:	0f 85 97 fe ff ff    	jne    523154 <<gpui_gpu::renderer::RendererState>::render+0x1dd4>
  5232bd:	e9 69 fd ff ff       	jmp    52302b <<gpui_gpu::renderer::RendererState>::render+0x1cab>
  5232c2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  5232c7:	48 8b 78 28          	mov    0x28(%rax),%rdi
  5232cb:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
  5232d2:	00 00 00 00 00 
  5232d7:	48 85 ff             	test   %rdi,%rdi
  5232da:	0f 84 c8 00 00 00    	je     5233a8 <<gpui_gpu::renderer::RendererState>::render+0x2028>
  5232e0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  5232e5:	4c 8b 40 20          	mov    0x20(%rax),%r8
  5232e9:	48 c1 e7 03          	shl    $0x3,%rdi
  5232ed:	83 7c 24 68 00       	cmpl   $0x0,0x68(%rsp)
  5232f2:	0f 84 e9 06 00 00    	je     5239e1 <<gpui_gpu::renderer::RendererState>::render+0x2661>
  5232f8:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  5232ff:	00 00 
  523301:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  523308:	00 00 
  52330a:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  523311:	00 00 
  523313:	45 31 c9             	xor    %r9d,%r9d
  523316:	31 c9                	xor    %ecx,%ecx
  523318:	eb 23                	jmp    52333d <<gpui_gpu::renderer::RendererState>::render+0x1fbd>
  52331a:	48 ff 44 24 40       	incq   0x40(%rsp)
  52331f:	49 ff c1             	inc    %r9
  523322:	4c 3b 4c 24 68       	cmp    0x68(%rsp),%r9
  523327:	b8 00 00 00 00       	mov    $0x0,%eax
  52332c:	4c 0f 44 c8          	cmove  %rax,%r9
  523330:	48 ff c1             	inc    %rcx
  523333:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  523337:	0f 84 86 00 00 00    	je     5233c3 <<gpui_gpu::renderer::RendererState>::render+0x2043>
  52333d:	45 8b 54 c8 04       	mov    0x4(%r8,%rcx,8),%r10d
  523342:	44 89 d0             	mov    %r10d,%eax
  523345:	f7 d8                	neg    %eax
  523347:	70 d1                	jo     52331a <<gpui_gpu::renderer::RendererState>::render+0x1f9a>
  523349:	45 2b 14 c8          	sub    (%r8,%rcx,8),%r10d
  52334d:	74 d0                	je     52331f <<gpui_gpu::renderer::RendererState>::render+0x1f9f>
  52334f:	48 89 c8             	mov    %rcx,%rax
  523352:	48 c1 e8 20          	shr    $0x20,%rax
  523356:	74 0f                	je     523367 <<gpui_gpu::renderer::RendererState>::render+0x1fe7>
  523358:	48 89 c8             	mov    %rcx,%rax
  52335b:	31 d2                	xor    %edx,%edx
  52335d:	48 f7 74 24 68       	divq   0x68(%rsp)
  523362:	4c 89 ca             	mov    %r9,%rdx
  523365:	eb 08                	jmp    52336f <<gpui_gpu::renderer::RendererState>::render+0x1fef>
  523367:	89 c8                	mov    %ecx,%eax
  523369:	31 d2                	xor    %edx,%edx
  52336b:	f7 74 24 68          	divl   0x68(%rsp)
  52336f:	c1 e2 04             	shl    $0x4,%edx
  523372:	c1 e0 04             	shl    $0x4,%eax
  523375:	44 8d 5a 10          	lea    0x10(%rdx),%r11d
  523379:	45 39 f3             	cmp    %r14d,%r11d
  52337c:	45 0f 43 de          	cmovae %r14d,%r11d
  523380:	8d 70 10             	lea    0x10(%rax),%esi
  523383:	39 ee                	cmp    %ebp,%esi
  523385:	0f 43 f5             	cmovae %ebp,%esi
  523388:	41 29 d3             	sub    %edx,%r11d
  52338b:	29 c6                	sub    %eax,%esi
  52338d:	41 0f af f3          	imul   %r11d,%esi
  523391:	48 c1 e6 04          	shl    $0x4,%rsi
  523395:	48 01 74 24 10       	add    %rsi,0x10(%rsp)
  52339a:	4c 0f af d6          	imul   %rsi,%r10
  52339e:	4c 01 54 24 18       	add    %r10,0x18(%rsp)
  5233a3:	e9 77 ff ff ff       	jmp    52331f <<gpui_gpu::renderer::RendererState>::render+0x1f9f>
  5233a8:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  5233af:	00 00 
  5233b1:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  5233b8:	00 00 
  5233ba:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  5233c1:	00 00 
  5233c3:	41 f6 c7 01          	test   $0x1,%r15b
  5233c7:	74 53                	je     52341c <<gpui_gpu::renderer::RendererState>::render+0x209c>
  5233c9:	66 0f 6e 84 24 4c 03 	movd   0x34c(%rsp),%xmm0
  5233d0:	00 00 
  5233d2:	66 0f 7e c0          	movd   %xmm0,%eax
  5233d6:	85 c0                	test   %eax,%eax
  5233d8:	0f 99 c1             	setns  %cl
  5233db:	89 c2                	mov    %eax,%edx
  5233dd:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
  5233e3:	81 c2 00 00 80 ff    	add    $0xff800000,%edx
  5233e9:	81 fa 00 00 00 7f    	cmp    $0x7f000000,%edx
  5233ef:	0f 92 c2             	setb   %dl
  5233f2:	20 ca                	and    %cl,%dl
  5233f4:	ff c8                	dec    %eax
  5233f6:	3d ff ff 7f 00       	cmp    $0x7fffff,%eax
  5233fb:	0f 92 c0             	setb   %al
  5233fe:	08 d0                	or     %dl,%al
  523400:	b8 02 00 00 00       	mov    $0x2,%eax
  523405:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  52340c:	00 
  52340d:	66 0f 7e 84 24 14 01 	movd   %xmm0,0x114(%rsp)
  523414:	00 00 
  523416:	0f 84 bb 05 00 00    	je     5239d7 <<gpui_gpu::renderer::RendererState>::render+0x2657>
  52341c:	4c 8b bc 24 98 01 00 	mov    0x198(%rsp),%r15
  523423:	00 
  523424:	49 8d 47 18          	lea    0x18(%r15),%rax
  523428:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  52342d:	48 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%rcx
  523434:	00 
  523435:	48 83 c1 18          	add    $0x18,%rcx
  523439:	41 83 e5 01          	and    $0x1,%r13d
  52343d:	48 8b 94 24 b0 00 00 	mov    0xb0(%rsp),%rdx
  523444:	00 
  523445:	42 8d 04 2a          	lea    (%rdx,%r13,1),%eax
  523449:	41 83 fc 28          	cmp    $0x28,%r12d
  52344d:	42 8d 54 2a 04       	lea    0x4(%rdx,%r13,1),%edx
  523452:	0f 45 d0             	cmovne %eax,%edx
  523455:	8d 72 08             	lea    0x8(%rdx),%esi
  523458:	48 8b 84 24 70 03 00 	mov    0x370(%rsp),%rax
  52345f:	00 
  523460:	48 3b 84 24 78 03 00 	cmp    0x378(%rsp),%rax
  523467:	00 
  523468:	0f 44 f2             	cmove  %edx,%esi
  52346b:	0f 10 01             	movups (%rcx),%xmm0
  52346e:	0f 11 84 24 e0 02 00 	movups %xmm0,0x2e0(%rsp)
  523475:	00 
  523476:	44 89 b4 24 d0 02 00 	mov    %r14d,0x2d0(%rsp)
  52347d:	00 
  52347e:	89 ac 24 d4 02 00 00 	mov    %ebp,0x2d4(%rsp)
  523485:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  52348a:	89 84 24 d8 02 00 00 	mov    %eax,0x2d8(%rsp)
  523491:	89 b4 24 dc 02 00 00 	mov    %esi,0x2dc(%rsp)
  523498:	f3 0f 10 84 24 14 01 	movss  0x114(%rsp),%xmm0
  52349f:	00 00 
  5234a1:	f3 0f 11 84 24 f0 02 	movss  %xmm0,0x2f0(%rsp)
  5234a8:	00 00 
  5234aa:	48 c7 84 24 f4 02 00 	movq   $0x0,0x2f4(%rsp)
  5234b1:	00 00 00 00 00 
  5234b6:	c7 84 24 fc 02 00 00 	movl   $0x0,0x2fc(%rsp)
  5234bd:	00 00 00 00 
  5234c1:	48 8b 6c 24 08       	mov    0x8(%rsp),%rbp
  5234c6:	48 8d b5 30 02 00 00 	lea    0x230(%rbp),%rsi
  5234cd:	45 31 ed             	xor    %r13d,%r13d
  5234d0:	48 8d 8c 24 d0 02 00 	lea    0x2d0(%rsp),%rcx
  5234d7:	00 
  5234d8:	41 b8 30 00 00 00    	mov    $0x30,%r8d
  5234de:	4c 8b a4 24 00 01 00 	mov    0x100(%rsp),%r12
  5234e5:	00 
  5234e6:	4c 89 e7             	mov    %r12,%rdi
  5234e9:	48 89 74 24 68       	mov    %rsi,0x68(%rsp)
  5234ee:	31 d2                	xor    %edx,%edx
  5234f0:	ff 15 a2 61 da 00    	call   *0xda61a2(%rip)        # 12c9698 <_GLOBAL_OFFSET_TABLE_+0x5858>
  5234f6:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
  5234fa:	4c 8b 45 10          	mov    0x10(%rbp),%r8
  5234fe:	49 c1 e0 04          	shl    $0x4,%r8
  523502:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
  523509:	00 
  52350a:	4c 89 fe             	mov    %r15,%rsi
  52350d:	4c 89 e2             	mov    %r12,%rdx
  523510:	e8 1b c5 ff ff       	call   51fa30 <<gpui_gpu::renderer::Buffer>::write>
  523515:	48 8d bd 80 02 00 00 	lea    0x280(%rbp),%rdi
  52351c:	48 8b 4d 20          	mov    0x20(%rbp),%rcx
  523520:	4c 8b 45 28          	mov    0x28(%rbp),%r8
  523524:	49 c1 e0 03          	shl    $0x3,%r8
  523528:	48 89 bc 24 b0 00 00 	mov    %rdi,0xb0(%rsp)
  52352f:	00 
  523530:	4c 89 fe             	mov    %r15,%rsi
  523533:	4c 89 e2             	mov    %r12,%rdx
  523536:	e8 f5 c4 ff ff       	call   51fa30 <<gpui_gpu::renderer::Buffer>::write>
  52353b:	48 8d bd a8 02 00 00 	lea    0x2a8(%rbp),%rdi
  523542:	48 8b 4d 38          	mov    0x38(%rbp),%rcx
  523546:	4c 8b 45 40          	mov    0x40(%rbp),%r8
  52354a:	49 c1 e0 02          	shl    $0x2,%r8
  52354e:	48 89 bc 24 a8 00 00 	mov    %rdi,0xa8(%rsp)
  523555:	00 
  523556:	4c 89 fe             	mov    %r15,%rsi
  523559:	4c 89 e2             	mov    %r12,%rdx
  52355c:	e8 cf c4 ff ff       	call   51fa30 <<gpui_gpu::renderer::Buffer>::write>
  523561:	48 8d bd d0 02 00 00 	lea    0x2d0(%rbp),%rdi
  523568:	48 8b 4d 68          	mov    0x68(%rbp),%rcx
  52356c:	4c 8b 45 70          	mov    0x70(%rbp),%r8
  523570:	49 c1 e0 05          	shl    $0x5,%r8
  523574:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
  523579:	4c 89 fe             	mov    %r15,%rsi
  52357c:	4c 89 e2             	mov    %r12,%rdx
  52357f:	e8 ac c4 ff ff       	call   51fa30 <<gpui_gpu::renderer::Buffer>::write>
  523584:	48 83 bd 28 03 00 00 	cmpq   $0x0,0x328(%rbp)
  52358b:	00 
  52358c:	75 15                	jne    5235a3 <<gpui_gpu::renderer::RendererState>::render+0x2223>
  52358e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  523593:	4c 8b 68 10          	mov    0x10(%rax),%r13
  523597:	49 83 fd 01          	cmp    $0x1,%r13
  52359b:	49 83 d5 00          	adc    $0x0,%r13
  52359f:	49 c1 e5 04          	shl    $0x4,%r13
  5235a3:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  5235a8:	48 8b 4e 28          	mov    0x28(%rsi),%rcx
  5235ac:	48 8b 46 40          	mov    0x40(%rsi),%rax
  5235b0:	48 83 f9 01          	cmp    $0x1,%rcx
  5235b4:	48 83 d1 00          	adc    $0x0,%rcx
  5235b8:	48 c1 e1 03          	shl    $0x3,%rcx
  5235bc:	48 83 f8 01          	cmp    $0x1,%rax
  5235c0:	48 83 d0 00          	adc    $0x0,%rax
  5235c4:	48 c1 e0 02          	shl    $0x2,%rax
  5235c8:	48 8b 56 70          	mov    0x70(%rsi),%rdx
  5235cc:	48 83 fa 01          	cmp    $0x1,%rdx
  5235d0:	48 83 d2 00          	adc    $0x0,%rdx
  5235d4:	48 81 c6 c8 00 00 00 	add    $0xc8,%rsi
  5235db:	48 c1 e2 05          	shl    $0x5,%rdx
  5235df:	48 c7 84 24 c0 01 00 	movq   $0x0,0x1c0(%rsp)
  5235e6:	00 00 00 00 00 
  5235eb:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
  5235f0:	48 89 bc 24 c8 01 00 	mov    %rdi,0x1c8(%rsp)
  5235f7:	00 
  5235f8:	48 c7 84 24 e8 01 00 	movq   $0x0,0x1e8(%rsp)
  5235ff:	00 00 00 00 00 
  523604:	0f 57 c0             	xorps  %xmm0,%xmm0
  523607:	0f 11 84 24 d0 01 00 	movups %xmm0,0x1d0(%rsp)
  52360e:	00 
  52360f:	c7 84 24 e0 01 00 00 	movl   $0x0,0x1e0(%rsp)
  523616:	00 00 00 00 
  52361a:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
  523621:	00 
  523622:	48 89 bc 24 f0 01 00 	mov    %rdi,0x1f0(%rsp)
  523629:	00 
  52362a:	48 c7 84 24 f8 01 00 	movq   $0x0,0x1f8(%rsp)
  523631:	00 00 00 00 00 
  523636:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
  52363d:	00 
  52363e:	c7 84 24 08 02 00 00 	movl   $0x1,0x208(%rsp)
  523645:	01 00 00 00 
  523649:	48 c7 84 24 10 02 00 	movq   $0x0,0x210(%rsp)
  523650:	00 00 00 00 00 
  523655:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
  52365c:	00 
  52365d:	48 89 bc 24 18 02 00 	mov    %rdi,0x218(%rsp)
  523664:	00 
  523665:	48 c7 84 24 20 02 00 	movq   $0x0,0x220(%rsp)
  52366c:	00 00 00 00 00 
  523671:	48 89 8c 24 28 02 00 	mov    %rcx,0x228(%rsp)
  523678:	00 
  523679:	c7 84 24 30 02 00 00 	movl   $0x2,0x230(%rsp)
  523680:	02 00 00 00 
  523684:	48 c7 84 24 38 02 00 	movq   $0x0,0x238(%rsp)
  52368b:	00 00 00 00 00 
  523690:	48 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%rcx
  523697:	00 
  523698:	48 89 8c 24 40 02 00 	mov    %rcx,0x240(%rsp)
  52369f:	00 
  5236a0:	48 c7 84 24 48 02 00 	movq   $0x0,0x248(%rsp)
  5236a7:	00 00 00 00 00 
  5236ac:	48 89 84 24 50 02 00 	mov    %rax,0x250(%rsp)
  5236b3:	00 
  5236b4:	c7 84 24 58 02 00 00 	movl   $0x3,0x258(%rsp)
  5236bb:	03 00 00 00 
  5236bf:	48 c7 84 24 60 02 00 	movq   $0x4,0x260(%rsp)
  5236c6:	00 04 00 00 00 
  5236cb:	48 89 b4 24 68 02 00 	mov    %rsi,0x268(%rsp)
  5236d2:	00 
  5236d3:	c7 84 24 80 02 00 00 	movl   $0x4,0x280(%rsp)
  5236da:	04 00 00 00 
  5236de:	48 c7 84 24 88 02 00 	movq   $0x0,0x288(%rsp)
  5236e5:	00 00 00 00 00 
  5236ea:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  5236ef:	48 89 84 24 90 02 00 	mov    %rax,0x290(%rsp)
  5236f6:	00 
  5236f7:	48 c7 84 24 98 02 00 	movq   $0x0,0x298(%rsp)
  5236fe:	00 00 00 00 00 
  523703:	48 89 94 24 a0 02 00 	mov    %rdx,0x2a0(%rsp)
  52370a:	00 
  52370b:	c7 84 24 a8 02 00 00 	movl   $0x5,0x2a8(%rsp)
  523712:	05 00 00 00 
  523716:	48 8d 05 2f 09 67 00 	lea    0x67092f(%rip),%rax        # b9404c <tracing_core::dispatcher::NO_SUBSCRIBER+0x130>
  52371d:	48 89 84 24 20 03 00 	mov    %rax,0x320(%rsp)
  523724:	00 
  523725:	48 c7 84 24 28 03 00 	movq   $0xa,0x328(%rsp)
  52372c:	00 0a 00 00 00 
  523731:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  523736:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
  52373d:	00 
  52373e:	48 8d 84 24 c0 01 00 	lea    0x1c0(%rsp),%rax
  523745:	00 
  523746:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
  52374d:	00 
  52374e:	48 c7 84 24 18 03 00 	movq   $0x6,0x318(%rsp)
  523755:	00 06 00 00 00 
  52375a:	48 8d b4 24 08 03 00 	lea    0x308(%rsp),%rsi
  523761:	00 
  523762:	4c 8b bc 24 98 01 00 	mov    0x198(%rsp),%r15
  523769:	00 
  52376a:	4c 89 ff             	mov    %r15,%rdi
  52376d:	ff 15 75 6b da 00    	call   *0xda6b75(%rip)        # 12ca2e8 <_GLOBAL_OFFSET_TABLE_+0x64a8>
  523773:	49 89 c4             	mov    %rax,%r12
  523776:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
  52377d:	00 
  52377e:	48 8d 94 24 a0 01 00 	lea    0x1a0(%rsp),%rdx
  523785:	00 
  523786:	4c 89 ff             	mov    %r15,%rdi
  523789:	48 8b b4 24 e8 03 00 	mov    0x3e8(%rsp),%rsi
  523790:	00 
  523791:	e8 5a cc ff ff       	call   5203f0 <<gpui_gpu::renderer::GpuContext>::submit>
  523796:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  52379b:	41 8d 8e 00 00 00 80 	lea    -0x80000000(%r14),%ecx
  5237a2:	48 8b 84 24 70 03 00 	mov    0x370(%rsp),%rax
  5237a9:	00 
  5237aa:	48 3b 84 24 78 03 00 	cmp    0x378(%rsp),%rax
  5237b1:	00 
  5237b2:	41 0f 44 ce          	cmove  %r14d,%ecx
  5237b6:	48 01 8c 24 08 01 00 	add    %rcx,0x108(%rsp)
  5237bd:	00 
  5237be:	48 8b 03             	mov    (%rbx),%rax
  5237c1:	48 85 c0             	test   %rax,%rax
  5237c4:	74 0f                	je     5237d5 <<gpui_gpu::renderer::RendererState>::render+0x2455>
  5237c6:	f0 48 ff 08          	lock decq (%rax)
  5237ca:	75 09                	jne    5237d5 <<gpui_gpu::renderer::RendererState>::render+0x2455>
  5237cc:	48 89 df             	mov    %rbx,%rdi
  5237cf:	ff 15 fb 3a da 00    	call   *0xda3afb(%rip)        # 12c72d0 <_GLOBAL_OFFSET_TABLE_+0x3490>
  5237d5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  5237da:	4c 89 a0 30 03 00 00 	mov    %r12,0x330(%rax)
  5237e1:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
  5237e8:	00 
  5237e9:	48 89 88 38 03 00 00 	mov    %rcx,0x338(%rax)
  5237f0:	4c 8b 40 10          	mov    0x10(%rax),%r8
  5237f4:	48 8b 70 28          	mov    0x28(%rax),%rsi
  5237f8:	48 8b 48 70          	mov    0x70(%rax),%rcx
  5237fc:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
  523803:	00 
  523804:	49 c1 e0 04          	shl    $0x4,%r8
  523808:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  52380d:	49 8d 3c 90          	lea    (%r8,%rdx,4),%rdi
  523811:	48 8d 34 f7          	lea    (%rdi,%rsi,8),%rsi
  523815:	48 89 cf             	mov    %rcx,%rdi
  523818:	48 c1 e7 05          	shl    $0x5,%rdi
  52381c:	48 8d 0c 37          	lea    (%rdi,%rsi,1),%rcx
  523820:	48 83 c1 30          	add    $0x30,%rcx
  523824:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
  52382b:	00 
  52382c:	48 8b b8 78 02 00 00 	mov    0x278(%rax),%rdi
  523833:	48 03 b8 50 02 00 00 	add    0x250(%rax),%rdi
  52383a:	48 03 b8 a0 02 00 00 	add    0x2a0(%rax),%rdi
  523841:	48 03 b8 c8 02 00 00 	add    0x2c8(%rax),%rdi
  523848:	48 03 b8 f0 02 00 00 	add    0x2f0(%rax),%rdi
  52384f:	48 8b b0 08 03 00 00 	mov    0x308(%rax),%rsi
  523856:	48 03 b0 10 03 00 00 	add    0x310(%rax),%rsi
  52385d:	44 8b 88 50 01 00 00 	mov    0x150(%rax),%r9d
  523864:	4d 0f af c9          	imul   %r9,%r9
  523868:	4c 8b 9c 24 d0 00 00 	mov    0xd0(%rsp),%r11
  52386f:	00 
  523870:	4c 89 d9             	mov    %r11,%rcx
  523873:	48 29 d1             	sub    %rdx,%rcx
  523876:	4c 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%r10
  52387d:	00 
  52387e:	4d 89 d7             	mov    %r10,%r15
  523881:	48 8b ac 24 38 03 00 	mov    0x338(%rsp),%rbp
  523888:	00 
  523889:	49 29 ef             	sub    %rbp,%r15
  52388c:	48 8b 98 60 01 00 00 	mov    0x160(%rax),%rbx
  523893:	48 ff c3             	inc    %rbx
  523896:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
  52389d:	4c 0f 45 f3          	cmovne %rbx,%r14
  5238a1:	48 8b 18             	mov    (%rax),%rbx
  5238a4:	48 c1 e3 04          	shl    $0x4,%rbx
  5238a8:	4c 8b 60 48          	mov    0x48(%rax),%r12
  5238ac:	4c 03 60 30          	add    0x30(%rax),%r12
  5238b0:	4c 8b 68 18          	mov    0x18(%rax),%r13
  5238b4:	4a 8d 1c eb          	lea    (%rbx,%r13,8),%rbx
  5238b8:	4a 8d 1c a3          	lea    (%rbx,%r12,4),%rbx
  5238bc:	4c 8b 60 60          	mov    0x60(%rax),%r12
  5238c0:	49 c1 e4 05          	shl    $0x5,%r12
  5238c4:	49 01 dc             	add    %rbx,%r12
  5238c7:	48 8b 98 38 01 00 00 	mov    0x138(%rax),%rbx
  5238ce:	4c 8b a8 30 01 00 00 	mov    0x130(%rax),%r13
  5238d5:	4c 89 b0 60 01 00 00 	mov    %r14,0x160(%rax)
  5238dc:	4c 89 90 68 01 00 00 	mov    %r10,0x168(%rax)
  5238e3:	4f 8d 34 1b          	lea    (%r11,%r11,1),%r14
  5238e7:	4c 89 b0 70 01 00 00 	mov    %r14,0x170(%rax)
  5238ee:	48 c7 80 78 01 00 00 	movq   $0x1,0x178(%rax)
  5238f5:	01 00 00 00 
  5238f9:	4c 89 90 80 01 00 00 	mov    %r10,0x180(%rax)
  523900:	48 89 90 88 01 00 00 	mov    %rdx,0x188(%rax)
  523907:	4c 89 98 90 01 00 00 	mov    %r11,0x190(%rax)
  52390e:	48 89 88 98 01 00 00 	mov    %rcx,0x198(%rax)
  523915:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  52391a:	48 89 88 a0 01 00 00 	mov    %rcx,0x1a0(%rax)
  523921:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  523926:	48 89 88 a8 01 00 00 	mov    %rcx,0x1a8(%rax)
  52392d:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  523932:	48 89 88 b0 01 00 00 	mov    %rcx,0x1b0(%rax)
  523939:	48 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%rcx
  523940:	00 
  523941:	48 89 88 b8 01 00 00 	mov    %rcx,0x1b8(%rax)
  523948:	4c 89 80 c0 01 00 00 	mov    %r8,0x1c0(%rax)
  52394f:	48 8b 94 24 30 03 00 	mov    0x330(%rsp),%rdx
  523956:	00 
  523957:	48 89 90 c8 01 00 00 	mov    %rdx,0x1c8(%rax)
  52395e:	48 89 a8 d0 01 00 00 	mov    %rbp,0x1d0(%rax)
  523965:	4c 89 b8 d8 01 00 00 	mov    %r15,0x1d8(%rax)
  52396c:	48 8b 8c 24 b0 02 00 	mov    0x2b0(%rsp),%rcx
  523973:	00 
  523974:	48 89 88 e0 01 00 00 	mov    %rcx,0x1e0(%rax)
  52397b:	48 89 b8 e8 01 00 00 	mov    %rdi,0x1e8(%rax)
  523982:	4c 89 88 f0 01 00 00 	mov    %r9,0x1f0(%rax)
  523989:	49 01 dd             	add    %rbx,%r13
  52398c:	48 89 98 f8 01 00 00 	mov    %rbx,0x1f8(%rax)
  523993:	4c 89 a8 00 02 00 00 	mov    %r13,0x200(%rax)
  52399a:	4c 89 a0 08 02 00 00 	mov    %r12,0x208(%rax)
  5239a1:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
  5239a8:	00 
  5239a9:	48 89 88 10 02 00 00 	mov    %rcx,0x210(%rax)
  5239b0:	48 89 b0 18 02 00 00 	mov    %rsi,0x218(%rax)
  5239b7:	c6 80 20 02 00 00 00 	movb   $0x0,0x220(%rax)
  5239be:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  5239c3:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  5239c8:	48 89 47 08          	mov    %rax,0x8(%rdi)
  5239cc:	c7 07 ff ff ff ff    	movl   $0xffffffff,(%rdi)
  5239d2:	e9 ba da ff ff       	jmp    521491 <<gpui_gpu::renderer::RendererState>::render+0x111>
  5239d7:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  5239dc:	e9 a2 da ff ff       	jmp    521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  5239e1:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  5239e8:	00 00 
  5239ea:	31 c0                	xor    %eax,%eax
  5239ec:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  5239f3:	00 00 
  5239f5:	eb 12                	jmp    523a09 <<gpui_gpu::renderer::RendererState>::render+0x2689>
  5239f7:	48 ff 44 24 40       	incq   0x40(%rsp)
  5239fc:	48 83 c0 08          	add    $0x8,%rax
  523a00:	48 39 c7             	cmp    %rax,%rdi
  523a03:	0f 84 b1 f9 ff ff    	je     5233ba <<gpui_gpu::renderer::RendererState>::render+0x203a>
  523a09:	41 8b 4c 00 04       	mov    0x4(%r8,%rax,1),%ecx
  523a0e:	89 ca                	mov    %ecx,%edx
  523a10:	f7 da                	neg    %edx
  523a12:	70 e3                	jo     5239f7 <<gpui_gpu::renderer::RendererState>::render+0x2677>
  523a14:	41 3b 0c 00          	cmp    (%r8,%rax,1),%ecx
  523a18:	74 e2                	je     5239fc <<gpui_gpu::renderer::RendererState>::render+0x267c>
  523a1a:	48 8d 3d af ce d5 00 	lea    0xd5ceaf(%rip),%rdi        # 12808d0 <anon.11c63428aaff144b0aa1b5cb745d0db3.29.llvm.9269992671348706103+0x10>
  523a21:	ff 15 11 15 da 00    	call   *0xda1511(%rip)        # 12c4f38 <_GLOBAL_OFFSET_TABLE_+0x10f8>
  523a27:	48 8d 3d f2 cc d5 00 	lea    0xd5ccf2(%rip),%rdi        # 1280720 <anon.255c8ba72969252177b3101bd34b486f.6.llvm.2677678285831016542+0x60>
  523a2e:	ff 15 1c 1e da 00    	call   *0xda1e1c(%rip)        # 12c5850 <_GLOBAL_OFFSET_TABLE_+0x1a10>
  523a34:	48 8d 15 fd cc d5 00 	lea    0xd5ccfd(%rip),%rdx        # 1280738 <anon.255c8ba72969252177b3101bd34b486f.6.llvm.2677678285831016542+0x78>
  523a3b:	ff 15 9f 64 da 00    	call   *0xda649f(%rip)        # 12c9ee0 <_GLOBAL_OFFSET_TABLE_+0x60a0>
  523a41:	48 8d 15 c0 cc d5 00 	lea    0xd5ccc0(%rip),%rdx        # 1280708 <anon.255c8ba72969252177b3101bd34b486f.6.llvm.2677678285831016542+0x48>
  523a48:	ff 15 92 64 da 00    	call   *0xda6492(%rip)        # 12c9ee0 <_GLOBAL_OFFSET_TABLE_+0x60a0>
  523a4e:	49 89 c6             	mov    %rax,%r14
  523a51:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  523a56:	4c 89 a0 30 03 00 00 	mov    %r12,0x330(%rax)
  523a5d:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
  523a64:	00 
  523a65:	48 89 88 38 03 00 00 	mov    %rcx,0x338(%rax)
  523a6c:	4c 89 f7             	mov    %r14,%rdi
  523a6f:	e8 cc 45 b6 ff       	call   88040 <_Unwind_Resume@plt>
  523a74:	49 89 c6             	mov    %rax,%r14
  523a77:	f0 49 ff 0c 24       	lock decq (%r12)
  523a7c:	75 20                	jne    523a9e <<gpui_gpu::renderer::RendererState>::render+0x271e>
  523a7e:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  523a85:	00 
  523a86:	ff 15 44 38 da 00    	call   *0xda3844(%rip)        # 12c72d0 <_GLOBAL_OFFSET_TABLE_+0x3490>
  523a8c:	eb 10                	jmp    523a9e <<gpui_gpu::renderer::RendererState>::render+0x271e>
  523a8e:	ff 15 74 6f da 00    	call   *0xda6f74(%rip)        # 12caa08 <_GLOBAL_OFFSET_TABLE_+0x6bc8>
  523a94:	49 89 c6             	mov    %rax,%r14
  523a97:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  523a9e:	4c 89 f7             	mov    %r14,%rdi
  523aa1:	e8 9a 45 b6 ff       	call   88040 <_Unwind_Resume@plt>
