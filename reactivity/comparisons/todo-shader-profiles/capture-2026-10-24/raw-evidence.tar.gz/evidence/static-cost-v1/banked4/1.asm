
/home/miles/gpui-ce3-compute-20261024/evidence/todo-shader-profiles/attempt2/builds/banked4/todo_comparison_mapped:     file format elf64-x86-64


Disassembly of section .text:

0000000000523ab0 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  523ab0:	55                   	push   %rbp
  523ab1:	41 57                	push   %r15
  523ab3:	41 56                	push   %r14
  523ab5:	41 55                	push   %r13
  523ab7:	41 54                	push   %r12
  523ab9:	53                   	push   %rbx
  523aba:	48 81 ec f8 02 00 00 	sub    $0x2f8,%rsp
  523ac1:	f3 0f 10 9a 88 00 00 	movss  0x88(%rdx),%xmm3
  523ac8:	00 
  523ac9:	f3 0f 10 05 97 1c 60 	movss  0x601c97(%rip),%xmm0        # b25768 <anon.9adf6b51329d0e8f0ba7a07edbf8a285.69.llvm.2988996700849332186+0x14>
  523ad0:	00 
  523ad1:	0f 28 cb             	movaps %xmm3,%xmm1
  523ad4:	f3 0f 5c c8          	subss  %xmm0,%xmm1
  523ad8:	f3 48 0f 2c c1       	cvttss2si %xmm1,%rax
  523add:	f3 4c 0f 2c d3       	cvttss2si %xmm3,%r10
  523ae2:	4d 89 d3             	mov    %r10,%r11
  523ae5:	49 c1 fb 3f          	sar    $0x3f,%r11
  523ae9:	49 21 c3             	and    %rax,%r11
  523aec:	4d 09 d3             	or     %r10,%r11
  523aef:	45 31 d2             	xor    %r10d,%r10d
  523af2:	0f 57 c9             	xorps  %xmm1,%xmm1
  523af5:	0f 2e d9             	ucomiss %xmm1,%xmm3
  523af8:	4d 0f 42 da          	cmovb  %r10,%r11
  523afc:	f3 0f 10 a2 90 00 00 	movss  0x90(%rdx),%xmm4
  523b03:	00 
  523b04:	f3 0f 10 15 60 1c 60 	movss  0x601c60(%rip),%xmm2        # b2576c <anon.9adf6b51329d0e8f0ba7a07edbf8a285.69.llvm.2988996700849332186+0x18>
  523b0b:	00 
  523b0c:	0f 2e da             	ucomiss %xmm2,%xmm3
  523b0f:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
  523b16:	4d 0f 47 de          	cmova  %r14,%r11
  523b1a:	0f 28 dc             	movaps %xmm4,%xmm3
  523b1d:	f3 0f 5c d8          	subss  %xmm0,%xmm3
  523b21:	f3 48 0f 2c c3       	cvttss2si %xmm3,%rax
  523b26:	f3 48 0f 2c dc       	cvttss2si %xmm4,%rbx
  523b2b:	49 89 df             	mov    %rbx,%r15
  523b2e:	49 c1 ff 3f          	sar    $0x3f,%r15
  523b32:	49 21 c7             	and    %rax,%r15
  523b35:	49 09 df             	or     %rbx,%r15
  523b38:	0f 2e e1             	ucomiss %xmm1,%xmm4
  523b3b:	4d 0f 42 fa          	cmovb  %r10,%r15
  523b3f:	0f 2e e2             	ucomiss %xmm2,%xmm4
  523b42:	4d 0f 47 fe          	cmova  %r14,%r15
  523b46:	f3 0f 10 9a 8c 00 00 	movss  0x8c(%rdx),%xmm3
  523b4d:	00 
  523b4e:	4b 8d 04 3b          	lea    (%r11,%r15,1),%rax
  523b52:	48 ff c8             	dec    %rax
  523b55:	48 c1 e8 04          	shr    $0x4,%rax
  523b59:	49 c1 eb 04          	shr    $0x4,%r11
  523b5d:	49 89 c5             	mov    %rax,%r13
  523b60:	4d 29 dd             	sub    %r11,%r13
  523b63:	49 ff c5             	inc    %r13
  523b66:	0f 28 e3             	movaps %xmm3,%xmm4
  523b69:	f3 0f 5c e0          	subss  %xmm0,%xmm4
  523b6d:	f3 4c 0f 2c e4       	cvttss2si %xmm4,%r12
  523b72:	f3 4c 0f 2c fb       	cvttss2si %xmm3,%r15
  523b77:	4c 89 fb             	mov    %r15,%rbx
  523b7a:	48 c1 fb 3f          	sar    $0x3f,%rbx
  523b7e:	4c 21 e3             	and    %r12,%rbx
  523b81:	4c 09 fb             	or     %r15,%rbx
  523b84:	0f 2e d9             	ucomiss %xmm1,%xmm3
  523b87:	49 0f 42 da          	cmovb  %r10,%rbx
  523b8b:	0f 2e da             	ucomiss %xmm2,%xmm3
  523b8e:	f3 0f 10 9a 94 00 00 	movss  0x94(%rdx),%xmm3
  523b95:	00 
  523b96:	49 0f 47 de          	cmova  %r14,%rbx
  523b9a:	0f 28 e3             	movaps %xmm3,%xmm4
  523b9d:	f3 0f 5c e0          	subss  %xmm0,%xmm4
  523ba1:	f3 48 0f 2c ec       	cvttss2si %xmm4,%rbp
  523ba6:	f3 4c 0f 2c fb       	cvttss2si %xmm3,%r15
  523bab:	4d 89 fc             	mov    %r15,%r12
  523bae:	49 c1 fc 3f          	sar    $0x3f,%r12
  523bb2:	49 21 ec             	and    %rbp,%r12
  523bb5:	4d 09 fc             	or     %r15,%r12
  523bb8:	0f 2e d9             	ucomiss %xmm1,%xmm3
  523bbb:	4d 0f 42 e2          	cmovb  %r10,%r12
  523bbf:	0f 2e da             	ucomiss %xmm2,%xmm3
  523bc2:	4d 0f 47 e6          	cmova  %r14,%r12
  523bc6:	4e 8d 34 23          	lea    (%rbx,%r12,1),%r14
  523bca:	49 ff ce             	dec    %r14
  523bcd:	49 c1 ee 04          	shr    $0x4,%r14
  523bd1:	48 c1 eb 04          	shr    $0x4,%rbx
  523bd5:	4d 89 f7             	mov    %r14,%r15
  523bd8:	49 29 df             	sub    %rbx,%r15
  523bdb:	49 ff c7             	inc    %r15
  523bde:	4d 0f af fd          	imul   %r13,%r15
  523be2:	4c 03 bc 24 48 03 00 	add    0x348(%rsp),%r15
  523be9:	00 
  523bea:	41 0f 92 c2          	setb   %r10b
  523bee:	49 81 ff 01 00 40 00 	cmp    $0x400001,%r15
  523bf5:	40 0f 93 c5          	setae  %bpl
  523bf9:	44 08 d5             	or     %r10b,%bpl
  523bfc:	41 ba 06 00 00 00    	mov    $0x6,%r10d
  523c02:	0f 85 83 0f 00 00    	jne    524b8b <<gpui_gpu::renderer::RendererState>::bin_draw+0x10db>
  523c08:	44 89 84 24 bc 00 00 	mov    %r8d,0xbc(%rsp)
  523c0f:	00 
  523c10:	4c 89 8c 24 a0 00 00 	mov    %r9,0xa0(%rsp)
  523c17:	00 
  523c18:	4c 89 bc 24 88 01 00 	mov    %r15,0x188(%rsp)
  523c1f:	00 
  523c20:	48 89 bc 24 90 01 00 	mov    %rdi,0x190(%rsp)
  523c27:	00 
  523c28:	49 39 de             	cmp    %rbx,%r14
  523c2b:	0f 82 40 0f 00 00    	jb     524b71 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  523c31:	4c 39 d8             	cmp    %r11,%rax
  523c34:	0f 82 37 0f 00 00    	jb     524b71 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  523c3a:	48 8b ac 24 30 03 00 	mov    0x330(%rsp),%rbp
  523c41:	00 
  523c42:	4c 8b 66 20          	mov    0x20(%rsi),%r12
  523c46:	48 89 f7             	mov    %rsi,%rdi
  523c49:	48 8b 76 28          	mov    0x28(%rsi),%rsi
  523c4d:	48 89 bc 24 c0 00 00 	mov    %rdi,0xc0(%rsp)
  523c54:	00 
  523c55:	80 bf 40 03 00 00 00 	cmpb   $0x0,0x340(%rdi)
  523c5c:	0f 84 cb 0d 00 00    	je     524a2d <<gpui_gpu::renderer::RendererState>::bin_draw+0xf7d>
  523c62:	80 3a 00             	cmpb   $0x0,(%rdx)
  523c65:	0f 85 08 0e 00 00    	jne    524a73 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfc3>
  523c6b:	f3 0f 10 82 a4 00 00 	movss  0xa4(%rdx),%xmm0
  523c72:	00 
  523c73:	0f 2e 05 22 1a 60 00 	ucomiss 0x601a22(%rip),%xmm0        # b2569c <anon.65fa6619250d5a71bfd5ef20e1dfbaf0.11.llvm.7726090819372637783+0x8>
  523c7a:	0f 85 f3 0d 00 00    	jne    524a73 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfc3>
  523c80:	0f 8a ed 0d 00 00    	jp     524a73 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfc3>
  523c86:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
  523c8d:	00 
  523c8e:	8b ba 98 00 00 00    	mov    0x98(%rdx),%edi
  523c94:	41 89 ff             	mov    %edi,%r15d
  523c97:	41 81 e7 00 00 80 7f 	and    $0x7f800000,%r15d
  523c9e:	41 ff cf             	dec    %r15d
  523ca1:	44 8b 8a 9c 00 00 00 	mov    0x9c(%rdx),%r9d
  523ca8:	45 89 cd             	mov    %r9d,%r13d
  523cab:	41 81 e5 00 00 80 7f 	and    $0x7f800000,%r13d
  523cb2:	41 ff cd             	dec    %r13d
  523cb5:	44 8b 82 a0 00 00 00 	mov    0xa0(%rdx),%r8d
  523cbc:	45 89 c2             	mov    %r8d,%r10d
  523cbf:	41 81 e2 00 00 80 7f 	and    $0x7f800000,%r10d
  523cc6:	41 ff ca             	dec    %r10d
  523cc9:	48 85 ed             	test   %rbp,%rbp
  523ccc:	0f 84 e4 0d 00 00    	je     524ab6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1006>
  523cd2:	41 81 fa ff ff 7f 7f 	cmp    $0x7f7fffff,%r10d
  523cd9:	0f 92 c0             	setb   %al
  523cdc:	45 85 c0             	test   %r8d,%r8d
  523cdf:	41 0f 99 c2          	setns  %r10b
  523ce3:	41 81 fd ff ff 7f 7f 	cmp    $0x7f7fffff,%r13d
  523cea:	41 0f 92 c0          	setb   %r8b
  523cee:	45 85 c9             	test   %r9d,%r9d
  523cf1:	41 0f 99 c5          	setns  %r13b
  523cf5:	41 81 ff ff ff 7f 7f 	cmp    $0x7f7fffff,%r15d
  523cfc:	41 0f 92 c7          	setb   %r15b
  523d00:	85 ff                	test   %edi,%edi
  523d02:	40 0f 99 c7          	setns  %dil
  523d06:	44 08 ff             	or     %r15b,%dil
  523d09:	40 80 ff 01          	cmp    $0x1,%dil
  523d0d:	0f 85 0d 0e 00 00    	jne    524b20 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1070>
  523d13:	45 08 c5             	or     %r8b,%r13b
  523d16:	0f 84 04 0e 00 00    	je     524b20 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1070>
  523d1c:	41 08 c2             	or     %al,%r10b
  523d1f:	0f 84 fb 0d 00 00    	je     524b20 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1070>
  523d25:	44 8b 94 24 40 03 00 	mov    0x340(%rsp),%r10d
  523d2c:	00 
  523d2d:	44 8b bc 24 38 03 00 	mov    0x338(%rsp),%r15d
  523d34:	00 
  523d35:	66 0f 6e d1          	movd   %ecx,%xmm2
  523d39:	48 c1 e9 20          	shr    $0x20,%rcx
  523d3d:	f3 0f 10 42 78       	movss  0x78(%rdx),%xmm0
  523d42:	f3 0f 10 9a 80 00 00 	movss  0x80(%rdx),%xmm3
  523d49:	00 
  523d4a:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  523d4e:	f3 0f 10 a2 84 00 00 	movss  0x84(%rdx),%xmm4
  523d55:	00 
  523d56:	f3 0f 10 4a 7c       	movss  0x7c(%rdx),%xmm1
  523d5b:	f3 0f 5a c9          	cvtss2sd %xmm1,%xmm1
  523d5f:	f3 0f 5a db          	cvtss2sd %xmm3,%xmm3
  523d63:	f3 0f 5a e4          	cvtss2sd %xmm4,%xmm4
  523d67:	f2 0f 58 d8          	addsd  %xmm0,%xmm3
  523d6b:	f2 0f 11 9c 24 a8 01 	movsd  %xmm3,0x1a8(%rsp)
  523d72:	00 00 
  523d74:	f2 0f 58 e1          	addsd  %xmm1,%xmm4
  523d78:	f2 0f 11 a4 24 a0 01 	movsd  %xmm4,0x1a0(%rsp)
  523d7f:	00 00 
  523d81:	f2 0f 10 62 48       	movsd  0x48(%rdx),%xmm4
  523d86:	f2 0f 10 6a 58       	movsd  0x58(%rdx),%xmm5
  523d8b:	f2 0f 10 72 68       	movsd  0x68(%rdx),%xmm6
  523d90:	f3 0f 10 5a 38       	movss  0x38(%rdx),%xmm3
  523d95:	f3 0f 5a fb          	cvtss2sd %xmm3,%xmm7
  523d99:	f3 0f 10 5a 40       	movss  0x40(%rdx),%xmm3
  523d9e:	f3 0f 5a db          	cvtss2sd %xmm3,%xmm3
  523da2:	44 0f 28 05 36 aa 5f 	movaps 0x5faa36(%rip),%xmm8        # b1e7e0 <anon.53de480418173883b8e15d81740454e2.346.llvm.622318203107919755+0x308>
  523da9:	00 
  523daa:	0f 29 bc 24 80 00 00 	movaps %xmm7,0x80(%rsp)
  523db1:	00 
  523db2:	41 0f 54 f8          	andps  %xmm8,%xmm7
  523db6:	0f 29 7c 24 70       	movaps %xmm7,0x70(%rsp)
  523dbb:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
  523dc0:	41 0f 54 d8          	andps  %xmm8,%xmm3
  523dc4:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
  523dc9:	f3 0f 5a d2          	cvtss2sd %xmm2,%xmm2
  523dcd:	f2 0f 11 54 24 08    	movsd  %xmm2,0x8(%rsp)
  523dd3:	0f 28 d4             	movaps %xmm4,%xmm2
  523dd6:	41 0f 54 d0          	andps  %xmm8,%xmm2
  523dda:	0f 29 94 24 50 02 00 	movaps %xmm2,0x250(%rsp)
  523de1:	00 
  523de2:	0f 28 d5             	movaps %xmm5,%xmm2
  523de5:	41 0f 54 d0          	andps  %xmm8,%xmm2
  523de9:	0f 29 94 24 30 02 00 	movaps %xmm2,0x230(%rsp)
  523df0:	00 
  523df1:	0f 28 d6             	movaps %xmm6,%xmm2
  523df4:	41 0f 54 d0          	andps  %xmm8,%xmm2
  523df8:	0f 29 94 24 20 01 00 	movaps %xmm2,0x120(%rsp)
  523dff:	00 
  523e00:	f3 0f 10 52 3c       	movss  0x3c(%rdx),%xmm2
  523e05:	0f 57 db             	xorps  %xmm3,%xmm3
  523e08:	f3 0f 5a da          	cvtss2sd %xmm2,%xmm3
  523e0c:	f3 0f 10 52 44       	movss  0x44(%rdx),%xmm2
  523e11:	0f 57 ff             	xorps  %xmm7,%xmm7
  523e14:	f3 0f 5a fa          	cvtss2sd %xmm2,%xmm7
  523e18:	0f 29 5c 24 40       	movaps %xmm3,0x40(%rsp)
  523e1d:	41 0f 54 d8          	andps  %xmm8,%xmm3
  523e21:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
  523e26:	66 0f 6e d1          	movd   %ecx,%xmm2
  523e2a:	f3 0f 5a d2          	cvtss2sd %xmm2,%xmm2
  523e2e:	f2 0f 11 14 24       	movsd  %xmm2,(%rsp)
  523e33:	0f 29 7c 24 10       	movaps %xmm7,0x10(%rsp)
  523e38:	41 0f 54 f8          	andps  %xmm8,%xmm7
  523e3c:	0f 29 7c 24 20       	movaps %xmm7,0x20(%rsp)
  523e41:	f2 0f 10 5a 50       	movsd  0x50(%rdx),%xmm3
  523e46:	0f 28 d3             	movaps %xmm3,%xmm2
  523e49:	41 0f 54 d0          	andps  %xmm8,%xmm2
  523e4d:	0f 29 94 24 d0 01 00 	movaps %xmm2,0x1d0(%rsp)
  523e54:	00 
  523e55:	f2 0f 10 7a 60       	movsd  0x60(%rdx),%xmm7
  523e5a:	0f 28 d7             	movaps %xmm7,%xmm2
  523e5d:	41 0f 54 d0          	andps  %xmm8,%xmm2
  523e61:	0f 29 94 24 b0 01 00 	movaps %xmm2,0x1b0(%rsp)
  523e68:	00 
  523e69:	f2 44 0f 10 4a 70    	movsd  0x70(%rdx),%xmm9
  523e6f:	41 0f 28 d1          	movaps %xmm9,%xmm2
  523e73:	41 0f 54 d0          	andps  %xmm8,%xmm2
  523e77:	0f 29 94 24 e0 00 00 	movaps %xmm2,0xe0(%rsp)
  523e7e:	00 
  523e7f:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  523e86:	00 
  523e87:	48 8b 48 58          	mov    0x58(%rax),%rcx
  523e8b:	48 89 8c 24 d8 00 00 	mov    %rcx,0xd8(%rsp)
  523e92:	00 
  523e93:	48 8b 40 50          	mov    0x50(%rax),%rax
  523e97:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
  523e9e:	00 
  523e9f:	0f 29 a4 24 60 02 00 	movaps %xmm4,0x260(%rsp)
  523ea6:	00 
  523ea7:	0f 57 d2             	xorps  %xmm2,%xmm2
  523eaa:	f2 0f 5a d4          	cvtsd2ss %xmm4,%xmm2
  523eae:	0f 57 e4             	xorps  %xmm4,%xmm4
  523eb1:	f3 0f 5a e2          	cvtss2sd %xmm2,%xmm4
  523eb5:	0f 29 9c 24 e0 01 00 	movaps %xmm3,0x1e0(%rsp)
  523ebc:	00 
  523ebd:	0f 57 d2             	xorps  %xmm2,%xmm2
  523ec0:	f2 0f 5a d3          	cvtsd2ss %xmm3,%xmm2
  523ec4:	0f 57 db             	xorps  %xmm3,%xmm3
  523ec7:	f3 0f 5a da          	cvtss2sd %xmm2,%xmm3
  523ecb:	0f 29 ac 24 40 02 00 	movaps %xmm5,0x240(%rsp)
  523ed2:	00 
  523ed3:	0f 57 d2             	xorps  %xmm2,%xmm2
  523ed6:	f2 0f 5a d5          	cvtsd2ss %xmm5,%xmm2
  523eda:	0f 57 ed             	xorps  %xmm5,%xmm5
  523edd:	f3 0f 5a ea          	cvtss2sd %xmm2,%xmm5
  523ee1:	0f 29 bc 24 c0 01 00 	movaps %xmm7,0x1c0(%rsp)
  523ee8:	00 
  523ee9:	0f 57 d2             	xorps  %xmm2,%xmm2
  523eec:	f2 0f 5a d7          	cvtsd2ss %xmm7,%xmm2
  523ef0:	0f 57 ff             	xorps  %xmm7,%xmm7
  523ef3:	f3 0f 5a fa          	cvtss2sd %xmm2,%xmm7
  523ef7:	0f 29 b4 24 30 01 00 	movaps %xmm6,0x130(%rsp)
  523efe:	00 
  523eff:	0f 57 d2             	xorps  %xmm2,%xmm2
  523f02:	f2 0f 5a d6          	cvtsd2ss %xmm6,%xmm2
  523f06:	f3 0f 5a f2          	cvtss2sd %xmm2,%xmm6
  523f0a:	44 0f 29 8c 24 f0 00 	movaps %xmm9,0xf0(%rsp)
  523f11:	00 00 
  523f13:	0f 57 d2             	xorps  %xmm2,%xmm2
  523f16:	f2 41 0f 5a d1       	cvtsd2ss %xmm9,%xmm2
  523f1b:	f3 0f 5a d2          	cvtss2sd %xmm2,%xmm2
  523f1f:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  523f26:	00 
  523f27:	ff c0                	inc    %eax
  523f29:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  523f30:	00 
  523f31:	0f 29 a4 24 a0 02 00 	movaps %xmm4,0x2a0(%rsp)
  523f38:	00 
  523f39:	41 0f 54 e0          	andps  %xmm8,%xmm4
  523f3d:	0f 29 a4 24 90 02 00 	movaps %xmm4,0x290(%rsp)
  523f44:	00 
  523f45:	0f 29 ac 24 80 02 00 	movaps %xmm5,0x280(%rsp)
  523f4c:	00 
  523f4d:	41 0f 54 e8          	andps  %xmm8,%xmm5
  523f51:	0f 29 ac 24 70 02 00 	movaps %xmm5,0x270(%rsp)
  523f58:	00 
  523f59:	0f 29 b4 24 c0 00 00 	movaps %xmm6,0xc0(%rsp)
  523f60:	00 
  523f61:	41 0f 54 f0          	andps  %xmm8,%xmm6
  523f65:	0f 29 b4 24 40 01 00 	movaps %xmm6,0x140(%rsp)
  523f6c:	00 
  523f6d:	0f 29 9c 24 20 02 00 	movaps %xmm3,0x220(%rsp)
  523f74:	00 
  523f75:	41 0f 54 d8          	andps  %xmm8,%xmm3
  523f79:	0f 29 9c 24 10 02 00 	movaps %xmm3,0x210(%rsp)
  523f80:	00 
  523f81:	0f 29 bc 24 00 02 00 	movaps %xmm7,0x200(%rsp)
  523f88:	00 
  523f89:	41 0f 54 f8          	andps  %xmm8,%xmm7
  523f8d:	0f 29 bc 24 f0 01 00 	movaps %xmm7,0x1f0(%rsp)
  523f94:	00 
  523f95:	0f 29 94 24 00 01 00 	movaps %xmm2,0x100(%rsp)
  523f9c:	00 
  523f9d:	44 0f 54 c2          	andps  %xmm2,%xmm8
  523fa1:	44 0f 29 84 24 10 01 	movaps %xmm8,0x110(%rsp)
  523fa8:	00 00 
  523faa:	48 89 e8             	mov    %rbp,%rax
  523fad:	48 0f af c3          	imul   %rbx,%rax
  523fb1:	49 01 c3             	add    %rax,%r11
  523fb4:	4c 8b ac 24 b0 00 00 	mov    0xb0(%rsp),%r13
  523fbb:	00 
  523fbc:	eb 1e                	jmp    523fdc <<gpui_gpu::renderer::RendererState>::bin_draw+0x52c>
  523fbe:	66 90                	xchg   %ax,%ax
  523fc0:	49 01 eb             	add    %rbp,%r11
  523fc3:	4c 39 f3             	cmp    %r14,%rbx
  523fc6:	48 8b 9c 24 98 01 00 	mov    0x198(%rsp),%rbx
  523fcd:	00 
  523fce:	4c 8b ac 24 b0 00 00 	mov    0xb0(%rsp),%r13
  523fd5:	00 
  523fd6:	0f 84 95 0b 00 00    	je     524b71 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  523fdc:	48 8d 43 01          	lea    0x1(%rbx),%rax
  523fe0:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
  523fe7:	00 
  523fe8:	4c 89 d9             	mov    %r11,%rcx
  523feb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  523ff0:	48 89 c8             	mov    %rcx,%rax
  523ff3:	48 c1 e8 20          	shr    $0x20,%rax
  523ff7:	74 17                	je     524010 <<gpui_gpu::renderer::RendererState>::bin_draw+0x560>
  523ff9:	48 89 c8             	mov    %rcx,%rax
  523ffc:	31 d2                	xor    %edx,%edx
  523ffe:	48 f7 f5             	div    %rbp
  524001:	eb 13                	jmp    524016 <<gpui_gpu::renderer::RendererState>::bin_draw+0x566>
  524003:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  52400a:	84 00 00 00 00 00 
  524010:	89 c8                	mov    %ecx,%eax
  524012:	31 d2                	xor    %edx,%edx
  524014:	f7 f5                	div    %ebp
  524016:	c1 e2 04             	shl    $0x4,%edx
  524019:	c1 e0 04             	shl    $0x4,%eax
  52401c:	8d 7a 10             	lea    0x10(%rdx),%edi
  52401f:	44 39 ff             	cmp    %r15d,%edi
  524022:	41 0f 43 ff          	cmovae %r15d,%edi
  524026:	44 8d 40 10          	lea    0x10(%rax),%r8d
  52402a:	45 39 d0             	cmp    %r10d,%r8d
  52402d:	45 0f 43 c2          	cmovae %r10d,%r8d
  524031:	45 0f 57 e4          	xorps  %xmm12,%xmm12
  524035:	f2 44 0f 2a e2       	cvtsi2sd %edx,%xmm12
  52403a:	66 41 0f 2e c4       	ucomisd %xmm12,%xmm0
  52403f:	77 3f                	ja     524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524041:	89 c0                	mov    %eax,%eax
  524043:	45 0f 57 f6          	xorps  %xmm14,%xmm14
  524047:	f2 4c 0f 2a f0       	cvtsi2sd %rax,%xmm14
  52404c:	66 41 0f 2e ce       	ucomisd %xmm14,%xmm1
  524051:	77 2d                	ja     524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524053:	0f 57 f6             	xorps  %xmm6,%xmm6
  524056:	f2 0f 2a f7          	cvtsi2sd %edi,%xmm6
  52405a:	66 0f 2e b4 24 a8 01 	ucomisd 0x1a8(%rsp),%xmm6
  524061:	00 00 
  524063:	77 1b                	ja     524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524065:	45 0f 57 ff          	xorps  %xmm15,%xmm15
  524069:	f2 45 0f 2a f8       	cvtsi2sd %r8d,%xmm15
  52406e:	66 44 0f 2e bc 24 a0 	ucomisd 0x1a0(%rsp),%xmm15
  524075:	01 00 00 
  524078:	76 25                	jbe    52409f <<gpui_gpu::renderer::RendererState>::bin_draw+0x5ef>
  52407a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  524080:	48 39 f1             	cmp    %rsi,%rcx
  524083:	0f 83 f6 0c 00 00    	jae    524d7f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524089:	41 ff 44 cc 04       	incl   0x4(%r12,%rcx,8)
  52408e:	48 ff c1             	inc    %rcx
  524091:	49 ff cd             	dec    %r13
  524094:	0f 85 56 ff ff ff    	jne    523ff0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x540>
  52409a:	e9 21 ff ff ff       	jmp    523fc0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x510>
  52409f:	f2 0f 10 15 e9 96 5f 	movsd  0x5f96e9(%rip),%xmm2        # b1d790 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x8>
  5240a6:	00 
  5240a7:	f2 44 0f 58 f2       	addsd  %xmm2,%xmm14
  5240ac:	f2 44 0f 58 e2       	addsd  %xmm2,%xmm12
  5240b1:	66 45 0f 28 d6       	movapd %xmm14,%xmm10
  5240b6:	f2 44 0f 59 94 24 80 	mulsd  0x280(%rsp),%xmm10
  5240bd:	02 00 00 
  5240c0:	66 45 0f 28 de       	movapd %xmm14,%xmm11
  5240c5:	f2 44 0f 59 9c 24 70 	mulsd  0x270(%rsp),%xmm11
  5240cc:	02 00 00 
  5240cf:	66 45 0f 28 cc       	movapd %xmm12,%xmm9
  5240d4:	f2 44 0f 59 8c 24 a0 	mulsd  0x2a0(%rsp),%xmm9
  5240db:	02 00 00 
  5240de:	66 41 0f 28 d1       	movapd %xmm9,%xmm2
  5240e3:	f2 41 0f 58 d2       	addsd  %xmm10,%xmm2
  5240e8:	f2 0f 58 94 24 c0 00 	addsd  0xc0(%rsp),%xmm2
  5240ef:	00 00 
  5240f1:	f2 0f 5c 94 24 80 00 	subsd  0x80(%rsp),%xmm2
  5240f8:	00 00 
  5240fa:	66 0f 28 ac 24 90 02 	movapd 0x290(%rsp),%xmm5
  524101:	00 00 
  524103:	f2 41 0f 59 ec       	mulsd  %xmm12,%xmm5
  524108:	66 0f 28 dd          	movapd %xmm5,%xmm3
  52410c:	f2 41 0f 58 db       	addsd  %xmm11,%xmm3
  524111:	f2 0f 58 9c 24 40 01 	addsd  0x140(%rsp),%xmm3
  524118:	00 00 
  52411a:	f2 0f 58 5c 24 70    	addsd  0x70(%rsp),%xmm3
  524120:	f2 0f 58 5c 24 60    	addsd  0x60(%rsp),%xmm3
  524126:	f2 0f 58 1d da 8f 5f 	addsd  0x5f8fda(%rip),%xmm3        # b1d108 <_fini+0x928>
  52412d:	00 
  52412e:	f2 0f 59 1d 6a 96 5f 	mulsd  0x5f966a(%rip),%xmm3        # b1d7a0 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x18>
  524135:	00 
  524136:	f2 0f 58 5c 24 08    	addsd  0x8(%rsp),%xmm3
  52413c:	66 0f 2e da          	ucomisd %xmm2,%xmm3
  524140:	0f 83 3a ff ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524146:	66 0f 28 64 24 50    	movapd 0x50(%rsp),%xmm4
  52414c:	f2 0f 5c e2          	subsd  %xmm2,%xmm4
  524150:	66 0f 2e dc          	ucomisd %xmm4,%xmm3
  524154:	0f 83 26 ff ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  52415a:	66 0f 28 9c 24 40 02 	movapd 0x240(%rsp),%xmm3
  524161:	00 00 
  524163:	f2 41 0f 59 de       	mulsd  %xmm14,%xmm3
  524168:	66 44 0f 28 ac 24 30 	movapd 0x230(%rsp),%xmm13
  52416f:	02 00 00 
  524172:	f2 45 0f 59 ee       	mulsd  %xmm14,%xmm13
  524177:	66 0f 28 94 24 60 02 	movapd 0x260(%rsp),%xmm2
  52417e:	00 00 
  524180:	f2 41 0f 59 d4       	mulsd  %xmm12,%xmm2
  524185:	66 0f 29 94 24 50 01 	movapd %xmm2,0x150(%rsp)
  52418c:	00 00 
  52418e:	f2 0f 58 d3          	addsd  %xmm3,%xmm2
  524192:	f2 0f 58 94 24 30 01 	addsd  0x130(%rsp),%xmm2
  524199:	00 00 
  52419b:	f2 0f 5c 94 24 80 00 	subsd  0x80(%rsp),%xmm2
  5241a2:	00 00 
  5241a4:	66 0f 28 a4 24 50 02 	movapd 0x250(%rsp),%xmm4
  5241ab:	00 00 
  5241ad:	f2 41 0f 59 e4       	mulsd  %xmm12,%xmm4
  5241b2:	f2 0f 11 a4 24 a8 00 	movsd  %xmm4,0xa8(%rsp)
  5241b9:	00 00 
  5241bb:	f2 41 0f 58 e5       	addsd  %xmm13,%xmm4
  5241c0:	f2 0f 58 a4 24 20 01 	addsd  0x120(%rsp),%xmm4
  5241c7:	00 00 
  5241c9:	f2 0f 58 64 24 70    	addsd  0x70(%rsp),%xmm4
  5241cf:	f2 0f 58 64 24 60    	addsd  0x60(%rsp),%xmm4
  5241d5:	f2 0f 58 25 2b 8f 5f 	addsd  0x5f8f2b(%rip),%xmm4        # b1d108 <_fini+0x928>
  5241dc:	00 
  5241dd:	f2 0f 59 25 c3 95 5f 	mulsd  0x5f95c3(%rip),%xmm4        # b1d7a8 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x20>
  5241e4:	00 
  5241e5:	66 0f 2e e2          	ucomisd %xmm2,%xmm4
  5241e9:	0f 83 91 fe ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5241ef:	66 0f 28 7c 24 50    	movapd 0x50(%rsp),%xmm7
  5241f5:	f2 0f 5c fa          	subsd  %xmm2,%xmm7
  5241f9:	66 0f 2e e7          	ucomisd %xmm7,%xmm4
  5241fd:	0f 83 7d fe ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524203:	66 41 0f 28 e6       	movapd %xmm14,%xmm4
  524208:	f2 0f 59 a4 24 00 02 	mulsd  0x200(%rsp),%xmm4
  52420f:	00 00 
  524211:	66 41 0f 28 d6       	movapd %xmm14,%xmm2
  524216:	f2 0f 59 94 24 f0 01 	mulsd  0x1f0(%rsp),%xmm2
  52421d:	00 00 
  52421f:	66 41 0f 28 fc       	movapd %xmm12,%xmm7
  524224:	f2 0f 59 bc 24 20 02 	mulsd  0x220(%rsp),%xmm7
  52422b:	00 00 
  52422d:	f2 0f 11 bc 24 80 01 	movsd  %xmm7,0x180(%rsp)
  524234:	00 00 
  524236:	f2 0f 11 a4 24 98 00 	movsd  %xmm4,0x98(%rsp)
  52423d:	00 00 
  52423f:	f2 0f 58 fc          	addsd  %xmm4,%xmm7
  524243:	f2 0f 58 bc 24 00 01 	addsd  0x100(%rsp),%xmm7
  52424a:	00 00 
  52424c:	f2 0f 5c 7c 24 40    	subsd  0x40(%rsp),%xmm7
  524252:	66 41 0f 28 e4       	movapd %xmm12,%xmm4
  524257:	f2 0f 59 a4 24 10 02 	mulsd  0x210(%rsp),%xmm4
  52425e:	00 00 
  524260:	f2 0f 11 a4 24 78 01 	movsd  %xmm4,0x178(%rsp)
  524267:	00 00 
  524269:	f2 0f 58 e2          	addsd  %xmm2,%xmm4
  52426d:	f2 0f 58 a4 24 10 01 	addsd  0x110(%rsp),%xmm4
  524274:	00 00 
  524276:	f2 0f 58 64 24 30    	addsd  0x30(%rsp),%xmm4
  52427c:	f2 0f 58 64 24 20    	addsd  0x20(%rsp),%xmm4
  524282:	f2 0f 58 25 7e 8e 5f 	addsd  0x5f8e7e(%rip),%xmm4        # b1d108 <_fini+0x928>
  524289:	00 
  52428a:	f2 0f 59 25 0e 95 5f 	mulsd  0x5f950e(%rip),%xmm4        # b1d7a0 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x18>
  524291:	00 
  524292:	f2 0f 58 24 24       	addsd  (%rsp),%xmm4
  524297:	66 0f 2e e7          	ucomisd %xmm7,%xmm4
  52429b:	0f 83 df fd ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5242a1:	66 44 0f 28 44 24 10 	movapd 0x10(%rsp),%xmm8
  5242a8:	f2 44 0f 5c c7       	subsd  %xmm7,%xmm8
  5242ad:	66 41 0f 2e e0       	ucomisd %xmm8,%xmm4
  5242b2:	0f 83 c8 fd ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5242b8:	66 0f 28 a4 24 c0 01 	movapd 0x1c0(%rsp),%xmm4
  5242bf:	00 00 
  5242c1:	f2 41 0f 59 e6       	mulsd  %xmm14,%xmm4
  5242c6:	f2 44 0f 59 b4 24 b0 	mulsd  0x1b0(%rsp),%xmm14
  5242cd:	01 00 00 
  5242d0:	66 0f 28 bc 24 e0 01 	movapd 0x1e0(%rsp),%xmm7
  5242d7:	00 00 
  5242d9:	f2 41 0f 59 fc       	mulsd  %xmm12,%xmm7
  5242de:	66 0f 29 bc 24 d0 02 	movapd %xmm7,0x2d0(%rsp)
  5242e5:	00 00 
  5242e7:	66 0f 29 a4 24 e0 02 	movapd %xmm4,0x2e0(%rsp)
  5242ee:	00 00 
  5242f0:	f2 0f 58 fc          	addsd  %xmm4,%xmm7
  5242f4:	f2 0f 58 bc 24 f0 00 	addsd  0xf0(%rsp),%xmm7
  5242fb:	00 00 
  5242fd:	f2 0f 5c 7c 24 40    	subsd  0x40(%rsp),%xmm7
  524303:	f2 44 0f 59 a4 24 d0 	mulsd  0x1d0(%rsp),%xmm12
  52430a:	01 00 00 
  52430d:	66 41 0f 28 e4       	movapd %xmm12,%xmm4
  524312:	f2 41 0f 58 e6       	addsd  %xmm14,%xmm4
  524317:	f2 0f 58 a4 24 e0 00 	addsd  0xe0(%rsp),%xmm4
  52431e:	00 00 
  524320:	f2 0f 58 64 24 30    	addsd  0x30(%rsp),%xmm4
  524326:	f2 0f 58 64 24 20    	addsd  0x20(%rsp),%xmm4
  52432c:	f2 0f 58 25 d4 8d 5f 	addsd  0x5f8dd4(%rip),%xmm4        # b1d108 <_fini+0x928>
  524333:	00 
  524334:	f2 0f 59 25 6c 94 5f 	mulsd  0x5f946c(%rip),%xmm4        # b1d7a8 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x20>
  52433b:	00 
  52433c:	66 0f 2e e7          	ucomisd %xmm7,%xmm4
  524340:	0f 83 3a fd ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524346:	66 44 0f 28 44 24 10 	movapd 0x10(%rsp),%xmm8
  52434d:	f2 44 0f 5c c7       	subsd  %xmm7,%xmm8
  524352:	66 41 0f 2e e0       	ucomisd %xmm8,%xmm4
  524357:	0f 83 23 fd ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  52435d:	f2 0f 58 35 33 94 5f 	addsd  0x5f9433(%rip),%xmm6        # b1d798 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x10>
  524364:	00 
  524365:	66 0f 28 e6          	movapd %xmm6,%xmm4
  524369:	f2 0f 59 a4 24 a0 02 	mulsd  0x2a0(%rsp),%xmm4
  524370:	00 00 
  524372:	66 0f 28 fc          	movapd %xmm4,%xmm7
  524376:	f2 44 0f 58 d4       	addsd  %xmm4,%xmm10
  52437b:	f2 44 0f 58 94 24 c0 	addsd  0xc0(%rsp),%xmm10
  524382:	00 00 00 
  524385:	f2 44 0f 5c 94 24 80 	subsd  0x80(%rsp),%xmm10
  52438c:	00 00 00 
  52438f:	66 0f 28 a4 24 90 02 	movapd 0x290(%rsp),%xmm4
  524396:	00 00 
  524398:	f2 0f 59 e6          	mulsd  %xmm6,%xmm4
  52439c:	f2 44 0f 58 dc       	addsd  %xmm4,%xmm11
  5243a1:	f2 44 0f 58 9c 24 40 	addsd  0x140(%rsp),%xmm11
  5243a8:	01 00 00 
  5243ab:	f2 44 0f 58 5c 24 70 	addsd  0x70(%rsp),%xmm11
  5243b2:	f2 44 0f 58 5c 24 60 	addsd  0x60(%rsp),%xmm11
  5243b9:	f2 44 0f 58 1d 46 8d 	addsd  0x5f8d46(%rip),%xmm11        # b1d108 <_fini+0x928>
  5243c0:	5f 00 
  5243c2:	f2 44 0f 59 1d d5 93 	mulsd  0x5f93d5(%rip),%xmm11        # b1d7a0 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x18>
  5243c9:	5f 00 
  5243cb:	f2 44 0f 58 5c 24 08 	addsd  0x8(%rsp),%xmm11
  5243d2:	66 45 0f 2e da       	ucomisd %xmm10,%xmm11
  5243d7:	0f 83 a3 fc ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5243dd:	66 44 0f 28 c4       	movapd %xmm4,%xmm8
  5243e2:	66 0f 28 64 24 50    	movapd 0x50(%rsp),%xmm4
  5243e8:	f2 41 0f 5c e2       	subsd  %xmm10,%xmm4
  5243ed:	66 44 0f 2e dc       	ucomisd %xmm4,%xmm11
  5243f2:	0f 83 88 fc ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5243f8:	66 0f 28 a4 24 60 02 	movapd 0x260(%rsp),%xmm4
  5243ff:	00 00 
  524401:	f2 0f 59 e6          	mulsd  %xmm6,%xmm4
  524405:	66 0f 29 a4 24 c0 02 	movapd %xmm4,0x2c0(%rsp)
  52440c:	00 00 
  52440e:	f2 0f 58 dc          	addsd  %xmm4,%xmm3
  524412:	f2 0f 58 9c 24 30 01 	addsd  0x130(%rsp),%xmm3
  524419:	00 00 
  52441b:	f2 0f 5c 9c 24 80 00 	subsd  0x80(%rsp),%xmm3
  524422:	00 00 
  524424:	66 0f 28 a4 24 50 02 	movapd 0x250(%rsp),%xmm4
  52442b:	00 00 
  52442d:	f2 0f 59 e6          	mulsd  %xmm6,%xmm4
  524431:	f2 44 0f 58 ec       	addsd  %xmm4,%xmm13
  524436:	f2 44 0f 58 ac 24 20 	addsd  0x120(%rsp),%xmm13
  52443d:	01 00 00 
  524440:	f2 44 0f 58 6c 24 70 	addsd  0x70(%rsp),%xmm13
  524447:	f2 44 0f 58 6c 24 60 	addsd  0x60(%rsp),%xmm13
  52444e:	f2 44 0f 58 2d b1 8c 	addsd  0x5f8cb1(%rip),%xmm13        # b1d108 <_fini+0x928>
  524455:	5f 00 
  524457:	f2 44 0f 59 2d 48 93 	mulsd  0x5f9348(%rip),%xmm13        # b1d7a8 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x20>
  52445e:	5f 00 
  524460:	66 44 0f 2e eb       	ucomisd %xmm3,%xmm13
  524465:	0f 83 15 fc ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  52446b:	66 44 0f 28 dc       	movapd %xmm4,%xmm11
  524470:	66 0f 28 64 24 50    	movapd 0x50(%rsp),%xmm4
  524476:	f2 0f 5c e3          	subsd  %xmm3,%xmm4
  52447a:	66 44 0f 2e ec       	ucomisd %xmm4,%xmm13
  52447f:	0f 83 fb fb ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524485:	66 0f 28 de          	movapd %xmm6,%xmm3
  524489:	f2 0f 59 9c 24 20 02 	mulsd  0x220(%rsp),%xmm3
  524490:	00 00 
  524492:	f2 0f 11 9c 24 70 01 	movsd  %xmm3,0x170(%rsp)
  524499:	00 00 
  52449b:	f2 44 0f 10 94 24 98 	movsd  0x98(%rsp),%xmm10
  5244a2:	00 00 00 
  5244a5:	f2 44 0f 58 d3       	addsd  %xmm3,%xmm10
  5244aa:	f2 44 0f 58 94 24 00 	addsd  0x100(%rsp),%xmm10
  5244b1:	01 00 00 
  5244b4:	f2 44 0f 5c 54 24 40 	subsd  0x40(%rsp),%xmm10
  5244bb:	66 0f 28 de          	movapd %xmm6,%xmm3
  5244bf:	f2 0f 59 9c 24 10 02 	mulsd  0x210(%rsp),%xmm3
  5244c6:	00 00 
  5244c8:	f2 0f 11 9c 24 98 00 	movsd  %xmm3,0x98(%rsp)
  5244cf:	00 00 
  5244d1:	f2 0f 58 d3          	addsd  %xmm3,%xmm2
  5244d5:	f2 0f 58 94 24 10 01 	addsd  0x110(%rsp),%xmm2
  5244dc:	00 00 
  5244de:	f2 0f 58 54 24 30    	addsd  0x30(%rsp),%xmm2
  5244e4:	f2 0f 58 54 24 20    	addsd  0x20(%rsp),%xmm2
  5244ea:	f2 0f 58 15 16 8c 5f 	addsd  0x5f8c16(%rip),%xmm2        # b1d108 <_fini+0x928>
  5244f1:	00 
  5244f2:	f2 0f 59 15 a6 92 5f 	mulsd  0x5f92a6(%rip),%xmm2        # b1d7a0 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x18>
  5244f9:	00 
  5244fa:	f2 0f 58 14 24       	addsd  (%rsp),%xmm2
  5244ff:	66 41 0f 2e d2       	ucomisd %xmm10,%xmm2
  524504:	0f 83 76 fb ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  52450a:	66 0f 28 5c 24 10    	movapd 0x10(%rsp),%xmm3
  524510:	f2 41 0f 5c da       	subsd  %xmm10,%xmm3
  524515:	66 0f 2e d3          	ucomisd %xmm3,%xmm2
  524519:	0f 83 61 fb ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  52451f:	66 0f 28 94 24 e0 01 	movapd 0x1e0(%rsp),%xmm2
  524526:	00 00 
  524528:	f2 0f 59 d6          	mulsd  %xmm6,%xmm2
  52452c:	66 0f 29 94 24 b0 02 	movapd %xmm2,0x2b0(%rsp)
  524533:	00 00 
  524535:	66 0f 28 a4 24 e0 02 	movapd 0x2e0(%rsp),%xmm4
  52453c:	00 00 
  52453e:	f2 0f 58 e2          	addsd  %xmm2,%xmm4
  524542:	f2 0f 58 a4 24 f0 00 	addsd  0xf0(%rsp),%xmm4
  524549:	00 00 
  52454b:	f2 0f 5c 64 24 40    	subsd  0x40(%rsp),%xmm4
  524551:	f2 0f 59 b4 24 d0 01 	mulsd  0x1d0(%rsp),%xmm6
  524558:	00 00 
  52455a:	f2 44 0f 58 f6       	addsd  %xmm6,%xmm14
  52455f:	f2 44 0f 58 b4 24 e0 	addsd  0xe0(%rsp),%xmm14
  524566:	00 00 00 
  524569:	f2 44 0f 58 74 24 30 	addsd  0x30(%rsp),%xmm14
  524570:	f2 44 0f 58 74 24 20 	addsd  0x20(%rsp),%xmm14
  524577:	f2 44 0f 58 35 88 8b 	addsd  0x5f8b88(%rip),%xmm14        # b1d108 <_fini+0x928>
  52457e:	5f 00 
  524580:	f2 44 0f 59 35 1f 92 	mulsd  0x5f921f(%rip),%xmm14        # b1d7a8 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x20>
  524587:	5f 00 
  524589:	66 44 0f 2e f4       	ucomisd %xmm4,%xmm14
  52458e:	0f 83 ec fa ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524594:	66 0f 28 54 24 10    	movapd 0x10(%rsp),%xmm2
  52459a:	f2 0f 5c d4          	subsd  %xmm4,%xmm2
  52459e:	66 44 0f 2e f2       	ucomisd %xmm2,%xmm14
  5245a3:	0f 83 d7 fa ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5245a9:	f2 44 0f 58 3d e6 91 	addsd  0x5f91e6(%rip),%xmm15        # b1d798 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x10>
  5245b0:	5f 00 
  5245b2:	66 41 0f 28 df       	movapd %xmm15,%xmm3
  5245b7:	f2 0f 59 9c 24 80 02 	mulsd  0x280(%rsp),%xmm3
  5245be:	00 00 
  5245c0:	66 41 0f 28 d7       	movapd %xmm15,%xmm2
  5245c5:	f2 0f 59 94 24 70 02 	mulsd  0x270(%rsp),%xmm2
  5245cc:	00 00 
  5245ce:	f2 44 0f 58 cb       	addsd  %xmm3,%xmm9
  5245d3:	f2 44 0f 58 8c 24 c0 	addsd  0xc0(%rsp),%xmm9
  5245da:	00 00 00 
  5245dd:	f2 44 0f 5c 8c 24 80 	subsd  0x80(%rsp),%xmm9
  5245e4:	00 00 00 
  5245e7:	f2 0f 58 ea          	addsd  %xmm2,%xmm5
  5245eb:	f2 0f 58 ac 24 40 01 	addsd  0x140(%rsp),%xmm5
  5245f2:	00 00 
  5245f4:	f2 0f 58 6c 24 70    	addsd  0x70(%rsp),%xmm5
  5245fa:	f2 0f 58 6c 24 60    	addsd  0x60(%rsp),%xmm5
  524600:	f2 0f 58 2d 00 8b 5f 	addsd  0x5f8b00(%rip),%xmm5        # b1d108 <_fini+0x928>
  524607:	00 
  524608:	f2 0f 59 2d 90 91 5f 	mulsd  0x5f9190(%rip),%xmm5        # b1d7a0 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x18>
  52460f:	00 
  524610:	f2 0f 58 6c 24 08    	addsd  0x8(%rsp),%xmm5
  524616:	66 41 0f 2e e9       	ucomisd %xmm9,%xmm5
  52461b:	0f 83 5f fa ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524621:	66 0f 28 64 24 50    	movapd 0x50(%rsp),%xmm4
  524627:	f2 41 0f 5c e1       	subsd  %xmm9,%xmm4
  52462c:	66 0f 2e ec          	ucomisd %xmm4,%xmm5
  524630:	0f 83 4a fa ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524636:	66 44 0f 28 b4 24 40 	movapd 0x240(%rsp),%xmm14
  52463d:	02 00 00 
  524640:	f2 45 0f 59 f7       	mulsd  %xmm15,%xmm14
  524645:	66 0f 28 ac 24 30 02 	movapd 0x230(%rsp),%xmm5
  52464c:	00 00 
  52464e:	f2 41 0f 59 ef       	mulsd  %xmm15,%xmm5
  524653:	66 0f 28 a4 24 50 01 	movapd 0x150(%rsp),%xmm4
  52465a:	00 00 
  52465c:	f2 41 0f 58 e6       	addsd  %xmm14,%xmm4
  524661:	f2 0f 58 a4 24 30 01 	addsd  0x130(%rsp),%xmm4
  524668:	00 00 
  52466a:	f2 0f 5c a4 24 80 00 	subsd  0x80(%rsp),%xmm4
  524671:	00 00 
  524673:	f2 44 0f 10 94 24 a8 	movsd  0xa8(%rsp),%xmm10
  52467a:	00 00 00 
  52467d:	f2 44 0f 58 d5       	addsd  %xmm5,%xmm10
  524682:	f2 44 0f 58 94 24 20 	addsd  0x120(%rsp),%xmm10
  524689:	01 00 00 
  52468c:	f2 44 0f 58 54 24 70 	addsd  0x70(%rsp),%xmm10
  524693:	f2 44 0f 58 54 24 60 	addsd  0x60(%rsp),%xmm10
  52469a:	f2 44 0f 58 15 65 8a 	addsd  0x5f8a65(%rip),%xmm10        # b1d108 <_fini+0x928>
  5246a1:	5f 00 
  5246a3:	f2 44 0f 59 15 fc 90 	mulsd  0x5f90fc(%rip),%xmm10        # b1d7a8 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x20>
  5246aa:	5f 00 
  5246ac:	66 44 0f 2e d4       	ucomisd %xmm4,%xmm10
  5246b1:	0f 83 c9 f9 ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5246b7:	66 44 0f 28 ec       	movapd %xmm4,%xmm13
  5246bc:	66 0f 28 64 24 50    	movapd 0x50(%rsp),%xmm4
  5246c2:	f2 41 0f 5c e5       	subsd  %xmm13,%xmm4
  5246c7:	66 44 0f 2e d4       	ucomisd %xmm4,%xmm10
  5246cc:	0f 83 ae f9 ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5246d2:	66 45 0f 28 d7       	movapd %xmm15,%xmm10
  5246d7:	f2 44 0f 59 94 24 00 	mulsd  0x200(%rsp),%xmm10
  5246de:	02 00 00 
  5246e1:	66 41 0f 28 e7       	movapd %xmm15,%xmm4
  5246e6:	f2 0f 59 a4 24 f0 01 	mulsd  0x1f0(%rsp),%xmm4
  5246ed:	00 00 
  5246ef:	f2 44 0f 10 8c 24 80 	movsd  0x180(%rsp),%xmm9
  5246f6:	01 00 00 
  5246f9:	f2 44 0f 11 94 24 a8 	movsd  %xmm10,0xa8(%rsp)
  524700:	00 00 00 
  524703:	f2 45 0f 58 ca       	addsd  %xmm10,%xmm9
  524708:	f2 44 0f 58 8c 24 00 	addsd  0x100(%rsp),%xmm9
  52470f:	01 00 00 
  524712:	f2 44 0f 5c 4c 24 40 	subsd  0x40(%rsp),%xmm9
  524719:	f2 44 0f 10 ac 24 78 	movsd  0x178(%rsp),%xmm13
  524720:	01 00 00 
  524723:	f2 0f 11 a4 24 50 01 	movsd  %xmm4,0x150(%rsp)
  52472a:	00 00 
  52472c:	f2 44 0f 58 ec       	addsd  %xmm4,%xmm13
  524731:	f2 44 0f 58 ac 24 10 	addsd  0x110(%rsp),%xmm13
  524738:	01 00 00 
  52473b:	f2 44 0f 58 6c 24 30 	addsd  0x30(%rsp),%xmm13
  524742:	f2 44 0f 58 6c 24 20 	addsd  0x20(%rsp),%xmm13
  524749:	f2 44 0f 58 2d b6 89 	addsd  0x5f89b6(%rip),%xmm13        # b1d108 <_fini+0x928>
  524750:	5f 00 
  524752:	f2 44 0f 59 2d 45 90 	mulsd  0x5f9045(%rip),%xmm13        # b1d7a0 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x18>
  524759:	5f 00 
  52475b:	f2 44 0f 58 2c 24    	addsd  (%rsp),%xmm13
  524761:	66 45 0f 2e e9       	ucomisd %xmm9,%xmm13
  524766:	0f 83 14 f9 ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  52476c:	66 45 0f 28 d1       	movapd %xmm9,%xmm10
  524771:	66 44 0f 28 4c 24 10 	movapd 0x10(%rsp),%xmm9
  524778:	f2 45 0f 5c ca       	subsd  %xmm10,%xmm9
  52477d:	66 45 0f 2e e9       	ucomisd %xmm9,%xmm13
  524782:	0f 83 f8 f8 ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524788:	66 44 0f 28 8c 24 c0 	movapd 0x1c0(%rsp),%xmm9
  52478f:	01 00 00 
  524792:	f2 45 0f 59 cf       	mulsd  %xmm15,%xmm9
  524797:	f2 44 0f 59 bc 24 b0 	mulsd  0x1b0(%rsp),%xmm15
  52479e:	01 00 00 
  5247a1:	66 44 0f 28 94 24 d0 	movapd 0x2d0(%rsp),%xmm10
  5247a8:	02 00 00 
  5247ab:	f2 45 0f 58 d1       	addsd  %xmm9,%xmm10
  5247b0:	f2 44 0f 58 94 24 f0 	addsd  0xf0(%rsp),%xmm10
  5247b7:	00 00 00 
  5247ba:	f2 44 0f 5c 54 24 40 	subsd  0x40(%rsp),%xmm10
  5247c1:	f2 45 0f 58 e7       	addsd  %xmm15,%xmm12
  5247c6:	f2 44 0f 58 a4 24 e0 	addsd  0xe0(%rsp),%xmm12
  5247cd:	00 00 00 
  5247d0:	f2 44 0f 58 64 24 30 	addsd  0x30(%rsp),%xmm12
  5247d7:	f2 44 0f 58 64 24 20 	addsd  0x20(%rsp),%xmm12
  5247de:	f2 44 0f 58 25 21 89 	addsd  0x5f8921(%rip),%xmm12        # b1d108 <_fini+0x928>
  5247e5:	5f 00 
  5247e7:	f2 44 0f 59 25 b8 8f 	mulsd  0x5f8fb8(%rip),%xmm12        # b1d7a8 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x20>
  5247ee:	5f 00 
  5247f0:	66 45 0f 2e e2       	ucomisd %xmm10,%xmm12
  5247f5:	0f 83 85 f8 ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5247fb:	66 41 0f 28 e2       	movapd %xmm10,%xmm4
  524800:	66 44 0f 28 54 24 10 	movapd 0x10(%rsp),%xmm10
  524807:	f2 44 0f 5c d4       	subsd  %xmm4,%xmm10
  52480c:	66 45 0f 2e e2       	ucomisd %xmm10,%xmm12
  524811:	0f 83 69 f8 ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524817:	f2 0f 58 fb          	addsd  %xmm3,%xmm7
  52481b:	f2 0f 58 bc 24 c0 00 	addsd  0xc0(%rsp),%xmm7
  524822:	00 00 
  524824:	f2 0f 5c bc 24 80 00 	subsd  0x80(%rsp),%xmm7
  52482b:	00 00 
  52482d:	f2 44 0f 58 c2       	addsd  %xmm2,%xmm8
  524832:	f2 44 0f 58 84 24 40 	addsd  0x140(%rsp),%xmm8
  524839:	01 00 00 
  52483c:	f2 44 0f 58 44 24 70 	addsd  0x70(%rsp),%xmm8
  524843:	f2 44 0f 58 44 24 60 	addsd  0x60(%rsp),%xmm8
  52484a:	f2 44 0f 58 05 b5 88 	addsd  0x5f88b5(%rip),%xmm8        # b1d108 <_fini+0x928>
  524851:	5f 00 
  524853:	f2 44 0f 59 05 44 8f 	mulsd  0x5f8f44(%rip),%xmm8        # b1d7a0 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x18>
  52485a:	5f 00 
  52485c:	f2 44 0f 58 44 24 08 	addsd  0x8(%rsp),%xmm8
  524863:	66 44 0f 2e c7       	ucomisd %xmm7,%xmm8
  524868:	0f 83 12 f8 ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  52486e:	66 0f 28 54 24 50    	movapd 0x50(%rsp),%xmm2
  524874:	f2 0f 5c d7          	subsd  %xmm7,%xmm2
  524878:	66 44 0f 2e c2       	ucomisd %xmm2,%xmm8
  52487d:	0f 83 fd f7 ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524883:	66 0f 28 94 24 c0 02 	movapd 0x2c0(%rsp),%xmm2
  52488a:	00 00 
  52488c:	f2 41 0f 58 d6       	addsd  %xmm14,%xmm2
  524891:	f2 0f 58 94 24 30 01 	addsd  0x130(%rsp),%xmm2
  524898:	00 00 
  52489a:	f2 0f 5c 94 24 80 00 	subsd  0x80(%rsp),%xmm2
  5248a1:	00 00 
  5248a3:	f2 44 0f 58 dd       	addsd  %xmm5,%xmm11
  5248a8:	f2 44 0f 58 9c 24 20 	addsd  0x120(%rsp),%xmm11
  5248af:	01 00 00 
  5248b2:	f2 44 0f 58 5c 24 70 	addsd  0x70(%rsp),%xmm11
  5248b9:	f2 44 0f 58 5c 24 60 	addsd  0x60(%rsp),%xmm11
  5248c0:	f2 44 0f 58 1d 3f 88 	addsd  0x5f883f(%rip),%xmm11        # b1d108 <_fini+0x928>
  5248c7:	5f 00 
  5248c9:	f2 44 0f 59 1d d6 8e 	mulsd  0x5f8ed6(%rip),%xmm11        # b1d7a8 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x20>
  5248d0:	5f 00 
  5248d2:	66 44 0f 2e da       	ucomisd %xmm2,%xmm11
  5248d7:	0f 83 a3 f7 ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5248dd:	66 0f 28 da          	movapd %xmm2,%xmm3
  5248e1:	66 0f 28 54 24 50    	movapd 0x50(%rsp),%xmm2
  5248e7:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
  5248eb:	66 44 0f 2e da       	ucomisd %xmm2,%xmm11
  5248f0:	0f 83 8a f7 ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5248f6:	f2 0f 10 94 24 70 01 	movsd  0x170(%rsp),%xmm2
  5248fd:	00 00 
  5248ff:	f2 0f 58 94 24 a8 00 	addsd  0xa8(%rsp),%xmm2
  524906:	00 00 
  524908:	f2 0f 58 94 24 00 01 	addsd  0x100(%rsp),%xmm2
  52490f:	00 00 
  524911:	f2 0f 5c 54 24 40    	subsd  0x40(%rsp),%xmm2
  524917:	f2 0f 10 ac 24 98 00 	movsd  0x98(%rsp),%xmm5
  52491e:	00 00 
  524920:	f2 0f 58 ac 24 50 01 	addsd  0x150(%rsp),%xmm5
  524927:	00 00 
  524929:	f2 0f 58 ac 24 10 01 	addsd  0x110(%rsp),%xmm5
  524930:	00 00 
  524932:	f2 0f 58 6c 24 30    	addsd  0x30(%rsp),%xmm5
  524938:	f2 0f 58 6c 24 20    	addsd  0x20(%rsp),%xmm5
  52493e:	f2 0f 58 2d c2 87 5f 	addsd  0x5f87c2(%rip),%xmm5        # b1d108 <_fini+0x928>
  524945:	00 
  524946:	f2 0f 59 2d 52 8e 5f 	mulsd  0x5f8e52(%rip),%xmm5        # b1d7a0 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x18>
  52494d:	00 
  52494e:	f2 0f 58 2c 24       	addsd  (%rsp),%xmm5
  524953:	66 0f 2e ea          	ucomisd %xmm2,%xmm5
  524957:	0f 83 23 f7 ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  52495d:	66 0f 28 da          	movapd %xmm2,%xmm3
  524961:	66 0f 28 54 24 10    	movapd 0x10(%rsp),%xmm2
  524967:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
  52496b:	66 0f 2e ea          	ucomisd %xmm2,%xmm5
  52496f:	0f 83 0b f7 ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524975:	66 0f 28 94 24 b0 02 	movapd 0x2b0(%rsp),%xmm2
  52497c:	00 00 
  52497e:	f2 41 0f 58 d1       	addsd  %xmm9,%xmm2
  524983:	f2 0f 58 94 24 f0 00 	addsd  0xf0(%rsp),%xmm2
  52498a:	00 00 
  52498c:	f2 0f 5c 54 24 40    	subsd  0x40(%rsp),%xmm2
  524992:	f2 41 0f 58 f7       	addsd  %xmm15,%xmm6
  524997:	f2 0f 58 b4 24 e0 00 	addsd  0xe0(%rsp),%xmm6
  52499e:	00 00 
  5249a0:	f2 0f 58 74 24 30    	addsd  0x30(%rsp),%xmm6
  5249a6:	f2 0f 58 74 24 20    	addsd  0x20(%rsp),%xmm6
  5249ac:	f2 0f 58 35 54 87 5f 	addsd  0x5f8754(%rip),%xmm6        # b1d108 <_fini+0x928>
  5249b3:	00 
  5249b4:	f2 0f 59 35 ec 8d 5f 	mulsd  0x5f8dec(%rip),%xmm6        # b1d7a8 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x20>
  5249bb:	00 
  5249bc:	66 0f 2e f2          	ucomisd %xmm2,%xmm6
  5249c0:	0f 83 ba f6 ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5249c6:	66 0f 28 da          	movapd %xmm2,%xmm3
  5249ca:	66 0f 28 54 24 10    	movapd 0x10(%rsp),%xmm2
  5249d0:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
  5249d4:	66 0f 2e f2          	ucomisd %xmm2,%xmm6
  5249d8:	0f 83 a2 f6 ff ff    	jae    524080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5249de:	48 39 f1             	cmp    %rsi,%rcx
  5249e1:	0f 83 b5 03 00 00    	jae    524d9c <<gpui_gpu::renderer::RendererState>::bin_draw+0x12ec>
  5249e7:	8b 84 24 bc 00 00 00 	mov    0xbc(%rsp),%eax
  5249ee:	41 89 04 cc          	mov    %eax,(%r12,%rcx,8)
  5249f2:	41 c7 44 cc 04 01 00 	movl   $0x1,0x4(%r12,%rcx,8)
  5249f9:	00 00 
  5249fb:	48 3b 8c 24 d8 00 00 	cmp    0xd8(%rsp),%rcx
  524a02:	00 
  524a03:	0f 83 a3 03 00 00    	jae    524dac <<gpui_gpu::renderer::RendererState>::bin_draw+0x12fc>
  524a09:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  524a10:	00 
  524a11:	48 8b 94 24 68 01 00 	mov    0x168(%rsp),%rdx
  524a18:	00 
  524a19:	89 04 8a             	mov    %eax,(%rdx,%rcx,4)
  524a1c:	48 ff c1             	inc    %rcx
  524a1f:	49 ff cd             	dec    %r13
  524a22:	0f 85 c8 f5 ff ff    	jne    523ff0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x540>
  524a28:	e9 93 f5 ff ff       	jmp    523fc0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x510>
  524a2d:	48 89 e8             	mov    %rbp,%rax
  524a30:	48 0f af c3          	imul   %rbx,%rax
  524a34:	49 01 c3             	add    %rax,%r11
  524a37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  524a3e:	00 00 
  524a40:	48 89 d8             	mov    %rbx,%rax
  524a43:	48 ff c3             	inc    %rbx
  524a46:	4c 89 d9             	mov    %r11,%rcx
  524a49:	4c 89 ea             	mov    %r13,%rdx
  524a4c:	0f 1f 40 00          	nopl   0x0(%rax)
  524a50:	48 39 f1             	cmp    %rsi,%rcx
  524a53:	0f 83 26 03 00 00    	jae    524d7f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524a59:	41 ff 44 cc 04       	incl   0x4(%r12,%rcx,8)
  524a5e:	48 ff c1             	inc    %rcx
  524a61:	48 ff ca             	dec    %rdx
  524a64:	75 ea                	jne    524a50 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfa0>
  524a66:	49 01 eb             	add    %rbp,%r11
  524a69:	4c 39 f0             	cmp    %r14,%rax
  524a6c:	75 d2                	jne    524a40 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf90>
  524a6e:	e9 fe 00 00 00       	jmp    524b71 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  524a73:	48 89 e8             	mov    %rbp,%rax
  524a76:	48 0f af c3          	imul   %rbx,%rax
  524a7a:	49 01 c3             	add    %rax,%r11
  524a7d:	0f 1f 00             	nopl   (%rax)
  524a80:	48 8d 43 01          	lea    0x1(%rbx),%rax
  524a84:	4c 89 d9             	mov    %r11,%rcx
  524a87:	4c 89 ea             	mov    %r13,%rdx
  524a8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  524a90:	48 39 f1             	cmp    %rsi,%rcx
  524a93:	0f 83 e6 02 00 00    	jae    524d7f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524a99:	41 ff 44 cc 04       	incl   0x4(%r12,%rcx,8)
  524a9e:	48 ff c1             	inc    %rcx
  524aa1:	48 ff ca             	dec    %rdx
  524aa4:	75 ea                	jne    524a90 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfe0>
  524aa6:	49 01 eb             	add    %rbp,%r11
  524aa9:	4c 39 f3             	cmp    %r14,%rbx
  524aac:	48 89 c3             	mov    %rax,%rbx
  524aaf:	75 cf                	jne    524a80 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfd0>
  524ab1:	e9 bb 00 00 00       	jmp    524b71 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  524ab6:	85 ff                	test   %edi,%edi
  524ab8:	0f 88 e2 00 00 00    	js     524ba0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10f0>
  524abe:	45 85 c9             	test   %r9d,%r9d
  524ac1:	0f 88 3c 01 00 00    	js     524c03 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1153>
  524ac7:	45 85 c0             	test   %r8d,%r8d
  524aca:	0f 89 bf 02 00 00    	jns    524d8f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12df>
  524ad0:	41 81 fa ff ff 7f 7f 	cmp    $0x7f7fffff,%r10d
  524ad7:	0f 82 b2 02 00 00    	jb     524d8f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12df>
  524add:	4c 39 de             	cmp    %r11,%rsi
  524ae0:	4c 89 d9             	mov    %r11,%rcx
  524ae3:	48 0f 47 ce          	cmova  %rsi,%rcx
  524ae7:	48 ff c0             	inc    %rax
  524aea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  524af0:	48 8d 53 01          	lea    0x1(%rbx),%rdx
  524af4:	4c 89 df             	mov    %r11,%rdi
  524af7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  524afe:	00 00 
  524b00:	48 39 f9             	cmp    %rdi,%rcx
  524b03:	0f 84 76 02 00 00    	je     524d7f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524b09:	41 ff 44 fc 04       	incl   0x4(%r12,%rdi,8)
  524b0e:	48 ff c7             	inc    %rdi
  524b11:	48 39 f8             	cmp    %rdi,%rax
  524b14:	75 ea                	jne    524b00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1050>
  524b16:	4c 39 f3             	cmp    %r14,%rbx
  524b19:	48 89 d3             	mov    %rdx,%rbx
  524b1c:	75 d2                	jne    524af0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1040>
  524b1e:	eb 51                	jmp    524b71 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  524b20:	48 89 e8             	mov    %rbp,%rax
  524b23:	48 0f af c3          	imul   %rbx,%rax
  524b27:	49 01 c3             	add    %rax,%r11
  524b2a:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
  524b31:	00 
  524b32:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  524b39:	1f 84 00 00 00 00 00 
  524b40:	48 8d 43 01          	lea    0x1(%rbx),%rax
  524b44:	4c 89 d9             	mov    %r11,%rcx
  524b47:	48 89 fa             	mov    %rdi,%rdx
  524b4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  524b50:	48 39 f1             	cmp    %rsi,%rcx
  524b53:	0f 83 26 02 00 00    	jae    524d7f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524b59:	41 ff 44 cc 04       	incl   0x4(%r12,%rcx,8)
  524b5e:	48 ff c1             	inc    %rcx
  524b61:	48 ff ca             	dec    %rdx
  524b64:	75 ea                	jne    524b50 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10a0>
  524b66:	49 01 eb             	add    %rbp,%r11
  524b69:	4c 39 f3             	cmp    %r14,%rbx
  524b6c:	48 89 c3             	mov    %rax,%rbx
  524b6f:	75 cf                	jne    524b40 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1090>
  524b71:	48 8b bc 24 90 01 00 	mov    0x190(%rsp),%rdi
  524b78:	00 
  524b79:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  524b80:	00 
  524b81:	48 89 47 08          	mov    %rax,0x8(%rdi)
  524b85:	41 ba ff ff ff ff    	mov    $0xffffffff,%r10d
  524b8b:	44 89 17             	mov    %r10d,(%rdi)
  524b8e:	48 81 c4 f8 02 00 00 	add    $0x2f8,%rsp
  524b95:	5b                   	pop    %rbx
  524b96:	41 5c                	pop    %r12
  524b98:	41 5d                	pop    %r13
  524b9a:	41 5e                	pop    %r14
  524b9c:	41 5f                	pop    %r15
  524b9e:	5d                   	pop    %rbp
  524b9f:	c3                   	ret
  524ba0:	41 81 ff ff ff 7f 7f 	cmp    $0x7f7fffff,%r15d
  524ba7:	0f 83 b6 00 00 00    	jae    524c63 <<gpui_gpu::renderer::RendererState>::bin_draw+0x11b3>
  524bad:	45 85 c9             	test   %r9d,%r9d
  524bb0:	0f 88 2d 01 00 00    	js     524ce3 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1233>
  524bb6:	45 85 c0             	test   %r8d,%r8d
  524bb9:	0f 89 d0 01 00 00    	jns    524d8f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12df>
  524bbf:	41 81 fa ff ff 7f 7f 	cmp    $0x7f7fffff,%r10d
  524bc6:	0f 82 c3 01 00 00    	jb     524d8f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12df>
  524bcc:	4c 39 de             	cmp    %r11,%rsi
  524bcf:	4c 89 d9             	mov    %r11,%rcx
  524bd2:	48 0f 47 ce          	cmova  %rsi,%rcx
  524bd6:	48 ff c0             	inc    %rax
  524bd9:	48 8d 53 01          	lea    0x1(%rbx),%rdx
  524bdd:	4c 89 df             	mov    %r11,%rdi
  524be0:	48 39 f9             	cmp    %rdi,%rcx
  524be3:	0f 84 96 01 00 00    	je     524d7f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524be9:	41 ff 44 fc 04       	incl   0x4(%r12,%rdi,8)
  524bee:	48 ff c7             	inc    %rdi
  524bf1:	48 39 f8             	cmp    %rdi,%rax
  524bf4:	75 ea                	jne    524be0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1130>
  524bf6:	4c 39 f3             	cmp    %r14,%rbx
  524bf9:	48 89 d3             	mov    %rdx,%rbx
  524bfc:	75 db                	jne    524bd9 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1129>
  524bfe:	e9 6e ff ff ff       	jmp    524b71 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  524c03:	41 81 fd ff ff 7f 7f 	cmp    $0x7f7fffff,%r13d
  524c0a:	0f 83 93 00 00 00    	jae    524ca3 <<gpui_gpu::renderer::RendererState>::bin_draw+0x11f3>
  524c10:	45 85 c0             	test   %r8d,%r8d
  524c13:	0f 89 76 01 00 00    	jns    524d8f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12df>
  524c19:	41 81 fa ff ff 7f 7f 	cmp    $0x7f7fffff,%r10d
  524c20:	0f 82 69 01 00 00    	jb     524d8f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12df>
  524c26:	4c 39 de             	cmp    %r11,%rsi
  524c29:	4c 89 d9             	mov    %r11,%rcx
  524c2c:	48 0f 47 ce          	cmova  %rsi,%rcx
  524c30:	48 ff c0             	inc    %rax
  524c33:	48 8d 53 01          	lea    0x1(%rbx),%rdx
  524c37:	4c 89 df             	mov    %r11,%rdi
  524c3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  524c40:	48 39 f9             	cmp    %rdi,%rcx
  524c43:	0f 84 36 01 00 00    	je     524d7f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524c49:	41 ff 44 fc 04       	incl   0x4(%r12,%rdi,8)
  524c4e:	48 ff c7             	inc    %rdi
  524c51:	48 39 f8             	cmp    %rdi,%rax
  524c54:	75 ea                	jne    524c40 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1190>
  524c56:	4c 39 f3             	cmp    %r14,%rbx
  524c59:	48 89 d3             	mov    %rdx,%rbx
  524c5c:	75 d5                	jne    524c33 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1183>
  524c5e:	e9 0e ff ff ff       	jmp    524b71 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  524c63:	4c 39 de             	cmp    %r11,%rsi
  524c66:	4c 89 d9             	mov    %r11,%rcx
  524c69:	48 0f 47 ce          	cmova  %rsi,%rcx
  524c6d:	48 ff c0             	inc    %rax
  524c70:	48 8d 53 01          	lea    0x1(%rbx),%rdx
  524c74:	4c 89 df             	mov    %r11,%rdi
  524c77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  524c7e:	00 00 
  524c80:	48 39 f9             	cmp    %rdi,%rcx
  524c83:	0f 84 f6 00 00 00    	je     524d7f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524c89:	41 ff 44 fc 04       	incl   0x4(%r12,%rdi,8)
  524c8e:	48 ff c7             	inc    %rdi
  524c91:	48 39 f8             	cmp    %rdi,%rax
  524c94:	75 ea                	jne    524c80 <<gpui_gpu::renderer::RendererState>::bin_draw+0x11d0>
  524c96:	4c 39 f3             	cmp    %r14,%rbx
  524c99:	48 89 d3             	mov    %rdx,%rbx
  524c9c:	75 d2                	jne    524c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x11c0>
  524c9e:	e9 ce fe ff ff       	jmp    524b71 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  524ca3:	4c 39 de             	cmp    %r11,%rsi
  524ca6:	4c 89 d9             	mov    %r11,%rcx
  524ca9:	48 0f 47 ce          	cmova  %rsi,%rcx
  524cad:	48 ff c0             	inc    %rax
  524cb0:	48 8d 53 01          	lea    0x1(%rbx),%rdx
  524cb4:	4c 89 df             	mov    %r11,%rdi
  524cb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  524cbe:	00 00 
  524cc0:	48 39 f9             	cmp    %rdi,%rcx
  524cc3:	0f 84 b6 00 00 00    	je     524d7f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524cc9:	41 ff 44 fc 04       	incl   0x4(%r12,%rdi,8)
  524cce:	48 ff c7             	inc    %rdi
  524cd1:	48 39 f8             	cmp    %rdi,%rax
  524cd4:	75 ea                	jne    524cc0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1210>
  524cd6:	4c 39 f3             	cmp    %r14,%rbx
  524cd9:	48 89 d3             	mov    %rdx,%rbx
  524cdc:	75 d2                	jne    524cb0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1200>
  524cde:	e9 8e fe ff ff       	jmp    524b71 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  524ce3:	41 81 fd ff ff 7f 7f 	cmp    $0x7f7fffff,%r13d
  524cea:	73 53                	jae    524d3f <<gpui_gpu::renderer::RendererState>::bin_draw+0x128f>
  524cec:	45 85 c0             	test   %r8d,%r8d
  524cef:	0f 89 9a 00 00 00    	jns    524d8f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12df>
  524cf5:	41 81 fa ff ff 7f 7f 	cmp    $0x7f7fffff,%r10d
  524cfc:	0f 82 8d 00 00 00    	jb     524d8f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12df>
  524d02:	4c 39 de             	cmp    %r11,%rsi
  524d05:	4c 89 d9             	mov    %r11,%rcx
  524d08:	48 0f 47 ce          	cmova  %rsi,%rcx
  524d0c:	48 ff c0             	inc    %rax
  524d0f:	48 8d 53 01          	lea    0x1(%rbx),%rdx
  524d13:	4c 89 df             	mov    %r11,%rdi
  524d16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  524d1d:	00 00 00 
  524d20:	48 39 f9             	cmp    %rdi,%rcx
  524d23:	74 5a                	je     524d7f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524d25:	41 ff 44 fc 04       	incl   0x4(%r12,%rdi,8)
  524d2a:	48 ff c7             	inc    %rdi
  524d2d:	48 39 f8             	cmp    %rdi,%rax
  524d30:	75 ee                	jne    524d20 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1270>
  524d32:	4c 39 f3             	cmp    %r14,%rbx
  524d35:	48 89 d3             	mov    %rdx,%rbx
  524d38:	75 d5                	jne    524d0f <<gpui_gpu::renderer::RendererState>::bin_draw+0x125f>
  524d3a:	e9 32 fe ff ff       	jmp    524b71 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  524d3f:	4c 39 de             	cmp    %r11,%rsi
  524d42:	4c 89 d9             	mov    %r11,%rcx
  524d45:	48 0f 47 ce          	cmova  %rsi,%rcx
  524d49:	48 ff c0             	inc    %rax
  524d4c:	48 8d 53 01          	lea    0x1(%rbx),%rdx
  524d50:	4c 89 df             	mov    %r11,%rdi
  524d53:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  524d5a:	84 00 00 00 00 00 
  524d60:	48 39 f9             	cmp    %rdi,%rcx
  524d63:	74 1a                	je     524d7f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524d65:	41 ff 44 fc 04       	incl   0x4(%r12,%rdi,8)
  524d6a:	48 ff c7             	inc    %rdi
  524d6d:	48 39 f8             	cmp    %rdi,%rax
  524d70:	75 ee                	jne    524d60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x12b0>
  524d72:	4c 39 f3             	cmp    %r14,%rbx
  524d75:	48 89 d3             	mov    %rdx,%rbx
  524d78:	75 d2                	jne    524d4c <<gpui_gpu::renderer::RendererState>::bin_draw+0x129c>
  524d7a:	e9 f2 fd ff ff       	jmp    524b71 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  524d7f:	48 8d 15 2a ba d5 00 	lea    0xd5ba2a(%rip),%rdx        # 12807b0 <anon.255c8ba72969252177b3101bd34b486f.6.llvm.2677678285831016542+0xf0>
  524d86:	48 89 cf             	mov    %rcx,%rdi
  524d89:	ff 15 51 51 da 00    	call   *0xda5151(%rip)        # 12c9ee0 <_GLOBAL_OFFSET_TABLE_+0x60a0>
  524d8f:	48 8d 3d 3a bb d5 00 	lea    0xd5bb3a(%rip),%rdi        # 12808d0 <anon.11c63428aaff144b0aa1b5cb745d0db3.29.llvm.9269992671348706103+0x10>
  524d96:	ff 15 9c 01 da 00    	call   *0xda019c(%rip)        # 12c4f38 <_GLOBAL_OFFSET_TABLE_+0x10f8>
  524d9c:	48 8d 15 25 ba d5 00 	lea    0xd5ba25(%rip),%rdx        # 12807c8 <anon.255c8ba72969252177b3101bd34b486f.6.llvm.2677678285831016542+0x108>
  524da3:	48 89 cf             	mov    %rcx,%rdi
  524da6:	ff 15 34 51 da 00    	call   *0xda5134(%rip)        # 12c9ee0 <_GLOBAL_OFFSET_TABLE_+0x60a0>
  524dac:	48 8d 15 2d ba d5 00 	lea    0xd5ba2d(%rip),%rdx        # 12807e0 <anon.255c8ba72969252177b3101bd34b486f.6.llvm.2677678285831016542+0x120>
  524db3:	48 89 cf             	mov    %rcx,%rdi
  524db6:	48 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%rsi
  524dbd:	00 
  524dbe:	ff 15 1c 51 da 00    	call   *0xda511c(%rip)        # 12c9ee0 <_GLOBAL_OFFSET_TABLE_+0x60a0>
