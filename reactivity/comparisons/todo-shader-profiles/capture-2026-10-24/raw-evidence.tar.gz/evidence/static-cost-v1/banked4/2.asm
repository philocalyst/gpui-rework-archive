
/home/miles/gpui-ce3-compute-20261024/evidence/todo-shader-profiles/attempt2/builds/banked4/todo_comparison_mapped:     file format elf64-x86-64


Disassembly of section .text:

00000000001ce350 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>>:
  1ce350:	55                   	push   %rbp
  1ce351:	41 57                	push   %r15
  1ce353:	41 56                	push   %r14
  1ce355:	41 55                	push   %r13
  1ce357:	41 54                	push   %r12
  1ce359:	53                   	push   %rbx
  1ce35a:	48 81 ec c8 0c 00 00 	sub    $0xcc8,%rsp
  1ce361:	48 89 fb             	mov    %rdi,%rbx
  1ce364:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
  1ce369:	ba a0 01 00 00       	mov    $0x1a0,%edx
  1ce36e:	ff 15 b4 5f 0f 01    	call   *0x10f5fb4(%rip)        # 12c4328 <memcpy@GLIBC_2.14>
  1ce374:	64 48 8b 04 25 00 00 	mov    %fs:0x0,%rax
  1ce37b:	00 00 
  1ce37d:	48 8d 80 f0 fe ff ff 	lea    -0x110(%rax),%rax
  1ce384:	80 78 10 01          	cmpb   $0x1,0x10(%rax)
  1ce388:	48 89 9c 24 48 02 00 	mov    %rbx,0x248(%rsp)
  1ce38f:	00 
  1ce390:	75 44                	jne    1ce3d6 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x86>
  1ce392:	48 89 84 24 90 02 00 	mov    %rax,0x290(%rsp)
  1ce399:	00 
  1ce39a:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
  1ce3a1:	00 
  1ce3a2:	48 c7 84 24 a0 02 00 	movq   $0x0,0x2a0(%rsp)
  1ce3a9:	00 00 00 00 00 
  1ce3ae:	48 8d 9c 24 a0 00 00 	lea    0xa0(%rsp),%rbx
  1ce3b5:	00 
  1ce3b6:	4c 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%r15
  1ce3bd:	00 
  1ce3be:	0f b6 84 24 0c 02 00 	movzbl 0x20c(%rsp),%eax
  1ce3c5:	00 
  1ce3c6:	48 8d 0d a7 76 99 00 	lea    0x9976a7(%rip),%rcx        # b65a74 <anon.1ff77c7c1c4ccf5bc9ac09e6755ce13a.72.llvm.508734745195800081+0x318e>
  1ce3cd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
  1ce3d1:	48 01 c8             	add    %rcx,%rax
  1ce3d4:	ff e0                	jmp    *%rax
  1ce3d6:	48 89 c7             	mov    %rax,%rdi
  1ce3d9:	31 f6                	xor    %esi,%esi
  1ce3db:	e8 50 ce eb ff       	call   8b230 <<std::sys::thread_local::native::lazy::Storage<core::task::wake::Waker, ()>>::get_or_init_slow::<pollster::LOCAL_WAKER::{K#0}::{closure#0}::{closure#0}>>
  1ce3e0:	48 85 c0             	test   %rax,%rax
  1ce3e3:	75 ad                	jne    1ce392 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x42>
  1ce3e5:	48 8d 3d 5c ac 09 01 	lea    0x109ac5c(%rip),%rdi        # 1269048 <anon.a6257334ecde00274c07381362c94de0.1.llvm.11926555745833327518>
  1ce3ec:	ff 15 26 6a 0f 01    	call   *0x10f6a26(%rip)        # 12c4e18 <_GLOBAL_OFFSET_TABLE_+0xfd8>
  1ce3f2:	eb 35                	jmp    1ce429 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xd9>
  1ce3f4:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
  1ce3f9:	48 89 74 24 78       	mov    %rsi,0x78(%rsp)
  1ce3fe:	8b 83 68 01 00 00    	mov    0x168(%rbx),%eax
  1ce404:	89 43 e8             	mov    %eax,-0x18(%rbx)
  1ce407:	48 8b 83 60 01 00 00 	mov    0x160(%rbx),%rax
  1ce40e:	48 89 43 e0          	mov    %rax,-0x20(%rbx)
  1ce412:	c6 84 24 98 00 00 00 	movb   $0x0,0x98(%rsp)
  1ce419:	00 
  1ce41a:	eb 40                	jmp    1ce45c <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x10c>
  1ce41c:	48 8d 3d 55 ac 09 01 	lea    0x109ac55(%rip),%rdi        # 1269078 <anon.a6257334ecde00274c07381362c94de0.1.llvm.11926555745833327518+0x30>
  1ce423:	ff 15 6f ac 0f 01    	call   *0x10fac6f(%rip)        # 12c9098 <_GLOBAL_OFFSET_TABLE_+0x5258>
  1ce429:	0f 0b                	ud2
  1ce42b:	48 8d 3d 46 ac 09 01 	lea    0x109ac46(%rip),%rdi        # 1269078 <anon.a6257334ecde00274c07381362c94de0.1.llvm.11926555745833327518+0x30>
  1ce432:	ff 15 90 96 0f 01    	call   *0x10f9690(%rip)        # 12c7ac8 <_GLOBAL_OFFSET_TABLE_+0x3c88>
  1ce438:	eb ef                	jmp    1ce429 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xd9>
  1ce43a:	e9 27 0e 00 00       	jmp    1cf266 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xf16>
  1ce43f:	0f b6 84 24 98 00 00 	movzbl 0x98(%rsp),%eax
  1ce446:	00 
  1ce447:	48 8d 0d 36 76 99 00 	lea    0x997636(%rip),%rcx        # b65a84 <anon.1ff77c7c1c4ccf5bc9ac09e6755ce13a.72.llvm.508734745195800081+0x319e>
  1ce44e:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
  1ce452:	48 01 c8             	add    %rcx,%rax
  1ce455:	ff e0                	jmp    *%rax
  1ce457:	48 8b 74 24 78       	mov    0x78(%rsp),%rsi
  1ce45c:	66 c7 84 24 99 00 00 	movw   $0x0,0x99(%rsp)
  1ce463:	00 00 00 
  1ce466:	8b 43 e8             	mov    -0x18(%rbx),%eax
  1ce469:	89 43 f4             	mov    %eax,-0xc(%rbx)
  1ce46c:	48 8b 43 e0          	mov    -0x20(%rbx),%rax
  1ce470:	48 89 43 ec          	mov    %rax,-0x14(%rbx)
  1ce474:	44 8b ac 24 8c 00 00 	mov    0x8c(%rsp),%r13d
  1ce47b:	00 
  1ce47c:	49 83 fd 28          	cmp    $0x28,%r13
  1ce480:	0f 87 a9 0b 00 00    	ja     1cf02f <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xcdf>
  1ce486:	48 b8 00 00 40 08 00 	movabs $0x10008400000,%rax
  1ce48d:	01 00 00 
  1ce490:	4c 0f a3 e8          	bt     %r13,%rax
  1ce494:	0f 83 95 0b 00 00    	jae    1cf02f <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xcdf>
  1ce49a:	48 8d 05 ec cc 98 00 	lea    0x98ccec(%rip),%rax        # b5b18d <anon.62eff4c8e93f4a8da5d7c25ff3fb4abc.72.llvm.8696119423821192211+0x4>
  1ce4a1:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  1ce4a8:	00 
  1ce4a9:	48 c7 84 24 c0 00 00 	movq   $0x4,0xc0(%rsp)
  1ce4b0:	00 04 00 00 00 
  1ce4b5:	0f 57 c0             	xorps  %xmm0,%xmm0
  1ce4b8:	0f 11 43 28          	movups %xmm0,0x28(%rbx)
  1ce4bc:	0f 28 0d ad 05 95 00 	movaps 0x9505ad(%rip),%xmm1        # b1ea70 <anon.0405107bad68a143ea614ca8c913c61f.21.llvm.3488652764154817189+0x70>
  1ce4c3:	0f 11 8c 24 d8 00 00 	movups %xmm1,0xd8(%rsp)
  1ce4ca:	00 
  1ce4cb:	0f 28 0d ae 05 95 00 	movaps 0x9505ae(%rip),%xmm1        # b1ea80 <anon.0405107bad68a143ea614ca8c913c61f.21.llvm.3488652764154817189+0x80>
  1ce4d2:	0f 11 8c 24 e8 00 00 	movups %xmm1,0xe8(%rsp)
  1ce4d9:	00 
  1ce4da:	0f 28 0d af 05 95 00 	movaps 0x9505af(%rip),%xmm1        # b1ea90 <anon.0405107bad68a143ea614ca8c913c61f.21.llvm.3488652764154817189+0x90>
  1ce4e1:	0f 11 8c 24 f8 00 00 	movups %xmm1,0xf8(%rsp)
  1ce4e8:	00 
  1ce4e9:	f2 0f 10 0d af 05 95 	movsd  0x9505af(%rip),%xmm1        # b1eaa0 <anon.0405107bad68a143ea614ca8c913c61f.21.llvm.3488652764154817189+0xa0>
  1ce4f0:	00 
  1ce4f1:	0f 11 8c 24 08 01 00 	movups %xmm1,0x108(%rsp)
  1ce4f8:	00 
  1ce4f9:	c7 84 24 18 01 00 00 	movl   $0x0,0x118(%rsp)
  1ce500:	00 00 00 00 
  1ce504:	48 c7 84 24 20 01 00 	movq   $0x10000,0x120(%rsp)
  1ce50b:	00 00 00 01 00 
  1ce510:	48 c7 84 24 28 01 00 	movq   $0x8000000,0x128(%rsp)
  1ce517:	00 00 00 00 08 
  1ce51c:	c7 84 24 30 01 00 00 	movl   $0x8,0x130(%rsp)
  1ce523:	08 00 00 00 
  1ce527:	48 c7 84 24 38 01 00 	movq   $0x10000000,0x138(%rsp)
  1ce52e:	00 00 00 00 10 
  1ce533:	0f 28 0d 76 05 95 00 	movaps 0x950576(%rip),%xmm1        # b1eab0 <anon.0405107bad68a143ea614ca8c913c61f.21.llvm.3488652764154817189+0xb0>
  1ce53a:	0f 11 8c 24 40 01 00 	movups %xmm1,0x140(%rsp)
  1ce541:	00 
  1ce542:	0f 28 0d 77 05 95 00 	movaps 0x950577(%rip),%xmm1        # b1eac0 <anon.0405107bad68a143ea614ca8c913c61f.21.llvm.3488652764154817189+0xc0>
  1ce549:	0f 11 8c 24 50 01 00 	movups %xmm1,0x150(%rsp)
  1ce550:	00 
  1ce551:	0f 28 0d 78 05 95 00 	movaps 0x950578(%rip),%xmm1        # b1ead0 <anon.0405107bad68a143ea614ca8c913c61f.21.llvm.3488652764154817189+0xd0>
  1ce558:	0f 11 8c 24 60 01 00 	movups %xmm1,0x160(%rsp)
  1ce55f:	00 
  1ce560:	48 c7 84 24 70 01 00 	movq   $0xffff,0x170(%rsp)
  1ce567:	00 ff ff 00 00 
  1ce56c:	c7 84 24 78 01 00 00 	movl   $0xf4240,0x178(%rsp)
  1ce573:	40 42 0f 00 
  1ce577:	0f 11 83 0c 01 00 00 	movups %xmm0,0x10c(%rbx)
  1ce57e:	0f 11 83 fc 00 00 00 	movups %xmm0,0xfc(%rbx)
  1ce585:	0f 11 83 ec 00 00 00 	movups %xmm0,0xec(%rbx)
  1ce58c:	0f 11 83 dc 00 00 00 	movups %xmm0,0xdc(%rbx)
  1ce593:	c7 83 1c 01 00 00 00 	movl   $0x0,0x11c(%rbx)
  1ce59a:	00 00 00 
  1ce59d:	c7 84 24 c0 01 00 00 	movl   $0x1c,0x1c0(%rsp)
  1ce5a4:	1c 00 00 00 
  1ce5a8:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
  1ce5af:	00 00 00 00 00 
  1ce5b4:	48 c7 83 29 01 00 00 	movq   $0x0,0x129(%rbx)
  1ce5bb:	00 00 00 00 
  1ce5bf:	48 c7 83 24 01 00 00 	movq   $0x0,0x124(%rbx)
  1ce5c6:	00 00 00 00 
  1ce5ca:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
  1ce5d1:	00 
  1ce5d2:	48 89 da             	mov    %rbx,%rdx
  1ce5d5:	ff 15 8d bf 0f 01    	call   *0x10fbf8d(%rip)        # 12ca568 <_GLOBAL_OFFSET_TABLE_+0x6728>
  1ce5db:	48 8b 84 24 00 03 00 	mov    0x300(%rsp),%rax
  1ce5e2:	00 
  1ce5e3:	48 8d 8c 24 d8 01 00 	lea    0x1d8(%rsp),%rcx
  1ce5ea:	00 
  1ce5eb:	48 89 41 20          	mov    %rax,0x20(%rcx)
  1ce5ef:	0f 10 84 24 e0 02 00 	movups 0x2e0(%rsp),%xmm0
  1ce5f6:	00 
  1ce5f7:	0f 10 8c 24 f0 02 00 	movups 0x2f0(%rsp),%xmm1
  1ce5fe:	00 
  1ce5ff:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
  1ce603:	0f 11 01             	movups %xmm0,(%rcx)
  1ce606:	0f b6 84 24 f8 01 00 	movzbl 0x1f8(%rsp),%eax
  1ce60d:	00 
  1ce60e:	48 8d 0d 93 74 99 00 	lea    0x997493(%rip),%rcx        # b65aa8 <anon.1ff77c7c1c4ccf5bc9ac09e6755ce13a.72.llvm.508734745195800081+0x31c2>
  1ce615:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
  1ce619:	48 01 c8             	add    %rcx,%rax
  1ce61c:	ff e0                	jmp    *%rax
  1ce61e:	0f b6 84 24 f8 01 00 	movzbl 0x1f8(%rsp),%eax
  1ce625:	00 
  1ce626:	48 8d 0d 7b 74 99 00 	lea    0x99747b(%rip),%rcx        # b65aa8 <anon.1ff77c7c1c4ccf5bc9ac09e6755ce13a.72.llvm.508734745195800081+0x31c2>
  1ce62d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
  1ce631:	48 01 c8             	add    %rcx,%rax
  1ce634:	ff e0                	jmp    *%rax
  1ce636:	48 8b b4 24 d8 01 00 	mov    0x1d8(%rsp),%rsi
  1ce63d:	00 
  1ce63e:	48 8b 84 24 e0 01 00 	mov    0x1e0(%rsp),%rax
  1ce645:	00 
  1ce646:	48 89 b4 24 e8 01 00 	mov    %rsi,0x1e8(%rsp)
  1ce64d:	00 
  1ce64e:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
  1ce655:	00 
  1ce656:	eb 10                	jmp    1ce668 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x318>
  1ce658:	48 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%rsi
  1ce65f:	00 
  1ce660:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
  1ce667:	00 
  1ce668:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
  1ce66f:	00 
  1ce670:	48 8d 94 24 90 02 00 	lea    0x290(%rsp),%rdx
  1ce677:	00 
  1ce678:	ff 50 18             	call   *0x18(%rax)
  1ce67b:	44 0f b6 a4 24 e0 02 	movzbl 0x2e0(%rsp),%r12d
  1ce682:	00 00 
  1ce684:	41 80 fc fe          	cmp    $0xfe,%r12b
  1ce688:	75 0f                	jne    1ce699 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x349>
  1ce68a:	c6 84 24 f8 01 00 00 	movb   $0x3,0x1f8(%rsp)
  1ce691:	03 
  1ce692:	b0 03                	mov    $0x3,%al
  1ce694:	e9 d1 04 00 00       	jmp    1ceb6a <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x81a>
  1ce699:	48 8d 94 24 e1 02 00 	lea    0x2e1(%rsp),%rdx
  1ce6a0:	00 
  1ce6a1:	8b 02                	mov    (%rdx),%eax
  1ce6a3:	8b 4a 03             	mov    0x3(%rdx),%ecx
  1ce6a6:	89 4c 24 1b          	mov    %ecx,0x1b(%rsp)
  1ce6aa:	89 44 24 18          	mov    %eax,0x18(%rsp)
  1ce6ae:	4c 8b bc 24 e8 02 00 	mov    0x2e8(%rsp),%r15
  1ce6b5:	00 
  1ce6b6:	4c 8b b4 24 f0 02 00 	mov    0x2f0(%rsp),%r14
  1ce6bd:	00 
  1ce6be:	0f 10 42 17          	movups 0x17(%rdx),%xmm0
  1ce6c2:	0f 10 4a 27          	movups 0x27(%rdx),%xmm1
  1ce6c6:	0f 10 52 37          	movups 0x37(%rdx),%xmm2
  1ce6ca:	0f 29 84 24 10 02 00 	movaps %xmm0,0x210(%rsp)
  1ce6d1:	00 
  1ce6d2:	0f 29 8c 24 20 02 00 	movaps %xmm1,0x220(%rsp)
  1ce6d9:	00 
  1ce6da:	0f 29 94 24 30 02 00 	movaps %xmm2,0x230(%rsp)
  1ce6e1:	00 
  1ce6e2:	48 8b ac 24 e8 01 00 	mov    0x1e8(%rsp),%rbp
  1ce6e9:	00 
  1ce6ea:	4c 8b ac 24 f0 01 00 	mov    0x1f0(%rsp),%r13
  1ce6f1:	00 
  1ce6f2:	49 8b 45 00          	mov    0x0(%r13),%rax
  1ce6f6:	48 85 c0             	test   %rax,%rax
  1ce6f9:	74 05                	je     1ce700 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x3b0>
  1ce6fb:	48 89 ef             	mov    %rbp,%rdi
  1ce6fe:	ff d0                	call   *%rax
  1ce700:	49 8b 75 08          	mov    0x8(%r13),%rsi
  1ce704:	48 85 f6             	test   %rsi,%rsi
  1ce707:	74 0d                	je     1ce716 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x3c6>
  1ce709:	49 8b 55 10          	mov    0x10(%r13),%rdx
  1ce70d:	48 89 ef             	mov    %rbp,%rdi
  1ce710:	ff 15 42 7d 0f 01    	call   *0x10f7d42(%rip)        # 12c6458 <_GLOBAL_OFFSET_TABLE_+0x2618>
  1ce716:	41 80 fc ff          	cmp    $0xff,%r12b
  1ce71a:	74 40                	je     1ce75c <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x40c>
  1ce71c:	8b 44 24 18          	mov    0x18(%rsp),%eax
  1ce720:	8b 4c 24 1b          	mov    0x1b(%rsp),%ecx
  1ce724:	89 4c 24 13          	mov    %ecx,0x13(%rsp)
  1ce728:	89 44 24 10          	mov    %eax,0x10(%rsp)
  1ce72c:	0f 28 84 24 10 02 00 	movaps 0x210(%rsp),%xmm0
  1ce733:	00 
  1ce734:	0f 28 8c 24 20 02 00 	movaps 0x220(%rsp),%xmm1
  1ce73b:	00 
  1ce73c:	0f 28 94 24 30 02 00 	movaps 0x230(%rsp),%xmm2
  1ce743:	00 
  1ce744:	0f 29 84 24 b0 02 00 	movaps %xmm0,0x2b0(%rsp)
  1ce74b:	00 
  1ce74c:	0f 29 8c 24 c0 02 00 	movaps %xmm1,0x2c0(%rsp)
  1ce753:	00 
  1ce754:	0f 29 94 24 d0 02 00 	movaps %xmm2,0x2d0(%rsp)
  1ce75b:	00 
  1ce75c:	c6 84 24 f8 01 00 00 	movb   $0x1,0x1f8(%rsp)
  1ce763:	01 
  1ce764:	48 8d bc 24 d8 01 00 	lea    0x1d8(%rsp),%rdi
  1ce76b:	00 
  1ce76c:	e8 af 1d 00 00       	call   1d0520 <core::ptr::drop_glue::<<wgpu::api::instance::Instance>::request_adapter::{closure#0}>>
  1ce771:	41 80 fc ff          	cmp    $0xff,%r12b
  1ce775:	0f 85 cb 07 00 00    	jne    1cef46 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xbf6>
  1ce77b:	4c 89 7c 24 48       	mov    %r15,0x48(%rsp)
  1ce780:	4c 89 74 24 50       	mov    %r14,0x50(%rsp)
  1ce785:	66 c7 84 24 99 00 00 	movw   $0x0,0x99(%rsp)
  1ce78c:	00 00 00 
  1ce78f:	8b 43 f4             	mov    -0xc(%rbx),%eax
  1ce792:	48 8d 8c 24 e1 02 00 	lea    0x2e1(%rsp),%rcx
  1ce799:	00 
  1ce79a:	89 41 13             	mov    %eax,0x13(%rcx)
  1ce79d:	48 8b 43 ec          	mov    -0x14(%rbx),%rax
  1ce7a1:	48 89 41 0b          	mov    %rax,0xb(%rcx)
  1ce7a5:	48 8b 84 24 f0 02 00 	mov    0x2f0(%rsp),%rax
  1ce7ac:	00 
  1ce7ad:	48 89 83 90 00 00 00 	mov    %rax,0x90(%rbx)
  1ce7b4:	0f 10 84 24 e0 02 00 	movups 0x2e0(%rsp),%xmm0
  1ce7bb:	00 
  1ce7bc:	0f 11 83 80 00 00 00 	movups %xmm0,0x80(%rbx)
  1ce7c3:	4c 89 bc 24 10 01 00 	mov    %r15,0x110(%rsp)
  1ce7ca:	00 
  1ce7cb:	4c 89 b4 24 18 01 00 	mov    %r14,0x118(%rsp)
  1ce7d2:	00 
  1ce7d3:	c6 84 24 3e 01 00 00 	movb   $0x0,0x13e(%rsp)
  1ce7da:	00 
  1ce7db:	eb 28                	jmp    1ce805 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x4b5>
  1ce7dd:	0f b6 84 24 3e 01 00 	movzbl 0x13e(%rsp),%eax
  1ce7e4:	00 
  1ce7e5:	48 8d 0d ac 72 99 00 	lea    0x9972ac(%rip),%rcx        # b65a98 <anon.1ff77c7c1c4ccf5bc9ac09e6755ce13a.72.llvm.508734745195800081+0x31b2>
  1ce7ec:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
  1ce7f0:	48 01 c8             	add    %rcx,%rax
  1ce7f3:	ff e0                	jmp    *%rax
  1ce7f5:	4c 8b bc 24 10 01 00 	mov    0x110(%rsp),%r15
  1ce7fc:	00 
  1ce7fd:	4c 8b b4 24 18 01 00 	mov    0x118(%rsp),%r14
  1ce804:	00 
  1ce805:	66 c7 83 9c 00 00 00 	movw   $0x0,0x9c(%rbx)
  1ce80c:	00 00 
  1ce80e:	c7 83 98 00 00 00 00 	movl   $0x0,0x98(%rbx)
  1ce815:	00 00 00 
  1ce818:	4c 89 bc 24 d0 00 00 	mov    %r15,0xd0(%rsp)
  1ce81f:	00 
  1ce820:	66 c7 84 24 3c 01 00 	movw   $0x101,0x13c(%rsp)
  1ce827:	00 01 01 
  1ce82a:	4c 89 b4 24 d8 00 00 	mov    %r14,0xd8(%rsp)
  1ce831:	00 
  1ce832:	8b 83 94 00 00 00    	mov    0x94(%rbx),%eax
  1ce838:	89 83 88 00 00 00    	mov    %eax,0x88(%rbx)
  1ce83e:	48 8b 83 8c 00 00 00 	mov    0x8c(%rbx),%rax
  1ce845:	48 89 83 80 00 00 00 	mov    %rax,0x80(%rbx)
  1ce84c:	44 8b ac 24 20 01 00 	mov    0x120(%rsp),%r13d
  1ce853:	00 
  1ce854:	49 83 fd 28          	cmp    $0x28,%r13
  1ce858:	0f 87 c3 04 00 00    	ja     1ced21 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x9d1>
  1ce85e:	48 b8 00 00 40 08 00 	movabs $0x10008400000,%rax
  1ce865:	01 00 00 
  1ce868:	4c 0f a3 e8          	bt     %r13,%rax
  1ce86c:	0f 83 af 04 00 00    	jae    1ced21 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x9d1>
  1ce872:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
  1ce879:	00 
  1ce87a:	4c 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%r15
  1ce881:	00 
  1ce882:	4c 89 fe             	mov    %r15,%rsi
  1ce885:	ba 01 00 00 00       	mov    $0x1,%edx
  1ce88a:	ff 15 28 d6 0f 01    	call   *0x10fd628(%rip)        # 12cbeb8 <_GLOBAL_OFFSET_TABLE_+0x8078>
  1ce890:	c6 84 24 3b 01 00 00 	movb   $0x1,0x13b(%rsp)
  1ce897:	01 
  1ce898:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
  1ce89f:	00 00 00 00 00 
  1ce8a4:	4c 8d 35 21 74 99 00 	lea    0x997421(%rip),%r14        # b65ccc <anon.1ff77c7c1c4ccf5bc9ac09e6755ce13a.72.llvm.508734745195800081+0x33e6>
  1ce8ab:	4c 89 b4 24 f8 02 00 	mov    %r14,0x2f8(%rsp)
  1ce8b2:	00 
  1ce8b3:	48 c7 84 24 00 03 00 	movq   $0x14,0x300(%rsp)
  1ce8ba:	00 14 00 00 00 
  1ce8bf:	48 c7 84 24 e0 02 00 	movq   $0xffffffffffffffff,0x2e0(%rsp)
  1ce8c6:	00 ff ff ff ff 
  1ce8cb:	48 8d 05 0e 74 99 00 	lea    0x99740e(%rip),%rax        # b65ce0 <anon.1ff77c7c1c4ccf5bc9ac09e6755ce13a.72.llvm.508734745195800081+0x33fa>
  1ce8d2:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
  1ce8d9:	00 
  1ce8da:	48 c7 84 24 f0 02 00 	movq   $0x3c1e,0x2f0(%rsp)
  1ce8e1:	00 1e 3c 00 00 
  1ce8e6:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
  1ce8ed:	00 
  1ce8ee:	4c 89 ff             	mov    %r15,%rdi
  1ce8f1:	ff 15 49 61 0f 01    	call   *0x10f6149(%rip)        # 12c4a40 <_GLOBAL_OFFSET_TABLE_+0xc00>
  1ce8f7:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
  1ce8fe:	00 
  1ce8ff:	c6 84 24 3a 01 00 00 	movb   $0x1,0x13a(%rsp)
  1ce906:	01 
  1ce907:	48 c7 84 24 e8 00 00 	movq   $0x0,0xe8(%rsp)
  1ce90e:	00 00 00 00 00 
  1ce913:	8b 83 88 00 00 00    	mov    0x88(%rbx),%eax
  1ce919:	89 44 24 20          	mov    %eax,0x20(%rsp)
  1ce91d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
  1ce924:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  1ce929:	48 b8 ff ff ff ff 0f 	movabs $0xfffffffff,%rax
  1ce930:	00 00 00 
  1ce933:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  1ce938:	4c 89 b4 24 60 03 00 	mov    %r14,0x360(%rsp)
  1ce93f:	00 
  1ce940:	48 c7 84 24 68 03 00 	movq   $0x14,0x368(%rsp)
  1ce947:	00 14 00 00 00 
  1ce94c:	48 c7 84 24 70 03 00 	movq   $0x0,0x370(%rsp)
  1ce953:	00 00 00 00 00 
  1ce958:	48 8d 05 9f af 99 00 	lea    0x99af9f(%rip),%rax        # b698fe <anon.1ff77c7c1c4ccf5bc9ac09e6755ce13a.72.llvm.508734745195800081+0x7018>
  1ce95f:	48 89 84 24 20 03 00 	mov    %rax,0x320(%rsp)
  1ce966:	00 
  1ce967:	48 c7 84 24 28 03 00 	movq   $0x6,0x328(%rsp)
  1ce96e:	00 06 00 00 00 
  1ce973:	48 c7 84 24 30 03 00 	movq   $0x8,0x330(%rsp)
  1ce97a:	00 08 00 00 00 
  1ce97f:	48 c7 84 24 38 03 00 	movq   $0x0,0x338(%rsp)
  1ce986:	00 00 00 00 00 
  1ce98b:	48 8d 8c 24 e0 00 00 	lea    0xe0(%rsp),%rcx
  1ce992:	00 
  1ce993:	48 89 8c 24 40 03 00 	mov    %rcx,0x340(%rsp)
  1ce99a:	00 
  1ce99b:	48 c7 84 24 48 03 00 	movq   $0x8,0x348(%rsp)
  1ce9a2:	00 08 00 00 00 
  1ce9a7:	48 c7 84 24 50 03 00 	movq   $0x0,0x350(%rsp)
  1ce9ae:	00 00 00 00 00 
  1ce9b3:	c6 84 24 58 03 00 00 	movb   $0x1,0x358(%rsp)
  1ce9ba:	01 
  1ce9bb:	c7 84 24 f0 03 00 00 	movl   $0x2,0x3f0(%rsp)
  1ce9c2:	02 00 00 00 
  1ce9c6:	c6 84 24 f4 03 00 00 	movb   $0x0,0x3f4(%rsp)
  1ce9cd:	00 
  1ce9ce:	c7 84 24 f8 03 00 00 	movl   $0x0,0x3f8(%rsp)
  1ce9d5:	00 00 00 00 
  1ce9d9:	c6 84 24 fc 03 00 00 	movb   $0x0,0x3fc(%rsp)
  1ce9e0:	00 
  1ce9e1:	c7 84 24 ac 03 00 00 	movl   $0x0,0x3ac(%rsp)
  1ce9e8:	00 00 00 00 
  1ce9ec:	c7 84 24 80 03 00 00 	movl   $0x1,0x380(%rsp)
  1ce9f3:	01 00 00 00 
  1ce9f7:	48 c7 84 24 88 03 00 	movq   $0xffffffffffffffff,0x388(%rsp)
  1ce9fe:	00 ff ff ff ff 
  1cea03:	c6 84 24 90 03 00 00 	movb   $0x0,0x390(%rsp)
  1cea0a:	00 
  1cea0b:	48 8d 05 7e b2 98 00 	lea    0x98b27e(%rip),%rax        # b59c90 <anon.085e9ca5054b3fe6ec3aa911f29bf4aa.50.llvm.16042612370926466725+0x18>
  1cea12:	48 89 84 24 e0 02 00 	mov    %rax,0x2e0(%rsp)
  1cea19:	00 
  1cea1a:	48 c7 84 24 e8 02 00 	movq   $0x8,0x2e8(%rsp)
  1cea21:	00 08 00 00 00 
  1cea26:	48 8d 44 24 18       	lea    0x18(%rsp),%rax
  1cea2b:	48 89 84 24 f0 02 00 	mov    %rax,0x2f0(%rsp)
  1cea32:	00 
  1cea33:	48 c7 84 24 f8 02 00 	movq   $0x1,0x2f8(%rsp)
  1cea3a:	00 01 00 00 00 
  1cea3f:	48 89 8c 24 00 03 00 	mov    %rcx,0x300(%rsp)
  1cea46:	00 
  1cea47:	48 c7 84 24 08 03 00 	movq   $0x8,0x308(%rsp)
  1cea4e:	00 08 00 00 00 
  1cea53:	48 c7 84 24 10 03 00 	movq   $0x0,0x310(%rsp)
  1cea5a:	00 00 00 00 00 
  1cea5f:	c6 84 24 18 03 00 00 	movb   $0x1,0x318(%rsp)
  1cea66:	01 
  1cea67:	0f 28 05 72 00 95 00 	movaps 0x950072(%rip),%xmm0        # b1eae0 <anon.0405107bad68a143ea614ca8c913c61f.21.llvm.3488652764154817189+0xe0>
  1cea6e:	0f 11 84 24 e0 03 00 	movups %xmm0,0x3e0(%rsp)
  1cea75:	00 
  1cea76:	48 c7 84 24 78 03 00 	movq   $0x0,0x378(%rsp)
  1cea7d:	00 00 00 00 00 
  1cea82:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
  1cea89:	00 
  1cea8a:	4c 89 ff             	mov    %r15,%rdi
  1cea8d:	ff 15 d5 7e 0f 01    	call   *0x10f7ed5(%rip)        # 12c6968 <_GLOBAL_OFFSET_TABLE_+0x2b28>
  1cea93:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  1cea9a:	00 
  1cea9b:	66 c7 84 24 39 01 00 	movw   $0x1,0x139(%rsp)
  1ceaa2:	00 01 00 
  1ceaa5:	48 8d 84 24 e8 00 00 	lea    0xe8(%rsp),%rax
  1ceaac:	00 
  1ceaad:	0f 10 00             	movups (%rax),%xmm0
  1ceab0:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
  1ceab7:	00 
  1ceab8:	48 8b 40 10          	mov    0x10(%rax),%rax
  1ceabc:	48 89 84 24 f0 02 00 	mov    %rax,0x2f0(%rsp)
  1ceac3:	00 
  1ceac4:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
  1ceacb:	00 
  1ceacc:	e8 1f 12 00 00       	call   1cfcf0 <core::ptr::drop_glue::<core::option::Option<(wgpu::api::shader_module::ShaderModule, wgpu::api::bind_group_layout::BindGroupLayout, wgpu::api::pipeline_layout::PipelineLayout)>>>
  1cead1:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
  1cead8:	00 
  1cead9:	31 f6                	xor    %esi,%esi
  1ceadb:	ff 15 9f ac 0f 01    	call   *0x10fac9f(%rip)        # 12c9780 <_GLOBAL_OFFSET_TABLE_+0x5940>
  1ceae1:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
  1ceae8:	00 
  1ceae9:	c6 84 24 38 01 00 00 	movb   $0x1,0x138(%rsp)
  1ceaf0:	01 
  1ceaf1:	c6 84 24 3b 01 00 00 	movb   $0x0,0x13b(%rsp)
  1ceaf8:	00 
  1ceaf9:	0f 10 84 24 80 02 00 	movups 0x280(%rsp),%xmm0
  1ceb00:	00 
  1ceb01:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
  1ceb08:	00 
  1ceb09:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
  1ceb10:	00 
  1ceb11:	ff 15 b1 ba 0f 01    	call   *0x10fbab1(%rip)        # 12ca5c8 <_GLOBAL_OFFSET_TABLE_+0x6788>
  1ceb17:	48 89 c6             	mov    %rax,%rsi
  1ceb1a:	48 89 d0             	mov    %rdx,%rax
  1ceb1d:	48 89 b4 24 c0 00 00 	mov    %rsi,0xc0(%rsp)
  1ceb24:	00 
  1ceb25:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  1ceb2c:	00 
  1ceb2d:	eb 10                	jmp    1ceb3f <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x7ef>
  1ceb2f:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
  1ceb36:	00 
  1ceb37:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  1ceb3e:	00 
  1ceb3f:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
  1ceb46:	00 
  1ceb47:	48 8d 94 24 90 02 00 	lea    0x290(%rsp),%rdx
  1ceb4e:	00 
  1ceb4f:	ff 50 18             	call   *0x18(%rax)
  1ceb52:	4c 8b b4 24 e0 02 00 	mov    0x2e0(%rsp),%r14
  1ceb59:	00 
  1ceb5a:	49 83 fe fe          	cmp    $0xfffffffffffffffe,%r14
  1ceb5e:	75 1e                	jne    1ceb7e <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x82e>
  1ceb60:	c6 84 24 3e 01 00 00 	movb   $0x3,0x13e(%rsp)
  1ceb67:	03 
  1ceb68:	b0 04                	mov    $0x4,%al
  1ceb6a:	88 84 24 98 00 00 00 	mov    %al,0x98(%rsp)
  1ceb71:	c6 84 24 0c 02 00 00 	movb   $0x3,0x20c(%rsp)
  1ceb78:	03 
  1ceb79:	e9 19 03 00 00       	jmp    1cee97 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xb47>
  1ceb7e:	48 8d 8c 24 e1 02 00 	lea    0x2e1(%rsp),%rcx
  1ceb85:	00 
  1ceb86:	48 8b 41 27          	mov    0x27(%rcx),%rax
  1ceb8a:	48 89 84 24 30 02 00 	mov    %rax,0x230(%rsp)
  1ceb91:	00 
  1ceb92:	0f 10 41 07          	movups 0x7(%rcx),%xmm0
  1ceb96:	0f 10 49 17          	movups 0x17(%rcx),%xmm1
  1ceb9a:	0f 29 8c 24 20 02 00 	movaps %xmm1,0x220(%rsp)
  1ceba1:	00 
  1ceba2:	0f 29 84 24 10 02 00 	movaps %xmm0,0x210(%rsp)
  1ceba9:	00 
  1cebaa:	48 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%rbp
  1cebb1:	00 
  1cebb2:	4c 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%r15
  1cebb9:	00 
  1cebba:	49 8b 07             	mov    (%r15),%rax
  1cebbd:	48 85 c0             	test   %rax,%rax
  1cebc0:	74 05                	je     1cebc7 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x877>
  1cebc2:	48 89 ef             	mov    %rbp,%rdi
  1cebc5:	ff d0                	call   *%rax
  1cebc7:	49 8b 77 08          	mov    0x8(%r15),%rsi
  1cebcb:	48 85 f6             	test   %rsi,%rsi
  1cebce:	74 0d                	je     1cebdd <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x88d>
  1cebd0:	49 8b 57 10          	mov    0x10(%r15),%rdx
  1cebd4:	48 89 ef             	mov    %rbp,%rdi
  1cebd7:	ff 15 7b 78 0f 01    	call   *0x10f787b(%rip)        # 12c6458 <_GLOBAL_OFFSET_TABLE_+0x2618>
  1cebdd:	41 83 fe ff          	cmp    $0xffffffff,%r14d
  1cebe1:	0f 84 ce 02 00 00    	je     1ceeb5 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xb65>
  1cebe7:	4c 89 b4 24 e0 02 00 	mov    %r14,0x2e0(%rsp)
  1cebee:	00 
  1cebef:	48 8b 84 24 30 02 00 	mov    0x230(%rsp),%rax
  1cebf6:	00 
  1cebf7:	48 8d 8c 24 e1 02 00 	lea    0x2e1(%rsp),%rcx
  1cebfe:	00 
  1cebff:	48 89 41 27          	mov    %rax,0x27(%rcx)
  1cec03:	0f 28 84 24 10 02 00 	movaps 0x210(%rsp),%xmm0
  1cec0a:	00 
  1cec0b:	0f 28 8c 24 20 02 00 	movaps 0x220(%rsp),%xmm1
  1cec12:	00 
  1cec13:	0f 11 49 17          	movups %xmm1,0x17(%rcx)
  1cec17:	0f 11 41 07          	movups %xmm0,0x7(%rcx)
  1cec1b:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
  1cec22:	00 00 
  1cec24:	48 c7 44 24 60 01 00 	movq   $0x1,0x60(%rsp)
  1cec2b:	00 00 
  1cec2d:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
  1cec34:	00 00 
  1cec36:	48 c7 44 24 28 20 00 	movq   $0x60000020,0x28(%rsp)
  1cec3d:	00 60 
  1cec3f:	48 8d 44 24 58       	lea    0x58(%rsp),%rax
  1cec44:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  1cec49:	48 8d 05 e0 a4 09 01 	lea    0x109a4e0(%rip),%rax        # 1269130 <anon.a6257334ecde00274c07381362c94de0.1.llvm.11926555745833327518+0xe8>
  1cec50:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  1cec55:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
  1cec5c:	00 
  1cec5d:	48 8d 74 24 18       	lea    0x18(%rsp),%rsi
  1cec62:	4c 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%r15
  1cec69:	00 
  1cec6a:	ff 15 d0 55 0f 01    	call   *0x10f55d0(%rip)        # 12c4240 <_GLOBAL_OFFSET_TABLE_+0x400>
  1cec70:	84 c0                	test   %al,%al
  1cec72:	0f 85 43 04 00 00    	jne    1cf0bb <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xd6b>
  1cec78:	4c 8b 64 24 58       	mov    0x58(%rsp),%r12
  1cec7d:	4c 8b 74 24 60       	mov    0x60(%rsp),%r14
  1cec82:	4c 8b 6c 24 68       	mov    0x68(%rsp),%r13
  1cec87:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
  1cec8e:	00 
  1cec8f:	e8 bc 26 00 00       	call   1d1350 <core::ptr::drop_glue::<wgpu::api::device::Error>>
  1cec94:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
  1cec9b:	00 
  1cec9c:	f0 48 ff 08          	lock decq (%rax)
  1ceca0:	75 0e                	jne    1cecb0 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x960>
  1ceca2:	48 8d bc 24 08 01 00 	lea    0x108(%rsp),%rdi
  1ceca9:	00 
  1cecaa:	ff 15 70 77 0f 01    	call   *0x10f7770(%rip)        # 12c6420 <_GLOBAL_OFFSET_TABLE_+0x25e0>
  1cecb0:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
  1cecb5:	4c 89 34 24          	mov    %r14,(%rsp)
  1cecb9:	c6 84 24 38 01 00 00 	movb   $0x0,0x138(%rsp)
  1cecc0:	00 
  1cecc1:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  1cecc8:	00 
  1cecc9:	f0 48 ff 08          	lock decq (%rax)
  1ceccd:	75 0e                	jne    1cecdd <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x98d>
  1ceccf:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
  1cecd6:	00 
  1cecd7:	ff 15 2b 78 0f 01    	call   *0x10f782b(%rip)        # 12c6508 <_GLOBAL_OFFSET_TABLE_+0x26c8>
  1cecdd:	66 c7 84 24 39 01 00 	movw   $0x0,0x139(%rsp)
  1cece4:	00 00 00 
  1cece7:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
  1cecee:	00 
  1cecef:	f0 48 ff 08          	lock decq (%rax)
  1cecf3:	75 0e                	jne    1ced03 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x9b3>
  1cecf5:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
  1cecfc:	00 
  1cecfd:	ff 15 cd ca 0f 01    	call   *0x10fcacd(%rip)        # 12cb7d0 <_GLOBAL_OFFSET_TABLE_+0x7990>
  1ced03:	c6 84 24 3b 01 00 00 	movb   $0x0,0x13b(%rsp)
  1ced0a:	00 
  1ced0b:	41 bd 01 00 00 00    	mov    $0x1,%r13d
  1ced11:	4c 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%r14
  1ced18:	00 
  1ced19:	f0 49 ff 0e          	lock decq (%r14)
  1ced1d:	74 20                	je     1ced3f <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x9ef>
  1ced1f:	eb 2c                	jmp    1ced4d <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x9fd>
  1ced21:	4c 8b a4 24 24 01 00 	mov    0x124(%rsp),%r12
  1ced28:	00 
  1ced29:	49 c1 e5 20          	shl    $0x20,%r13
  1ced2d:	49 83 cd 02          	or     $0x2,%r13
  1ced31:	4c 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%r15
  1ced38:	00 
  1ced39:	f0 49 ff 0e          	lock decq (%r14)
  1ced3d:	75 0e                	jne    1ced4d <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x9fd>
  1ced3f:	48 8d bc 24 d8 00 00 	lea    0xd8(%rsp),%rdi
  1ced46:	00 
  1ced47:	ff 15 d3 85 0f 01    	call   *0x10f85d3(%rip)        # 12c7320 <_GLOBAL_OFFSET_TABLE_+0x34e0>
  1ced4d:	c6 84 24 3c 01 00 00 	movb   $0x0,0x13c(%rsp)
  1ced54:	00 
  1ced55:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  1ced5c:	00 
  1ced5d:	f0 48 ff 08          	lock decq (%rax)
  1ced61:	75 09                	jne    1ced6c <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xa1c>
  1ced63:	4c 89 ff             	mov    %r15,%rdi
  1ced66:	ff 15 9c 70 0f 01    	call   *0x10f709c(%rip)        # 12c5e08 <_GLOBAL_OFFSET_TABLE_+0x1fc8>
  1ced6c:	66 c7 84 24 3d 01 00 	movw   $0x100,0x13d(%rsp)
  1ced73:	00 00 01 
  1ced76:	bd ff ff ff ff       	mov    $0xffffffff,%ebp
  1ced7b:	48 89 df             	mov    %rbx,%rdi
  1ced7e:	e8 3d 15 00 00       	call   1d02c0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  1ced83:	66 c7 84 24 98 00 00 	movw   $0x1,0x98(%rsp)
  1ced8a:	00 01 00 
  1ced8d:	c6 84 24 9a 00 00 00 	movb   $0x0,0x9a(%rsp)
  1ced94:	00 
  1ced95:	83 fd ff             	cmp    $0xffffffff,%ebp
  1ced98:	0f 84 a1 02 00 00    	je     1cf03f <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xcef>
  1ced9e:	4c 89 ac 24 50 02 00 	mov    %r13,0x250(%rsp)
  1ceda5:	00 
  1ceda6:	4c 89 a4 24 58 02 00 	mov    %r12,0x258(%rsp)
  1cedad:	00 
  1cedae:	48 8b 04 24          	mov    (%rsp),%rax
  1cedb2:	48 89 84 24 60 02 00 	mov    %rax,0x260(%rsp)
  1cedb9:	00 
  1cedba:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  1cedbf:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
  1cedc6:	00 
  1cedc7:	89 ac 24 70 02 00 00 	mov    %ebp,0x270(%rsp)
  1cedce:	4c 89 b4 24 74 02 00 	mov    %r14,0x274(%rsp)
  1cedd5:	00 
  1cedd6:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
  1ceddd:	00 
  1cedde:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
  1cede5:	00 
  1cede6:	ff 15 d4 ba 0f 01    	call   *0x10fbad4(%rip)        # 12ca8c0 <_GLOBAL_OFFSET_TABLE_+0x6a80>
  1cedec:	0f 10 84 24 50 02 00 	movups 0x250(%rsp),%xmm0
  1cedf3:	00 
  1cedf4:	0f 10 8c 24 60 02 00 	movups 0x260(%rsp),%xmm1
  1cedfb:	00 
  1cedfc:	0f 10 94 24 70 02 00 	movups 0x270(%rsp),%xmm2
  1cee03:	00 
  1cee04:	48 8d 84 24 98 0c 00 	lea    0xc98(%rsp),%rax
  1cee0b:	00 
  1cee0c:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  1cee10:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  1cee14:	0f 11 00             	movups %xmm0,(%rax)
  1cee17:	4c 8b b4 24 e0 02 00 	mov    0x2e0(%rsp),%r14
  1cee1e:	00 
  1cee1f:	4c 8b ac 24 e8 02 00 	mov    0x2e8(%rsp),%r13
  1cee26:	00 
  1cee27:	48 8b 84 24 f0 02 00 	mov    0x2f0(%rsp),%rax
  1cee2e:	00 
  1cee2f:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  1cee34:	48 8b 84 24 f8 02 00 	mov    0x2f8(%rsp),%rax
  1cee3b:	00 
  1cee3c:	48 89 04 24          	mov    %rax,(%rsp)
  1cee40:	4c 8b a4 24 00 03 00 	mov    0x300(%rsp),%r12
  1cee47:	00 
  1cee48:	48 8d ac 24 78 09 00 	lea    0x978(%rsp),%rbp
  1cee4f:	00 
  1cee50:	4c 8b 3d d1 54 0f 01 	mov    0x10f54d1(%rip),%r15        # 12c4328 <memcpy@GLIBC_2.14>
  1cee57:	ba 20 03 00 00       	mov    $0x320,%edx
  1cee5c:	48 89 ef             	mov    %rbp,%rdi
  1cee5f:	48 8d b4 24 08 03 00 	lea    0x308(%rsp),%rsi
  1cee66:	00 
  1cee67:	41 ff d7             	call   *%r15
  1cee6a:	48 8d bc 24 28 06 00 	lea    0x628(%rsp),%rdi
  1cee71:	00 
  1cee72:	ba 50 03 00 00       	mov    $0x350,%edx
  1cee77:	48 89 ee             	mov    %rbp,%rsi
  1cee7a:	41 ff d7             	call   *%r15
  1cee7d:	c6 84 24 0c 02 00 00 	movb   $0x1,0x20c(%rsp)
  1cee84:	01 
  1cee85:	49 83 fe fe          	cmp    $0xfffffffffffffffe,%r14
  1cee89:	4c 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%r15
  1cee90:	00 
  1cee91:	0f 85 d4 01 00 00    	jne    1cf06b <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xd1b>
  1cee97:	ff 15 2b 91 0f 01    	call   *0x10f912b(%rip)        # 12c7fc8 <_GLOBAL_OFFSET_TABLE_+0x4188>
  1cee9d:	0f b6 84 24 0c 02 00 	movzbl 0x20c(%rsp),%eax
  1ceea4:	00 
  1ceea5:	48 8d 0d c8 6b 99 00 	lea    0x996bc8(%rip),%rcx        # b65a74 <anon.1ff77c7c1c4ccf5bc9ac09e6755ce13a.72.llvm.508734745195800081+0x318e>
  1ceeac:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
  1ceeb0:	48 01 c8             	add    %rcx,%rax
  1ceeb3:	ff e0                	jmp    *%rax
  1ceeb5:	4c 8b ac 24 d0 00 00 	mov    0xd0(%rsp),%r13
  1ceebc:	00 
  1ceebd:	4c 8b a4 24 d8 00 00 	mov    0xd8(%rsp),%r12
  1ceec4:	00 
  1ceec5:	66 c7 84 24 3c 01 00 	movw   $0x0,0x13c(%rsp)
  1ceecc:	00 00 00 
  1ceecf:	8b ac 24 20 01 00 00 	mov    0x120(%rsp),%ebp
  1ceed6:	4c 8b b4 24 24 01 00 	mov    0x124(%rsp),%r14
  1ceedd:	00 
  1ceede:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  1ceee5:	00 
  1ceee6:	48 89 04 24          	mov    %rax,(%rsp)
  1ceeea:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
  1ceef1:	00 
  1ceef2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  1ceef7:	66 c7 84 24 38 01 00 	movw   $0x0,0x138(%rsp)
  1ceefe:	00 00 00 
  1cef01:	c6 84 24 3a 01 00 00 	movb   $0x0,0x13a(%rsp)
  1cef08:	00 
  1cef09:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
  1cef10:	00 
  1cef11:	f0 48 ff 08          	lock decq (%rax)
  1cef15:	4c 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%r15
  1cef1c:	00 
  1cef1d:	75 0e                	jne    1cef2d <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xbdd>
  1cef1f:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
  1cef26:	00 
  1cef27:	ff 15 a3 c8 0f 01    	call   *0x10fc8a3(%rip)        # 12cb7d0 <_GLOBAL_OFFSET_TABLE_+0x7990>
  1cef2d:	c7 84 24 3b 01 00 00 	movl   $0x1000000,0x13b(%rsp)
  1cef34:	00 00 00 01 
  1cef38:	83 fd fe             	cmp    $0xfffffffe,%ebp
  1cef3b:	0f 84 27 fc ff ff    	je     1ceb68 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x818>
  1cef41:	e9 35 fe ff ff       	jmp    1ced7b <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xa2b>
  1cef46:	44 88 a4 24 e0 02 00 	mov    %r12b,0x2e0(%rsp)
  1cef4d:	00 
  1cef4e:	8b 44 24 10          	mov    0x10(%rsp),%eax
  1cef52:	8b 4c 24 13          	mov    0x13(%rsp),%ecx
  1cef56:	89 84 24 e1 02 00 00 	mov    %eax,0x2e1(%rsp)
  1cef5d:	89 8c 24 e4 02 00 00 	mov    %ecx,0x2e4(%rsp)
  1cef64:	4c 89 bc 24 e8 02 00 	mov    %r15,0x2e8(%rsp)
  1cef6b:	00 
  1cef6c:	4c 89 b4 24 f0 02 00 	mov    %r14,0x2f0(%rsp)
  1cef73:	00 
  1cef74:	0f 28 84 24 b0 02 00 	movaps 0x2b0(%rsp),%xmm0
  1cef7b:	00 
  1cef7c:	0f 28 8c 24 c0 02 00 	movaps 0x2c0(%rsp),%xmm1
  1cef83:	00 
  1cef84:	0f 28 94 24 d0 02 00 	movaps 0x2d0(%rsp),%xmm2
  1cef8b:	00 
  1cef8c:	0f 11 84 24 f8 02 00 	movups %xmm0,0x2f8(%rsp)
  1cef93:	00 
  1cef94:	0f 11 8c 24 08 03 00 	movups %xmm1,0x308(%rsp)
  1cef9b:	00 
  1cef9c:	0f 11 94 24 18 03 00 	movups %xmm2,0x318(%rsp)
  1cefa3:	00 
  1cefa4:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  1cefab:	00 00 
  1cefad:	48 c7 44 24 20 01 00 	movq   $0x1,0x20(%rsp)
  1cefb4:	00 00 
  1cefb6:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
  1cefbd:	00 00 
  1cefbf:	48 c7 84 24 20 02 00 	movq   $0x60000020,0x220(%rsp)
  1cefc6:	00 20 00 00 60 
  1cefcb:	48 8d 44 24 18       	lea    0x18(%rsp),%rax
  1cefd0:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  1cefd7:	00 
  1cefd8:	48 8d 05 51 a1 09 01 	lea    0x109a151(%rip),%rax        # 1269130 <anon.a6257334ecde00274c07381362c94de0.1.llvm.11926555745833327518+0xe8>
  1cefdf:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
  1cefe6:	00 
  1cefe7:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
  1cefee:	00 
  1cefef:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
  1ceff6:	00 
  1ceff7:	ff 15 eb a4 0f 01    	call   *0x10fa4eb(%rip)        # 12c94e8 <_GLOBAL_OFFSET_TABLE_+0x56a8>
  1ceffd:	84 c0                	test   %al,%al
  1cefff:	0f 85 d3 00 00 00    	jne    1cf0d8 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xd88>
  1cf005:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  1cf00a:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  1cf00f:	48 89 04 24          	mov    %rax,(%rsp)
  1cf013:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  1cf018:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  1cf01d:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
  1cf024:	00 
  1cf025:	e8 36 21 00 00       	call   1d1160 <core::ptr::drop_glue::<wgpu::api::device::RequestDeviceError>>
  1cf02a:	45 31 ed             	xor    %r13d,%r13d
  1cf02d:	eb 10                	jmp    1cf03f <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xcef>
  1cf02f:	4c 8b a4 24 90 00 00 	mov    0x90(%rsp),%r12
  1cf036:	00 
  1cf037:	49 c1 e5 20          	shl    $0x20,%r13
  1cf03b:	49 83 cd 02          	or     $0x2,%r13
  1cf03f:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
  1cf044:	48 8d bc 24 28 06 00 	lea    0x628(%rsp),%rdi
  1cf04b:	00 
  1cf04c:	48 8d b4 24 78 09 00 	lea    0x978(%rsp),%rsi
  1cf053:	00 
  1cf054:	ba 50 03 00 00       	mov    $0x350,%edx
  1cf059:	ff 15 c9 52 0f 01    	call   *0x10f52c9(%rip)        # 12c4328 <memcpy@GLIBC_2.14>
  1cf05f:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
  1cf066:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
  1cf06b:	48 8b 9c 24 48 02 00 	mov    0x248(%rsp),%rbx
  1cf072:	00 
  1cf073:	48 8d 7b 28          	lea    0x28(%rbx),%rdi
  1cf077:	48 8d b4 24 28 06 00 	lea    0x628(%rsp),%rsi
  1cf07e:	00 
  1cf07f:	ba 50 03 00 00       	mov    $0x350,%edx
  1cf084:	ff 15 9e 52 0f 01    	call   *0x10f529e(%rip)        # 12c4328 <memcpy@GLIBC_2.14>
  1cf08a:	4c 89 33             	mov    %r14,(%rbx)
  1cf08d:	4c 89 6b 08          	mov    %r13,0x8(%rbx)
  1cf091:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  1cf096:	48 89 43 10          	mov    %rax,0x10(%rbx)
  1cf09a:	48 8b 04 24          	mov    (%rsp),%rax
  1cf09e:	48 89 43 18          	mov    %rax,0x18(%rbx)
  1cf0a2:	4c 89 63 20          	mov    %r12,0x20(%rbx)
  1cf0a6:	48 89 d8             	mov    %rbx,%rax
  1cf0a9:	48 81 c4 c8 0c 00 00 	add    $0xcc8,%rsp
  1cf0b0:	5b                   	pop    %rbx
  1cf0b1:	41 5c                	pop    %r12
  1cf0b3:	41 5d                	pop    %r13
  1cf0b5:	41 5e                	pop    %r14
  1cf0b7:	41 5f                	pop    %r15
  1cf0b9:	5d                   	pop    %rbp
  1cf0ba:	c3                   	ret
  1cf0bb:	48 8d 3d 78 a8 99 00 	lea    0x99a878(%rip),%rdi        # b6993a <anon.1ff77c7c1c4ccf5bc9ac09e6755ce13a.72.llvm.508734745195800081+0x7054>
  1cf0c2:	48 8d 15 97 a0 09 01 	lea    0x109a097(%rip),%rdx        # 1269160 <anon.a6257334ecde00274c07381362c94de0.1.llvm.11926555745833327518+0x118>
  1cf0c9:	be 37 00 00 00       	mov    $0x37,%esi
  1cf0ce:	e8 9d b5 eb ff       	call   8a670 <core::result::unwrap_failed::<core::fmt::Error>>
  1cf0d3:	e9 51 f3 ff ff       	jmp    1ce429 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xd9>
  1cf0d8:	48 8d 3d 5b a8 99 00 	lea    0x99a85b(%rip),%rdi        # b6993a <anon.1ff77c7c1c4ccf5bc9ac09e6755ce13a.72.llvm.508734745195800081+0x7054>
  1cf0df:	48 8d 15 7a a0 09 01 	lea    0x109a07a(%rip),%rdx        # 1269160 <anon.a6257334ecde00274c07381362c94de0.1.llvm.11926555745833327518+0x118>
  1cf0e6:	be 37 00 00 00       	mov    $0x37,%esi
  1cf0eb:	e8 80 b5 eb ff       	call   8a670 <core::result::unwrap_failed::<core::fmt::Error>>
  1cf0f0:	e9 34 f3 ff ff       	jmp    1ce429 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xd9>
  1cf0f5:	48 8d 3d 64 9f 09 01 	lea    0x1099f64(%rip),%rdi        # 1269060 <anon.a6257334ecde00274c07381362c94de0.1.llvm.11926555745833327518+0x18>
  1cf0fc:	ff 15 96 9f 0f 01    	call   *0x10f9f96(%rip)        # 12c9098 <_GLOBAL_OFFSET_TABLE_+0x5258>
  1cf102:	e9 22 f3 ff ff       	jmp    1ce429 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xd9>
  1cf107:	48 8d 3d 52 9f 09 01 	lea    0x1099f52(%rip),%rdi        # 1269060 <anon.a6257334ecde00274c07381362c94de0.1.llvm.11926555745833327518+0x18>
  1cf10e:	ff 15 b4 89 0f 01    	call   *0x10f89b4(%rip)        # 12c7ac8 <_GLOBAL_OFFSET_TABLE_+0x3c88>
  1cf114:	e9 10 f3 ff ff       	jmp    1ce429 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xd9>
  1cf119:	48 8d 3d a0 9f 09 01 	lea    0x1099fa0(%rip),%rdi        # 12690c0 <anon.a6257334ecde00274c07381362c94de0.1.llvm.11926555745833327518+0x78>
  1cf120:	ff 15 a2 89 0f 01    	call   *0x10f89a2(%rip)        # 12c7ac8 <_GLOBAL_OFFSET_TABLE_+0x3c88>
  1cf126:	e9 fe f2 ff ff       	jmp    1ce429 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xd9>
  1cf12b:	48 8d 3d 8e 9f 09 01 	lea    0x1099f8e(%rip),%rdi        # 12690c0 <anon.a6257334ecde00274c07381362c94de0.1.llvm.11926555745833327518+0x78>
  1cf132:	ff 15 60 9f 0f 01    	call   *0x10f9f60(%rip)        # 12c9098 <_GLOBAL_OFFSET_TABLE_+0x5258>
  1cf138:	e9 ec f2 ff ff       	jmp    1ce429 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xd9>
  1cf13d:	48 8d 3d 64 9f 09 01 	lea    0x1099f64(%rip),%rdi        # 12690a8 <anon.a6257334ecde00274c07381362c94de0.1.llvm.11926555745833327518+0x60>
  1cf144:	ff 15 7e 89 0f 01    	call   *0x10f897e(%rip)        # 12c7ac8 <_GLOBAL_OFFSET_TABLE_+0x3c88>
  1cf14a:	e9 da f2 ff ff       	jmp    1ce429 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xd9>
  1cf14f:	48 8d 3d 52 9f 09 01 	lea    0x1099f52(%rip),%rdi        # 12690a8 <anon.a6257334ecde00274c07381362c94de0.1.llvm.11926555745833327518+0x60>
  1cf156:	ff 15 3c 9f 0f 01    	call   *0x10f9f3c(%rip)        # 12c9098 <_GLOBAL_OFFSET_TABLE_+0x5258>
  1cf15c:	e9 c8 f2 ff ff       	jmp    1ce429 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xd9>
  1cf161:	49 89 c6             	mov    %rax,%r14
  1cf164:	e9 ef 01 00 00       	jmp    1cf358 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x1008>
  1cf169:	e9 99 00 00 00       	jmp    1cf207 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xeb7>
  1cf16e:	e9 9c 00 00 00       	jmp    1cf20f <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xebf>
  1cf173:	49 89 c6             	mov    %rax,%r14
  1cf176:	e9 8e 02 00 00       	jmp    1cf409 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x10b9>
  1cf17b:	49 89 c6             	mov    %rax,%r14
  1cf17e:	e9 5d 02 00 00       	jmp    1cf3e0 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x1090>
  1cf183:	e9 9f 00 00 00       	jmp    1cf227 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xed7>
  1cf188:	e9 4d 01 00 00       	jmp    1cf2da <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xf8a>
  1cf18d:	49 89 c6             	mov    %rax,%r14
  1cf190:	49 8b 77 08          	mov    0x8(%r15),%rsi
  1cf194:	48 85 f6             	test   %rsi,%rsi
  1cf197:	75 0d                	jne    1cf1a6 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xe56>
  1cf199:	4c 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%r15
  1cf1a0:	00 
  1cf1a1:	e9 5e 01 00 00       	jmp    1cf304 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xfb4>
  1cf1a6:	49 8b 57 10          	mov    0x10(%r15),%rdx
  1cf1aa:	48 89 ef             	mov    %rbp,%rdi
  1cf1ad:	ff 15 a5 72 0f 01    	call   *0x10f72a5(%rip)        # 12c6458 <_GLOBAL_OFFSET_TABLE_+0x2618>
  1cf1b3:	4c 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%r15
  1cf1ba:	00 
  1cf1bb:	e9 44 01 00 00       	jmp    1cf304 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xfb4>
  1cf1c0:	49 89 c6             	mov    %rax,%r14
  1cf1c3:	49 8b 75 08          	mov    0x8(%r13),%rsi
  1cf1c7:	48 85 f6             	test   %rsi,%rsi
  1cf1ca:	0f 84 b6 00 00 00    	je     1cf286 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xf36>
  1cf1d0:	49 8b 55 10          	mov    0x10(%r13),%rdx
  1cf1d4:	48 89 ef             	mov    %rbp,%rdi
  1cf1d7:	ff 15 7b 72 0f 01    	call   *0x10f727b(%rip)        # 12c6458 <_GLOBAL_OFFSET_TABLE_+0x2618>
  1cf1dd:	e9 a4 00 00 00       	jmp    1cf286 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xf36>
  1cf1e2:	49 89 c6             	mov    %rax,%r14
  1cf1e5:	e9 29 02 00 00       	jmp    1cf413 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x10c3>
  1cf1ea:	49 89 c6             	mov    %rax,%r14
  1cf1ed:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
  1cf1f4:	00 
  1cf1f5:	e8 66 16 00 00       	call   1d0860 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>>
  1cf1fa:	e9 7e 02 00 00       	jmp    1cf47d <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x112d>
  1cf1ff:	49 89 c6             	mov    %rax,%r14
  1cf202:	e9 14 02 00 00       	jmp    1cf41b <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x10cb>
  1cf207:	49 89 c6             	mov    %rax,%r14
  1cf20a:	e9 1b 01 00 00       	jmp    1cf32a <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xfda>
  1cf20f:	49 89 c6             	mov    %rax,%r14
  1cf212:	e9 84 01 00 00       	jmp    1cf39b <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x104b>
  1cf217:	49 89 c6             	mov    %rax,%r14
  1cf21a:	e9 13 01 00 00       	jmp    1cf332 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xfe2>
  1cf21f:	49 89 c6             	mov    %rax,%r14
  1cf222:	e9 8b 01 00 00       	jmp    1cf3b2 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x1062>
  1cf227:	49 89 c6             	mov    %rax,%r14
  1cf22a:	e9 d5 00 00 00       	jmp    1cf304 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xfb4>
  1cf22f:	49 89 c6             	mov    %rax,%r14
  1cf232:	e9 21 01 00 00       	jmp    1cf358 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x1008>
  1cf237:	eb 25                	jmp    1cf25e <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xf0e>
  1cf239:	49 89 c6             	mov    %rax,%r14
  1cf23c:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
  1cf243:	00 
  1cf244:	48 8b b4 24 c8 00 00 	mov    0xc8(%rsp),%rsi
  1cf24b:	00 
  1cf24c:	e8 df 08 00 00       	call   1cfb30 <core::ptr::drop_glue::<core::pin::Pin<alloc::boxed::Box<dyn wgpu::dispatch::PopErrorScopeFuture<Output = core::option::Option<wgpu::api::device::Error>>>>>>
  1cf251:	e9 ae 00 00 00       	jmp    1cf304 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xfb4>
  1cf256:	49 89 c6             	mov    %rax,%r14
  1cf259:	e9 15 02 00 00       	jmp    1cf473 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x1123>
  1cf25e:	49 89 c6             	mov    %rax,%r14
  1cf261:	e9 05 02 00 00       	jmp    1cf46b <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x111b>
  1cf266:	49 89 c6             	mov    %rax,%r14
  1cf269:	e9 17 02 00 00       	jmp    1cf485 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x1135>
  1cf26e:	49 89 c6             	mov    %rax,%r14
  1cf271:	48 8b bc 24 e8 01 00 	mov    0x1e8(%rsp),%rdi
  1cf278:	00 
  1cf279:	48 8b b4 24 f0 01 00 	mov    0x1f0(%rsp),%rsi
  1cf280:	00 
  1cf281:	e8 aa 08 00 00       	call   1cfb30 <core::ptr::drop_glue::<core::pin::Pin<alloc::boxed::Box<dyn wgpu::dispatch::PopErrorScopeFuture<Output = core::option::Option<wgpu::api::device::Error>>>>>>
  1cf286:	c6 84 24 f8 01 00 00 	movb   $0x2,0x1f8(%rsp)
  1cf28d:	02 
  1cf28e:	eb 09                	jmp    1cf299 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xf49>
  1cf290:	ff 15 72 b7 0f 01    	call   *0x10fb772(%rip)        # 12caa08 <_GLOBAL_OFFSET_TABLE_+0x6bc8>
  1cf296:	49 89 c6             	mov    %rax,%r14
  1cf299:	48 8d bc 24 d8 01 00 	lea    0x1d8(%rsp),%rdi
  1cf2a0:	00 
  1cf2a1:	e8 7a 12 00 00       	call   1d0520 <core::ptr::drop_glue::<<wgpu::api::instance::Instance>::request_adapter::{closure#0}>>
  1cf2a6:	e9 c0 01 00 00       	jmp    1cf46b <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x111b>
  1cf2ab:	49 89 c6             	mov    %rax,%r14
  1cf2ae:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1cf2b3:	48 85 f6             	test   %rsi,%rsi
  1cf2b6:	74 10                	je     1cf2c8 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xf78>
  1cf2b8:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  1cf2bd:	ba 01 00 00 00       	mov    $0x1,%edx
  1cf2c2:	ff 15 90 71 0f 01    	call   *0x10f7190(%rip)        # 12c6458 <_GLOBAL_OFFSET_TABLE_+0x2618>
  1cf2c8:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
  1cf2cf:	00 
  1cf2d0:	e8 8b 1e 00 00       	call   1d1160 <core::ptr::drop_glue::<wgpu::api::device::RequestDeviceError>>
  1cf2d5:	e9 91 01 00 00       	jmp    1cf46b <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x111b>
  1cf2da:	49 89 c6             	mov    %rax,%r14
  1cf2dd:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  1cf2e2:	48 85 f6             	test   %rsi,%rsi
  1cf2e5:	74 10                	je     1cf2f7 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xfa7>
  1cf2e7:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
  1cf2ec:	ba 01 00 00 00       	mov    $0x1,%edx
  1cf2f1:	ff 15 61 71 0f 01    	call   *0x10f7161(%rip)        # 12c6458 <_GLOBAL_OFFSET_TABLE_+0x2618>
  1cf2f7:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
  1cf2fe:	00 
  1cf2ff:	e8 4c 20 00 00       	call   1d1350 <core::ptr::drop_glue::<wgpu::api::device::Error>>
  1cf304:	80 bc 24 38 01 00 00 	cmpb   $0x1,0x138(%rsp)
  1cf30b:	01 
  1cf30c:	75 1c                	jne    1cf32a <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xfda>
  1cf30e:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
  1cf315:	00 
  1cf316:	f0 48 ff 08          	lock decq (%rax)
  1cf31a:	75 0e                	jne    1cf32a <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0xfda>
  1cf31c:	48 8d bc 24 08 01 00 	lea    0x108(%rsp),%rdi
  1cf323:	00 
  1cf324:	ff 15 f6 70 0f 01    	call   *0x10f70f6(%rip)        # 12c6420 <_GLOBAL_OFFSET_TABLE_+0x25e0>
  1cf32a:	c6 84 24 38 01 00 00 	movb   $0x0,0x138(%rsp)
  1cf331:	00 
  1cf332:	80 bc 24 39 01 00 00 	cmpb   $0x0,0x139(%rsp)
  1cf339:	00 
  1cf33a:	74 1c                	je     1cf358 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x1008>
  1cf33c:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  1cf343:	00 
  1cf344:	f0 48 ff 08          	lock decq (%rax)
  1cf348:	75 0e                	jne    1cf358 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x1008>
  1cf34a:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
  1cf351:	00 
  1cf352:	ff 15 b0 71 0f 01    	call   *0x10f71b0(%rip)        # 12c6508 <_GLOBAL_OFFSET_TABLE_+0x26c8>
  1cf358:	c6 84 24 39 01 00 00 	movb   $0x0,0x139(%rsp)
  1cf35f:	00 
  1cf360:	80 bc 24 3a 01 00 00 	cmpb   $0x0,0x13a(%rsp)
  1cf367:	00 
  1cf368:	74 0d                	je     1cf377 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x1027>
  1cf36a:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
  1cf371:	00 
  1cf372:	e8 79 09 00 00       	call   1cfcf0 <core::ptr::drop_glue::<core::option::Option<(wgpu::api::shader_module::ShaderModule, wgpu::api::bind_group_layout::BindGroupLayout, wgpu::api::pipeline_layout::PipelineLayout)>>>
  1cf377:	c6 84 24 3a 01 00 00 	movb   $0x0,0x13a(%rsp)
  1cf37e:	00 
  1cf37f:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
  1cf386:	00 
  1cf387:	f0 48 ff 08          	lock decq (%rax)
  1cf38b:	75 0e                	jne    1cf39b <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x104b>
  1cf38d:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
  1cf394:	00 
  1cf395:	ff 15 35 c4 0f 01    	call   *0x10fc435(%rip)        # 12cb7d0 <_GLOBAL_OFFSET_TABLE_+0x7990>
  1cf39b:	80 bc 24 3b 01 00 00 	cmpb   $0x0,0x13b(%rsp)
  1cf3a2:	00 
  1cf3a3:	74 0d                	je     1cf3b2 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x1062>
  1cf3a5:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
  1cf3ac:	00 
  1cf3ad:	e8 4e 1d 00 00       	call   1d1100 <core::ptr::drop_glue::<wgpu::api::device::ErrorScopeGuard>>
  1cf3b2:	c6 84 24 3b 01 00 00 	movb   $0x0,0x13b(%rsp)
  1cf3b9:	00 
  1cf3ba:	80 bc 24 3c 01 00 00 	cmpb   $0x0,0x13c(%rsp)
  1cf3c1:	00 
  1cf3c2:	74 1c                	je     1cf3e0 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x1090>
  1cf3c4:	48 8b 84 24 d8 00 00 	mov    0xd8(%rsp),%rax
  1cf3cb:	00 
  1cf3cc:	f0 48 ff 08          	lock decq (%rax)
  1cf3d0:	75 0e                	jne    1cf3e0 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x1090>
  1cf3d2:	48 8d bc 24 d8 00 00 	lea    0xd8(%rsp),%rdi
  1cf3d9:	00 
  1cf3da:	ff 15 40 7f 0f 01    	call   *0x10f7f40(%rip)        # 12c7320 <_GLOBAL_OFFSET_TABLE_+0x34e0>
  1cf3e0:	c6 84 24 3c 01 00 00 	movb   $0x0,0x13c(%rsp)
  1cf3e7:	00 
  1cf3e8:	80 bc 24 3d 01 00 00 	cmpb   $0x0,0x13d(%rsp)
  1cf3ef:	00 
  1cf3f0:	74 17                	je     1cf409 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x10b9>
  1cf3f2:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  1cf3f9:	00 
  1cf3fa:	f0 48 ff 08          	lock decq (%rax)
  1cf3fe:	75 09                	jne    1cf409 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x10b9>
  1cf400:	4c 89 ff             	mov    %r15,%rdi
  1cf403:	ff 15 ff 69 0f 01    	call   *0x10f69ff(%rip)        # 12c5e08 <_GLOBAL_OFFSET_TABLE_+0x1fc8>
  1cf409:	66 c7 84 24 3d 01 00 	movw   $0x200,0x13d(%rsp)
  1cf410:	00 00 02 
  1cf413:	48 89 df             	mov    %rbx,%rdi
  1cf416:	e8 a5 0e 00 00       	call   1d02c0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  1cf41b:	80 bc 24 99 00 00 00 	cmpb   $0x0,0x99(%rsp)
  1cf422:	00 
  1cf423:	74 16                	je     1cf43b <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x10eb>
  1cf425:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  1cf42a:	f0 48 ff 08          	lock decq (%rax)
  1cf42e:	75 0b                	jne    1cf43b <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x10eb>
  1cf430:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
  1cf435:	ff 15 e5 7e 0f 01    	call   *0x10f7ee5(%rip)        # 12c7320 <_GLOBAL_OFFSET_TABLE_+0x34e0>
  1cf43b:	c6 84 24 99 00 00 00 	movb   $0x0,0x99(%rsp)
  1cf442:	00 
  1cf443:	80 bc 24 9a 00 00 00 	cmpb   $0x0,0x9a(%rsp)
  1cf44a:	00 
  1cf44b:	74 16                	je     1cf463 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x1113>
  1cf44d:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  1cf452:	f0 48 ff 08          	lock decq (%rax)
  1cf456:	75 0b                	jne    1cf463 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x1113>
  1cf458:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
  1cf45d:	ff 15 a5 69 0f 01    	call   *0x10f69a5(%rip)        # 12c5e08 <_GLOBAL_OFFSET_TABLE_+0x1fc8>
  1cf463:	c6 84 24 9a 00 00 00 	movb   $0x0,0x9a(%rsp)
  1cf46a:	00 
  1cf46b:	c6 84 24 98 00 00 00 	movb   $0x2,0x98(%rsp)
  1cf472:	02 
  1cf473:	48 8d 7c 24 78       	lea    0x78(%rsp),%rdi
  1cf478:	e8 63 10 00 00       	call   1d04e0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>>
  1cf47d:	c6 84 24 0c 02 00 00 	movb   $0x2,0x20c(%rsp)
  1cf484:	02 
  1cf485:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
  1cf48a:	e8 e1 05 00 00       	call   1cfa70 <core::ptr::drop_glue::<core::pin::PinMacroHelper<<gpui_gpu::renderer::Renderer>::request::{closure#0}>>>
  1cf48f:	4c 89 f7             	mov    %r14,%rdi
  1cf492:	e8 a9 8b eb ff       	call   88040 <_Unwind_Resume@plt>
  1cf497:	ff 15 6b b5 0f 01    	call   *0x10fb56b(%rip)        # 12caa08 <_GLOBAL_OFFSET_TABLE_+0x6bc8>
  1cf49d:	ff 15 65 b5 0f 01    	call   *0x10fb565(%rip)        # 12caa08 <_GLOBAL_OFFSET_TABLE_+0x6bc8>
  1cf4a3:	ff 15 5f b5 0f 01    	call   *0x10fb55f(%rip)        # 12caa08 <_GLOBAL_OFFSET_TABLE_+0x6bc8>
  1cf4a9:	ff 15 59 b5 0f 01    	call   *0x10fb559(%rip)        # 12caa08 <_GLOBAL_OFFSET_TABLE_+0x6bc8>
