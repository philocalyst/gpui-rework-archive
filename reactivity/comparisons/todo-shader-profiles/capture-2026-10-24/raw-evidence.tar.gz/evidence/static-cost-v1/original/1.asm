
/home/miles/gpui-ce3-compute-20261024/evidence/todo-shader-profiles/attempt2/builds/original/todo_comparison_mapped:     file format elf64-x86-64


Disassembly of section .text:

0000000000523bc0 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  523bc0:	55                   	push   %rbp
  523bc1:	41 57                	push   %r15
  523bc3:	41 56                	push   %r14
  523bc5:	41 55                	push   %r13
  523bc7:	41 54                	push   %r12
  523bc9:	53                   	push   %rbx
  523bca:	48 81 ec f8 02 00 00 	sub    $0x2f8,%rsp
  523bd1:	f3 0f 10 9a 88 00 00 	movss  0x88(%rdx),%xmm3
  523bd8:	00 
  523bd9:	f3 0f 10 05 a7 1b 60 	movss  0x601ba7(%rip),%xmm0        # b25788 <anon.9adf6b51329d0e8f0ba7a07edbf8a285.69.llvm.2988996700849332186+0x14>
  523be0:	00 
  523be1:	0f 28 cb             	movaps %xmm3,%xmm1
  523be4:	f3 0f 5c c8          	subss  %xmm0,%xmm1
  523be8:	f3 48 0f 2c c1       	cvttss2si %xmm1,%rax
  523bed:	f3 4c 0f 2c d3       	cvttss2si %xmm3,%r10
  523bf2:	4d 89 d3             	mov    %r10,%r11
  523bf5:	49 c1 fb 3f          	sar    $0x3f,%r11
  523bf9:	49 21 c3             	and    %rax,%r11
  523bfc:	4d 09 d3             	or     %r10,%r11
  523bff:	45 31 d2             	xor    %r10d,%r10d
  523c02:	0f 57 c9             	xorps  %xmm1,%xmm1
  523c05:	0f 2e d9             	ucomiss %xmm1,%xmm3
  523c08:	4d 0f 42 da          	cmovb  %r10,%r11
  523c0c:	f3 0f 10 a2 90 00 00 	movss  0x90(%rdx),%xmm4
  523c13:	00 
  523c14:	f3 0f 10 15 70 1b 60 	movss  0x601b70(%rip),%xmm2        # b2578c <anon.9adf6b51329d0e8f0ba7a07edbf8a285.69.llvm.2988996700849332186+0x18>
  523c1b:	00 
  523c1c:	0f 2e da             	ucomiss %xmm2,%xmm3
  523c1f:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
  523c26:	4d 0f 47 de          	cmova  %r14,%r11
  523c2a:	0f 28 dc             	movaps %xmm4,%xmm3
  523c2d:	f3 0f 5c d8          	subss  %xmm0,%xmm3
  523c31:	f3 48 0f 2c c3       	cvttss2si %xmm3,%rax
  523c36:	f3 48 0f 2c dc       	cvttss2si %xmm4,%rbx
  523c3b:	49 89 df             	mov    %rbx,%r15
  523c3e:	49 c1 ff 3f          	sar    $0x3f,%r15
  523c42:	49 21 c7             	and    %rax,%r15
  523c45:	49 09 df             	or     %rbx,%r15
  523c48:	0f 2e e1             	ucomiss %xmm1,%xmm4
  523c4b:	4d 0f 42 fa          	cmovb  %r10,%r15
  523c4f:	0f 2e e2             	ucomiss %xmm2,%xmm4
  523c52:	4d 0f 47 fe          	cmova  %r14,%r15
  523c56:	f3 0f 10 9a 8c 00 00 	movss  0x8c(%rdx),%xmm3
  523c5d:	00 
  523c5e:	4b 8d 04 3b          	lea    (%r11,%r15,1),%rax
  523c62:	48 ff c8             	dec    %rax
  523c65:	48 c1 e8 04          	shr    $0x4,%rax
  523c69:	49 c1 eb 04          	shr    $0x4,%r11
  523c6d:	49 89 c5             	mov    %rax,%r13
  523c70:	4d 29 dd             	sub    %r11,%r13
  523c73:	49 ff c5             	inc    %r13
  523c76:	0f 28 e3             	movaps %xmm3,%xmm4
  523c79:	f3 0f 5c e0          	subss  %xmm0,%xmm4
  523c7d:	f3 4c 0f 2c e4       	cvttss2si %xmm4,%r12
  523c82:	f3 4c 0f 2c fb       	cvttss2si %xmm3,%r15
  523c87:	4c 89 fb             	mov    %r15,%rbx
  523c8a:	48 c1 fb 3f          	sar    $0x3f,%rbx
  523c8e:	4c 21 e3             	and    %r12,%rbx
  523c91:	4c 09 fb             	or     %r15,%rbx
  523c94:	0f 2e d9             	ucomiss %xmm1,%xmm3
  523c97:	49 0f 42 da          	cmovb  %r10,%rbx
  523c9b:	0f 2e da             	ucomiss %xmm2,%xmm3
  523c9e:	f3 0f 10 9a 94 00 00 	movss  0x94(%rdx),%xmm3
  523ca5:	00 
  523ca6:	49 0f 47 de          	cmova  %r14,%rbx
  523caa:	0f 28 e3             	movaps %xmm3,%xmm4
  523cad:	f3 0f 5c e0          	subss  %xmm0,%xmm4
  523cb1:	f3 48 0f 2c ec       	cvttss2si %xmm4,%rbp
  523cb6:	f3 4c 0f 2c fb       	cvttss2si %xmm3,%r15
  523cbb:	4d 89 fc             	mov    %r15,%r12
  523cbe:	49 c1 fc 3f          	sar    $0x3f,%r12
  523cc2:	49 21 ec             	and    %rbp,%r12
  523cc5:	4d 09 fc             	or     %r15,%r12
  523cc8:	0f 2e d9             	ucomiss %xmm1,%xmm3
  523ccb:	4d 0f 42 e2          	cmovb  %r10,%r12
  523ccf:	0f 2e da             	ucomiss %xmm2,%xmm3
  523cd2:	4d 0f 47 e6          	cmova  %r14,%r12
  523cd6:	4e 8d 34 23          	lea    (%rbx,%r12,1),%r14
  523cda:	49 ff ce             	dec    %r14
  523cdd:	49 c1 ee 04          	shr    $0x4,%r14
  523ce1:	48 c1 eb 04          	shr    $0x4,%rbx
  523ce5:	4d 89 f7             	mov    %r14,%r15
  523ce8:	49 29 df             	sub    %rbx,%r15
  523ceb:	49 ff c7             	inc    %r15
  523cee:	4d 0f af fd          	imul   %r13,%r15
  523cf2:	4c 03 bc 24 48 03 00 	add    0x348(%rsp),%r15
  523cf9:	00 
  523cfa:	41 0f 92 c2          	setb   %r10b
  523cfe:	49 81 ff 01 00 40 00 	cmp    $0x400001,%r15
  523d05:	40 0f 93 c5          	setae  %bpl
  523d09:	44 08 d5             	or     %r10b,%bpl
  523d0c:	41 ba 06 00 00 00    	mov    $0x6,%r10d
  523d12:	0f 85 83 0f 00 00    	jne    524c9b <<gpui_gpu::renderer::RendererState>::bin_draw+0x10db>
  523d18:	44 89 84 24 bc 00 00 	mov    %r8d,0xbc(%rsp)
  523d1f:	00 
  523d20:	4c 89 8c 24 a0 00 00 	mov    %r9,0xa0(%rsp)
  523d27:	00 
  523d28:	4c 89 bc 24 88 01 00 	mov    %r15,0x188(%rsp)
  523d2f:	00 
  523d30:	48 89 bc 24 90 01 00 	mov    %rdi,0x190(%rsp)
  523d37:	00 
  523d38:	49 39 de             	cmp    %rbx,%r14
  523d3b:	0f 82 40 0f 00 00    	jb     524c81 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  523d41:	4c 39 d8             	cmp    %r11,%rax
  523d44:	0f 82 37 0f 00 00    	jb     524c81 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  523d4a:	48 8b ac 24 30 03 00 	mov    0x330(%rsp),%rbp
  523d51:	00 
  523d52:	4c 8b 66 20          	mov    0x20(%rsi),%r12
  523d56:	48 89 f7             	mov    %rsi,%rdi
  523d59:	48 8b 76 28          	mov    0x28(%rsi),%rsi
  523d5d:	48 89 bc 24 c0 00 00 	mov    %rdi,0xc0(%rsp)
  523d64:	00 
  523d65:	80 bf 40 03 00 00 00 	cmpb   $0x0,0x340(%rdi)
  523d6c:	0f 84 cb 0d 00 00    	je     524b3d <<gpui_gpu::renderer::RendererState>::bin_draw+0xf7d>
  523d72:	80 3a 00             	cmpb   $0x0,(%rdx)
  523d75:	0f 85 08 0e 00 00    	jne    524b83 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfc3>
  523d7b:	f3 0f 10 82 a4 00 00 	movss  0xa4(%rdx),%xmm0
  523d82:	00 
  523d83:	0f 2e 05 32 19 60 00 	ucomiss 0x601932(%rip),%xmm0        # b256bc <anon.65fa6619250d5a71bfd5ef20e1dfbaf0.11.llvm.7726090819372637783+0x8>
  523d8a:	0f 85 f3 0d 00 00    	jne    524b83 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfc3>
  523d90:	0f 8a ed 0d 00 00    	jp     524b83 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfc3>
  523d96:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
  523d9d:	00 
  523d9e:	8b ba 98 00 00 00    	mov    0x98(%rdx),%edi
  523da4:	41 89 ff             	mov    %edi,%r15d
  523da7:	41 81 e7 00 00 80 7f 	and    $0x7f800000,%r15d
  523dae:	41 ff cf             	dec    %r15d
  523db1:	44 8b 8a 9c 00 00 00 	mov    0x9c(%rdx),%r9d
  523db8:	45 89 cd             	mov    %r9d,%r13d
  523dbb:	41 81 e5 00 00 80 7f 	and    $0x7f800000,%r13d
  523dc2:	41 ff cd             	dec    %r13d
  523dc5:	44 8b 82 a0 00 00 00 	mov    0xa0(%rdx),%r8d
  523dcc:	45 89 c2             	mov    %r8d,%r10d
  523dcf:	41 81 e2 00 00 80 7f 	and    $0x7f800000,%r10d
  523dd6:	41 ff ca             	dec    %r10d
  523dd9:	48 85 ed             	test   %rbp,%rbp
  523ddc:	0f 84 e4 0d 00 00    	je     524bc6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1006>
  523de2:	41 81 fa ff ff 7f 7f 	cmp    $0x7f7fffff,%r10d
  523de9:	0f 92 c0             	setb   %al
  523dec:	45 85 c0             	test   %r8d,%r8d
  523def:	41 0f 99 c2          	setns  %r10b
  523df3:	41 81 fd ff ff 7f 7f 	cmp    $0x7f7fffff,%r13d
  523dfa:	41 0f 92 c0          	setb   %r8b
  523dfe:	45 85 c9             	test   %r9d,%r9d
  523e01:	41 0f 99 c5          	setns  %r13b
  523e05:	41 81 ff ff ff 7f 7f 	cmp    $0x7f7fffff,%r15d
  523e0c:	41 0f 92 c7          	setb   %r15b
  523e10:	85 ff                	test   %edi,%edi
  523e12:	40 0f 99 c7          	setns  %dil
  523e16:	44 08 ff             	or     %r15b,%dil
  523e19:	40 80 ff 01          	cmp    $0x1,%dil
  523e1d:	0f 85 0d 0e 00 00    	jne    524c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1070>
  523e23:	45 08 c5             	or     %r8b,%r13b
  523e26:	0f 84 04 0e 00 00    	je     524c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1070>
  523e2c:	41 08 c2             	or     %al,%r10b
  523e2f:	0f 84 fb 0d 00 00    	je     524c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1070>
  523e35:	44 8b 94 24 40 03 00 	mov    0x340(%rsp),%r10d
  523e3c:	00 
  523e3d:	44 8b bc 24 38 03 00 	mov    0x338(%rsp),%r15d
  523e44:	00 
  523e45:	66 0f 6e d1          	movd   %ecx,%xmm2
  523e49:	48 c1 e9 20          	shr    $0x20,%rcx
  523e4d:	f3 0f 10 42 78       	movss  0x78(%rdx),%xmm0
  523e52:	f3 0f 10 9a 80 00 00 	movss  0x80(%rdx),%xmm3
  523e59:	00 
  523e5a:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  523e5e:	f3 0f 10 a2 84 00 00 	movss  0x84(%rdx),%xmm4
  523e65:	00 
  523e66:	f3 0f 10 4a 7c       	movss  0x7c(%rdx),%xmm1
  523e6b:	f3 0f 5a c9          	cvtss2sd %xmm1,%xmm1
  523e6f:	f3 0f 5a db          	cvtss2sd %xmm3,%xmm3
  523e73:	f3 0f 5a e4          	cvtss2sd %xmm4,%xmm4
  523e77:	f2 0f 58 d8          	addsd  %xmm0,%xmm3
  523e7b:	f2 0f 11 9c 24 a8 01 	movsd  %xmm3,0x1a8(%rsp)
  523e82:	00 00 
  523e84:	f2 0f 58 e1          	addsd  %xmm1,%xmm4
  523e88:	f2 0f 11 a4 24 a0 01 	movsd  %xmm4,0x1a0(%rsp)
  523e8f:	00 00 
  523e91:	f2 0f 10 62 48       	movsd  0x48(%rdx),%xmm4
  523e96:	f2 0f 10 6a 58       	movsd  0x58(%rdx),%xmm5
  523e9b:	f2 0f 10 72 68       	movsd  0x68(%rdx),%xmm6
  523ea0:	f3 0f 10 5a 38       	movss  0x38(%rdx),%xmm3
  523ea5:	f3 0f 5a fb          	cvtss2sd %xmm3,%xmm7
  523ea9:	f3 0f 10 5a 40       	movss  0x40(%rdx),%xmm3
  523eae:	f3 0f 5a db          	cvtss2sd %xmm3,%xmm3
  523eb2:	44 0f 28 05 26 a9 5f 	movaps 0x5fa926(%rip),%xmm8        # b1e7e0 <anon.53de480418173883b8e15d81740454e2.346.llvm.622318203107919755+0x308>
  523eb9:	00 
  523eba:	0f 29 bc 24 80 00 00 	movaps %xmm7,0x80(%rsp)
  523ec1:	00 
  523ec2:	41 0f 54 f8          	andps  %xmm8,%xmm7
  523ec6:	0f 29 7c 24 70       	movaps %xmm7,0x70(%rsp)
  523ecb:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
  523ed0:	41 0f 54 d8          	andps  %xmm8,%xmm3
  523ed4:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
  523ed9:	f3 0f 5a d2          	cvtss2sd %xmm2,%xmm2
  523edd:	f2 0f 11 54 24 08    	movsd  %xmm2,0x8(%rsp)
  523ee3:	0f 28 d4             	movaps %xmm4,%xmm2
  523ee6:	41 0f 54 d0          	andps  %xmm8,%xmm2
  523eea:	0f 29 94 24 50 02 00 	movaps %xmm2,0x250(%rsp)
  523ef1:	00 
  523ef2:	0f 28 d5             	movaps %xmm5,%xmm2
  523ef5:	41 0f 54 d0          	andps  %xmm8,%xmm2
  523ef9:	0f 29 94 24 30 02 00 	movaps %xmm2,0x230(%rsp)
  523f00:	00 
  523f01:	0f 28 d6             	movaps %xmm6,%xmm2
  523f04:	41 0f 54 d0          	andps  %xmm8,%xmm2
  523f08:	0f 29 94 24 20 01 00 	movaps %xmm2,0x120(%rsp)
  523f0f:	00 
  523f10:	f3 0f 10 52 3c       	movss  0x3c(%rdx),%xmm2
  523f15:	0f 57 db             	xorps  %xmm3,%xmm3
  523f18:	f3 0f 5a da          	cvtss2sd %xmm2,%xmm3
  523f1c:	f3 0f 10 52 44       	movss  0x44(%rdx),%xmm2
  523f21:	0f 57 ff             	xorps  %xmm7,%xmm7
  523f24:	f3 0f 5a fa          	cvtss2sd %xmm2,%xmm7
  523f28:	0f 29 5c 24 40       	movaps %xmm3,0x40(%rsp)
  523f2d:	41 0f 54 d8          	andps  %xmm8,%xmm3
  523f31:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
  523f36:	66 0f 6e d1          	movd   %ecx,%xmm2
  523f3a:	f3 0f 5a d2          	cvtss2sd %xmm2,%xmm2
  523f3e:	f2 0f 11 14 24       	movsd  %xmm2,(%rsp)
  523f43:	0f 29 7c 24 10       	movaps %xmm7,0x10(%rsp)
  523f48:	41 0f 54 f8          	andps  %xmm8,%xmm7
  523f4c:	0f 29 7c 24 20       	movaps %xmm7,0x20(%rsp)
  523f51:	f2 0f 10 5a 50       	movsd  0x50(%rdx),%xmm3
  523f56:	0f 28 d3             	movaps %xmm3,%xmm2
  523f59:	41 0f 54 d0          	andps  %xmm8,%xmm2
  523f5d:	0f 29 94 24 d0 01 00 	movaps %xmm2,0x1d0(%rsp)
  523f64:	00 
  523f65:	f2 0f 10 7a 60       	movsd  0x60(%rdx),%xmm7
  523f6a:	0f 28 d7             	movaps %xmm7,%xmm2
  523f6d:	41 0f 54 d0          	andps  %xmm8,%xmm2
  523f71:	0f 29 94 24 b0 01 00 	movaps %xmm2,0x1b0(%rsp)
  523f78:	00 
  523f79:	f2 44 0f 10 4a 70    	movsd  0x70(%rdx),%xmm9
  523f7f:	41 0f 28 d1          	movaps %xmm9,%xmm2
  523f83:	41 0f 54 d0          	andps  %xmm8,%xmm2
  523f87:	0f 29 94 24 e0 00 00 	movaps %xmm2,0xe0(%rsp)
  523f8e:	00 
  523f8f:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  523f96:	00 
  523f97:	48 8b 48 58          	mov    0x58(%rax),%rcx
  523f9b:	48 89 8c 24 d8 00 00 	mov    %rcx,0xd8(%rsp)
  523fa2:	00 
  523fa3:	48 8b 40 50          	mov    0x50(%rax),%rax
  523fa7:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
  523fae:	00 
  523faf:	0f 29 a4 24 60 02 00 	movaps %xmm4,0x260(%rsp)
  523fb6:	00 
  523fb7:	0f 57 d2             	xorps  %xmm2,%xmm2
  523fba:	f2 0f 5a d4          	cvtsd2ss %xmm4,%xmm2
  523fbe:	0f 57 e4             	xorps  %xmm4,%xmm4
  523fc1:	f3 0f 5a e2          	cvtss2sd %xmm2,%xmm4
  523fc5:	0f 29 9c 24 e0 01 00 	movaps %xmm3,0x1e0(%rsp)
  523fcc:	00 
  523fcd:	0f 57 d2             	xorps  %xmm2,%xmm2
  523fd0:	f2 0f 5a d3          	cvtsd2ss %xmm3,%xmm2
  523fd4:	0f 57 db             	xorps  %xmm3,%xmm3
  523fd7:	f3 0f 5a da          	cvtss2sd %xmm2,%xmm3
  523fdb:	0f 29 ac 24 40 02 00 	movaps %xmm5,0x240(%rsp)
  523fe2:	00 
  523fe3:	0f 57 d2             	xorps  %xmm2,%xmm2
  523fe6:	f2 0f 5a d5          	cvtsd2ss %xmm5,%xmm2
  523fea:	0f 57 ed             	xorps  %xmm5,%xmm5
  523fed:	f3 0f 5a ea          	cvtss2sd %xmm2,%xmm5
  523ff1:	0f 29 bc 24 c0 01 00 	movaps %xmm7,0x1c0(%rsp)
  523ff8:	00 
  523ff9:	0f 57 d2             	xorps  %xmm2,%xmm2
  523ffc:	f2 0f 5a d7          	cvtsd2ss %xmm7,%xmm2
  524000:	0f 57 ff             	xorps  %xmm7,%xmm7
  524003:	f3 0f 5a fa          	cvtss2sd %xmm2,%xmm7
  524007:	0f 29 b4 24 30 01 00 	movaps %xmm6,0x130(%rsp)
  52400e:	00 
  52400f:	0f 57 d2             	xorps  %xmm2,%xmm2
  524012:	f2 0f 5a d6          	cvtsd2ss %xmm6,%xmm2
  524016:	f3 0f 5a f2          	cvtss2sd %xmm2,%xmm6
  52401a:	44 0f 29 8c 24 f0 00 	movaps %xmm9,0xf0(%rsp)
  524021:	00 00 
  524023:	0f 57 d2             	xorps  %xmm2,%xmm2
  524026:	f2 41 0f 5a d1       	cvtsd2ss %xmm9,%xmm2
  52402b:	f3 0f 5a d2          	cvtss2sd %xmm2,%xmm2
  52402f:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  524036:	00 
  524037:	ff c0                	inc    %eax
  524039:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  524040:	00 
  524041:	0f 29 a4 24 a0 02 00 	movaps %xmm4,0x2a0(%rsp)
  524048:	00 
  524049:	41 0f 54 e0          	andps  %xmm8,%xmm4
  52404d:	0f 29 a4 24 90 02 00 	movaps %xmm4,0x290(%rsp)
  524054:	00 
  524055:	0f 29 ac 24 80 02 00 	movaps %xmm5,0x280(%rsp)
  52405c:	00 
  52405d:	41 0f 54 e8          	andps  %xmm8,%xmm5
  524061:	0f 29 ac 24 70 02 00 	movaps %xmm5,0x270(%rsp)
  524068:	00 
  524069:	0f 29 b4 24 c0 00 00 	movaps %xmm6,0xc0(%rsp)
  524070:	00 
  524071:	41 0f 54 f0          	andps  %xmm8,%xmm6
  524075:	0f 29 b4 24 40 01 00 	movaps %xmm6,0x140(%rsp)
  52407c:	00 
  52407d:	0f 29 9c 24 20 02 00 	movaps %xmm3,0x220(%rsp)
  524084:	00 
  524085:	41 0f 54 d8          	andps  %xmm8,%xmm3
  524089:	0f 29 9c 24 10 02 00 	movaps %xmm3,0x210(%rsp)
  524090:	00 
  524091:	0f 29 bc 24 00 02 00 	movaps %xmm7,0x200(%rsp)
  524098:	00 
  524099:	41 0f 54 f8          	andps  %xmm8,%xmm7
  52409d:	0f 29 bc 24 f0 01 00 	movaps %xmm7,0x1f0(%rsp)
  5240a4:	00 
  5240a5:	0f 29 94 24 00 01 00 	movaps %xmm2,0x100(%rsp)
  5240ac:	00 
  5240ad:	44 0f 54 c2          	andps  %xmm2,%xmm8
  5240b1:	44 0f 29 84 24 10 01 	movaps %xmm8,0x110(%rsp)
  5240b8:	00 00 
  5240ba:	48 89 e8             	mov    %rbp,%rax
  5240bd:	48 0f af c3          	imul   %rbx,%rax
  5240c1:	49 01 c3             	add    %rax,%r11
  5240c4:	4c 8b ac 24 b0 00 00 	mov    0xb0(%rsp),%r13
  5240cb:	00 
  5240cc:	eb 1e                	jmp    5240ec <<gpui_gpu::renderer::RendererState>::bin_draw+0x52c>
  5240ce:	66 90                	xchg   %ax,%ax
  5240d0:	49 01 eb             	add    %rbp,%r11
  5240d3:	4c 39 f3             	cmp    %r14,%rbx
  5240d6:	48 8b 9c 24 98 01 00 	mov    0x198(%rsp),%rbx
  5240dd:	00 
  5240de:	4c 8b ac 24 b0 00 00 	mov    0xb0(%rsp),%r13
  5240e5:	00 
  5240e6:	0f 84 95 0b 00 00    	je     524c81 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  5240ec:	48 8d 43 01          	lea    0x1(%rbx),%rax
  5240f0:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
  5240f7:	00 
  5240f8:	4c 89 d9             	mov    %r11,%rcx
  5240fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  524100:	48 89 c8             	mov    %rcx,%rax
  524103:	48 c1 e8 20          	shr    $0x20,%rax
  524107:	74 17                	je     524120 <<gpui_gpu::renderer::RendererState>::bin_draw+0x560>
  524109:	48 89 c8             	mov    %rcx,%rax
  52410c:	31 d2                	xor    %edx,%edx
  52410e:	48 f7 f5             	div    %rbp
  524111:	eb 13                	jmp    524126 <<gpui_gpu::renderer::RendererState>::bin_draw+0x566>
  524113:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  52411a:	84 00 00 00 00 00 
  524120:	89 c8                	mov    %ecx,%eax
  524122:	31 d2                	xor    %edx,%edx
  524124:	f7 f5                	div    %ebp
  524126:	c1 e2 04             	shl    $0x4,%edx
  524129:	c1 e0 04             	shl    $0x4,%eax
  52412c:	8d 7a 10             	lea    0x10(%rdx),%edi
  52412f:	44 39 ff             	cmp    %r15d,%edi
  524132:	41 0f 43 ff          	cmovae %r15d,%edi
  524136:	44 8d 40 10          	lea    0x10(%rax),%r8d
  52413a:	45 39 d0             	cmp    %r10d,%r8d
  52413d:	45 0f 43 c2          	cmovae %r10d,%r8d
  524141:	45 0f 57 e4          	xorps  %xmm12,%xmm12
  524145:	f2 44 0f 2a e2       	cvtsi2sd %edx,%xmm12
  52414a:	66 41 0f 2e c4       	ucomisd %xmm12,%xmm0
  52414f:	77 3f                	ja     524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524151:	89 c0                	mov    %eax,%eax
  524153:	45 0f 57 f6          	xorps  %xmm14,%xmm14
  524157:	f2 4c 0f 2a f0       	cvtsi2sd %rax,%xmm14
  52415c:	66 41 0f 2e ce       	ucomisd %xmm14,%xmm1
  524161:	77 2d                	ja     524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524163:	0f 57 f6             	xorps  %xmm6,%xmm6
  524166:	f2 0f 2a f7          	cvtsi2sd %edi,%xmm6
  52416a:	66 0f 2e b4 24 a8 01 	ucomisd 0x1a8(%rsp),%xmm6
  524171:	00 00 
  524173:	77 1b                	ja     524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524175:	45 0f 57 ff          	xorps  %xmm15,%xmm15
  524179:	f2 45 0f 2a f8       	cvtsi2sd %r8d,%xmm15
  52417e:	66 44 0f 2e bc 24 a0 	ucomisd 0x1a0(%rsp),%xmm15
  524185:	01 00 00 
  524188:	76 25                	jbe    5241af <<gpui_gpu::renderer::RendererState>::bin_draw+0x5ef>
  52418a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  524190:	48 39 f1             	cmp    %rsi,%rcx
  524193:	0f 83 f6 0c 00 00    	jae    524e8f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524199:	41 ff 44 cc 04       	incl   0x4(%r12,%rcx,8)
  52419e:	48 ff c1             	inc    %rcx
  5241a1:	49 ff cd             	dec    %r13
  5241a4:	0f 85 56 ff ff ff    	jne    524100 <<gpui_gpu::renderer::RendererState>::bin_draw+0x540>
  5241aa:	e9 21 ff ff ff       	jmp    5240d0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x510>
  5241af:	f2 0f 10 15 d9 95 5f 	movsd  0x5f95d9(%rip),%xmm2        # b1d790 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x8>
  5241b6:	00 
  5241b7:	f2 44 0f 58 f2       	addsd  %xmm2,%xmm14
  5241bc:	f2 44 0f 58 e2       	addsd  %xmm2,%xmm12
  5241c1:	66 45 0f 28 d6       	movapd %xmm14,%xmm10
  5241c6:	f2 44 0f 59 94 24 80 	mulsd  0x280(%rsp),%xmm10
  5241cd:	02 00 00 
  5241d0:	66 45 0f 28 de       	movapd %xmm14,%xmm11
  5241d5:	f2 44 0f 59 9c 24 70 	mulsd  0x270(%rsp),%xmm11
  5241dc:	02 00 00 
  5241df:	66 45 0f 28 cc       	movapd %xmm12,%xmm9
  5241e4:	f2 44 0f 59 8c 24 a0 	mulsd  0x2a0(%rsp),%xmm9
  5241eb:	02 00 00 
  5241ee:	66 41 0f 28 d1       	movapd %xmm9,%xmm2
  5241f3:	f2 41 0f 58 d2       	addsd  %xmm10,%xmm2
  5241f8:	f2 0f 58 94 24 c0 00 	addsd  0xc0(%rsp),%xmm2
  5241ff:	00 00 
  524201:	f2 0f 5c 94 24 80 00 	subsd  0x80(%rsp),%xmm2
  524208:	00 00 
  52420a:	66 0f 28 ac 24 90 02 	movapd 0x290(%rsp),%xmm5
  524211:	00 00 
  524213:	f2 41 0f 59 ec       	mulsd  %xmm12,%xmm5
  524218:	66 0f 28 dd          	movapd %xmm5,%xmm3
  52421c:	f2 41 0f 58 db       	addsd  %xmm11,%xmm3
  524221:	f2 0f 58 9c 24 40 01 	addsd  0x140(%rsp),%xmm3
  524228:	00 00 
  52422a:	f2 0f 58 5c 24 70    	addsd  0x70(%rsp),%xmm3
  524230:	f2 0f 58 5c 24 60    	addsd  0x60(%rsp),%xmm3
  524236:	f2 0f 58 1d ca 8e 5f 	addsd  0x5f8eca(%rip),%xmm3        # b1d108 <_fini+0x788>
  52423d:	00 
  52423e:	f2 0f 59 1d 5a 95 5f 	mulsd  0x5f955a(%rip),%xmm3        # b1d7a0 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x18>
  524245:	00 
  524246:	f2 0f 58 5c 24 08    	addsd  0x8(%rsp),%xmm3
  52424c:	66 0f 2e da          	ucomisd %xmm2,%xmm3
  524250:	0f 83 3a ff ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524256:	66 0f 28 64 24 50    	movapd 0x50(%rsp),%xmm4
  52425c:	f2 0f 5c e2          	subsd  %xmm2,%xmm4
  524260:	66 0f 2e dc          	ucomisd %xmm4,%xmm3
  524264:	0f 83 26 ff ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  52426a:	66 0f 28 9c 24 40 02 	movapd 0x240(%rsp),%xmm3
  524271:	00 00 
  524273:	f2 41 0f 59 de       	mulsd  %xmm14,%xmm3
  524278:	66 44 0f 28 ac 24 30 	movapd 0x230(%rsp),%xmm13
  52427f:	02 00 00 
  524282:	f2 45 0f 59 ee       	mulsd  %xmm14,%xmm13
  524287:	66 0f 28 94 24 60 02 	movapd 0x260(%rsp),%xmm2
  52428e:	00 00 
  524290:	f2 41 0f 59 d4       	mulsd  %xmm12,%xmm2
  524295:	66 0f 29 94 24 50 01 	movapd %xmm2,0x150(%rsp)
  52429c:	00 00 
  52429e:	f2 0f 58 d3          	addsd  %xmm3,%xmm2
  5242a2:	f2 0f 58 94 24 30 01 	addsd  0x130(%rsp),%xmm2
  5242a9:	00 00 
  5242ab:	f2 0f 5c 94 24 80 00 	subsd  0x80(%rsp),%xmm2
  5242b2:	00 00 
  5242b4:	66 0f 28 a4 24 50 02 	movapd 0x250(%rsp),%xmm4
  5242bb:	00 00 
  5242bd:	f2 41 0f 59 e4       	mulsd  %xmm12,%xmm4
  5242c2:	f2 0f 11 a4 24 a8 00 	movsd  %xmm4,0xa8(%rsp)
  5242c9:	00 00 
  5242cb:	f2 41 0f 58 e5       	addsd  %xmm13,%xmm4
  5242d0:	f2 0f 58 a4 24 20 01 	addsd  0x120(%rsp),%xmm4
  5242d7:	00 00 
  5242d9:	f2 0f 58 64 24 70    	addsd  0x70(%rsp),%xmm4
  5242df:	f2 0f 58 64 24 60    	addsd  0x60(%rsp),%xmm4
  5242e5:	f2 0f 58 25 1b 8e 5f 	addsd  0x5f8e1b(%rip),%xmm4        # b1d108 <_fini+0x788>
  5242ec:	00 
  5242ed:	f2 0f 59 25 b3 94 5f 	mulsd  0x5f94b3(%rip),%xmm4        # b1d7a8 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x20>
  5242f4:	00 
  5242f5:	66 0f 2e e2          	ucomisd %xmm2,%xmm4
  5242f9:	0f 83 91 fe ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5242ff:	66 0f 28 7c 24 50    	movapd 0x50(%rsp),%xmm7
  524305:	f2 0f 5c fa          	subsd  %xmm2,%xmm7
  524309:	66 0f 2e e7          	ucomisd %xmm7,%xmm4
  52430d:	0f 83 7d fe ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524313:	66 41 0f 28 e6       	movapd %xmm14,%xmm4
  524318:	f2 0f 59 a4 24 00 02 	mulsd  0x200(%rsp),%xmm4
  52431f:	00 00 
  524321:	66 41 0f 28 d6       	movapd %xmm14,%xmm2
  524326:	f2 0f 59 94 24 f0 01 	mulsd  0x1f0(%rsp),%xmm2
  52432d:	00 00 
  52432f:	66 41 0f 28 fc       	movapd %xmm12,%xmm7
  524334:	f2 0f 59 bc 24 20 02 	mulsd  0x220(%rsp),%xmm7
  52433b:	00 00 
  52433d:	f2 0f 11 bc 24 80 01 	movsd  %xmm7,0x180(%rsp)
  524344:	00 00 
  524346:	f2 0f 11 a4 24 98 00 	movsd  %xmm4,0x98(%rsp)
  52434d:	00 00 
  52434f:	f2 0f 58 fc          	addsd  %xmm4,%xmm7
  524353:	f2 0f 58 bc 24 00 01 	addsd  0x100(%rsp),%xmm7
  52435a:	00 00 
  52435c:	f2 0f 5c 7c 24 40    	subsd  0x40(%rsp),%xmm7
  524362:	66 41 0f 28 e4       	movapd %xmm12,%xmm4
  524367:	f2 0f 59 a4 24 10 02 	mulsd  0x210(%rsp),%xmm4
  52436e:	00 00 
  524370:	f2 0f 11 a4 24 78 01 	movsd  %xmm4,0x178(%rsp)
  524377:	00 00 
  524379:	f2 0f 58 e2          	addsd  %xmm2,%xmm4
  52437d:	f2 0f 58 a4 24 10 01 	addsd  0x110(%rsp),%xmm4
  524384:	00 00 
  524386:	f2 0f 58 64 24 30    	addsd  0x30(%rsp),%xmm4
  52438c:	f2 0f 58 64 24 20    	addsd  0x20(%rsp),%xmm4
  524392:	f2 0f 58 25 6e 8d 5f 	addsd  0x5f8d6e(%rip),%xmm4        # b1d108 <_fini+0x788>
  524399:	00 
  52439a:	f2 0f 59 25 fe 93 5f 	mulsd  0x5f93fe(%rip),%xmm4        # b1d7a0 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x18>
  5243a1:	00 
  5243a2:	f2 0f 58 24 24       	addsd  (%rsp),%xmm4
  5243a7:	66 0f 2e e7          	ucomisd %xmm7,%xmm4
  5243ab:	0f 83 df fd ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5243b1:	66 44 0f 28 44 24 10 	movapd 0x10(%rsp),%xmm8
  5243b8:	f2 44 0f 5c c7       	subsd  %xmm7,%xmm8
  5243bd:	66 41 0f 2e e0       	ucomisd %xmm8,%xmm4
  5243c2:	0f 83 c8 fd ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5243c8:	66 0f 28 a4 24 c0 01 	movapd 0x1c0(%rsp),%xmm4
  5243cf:	00 00 
  5243d1:	f2 41 0f 59 e6       	mulsd  %xmm14,%xmm4
  5243d6:	f2 44 0f 59 b4 24 b0 	mulsd  0x1b0(%rsp),%xmm14
  5243dd:	01 00 00 
  5243e0:	66 0f 28 bc 24 e0 01 	movapd 0x1e0(%rsp),%xmm7
  5243e7:	00 00 
  5243e9:	f2 41 0f 59 fc       	mulsd  %xmm12,%xmm7
  5243ee:	66 0f 29 bc 24 d0 02 	movapd %xmm7,0x2d0(%rsp)
  5243f5:	00 00 
  5243f7:	66 0f 29 a4 24 e0 02 	movapd %xmm4,0x2e0(%rsp)
  5243fe:	00 00 
  524400:	f2 0f 58 fc          	addsd  %xmm4,%xmm7
  524404:	f2 0f 58 bc 24 f0 00 	addsd  0xf0(%rsp),%xmm7
  52440b:	00 00 
  52440d:	f2 0f 5c 7c 24 40    	subsd  0x40(%rsp),%xmm7
  524413:	f2 44 0f 59 a4 24 d0 	mulsd  0x1d0(%rsp),%xmm12
  52441a:	01 00 00 
  52441d:	66 41 0f 28 e4       	movapd %xmm12,%xmm4
  524422:	f2 41 0f 58 e6       	addsd  %xmm14,%xmm4
  524427:	f2 0f 58 a4 24 e0 00 	addsd  0xe0(%rsp),%xmm4
  52442e:	00 00 
  524430:	f2 0f 58 64 24 30    	addsd  0x30(%rsp),%xmm4
  524436:	f2 0f 58 64 24 20    	addsd  0x20(%rsp),%xmm4
  52443c:	f2 0f 58 25 c4 8c 5f 	addsd  0x5f8cc4(%rip),%xmm4        # b1d108 <_fini+0x788>
  524443:	00 
  524444:	f2 0f 59 25 5c 93 5f 	mulsd  0x5f935c(%rip),%xmm4        # b1d7a8 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x20>
  52444b:	00 
  52444c:	66 0f 2e e7          	ucomisd %xmm7,%xmm4
  524450:	0f 83 3a fd ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524456:	66 44 0f 28 44 24 10 	movapd 0x10(%rsp),%xmm8
  52445d:	f2 44 0f 5c c7       	subsd  %xmm7,%xmm8
  524462:	66 41 0f 2e e0       	ucomisd %xmm8,%xmm4
  524467:	0f 83 23 fd ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  52446d:	f2 0f 58 35 23 93 5f 	addsd  0x5f9323(%rip),%xmm6        # b1d798 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x10>
  524474:	00 
  524475:	66 0f 28 e6          	movapd %xmm6,%xmm4
  524479:	f2 0f 59 a4 24 a0 02 	mulsd  0x2a0(%rsp),%xmm4
  524480:	00 00 
  524482:	66 0f 28 fc          	movapd %xmm4,%xmm7
  524486:	f2 44 0f 58 d4       	addsd  %xmm4,%xmm10
  52448b:	f2 44 0f 58 94 24 c0 	addsd  0xc0(%rsp),%xmm10
  524492:	00 00 00 
  524495:	f2 44 0f 5c 94 24 80 	subsd  0x80(%rsp),%xmm10
  52449c:	00 00 00 
  52449f:	66 0f 28 a4 24 90 02 	movapd 0x290(%rsp),%xmm4
  5244a6:	00 00 
  5244a8:	f2 0f 59 e6          	mulsd  %xmm6,%xmm4
  5244ac:	f2 44 0f 58 dc       	addsd  %xmm4,%xmm11
  5244b1:	f2 44 0f 58 9c 24 40 	addsd  0x140(%rsp),%xmm11
  5244b8:	01 00 00 
  5244bb:	f2 44 0f 58 5c 24 70 	addsd  0x70(%rsp),%xmm11
  5244c2:	f2 44 0f 58 5c 24 60 	addsd  0x60(%rsp),%xmm11
  5244c9:	f2 44 0f 58 1d 36 8c 	addsd  0x5f8c36(%rip),%xmm11        # b1d108 <_fini+0x788>
  5244d0:	5f 00 
  5244d2:	f2 44 0f 59 1d c5 92 	mulsd  0x5f92c5(%rip),%xmm11        # b1d7a0 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x18>
  5244d9:	5f 00 
  5244db:	f2 44 0f 58 5c 24 08 	addsd  0x8(%rsp),%xmm11
  5244e2:	66 45 0f 2e da       	ucomisd %xmm10,%xmm11
  5244e7:	0f 83 a3 fc ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5244ed:	66 44 0f 28 c4       	movapd %xmm4,%xmm8
  5244f2:	66 0f 28 64 24 50    	movapd 0x50(%rsp),%xmm4
  5244f8:	f2 41 0f 5c e2       	subsd  %xmm10,%xmm4
  5244fd:	66 44 0f 2e dc       	ucomisd %xmm4,%xmm11
  524502:	0f 83 88 fc ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524508:	66 0f 28 a4 24 60 02 	movapd 0x260(%rsp),%xmm4
  52450f:	00 00 
  524511:	f2 0f 59 e6          	mulsd  %xmm6,%xmm4
  524515:	66 0f 29 a4 24 c0 02 	movapd %xmm4,0x2c0(%rsp)
  52451c:	00 00 
  52451e:	f2 0f 58 dc          	addsd  %xmm4,%xmm3
  524522:	f2 0f 58 9c 24 30 01 	addsd  0x130(%rsp),%xmm3
  524529:	00 00 
  52452b:	f2 0f 5c 9c 24 80 00 	subsd  0x80(%rsp),%xmm3
  524532:	00 00 
  524534:	66 0f 28 a4 24 50 02 	movapd 0x250(%rsp),%xmm4
  52453b:	00 00 
  52453d:	f2 0f 59 e6          	mulsd  %xmm6,%xmm4
  524541:	f2 44 0f 58 ec       	addsd  %xmm4,%xmm13
  524546:	f2 44 0f 58 ac 24 20 	addsd  0x120(%rsp),%xmm13
  52454d:	01 00 00 
  524550:	f2 44 0f 58 6c 24 70 	addsd  0x70(%rsp),%xmm13
  524557:	f2 44 0f 58 6c 24 60 	addsd  0x60(%rsp),%xmm13
  52455e:	f2 44 0f 58 2d a1 8b 	addsd  0x5f8ba1(%rip),%xmm13        # b1d108 <_fini+0x788>
  524565:	5f 00 
  524567:	f2 44 0f 59 2d 38 92 	mulsd  0x5f9238(%rip),%xmm13        # b1d7a8 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x20>
  52456e:	5f 00 
  524570:	66 44 0f 2e eb       	ucomisd %xmm3,%xmm13
  524575:	0f 83 15 fc ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  52457b:	66 44 0f 28 dc       	movapd %xmm4,%xmm11
  524580:	66 0f 28 64 24 50    	movapd 0x50(%rsp),%xmm4
  524586:	f2 0f 5c e3          	subsd  %xmm3,%xmm4
  52458a:	66 44 0f 2e ec       	ucomisd %xmm4,%xmm13
  52458f:	0f 83 fb fb ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524595:	66 0f 28 de          	movapd %xmm6,%xmm3
  524599:	f2 0f 59 9c 24 20 02 	mulsd  0x220(%rsp),%xmm3
  5245a0:	00 00 
  5245a2:	f2 0f 11 9c 24 70 01 	movsd  %xmm3,0x170(%rsp)
  5245a9:	00 00 
  5245ab:	f2 44 0f 10 94 24 98 	movsd  0x98(%rsp),%xmm10
  5245b2:	00 00 00 
  5245b5:	f2 44 0f 58 d3       	addsd  %xmm3,%xmm10
  5245ba:	f2 44 0f 58 94 24 00 	addsd  0x100(%rsp),%xmm10
  5245c1:	01 00 00 
  5245c4:	f2 44 0f 5c 54 24 40 	subsd  0x40(%rsp),%xmm10
  5245cb:	66 0f 28 de          	movapd %xmm6,%xmm3
  5245cf:	f2 0f 59 9c 24 10 02 	mulsd  0x210(%rsp),%xmm3
  5245d6:	00 00 
  5245d8:	f2 0f 11 9c 24 98 00 	movsd  %xmm3,0x98(%rsp)
  5245df:	00 00 
  5245e1:	f2 0f 58 d3          	addsd  %xmm3,%xmm2
  5245e5:	f2 0f 58 94 24 10 01 	addsd  0x110(%rsp),%xmm2
  5245ec:	00 00 
  5245ee:	f2 0f 58 54 24 30    	addsd  0x30(%rsp),%xmm2
  5245f4:	f2 0f 58 54 24 20    	addsd  0x20(%rsp),%xmm2
  5245fa:	f2 0f 58 15 06 8b 5f 	addsd  0x5f8b06(%rip),%xmm2        # b1d108 <_fini+0x788>
  524601:	00 
  524602:	f2 0f 59 15 96 91 5f 	mulsd  0x5f9196(%rip),%xmm2        # b1d7a0 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x18>
  524609:	00 
  52460a:	f2 0f 58 14 24       	addsd  (%rsp),%xmm2
  52460f:	66 41 0f 2e d2       	ucomisd %xmm10,%xmm2
  524614:	0f 83 76 fb ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  52461a:	66 0f 28 5c 24 10    	movapd 0x10(%rsp),%xmm3
  524620:	f2 41 0f 5c da       	subsd  %xmm10,%xmm3
  524625:	66 0f 2e d3          	ucomisd %xmm3,%xmm2
  524629:	0f 83 61 fb ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  52462f:	66 0f 28 94 24 e0 01 	movapd 0x1e0(%rsp),%xmm2
  524636:	00 00 
  524638:	f2 0f 59 d6          	mulsd  %xmm6,%xmm2
  52463c:	66 0f 29 94 24 b0 02 	movapd %xmm2,0x2b0(%rsp)
  524643:	00 00 
  524645:	66 0f 28 a4 24 e0 02 	movapd 0x2e0(%rsp),%xmm4
  52464c:	00 00 
  52464e:	f2 0f 58 e2          	addsd  %xmm2,%xmm4
  524652:	f2 0f 58 a4 24 f0 00 	addsd  0xf0(%rsp),%xmm4
  524659:	00 00 
  52465b:	f2 0f 5c 64 24 40    	subsd  0x40(%rsp),%xmm4
  524661:	f2 0f 59 b4 24 d0 01 	mulsd  0x1d0(%rsp),%xmm6
  524668:	00 00 
  52466a:	f2 44 0f 58 f6       	addsd  %xmm6,%xmm14
  52466f:	f2 44 0f 58 b4 24 e0 	addsd  0xe0(%rsp),%xmm14
  524676:	00 00 00 
  524679:	f2 44 0f 58 74 24 30 	addsd  0x30(%rsp),%xmm14
  524680:	f2 44 0f 58 74 24 20 	addsd  0x20(%rsp),%xmm14
  524687:	f2 44 0f 58 35 78 8a 	addsd  0x5f8a78(%rip),%xmm14        # b1d108 <_fini+0x788>
  52468e:	5f 00 
  524690:	f2 44 0f 59 35 0f 91 	mulsd  0x5f910f(%rip),%xmm14        # b1d7a8 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x20>
  524697:	5f 00 
  524699:	66 44 0f 2e f4       	ucomisd %xmm4,%xmm14
  52469e:	0f 83 ec fa ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5246a4:	66 0f 28 54 24 10    	movapd 0x10(%rsp),%xmm2
  5246aa:	f2 0f 5c d4          	subsd  %xmm4,%xmm2
  5246ae:	66 44 0f 2e f2       	ucomisd %xmm2,%xmm14
  5246b3:	0f 83 d7 fa ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5246b9:	f2 44 0f 58 3d d6 90 	addsd  0x5f90d6(%rip),%xmm15        # b1d798 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x10>
  5246c0:	5f 00 
  5246c2:	66 41 0f 28 df       	movapd %xmm15,%xmm3
  5246c7:	f2 0f 59 9c 24 80 02 	mulsd  0x280(%rsp),%xmm3
  5246ce:	00 00 
  5246d0:	66 41 0f 28 d7       	movapd %xmm15,%xmm2
  5246d5:	f2 0f 59 94 24 70 02 	mulsd  0x270(%rsp),%xmm2
  5246dc:	00 00 
  5246de:	f2 44 0f 58 cb       	addsd  %xmm3,%xmm9
  5246e3:	f2 44 0f 58 8c 24 c0 	addsd  0xc0(%rsp),%xmm9
  5246ea:	00 00 00 
  5246ed:	f2 44 0f 5c 8c 24 80 	subsd  0x80(%rsp),%xmm9
  5246f4:	00 00 00 
  5246f7:	f2 0f 58 ea          	addsd  %xmm2,%xmm5
  5246fb:	f2 0f 58 ac 24 40 01 	addsd  0x140(%rsp),%xmm5
  524702:	00 00 
  524704:	f2 0f 58 6c 24 70    	addsd  0x70(%rsp),%xmm5
  52470a:	f2 0f 58 6c 24 60    	addsd  0x60(%rsp),%xmm5
  524710:	f2 0f 58 2d f0 89 5f 	addsd  0x5f89f0(%rip),%xmm5        # b1d108 <_fini+0x788>
  524717:	00 
  524718:	f2 0f 59 2d 80 90 5f 	mulsd  0x5f9080(%rip),%xmm5        # b1d7a0 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x18>
  52471f:	00 
  524720:	f2 0f 58 6c 24 08    	addsd  0x8(%rsp),%xmm5
  524726:	66 41 0f 2e e9       	ucomisd %xmm9,%xmm5
  52472b:	0f 83 5f fa ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524731:	66 0f 28 64 24 50    	movapd 0x50(%rsp),%xmm4
  524737:	f2 41 0f 5c e1       	subsd  %xmm9,%xmm4
  52473c:	66 0f 2e ec          	ucomisd %xmm4,%xmm5
  524740:	0f 83 4a fa ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524746:	66 44 0f 28 b4 24 40 	movapd 0x240(%rsp),%xmm14
  52474d:	02 00 00 
  524750:	f2 45 0f 59 f7       	mulsd  %xmm15,%xmm14
  524755:	66 0f 28 ac 24 30 02 	movapd 0x230(%rsp),%xmm5
  52475c:	00 00 
  52475e:	f2 41 0f 59 ef       	mulsd  %xmm15,%xmm5
  524763:	66 0f 28 a4 24 50 01 	movapd 0x150(%rsp),%xmm4
  52476a:	00 00 
  52476c:	f2 41 0f 58 e6       	addsd  %xmm14,%xmm4
  524771:	f2 0f 58 a4 24 30 01 	addsd  0x130(%rsp),%xmm4
  524778:	00 00 
  52477a:	f2 0f 5c a4 24 80 00 	subsd  0x80(%rsp),%xmm4
  524781:	00 00 
  524783:	f2 44 0f 10 94 24 a8 	movsd  0xa8(%rsp),%xmm10
  52478a:	00 00 00 
  52478d:	f2 44 0f 58 d5       	addsd  %xmm5,%xmm10
  524792:	f2 44 0f 58 94 24 20 	addsd  0x120(%rsp),%xmm10
  524799:	01 00 00 
  52479c:	f2 44 0f 58 54 24 70 	addsd  0x70(%rsp),%xmm10
  5247a3:	f2 44 0f 58 54 24 60 	addsd  0x60(%rsp),%xmm10
  5247aa:	f2 44 0f 58 15 55 89 	addsd  0x5f8955(%rip),%xmm10        # b1d108 <_fini+0x788>
  5247b1:	5f 00 
  5247b3:	f2 44 0f 59 15 ec 8f 	mulsd  0x5f8fec(%rip),%xmm10        # b1d7a8 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x20>
  5247ba:	5f 00 
  5247bc:	66 44 0f 2e d4       	ucomisd %xmm4,%xmm10
  5247c1:	0f 83 c9 f9 ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5247c7:	66 44 0f 28 ec       	movapd %xmm4,%xmm13
  5247cc:	66 0f 28 64 24 50    	movapd 0x50(%rsp),%xmm4
  5247d2:	f2 41 0f 5c e5       	subsd  %xmm13,%xmm4
  5247d7:	66 44 0f 2e d4       	ucomisd %xmm4,%xmm10
  5247dc:	0f 83 ae f9 ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5247e2:	66 45 0f 28 d7       	movapd %xmm15,%xmm10
  5247e7:	f2 44 0f 59 94 24 00 	mulsd  0x200(%rsp),%xmm10
  5247ee:	02 00 00 
  5247f1:	66 41 0f 28 e7       	movapd %xmm15,%xmm4
  5247f6:	f2 0f 59 a4 24 f0 01 	mulsd  0x1f0(%rsp),%xmm4
  5247fd:	00 00 
  5247ff:	f2 44 0f 10 8c 24 80 	movsd  0x180(%rsp),%xmm9
  524806:	01 00 00 
  524809:	f2 44 0f 11 94 24 a8 	movsd  %xmm10,0xa8(%rsp)
  524810:	00 00 00 
  524813:	f2 45 0f 58 ca       	addsd  %xmm10,%xmm9
  524818:	f2 44 0f 58 8c 24 00 	addsd  0x100(%rsp),%xmm9
  52481f:	01 00 00 
  524822:	f2 44 0f 5c 4c 24 40 	subsd  0x40(%rsp),%xmm9
  524829:	f2 44 0f 10 ac 24 78 	movsd  0x178(%rsp),%xmm13
  524830:	01 00 00 
  524833:	f2 0f 11 a4 24 50 01 	movsd  %xmm4,0x150(%rsp)
  52483a:	00 00 
  52483c:	f2 44 0f 58 ec       	addsd  %xmm4,%xmm13
  524841:	f2 44 0f 58 ac 24 10 	addsd  0x110(%rsp),%xmm13
  524848:	01 00 00 
  52484b:	f2 44 0f 58 6c 24 30 	addsd  0x30(%rsp),%xmm13
  524852:	f2 44 0f 58 6c 24 20 	addsd  0x20(%rsp),%xmm13
  524859:	f2 44 0f 58 2d a6 88 	addsd  0x5f88a6(%rip),%xmm13        # b1d108 <_fini+0x788>
  524860:	5f 00 
  524862:	f2 44 0f 59 2d 35 8f 	mulsd  0x5f8f35(%rip),%xmm13        # b1d7a0 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x18>
  524869:	5f 00 
  52486b:	f2 44 0f 58 2c 24    	addsd  (%rsp),%xmm13
  524871:	66 45 0f 2e e9       	ucomisd %xmm9,%xmm13
  524876:	0f 83 14 f9 ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  52487c:	66 45 0f 28 d1       	movapd %xmm9,%xmm10
  524881:	66 44 0f 28 4c 24 10 	movapd 0x10(%rsp),%xmm9
  524888:	f2 45 0f 5c ca       	subsd  %xmm10,%xmm9
  52488d:	66 45 0f 2e e9       	ucomisd %xmm9,%xmm13
  524892:	0f 83 f8 f8 ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524898:	66 44 0f 28 8c 24 c0 	movapd 0x1c0(%rsp),%xmm9
  52489f:	01 00 00 
  5248a2:	f2 45 0f 59 cf       	mulsd  %xmm15,%xmm9
  5248a7:	f2 44 0f 59 bc 24 b0 	mulsd  0x1b0(%rsp),%xmm15
  5248ae:	01 00 00 
  5248b1:	66 44 0f 28 94 24 d0 	movapd 0x2d0(%rsp),%xmm10
  5248b8:	02 00 00 
  5248bb:	f2 45 0f 58 d1       	addsd  %xmm9,%xmm10
  5248c0:	f2 44 0f 58 94 24 f0 	addsd  0xf0(%rsp),%xmm10
  5248c7:	00 00 00 
  5248ca:	f2 44 0f 5c 54 24 40 	subsd  0x40(%rsp),%xmm10
  5248d1:	f2 45 0f 58 e7       	addsd  %xmm15,%xmm12
  5248d6:	f2 44 0f 58 a4 24 e0 	addsd  0xe0(%rsp),%xmm12
  5248dd:	00 00 00 
  5248e0:	f2 44 0f 58 64 24 30 	addsd  0x30(%rsp),%xmm12
  5248e7:	f2 44 0f 58 64 24 20 	addsd  0x20(%rsp),%xmm12
  5248ee:	f2 44 0f 58 25 11 88 	addsd  0x5f8811(%rip),%xmm12        # b1d108 <_fini+0x788>
  5248f5:	5f 00 
  5248f7:	f2 44 0f 59 25 a8 8e 	mulsd  0x5f8ea8(%rip),%xmm12        # b1d7a8 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x20>
  5248fe:	5f 00 
  524900:	66 45 0f 2e e2       	ucomisd %xmm10,%xmm12
  524905:	0f 83 85 f8 ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  52490b:	66 41 0f 28 e2       	movapd %xmm10,%xmm4
  524910:	66 44 0f 28 54 24 10 	movapd 0x10(%rsp),%xmm10
  524917:	f2 44 0f 5c d4       	subsd  %xmm4,%xmm10
  52491c:	66 45 0f 2e e2       	ucomisd %xmm10,%xmm12
  524921:	0f 83 69 f8 ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524927:	f2 0f 58 fb          	addsd  %xmm3,%xmm7
  52492b:	f2 0f 58 bc 24 c0 00 	addsd  0xc0(%rsp),%xmm7
  524932:	00 00 
  524934:	f2 0f 5c bc 24 80 00 	subsd  0x80(%rsp),%xmm7
  52493b:	00 00 
  52493d:	f2 44 0f 58 c2       	addsd  %xmm2,%xmm8
  524942:	f2 44 0f 58 84 24 40 	addsd  0x140(%rsp),%xmm8
  524949:	01 00 00 
  52494c:	f2 44 0f 58 44 24 70 	addsd  0x70(%rsp),%xmm8
  524953:	f2 44 0f 58 44 24 60 	addsd  0x60(%rsp),%xmm8
  52495a:	f2 44 0f 58 05 a5 87 	addsd  0x5f87a5(%rip),%xmm8        # b1d108 <_fini+0x788>
  524961:	5f 00 
  524963:	f2 44 0f 59 05 34 8e 	mulsd  0x5f8e34(%rip),%xmm8        # b1d7a0 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x18>
  52496a:	5f 00 
  52496c:	f2 44 0f 58 44 24 08 	addsd  0x8(%rsp),%xmm8
  524973:	66 44 0f 2e c7       	ucomisd %xmm7,%xmm8
  524978:	0f 83 12 f8 ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  52497e:	66 0f 28 54 24 50    	movapd 0x50(%rsp),%xmm2
  524984:	f2 0f 5c d7          	subsd  %xmm7,%xmm2
  524988:	66 44 0f 2e c2       	ucomisd %xmm2,%xmm8
  52498d:	0f 83 fd f7 ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524993:	66 0f 28 94 24 c0 02 	movapd 0x2c0(%rsp),%xmm2
  52499a:	00 00 
  52499c:	f2 41 0f 58 d6       	addsd  %xmm14,%xmm2
  5249a1:	f2 0f 58 94 24 30 01 	addsd  0x130(%rsp),%xmm2
  5249a8:	00 00 
  5249aa:	f2 0f 5c 94 24 80 00 	subsd  0x80(%rsp),%xmm2
  5249b1:	00 00 
  5249b3:	f2 44 0f 58 dd       	addsd  %xmm5,%xmm11
  5249b8:	f2 44 0f 58 9c 24 20 	addsd  0x120(%rsp),%xmm11
  5249bf:	01 00 00 
  5249c2:	f2 44 0f 58 5c 24 70 	addsd  0x70(%rsp),%xmm11
  5249c9:	f2 44 0f 58 5c 24 60 	addsd  0x60(%rsp),%xmm11
  5249d0:	f2 44 0f 58 1d 2f 87 	addsd  0x5f872f(%rip),%xmm11        # b1d108 <_fini+0x788>
  5249d7:	5f 00 
  5249d9:	f2 44 0f 59 1d c6 8d 	mulsd  0x5f8dc6(%rip),%xmm11        # b1d7a8 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x20>
  5249e0:	5f 00 
  5249e2:	66 44 0f 2e da       	ucomisd %xmm2,%xmm11
  5249e7:	0f 83 a3 f7 ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  5249ed:	66 0f 28 da          	movapd %xmm2,%xmm3
  5249f1:	66 0f 28 54 24 50    	movapd 0x50(%rsp),%xmm2
  5249f7:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
  5249fb:	66 44 0f 2e da       	ucomisd %xmm2,%xmm11
  524a00:	0f 83 8a f7 ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524a06:	f2 0f 10 94 24 70 01 	movsd  0x170(%rsp),%xmm2
  524a0d:	00 00 
  524a0f:	f2 0f 58 94 24 a8 00 	addsd  0xa8(%rsp),%xmm2
  524a16:	00 00 
  524a18:	f2 0f 58 94 24 00 01 	addsd  0x100(%rsp),%xmm2
  524a1f:	00 00 
  524a21:	f2 0f 5c 54 24 40    	subsd  0x40(%rsp),%xmm2
  524a27:	f2 0f 10 ac 24 98 00 	movsd  0x98(%rsp),%xmm5
  524a2e:	00 00 
  524a30:	f2 0f 58 ac 24 50 01 	addsd  0x150(%rsp),%xmm5
  524a37:	00 00 
  524a39:	f2 0f 58 ac 24 10 01 	addsd  0x110(%rsp),%xmm5
  524a40:	00 00 
  524a42:	f2 0f 58 6c 24 30    	addsd  0x30(%rsp),%xmm5
  524a48:	f2 0f 58 6c 24 20    	addsd  0x20(%rsp),%xmm5
  524a4e:	f2 0f 58 2d b2 86 5f 	addsd  0x5f86b2(%rip),%xmm5        # b1d108 <_fini+0x788>
  524a55:	00 
  524a56:	f2 0f 59 2d 42 8d 5f 	mulsd  0x5f8d42(%rip),%xmm5        # b1d7a0 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x18>
  524a5d:	00 
  524a5e:	f2 0f 58 2c 24       	addsd  (%rsp),%xmm5
  524a63:	66 0f 2e ea          	ucomisd %xmm2,%xmm5
  524a67:	0f 83 23 f7 ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524a6d:	66 0f 28 da          	movapd %xmm2,%xmm3
  524a71:	66 0f 28 54 24 10    	movapd 0x10(%rsp),%xmm2
  524a77:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
  524a7b:	66 0f 2e ea          	ucomisd %xmm2,%xmm5
  524a7f:	0f 83 0b f7 ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524a85:	66 0f 28 94 24 b0 02 	movapd 0x2b0(%rsp),%xmm2
  524a8c:	00 00 
  524a8e:	f2 41 0f 58 d1       	addsd  %xmm9,%xmm2
  524a93:	f2 0f 58 94 24 f0 00 	addsd  0xf0(%rsp),%xmm2
  524a9a:	00 00 
  524a9c:	f2 0f 5c 54 24 40    	subsd  0x40(%rsp),%xmm2
  524aa2:	f2 41 0f 58 f7       	addsd  %xmm15,%xmm6
  524aa7:	f2 0f 58 b4 24 e0 00 	addsd  0xe0(%rsp),%xmm6
  524aae:	00 00 
  524ab0:	f2 0f 58 74 24 30    	addsd  0x30(%rsp),%xmm6
  524ab6:	f2 0f 58 74 24 20    	addsd  0x20(%rsp),%xmm6
  524abc:	f2 0f 58 35 44 86 5f 	addsd  0x5f8644(%rip),%xmm6        # b1d108 <_fini+0x788>
  524ac3:	00 
  524ac4:	f2 0f 59 35 dc 8c 5f 	mulsd  0x5f8cdc(%rip),%xmm6        # b1d7a8 <anon.79bbc5cfb2b7cc742066507c9090712d.71.llvm.17726448420113707424+0x20>
  524acb:	00 
  524acc:	66 0f 2e f2          	ucomisd %xmm2,%xmm6
  524ad0:	0f 83 ba f6 ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524ad6:	66 0f 28 da          	movapd %xmm2,%xmm3
  524ada:	66 0f 28 54 24 10    	movapd 0x10(%rsp),%xmm2
  524ae0:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
  524ae4:	66 0f 2e f2          	ucomisd %xmm2,%xmm6
  524ae8:	0f 83 a2 f6 ff ff    	jae    524190 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5d0>
  524aee:	48 39 f1             	cmp    %rsi,%rcx
  524af1:	0f 83 b5 03 00 00    	jae    524eac <<gpui_gpu::renderer::RendererState>::bin_draw+0x12ec>
  524af7:	8b 84 24 bc 00 00 00 	mov    0xbc(%rsp),%eax
  524afe:	41 89 04 cc          	mov    %eax,(%r12,%rcx,8)
  524b02:	41 c7 44 cc 04 01 00 	movl   $0x1,0x4(%r12,%rcx,8)
  524b09:	00 00 
  524b0b:	48 3b 8c 24 d8 00 00 	cmp    0xd8(%rsp),%rcx
  524b12:	00 
  524b13:	0f 83 a3 03 00 00    	jae    524ebc <<gpui_gpu::renderer::RendererState>::bin_draw+0x12fc>
  524b19:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  524b20:	00 
  524b21:	48 8b 94 24 68 01 00 	mov    0x168(%rsp),%rdx
  524b28:	00 
  524b29:	89 04 8a             	mov    %eax,(%rdx,%rcx,4)
  524b2c:	48 ff c1             	inc    %rcx
  524b2f:	49 ff cd             	dec    %r13
  524b32:	0f 85 c8 f5 ff ff    	jne    524100 <<gpui_gpu::renderer::RendererState>::bin_draw+0x540>
  524b38:	e9 93 f5 ff ff       	jmp    5240d0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x510>
  524b3d:	48 89 e8             	mov    %rbp,%rax
  524b40:	48 0f af c3          	imul   %rbx,%rax
  524b44:	49 01 c3             	add    %rax,%r11
  524b47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  524b4e:	00 00 
  524b50:	48 89 d8             	mov    %rbx,%rax
  524b53:	48 ff c3             	inc    %rbx
  524b56:	4c 89 d9             	mov    %r11,%rcx
  524b59:	4c 89 ea             	mov    %r13,%rdx
  524b5c:	0f 1f 40 00          	nopl   0x0(%rax)
  524b60:	48 39 f1             	cmp    %rsi,%rcx
  524b63:	0f 83 26 03 00 00    	jae    524e8f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524b69:	41 ff 44 cc 04       	incl   0x4(%r12,%rcx,8)
  524b6e:	48 ff c1             	inc    %rcx
  524b71:	48 ff ca             	dec    %rdx
  524b74:	75 ea                	jne    524b60 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfa0>
  524b76:	49 01 eb             	add    %rbp,%r11
  524b79:	4c 39 f0             	cmp    %r14,%rax
  524b7c:	75 d2                	jne    524b50 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf90>
  524b7e:	e9 fe 00 00 00       	jmp    524c81 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  524b83:	48 89 e8             	mov    %rbp,%rax
  524b86:	48 0f af c3          	imul   %rbx,%rax
  524b8a:	49 01 c3             	add    %rax,%r11
  524b8d:	0f 1f 00             	nopl   (%rax)
  524b90:	48 8d 43 01          	lea    0x1(%rbx),%rax
  524b94:	4c 89 d9             	mov    %r11,%rcx
  524b97:	4c 89 ea             	mov    %r13,%rdx
  524b9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  524ba0:	48 39 f1             	cmp    %rsi,%rcx
  524ba3:	0f 83 e6 02 00 00    	jae    524e8f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524ba9:	41 ff 44 cc 04       	incl   0x4(%r12,%rcx,8)
  524bae:	48 ff c1             	inc    %rcx
  524bb1:	48 ff ca             	dec    %rdx
  524bb4:	75 ea                	jne    524ba0 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfe0>
  524bb6:	49 01 eb             	add    %rbp,%r11
  524bb9:	4c 39 f3             	cmp    %r14,%rbx
  524bbc:	48 89 c3             	mov    %rax,%rbx
  524bbf:	75 cf                	jne    524b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfd0>
  524bc1:	e9 bb 00 00 00       	jmp    524c81 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  524bc6:	85 ff                	test   %edi,%edi
  524bc8:	0f 88 e2 00 00 00    	js     524cb0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10f0>
  524bce:	45 85 c9             	test   %r9d,%r9d
  524bd1:	0f 88 3c 01 00 00    	js     524d13 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1153>
  524bd7:	45 85 c0             	test   %r8d,%r8d
  524bda:	0f 89 bf 02 00 00    	jns    524e9f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12df>
  524be0:	41 81 fa ff ff 7f 7f 	cmp    $0x7f7fffff,%r10d
  524be7:	0f 82 b2 02 00 00    	jb     524e9f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12df>
  524bed:	4c 39 de             	cmp    %r11,%rsi
  524bf0:	4c 89 d9             	mov    %r11,%rcx
  524bf3:	48 0f 47 ce          	cmova  %rsi,%rcx
  524bf7:	48 ff c0             	inc    %rax
  524bfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  524c00:	48 8d 53 01          	lea    0x1(%rbx),%rdx
  524c04:	4c 89 df             	mov    %r11,%rdi
  524c07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  524c0e:	00 00 
  524c10:	48 39 f9             	cmp    %rdi,%rcx
  524c13:	0f 84 76 02 00 00    	je     524e8f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524c19:	41 ff 44 fc 04       	incl   0x4(%r12,%rdi,8)
  524c1e:	48 ff c7             	inc    %rdi
  524c21:	48 39 f8             	cmp    %rdi,%rax
  524c24:	75 ea                	jne    524c10 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1050>
  524c26:	4c 39 f3             	cmp    %r14,%rbx
  524c29:	48 89 d3             	mov    %rdx,%rbx
  524c2c:	75 d2                	jne    524c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1040>
  524c2e:	eb 51                	jmp    524c81 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  524c30:	48 89 e8             	mov    %rbp,%rax
  524c33:	48 0f af c3          	imul   %rbx,%rax
  524c37:	49 01 c3             	add    %rax,%r11
  524c3a:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
  524c41:	00 
  524c42:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  524c49:	1f 84 00 00 00 00 00 
  524c50:	48 8d 43 01          	lea    0x1(%rbx),%rax
  524c54:	4c 89 d9             	mov    %r11,%rcx
  524c57:	48 89 fa             	mov    %rdi,%rdx
  524c5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  524c60:	48 39 f1             	cmp    %rsi,%rcx
  524c63:	0f 83 26 02 00 00    	jae    524e8f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524c69:	41 ff 44 cc 04       	incl   0x4(%r12,%rcx,8)
  524c6e:	48 ff c1             	inc    %rcx
  524c71:	48 ff ca             	dec    %rdx
  524c74:	75 ea                	jne    524c60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10a0>
  524c76:	49 01 eb             	add    %rbp,%r11
  524c79:	4c 39 f3             	cmp    %r14,%rbx
  524c7c:	48 89 c3             	mov    %rax,%rbx
  524c7f:	75 cf                	jne    524c50 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1090>
  524c81:	48 8b bc 24 90 01 00 	mov    0x190(%rsp),%rdi
  524c88:	00 
  524c89:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  524c90:	00 
  524c91:	48 89 47 08          	mov    %rax,0x8(%rdi)
  524c95:	41 ba ff ff ff ff    	mov    $0xffffffff,%r10d
  524c9b:	44 89 17             	mov    %r10d,(%rdi)
  524c9e:	48 81 c4 f8 02 00 00 	add    $0x2f8,%rsp
  524ca5:	5b                   	pop    %rbx
  524ca6:	41 5c                	pop    %r12
  524ca8:	41 5d                	pop    %r13
  524caa:	41 5e                	pop    %r14
  524cac:	41 5f                	pop    %r15
  524cae:	5d                   	pop    %rbp
  524caf:	c3                   	ret
  524cb0:	41 81 ff ff ff 7f 7f 	cmp    $0x7f7fffff,%r15d
  524cb7:	0f 83 b6 00 00 00    	jae    524d73 <<gpui_gpu::renderer::RendererState>::bin_draw+0x11b3>
  524cbd:	45 85 c9             	test   %r9d,%r9d
  524cc0:	0f 88 2d 01 00 00    	js     524df3 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1233>
  524cc6:	45 85 c0             	test   %r8d,%r8d
  524cc9:	0f 89 d0 01 00 00    	jns    524e9f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12df>
  524ccf:	41 81 fa ff ff 7f 7f 	cmp    $0x7f7fffff,%r10d
  524cd6:	0f 82 c3 01 00 00    	jb     524e9f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12df>
  524cdc:	4c 39 de             	cmp    %r11,%rsi
  524cdf:	4c 89 d9             	mov    %r11,%rcx
  524ce2:	48 0f 47 ce          	cmova  %rsi,%rcx
  524ce6:	48 ff c0             	inc    %rax
  524ce9:	48 8d 53 01          	lea    0x1(%rbx),%rdx
  524ced:	4c 89 df             	mov    %r11,%rdi
  524cf0:	48 39 f9             	cmp    %rdi,%rcx
  524cf3:	0f 84 96 01 00 00    	je     524e8f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524cf9:	41 ff 44 fc 04       	incl   0x4(%r12,%rdi,8)
  524cfe:	48 ff c7             	inc    %rdi
  524d01:	48 39 f8             	cmp    %rdi,%rax
  524d04:	75 ea                	jne    524cf0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1130>
  524d06:	4c 39 f3             	cmp    %r14,%rbx
  524d09:	48 89 d3             	mov    %rdx,%rbx
  524d0c:	75 db                	jne    524ce9 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1129>
  524d0e:	e9 6e ff ff ff       	jmp    524c81 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  524d13:	41 81 fd ff ff 7f 7f 	cmp    $0x7f7fffff,%r13d
  524d1a:	0f 83 93 00 00 00    	jae    524db3 <<gpui_gpu::renderer::RendererState>::bin_draw+0x11f3>
  524d20:	45 85 c0             	test   %r8d,%r8d
  524d23:	0f 89 76 01 00 00    	jns    524e9f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12df>
  524d29:	41 81 fa ff ff 7f 7f 	cmp    $0x7f7fffff,%r10d
  524d30:	0f 82 69 01 00 00    	jb     524e9f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12df>
  524d36:	4c 39 de             	cmp    %r11,%rsi
  524d39:	4c 89 d9             	mov    %r11,%rcx
  524d3c:	48 0f 47 ce          	cmova  %rsi,%rcx
  524d40:	48 ff c0             	inc    %rax
  524d43:	48 8d 53 01          	lea    0x1(%rbx),%rdx
  524d47:	4c 89 df             	mov    %r11,%rdi
  524d4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  524d50:	48 39 f9             	cmp    %rdi,%rcx
  524d53:	0f 84 36 01 00 00    	je     524e8f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524d59:	41 ff 44 fc 04       	incl   0x4(%r12,%rdi,8)
  524d5e:	48 ff c7             	inc    %rdi
  524d61:	48 39 f8             	cmp    %rdi,%rax
  524d64:	75 ea                	jne    524d50 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1190>
  524d66:	4c 39 f3             	cmp    %r14,%rbx
  524d69:	48 89 d3             	mov    %rdx,%rbx
  524d6c:	75 d5                	jne    524d43 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1183>
  524d6e:	e9 0e ff ff ff       	jmp    524c81 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  524d73:	4c 39 de             	cmp    %r11,%rsi
  524d76:	4c 89 d9             	mov    %r11,%rcx
  524d79:	48 0f 47 ce          	cmova  %rsi,%rcx
  524d7d:	48 ff c0             	inc    %rax
  524d80:	48 8d 53 01          	lea    0x1(%rbx),%rdx
  524d84:	4c 89 df             	mov    %r11,%rdi
  524d87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  524d8e:	00 00 
  524d90:	48 39 f9             	cmp    %rdi,%rcx
  524d93:	0f 84 f6 00 00 00    	je     524e8f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524d99:	41 ff 44 fc 04       	incl   0x4(%r12,%rdi,8)
  524d9e:	48 ff c7             	inc    %rdi
  524da1:	48 39 f8             	cmp    %rdi,%rax
  524da4:	75 ea                	jne    524d90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x11d0>
  524da6:	4c 39 f3             	cmp    %r14,%rbx
  524da9:	48 89 d3             	mov    %rdx,%rbx
  524dac:	75 d2                	jne    524d80 <<gpui_gpu::renderer::RendererState>::bin_draw+0x11c0>
  524dae:	e9 ce fe ff ff       	jmp    524c81 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  524db3:	4c 39 de             	cmp    %r11,%rsi
  524db6:	4c 89 d9             	mov    %r11,%rcx
  524db9:	48 0f 47 ce          	cmova  %rsi,%rcx
  524dbd:	48 ff c0             	inc    %rax
  524dc0:	48 8d 53 01          	lea    0x1(%rbx),%rdx
  524dc4:	4c 89 df             	mov    %r11,%rdi
  524dc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  524dce:	00 00 
  524dd0:	48 39 f9             	cmp    %rdi,%rcx
  524dd3:	0f 84 b6 00 00 00    	je     524e8f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524dd9:	41 ff 44 fc 04       	incl   0x4(%r12,%rdi,8)
  524dde:	48 ff c7             	inc    %rdi
  524de1:	48 39 f8             	cmp    %rdi,%rax
  524de4:	75 ea                	jne    524dd0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1210>
  524de6:	4c 39 f3             	cmp    %r14,%rbx
  524de9:	48 89 d3             	mov    %rdx,%rbx
  524dec:	75 d2                	jne    524dc0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1200>
  524dee:	e9 8e fe ff ff       	jmp    524c81 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  524df3:	41 81 fd ff ff 7f 7f 	cmp    $0x7f7fffff,%r13d
  524dfa:	73 53                	jae    524e4f <<gpui_gpu::renderer::RendererState>::bin_draw+0x128f>
  524dfc:	45 85 c0             	test   %r8d,%r8d
  524dff:	0f 89 9a 00 00 00    	jns    524e9f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12df>
  524e05:	41 81 fa ff ff 7f 7f 	cmp    $0x7f7fffff,%r10d
  524e0c:	0f 82 8d 00 00 00    	jb     524e9f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12df>
  524e12:	4c 39 de             	cmp    %r11,%rsi
  524e15:	4c 89 d9             	mov    %r11,%rcx
  524e18:	48 0f 47 ce          	cmova  %rsi,%rcx
  524e1c:	48 ff c0             	inc    %rax
  524e1f:	48 8d 53 01          	lea    0x1(%rbx),%rdx
  524e23:	4c 89 df             	mov    %r11,%rdi
  524e26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  524e2d:	00 00 00 
  524e30:	48 39 f9             	cmp    %rdi,%rcx
  524e33:	74 5a                	je     524e8f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524e35:	41 ff 44 fc 04       	incl   0x4(%r12,%rdi,8)
  524e3a:	48 ff c7             	inc    %rdi
  524e3d:	48 39 f8             	cmp    %rdi,%rax
  524e40:	75 ee                	jne    524e30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1270>
  524e42:	4c 39 f3             	cmp    %r14,%rbx
  524e45:	48 89 d3             	mov    %rdx,%rbx
  524e48:	75 d5                	jne    524e1f <<gpui_gpu::renderer::RendererState>::bin_draw+0x125f>
  524e4a:	e9 32 fe ff ff       	jmp    524c81 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  524e4f:	4c 39 de             	cmp    %r11,%rsi
  524e52:	4c 89 d9             	mov    %r11,%rcx
  524e55:	48 0f 47 ce          	cmova  %rsi,%rcx
  524e59:	48 ff c0             	inc    %rax
  524e5c:	48 8d 53 01          	lea    0x1(%rbx),%rdx
  524e60:	4c 89 df             	mov    %r11,%rdi
  524e63:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  524e6a:	84 00 00 00 00 00 
  524e70:	48 39 f9             	cmp    %rdi,%rcx
  524e73:	74 1a                	je     524e8f <<gpui_gpu::renderer::RendererState>::bin_draw+0x12cf>
  524e75:	41 ff 44 fc 04       	incl   0x4(%r12,%rdi,8)
  524e7a:	48 ff c7             	inc    %rdi
  524e7d:	48 39 f8             	cmp    %rdi,%rax
  524e80:	75 ee                	jne    524e70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x12b0>
  524e82:	4c 39 f3             	cmp    %r14,%rbx
  524e85:	48 89 d3             	mov    %rdx,%rbx
  524e88:	75 d2                	jne    524e5c <<gpui_gpu::renderer::RendererState>::bin_draw+0x129c>
  524e8a:	e9 f2 fd ff ff       	jmp    524c81 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c1>
  524e8f:	48 8d 15 1a b9 d5 00 	lea    0xd5b91a(%rip),%rdx        # 12807b0 <anon.255c8ba72969252177b3101bd34b486f.6.llvm.2677678285831016542+0xf0>
  524e96:	48 89 cf             	mov    %rcx,%rdi
  524e99:	ff 15 41 50 da 00    	call   *0xda5041(%rip)        # 12c9ee0 <_GLOBAL_OFFSET_TABLE_+0x60a0>
  524e9f:	48 8d 3d 2a ba d5 00 	lea    0xd5ba2a(%rip),%rdi        # 12808d0 <anon.11c63428aaff144b0aa1b5cb745d0db3.29.llvm.13440534355744728144+0x10>
  524ea6:	ff 15 8c 00 da 00    	call   *0xda008c(%rip)        # 12c4f38 <_GLOBAL_OFFSET_TABLE_+0x10f8>
  524eac:	48 8d 15 15 b9 d5 00 	lea    0xd5b915(%rip),%rdx        # 12807c8 <anon.255c8ba72969252177b3101bd34b486f.6.llvm.2677678285831016542+0x108>
  524eb3:	48 89 cf             	mov    %rcx,%rdi
  524eb6:	ff 15 24 50 da 00    	call   *0xda5024(%rip)        # 12c9ee0 <_GLOBAL_OFFSET_TABLE_+0x60a0>
  524ebc:	48 8d 15 1d b9 d5 00 	lea    0xd5b91d(%rip),%rdx        # 12807e0 <anon.255c8ba72969252177b3101bd34b486f.6.llvm.2677678285831016542+0x120>
  524ec3:	48 89 cf             	mov    %rcx,%rdi
  524ec6:	48 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%rsi
  524ecd:	00 
  524ece:	ff 15 0c 50 da 00    	call   *0xda500c(%rip)        # 12c9ee0 <_GLOBAL_OFFSET_TABLE_+0x60a0>
