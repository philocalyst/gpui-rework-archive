
/home/miles/gpui-ce3-compute-20261024/evidence/todo-shader-profiles/attempt2/builds/original/todo_comparison_mapped:     file format elf64-x86-64


Disassembly of section .text:

0000000000521380 <<gpui_gpu::renderer::RendererState>::render>:
  521380:	55                   	push   %rbp
  521381:	41 57                	push   %r15
  521383:	41 56                	push   %r14
  521385:	41 55                	push   %r13
  521387:	41 54                	push   %r12
  521389:	53                   	push   %rbx
  52138a:	48 81 ec d8 04 00 00 	sub    $0x4d8,%rsp
  521391:	48 8b 86 28 02 00 00 	mov    0x228(%rsi),%rax
  521398:	4c 8b 4a 18          	mov    0x18(%rdx),%r9
  52139c:	4c 39 c8             	cmp    %r9,%rax
  52139f:	74 1c                	je     5213bd <<gpui_gpu::renderer::RendererState>::render+0x3d>
  5213a1:	4c 8b 50 10          	mov    0x10(%rax),%r10
  5213a5:	4d 3b 51 10          	cmp    0x10(%r9),%r10
  5213a9:	0f 85 dc 00 00 00    	jne    52148b <<gpui_gpu::renderer::RendererState>::render+0x10b>
  5213af:	48 8b 40 18          	mov    0x18(%rax),%rax
  5213b3:	49 3b 41 18          	cmp    0x18(%r9),%rax
  5213b7:	0f 85 ce 00 00 00    	jne    52148b <<gpui_gpu::renderer::RendererState>::render+0x10b>
  5213bd:	48 8d 9e 30 03 00 00 	lea    0x330(%rsi),%rbx
  5213c4:	48 8b 86 30 03 00 00 	mov    0x330(%rsi),%rax
  5213cb:	48 85 c0             	test   %rax,%rax
  5213ce:	74 2d                	je     5213fd <<gpui_gpu::renderer::RendererState>::render+0x7d>
  5213d0:	f0 48 ff 08          	lock decq (%rax)
  5213d4:	75 27                	jne    5213fd <<gpui_gpu::renderer::RendererState>::render+0x7d>
  5213d6:	49 89 fe             	mov    %rdi,%r14
  5213d9:	48 89 df             	mov    %rbx,%rdi
  5213dc:	49 89 f4             	mov    %rsi,%r12
  5213df:	4d 89 c5             	mov    %r8,%r13
  5213e2:	49 89 d7             	mov    %rdx,%r15
  5213e5:	48 89 cd             	mov    %rcx,%rbp
  5213e8:	ff 15 e2 5e da 00    	call   *0xda5ee2(%rip)        # 12c72d0 <_GLOBAL_OFFSET_TABLE_+0x3490>
  5213ee:	48 89 e9             	mov    %rbp,%rcx
  5213f1:	4c 89 fa             	mov    %r15,%rdx
  5213f4:	4d 89 e8             	mov    %r13,%r8
  5213f7:	4c 89 e6             	mov    %r12,%rsi
  5213fa:	4c 89 f7             	mov    %r14,%rdi
  5213fd:	48 c7 86 30 03 00 00 	movq   $0x0,0x330(%rsi)
  521404:	00 00 00 00 
  521408:	44 8b 21             	mov    (%rcx),%r12d
  52140b:	44 8b 49 08          	mov    0x8(%rcx),%r9d
  52140f:	0f b6 41 0d          	movzbl 0xd(%rcx),%eax
  521413:	45 85 c9             	test   %r9d,%r9d
  521416:	41 0f 98 c2          	sets   %r10b
  52141a:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  521421:	45 8d 99 00 00 80 ff 	lea    -0x800000(%r9),%r11d
  521428:	41 81 fb 00 00 00 7f 	cmp    $0x7f000000,%r11d
  52142f:	41 0f 92 c3          	setb   %r11b
  521433:	45 20 d3             	and    %r10b,%r11b
  521436:	41 8d 69 ff          	lea    -0x1(%r9),%ebp
  52143a:	81 fd ff ff 7f 00    	cmp    $0x7fffff,%ebp
  521440:	40 0f 92 c5          	setb   %bpl
  521444:	44 20 d5             	and    %r10b,%bpl
  521447:	45 85 c9             	test   %r9d,%r9d
  52144a:	41 0f 94 c2          	sete   %r10b
  52144e:	41 81 f9 00 00 80 7f 	cmp    $0x7f800000,%r9d
  521455:	41 0f 94 c6          	sete   %r14b
  521459:	45 08 d6             	or     %r10b,%r14b
  52145c:	41 81 f9 01 00 80 7f 	cmp    $0x7f800001,%r9d
  521463:	41 0f 9d c1          	setge  %r9b
  521467:	45 08 f1             	or     %r14b,%r9b
  52146a:	41 08 e9             	or     %bpl,%r9b
  52146d:	45 85 e4             	test   %r12d,%r12d
  521470:	41 0f 95 c2          	setne  %r10b
  521474:	41 20 c2             	and    %al,%r10b
  521477:	45 08 da             	or     %r11b,%r10b
  52147a:	45 08 ca             	or     %r9b,%r10b
  52147d:	41 f6 c2 01          	test   $0x1,%r10b
  521481:	74 23                	je     5214a6 <<gpui_gpu::renderer::RendererState>::render+0x126>
  521483:	c7 07 03 00 00 00    	movl   $0x3,(%rdi)
  521489:	eb 06                	jmp    521491 <<gpui_gpu::renderer::RendererState>::render+0x111>
  52148b:	c7 07 04 00 00 00    	movl   $0x4,(%rdi)
  521491:	48 89 f8             	mov    %rdi,%rax
  521494:	48 81 c4 d8 04 00 00 	add    $0x4d8,%rsp
  52149b:	5b                   	pop    %rbx
  52149c:	41 5c                	pop    %r12
  52149e:	41 5d                	pop    %r13
  5214a0:	41 5e                	pop    %r14
  5214a2:	41 5f                	pop    %r15
  5214a4:	5d                   	pop    %rbp
  5214a5:	c3                   	ret
  5214a6:	66 0f 6e 51 04       	movd   0x4(%rcx),%xmm2
  5214ab:	0f b6 69 0c          	movzbl 0xc(%rcx),%ebp
  5214af:	41 f6 c4 01          	test   $0x1,%r12b
  5214b3:	74 76                	je     52152b <<gpui_gpu::renderer::RendererState>::render+0x1ab>
  5214b5:	66 41 0f 7e d1       	movd   %xmm2,%r9d
  5214ba:	45 85 c9             	test   %r9d,%r9d
  5214bd:	41 0f 98 c2          	sets   %r10b
  5214c1:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  5214c8:	45 8d 99 00 00 80 ff 	lea    -0x800000(%r9),%r11d
  5214cf:	41 81 fb 00 00 00 7f 	cmp    $0x7f000000,%r11d
  5214d6:	41 0f 92 c3          	setb   %r11b
  5214da:	45 20 d3             	and    %r10b,%r11b
  5214dd:	45 8d 71 ff          	lea    -0x1(%r9),%r14d
  5214e1:	41 81 fe ff ff 7f 00 	cmp    $0x7fffff,%r14d
  5214e8:	41 0f 92 c6          	setb   %r14b
  5214ec:	45 20 d6             	and    %r10b,%r14b
  5214ef:	45 85 c9             	test   %r9d,%r9d
  5214f2:	41 0f 94 c2          	sete   %r10b
  5214f6:	41 81 f9 00 00 80 7f 	cmp    $0x7f800000,%r9d
  5214fd:	41 0f 94 c7          	sete   %r15b
  521501:	45 08 d7             	or     %r10b,%r15b
  521504:	41 81 f9 01 00 80 7f 	cmp    $0x7f800001,%r9d
  52150b:	41 0f 9d c1          	setge  %r9b
  52150f:	45 08 f9             	or     %r15b,%r9b
  521512:	45 08 f1             	or     %r14b,%r9b
  521515:	45 08 d9             	or     %r11b,%r9b
  521518:	0f 85 65 ff ff ff    	jne    521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  52151e:	0f 2e 15 57 42 60 00 	ucomiss 0x604257(%rip),%xmm2        # b2577c <anon.9adf6b51329d0e8f0ba7a07edbf8a285.69.llvm.2988996700849332186+0x8>
  521525:	0f 87 58 ff ff ff    	ja     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  52152b:	4c 8b 71 28          	mov    0x28(%rcx),%r14
  52152f:	45 3b 70 20          	cmp    0x20(%r8),%r14d
  521533:	0f 85 4a ff ff ff    	jne    521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  521539:	66 49 0f 6e de       	movq   %r14,%xmm3
  52153e:	66 0f 70 c3 55       	pshufd $0x55,%xmm3,%xmm0
  521543:	66 41 0f 7e c7       	movd   %xmm0,%r15d
  521548:	45 3b 78 24          	cmp    0x24(%r8),%r15d
  52154c:	0f 85 31 ff ff ff    	jne    521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  521552:	45 8b 68 38          	mov    0x38(%r8),%r13d
  521556:	44 3b 6a 20          	cmp    0x20(%rdx),%r13d
  52155a:	0f 85 23 ff ff ff    	jne    521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  521560:	41 83 fd 4c          	cmp    $0x4c,%r13d
  521564:	75 23                	jne    521589 <<gpui_gpu::renderer::RendererState>::render+0x209>
  521566:	f3 41 0f 7e 40 3c    	movq   0x3c(%r8),%xmm0
  52156c:	f3 0f 7e 4a 24       	movq   0x24(%rdx),%xmm1
  521571:	66 0f 76 c8          	pcmpeqd %xmm0,%xmm1
  521575:	66 0f 70 c1 50       	pshufd $0x50,%xmm1,%xmm0
  52157a:	66 44 0f 50 c8       	movmskpd %xmm0,%r9d
  52157f:	41 83 f9 03          	cmp    $0x3,%r9d
  521583:	0f 85 fa fe ff ff    	jne    521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  521589:	66 0f 70 c3 50       	pshufd $0x50,%xmm3,%xmm0
  52158e:	66 0f ef 05 ba d3 5f 	pxor   0x5fd3ba(%rip),%xmm0        # b1e950 <anon.53de480418173883b8e15d81740454e2.346.llvm.622318203107919755+0x478>
  521595:	00 
  521596:	66 0f 66 05 12 e1 5f 	pcmpgtd 0x5fe112(%rip),%xmm0        # b1f6b0 <anon.4c7612a127e3a36f92a87c4915c21e6b.10.llvm.11927054215468658933+0x390>
  52159d:	00 
  52159e:	66 44 0f 50 c8       	movmskpd %xmm0,%r9d
  5215a3:	41 f6 c1 02          	test   $0x2,%r9b
  5215a7:	75 2e                	jne    5215d7 <<gpui_gpu::renderer::RendererState>::render+0x257>
  5215a9:	41 f6 c1 01          	test   $0x1,%r9b
  5215ad:	75 28                	jne    5215d7 <<gpui_gpu::renderer::RendererState>::render+0x257>
  5215af:	45 89 f1             	mov    %r14d,%r9d
  5215b2:	4d 0f af cf          	imul   %r15,%r9
  5215b6:	49 81 c1 ff ff ff fe 	add    $0xfffffffffeffffff,%r9
  5215bd:	49 81 f9 00 00 00 ff 	cmp    $0xffffffffff000000,%r9
  5215c4:	72 11                	jb     5215d7 <<gpui_gpu::renderer::RendererState>::render+0x257>
  5215c6:	4c 8b 51 10          	mov    0x10(%rcx),%r10
  5215ca:	49 81 ba 80 00 00 00 	cmpq   $0x10000,0x80(%r10)
  5215d1:	00 00 01 00 
  5215d5:	76 0b                	jbe    5215e2 <<gpui_gpu::renderer::RendererState>::render+0x262>
  5215d7:	c7 07 06 00 00 00    	movl   $0x6,(%rdi)
  5215dd:	e9 af fe ff ff       	jmp    521491 <<gpui_gpu::renderer::RendererState>::render+0x111>
  5215e2:	66 0f 6e 41 18       	movd   0x18(%rcx),%xmm0
  5215e7:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  5215ec:	45 01 c9             	add    %r9d,%r9d
  5215ef:	41 81 f9 ff ff ff fe 	cmp    $0xfeffffff,%r9d
  5215f6:	0f 87 87 fe ff ff    	ja     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  5215fc:	66 0f db 05 5c d3 5f 	pand   0x5fd35c(%rip),%xmm0        # b1e960 <anon.53de480418173883b8e15d81740454e2.346.llvm.622318203107919755+0x488>
  521603:	00 
  521604:	0f 2e 05 75 41 60 00 	ucomiss 0x604175(%rip),%xmm0        # b25780 <anon.9adf6b51329d0e8f0ba7a07edbf8a285.69.llvm.2988996700849332186+0xc>
  52160b:	0f 87 72 fe ff ff    	ja     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  521611:	66 0f 6e 41 1c       	movd   0x1c(%rcx),%xmm0
  521616:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  52161b:	45 01 c9             	add    %r9d,%r9d
  52161e:	41 81 f9 ff ff ff fe 	cmp    $0xfeffffff,%r9d
  521625:	0f 87 58 fe ff ff    	ja     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  52162b:	66 0f db 05 2d d3 5f 	pand   0x5fd32d(%rip),%xmm0        # b1e960 <anon.53de480418173883b8e15d81740454e2.346.llvm.622318203107919755+0x488>
  521632:	00 
  521633:	0f 2e 05 46 41 60 00 	ucomiss 0x604146(%rip),%xmm0        # b25780 <anon.9adf6b51329d0e8f0ba7a07edbf8a285.69.llvm.2988996700849332186+0xc>
  52163a:	0f 87 43 fe ff ff    	ja     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  521640:	66 0f 6e 41 20       	movd   0x20(%rcx),%xmm0
  521645:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  52164a:	45 01 c9             	add    %r9d,%r9d
  52164d:	41 81 f9 ff ff ff fe 	cmp    $0xfeffffff,%r9d
  521654:	0f 87 29 fe ff ff    	ja     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  52165a:	66 0f db 05 fe d2 5f 	pand   0x5fd2fe(%rip),%xmm0        # b1e960 <anon.53de480418173883b8e15d81740454e2.346.llvm.622318203107919755+0x488>
  521661:	00 
  521662:	0f 2e 05 17 41 60 00 	ucomiss 0x604117(%rip),%xmm0        # b25780 <anon.9adf6b51329d0e8f0ba7a07edbf8a285.69.llvm.2988996700849332186+0xc>
  521669:	0f 87 14 fe ff ff    	ja     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  52166f:	66 0f 6e 41 24       	movd   0x24(%rcx),%xmm0
  521674:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  521679:	45 01 c9             	add    %r9d,%r9d
  52167c:	41 81 f9 ff ff ff fe 	cmp    $0xfeffffff,%r9d
  521683:	0f 87 fa fd ff ff    	ja     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  521689:	66 0f 6f 0d cf d2 5f 	movdqa 0x5fd2cf(%rip),%xmm1        # b1e960 <anon.53de480418173883b8e15d81740454e2.346.llvm.622318203107919755+0x488>
  521690:	00 
  521691:	66 0f db c8          	pand   %xmm0,%xmm1
  521695:	0f 2e 0d e4 40 60 00 	ucomiss 0x6040e4(%rip),%xmm1        # b25780 <anon.9adf6b51329d0e8f0ba7a07edbf8a285.69.llvm.2988996700849332186+0xc>
  52169c:	0f 87 e1 fd ff ff    	ja     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  5216a2:	0f 57 c9             	xorps  %xmm1,%xmm1
  5216a5:	0f 2e c1             	ucomiss %xmm1,%xmm0
  5216a8:	0f 82 d5 fd ff ff    	jb     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  5216ae:	f3 0f 10 0d 06 40 60 	movss  0x604006(%rip),%xmm1        # b256bc <anon.65fa6619250d5a71bfd5ef20e1dfbaf0.11.llvm.7726090819372637783+0x8>
  5216b5:	00 
  5216b6:	0f 2e c8             	ucomiss %xmm0,%xmm1
  5216b9:	0f 82 c4 fd ff ff    	jb     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  5216bf:	44 8b 49 30          	mov    0x30(%rcx),%r9d
  5216c3:	41 83 fd 28          	cmp    $0x28,%r13d
  5216c7:	75 0a                	jne    5216d3 <<gpui_gpu::renderer::RendererState>::render+0x353>
  5216c9:	a8 01                	test   $0x1,%al
  5216cb:	0f 84 b2 fd ff ff    	je     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  5216d1:	eb 1b                	jmp    5216ee <<gpui_gpu::renderer::RendererState>::render+0x36e>
  5216d3:	a8 01                	test   $0x1,%al
  5216d5:	0f 85 a8 fd ff ff    	jne    521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  5216db:	0f 2e 05 da 3f 60 00 	ucomiss 0x603fda(%rip),%xmm0        # b256bc <anon.65fa6619250d5a71bfd5ef20e1dfbaf0.11.llvm.7726090819372637783+0x8>
  5216e2:	0f 85 9b fd ff ff    	jne    521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  5216e8:	0f 8a 95 fd ff ff    	jp     521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  5216ee:	44 89 4c 24 30       	mov    %r9d,0x30(%rsp)
  5216f3:	4c 89 94 24 c0 00 00 	mov    %r10,0xc0(%rsp)
  5216fa:	00 
  5216fb:	f3 0f 11 8c 24 14 01 	movss  %xmm1,0x114(%rsp)
  521702:	00 00 
  521704:	66 0f 7e 94 24 2c 03 	movd   %xmm2,0x32c(%rsp)
  52170b:	00 00 
  52170d:	48 89 94 24 98 01 00 	mov    %rdx,0x198(%rsp)
  521714:	00 
  521715:	4c 89 84 24 38 04 00 	mov    %r8,0x438(%rsp)
  52171c:	00 
  52171d:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
  521722:	66 0f 6f 05 96 df 5f 	movdqa 0x5fdf96(%rip),%xmm0        # b1f6c0 <anon.4c7612a127e3a36f92a87c4915c21e6b.10.llvm.11927054215468658933+0x3a0>
  521729:	00 
  52172a:	66 0f 7f 9c 24 a0 00 	movdqa %xmm3,0xa0(%rsp)
  521731:	00 00 
  521733:	66 0f fe c3          	paddd  %xmm3,%xmm0
  521737:	66 0f 72 d0 04       	psrld  $0x4,%xmm0
  52173c:	66 0f 7e c0          	movd   %xmm0,%eax
  521740:	48 8d 7e 18          	lea    0x18(%rsi),%rdi
  521744:	48 c7 46 28 00 00 00 	movq   $0x0,0x28(%rsi)
  52174b:	00 
  52174c:	66 0f 70 c0 55       	pshufd $0x55,%xmm0,%xmm0
  521751:	66 0f 7e c2          	movd   %xmm0,%edx
  521755:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  52175a:	0f af d0             	imul   %eax,%edx
  52175d:	48 89 bc 24 d8 00 00 	mov    %rdi,0xd8(%rsp)
  521764:	00 
  521765:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  52176a:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  52176f:	48 89 d6             	mov    %rdx,%rsi
  521772:	31 d2                	xor    %edx,%edx
  521774:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
  52177b:	00 
  52177c:	e8 1f 48 00 00       	call   525fa0 <<alloc::vec::Vec<[u32; 2]>>::resize>
  521781:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  521786:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
  52178d:	00 
  52178e:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
  521795:	00 
  521796:	ff 15 14 43 da 00    	call   *0xda4314(%rip)        # 12c5ab0 <_GLOBAL_OFFSET_TABLE_+0x1c70>
  52179c:	48 89 d1             	mov    %rdx,%rcx
  52179f:	48 29 c1             	sub    %rax,%rcx
  5217a2:	48 81 f9 00 00 30 00 	cmp    $0x300000,%rcx
  5217a9:	76 10                	jbe    5217bb <<gpui_gpu::renderer::RendererState>::render+0x43b>
  5217ab:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  5217b0:	c7 07 06 00 00 00    	movl   $0x6,(%rdi)
  5217b6:	e9 d6 fc ff ff       	jmp    521491 <<gpui_gpu::renderer::RendererState>::render+0x111>
  5217bb:	48 89 ce             	mov    %rcx,%rsi
  5217be:	48 c1 e9 03          	shr    $0x3,%rcx
  5217c2:	48 bf ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rdi
  5217c9:	aa aa aa 
  5217cc:	48 0f af f9          	imul   %rcx,%rdi
  5217d0:	48 89 bc 24 98 00 00 	mov    %rdi,0x98(%rsp)
  5217d7:	00 
  5217d8:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
  5217df:	00 
  5217e0:	48 89 94 24 60 03 00 	mov    %rdx,0x360(%rsp)
  5217e7:	00 
  5217e8:	48 39 c2             	cmp    %rax,%rdx
  5217eb:	74 32                	je     52181f <<gpui_gpu::renderer::RendererState>::render+0x49f>
  5217ed:	b8 ab aa aa aa       	mov    $0xaaaaaaab,%eax
  5217f2:	48 0f af f0          	imul   %rax,%rsi
  5217f6:	48 c1 ee 2a          	shr    $0x2a,%rsi
  5217fa:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  521801:	00 
  521802:	89 c8                	mov    %ecx,%eax
  521804:	83 e0 3f             	and    $0x3f,%eax
  521807:	48 01 ce             	add    %rcx,%rsi
  52180a:	48 83 f8 01          	cmp    $0x1,%rax
  52180e:	48 83 de ff          	sbb    $0xffffffffffffffff,%rsi
  521812:	48 ff c6             	inc    %rsi
  521815:	48 89 b4 24 30 03 00 	mov    %rsi,0x330(%rsp)
  52181c:	00 
  52181d:	eb 0c                	jmp    52182b <<gpui_gpu::renderer::RendererState>::render+0x4ab>
  52181f:	48 c7 84 24 30 03 00 	movq   $0x0,0x330(%rsp)
  521826:	00 00 00 00 00 
  52182b:	48 8b 94 24 c0 00 00 	mov    0xc0(%rsp),%rdx
  521832:	00 
  521833:	48 8b 82 80 00 00 00 	mov    0x80(%rdx),%rax
  52183a:	48 8b 8a 98 00 00 00 	mov    0x98(%rdx),%rcx
  521841:	48 03 8a b0 00 00 00 	add    0xb0(%rdx),%rcx
  521848:	48 89 94 24 c0 01 00 	mov    %rdx,0x1c0(%rsp)
  52184f:	00 
  521850:	8b 54 24 30          	mov    0x30(%rsp),%edx
  521854:	89 94 24 e0 01 00 00 	mov    %edx,0x1e0(%rsp)
  52185b:	48 c7 84 24 c8 01 00 	movq   $0x0,0x1c8(%rsp)
  521862:	00 00 00 00 00 
  521867:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
  52186e:	00 
  52186f:	48 89 8c 24 d8 01 00 	mov    %rcx,0x1d8(%rsp)
  521876:	00 
  521877:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  52187c:	0f b6 90 41 03 00 00 	movzbl 0x341(%rax),%edx
  521883:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  52188a:	00 
  52188b:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
  521892:	00 
  521893:	e8 48 de ff ff       	call   51f6e0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>
  521898:	8b 84 24 18 01 00 00 	mov    0x118(%rsp),%eax
  52189f:	83 f8 ff             	cmp    $0xffffffff,%eax
  5218a2:	74 2f                	je     5218d3 <<gpui_gpu::renderer::RendererState>::render+0x553>
  5218a4:	8b 8c 24 1c 01 00 00 	mov    0x11c(%rsp),%ecx
  5218ab:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
  5218b2:	00 
  5218b3:	0f 10 84 24 28 01 00 	movups 0x128(%rsp),%xmm0
  5218ba:	00 
  5218bb:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  5218c0:	f3 0f 7f 47 10       	movdqu %xmm0,0x10(%rdi)
  5218c5:	89 07                	mov    %eax,(%rdi)
  5218c7:	89 4f 04             	mov    %ecx,0x4(%rdi)
  5218ca:	48 89 57 08          	mov    %rdx,0x8(%rdi)
  5218ce:	e9 be fb ff ff       	jmp    521491 <<gpui_gpu::renderer::RendererState>::render+0x111>
  5218d3:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
  5218da:	00 
  5218db:	48 03 94 24 30 03 00 	add    0x330(%rsp),%rdx
  5218e2:	00 
  5218e3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  5218e8:	48 8b 77 10          	mov    0x10(%rdi),%rsi
  5218ec:	b9 04 00 00 00       	mov    $0x4,%ecx
  5218f1:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  5218f7:	e8 14 6f 00 00       	call   528810 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  5218fc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  521900:	0f 85 a5 fe ff ff    	jne    5217ab <<gpui_gpu::renderer::RendererState>::render+0x42b>
  521906:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  52190b:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
  521912:	00 
  521913:	48 8b 94 24 98 00 00 	mov    0x98(%rsp),%rdx
  52191a:	00 
  52191b:	e8 c0 6f 00 00       	call   5288e0 <gpui_gpu::renderer::slots::write_prefix>
  521920:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  521925:	48 8d 78 48          	lea    0x48(%rax),%rdi
  521929:	48 c7 40 58 00 00 00 	movq   $0x0,0x58(%rax)
  521930:	00 
  521931:	48 89 bc 24 40 04 00 	mov    %rdi,0x440(%rsp)
  521938:	00 
  521939:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  52193e:	31 d2                	xor    %edx,%edx
  521940:	e8 7b 47 00 00       	call   5260c0 <<alloc::vec::Vec<u32>>::resize>
  521945:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  52194a:	48 c7 40 70 00 00 00 	movq   $0x0,0x70(%rax)
  521951:	00 
  521952:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
  521957:	75 0f                	jne    521968 <<gpui_gpu::renderer::RendererState>::render+0x5e8>
  521959:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  52195e:	48 8d 78 60          	lea    0x60(%rax),%rdi
  521962:	ff 15 28 82 da 00    	call   *0xda8228(%rip)        # 12c9b90 <_GLOBAL_OFFSET_TABLE_+0x5d50>
  521968:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  52196d:	48 8b 48 68          	mov    0x68(%rax),%rcx
  521971:	66 0f ef c0          	pxor   %xmm0,%xmm0
  521975:	f3 0f 7f 41 10       	movdqu %xmm0,0x10(%rcx)
  52197a:	f3 0f 7f 01          	movdqu %xmm0,(%rcx)
  52197e:	48 c7 40 70 01 00 00 	movq   $0x1,0x70(%rax)
  521985:	00 
  521986:	48 8d b8 f8 02 00 00 	lea    0x2f8(%rax),%rdi
  52198d:	e8 5e 40 00 00       	call   5259f0 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  521992:	48 8b 94 24 c0 00 00 	mov    0xc0(%rsp),%rdx
  521999:	00 
  52199a:	48 8b 82 98 00 00 00 	mov    0x98(%rdx),%rax
  5219a1:	48 03 82 b0 00 00 00 	add    0xb0(%rdx),%rax
  5219a8:	48 8b 8a 80 00 00 00 	mov    0x80(%rdx),%rcx
  5219af:	48 89 94 24 b0 02 00 	mov    %rdx,0x2b0(%rsp)
  5219b6:	00 
  5219b7:	48 c7 84 24 b8 02 00 	movq   $0x0,0x2b8(%rsp)
  5219be:	00 00 00 00 00 
  5219c3:	48 89 8c 24 c0 02 00 	mov    %rcx,0x2c0(%rsp)
  5219ca:	00 
  5219cb:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
  5219d2:	00 
  5219d3:	8b 44 24 30          	mov    0x30(%rsp),%eax
  5219d7:	89 84 24 d0 02 00 00 	mov    %eax,0x2d0(%rsp)
  5219de:	48 8d bc 24 48 04 00 	lea    0x448(%rsp),%rdi
  5219e5:	00 
  5219e6:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
  5219ed:	00 
  5219ee:	ff 15 7c 5f da 00    	call   *0xda5f7c(%rip)        # 12c7970 <_GLOBAL_OFFSET_TABLE_+0x3b30>
  5219f4:	48 8b 84 24 48 04 00 	mov    0x448(%rsp),%rax
  5219fb:	00 
  5219fc:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  521a01:	48 85 c0             	test   %rax,%rax
  521a04:	0f 84 f1 0f 00 00    	je     5229fb <<gpui_gpu::renderer::RendererState>::render+0x167b>
  521a0a:	0f 28 94 24 a0 00 00 	movaps 0xa0(%rsp),%xmm2
  521a11:	00 
  521a12:	0f 13 94 24 58 03 00 	movlps %xmm2,0x358(%rsp)
  521a19:	00 
  521a1a:	0f 57 c9             	xorps  %xmm1,%xmm1
  521a1d:	0f 14 d1             	unpcklps %xmm1,%xmm2
  521a20:	0f 28 05 a9 cd 5f 00 	movaps 0x5fcda9(%rip),%xmm0        # b1e7d0 <anon.53de480418173883b8e15d81740454e2.346.llvm.622318203107919755+0x2f8>
  521a27:	0f 56 d0             	orps   %xmm0,%xmm2
  521a2a:	66 0f 5c d0          	subpd  %xmm0,%xmm2
  521a2e:	66 0f 5a c2          	cvtpd2ps %xmm2,%xmm0
  521a32:	0f 16 c8             	movlhps %xmm0,%xmm1
  521a35:	0f 29 8c 24 b0 04 00 	movaps %xmm1,0x4b0(%rsp)
  521a3c:	00 
  521a3d:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
  521a44:	00 00 
  521a46:	48 c7 84 24 c8 00 00 	movq   $0x0,0xc8(%rsp)
  521a4d:	00 00 00 00 00 
  521a52:	48 c7 84 24 10 03 00 	movq   $0x0,0x310(%rsp)
  521a59:	00 00 00 00 00 
  521a5e:	48 c7 84 24 18 03 00 	movq   $0x0,0x318(%rsp)
  521a65:	00 00 00 00 00 
  521a6a:	48 c7 84 24 00 01 00 	movq   $0x0,0x100(%rsp)
  521a71:	00 00 00 00 00 
  521a76:	48 8b 94 24 50 04 00 	mov    0x450(%rsp),%rdx
  521a7d:	00 
  521a7e:	4c 8b 84 24 58 04 00 	mov    0x458(%rsp),%r8
  521a85:	00 
  521a86:	48 8b bc 24 60 04 00 	mov    0x460(%rsp),%rdi
  521a8d:	00 
  521a8e:	0f 10 94 24 68 04 00 	movups 0x468(%rsp),%xmm2
  521a95:	00 
  521a96:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
  521a9b:	48 8d 8c 24 78 04 00 	lea    0x478(%rsp),%rcx
  521aa2:	00 
  521aa3:	48 8b 41 20          	mov    0x20(%rcx),%rax
  521aa7:	48 89 84 24 c0 03 00 	mov    %rax,0x3c0(%rsp)
  521aae:	00 
  521aaf:	0f 10 01             	movups (%rcx),%xmm0
  521ab2:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
  521ab6:	0f 29 8c 24 b0 03 00 	movaps %xmm1,0x3b0(%rsp)
  521abd:	00 
  521abe:	0f 29 84 24 a0 03 00 	movaps %xmm0,0x3a0(%rsp)
  521ac5:	00 
  521ac6:	0f 10 41 28          	movups 0x28(%rcx),%xmm0
  521aca:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
  521ad1:	00 
  521ad2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  521ad7:	0f b6 b0 41 03 00 00 	movzbl 0x341(%rax),%esi
  521ade:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  521ae3:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
  521aea:	00 
  521aeb:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
  521af0:	48 89 94 24 c8 01 00 	mov    %rdx,0x1c8(%rsp)
  521af7:	00 
  521af8:	4c 89 44 24 38       	mov    %r8,0x38(%rsp)
  521afd:	4c 89 84 24 d0 01 00 	mov    %r8,0x1d0(%rsp)
  521b04:	00 
  521b05:	48 89 bc 24 a0 00 00 	mov    %rdi,0xa0(%rsp)
  521b0c:	00 
  521b0d:	48 89 bc 24 d8 01 00 	mov    %rdi,0x1d8(%rsp)
  521b14:	00 
  521b15:	0f 11 94 24 e0 01 00 	movups %xmm2,0x1e0(%rsp)
  521b1c:	00 
  521b1d:	48 8b 41 20          	mov    0x20(%rcx),%rax
  521b21:	48 8d 94 24 f0 01 00 	lea    0x1f0(%rsp),%rdx
  521b28:	00 
  521b29:	48 89 42 20          	mov    %rax,0x20(%rdx)
  521b2d:	0f 10 01             	movups (%rcx),%xmm0
  521b30:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
  521b34:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  521b38:	0f 11 02             	movups %xmm0,(%rdx)
  521b3b:	66 0f 10 41 28       	movupd 0x28(%rcx),%xmm0
  521b40:	48 8d 84 24 18 02 00 	lea    0x218(%rsp),%rax
  521b47:	00 
  521b48:	66 0f 11 00          	movupd %xmm0,(%rax)
  521b4c:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
  521b53:	00 
  521b54:	e8 87 33 00 00       	call   524ee0 <gpui_gpu::renderer::compact_group>
  521b59:	88 84 24 e0 00 00 00 	mov    %al,0xe0(%rsp)
  521b60:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
  521b64:	66 0f 28 4c 24 50    	movapd 0x50(%rsp),%xmm1
  521b6a:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
  521b6e:	0f 85 0e 01 00 00    	jne    521c82 <<gpui_gpu::renderer::RendererState>::render+0x902>
  521b74:	0f 8a 08 01 00 00    	jp     521c82 <<gpui_gpu::renderer::RendererState>::render+0x902>
  521b7a:	66 0f 28 44 24 50    	movapd 0x50(%rsp),%xmm0
  521b80:	66 0f 15 c0          	unpckhpd %xmm0,%xmm0
  521b84:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
  521b88:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
  521b8c:	0f 85 f0 00 00 00    	jne    521c82 <<gpui_gpu::renderer::RendererState>::render+0x902>
  521b92:	0f 8a ea 00 00 00    	jp     521c82 <<gpui_gpu::renderer::RendererState>::render+0x902>
  521b98:	48 83 7c 24 38 00    	cmpq   $0x0,0x38(%rsp)
  521b9e:	74 5d                	je     521bfd <<gpui_gpu::renderer::RendererState>::render+0x87d>
  521ba0:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  521ba5:	48 8d 04 85 00 00 00 	lea    0x0(,%rax,4),%rax
  521bac:	00 
  521bad:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  521bb2:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
  521bb9:	00 00 
  521bbb:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  521bc0:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  521bc5:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  521bc8:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
  521bcf:	00 
  521bd0:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  521bd5:	e8 56 dc ff ff       	call   51f830 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  521bda:	80 bc 24 c0 01 00 00 	cmpb   $0x0,0x1c0(%rsp)
  521be1:	00 
  521be2:	0f 85 9a 00 00 00    	jne    521c82 <<gpui_gpu::renderer::RendererState>::render+0x902>
  521be8:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  521bed:	48 83 c1 04          	add    $0x4,%rcx
  521bf1:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  521bf6:	48 39 4c 24 70       	cmp    %rcx,0x70(%rsp)
  521bfb:	75 be                	jne    521bbb <<gpui_gpu::renderer::RendererState>::render+0x83b>
  521bfd:	8b 84 24 a0 04 00 00 	mov    0x4a0(%rsp),%eax
  521c04:	89 84 24 94 00 00 00 	mov    %eax,0x94(%rsp)
  521c0b:	8b 84 24 a4 04 00 00 	mov    0x4a4(%rsp),%eax
  521c12:	89 84 24 90 00 00 00 	mov    %eax,0x90(%rsp)
  521c19:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
  521c1d:	66 0f 29 84 24 70 03 	movapd %xmm0,0x370(%rsp)
  521c24:	00 00 
  521c26:	b0 01                	mov    $0x1,%al
  521c28:	89 84 24 f0 00 00 00 	mov    %eax,0xf0(%rsp)
  521c2f:	c7 84 24 8c 00 00 00 	movl   $0x0,0x8c(%rsp)
  521c36:	00 00 00 00 
  521c3a:	f2 0f 10 84 24 a8 04 	movsd  0x4a8(%rsp),%xmm0
  521c41:	00 00 
  521c43:	0f 29 84 24 80 03 00 	movaps %xmm0,0x380(%rsp)
  521c4a:	00 
  521c4b:	f3 0f 10 05 69 3a 60 	movss  0x603a69(%rip),%xmm0        # b256bc <anon.65fa6619250d5a71bfd5ef20e1dfbaf0.11.llvm.7726090819372637783+0x8>
  521c52:	00 
  521c53:	0f 29 84 24 00 04 00 	movaps %xmm0,0x400(%rsp)
  521c5a:	00 
  521c5b:	f2 0f 10 05 cd cc 5f 	movsd  0x5fcccd(%rip),%xmm0        # b1e930 <anon.53de480418173883b8e15d81740454e2.346.llvm.622318203107919755+0x458>
  521c62:	00 
  521c63:	0f 29 84 24 10 04 00 	movaps %xmm0,0x410(%rsp)
  521c6a:	00 
  521c6b:	66 0f 28 84 24 b0 04 	movapd 0x4b0(%rsp),%xmm0
  521c72:	00 00 
  521c74:	66 0f 29 84 24 20 04 	movapd %xmm0,0x420(%rsp)
  521c7b:	00 00 
  521c7d:	e9 fd 00 00 00       	jmp    521d7f <<gpui_gpu::renderer::RendererState>::render+0x9ff>
  521c82:	0f 10 84 24 80 04 00 	movups 0x480(%rsp),%xmm0
  521c89:	00 
  521c8a:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  521c8f:	0f 10 84 24 90 04 00 	movups 0x490(%rsp),%xmm0
  521c96:	00 
  521c97:	0f 29 84 24 20 04 00 	movaps %xmm0,0x420(%rsp)
  521c9e:	00 
  521c9f:	8b 84 24 a0 04 00 00 	mov    0x4a0(%rsp),%eax
  521ca6:	89 84 24 94 00 00 00 	mov    %eax,0x94(%rsp)
  521cad:	8b 84 24 a4 04 00 00 	mov    0x4a4(%rsp),%eax
  521cb4:	89 84 24 90 00 00 00 	mov    %eax,0x90(%rsp)
  521cbb:	f2 0f 10 84 24 a8 04 	movsd  0x4a8(%rsp),%xmm0
  521cc2:	00 00 
  521cc4:	0f 29 84 24 80 03 00 	movaps %xmm0,0x380(%rsp)
  521ccb:	00 
  521ccc:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
  521cd1:	0f 28 c8             	movaps %xmm0,%xmm1
  521cd4:	0f 16 8c 24 78 04 00 	movhps 0x478(%rsp),%xmm1
  521cdb:	00 
  521cdc:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
  521ce1:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  521ce8:	00 
  521ce9:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
  521cf0:	00 
  521cf1:	0f 11 84 24 c8 01 00 	movups %xmm0,0x1c8(%rsp)
  521cf8:	00 
  521cf9:	48 8d 94 24 78 04 00 	lea    0x478(%rsp),%rdx
  521d00:	00 
  521d01:	48 8b 42 10          	mov    0x10(%rdx),%rax
  521d05:	48 8d 8c 24 18 02 00 	lea    0x218(%rsp),%rcx
  521d0c:	00 
  521d0d:	48 89 41 d0          	mov    %rax,-0x30(%rcx)
  521d11:	0f 10 02             	movups (%rdx),%xmm0
  521d14:	0f 11 41 c0          	movups %xmm0,-0x40(%rcx)
  521d18:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  521d1d:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
  521d24:	00 
  521d25:	48 8d 94 24 90 04 00 	lea    0x490(%rsp),%rdx
  521d2c:	00 
  521d2d:	e8 5e e8 ff ff       	call   520590 <<gpui_gpu::renderer::RendererState>::correction>
  521d32:	89 84 24 8c 00 00 00 	mov    %eax,0x8c(%rsp)
  521d39:	f2 0f 10 84 24 a0 00 	movsd  0xa0(%rsp),%xmm0
  521d40:	00 00 
  521d42:	66 0f 5a 4c 24 20    	cvtpd2ps 0x20(%rsp),%xmm1
  521d48:	66 0f 29 8c 24 70 03 	movapd %xmm1,0x370(%rsp)
  521d4f:	00 00 
  521d51:	66 0f 5a 4c 24 70    	cvtpd2ps 0x70(%rsp),%xmm1
  521d57:	66 0f 29 8c 24 10 04 	movapd %xmm1,0x410(%rsp)
  521d5e:	00 00 
  521d60:	66 0f c6 44 24 50 02 	shufpd $0x2,0x50(%rsp),%xmm0
  521d67:	66 0f 5a c0          	cvtpd2ps %xmm0,%xmm0
  521d6b:	66 0f 29 84 24 00 04 	movapd %xmm0,0x400(%rsp)
  521d72:	00 00 
  521d74:	c7 84 24 f0 00 00 00 	movl   $0x0,0xf0(%rsp)
  521d7b:	00 00 00 00 
  521d7f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  521d84:	48 8d 04 85 00 00 00 	lea    0x0(,%rax,4),%rax
  521d8b:	00 
  521d8c:	48 89 84 24 30 04 00 	mov    %rax,0x430(%rsp)
  521d93:	00 
  521d94:	80 bc 24 e0 00 00 00 	cmpb   $0x0,0xe0(%rsp)
  521d9b:	00 
  521d9c:	0f 84 b5 01 00 00    	je     521f57 <<gpui_gpu::renderer::RendererState>::render+0xbd7>
  521da2:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  521da7:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  521dac:	48 8d 04 81          	lea    (%rcx,%rax,4),%rax
  521db0:	48 89 8c 24 a0 01 00 	mov    %rcx,0x1a0(%rsp)
  521db7:	00 
  521db8:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
  521dbf:	00 
  521dc0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  521dc5:	48 89 84 24 b0 01 00 	mov    %rax,0x1b0(%rsp)
  521dcc:	00 
  521dcd:	48 c7 84 24 b8 01 00 	movq   $0x0,0x1b8(%rsp)
  521dd4:	00 00 00 00 00 
  521dd9:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  521de0:	00 
  521de1:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
  521de8:	00 
  521de9:	e8 22 3a 00 00       	call   525810 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  521dee:	80 bc 24 20 01 00 00 	cmpb   $0xff,0x120(%rsp)
  521df5:	ff 
  521df6:	0f 84 1a 07 00 00    	je     522516 <<gpui_gpu::renderer::RendererState>::render+0x1196>
  521dfc:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
  521e00:	66 0f 29 44 24 20    	movapd %xmm0,0x20(%rsp)
  521e06:	48 8b 94 24 18 01 00 	mov    0x118(%rsp),%rdx
  521e0d:	00 
  521e0e:	48 03 94 24 c8 00 00 	add    0xc8(%rsp),%rdx
  521e15:	00 
  521e16:	48 8d b4 24 19 01 00 	lea    0x119(%rsp),%rsi
  521e1d:	00 
  521e1e:	0f 10 46 3f          	movups 0x3f(%rsi),%xmm0
  521e22:	48 8d 8c 24 18 02 00 	lea    0x218(%rsp),%rcx
  521e29:	00 
  521e2a:	0f 11 41 e0          	movups %xmm0,-0x20(%rcx)
  521e2e:	0f 10 46 4f          	movups 0x4f(%rsi),%xmm0
  521e32:	0f 11 41 30          	movups %xmm0,0x30(%rcx)
  521e36:	48 8b 46 37          	mov    0x37(%rsi),%rax
  521e3a:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
  521e41:	00 
  521e42:	0f 10 46 07          	movups 0x7(%rsi),%xmm0
  521e46:	0f 10 4e 17          	movups 0x17(%rsi),%xmm1
  521e4a:	0f 10 56 27          	movups 0x27(%rsi),%xmm2
  521e4e:	0f 29 94 24 e0 01 00 	movaps %xmm2,0x1e0(%rsp)
  521e55:	00 
  521e56:	0f 29 8c 24 d0 01 00 	movaps %xmm1,0x1d0(%rsp)
  521e5d:	00 
  521e5e:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
  521e65:	00 
  521e66:	48 8d b4 24 78 04 00 	lea    0x478(%rsp),%rsi
  521e6d:	00 
  521e6e:	48 8b 46 10          	mov    0x10(%rsi),%rax
  521e72:	48 8d bc 24 f0 01 00 	lea    0x1f0(%rsp),%rdi
  521e79:	00 
  521e7a:	48 89 47 40          	mov    %rax,0x40(%rdi)
  521e7e:	0f 10 06             	movups (%rsi),%xmm0
  521e81:	0f 11 47 30          	movups %xmm0,0x30(%rdi)
  521e85:	48 8d 84 24 90 04 00 	lea    0x490(%rsp),%rax
  521e8c:	00 
  521e8d:	0f 10 00             	movups (%rax),%xmm0
  521e90:	0f 11 41 20          	movups %xmm0,0x20(%rcx)
  521e94:	0f 10 46 28          	movups 0x28(%rsi),%xmm0
  521e98:	0f 11 41 40          	movups %xmm0,0x40(%rcx)
  521e9c:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  521ea3:	00 
  521ea4:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
  521eab:	00 
  521eac:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
  521eb1:	0f 29 84 24 10 02 00 	movaps %xmm0,0x210(%rsp)
  521eb8:	00 
  521eb9:	48 8d bc 24 e8 02 00 	lea    0x2e8(%rsp),%rdi
  521ec0:	00 
  521ec1:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
  521ec8:	00 
  521ec9:	44 89 f1             	mov    %r14d,%ecx
  521ecc:	45 89 f8             	mov    %r15d,%r8d
  521ecf:	e8 5c 30 00 00       	call   524f30 <gpui_gpu::renderer::validate_draw>
  521ed4:	8b 8c 24 e8 02 00 00 	mov    0x2e8(%rsp),%ecx
  521edb:	48 8b 84 24 ec 02 00 	mov    0x2ec(%rsp),%rax
  521ee2:	00 
  521ee3:	83 f9 ff             	cmp    $0xffffffff,%ecx
  521ee6:	0f 85 cc 0b 00 00    	jne    522ab8 <<gpui_gpu::renderer::RendererState>::render+0x1738>
  521eec:	0f 28 4c 24 20       	movaps 0x20(%rsp),%xmm1
  521ef1:	0f 28 c1             	movaps %xmm1,%xmm0
  521ef4:	66 48 0f 6e d0       	movq   %rax,%xmm2
  521ef9:	0f 5f ca             	maxps  %xmm2,%xmm1
  521efc:	0f c2 d2 03          	cmpunordps %xmm2,%xmm2
  521f00:	0f 54 c2             	andps  %xmm2,%xmm0
  521f03:	0f 55 d1             	andnps %xmm1,%xmm2
  521f06:	0f 56 d0             	orps   %xmm0,%xmm2
  521f09:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
  521f0e:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  521f15:	00 
  521f16:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
  521f1d:	00 
  521f1e:	e8 ed 38 00 00       	call   525810 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  521f23:	80 bc 24 20 01 00 00 	cmpb   $0xff,0x120(%rsp)
  521f2a:	ff 
  521f2b:	0f 85 d5 fe ff ff    	jne    521e06 <<gpui_gpu::renderer::RendererState>::render+0xa86>
  521f31:	66 0f 6f 44 24 20    	movdqa 0x20(%rsp),%xmm0
  521f37:	66 0f 7e c1          	movd   %xmm0,%ecx
  521f3b:	0f c6 c0 55          	shufps $0x55,%xmm0,%xmm0
  521f3f:	66 0f 7e c0          	movd   %xmm0,%eax
  521f43:	48 c1 e0 20          	shl    $0x20,%rax
  521f47:	48 09 c1             	or     %rax,%rcx
  521f4a:	48 89 8c 24 b8 00 00 	mov    %rcx,0xb8(%rsp)
  521f51:	00 
  521f52:	e9 cb 05 00 00       	jmp    522522 <<gpui_gpu::renderer::RendererState>::render+0x11a2>
  521f57:	48 83 7c 24 38 00    	cmpq   $0x0,0x38(%rsp)
  521f5d:	0f 84 42 0a 00 00    	je     5229a5 <<gpui_gpu::renderer::RendererState>::render+0x1625>
  521f63:	8b 84 24 8c 00 00 00 	mov    0x8c(%rsp),%eax
  521f6a:	0d 00 00 00 80       	or     $0x80000000,%eax
  521f6f:	89 84 24 24 03 00 00 	mov    %eax,0x324(%rsp)
  521f76:	0f 28 84 24 70 03 00 	movaps 0x370(%rsp),%xmm0
  521f7d:	00 
  521f7e:	0f c6 c0 55          	shufps $0x55,%xmm0,%xmm0
  521f82:	0f 29 84 24 c0 04 00 	movaps %xmm0,0x4c0(%rsp)
  521f89:	00 
  521f8a:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  521f91:	00 00 00 00 00 
  521f96:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  521f9b:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  521fa2:	00 
  521fa3:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  521fa6:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  521fad:	00 
  521fae:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  521fb3:	e8 78 d8 ff ff       	call   51f830 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  521fb8:	0f b6 bc 24 18 01 00 	movzbl 0x118(%rsp),%edi
  521fbf:	00 
  521fc0:	48 8d b4 24 19 01 00 	lea    0x119(%rsp),%rsi
  521fc7:	00 
  521fc8:	0f b6 46 02          	movzbl 0x2(%rsi),%eax
  521fcc:	48 8d 94 24 f0 01 00 	lea    0x1f0(%rsp),%rdx
  521fd3:	00 
  521fd4:	88 42 d3             	mov    %al,-0x2d(%rdx)
  521fd7:	0f b7 06             	movzwl (%rsi),%eax
  521fda:	66 89 42 d1          	mov    %ax,-0x2f(%rdx)
  521fde:	f3 0f 10 94 24 1c 01 	movss  0x11c(%rsp),%xmm2
  521fe5:	00 00 
  521fe7:	4c 8b 84 24 20 01 00 	mov    0x120(%rsp),%r8
  521fee:	00 
  521fef:	48 8b 46 2f          	mov    0x2f(%rsi),%rax
  521ff3:	48 89 02             	mov    %rax,(%rdx)
  521ff6:	0f 10 46 0f          	movups 0xf(%rsi),%xmm0
  521ffa:	0f 10 4e 1f          	movups 0x1f(%rsi),%xmm1
  521ffe:	0f 11 4a f0          	movups %xmm1,-0x10(%rdx)
  522002:	0f 11 42 e0          	movups %xmm0,-0x20(%rdx)
  522006:	0f 10 8c 24 50 01 00 	movups 0x150(%rsp),%xmm1
  52200d:	00 
  52200e:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
  522015:	00 
  522016:	0f 10 00             	movups (%rax),%xmm0
  522019:	48 8d 8c 24 18 02 00 	lea    0x218(%rsp),%rcx
  522020:	00 
  522021:	0f 11 41 30          	movups %xmm0,0x30(%rcx)
  522025:	48 8b 84 24 b0 03 00 	mov    0x3b0(%rsp),%rax
  52202c:	00 
  52202d:	48 89 42 40          	mov    %rax,0x40(%rdx)
  522031:	0f 28 84 24 a0 03 00 	movaps 0x3a0(%rsp),%xmm0
  522038:	00 
  522039:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
  52203d:	48 8d 84 24 b8 03 00 	lea    0x3b8(%rsp),%rax
  522044:	00 
  522045:	0f 10 00             	movups (%rax),%xmm0
  522048:	0f 11 41 20          	movups %xmm0,0x20(%rcx)
  52204c:	0f 28 84 24 40 03 00 	movaps 0x340(%rsp),%xmm0
  522053:	00 
  522054:	0f 11 41 40          	movups %xmm0,0x40(%rcx)
  522058:	0f 29 8c 24 80 01 00 	movaps %xmm1,0x180(%rsp)
  52205f:	00 
  522060:	0f 11 8c 24 f8 01 00 	movups %xmm1,0x1f8(%rsp)
  522067:	00 
  522068:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  52206f:	00 
  522070:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
  522077:	00 
  522078:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
  52207d:	0f 11 84 24 10 02 00 	movups %xmm0,0x210(%rsp)
  522084:	00 
  522085:	40 88 bc 24 b0 00 00 	mov    %dil,0xb0(%rsp)
  52208c:	00 
  52208d:	40 88 bc 24 c0 01 00 	mov    %dil,0x1c0(%rsp)
  522094:	00 
  522095:	0f 29 94 24 90 03 00 	movaps %xmm2,0x390(%rsp)
  52209c:	00 
  52209d:	f3 0f 11 94 24 c4 01 	movss  %xmm2,0x1c4(%rsp)
  5220a4:	00 00 
  5220a6:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
  5220ab:	4c 89 84 24 c8 01 00 	mov    %r8,0x1c8(%rsp)
  5220b2:	00 
  5220b3:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  5220ba:	00 
  5220bb:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
  5220c2:	00 
  5220c3:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
  5220ca:	00 
  5220cb:	44 89 f1             	mov    %r14d,%ecx
  5220ce:	45 89 f8             	mov    %r15d,%r8d
  5220d1:	e8 5a 2e 00 00       	call   524f30 <gpui_gpu::renderer::validate_draw>
  5220d6:	8b 84 24 18 01 00 00 	mov    0x118(%rsp),%eax
  5220dd:	48 8b 8c 24 1c 01 00 	mov    0x11c(%rsp),%rcx
  5220e4:	00 
  5220e5:	48 89 8c 24 08 01 00 	mov    %rcx,0x108(%rsp)
  5220ec:	00 
  5220ed:	83 f8 ff             	cmp    $0xffffffff,%eax
  5220f0:	0f 85 3d 0a 00 00    	jne    522b33 <<gpui_gpu::renderer::RendererState>::render+0x17b3>
  5220f6:	80 bc 24 b0 00 00 00 	cmpb   $0x2,0xb0(%rsp)
  5220fd:	02 
  5220fe:	0f 94 44 24 37       	sete   0x37(%rsp)
  522103:	48 83 7c 24 20 00    	cmpq   $0x0,0x20(%rsp)
  522109:	0f 95 44 24 36       	setne  0x36(%rsp)
  52210e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  522113:	8b 48 10             	mov    0x10(%rax),%ecx
  522116:	b8 00 00 00 80       	mov    $0x80000000,%eax
  52211b:	09 c1                	or     %eax,%ecx
  52211d:	89 8c 24 28 03 00 00 	mov    %ecx,0x328(%rsp)
  522124:	80 bc 24 f0 00 00 00 	cmpb   $0x0,0xf0(%rsp)
  52212b:	00 
  52212c:	74 5e                	je     52218c <<gpui_gpu::renderer::RendererState>::render+0xe0c>
  52212e:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  522135:	00 
  522136:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
  52213d:	00 
  52213e:	48 8b 94 24 58 03 00 	mov    0x358(%rsp),%rdx
  522145:	00 
  522146:	e8 b5 34 00 00       	call   525600 <gpui_gpu::renderer::sampled_solid_rect>
  52214b:	8b 84 24 18 01 00 00 	mov    0x118(%rsp),%eax
  522152:	0f 10 84 24 1c 01 00 	movups 0x11c(%rsp),%xmm0
  522159:	00 
  52215a:	0f 29 84 24 80 01 00 	movaps %xmm0,0x180(%rsp)
  522161:	00 
  522162:	83 f8 ff             	cmp    $0xffffffff,%eax
  522165:	0f 85 49 0e 00 00    	jne    522fb4 <<gpui_gpu::renderer::RendererState>::render+0x1c34>
  52216b:	0f 28 8c 24 80 01 00 	movaps 0x180(%rsp),%xmm1
  522172:	00 
  522173:	0f 28 c1             	movaps %xmm1,%xmm0
  522176:	66 0f 15 c1          	unpckhpd %xmm1,%xmm0
  52217a:	0f c6 c9 ff          	shufps $0xff,%xmm1,%xmm1
  52217e:	48 c7 84 24 f8 00 00 	movq   $0x0,0xf8(%rsp)
  522185:	00 00 00 00 00 
  52218a:	eb 23                	jmp    5221af <<gpui_gpu::renderer::RendererState>::render+0xe2f>
  52218c:	0f 28 8c 24 80 01 00 	movaps 0x180(%rsp),%xmm1
  522193:	00 
  522194:	0f 28 c1             	movaps %xmm1,%xmm0
  522197:	66 0f 15 c1          	unpckhpd %xmm1,%xmm0
  52219b:	0f c6 c9 ff          	shufps $0xff,%xmm1,%xmm1
  52219f:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
  5221a6:	00 
  5221a7:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
  5221ae:	00 
  5221af:	8b 84 24 94 00 00 00 	mov    0x94(%rsp),%eax
  5221b6:	89 44 24 20          	mov    %eax,0x20(%rsp)
  5221ba:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
  5221c1:	89 44 24 70          	mov    %eax,0x70(%rsp)
  5221c5:	0f 28 94 24 80 03 00 	movaps 0x380(%rsp),%xmm2
  5221cc:	00 
  5221cd:	0f 29 94 24 e0 00 00 	movaps %xmm2,0xe0(%rsp)
  5221d4:	00 
  5221d5:	80 bc 24 b0 00 00 00 	cmpb   $0x3,0xb0(%rsp)
  5221dc:	03 
  5221dd:	0f 85 a3 00 00 00    	jne    522286 <<gpui_gpu::renderer::RendererState>::render+0xf06>
  5221e3:	0f 57 d2             	xorps  %xmm2,%xmm2
  5221e6:	0f 28 9c 24 90 03 00 	movaps 0x390(%rsp),%xmm3
  5221ed:	00 
  5221ee:	0f 2e da             	ucomiss %xmm2,%xmm3
  5221f1:	8b 84 24 94 00 00 00 	mov    0x94(%rsp),%eax
  5221f8:	89 44 24 20          	mov    %eax,0x20(%rsp)
  5221fc:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
  522203:	89 44 24 70          	mov    %eax,0x70(%rsp)
  522207:	0f 28 94 24 80 03 00 	movaps 0x380(%rsp),%xmm2
  52220e:	00 
  52220f:	0f 29 94 24 e0 00 00 	movaps %xmm2,0xe0(%rsp)
  522216:	00 
  522217:	75 02                	jne    52221b <<gpui_gpu::renderer::RendererState>::render+0xe9b>
  522219:	7b 6b                	jnp    522286 <<gpui_gpu::renderer::RendererState>::render+0xf06>
  52221b:	f3 0f 10 25 61 35 60 	movss  0x603561(%rip),%xmm4        # b25784 <anon.9adf6b51329d0e8f0ba7a07edbf8a285.69.llvm.2988996700849332186+0x10>
  522222:	00 
  522223:	f3 0f 59 c4          	mulss  %xmm4,%xmm0
  522227:	0f 28 ac 24 90 03 00 	movaps 0x390(%rsp),%xmm5
  52222e:	00 
  52222f:	0f 28 d5             	movaps %xmm5,%xmm2
  522232:	f3 0f 5d d0          	minss  %xmm0,%xmm2
  522236:	f3 0f c2 c0 03       	cmpunordss %xmm0,%xmm0
  52223b:	0f 28 d8             	movaps %xmm0,%xmm3
  52223e:	0f 55 da             	andnps %xmm2,%xmm3
  522241:	0f 54 c5             	andps  %xmm5,%xmm0
  522244:	0f 56 c3             	orps   %xmm3,%xmm0
  522247:	f3 0f 59 cc          	mulss  %xmm4,%xmm1
  52224b:	0f 28 d1             	movaps %xmm1,%xmm2
  52224e:	f3 0f c2 d1 03       	cmpunordss %xmm1,%xmm2
  522253:	0f 28 da             	movaps %xmm2,%xmm3
  522256:	0f 54 d8             	andps  %xmm0,%xmm3
  522259:	f3 0f 5d c1          	minss  %xmm1,%xmm0
  52225d:	0f 55 d0             	andnps %xmm0,%xmm2
  522260:	0f 56 d3             	orps   %xmm3,%xmm2
  522263:	66 0f 7e d0          	movd   %xmm2,%eax
  522267:	89 44 24 20          	mov    %eax,0x20(%rsp)
  52226b:	25 00 00 80 ff       	and    $0xff800000,%eax
  522270:	b9 00 00 00 7f       	mov    $0x7f000000,%ecx
  522275:	29 c1                	sub    %eax,%ecx
  522277:	89 4c 24 70          	mov    %ecx,0x70(%rsp)
  52227b:	0f 57 c0             	xorps  %xmm0,%xmm0
  52227e:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
  522285:	00 
  522286:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  52228b:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
  522292:	00 
  522293:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  522298:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
  52229f:	00 
  5222a0:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  5222a5:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
  5222ac:	00 
  5222ad:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  5222b4:	00 
  5222b5:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  5222bc:	00 
  5222bd:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
  5222c2:	0f 11 84 24 38 01 00 	movups %xmm0,0x138(%rsp)
  5222c9:	00 
  5222ca:	48 8b 84 24 c0 03 00 	mov    0x3c0(%rsp),%rax
  5222d1:	00 
  5222d2:	48 8d 8c 24 19 01 00 	lea    0x119(%rsp),%rcx
  5222d9:	00 
  5222da:	48 89 41 4f          	mov    %rax,0x4f(%rcx)
  5222de:	0f 28 84 24 a0 03 00 	movaps 0x3a0(%rsp),%xmm0
  5222e5:	00 
  5222e6:	0f 28 8c 24 b0 03 00 	movaps 0x3b0(%rsp),%xmm1
  5222ed:	00 
  5222ee:	0f 11 49 3f          	movups %xmm1,0x3f(%rcx)
  5222f2:	0f 11 41 2f          	movups %xmm0,0x2f(%rcx)
  5222f6:	0f 28 84 24 40 03 00 	movaps 0x340(%rsp),%xmm0
  5222fd:	00 
  5222fe:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
  522305:	00 
  522306:	0f 11 40 10          	movups %xmm0,0x10(%rax)
  52230a:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  522311:	00 
  522312:	ff 15 68 3f da 00    	call   *0xda3f68(%rip)        # 12c6280 <_GLOBAL_OFFSET_TABLE_+0x2440>
  522318:	8b 8c 24 8c 00 00 00 	mov    0x8c(%rsp),%ecx
  52231f:	89 8c 24 b0 00 00 00 	mov    %ecx,0xb0(%rsp)
  522326:	85 c0                	test   %eax,%eax
  522328:	74 34                	je     52235e <<gpui_gpu::renderer::RendererState>::render+0xfde>
  52232a:	48 8b bc 24 98 00 00 	mov    0x98(%rsp),%rdi
  522331:	00 
  522332:	89 c6                	mov    %eax,%esi
  522334:	e8 67 65 00 00       	call   5288a0 <gpui_gpu::renderer::slots::color_word>
  522339:	89 44 24 20          	mov    %eax,0x20(%rsp)
  52233d:	0f 57 c0             	xorps  %xmm0,%xmm0
  522340:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
  522347:	00 
  522348:	c7 44 24 70 00 00 00 	movl   $0x0,0x70(%rsp)
  52234f:	00 
  522350:	8b 84 24 24 03 00 00 	mov    0x324(%rsp),%eax
  522357:	89 84 24 b0 00 00 00 	mov    %eax,0xb0(%rsp)
  52235e:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
  522365:	00 
  522366:	48 c1 e8 20          	shr    $0x20,%rax
  52236a:	48 89 84 24 90 03 00 	mov    %rax,0x390(%rsp)
  522371:	00 
  522372:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  522377:	48 8b 08             	mov    (%rax),%rcx
  52237a:	48 8b 70 10          	mov    0x10(%rax),%rsi
  52237e:	48 29 f1             	sub    %rsi,%rcx
  522381:	48 83 f9 05          	cmp    $0x5,%rcx
  522385:	0f 86 63 01 00 00    	jbe    5224ee <<gpui_gpu::renderer::RendererState>::render+0x116e>
  52238b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  522390:	48 8b 48 08          	mov    0x8(%rax),%rcx
  522394:	48 c1 e6 04          	shl    $0x4,%rsi
  522398:	0f 28 84 24 80 01 00 	movaps 0x180(%rsp),%xmm0
  52239f:	00 
  5223a0:	0f 11 04 31          	movups %xmm0,(%rcx,%rsi,1)
  5223a4:	0f 28 84 24 00 04 00 	movaps 0x400(%rsp),%xmm0
  5223ab:	00 
  5223ac:	0f 13 44 31 10       	movlps %xmm0,0x10(%rcx,%rsi,1)
  5223b1:	0f 28 84 24 70 03 00 	movaps 0x370(%rsp),%xmm0
  5223b8:	00 
  5223b9:	f3 0f 11 44 31 18    	movss  %xmm0,0x18(%rcx,%rsi,1)
  5223bf:	48 8b 94 24 f8 00 00 	mov    0xf8(%rsp),%rdx
  5223c6:	00 
  5223c7:	89 54 31 1c          	mov    %edx,0x1c(%rcx,%rsi,1)
  5223cb:	0f 28 84 24 10 04 00 	movaps 0x410(%rsp),%xmm0
  5223d2:	00 
  5223d3:	0f 13 44 31 20       	movlps %xmm0,0x20(%rcx,%rsi,1)
  5223d8:	0f 28 84 24 c0 04 00 	movaps 0x4c0(%rsp),%xmm0
  5223df:	00 
  5223e0:	f3 0f 11 44 31 28    	movss  %xmm0,0x28(%rcx,%rsi,1)
  5223e6:	48 8b 94 24 90 03 00 	mov    0x390(%rsp),%rdx
  5223ed:	00 
  5223ee:	89 54 31 2c          	mov    %edx,0x2c(%rcx,%rsi,1)
  5223f2:	0f 28 84 24 20 04 00 	movaps 0x420(%rsp),%xmm0
  5223f9:	00 
  5223fa:	0f 11 44 31 30       	movups %xmm0,0x30(%rcx,%rsi,1)
  5223ff:	8b 54 24 20          	mov    0x20(%rsp),%edx
  522403:	89 54 31 40          	mov    %edx,0x40(%rcx,%rsi,1)
  522407:	8b 54 24 70          	mov    0x70(%rsp),%edx
  52240b:	89 54 31 44          	mov    %edx,0x44(%rcx,%rsi,1)
  52240f:	66 0f 6f 84 24 e0 00 	movdqa 0xe0(%rsp),%xmm0
  522416:	00 00 
  522418:	66 0f d6 44 31 48    	movq   %xmm0,0x48(%rcx,%rsi,1)
  52241e:	48 c7 44 31 50 00 00 	movq   $0x0,0x50(%rcx,%rsi,1)
  522425:	00 00 
  522427:	c7 44 31 58 00 00 00 	movl   $0x0,0x58(%rcx,%rsi,1)
  52242e:	00 
  52242f:	8b 94 24 b0 00 00 00 	mov    0xb0(%rsp),%edx
  522436:	89 54 31 5c          	mov    %edx,0x5c(%rcx,%rsi,1)
  52243a:	48 83 40 10 06       	addq   $0x6,0x10(%rax)
  52243f:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  522446:	00 
  522447:	48 89 c6             	mov    %rax,%rsi
  52244a:	48 8d 94 24 c0 01 00 	lea    0x1c0(%rsp),%rdx
  522451:	00 
  522452:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
  522459:	00 
  52245a:	44 8b 84 24 28 03 00 	mov    0x328(%rsp),%r8d
  522461:	00 
  522462:	4c 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%r9
  522469:	00 
  52246a:	ff b4 24 00 01 00 00 	push   0x100(%rsp)
  522471:	41 57                	push   %r15
  522473:	41 56                	push   %r14
  522475:	ff 74 24 60          	push   0x60(%rsp)
  522479:	e8 42 17 00 00       	call   523bc0 <<gpui_gpu::renderer::RendererState>::bin_draw>
  52247e:	48 83 c4 20          	add    $0x20,%rsp
  522482:	8b 84 24 18 01 00 00 	mov    0x118(%rsp),%eax
  522489:	83 f8 ff             	cmp    $0xffffffff,%eax
  52248c:	0f 85 12 f4 ff ff    	jne    5218a4 <<gpui_gpu::renderer::RendererState>::render+0x524>
  522492:	0f b6 4c 24 37       	movzbl 0x37(%rsp),%ecx
  522497:	22 4c 24 36          	and    0x36(%rsp),%cl
  52249b:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  5224a0:	08 c8                	or     %cl,%al
  5224a2:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  5224a7:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
  5224ae:	00 
  5224af:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  5224b6:	00 
  5224b7:	48 ff 84 24 c8 00 00 	incq   0xc8(%rsp)
  5224be:	00 
  5224bf:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
  5224c6:	00 
  5224c7:	48 83 c2 04          	add    $0x4,%rdx
  5224cb:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  5224d0:	48 8d 04 85 00 00 00 	lea    0x0(,%rax,4),%rax
  5224d7:	00 
  5224d8:	48 89 94 24 b8 00 00 	mov    %rdx,0xb8(%rsp)
  5224df:	00 
  5224e0:	48 39 d0             	cmp    %rdx,%rax
  5224e3:	0f 85 ad fa ff ff    	jne    521f96 <<gpui_gpu::renderer::RendererState>::render+0xc16>
  5224e9:	e9 b7 04 00 00       	jmp    5229a5 <<gpui_gpu::renderer::RendererState>::render+0x1625>
  5224ee:	ba 06 00 00 00       	mov    $0x6,%edx
  5224f3:	b9 04 00 00 00       	mov    $0x4,%ecx
  5224f8:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  5224fe:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  522503:	e8 f8 23 b8 ff       	call   a4900 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  522508:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  52250d:	48 8b 70 10          	mov    0x10(%rax),%rsi
  522511:	e9 75 fe ff ff       	jmp    52238b <<gpui_gpu::renderer::RendererState>::render+0x100b>
  522516:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  52251d:	00 00 00 00 00 
  522522:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  522527:	8b 40 10             	mov    0x10(%rax),%eax
  52252a:	89 84 24 b0 00 00 00 	mov    %eax,0xb0(%rsp)
  522531:	80 bc 24 f0 00 00 00 	cmpb   $0x0,0xf0(%rsp)
  522538:	00 
  522539:	b8 00 00 00 00       	mov    $0x0,%eax
  52253e:	48 0f 44 84 24 b8 00 	cmove  0xb8(%rsp),%rax
  522545:	00 00 
  522547:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  52254c:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  522551:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
  522558:	00 
  522559:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  52255e:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
  522565:	00 
  522566:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  52256b:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
  522572:	00 
  522573:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  52257a:	00 
  52257b:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
  522582:	00 
  522583:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
  522588:	0f 11 84 24 e0 01 00 	movups %xmm0,0x1e0(%rsp)
  52258f:	00 
  522590:	48 8d 8c 24 78 04 00 	lea    0x478(%rsp),%rcx
  522597:	00 
  522598:	48 8b 41 20          	mov    0x20(%rcx),%rax
  52259c:	48 8d 94 24 f0 01 00 	lea    0x1f0(%rsp),%rdx
  5225a3:	00 
  5225a4:	48 89 42 20          	mov    %rax,0x20(%rdx)
  5225a8:	0f 10 01             	movups (%rcx),%xmm0
  5225ab:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
  5225af:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  5225b3:	0f 11 02             	movups %xmm0,(%rdx)
  5225b6:	f3 0f 6f 41 28       	movdqu 0x28(%rcx),%xmm0
  5225bb:	48 8d 84 24 18 02 00 	lea    0x218(%rsp),%rax
  5225c2:	00 
  5225c3:	f3 0f 7f 00          	movdqu %xmm0,(%rax)
  5225c7:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
  5225ce:	00 
  5225cf:	ff 15 ab 3c da 00    	call   *0xda3cab(%rip)        # 12c6280 <_GLOBAL_OFFSET_TABLE_+0x2440>
  5225d5:	85 c0                	test   %eax,%eax
  5225d7:	74 41                	je     52261a <<gpui_gpu::renderer::RendererState>::render+0x129a>
  5225d9:	48 8b bc 24 98 00 00 	mov    0x98(%rsp),%rdi
  5225e0:	00 
  5225e1:	89 c6                	mov    %eax,%esi
  5225e3:	e8 b8 62 00 00       	call   5288a0 <gpui_gpu::renderer::slots::color_word>
  5225e8:	89 84 24 94 00 00 00 	mov    %eax,0x94(%rsp)
  5225ef:	81 8c 24 8c 00 00 00 	orl    $0x80000000,0x8c(%rsp)
  5225f6:	00 00 00 80 
  5225fa:	c7 84 24 90 00 00 00 	movl   $0x0,0x90(%rsp)
  522601:	00 00 00 00 
  522605:	c7 44 24 70 00 00 00 	movl   $0x0,0x70(%rsp)
  52260c:	00 
  52260d:	c7 84 24 e0 00 00 00 	movl   $0x0,0xe0(%rsp)
  522614:	00 00 00 00 
  522618:	eb 1d                	jmp    522637 <<gpui_gpu::renderer::RendererState>::render+0x12b7>
  52261a:	66 0f 6f 84 24 80 03 	movdqa 0x380(%rsp),%xmm0
  522621:	00 00 
  522623:	66 0f 7e 44 24 70    	movd   %xmm0,0x70(%rsp)
  522629:	66 0f 70 c0 55       	pshufd $0x55,%xmm0,%xmm0
  52262e:	66 0f 7e 84 24 e0 00 	movd   %xmm0,0xe0(%rsp)
  522635:	00 00 
  522637:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  52263c:	48 8b 08             	mov    (%rax),%rcx
  52263f:	48 8b 70 10          	mov    0x10(%rax),%rsi
  522643:	48 29 f1             	sub    %rsi,%rcx
  522646:	48 83 f9 04          	cmp    $0x4,%rcx
  52264a:	0f 86 83 03 00 00    	jbe    5229d3 <<gpui_gpu::renderer::RendererState>::render+0x1653>
  522650:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  522655:	89 f9                	mov    %edi,%ecx
  522657:	48 c1 ef 20          	shr    $0x20,%rdi
  52265b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  522660:	48 8b 50 08          	mov    0x8(%rax),%rdx
  522664:	48 c1 e6 04          	shl    $0x4,%rsi
  522668:	0f 28 84 24 00 04 00 	movaps 0x400(%rsp),%xmm0
  52266f:	00 
  522670:	f3 0f 11 04 32       	movss  %xmm0,(%rdx,%rsi,1)
  522675:	0f c6 c0 55          	shufps $0x55,%xmm0,%xmm0
  522679:	f3 0f 11 44 32 04    	movss  %xmm0,0x4(%rdx,%rsi,1)
  52267f:	0f 28 84 24 70 03 00 	movaps 0x370(%rsp),%xmm0
  522686:	00 
  522687:	f3 0f 11 44 32 08    	movss  %xmm0,0x8(%rdx,%rsi,1)
  52268d:	89 4c 32 0c          	mov    %ecx,0xc(%rdx,%rsi,1)
  522691:	0f 28 8c 24 10 04 00 	movaps 0x410(%rsp),%xmm1
  522698:	00 
  522699:	f3 0f 11 4c 32 10    	movss  %xmm1,0x10(%rdx,%rsi,1)
  52269f:	0f c6 c9 55          	shufps $0x55,%xmm1,%xmm1
  5226a3:	f3 0f 11 4c 32 14    	movss  %xmm1,0x14(%rdx,%rsi,1)
  5226a9:	0f c6 c0 55          	shufps $0x55,%xmm0,%xmm0
  5226ad:	f3 0f 11 44 32 18    	movss  %xmm0,0x18(%rdx,%rsi,1)
  5226b3:	89 7c 32 1c          	mov    %edi,0x1c(%rdx,%rsi,1)
  5226b7:	66 0f 28 84 24 20 04 	movapd 0x420(%rsp),%xmm0
  5226be:	00 00 
  5226c0:	66 0f 11 44 32 20    	movupd %xmm0,0x20(%rdx,%rsi,1)
  5226c6:	8b 8c 24 94 00 00 00 	mov    0x94(%rsp),%ecx
  5226cd:	89 4c 32 30          	mov    %ecx,0x30(%rdx,%rsi,1)
  5226d1:	8b 8c 24 90 00 00 00 	mov    0x90(%rsp),%ecx
  5226d8:	89 4c 32 34          	mov    %ecx,0x34(%rdx,%rsi,1)
  5226dc:	8b 4c 24 70          	mov    0x70(%rsp),%ecx
  5226e0:	89 4c 32 38          	mov    %ecx,0x38(%rdx,%rsi,1)
  5226e4:	8b 8c 24 e0 00 00 00 	mov    0xe0(%rsp),%ecx
  5226eb:	89 4c 32 3c          	mov    %ecx,0x3c(%rdx,%rsi,1)
  5226ef:	8b 8c 24 8c 00 00 00 	mov    0x8c(%rsp),%ecx
  5226f6:	89 4c 32 40          	mov    %ecx,0x40(%rdx,%rsi,1)
  5226fa:	48 c7 44 32 44 00 00 	movq   $0x0,0x44(%rdx,%rsi,1)
  522701:	00 00 
  522703:	c7 44 32 4c 00 00 00 	movl   $0x0,0x4c(%rdx,%rsi,1)
  52270a:	00 
  52270b:	48 83 40 10 05       	addq   $0x5,0x10(%rax)
  522710:	48 ff 84 24 10 03 00 	incq   0x310(%rsp)
  522717:	00 
  522718:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  52271d:	48 01 84 24 18 03 00 	add    %rax,0x318(%rsp)
  522724:	00 
  522725:	48 85 c0             	test   %rax,%rax
  522728:	0f 84 77 02 00 00    	je     5229a5 <<gpui_gpu::renderer::RendererState>::render+0x1625>
  52272e:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
  522735:	00 00 
  522737:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  52273c:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  522741:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  522744:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  52274b:	00 
  52274c:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  522751:	e8 da d0 ff ff       	call   51f830 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  522756:	0f b6 84 24 18 01 00 	movzbl 0x118(%rsp),%eax
  52275d:	00 
  52275e:	4c 8d 84 24 19 01 00 	lea    0x119(%rsp),%r8
  522765:	00 
  522766:	41 8b 08             	mov    (%r8),%ecx
  522769:	41 8b 50 03          	mov    0x3(%r8),%edx
  52276d:	48 8d bc 24 f0 01 00 	lea    0x1f0(%rsp),%rdi
  522774:	00 
  522775:	89 57 d4             	mov    %edx,-0x2c(%rdi)
  522778:	89 4f d1             	mov    %ecx,-0x2f(%rdi)
  52277b:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
  522782:	00 
  522783:	41 0f 10 40 0f       	movups 0xf(%r8),%xmm0
  522788:	41 0f 10 48 1f       	movups 0x1f(%r8),%xmm1
  52278d:	0f 11 4f f0          	movups %xmm1,-0x10(%rdi)
  522791:	49 8b 50 2f          	mov    0x2f(%r8),%rdx
  522795:	48 89 17             	mov    %rdx,(%rdi)
  522798:	0f 11 47 e0          	movups %xmm0,-0x20(%rdi)
  52279c:	0f 10 8c 24 50 01 00 	movups 0x150(%rsp),%xmm1
  5227a3:	00 
  5227a4:	48 8d 94 24 60 01 00 	lea    0x160(%rsp),%rdx
  5227ab:	00 
  5227ac:	0f 10 02             	movups (%rdx),%xmm0
  5227af:	48 8d b4 24 18 02 00 	lea    0x218(%rsp),%rsi
  5227b6:	00 
  5227b7:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
  5227bb:	48 8b 94 24 b0 03 00 	mov    0x3b0(%rsp),%rdx
  5227c2:	00 
  5227c3:	48 89 57 40          	mov    %rdx,0x40(%rdi)
  5227c7:	0f 28 84 24 a0 03 00 	movaps 0x3a0(%rsp),%xmm0
  5227ce:	00 
  5227cf:	0f 11 47 30          	movups %xmm0,0x30(%rdi)
  5227d3:	48 8d 94 24 b8 03 00 	lea    0x3b8(%rsp),%rdx
  5227da:	00 
  5227db:	0f 10 02             	movups (%rdx),%xmm0
  5227de:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
  5227e2:	0f 28 84 24 40 03 00 	movaps 0x340(%rsp),%xmm0
  5227e9:	00 
  5227ea:	0f 11 46 40          	movups %xmm0,0x40(%rsi)
  5227ee:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
  5227f3:	0f 11 8c 24 f8 01 00 	movups %xmm1,0x1f8(%rsp)
  5227fa:	00 
  5227fb:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
  522802:	00 
  522803:	48 89 94 24 08 02 00 	mov    %rdx,0x208(%rsp)
  52280a:	00 
  52280b:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
  522810:	0f 11 84 24 10 02 00 	movups %xmm0,0x210(%rsp)
  522817:	00 
  522818:	88 84 24 c0 01 00 00 	mov    %al,0x1c0(%rsp)
  52281f:	48 89 8c 24 c8 01 00 	mov    %rcx,0x1c8(%rsp)
  522826:	00 
  522827:	3c 02                	cmp    $0x2,%al
  522829:	0f 94 84 24 80 01 00 	sete   0x180(%rsp)
  522830:	00 
  522831:	48 85 c9             	test   %rcx,%rcx
  522834:	0f 95 44 24 38       	setne  0x38(%rsp)
  522839:	80 bc 24 f0 00 00 00 	cmpb   $0x0,0xf0(%rsp)
  522840:	00 
  522841:	74 3a                	je     52287d <<gpui_gpu::renderer::RendererState>::render+0x14fd>
  522843:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  52284a:	00 
  52284b:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
  522852:	00 
  522853:	48 8b 94 24 58 03 00 	mov    0x358(%rsp),%rdx
  52285a:	00 
  52285b:	e8 a0 2d 00 00       	call   525600 <gpui_gpu::renderer::sampled_solid_rect>
  522860:	8b 84 24 18 01 00 00 	mov    0x118(%rsp),%eax
  522867:	0f 10 84 24 1c 01 00 	movups 0x11c(%rsp),%xmm0
  52286e:	00 
  52286f:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
  522874:	83 f8 ff             	cmp    $0xffffffff,%eax
  522877:	0f 85 df 07 00 00    	jne    52305c <<gpui_gpu::renderer::RendererState>::render+0x1cdc>
  52287d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  522882:	48 8b 08             	mov    (%rax),%rcx
  522885:	48 8b 40 10          	mov    0x10(%rax),%rax
  522889:	48 29 c1             	sub    %rax,%rcx
  52288c:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
  522893:	00 
  522894:	48 83 f9 01          	cmp    $0x1,%rcx
  522898:	0f 86 d7 00 00 00    	jbe    522975 <<gpui_gpu::renderer::RendererState>::render+0x15f5>
  52289e:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  5228a3:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
  5228a7:	48 c1 e0 04          	shl    $0x4,%rax
  5228ab:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
  5228b1:	f3 0f 7f 04 01       	movdqu %xmm0,(%rcx,%rax,1)
  5228b6:	48 c7 44 01 10 00 00 	movq   $0x0,0x10(%rcx,%rax,1)
  5228bd:	00 00 
  5228bf:	c7 44 01 18 00 00 00 	movl   $0x0,0x18(%rcx,%rax,1)
  5228c6:	00 
  5228c7:	8b 94 24 b0 00 00 00 	mov    0xb0(%rsp),%edx
  5228ce:	89 54 01 1c          	mov    %edx,0x1c(%rcx,%rax,1)
  5228d2:	48 83 46 10 02       	addq   $0x2,0x10(%rsi)
  5228d7:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  5228de:	00 
  5228df:	48 8d 94 24 c0 01 00 	lea    0x1c0(%rsp),%rdx
  5228e6:	00 
  5228e7:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  5228ee:	00 
  5228ef:	4c 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%r8
  5228f6:	00 
  5228f7:	4c 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%r9
  5228fe:	00 
  5228ff:	ff b4 24 00 01 00 00 	push   0x100(%rsp)
  522906:	41 57                	push   %r15
  522908:	41 56                	push   %r14
  52290a:	ff 74 24 60          	push   0x60(%rsp)
  52290e:	e8 ad 12 00 00       	call   523bc0 <<gpui_gpu::renderer::RendererState>::bin_draw>
  522913:	48 83 c4 20          	add    $0x20,%rsp
  522917:	8b 84 24 18 01 00 00 	mov    0x118(%rsp),%eax
  52291e:	83 f8 ff             	cmp    $0xffffffff,%eax
  522921:	0f 85 7d ef ff ff    	jne    5218a4 <<gpui_gpu::renderer::RendererState>::render+0x524>
  522927:	0f b6 8c 24 80 01 00 	movzbl 0x180(%rsp),%ecx
  52292e:	00 
  52292f:	22 4c 24 38          	and    0x38(%rsp),%cl
  522933:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  522938:	08 c8                	or     %cl,%al
  52293a:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  52293f:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
  522946:	00 
  522947:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  52294e:	00 
  52294f:	48 ff 84 24 c8 00 00 	incq   0xc8(%rsp)
  522956:	00 
  522957:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  52295c:	48 83 c1 04          	add    $0x4,%rcx
  522960:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  522965:	48 39 8c 24 30 04 00 	cmp    %rcx,0x430(%rsp)
  52296c:	00 
  52296d:	0f 85 c4 fd ff ff    	jne    522737 <<gpui_gpu::renderer::RendererState>::render+0x13b7>
  522973:	eb 30                	jmp    5229a5 <<gpui_gpu::renderer::RendererState>::render+0x1625>
  522975:	ba 02 00 00 00       	mov    $0x2,%edx
  52297a:	b9 04 00 00 00       	mov    $0x4,%ecx
  52297f:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  522985:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  52298a:	48 8b b4 24 e0 00 00 	mov    0xe0(%rsp),%rsi
  522991:	00 
  522992:	e8 69 1f b8 ff       	call   a4900 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  522997:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  52299c:	48 8b 40 10          	mov    0x10(%rax),%rax
  5229a0:	e9 f9 fe ff ff       	jmp    52289e <<gpui_gpu::renderer::RendererState>::render+0x151e>
  5229a5:	48 8d bc 24 48 04 00 	lea    0x448(%rsp),%rdi
  5229ac:	00 
  5229ad:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
  5229b4:	00 
  5229b5:	ff 15 b5 4f da 00    	call   *0xda4fb5(%rip)        # 12c7970 <_GLOBAL_OFFSET_TABLE_+0x3b30>
  5229bb:	48 8b 84 24 48 04 00 	mov    0x448(%rsp),%rax
  5229c2:	00 
  5229c3:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  5229c8:	48 85 c0             	test   %rax,%rax
  5229cb:	0f 85 a5 f0 ff ff    	jne    521a76 <<gpui_gpu::renderer::RendererState>::render+0x6f6>
  5229d1:	eb 61                	jmp    522a34 <<gpui_gpu::renderer::RendererState>::render+0x16b4>
  5229d3:	ba 05 00 00 00       	mov    $0x5,%edx
  5229d8:	b9 04 00 00 00       	mov    $0x4,%ecx
  5229dd:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  5229e3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  5229e8:	e8 13 1f b8 ff       	call   a4900 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  5229ed:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  5229f2:	48 8b 70 10          	mov    0x10(%rax),%rsi
  5229f6:	e9 55 fc ff ff       	jmp    522650 <<gpui_gpu::renderer::RendererState>::render+0x12d0>
  5229fb:	48 c7 84 24 00 01 00 	movq   $0x0,0x100(%rsp)
  522a02:	00 00 00 00 00 
  522a07:	48 c7 84 24 18 03 00 	movq   $0x0,0x318(%rsp)
  522a0e:	00 00 00 00 00 
  522a13:	48 c7 84 24 10 03 00 	movq   $0x0,0x310(%rsp)
  522a1a:	00 00 00 00 00 
  522a1f:	48 c7 84 24 c8 00 00 	movq   $0x0,0xc8(%rsp)
  522a26:	00 00 00 00 00 
  522a2b:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
  522a32:	00 00 
  522a34:	48 8b b4 24 98 01 00 	mov    0x198(%rsp),%rsi
  522a3b:	00 
  522a3c:	48 8d 56 08          	lea    0x8(%rsi),%rdx
  522a40:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  522a45:	48 8d 88 58 02 00 00 	lea    0x258(%rax),%rcx
  522a4c:	4c 8d 80 28 03 00 00 	lea    0x328(%rax),%r8
  522a53:	4c 8b 48 10          	mov    0x10(%rax),%r9
  522a57:	48 83 ec 08          	sub    $0x8,%rsp
  522a5b:	48 8d bc 24 c8 01 00 	lea    0x1c8(%rsp),%rdi
  522a62:	00 
  522a63:	48 89 94 24 10 01 00 	mov    %rdx,0x110(%rsp)
  522a6a:	00 
  522a6b:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
  522a72:	00 
  522a73:	4c 89 84 24 c0 00 00 	mov    %r8,0xc0(%rsp)
  522a7a:	00 
  522a7b:	ff b4 24 d8 00 00 00 	push   0xd8(%rsp)
  522a82:	e8 89 37 00 00       	call   526210 <gpui_gpu::renderer::images::prepare>
  522a87:	48 83 c4 10          	add    $0x10,%rsp
  522a8b:	83 bc 24 c0 01 00 00 	cmpl   $0xffffffff,0x1c0(%rsp)
  522a92:	ff 
  522a93:	74 49                	je     522ade <<gpui_gpu::renderer::RendererState>::render+0x175e>
  522a95:	f3 0f 6f 84 24 c0 01 	movdqu 0x1c0(%rsp),%xmm0
  522a9c:	00 00 
  522a9e:	0f 10 8c 24 d0 01 00 	movups 0x1d0(%rsp),%xmm1
  522aa5:	00 
  522aa6:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  522aab:	0f 11 4f 10          	movups %xmm1,0x10(%rdi)
  522aaf:	f3 0f 7f 07          	movdqu %xmm0,(%rdi)
  522ab3:	e9 d9 e9 ff ff       	jmp    521491 <<gpui_gpu::renderer::RendererState>::render+0x111>
  522ab8:	8b 94 24 04 03 00 00 	mov    0x304(%rsp),%edx
  522abf:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  522ac4:	89 57 1c             	mov    %edx,0x1c(%rdi)
  522ac7:	0f 10 84 24 f4 02 00 	movups 0x2f4(%rsp),%xmm0
  522ace:	00 
  522acf:	0f 11 47 0c          	movups %xmm0,0xc(%rdi)
  522ad3:	89 0f                	mov    %ecx,(%rdi)
  522ad5:	48 89 47 04          	mov    %rax,0x4(%rdi)
  522ad9:	e9 b3 e9 ff ff       	jmp    521491 <<gpui_gpu::renderer::RendererState>::render+0x111>
  522ade:	44 0f b6 44 24 68    	movzbl 0x68(%rsp),%r8d
  522ae4:	41 83 e0 01          	and    $0x1,%r8d
  522ae8:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
  522aef:	00 
  522af0:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  522af5:	48 8b 94 24 98 01 00 	mov    0x198(%rsp),%rdx
  522afc:	00 
  522afd:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
  522b04:	00 
  522b05:	e8 46 de ff ff       	call   520950 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  522b0a:	8b 84 24 c0 01 00 00 	mov    0x1c0(%rsp),%eax
  522b11:	83 f8 ff             	cmp    $0xffffffff,%eax
  522b14:	74 4b                	je     522b61 <<gpui_gpu::renderer::RendererState>::render+0x17e1>
  522b16:	8b 8c 24 c4 01 00 00 	mov    0x1c4(%rsp),%ecx
  522b1d:	48 8b 94 24 c8 01 00 	mov    0x1c8(%rsp),%rdx
  522b24:	00 
  522b25:	f3 0f 6f 84 24 d0 01 	movdqu 0x1d0(%rsp),%xmm0
  522b2c:	00 00 
  522b2e:	e9 88 ed ff ff       	jmp    5218bb <<gpui_gpu::renderer::RendererState>::render+0x53b>
  522b33:	8b 8c 24 34 01 00 00 	mov    0x134(%rsp),%ecx
  522b3a:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  522b3f:	89 4f 1c             	mov    %ecx,0x1c(%rdi)
  522b42:	0f 10 84 24 24 01 00 	movups 0x124(%rsp),%xmm0
  522b49:	00 
  522b4a:	0f 11 47 0c          	movups %xmm0,0xc(%rdi)
  522b4e:	89 07                	mov    %eax,(%rdi)
  522b50:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
  522b57:	00 
  522b58:	48 89 47 04          	mov    %rax,0x4(%rdi)
  522b5c:	e9 30 e9 ff ff       	jmp    521491 <<gpui_gpu::renderer::RendererState>::render+0x111>
  522b61:	48 8b 84 24 c8 01 00 	mov    0x1c8(%rsp),%rax
  522b68:	00 
  522b69:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  522b70:	00 
  522b71:	48 8b 94 24 c0 00 00 	mov    0xc0(%rsp),%rdx
  522b78:	00 
  522b79:	48 8b 82 80 00 00 00 	mov    0x80(%rdx),%rax
  522b80:	48 8b 8a 98 00 00 00 	mov    0x98(%rdx),%rcx
  522b87:	48 03 8a b0 00 00 00 	add    0xb0(%rdx),%rcx
  522b8e:	48 89 94 24 a0 03 00 	mov    %rdx,0x3a0(%rsp)
  522b95:	00 
  522b96:	48 c7 84 24 a8 03 00 	movq   $0x0,0x3a8(%rsp)
  522b9d:	00 00 00 00 00 
  522ba2:	48 89 84 24 b0 03 00 	mov    %rax,0x3b0(%rsp)
  522ba9:	00 
  522baa:	48 89 8c 24 b8 03 00 	mov    %rcx,0x3b8(%rsp)
  522bb1:	00 
  522bb2:	8b 44 24 30          	mov    0x30(%rsp),%eax
  522bb6:	89 84 24 c0 03 00 00 	mov    %eax,0x3c0(%rsp)
  522bbd:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  522bc4:	00 
  522bc5:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
  522bcc:	00 
  522bcd:	ff 15 9d 4d da 00    	call   *0xda4d9d(%rip)        # 12c7970 <_GLOBAL_OFFSET_TABLE_+0x3b30>
  522bd3:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
  522bda:	00 
  522bdb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  522be0:	48 85 c0             	test   %rax,%rax
  522be3:	0f 84 f9 03 00 00    	je     522fe2 <<gpui_gpu::renderer::RendererState>::render+0x1c62>
  522be9:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  522bee:	48 05 20 01 00 00    	add    $0x120,%rax
  522bf4:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  522bfb:	00 
  522bfc:	eb 39                	jmp    522c37 <<gpui_gpu::renderer::RendererState>::render+0x18b7>
  522bfe:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  522c05:	00 
  522c06:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
  522c0d:	00 
  522c0e:	ff 15 5c 4d da 00    	call   *0xda4d5c(%rip)        # 12c7970 <_GLOBAL_OFFSET_TABLE_+0x3b30>
  522c14:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
  522c1b:	00 
  522c1c:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  522c21:	48 89 8c 24 30 03 00 	mov    %rcx,0x330(%rsp)
  522c28:	00 
  522c29:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  522c2e:	48 85 c0             	test   %rax,%rax
  522c31:	0f 84 ab 03 00 00    	je     522fe2 <<gpui_gpu::renderer::RendererState>::render+0x1c62>
  522c37:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
  522c3e:	00 
  522c3f:	48 8b bc 24 28 01 00 	mov    0x128(%rsp),%rdi
  522c46:	00 
  522c47:	48 89 bc 24 98 00 00 	mov    %rdi,0x98(%rsp)
  522c4e:	00 
  522c4f:	48 8d 8c 24 30 01 00 	lea    0x130(%rsp),%rcx
  522c56:	00 
  522c57:	0f 10 41 40          	movups 0x40(%rcx),%xmm0
  522c5b:	48 8d 84 24 18 02 00 	lea    0x218(%rsp),%rax
  522c62:	00 
  522c63:	0f 11 00             	movups %xmm0,(%rax)
  522c66:	0f 10 01             	movups (%rcx),%xmm0
  522c69:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
  522c6d:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
  522c71:	0f 10 59 30          	movups 0x30(%rcx),%xmm3
  522c75:	0f 11 58 f0          	movups %xmm3,-0x10(%rax)
  522c79:	0f 11 50 e0          	movups %xmm2,-0x20(%rax)
  522c7d:	0f 11 48 d0          	movups %xmm1,-0x30(%rax)
  522c81:	0f 11 40 c0          	movups %xmm0,-0x40(%rax)
  522c85:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  522c8a:	0f b6 b0 41 03 00 00 	movzbl 0x341(%rax),%esi
  522c91:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  522c96:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
  522c9d:	00 
  522c9e:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
  522ca3:	48 89 94 24 c8 01 00 	mov    %rdx,0x1c8(%rsp)
  522caa:	00 
  522cab:	48 89 bc 24 d0 01 00 	mov    %rdi,0x1d0(%rsp)
  522cb2:	00 
  522cb3:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
  522cba:	00 
  522cbb:	e8 20 22 00 00       	call   524ee0 <gpui_gpu::renderer::compact_group>
  522cc0:	48 8b 8c 24 30 03 00 	mov    0x330(%rsp),%rcx
  522cc7:	00 
  522cc8:	48 8d 51 05          	lea    0x5(%rcx),%rdx
  522ccc:	84 c0                	test   %al,%al
  522cce:	48 0f 44 d1          	cmove  %rcx,%rdx
  522cd2:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  522cd7:	48 83 bc 24 98 00 00 	cmpq   $0x0,0x98(%rsp)
  522cde:	00 00 
  522ce0:	0f 84 18 ff ff ff    	je     522bfe <<gpui_gpu::renderer::RendererState>::render+0x187e>
  522ce6:	48 c1 a4 24 98 00 00 	shlq   $0x2,0x98(%rsp)
  522ced:	00 02 
  522cef:	34 01                	xor    $0x1,%al
  522cf1:	0f b6 c8             	movzbl %al,%ecx
  522cf4:	c1 e1 02             	shl    $0x2,%ecx
  522cf7:	48 8d 41 01          	lea    0x1(%rcx),%rax
  522cfb:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
  522d02:	00 
  522d03:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  522d08:	4c 8d 04 08          	lea    (%rax,%rcx,1),%r8
  522d0c:	49 ff c0             	inc    %r8
  522d0f:	48 83 c9 02          	or     $0x2,%rcx
  522d13:	49 c1 e0 04          	shl    $0x4,%r8
  522d17:	48 89 8c 24 80 01 00 	mov    %rcx,0x180(%rsp)
  522d1e:	00 
  522d1f:	c1 e1 04             	shl    $0x4,%ecx
  522d22:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  522d27:	31 c9                	xor    %ecx,%ecx
  522d29:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
  522d2e:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  522d33:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
  522d3a:	00 
  522d3b:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  522d3e:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
  522d45:	00 
  522d46:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  522d4b:	e8 e0 ca ff ff       	call   51f830 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  522d50:	0f b6 8c 24 c0 01 00 	movzbl 0x1c0(%rsp),%ecx
  522d57:	00 
  522d58:	0f b6 84 24 c1 01 00 	movzbl 0x1c1(%rsp),%eax
  522d5f:	00 
  522d60:	f3 0f 10 a4 24 c4 01 	movss  0x1c4(%rsp),%xmm4
  522d67:	00 00 
  522d69:	48 8d b4 24 c8 01 00 	lea    0x1c8(%rsp),%rsi
  522d70:	00 
  522d71:	48 8b 56 10          	mov    0x10(%rsi),%rdx
  522d75:	48 89 94 24 c0 02 00 	mov    %rdx,0x2c0(%rsp)
  522d7c:	00 
  522d7d:	0f 10 06             	movups (%rsi),%xmm0
  522d80:	0f 29 84 24 b0 02 00 	movaps %xmm0,0x2b0(%rsp)
  522d87:	00 
  522d88:	83 f9 01             	cmp    $0x1,%ecx
  522d8b:	0f 84 8f 00 00 00    	je     522e20 <<gpui_gpu::renderer::RendererState>::render+0x1aa0>
  522d91:	0f 29 a4 24 30 03 00 	movaps %xmm4,0x330(%rsp)
  522d98:	00 
  522d99:	48 8b b4 24 e0 01 00 	mov    0x1e0(%rsp),%rsi
  522da0:	00 
  522da1:	8b 94 24 e8 01 00 00 	mov    0x1e8(%rsp),%edx
  522da8:	89 54 24 20          	mov    %edx,0x20(%rsp)
  522dac:	8b 94 24 ec 01 00 00 	mov    0x1ec(%rsp),%edx
  522db3:	89 54 24 18          	mov    %edx,0x18(%rsp)
  522db7:	83 f9 03             	cmp    $0x3,%ecx
  522dba:	0f 85 e2 00 00 00    	jne    522ea2 <<gpui_gpu::renderer::RendererState>::render+0x1b22>
  522dc0:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  522dc7:	00 
  522dc8:	48 8b 39             	mov    (%rcx),%rdi
  522dcb:	48 85 ff             	test   %rdi,%rdi
  522dce:	0f 84 6a 0d 00 00    	je     523b3e <<gpui_gpu::renderer::RendererState>::render+0x27be>
  522dd4:	0f b6 d0             	movzbl %al,%edx
  522dd7:	e8 c4 30 00 00       	call   525ea0 <<gpui_gpu::renderer::images::Images>::metadata>
  522ddc:	89 c1                	mov    %eax,%ecx
  522dde:	48 c1 e8 20          	shr    $0x20,%rax
  522de2:	89 c2                	mov    %eax,%edx
  522de4:	83 ca 10             	or     $0x10,%edx
  522de7:	0f 57 c0             	xorps  %xmm0,%xmm0
  522dea:	0f 28 8c 24 30 03 00 	movaps 0x330(%rsp),%xmm1
  522df1:	00 
  522df2:	0f 2e c8             	ucomiss %xmm0,%xmm1
  522df5:	0f 45 c2             	cmovne %edx,%eax
  522df8:	0f 4a c2             	cmovp  %edx,%eax
  522dfb:	8b 54 24 18          	mov    0x18(%rsp),%edx
  522dff:	c1 e2 10             	shl    $0x10,%edx
  522e02:	0b 54 24 20          	or     0x20(%rsp),%edx
  522e06:	89 8c 24 a0 01 00 00 	mov    %ecx,0x1a0(%rsp)
  522e0d:	89 84 24 a4 01 00 00 	mov    %eax,0x1a4(%rsp)
  522e14:	89 94 24 a8 01 00 00 	mov    %edx,0x1a8(%rsp)
  522e1b:	e9 1f 01 00 00       	jmp    522f3f <<gpui_gpu::renderer::RendererState>::render+0x1bbf>
  522e20:	f3 0f 10 84 24 00 02 	movss  0x200(%rsp),%xmm0
  522e27:	00 00 
  522e29:	f3 0f 10 1d 53 29 60 	movss  0x602953(%rip),%xmm3        # b25784 <anon.9adf6b51329d0e8f0ba7a07edbf8a285.69.llvm.2988996700849332186+0x10>
  522e30:	00 
  522e31:	f3 0f 59 c3          	mulss  %xmm3,%xmm0
  522e35:	0f 28 cc             	movaps %xmm4,%xmm1
  522e38:	f3 0f 5d c8          	minss  %xmm0,%xmm1
  522e3c:	f3 0f c2 c0 03       	cmpunordss %xmm0,%xmm0
  522e41:	0f 28 d0             	movaps %xmm0,%xmm2
  522e44:	0f 55 d1             	andnps %xmm1,%xmm2
  522e47:	0f 54 c4             	andps  %xmm4,%xmm0
  522e4a:	0f 56 c2             	orps   %xmm2,%xmm0
  522e4d:	f3 0f 10 8c 24 04 02 	movss  0x204(%rsp),%xmm1
  522e54:	00 00 
  522e56:	f3 0f 59 cb          	mulss  %xmm3,%xmm1
  522e5a:	0f 28 d1             	movaps %xmm1,%xmm2
  522e5d:	f3 0f c2 d1 03       	cmpunordss %xmm1,%xmm2
  522e62:	0f 28 da             	movaps %xmm2,%xmm3
  522e65:	0f 54 d8             	andps  %xmm0,%xmm3
  522e68:	f3 0f 5d c1          	minss  %xmm1,%xmm0
  522e6c:	0f 55 d0             	andnps %xmm0,%xmm2
  522e6f:	0f 56 d3             	orps   %xmm3,%xmm2
  522e72:	66 0f 7e d0          	movd   %xmm2,%eax
  522e76:	25 00 00 80 ff       	and    $0xff800000,%eax
  522e7b:	b9 00 00 00 7f       	mov    $0x7f000000,%ecx
  522e80:	29 c1                	sub    %eax,%ecx
  522e82:	c7 84 24 a0 01 00 00 	movl   $0x40000000,0x1a0(%rsp)
  522e89:	00 00 00 40 
  522e8d:	f3 0f 11 94 24 a4 01 	movss  %xmm2,0x1a4(%rsp)
  522e94:	00 00 
  522e96:	89 8c 24 a8 01 00 00 	mov    %ecx,0x1a8(%rsp)
  522e9d:	e9 9d 00 00 00       	jmp    522f3f <<gpui_gpu::renderer::RendererState>::render+0x1bbf>
  522ea2:	80 f9 02             	cmp    $0x2,%cl
  522ea5:	75 50                	jne    522ef7 <<gpui_gpu::renderer::RendererState>::render+0x1b77>
  522ea7:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
  522eae:	00 
  522eaf:	48 8b 8c 24 c0 02 00 	mov    0x2c0(%rsp),%rcx
  522eb6:	00 
  522eb7:	48 89 8c 24 d0 01 00 	mov    %rcx,0x1d0(%rsp)
  522ebe:	00 
  522ebf:	0f 28 84 24 b0 02 00 	movaps 0x2b0(%rsp),%xmm0
  522ec6:	00 
  522ec7:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
  522ece:	00 
  522ecf:	48 89 b4 24 d8 01 00 	mov    %rsi,0x1d8(%rsp)
  522ed6:	00 
  522ed7:	8b 4c 24 20          	mov    0x20(%rsp),%ecx
  522edb:	89 8c 24 e0 01 00 00 	mov    %ecx,0x1e0(%rsp)
  522ee2:	8b 4c 24 18          	mov    0x18(%rsp),%ecx
  522ee6:	89 8c 24 e4 01 00 00 	mov    %ecx,0x1e4(%rsp)
  522eed:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
  522ef4:	00 
  522ef5:	eb 0c                	jmp    522f03 <<gpui_gpu::renderer::RendererState>::render+0x1b83>
  522ef7:	48 c7 84 24 c0 01 00 	movq   $0x0,0x1c0(%rsp)
  522efe:	00 00 00 00 00 
  522f03:	c7 84 24 f0 02 00 00 	movl   $0x0,0x2f0(%rsp)
  522f0a:	00 00 00 00 
  522f0e:	48 c7 84 24 e8 02 00 	movq   $0x0,0x2e8(%rsp)
  522f15:	00 00 00 00 00 
  522f1a:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  522f21:	00 
  522f22:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
  522f29:	00 
  522f2a:	48 8d 94 24 e8 02 00 	lea    0x2e8(%rsp),%rdx
  522f31:	00 
  522f32:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
  522f39:	00 
  522f3a:	e8 b1 b6 ff ff       	call   51e5f0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  522f3f:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  522f44:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
  522f4b:	00 
  522f4c:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
  522f50:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  522f55:	48 8b 70 10          	mov    0x10(%rax),%rsi
  522f59:	48 39 f7             	cmp    %rsi,%rdi
  522f5c:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  522f61:	0f 83 e4 0b 00 00    	jae    523b4b <<gpui_gpu::renderer::RendererState>::render+0x27cb>
  522f67:	48 8b 40 08          	mov    0x8(%rax),%rax
  522f6b:	8b 8c 24 a8 01 00 00 	mov    0x1a8(%rsp),%ecx
  522f72:	42 89 4c 00 08       	mov    %ecx,0x8(%rax,%r8,1)
  522f77:	48 8b 8c 24 a0 01 00 	mov    0x1a0(%rsp),%rcx
  522f7e:	00 
  522f7f:	4a 89 0c 00          	mov    %rcx,(%rax,%r8,1)
  522f83:	48 03 94 24 80 01 00 	add    0x180(%rsp),%rdx
  522f8a:	00 
  522f8b:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  522f90:	4c 03 44 24 38       	add    0x38(%rsp),%r8
  522f95:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  522f9c:	00 
  522f9d:	48 83 c1 04          	add    $0x4,%rcx
  522fa1:	48 39 8c 24 98 00 00 	cmp    %rcx,0x98(%rsp)
  522fa8:	00 
  522fa9:	0f 85 7a fd ff ff    	jne    522d29 <<gpui_gpu::renderer::RendererState>::render+0x19a9>
  522faf:	e9 4a fc ff ff       	jmp    522bfe <<gpui_gpu::renderer::RendererState>::render+0x187e>
  522fb4:	8b 8c 24 34 01 00 00 	mov    0x134(%rsp),%ecx
  522fbb:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  522fc0:	89 4f 1c             	mov    %ecx,0x1c(%rdi)
  522fc3:	48 8b 8c 24 2c 01 00 	mov    0x12c(%rsp),%rcx
  522fca:	00 
  522fcb:	48 89 4f 14          	mov    %rcx,0x14(%rdi)
  522fcf:	0f 28 84 24 80 01 00 	movaps 0x180(%rsp),%xmm0
  522fd6:	00 
  522fd7:	0f 11 47 04          	movups %xmm0,0x4(%rdi)
  522fdb:	89 07                	mov    %eax,(%rdi)
  522fdd:	e9 af e4 ff ff       	jmp    521491 <<gpui_gpu::renderer::RendererState>::render+0x111>
  522fe2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  522fe7:	48 8b 40 28          	mov    0x28(%rax),%rax
  522feb:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
  522ff2:	00 00 
  522ff4:	48 85 c0             	test   %rax,%rax
  522ff7:	0f 84 96 00 00 00    	je     523093 <<gpui_gpu::renderer::RendererState>::render+0x1d13>
  522ffd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  523002:	48 8b 49 20          	mov    0x20(%rcx),%rcx
  523006:	48 c1 e0 03          	shl    $0x3,%rax
  52300a:	31 ff                	xor    %edi,%edi
  52300c:	eb 1c                	jmp    52302a <<gpui_gpu::renderer::RendererState>::render+0x1caa>
  52300e:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  523013:	01 f2                	add    %esi,%edx
  523015:	89 14 f9             	mov    %edx,(%rcx,%rdi,8)
  523018:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
  52301d:	89 54 f9 04          	mov    %edx,0x4(%rcx,%rdi,8)
  523021:	48 ff c7             	inc    %rdi
  523024:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  523028:	74 5d                	je     523087 <<gpui_gpu::renderer::RendererState>::render+0x1d07>
  52302a:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  52302f:	48 8b 72 58          	mov    0x58(%rdx),%rsi
  523033:	48 39 f7             	cmp    %rsi,%rdi
  523036:	0f 83 1c 0b 00 00    	jae    523b58 <<gpui_gpu::renderer::RendererState>::render+0x27d8>
  52303c:	8b 74 f9 04          	mov    0x4(%rcx,%rdi,8),%esi
  523040:	83 fe 01             	cmp    $0x1,%esi
  523043:	75 c9                	jne    52300e <<gpui_gpu::renderer::RendererState>::render+0x1c8e>
  523045:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  52304a:	4c 8b 42 50          	mov    0x50(%rdx),%r8
  52304e:	ba 00 00 00 80       	mov    $0x80000000,%edx
  523053:	41 83 3c b8 00       	cmpl   $0x0,(%r8,%rdi,4)
  523058:	75 c3                	jne    52301d <<gpui_gpu::renderer::RendererState>::render+0x1c9d>
  52305a:	eb b2                	jmp    52300e <<gpui_gpu::renderer::RendererState>::render+0x1c8e>
  52305c:	8b 8c 24 34 01 00 00 	mov    0x134(%rsp),%ecx
  523063:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  523068:	89 4f 1c             	mov    %ecx,0x1c(%rdi)
  52306b:	48 8b 8c 24 2c 01 00 	mov    0x12c(%rsp),%rcx
  523072:	00 
  523073:	48 89 4f 14          	mov    %rcx,0x14(%rdi)
  523077:	89 07                	mov    %eax,(%rdi)
  523079:	0f 28 44 24 70       	movaps 0x70(%rsp),%xmm0
  52307e:	0f 11 47 04          	movups %xmm0,0x4(%rdi)
  523082:	e9 0a e4 ff ff       	jmp    521491 <<gpui_gpu::renderer::RendererState>::render+0x111>
  523087:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  52308c:	89 c0                	mov    %eax,%eax
  52308e:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  523093:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  523098:	48 8d 78 30          	lea    0x30(%rax),%rdi
  52309c:	48 c7 40 40 00 00 00 	movq   $0x0,0x40(%rax)
  5230a3:	00 
  5230a4:	48 89 7c 24 68       	mov    %rdi,0x68(%rsp)
  5230a9:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
  5230ae:	31 d2                	xor    %edx,%edx
  5230b0:	e8 0b 30 00 00       	call   5260c0 <<alloc::vec::Vec<u32>>::resize>
  5230b5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  5230ba:	48 8b 40 10          	mov    0x10(%rax),%rax
  5230be:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  5230c3:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  5230ca:	00 
  5230cb:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  5230d2:	00 
  5230d3:	48 8b 94 24 c0 00 00 	mov    0xc0(%rsp),%rdx
  5230da:	00 
  5230db:	48 8b 82 80 00 00 00 	mov    0x80(%rdx),%rax
  5230e2:	48 8b 8a 98 00 00 00 	mov    0x98(%rdx),%rcx
  5230e9:	48 03 8a b0 00 00 00 	add    0xb0(%rdx),%rcx
  5230f0:	48 89 94 24 e8 02 00 	mov    %rdx,0x2e8(%rsp)
  5230f7:	00 
  5230f8:	48 c7 84 24 f0 02 00 	movq   $0x0,0x2f0(%rsp)
  5230ff:	00 00 00 00 00 
  523104:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
  52310b:	00 
  52310c:	48 89 8c 24 00 03 00 	mov    %rcx,0x300(%rsp)
  523113:	00 
  523114:	8b 44 24 30          	mov    0x30(%rsp),%eax
  523118:	89 84 24 08 03 00 00 	mov    %eax,0x308(%rsp)
  52311f:	eb 17                	jmp    523138 <<gpui_gpu::renderer::RendererState>::render+0x1db8>
  523121:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  523126:	48 8d 41 fb          	lea    -0x5(%rcx),%rax
  52312a:	80 7c 24 30 00       	cmpb   $0x0,0x30(%rsp)
  52312f:	48 0f 45 c8          	cmovne %rax,%rcx
  523133:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  523138:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  52313f:	00 
  523140:	48 8d b4 24 e8 02 00 	lea    0x2e8(%rsp),%rsi
  523147:	00 
  523148:	ff 15 da 69 da 00    	call   *0xda69da(%rip)        # 12c9b28 <_GLOBAL_OFFSET_TABLE_+0x5ce8>
  52314e:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
  523155:	00 
  523156:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  52315b:	48 85 c0             	test   %rax,%rax
  52315e:	0f 84 59 02 00 00    	je     5233bd <<gpui_gpu::renderer::RendererState>::render+0x203d>
  523164:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
  52316b:	00 
  52316c:	48 8b 94 24 28 01 00 	mov    0x128(%rsp),%rdx
  523173:	00 
  523174:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  523179:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  52317e:	0f b6 b0 41 03 00 00 	movzbl 0x341(%rax),%esi
  523185:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  52318a:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
  523191:	00 
  523192:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
  523199:	00 
  52319a:	48 89 8c 24 c8 01 00 	mov    %rcx,0x1c8(%rsp)
  5231a1:	00 
  5231a2:	48 89 94 24 d0 01 00 	mov    %rdx,0x1d0(%rsp)
  5231a9:	00 
  5231aa:	48 8d 84 24 30 01 00 	lea    0x130(%rsp),%rax
  5231b1:	00 
  5231b2:	0f 10 00             	movups (%rax),%xmm0
  5231b5:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  5231b9:	66 0f 10 50 20       	movupd 0x20(%rax),%xmm2
  5231be:	48 8d 84 24 18 02 00 	lea    0x218(%rsp),%rax
  5231c5:	00 
  5231c6:	66 0f 11 50 e0       	movupd %xmm2,-0x20(%rax)
  5231cb:	0f 11 48 d0          	movups %xmm1,-0x30(%rax)
  5231cf:	0f 11 40 c0          	movups %xmm0,-0x40(%rax)
  5231d3:	48 8d 8c 24 60 01 00 	lea    0x160(%rsp),%rcx
  5231da:	00 
  5231db:	0f 10 01             	movups (%rcx),%xmm0
  5231de:	48 8d 94 24 08 02 00 	lea    0x208(%rsp),%rdx
  5231e5:	00 
  5231e6:	0f 11 02             	movups %xmm0,(%rdx)
  5231e9:	0f 10 41 10          	movups 0x10(%rcx),%xmm0
  5231ed:	0f 11 00             	movups %xmm0,(%rax)
  5231f0:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
  5231f7:	00 
  5231f8:	e8 e3 1c 00 00       	call   524ee0 <gpui_gpu::renderer::compact_group>
  5231fd:	88 44 24 30          	mov    %al,0x30(%rsp)
  523201:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  523206:	48 85 c0             	test   %rax,%rax
  523209:	0f 84 12 ff ff ff    	je     523121 <<gpui_gpu::renderer::RendererState>::render+0x1da1>
  52320f:	48 89 c1             	mov    %rax,%rcx
  523212:	48 c1 e1 02          	shl    $0x2,%rcx
  523216:	0f b6 44 24 30       	movzbl 0x30(%rsp),%eax
  52321b:	8d 14 85 00 00 00 00 	lea    0x0(,%rax,4),%edx
  523222:	48 83 ca fa          	or     $0xfffffffffffffffa,%rdx
  523226:	31 f6                	xor    %esi,%esi
  523228:	84 c0                	test   %al,%al
  52322a:	40 0f 94 c6          	sete   %sil
  52322e:	c1 e6 1f             	shl    $0x1f,%esi
  523231:	89 b4 24 98 00 00 00 	mov    %esi,0x98(%rsp)
  523238:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
  52323f:	00 
  523240:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  523245:	01 d0                	add    %edx,%eax
  523247:	89 44 24 50          	mov    %eax,0x50(%rsp)
  52324b:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  523250:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  523257:	00 
  523258:	8b 54 08 fc          	mov    -0x4(%rax,%rcx,1),%edx
  52325c:	48 8d bc 24 a0 03 00 	lea    0x3a0(%rsp),%rdi
  523263:	00 
  523264:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  523269:	e8 c2 c5 ff ff       	call   51f830 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  52326e:	48 ff 8c 24 40 03 00 	decq   0x340(%rsp)
  523275:	00 
  523276:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  52327d:	00 
  52327e:	48 01 44 24 18       	add    %rax,0x18(%rsp)
  523283:	8b 84 24 98 00 00 00 	mov    0x98(%rsp),%eax
  52328a:	0b 44 24 50          	or     0x50(%rsp),%eax
  52328e:	89 84 24 a0 01 00 00 	mov    %eax,0x1a0(%rsp)
  523295:	48 8d 84 24 30 01 00 	lea    0x130(%rsp),%rax
  52329c:	00 
  52329d:	0f 10 00             	movups (%rax),%xmm0
  5232a0:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  5232a4:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  5232a8:	48 8d 84 24 08 02 00 	lea    0x208(%rsp),%rax
  5232af:	00 
  5232b0:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  5232b4:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  5232b8:	0f 11 00             	movups %xmm0,(%rax)
  5232bb:	48 8d 8c 24 60 01 00 	lea    0x160(%rsp),%rcx
  5232c2:	00 
  5232c3:	0f 10 01             	movups (%rcx),%xmm0
  5232c6:	48 8d 84 24 18 02 00 	lea    0x218(%rsp),%rax
  5232cd:	00 
  5232ce:	0f 11 40 20          	movups %xmm0,0x20(%rax)
  5232d2:	0f 10 41 10          	movups 0x10(%rcx),%xmm0
  5232d6:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  5232da:	48 8d 8c 24 d8 03 00 	lea    0x3d8(%rsp),%rcx
  5232e1:	00 
  5232e2:	0f 10 01             	movups (%rcx),%xmm0
  5232e5:	0f 11 40 e0          	movups %xmm0,-0x20(%rax)
  5232e9:	0f 10 41 10          	movups 0x10(%rcx),%xmm0
  5232ed:	0f 11 40 30          	movups %xmm0,0x30(%rax)
  5232f1:	48 8b 84 24 d0 03 00 	mov    0x3d0(%rsp),%rax
  5232f8:	00 
  5232f9:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
  523300:	00 
  523301:	0f 10 84 24 a0 03 00 	movups 0x3a0(%rsp),%xmm0
  523308:	00 
  523309:	0f 10 8c 24 b0 03 00 	movups 0x3b0(%rsp),%xmm1
  523310:	00 
  523311:	66 0f 10 94 24 c0 03 	movupd 0x3c0(%rsp),%xmm2
  523318:	00 00 
  52331a:	66 0f 29 94 24 e0 01 	movapd %xmm2,0x1e0(%rsp)
  523321:	00 00 
  523323:	0f 29 8c 24 d0 01 00 	movaps %xmm1,0x1d0(%rsp)
  52332a:	00 
  52332b:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
  523332:	00 
  523333:	48 8b 84 24 d8 00 00 	mov    0xd8(%rsp),%rax
  52333a:	00 
  52333b:	48 89 84 24 b0 02 00 	mov    %rax,0x2b0(%rsp)
  523342:	00 
  523343:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  523348:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
  52334f:	00 
  523350:	48 8b 84 24 40 04 00 	mov    0x440(%rsp),%rax
  523357:	00 
  523358:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  52335f:	00 
  523360:	48 8d 84 24 40 03 00 	lea    0x340(%rsp),%rax
  523367:	00 
  523368:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
  52336f:	00 
  523370:	48 8d 84 24 a0 01 00 	lea    0x1a0(%rsp),%rax
  523377:	00 
  523378:	48 89 84 24 d0 02 00 	mov    %rax,0x2d0(%rsp)
  52337f:	00 
  523380:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
  523387:	00 
  523388:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  52338d:	48 8d 94 24 b0 02 00 	lea    0x2b0(%rsp),%rdx
  523394:	00 
  523395:	e8 26 c1 ff ff       	call   51f4c0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#6}>>
  52339a:	8b 44 24 50          	mov    0x50(%rsp),%eax
  52339e:	03 84 24 a0 00 00 00 	add    0xa0(%rsp),%eax
  5233a5:	89 44 24 50          	mov    %eax,0x50(%rsp)
  5233a9:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  5233ae:	48 83 c1 fc          	add    $0xfffffffffffffffc,%rcx
  5233b2:	0f 85 93 fe ff ff    	jne    52324b <<gpui_gpu::renderer::RendererState>::render+0x1ecb>
  5233b8:	e9 64 fd ff ff       	jmp    523121 <<gpui_gpu::renderer::RendererState>::render+0x1da1>
  5233bd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  5233c2:	48 8b 78 28          	mov    0x28(%rax),%rdi
  5233c6:	48 c7 84 24 d8 00 00 	movq   $0x0,0xd8(%rsp)
  5233cd:	00 00 00 00 00 
  5233d2:	48 85 ff             	test   %rdi,%rdi
  5233d5:	0f 84 d0 00 00 00    	je     5234ab <<gpui_gpu::renderer::RendererState>::render+0x212b>
  5233db:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  5233e0:	4c 8b 40 20          	mov    0x20(%rax),%r8
  5233e4:	48 c1 e7 03          	shl    $0x3,%rdi
  5233e8:	83 7c 24 48 00       	cmpl   $0x0,0x48(%rsp)
  5233ed:	0f 84 05 07 00 00    	je     523af8 <<gpui_gpu::renderer::RendererState>::render+0x2778>
  5233f3:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
  5233fa:	00 00 00 00 00 
  5233ff:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  523406:	00 00 
  523408:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  52340f:	00 00 
  523411:	45 31 c9             	xor    %r9d,%r9d
  523414:	31 c9                	xor    %ecx,%ecx
  523416:	eb 23                	jmp    52343b <<gpui_gpu::renderer::RendererState>::render+0x20bb>
  523418:	48 ff 44 24 50       	incq   0x50(%rsp)
  52341d:	49 ff c1             	inc    %r9
  523420:	4c 3b 4c 24 48       	cmp    0x48(%rsp),%r9
  523425:	b8 00 00 00 00       	mov    $0x0,%eax
  52342a:	4c 0f 44 c8          	cmove  %rax,%r9
  52342e:	48 ff c1             	inc    %rcx
  523431:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  523435:	0f 84 8e 00 00 00    	je     5234c9 <<gpui_gpu::renderer::RendererState>::render+0x2149>
  52343b:	45 8b 54 c8 04       	mov    0x4(%r8,%rcx,8),%r10d
  523440:	44 89 d0             	mov    %r10d,%eax
  523443:	f7 d8                	neg    %eax
  523445:	70 d1                	jo     523418 <<gpui_gpu::renderer::RendererState>::render+0x2098>
  523447:	45 2b 14 c8          	sub    (%r8,%rcx,8),%r10d
  52344b:	74 d0                	je     52341d <<gpui_gpu::renderer::RendererState>::render+0x209d>
  52344d:	48 89 c8             	mov    %rcx,%rax
  523450:	48 c1 e8 20          	shr    $0x20,%rax
  523454:	74 0f                	je     523465 <<gpui_gpu::renderer::RendererState>::render+0x20e5>
  523456:	48 89 c8             	mov    %rcx,%rax
  523459:	31 d2                	xor    %edx,%edx
  52345b:	48 f7 74 24 48       	divq   0x48(%rsp)
  523460:	4c 89 ca             	mov    %r9,%rdx
  523463:	eb 08                	jmp    52346d <<gpui_gpu::renderer::RendererState>::render+0x20ed>
  523465:	89 c8                	mov    %ecx,%eax
  523467:	31 d2                	xor    %edx,%edx
  523469:	f7 74 24 48          	divl   0x48(%rsp)
  52346d:	c1 e2 04             	shl    $0x4,%edx
  523470:	c1 e0 04             	shl    $0x4,%eax
  523473:	44 8d 5a 10          	lea    0x10(%rdx),%r11d
  523477:	45 39 f3             	cmp    %r14d,%r11d
  52347a:	45 0f 43 de          	cmovae %r14d,%r11d
  52347e:	8d 70 10             	lea    0x10(%rax),%esi
  523481:	44 39 fe             	cmp    %r15d,%esi
  523484:	41 0f 43 f7          	cmovae %r15d,%esi
  523488:	41 29 d3             	sub    %edx,%r11d
  52348b:	29 c6                	sub    %eax,%esi
  52348d:	41 0f af f3          	imul   %r11d,%esi
  523491:	48 c1 e6 04          	shl    $0x4,%rsi
  523495:	48 01 74 24 10       	add    %rsi,0x10(%rsp)
  52349a:	4c 0f af d6          	imul   %rsi,%r10
  52349e:	4c 01 94 24 a0 00 00 	add    %r10,0xa0(%rsp)
  5234a5:	00 
  5234a6:	e9 72 ff ff ff       	jmp    52341d <<gpui_gpu::renderer::RendererState>::render+0x209d>
  5234ab:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  5234b2:	00 00 
  5234b4:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  5234bb:	00 00 
  5234bd:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
  5234c4:	00 00 00 00 00 
  5234c9:	41 f6 c4 01          	test   $0x1,%r12b
  5234cd:	74 53                	je     523522 <<gpui_gpu::renderer::RendererState>::render+0x21a2>
  5234cf:	66 0f 6e 84 24 2c 03 	movd   0x32c(%rsp),%xmm0
  5234d6:	00 00 
  5234d8:	66 0f 7e c0          	movd   %xmm0,%eax
  5234dc:	85 c0                	test   %eax,%eax
  5234de:	0f 99 c1             	setns  %cl
  5234e1:	89 c2                	mov    %eax,%edx
  5234e3:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
  5234e9:	81 c2 00 00 80 ff    	add    $0xff800000,%edx
  5234ef:	81 fa 00 00 00 7f    	cmp    $0x7f000000,%edx
  5234f5:	0f 92 c2             	setb   %dl
  5234f8:	20 ca                	and    %cl,%dl
  5234fa:	ff c8                	dec    %eax
  5234fc:	3d ff ff 7f 00       	cmp    $0x7fffff,%eax
  523501:	0f 92 c0             	setb   %al
  523504:	08 d0                	or     %dl,%al
  523506:	b8 02 00 00 00       	mov    $0x2,%eax
  52350b:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
  523512:	00 
  523513:	66 0f 7e 84 24 14 01 	movd   %xmm0,0x114(%rsp)
  52351a:	00 00 
  52351c:	0f 84 cc 05 00 00    	je     523aee <<gpui_gpu::renderer::RendererState>::render+0x276e>
  523522:	4c 8b a4 24 98 01 00 	mov    0x198(%rsp),%r12
  523529:	00 
  52352a:	49 8d 44 24 18       	lea    0x18(%r12),%rax
  52352f:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  523534:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  52353b:	00 
  52353c:	48 83 c0 18          	add    $0x18,%rax
  523540:	83 e5 01             	and    $0x1,%ebp
  523543:	48 8b 94 24 d8 00 00 	mov    0xd8(%rsp),%rdx
  52354a:	00 
  52354b:	8d 0c 2a             	lea    (%rdx,%rbp,1),%ecx
  52354e:	41 83 fd 28          	cmp    $0x28,%r13d
  523552:	8d 54 2a 04          	lea    0x4(%rdx,%rbp,1),%edx
  523556:	0f 45 d1             	cmovne %ecx,%edx
  523559:	8d 4a 08             	lea    0x8(%rdx),%ecx
  52355c:	48 8b b4 24 60 03 00 	mov    0x360(%rsp),%rsi
  523563:	00 
  523564:	48 3b b4 24 68 03 00 	cmp    0x368(%rsp),%rsi
  52356b:	00 
  52356c:	0f 44 ca             	cmove  %edx,%ecx
  52356f:	0f 10 00             	movups (%rax),%xmm0
  523572:	0f 11 84 24 c0 02 00 	movups %xmm0,0x2c0(%rsp)
  523579:	00 
  52357a:	44 89 b4 24 b0 02 00 	mov    %r14d,0x2b0(%rsp)
  523581:	00 
  523582:	44 89 bc 24 b4 02 00 	mov    %r15d,0x2b4(%rsp)
  523589:	00 
  52358a:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  52358f:	89 84 24 b8 02 00 00 	mov    %eax,0x2b8(%rsp)
  523596:	89 8c 24 bc 02 00 00 	mov    %ecx,0x2bc(%rsp)
  52359d:	66 0f 6e 84 24 14 01 	movd   0x114(%rsp),%xmm0
  5235a4:	00 00 
  5235a6:	66 0f 7e 84 24 d0 02 	movd   %xmm0,0x2d0(%rsp)
  5235ad:	00 00 
  5235af:	48 c7 84 24 d4 02 00 	movq   $0x0,0x2d4(%rsp)
  5235b6:	00 00 00 00 00 
  5235bb:	c7 84 24 dc 02 00 00 	movl   $0x0,0x2dc(%rsp)
  5235c2:	00 00 00 00 
  5235c6:	48 8b 6c 24 08       	mov    0x8(%rsp),%rbp
  5235cb:	48 8d b5 30 02 00 00 	lea    0x230(%rbp),%rsi
  5235d2:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
  5235d9:	00 00 
  5235db:	48 8d 8c 24 b0 02 00 	lea    0x2b0(%rsp),%rcx
  5235e2:	00 
  5235e3:	41 b8 30 00 00 00    	mov    $0x30,%r8d
  5235e9:	4c 8b ac 24 08 01 00 	mov    0x108(%rsp),%r13
  5235f0:	00 
  5235f1:	4c 89 ef             	mov    %r13,%rdi
  5235f4:	48 89 b4 24 d8 00 00 	mov    %rsi,0xd8(%rsp)
  5235fb:	00 
  5235fc:	31 d2                	xor    %edx,%edx
  5235fe:	ff 15 94 60 da 00    	call   *0xda6094(%rip)        # 12c9698 <_GLOBAL_OFFSET_TABLE_+0x5858>
  523604:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
  523608:	4c 8b 45 10          	mov    0x10(%rbp),%r8
  52360c:	49 c1 e0 04          	shl    $0x4,%r8
  523610:	48 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%rdi
  523617:	00 
  523618:	4c 89 e6             	mov    %r12,%rsi
  52361b:	4c 89 ea             	mov    %r13,%rdx
  52361e:	e8 0d c4 ff ff       	call   51fa30 <<gpui_gpu::renderer::Buffer>::write>
  523623:	48 8d bd 80 02 00 00 	lea    0x280(%rbp),%rdi
  52362a:	48 8b 4d 20          	mov    0x20(%rbp),%rcx
  52362e:	4c 8b 45 28          	mov    0x28(%rbp),%r8
  523632:	49 c1 e0 03          	shl    $0x3,%r8
  523636:	48 89 bc 24 d0 00 00 	mov    %rdi,0xd0(%rsp)
  52363d:	00 
  52363e:	4c 89 e6             	mov    %r12,%rsi
  523641:	4c 89 ea             	mov    %r13,%rdx
  523644:	e8 e7 c3 ff ff       	call   51fa30 <<gpui_gpu::renderer::Buffer>::write>
  523649:	48 8d bd a8 02 00 00 	lea    0x2a8(%rbp),%rdi
  523650:	48 8b 4d 38          	mov    0x38(%rbp),%rcx
  523654:	4c 8b 45 40          	mov    0x40(%rbp),%r8
  523658:	49 c1 e0 02          	shl    $0x2,%r8
  52365c:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
  523661:	4c 89 e6             	mov    %r12,%rsi
  523664:	4c 89 ea             	mov    %r13,%rdx
  523667:	e8 c4 c3 ff ff       	call   51fa30 <<gpui_gpu::renderer::Buffer>::write>
  52366c:	48 8d bd d0 02 00 00 	lea    0x2d0(%rbp),%rdi
  523673:	48 8b 4d 68          	mov    0x68(%rbp),%rcx
  523677:	4c 8b 45 70          	mov    0x70(%rbp),%r8
  52367b:	49 c1 e0 05          	shl    $0x5,%r8
  52367f:	48 89 bc 24 c0 00 00 	mov    %rdi,0xc0(%rsp)
  523686:	00 
  523687:	4c 89 e6             	mov    %r12,%rsi
  52368a:	4c 89 ea             	mov    %r13,%rdx
  52368d:	e8 9e c3 ff ff       	call   51fa30 <<gpui_gpu::renderer::Buffer>::write>
  523692:	48 83 bd 28 03 00 00 	cmpq   $0x0,0x328(%rbp)
  523699:	00 
  52369a:	75 1a                	jne    5236b6 <<gpui_gpu::renderer::RendererState>::render+0x2336>
  52369c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  5236a1:	48 8b 40 10          	mov    0x10(%rax),%rax
  5236a5:	48 83 f8 01          	cmp    $0x1,%rax
  5236a9:	48 83 d0 00          	adc    $0x0,%rax
  5236ad:	48 c1 e0 04          	shl    $0x4,%rax
  5236b1:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  5236b6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  5236bb:	48 8b 4e 28          	mov    0x28(%rsi),%rcx
  5236bf:	48 8b 46 40          	mov    0x40(%rsi),%rax
  5236c3:	48 83 f9 01          	cmp    $0x1,%rcx
  5236c7:	48 83 d1 00          	adc    $0x0,%rcx
  5236cb:	48 c1 e1 03          	shl    $0x3,%rcx
  5236cf:	48 83 f8 01          	cmp    $0x1,%rax
  5236d3:	48 83 d0 00          	adc    $0x0,%rax
  5236d7:	48 c1 e0 02          	shl    $0x2,%rax
  5236db:	48 8b 56 70          	mov    0x70(%rsi),%rdx
  5236df:	48 83 fa 01          	cmp    $0x1,%rdx
  5236e3:	48 83 d2 00          	adc    $0x0,%rdx
  5236e7:	48 81 c6 c8 00 00 00 	add    $0xc8,%rsi
  5236ee:	48 c1 e2 05          	shl    $0x5,%rdx
  5236f2:	48 c7 84 24 c0 01 00 	movq   $0x0,0x1c0(%rsp)
  5236f9:	00 00 00 00 00 
  5236fe:	48 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%rdi
  523705:	00 
  523706:	48 89 bc 24 c8 01 00 	mov    %rdi,0x1c8(%rsp)
  52370d:	00 
  52370e:	48 c7 84 24 e8 01 00 	movq   $0x0,0x1e8(%rsp)
  523715:	00 00 00 00 00 
  52371a:	66 0f ef c0          	pxor   %xmm0,%xmm0
  52371e:	f3 0f 7f 84 24 d0 01 	movdqu %xmm0,0x1d0(%rsp)
  523725:	00 00 
  523727:	c7 84 24 e0 01 00 00 	movl   $0x0,0x1e0(%rsp)
  52372e:	00 00 00 00 
  523732:	48 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%rdi
  523739:	00 
  52373a:	48 89 bc 24 f0 01 00 	mov    %rdi,0x1f0(%rsp)
  523741:	00 
  523742:	48 c7 84 24 f8 01 00 	movq   $0x0,0x1f8(%rsp)
  523749:	00 00 00 00 00 
  52374e:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  523753:	48 89 bc 24 00 02 00 	mov    %rdi,0x200(%rsp)
  52375a:	00 
  52375b:	c7 84 24 08 02 00 00 	movl   $0x1,0x208(%rsp)
  523762:	01 00 00 00 
  523766:	48 c7 84 24 10 02 00 	movq   $0x0,0x210(%rsp)
  52376d:	00 00 00 00 00 
  523772:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
  523779:	00 
  52377a:	48 89 bc 24 18 02 00 	mov    %rdi,0x218(%rsp)
  523781:	00 
  523782:	48 c7 84 24 20 02 00 	movq   $0x0,0x220(%rsp)
  523789:	00 00 00 00 00 
  52378e:	48 89 8c 24 28 02 00 	mov    %rcx,0x228(%rsp)
  523795:	00 
  523796:	c7 84 24 30 02 00 00 	movl   $0x2,0x230(%rsp)
  52379d:	02 00 00 00 
  5237a1:	48 c7 84 24 38 02 00 	movq   $0x0,0x238(%rsp)
  5237a8:	00 00 00 00 00 
  5237ad:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  5237b2:	48 89 8c 24 40 02 00 	mov    %rcx,0x240(%rsp)
  5237b9:	00 
  5237ba:	48 c7 84 24 48 02 00 	movq   $0x0,0x248(%rsp)
  5237c1:	00 00 00 00 00 
  5237c6:	48 89 84 24 50 02 00 	mov    %rax,0x250(%rsp)
  5237cd:	00 
  5237ce:	c7 84 24 58 02 00 00 	movl   $0x3,0x258(%rsp)
  5237d5:	03 00 00 00 
  5237d9:	48 c7 84 24 60 02 00 	movq   $0x4,0x260(%rsp)
  5237e0:	00 04 00 00 00 
  5237e5:	48 89 b4 24 68 02 00 	mov    %rsi,0x268(%rsp)
  5237ec:	00 
  5237ed:	c7 84 24 80 02 00 00 	movl   $0x4,0x280(%rsp)
  5237f4:	04 00 00 00 
  5237f8:	48 c7 84 24 88 02 00 	movq   $0x0,0x288(%rsp)
  5237ff:	00 00 00 00 00 
  523804:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  52380b:	00 
  52380c:	48 89 84 24 90 02 00 	mov    %rax,0x290(%rsp)
  523813:	00 
  523814:	48 c7 84 24 98 02 00 	movq   $0x0,0x298(%rsp)
  52381b:	00 00 00 00 00 
  523820:	48 89 94 24 a0 02 00 	mov    %rdx,0x2a0(%rsp)
  523827:	00 
  523828:	c7 84 24 a8 02 00 00 	movl   $0x5,0x2a8(%rsp)
  52382f:	05 00 00 00 
  523833:	48 8d 05 12 06 67 00 	lea    0x670612(%rip),%rax        # b93e4c <tracing_core::dispatcher::NO_SUBSCRIBER+0x130>
  52383a:	48 89 84 24 00 03 00 	mov    %rax,0x300(%rsp)
  523841:	00 
  523842:	48 c7 84 24 08 03 00 	movq   $0xa,0x308(%rsp)
  523849:	00 0a 00 00 00 
  52384e:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  523853:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
  52385a:	00 
  52385b:	48 8d 84 24 c0 01 00 	lea    0x1c0(%rsp),%rax
  523862:	00 
  523863:	48 89 84 24 f0 02 00 	mov    %rax,0x2f0(%rsp)
  52386a:	00 
  52386b:	48 c7 84 24 f8 02 00 	movq   $0x6,0x2f8(%rsp)
  523872:	00 06 00 00 00 
  523877:	48 8d b4 24 e8 02 00 	lea    0x2e8(%rsp),%rsi
  52387e:	00 
  52387f:	4c 8b a4 24 98 01 00 	mov    0x198(%rsp),%r12
  523886:	00 
  523887:	4c 89 e7             	mov    %r12,%rdi
  52388a:	ff 15 58 6a da 00    	call   *0xda6a58(%rip)        # 12ca2e8 <_GLOBAL_OFFSET_TABLE_+0x64a8>
  523890:	49 89 c5             	mov    %rax,%r13
  523893:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
  52389a:	00 
  52389b:	48 8d 94 24 a0 01 00 	lea    0x1a0(%rsp),%rdx
  5238a2:	00 
  5238a3:	4c 89 e7             	mov    %r12,%rdi
  5238a6:	48 8b b4 24 38 04 00 	mov    0x438(%rsp),%rsi
  5238ad:	00 
  5238ae:	e8 3d cb ff ff       	call   5203f0 <<gpui_gpu::renderer::GpuContext>::submit>
  5238b3:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  5238b8:	49 c1 e7 20          	shl    $0x20,%r15
  5238bc:	41 8d ae 00 00 00 80 	lea    -0x80000000(%r14),%ebp
  5238c3:	48 8b 84 24 60 03 00 	mov    0x360(%rsp),%rax
  5238ca:	00 
  5238cb:	48 3b 84 24 68 03 00 	cmp    0x368(%rsp),%rax
  5238d2:	00 
  5238d3:	41 0f 44 ee          	cmove  %r14d,%ebp
  5238d7:	4c 09 fd             	or     %r15,%rbp
  5238da:	48 8b 03             	mov    (%rbx),%rax
  5238dd:	48 85 c0             	test   %rax,%rax
  5238e0:	74 0f                	je     5238f1 <<gpui_gpu::renderer::RendererState>::render+0x2571>
  5238e2:	f0 48 ff 08          	lock decq (%rax)
  5238e6:	75 09                	jne    5238f1 <<gpui_gpu::renderer::RendererState>::render+0x2571>
  5238e8:	48 89 df             	mov    %rbx,%rdi
  5238eb:	ff 15 df 39 da 00    	call   *0xda39df(%rip)        # 12c72d0 <_GLOBAL_OFFSET_TABLE_+0x3490>
  5238f1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  5238f6:	4c 89 a8 30 03 00 00 	mov    %r13,0x330(%rax)
  5238fd:	48 89 a8 38 03 00 00 	mov    %rbp,0x338(%rax)
  523904:	4c 8b 40 10          	mov    0x10(%rax),%r8
  523908:	48 8b 70 28          	mov    0x28(%rax),%rsi
  52390c:	48 8b 48 70          	mov    0x70(%rax),%rcx
  523910:	48 89 8c 24 d8 00 00 	mov    %rcx,0xd8(%rsp)
  523917:	00 
  523918:	49 c1 e0 04          	shl    $0x4,%r8
  52391c:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  523921:	49 8d 3c 90          	lea    (%r8,%rdx,4),%rdi
  523925:	48 8d 34 f7          	lea    (%rdi,%rsi,8),%rsi
  523929:	48 89 cf             	mov    %rcx,%rdi
  52392c:	48 c1 e7 05          	shl    $0x5,%rdi
  523930:	48 8d 0c 37          	lea    (%rdi,%rsi,1),%rcx
  523934:	48 83 c1 30          	add    $0x30,%rcx
  523938:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
  52393f:	00 
  523940:	48 8b b8 78 02 00 00 	mov    0x278(%rax),%rdi
  523947:	48 03 b8 50 02 00 00 	add    0x250(%rax),%rdi
  52394e:	48 03 b8 a0 02 00 00 	add    0x2a0(%rax),%rdi
  523955:	48 03 b8 c8 02 00 00 	add    0x2c8(%rax),%rdi
  52395c:	48 03 b8 f0 02 00 00 	add    0x2f0(%rax),%rdi
  523963:	48 8b b0 08 03 00 00 	mov    0x308(%rax),%rsi
  52396a:	48 03 b0 10 03 00 00 	add    0x310(%rax),%rsi
  523971:	44 8b 88 50 01 00 00 	mov    0x150(%rax),%r9d
  523978:	4d 0f af c9          	imul   %r9,%r9
  52397c:	4c 8b 9c 24 00 01 00 	mov    0x100(%rsp),%r11
  523983:	00 
  523984:	4c 89 d9             	mov    %r11,%rcx
  523987:	48 29 d1             	sub    %rdx,%rcx
  52398a:	4c 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%r10
  523991:	00 
  523992:	4d 89 d4             	mov    %r10,%r12
  523995:	48 8b ac 24 18 03 00 	mov    0x318(%rsp),%rbp
  52399c:	00 
  52399d:	49 29 ec             	sub    %rbp,%r12
  5239a0:	48 8b 98 60 01 00 00 	mov    0x160(%rax),%rbx
  5239a7:	48 ff c3             	inc    %rbx
  5239aa:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
  5239b1:	4c 0f 45 f3          	cmovne %rbx,%r14
  5239b5:	48 8b 18             	mov    (%rax),%rbx
  5239b8:	48 c1 e3 04          	shl    $0x4,%rbx
  5239bc:	4c 8b 78 48          	mov    0x48(%rax),%r15
  5239c0:	4c 03 78 30          	add    0x30(%rax),%r15
  5239c4:	4c 8b 68 18          	mov    0x18(%rax),%r13
  5239c8:	4a 8d 1c eb          	lea    (%rbx,%r13,8),%rbx
  5239cc:	4a 8d 1c bb          	lea    (%rbx,%r15,4),%rbx
  5239d0:	4c 8b 78 60          	mov    0x60(%rax),%r15
  5239d4:	49 c1 e7 05          	shl    $0x5,%r15
  5239d8:	49 01 df             	add    %rbx,%r15
  5239db:	48 8b 98 38 01 00 00 	mov    0x138(%rax),%rbx
  5239e2:	4c 8b a8 30 01 00 00 	mov    0x130(%rax),%r13
  5239e9:	4c 89 b0 60 01 00 00 	mov    %r14,0x160(%rax)
  5239f0:	4c 89 90 68 01 00 00 	mov    %r10,0x168(%rax)
  5239f7:	4f 8d 34 1b          	lea    (%r11,%r11,1),%r14
  5239fb:	4c 89 b0 70 01 00 00 	mov    %r14,0x170(%rax)
  523a02:	48 c7 80 78 01 00 00 	movq   $0x1,0x178(%rax)
  523a09:	01 00 00 00 
  523a0d:	4c 89 90 80 01 00 00 	mov    %r10,0x180(%rax)
  523a14:	48 89 90 88 01 00 00 	mov    %rdx,0x188(%rax)
  523a1b:	4c 89 98 90 01 00 00 	mov    %r11,0x190(%rax)
  523a22:	48 89 88 98 01 00 00 	mov    %rcx,0x198(%rax)
  523a29:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  523a2e:	48 89 88 a0 01 00 00 	mov    %rcx,0x1a0(%rax)
  523a35:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  523a3a:	48 89 88 a8 01 00 00 	mov    %rcx,0x1a8(%rax)
  523a41:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  523a48:	00 
  523a49:	48 89 88 b0 01 00 00 	mov    %rcx,0x1b0(%rax)
  523a50:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
  523a57:	00 
  523a58:	48 89 88 b8 01 00 00 	mov    %rcx,0x1b8(%rax)
  523a5f:	4c 89 80 c0 01 00 00 	mov    %r8,0x1c0(%rax)
  523a66:	48 8b 94 24 10 03 00 	mov    0x310(%rsp),%rdx
  523a6d:	00 
  523a6e:	48 89 90 c8 01 00 00 	mov    %rdx,0x1c8(%rax)
  523a75:	48 89 a8 d0 01 00 00 	mov    %rbp,0x1d0(%rax)
  523a7c:	4c 89 a0 d8 01 00 00 	mov    %r12,0x1d8(%rax)
  523a83:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
  523a8a:	00 
  523a8b:	48 89 88 e0 01 00 00 	mov    %rcx,0x1e0(%rax)
  523a92:	48 89 b8 e8 01 00 00 	mov    %rdi,0x1e8(%rax)
  523a99:	4c 89 88 f0 01 00 00 	mov    %r9,0x1f0(%rax)
  523aa0:	49 01 dd             	add    %rbx,%r13
  523aa3:	48 89 98 f8 01 00 00 	mov    %rbx,0x1f8(%rax)
  523aaa:	4c 89 a8 00 02 00 00 	mov    %r13,0x200(%rax)
  523ab1:	4c 89 b8 08 02 00 00 	mov    %r15,0x208(%rax)
  523ab8:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
  523abf:	00 
  523ac0:	48 89 88 10 02 00 00 	mov    %rcx,0x210(%rax)
  523ac7:	48 89 b0 18 02 00 00 	mov    %rsi,0x218(%rax)
  523ace:	c6 80 20 02 00 00 00 	movb   $0x0,0x220(%rax)
  523ad5:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  523ada:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  523adf:	48 89 47 08          	mov    %rax,0x8(%rdi)
  523ae3:	c7 07 ff ff ff ff    	movl   $0xffffffff,(%rdi)
  523ae9:	e9 a3 d9 ff ff       	jmp    521491 <<gpui_gpu::renderer::RendererState>::render+0x111>
  523aee:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  523af3:	e9 8b d9 ff ff       	jmp    521483 <<gpui_gpu::renderer::RendererState>::render+0x103>
  523af8:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  523aff:	00 00 
  523b01:	31 c0                	xor    %eax,%eax
  523b03:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  523b0a:	00 00 
  523b0c:	eb 12                	jmp    523b20 <<gpui_gpu::renderer::RendererState>::render+0x27a0>
  523b0e:	48 ff 44 24 50       	incq   0x50(%rsp)
  523b13:	48 83 c0 08          	add    $0x8,%rax
  523b17:	48 39 c7             	cmp    %rax,%rdi
  523b1a:	0f 84 9d f9 ff ff    	je     5234bd <<gpui_gpu::renderer::RendererState>::render+0x213d>
  523b20:	41 8b 4c 00 04       	mov    0x4(%r8,%rax,1),%ecx
  523b25:	89 ca                	mov    %ecx,%edx
  523b27:	f7 da                	neg    %edx
  523b29:	70 e3                	jo     523b0e <<gpui_gpu::renderer::RendererState>::render+0x278e>
  523b2b:	41 3b 0c 00          	cmp    (%r8,%rax,1),%ecx
  523b2f:	74 e2                	je     523b13 <<gpui_gpu::renderer::RendererState>::render+0x2793>
  523b31:	48 8d 3d 98 cd d5 00 	lea    0xd5cd98(%rip),%rdi        # 12808d0 <anon.11c63428aaff144b0aa1b5cb745d0db3.29.llvm.13440534355744728144+0x10>
  523b38:	ff 15 fa 13 da 00    	call   *0xda13fa(%rip)        # 12c4f38 <_GLOBAL_OFFSET_TABLE_+0x10f8>
  523b3e:	48 8d 3d db cb d5 00 	lea    0xd5cbdb(%rip),%rdi        # 1280720 <anon.255c8ba72969252177b3101bd34b486f.6.llvm.2677678285831016542+0x60>
  523b45:	ff 15 05 1d da 00    	call   *0xda1d05(%rip)        # 12c5850 <_GLOBAL_OFFSET_TABLE_+0x1a10>
  523b4b:	48 8d 15 e6 cb d5 00 	lea    0xd5cbe6(%rip),%rdx        # 1280738 <anon.255c8ba72969252177b3101bd34b486f.6.llvm.2677678285831016542+0x78>
  523b52:	ff 15 88 63 da 00    	call   *0xda6388(%rip)        # 12c9ee0 <_GLOBAL_OFFSET_TABLE_+0x60a0>
  523b58:	48 8d 15 a9 cb d5 00 	lea    0xd5cba9(%rip),%rdx        # 1280708 <anon.255c8ba72969252177b3101bd34b486f.6.llvm.2677678285831016542+0x48>
  523b5f:	ff 15 7b 63 da 00    	call   *0xda637b(%rip)        # 12c9ee0 <_GLOBAL_OFFSET_TABLE_+0x60a0>
  523b65:	49 89 c6             	mov    %rax,%r14
  523b68:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  523b6d:	4c 89 a8 30 03 00 00 	mov    %r13,0x330(%rax)
  523b74:	48 89 a8 38 03 00 00 	mov    %rbp,0x338(%rax)
  523b7b:	4c 89 f7             	mov    %r14,%rdi
  523b7e:	e8 bd 44 b6 ff       	call   88040 <_Unwind_Resume@plt>
  523b83:	49 89 c6             	mov    %rax,%r14
  523b86:	f0 49 ff 4d 00       	lock decq 0x0(%r13)
  523b8b:	75 20                	jne    523bad <<gpui_gpu::renderer::RendererState>::render+0x282d>
  523b8d:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  523b94:	00 
  523b95:	ff 15 35 37 da 00    	call   *0xda3735(%rip)        # 12c72d0 <_GLOBAL_OFFSET_TABLE_+0x3490>
  523b9b:	eb 10                	jmp    523bad <<gpui_gpu::renderer::RendererState>::render+0x282d>
  523b9d:	ff 15 65 6e da 00    	call   *0xda6e65(%rip)        # 12caa08 <_GLOBAL_OFFSET_TABLE_+0x6bc8>
  523ba3:	49 89 c6             	mov    %rax,%r14
  523ba6:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  523bad:	4c 89 f7             	mov    %r14,%rdi
  523bb0:	e8 8b 44 b6 ff       	call   88040 <_Unwind_Resume@plt>
