from pathlib import Path
import hashlib,json,subprocess,tarfile
R=Path('/tmp/gpui-mapped-todo-benchmark-sol');B=Path('/tmp/gpui-mapped-todo-benchmark-sol-build');out=B/'export';out.mkdir(exist_ok=False);pin='0062bf589829c4f28807ad0fde3e13285379294c';scope=['.cargo','clippy.toml','reactivity/Cargo.toml','reactivity/Cargo.lock','reactivity/rust-toolchain.toml','reactivity/crates','reactivity/vendor']
allowed=['reactivity/crates/gpui/Cargo.toml','reactivity/crates/gpui/examples/todo_comparison_five.rs','reactivity/crates/gpui/examples/support/todo_five.rs','reactivity/crates/gpui/examples/todo_comparison_mapped.rs','reactivity/crates/gpui/examples/support/todo_mapped.rs']
changed=subprocess.check_output(['git','-C',str(R),'diff','--name-only',pin,'HEAD','--',*scope],text=True).splitlines();assert set(changed)==set(allowed),changed
rawcommit=subprocess.check_output(['git','-C',str(R),'cat-file','commit',pin]);assert hashlib.sha1(b'commit '+str(len(rawcommit)).encode()+b'\0'+rawcommit).hexdigest()==pin
entries=subprocess.check_output(['git','-C',str(R),'ls-tree','-rz',pin,'--',*scope]);expected={}
for record in entries.split(b'\0'):
 if not record:continue
 header,name=record.split(b'\t',1);mode,kind,oid=header.decode().split();assert kind=='blob';expected[name.decode()]={'mode':mode,'git_blob':oid}
archive=B/'0062-scoped-base.tar'
with archive.open('wb') as f:subprocess.run(['git','-C',str(R),'archive',pin,'--',*scope],stdout=f,check=True)
with tarfile.open(archive) as tar:
 members={m.name:m for m in tar.getmembers() if m.isfile() or m.issym()};assert members.keys()==expected.keys()
 for name,m in members.items():
  data=m.linkname.encode() if m.issym() else tar.extractfile(m).read();assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==expected[name]['git_blob'];expected[name].update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
 tar.extractall(out,filter='data')
patch=B/'todo-overlay.patch';patch.write_bytes(subprocess.check_output(['git','-C',str(R),'diff','--binary',pin,'HEAD','--',*allowed]));subprocess.run(['git','apply',str(patch)],cwd=out,check=True)
final={}
for p in sorted(out.rglob('*')):
 if not(p.is_file() or p.is_symlink()):continue
 data=str(p.readlink()).encode() if p.is_symlink() else p.read_bytes();final[str(p.relative_to(out))]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'symlink':p.is_symlink()}
assert final.keys()==expected.keys()|set(allowed)
for name in expected:
 if name not in allowed:assert final[name]['sha256']==expected[name]['sha256'],name
metadata={'pin':pin,'fixture_commit':subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),'raw_commit':rawcommit.decode(),'scope':scope,'full_repository_claim':False,'core_production_files_unchanged_from_pin':True,'allowed_overlay_files':allowed,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'overlay_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),'upstream_files':expected,'final_files':final,'status':'unadopted mapped-API full-Todo successor; original fixture unchanged for same-core control'}
(B/'source-manifest.json').write_text(json.dumps(metadata,indent=2)+'\n');(out/'.benchmark-upstream.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps({'pin':pin,'fixture':metadata['fixture_commit'],'production_files_identical':True,'final_files':len(final),'bytes':archive.stat().st_size}))
