import datetime,fcntl,json,os,shutil,subprocess,sys,traceback
from pathlib import Path
T=Path('/home/miles/gpui-ce3-compute-20261024');D=T/'evidence/mapped-todo';D.mkdir(exist_ok=True);R=T/'src/five-app/runner';sys.path.insert(0,str(R));import todo_core as core
status={'pid':os.getpid(),'pgid':os.getpgrp(),'state':'starting','core_pin':'0062bf589829c4f28807ad0fde3e13285379294c','build_jobs':2,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'builds':[]}
def save():(D/'build-supervisor-v2.json').write_text(json.dumps(status,indent=2)+'\n')
save()
try:
 with(T/'host.lock').open('a+') as lease:
  fcntl.flock(lease,fcntl.LOCK_SH)
  if shutil.disk_usage(T).free<10*1024**3:raise RuntimeError('need10GiBbefore810MiBcachecopy+build;8GiBfloor')
  target=T/'targets/mapped-todo';assert target.exists();status['state']='reuse-complete-cache-copy-from-rejected-precompile-attempt';save();assert core.file_sha256(target/'release/examples/todo_comparison_five')==core.file_sha256(T/'targets/five-app/gpui/release/examples/todo_comparison_five')
  for example in ('todo_comparison_five','todo_comparison_mapped'):
   status.update(state='building',example=example);save();script=D/f'{example}-build.sh';script.write_text(f'''#!/usr/bin/env bash
set -euo pipefail
source {T}/env.sh
export CARGO_HOME=/home/miles/.cargo CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0
export CARGO_TARGET_DIR={target}
cd {T}/src/mapped-todo/reactivity
cargo build --offline --locked --release -p gpui --example {example} --features x11
/nix/store/if2h609psbpg1ysf1m27dpshjk2wzpk4-patchelf-0.15.2/bin/patchelf --set-interpreter /nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib/ld-linux-x86-64.so.2 {target}/release/examples/{example}
''');command=D/f'{example}-command.json';command.write_text(json.dumps(['bash',str(script)]));rc=subprocess.run([sys.executable,str(R/'build_one.py'),'--source',str(T/'src/mapped-todo'),'--binary',str(target/'release/examples'/example),'--lease',str(T/'host.lock'),'--receipt',str(D/f'{example}-v2-receipt.json'),'--log',str(D/f'{example}-v2-build.log'),'--command-json',str(command),'--timeout','1800']).returncode;status['builds'].append({'example':example,'exit_code':rc});save()
   if rc:raise RuntimeError(f'{example}buildfailed{rc}')
  status['state']='complete'
except BaseException as error:status.update(state='failed',error=repr(error),traceback=traceback.format_exc())
finally:status['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
