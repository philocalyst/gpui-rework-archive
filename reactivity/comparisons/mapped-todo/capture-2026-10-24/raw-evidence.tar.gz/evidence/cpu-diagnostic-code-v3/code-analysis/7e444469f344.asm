
jit-code/7e4444685000-7e44446b1000.bin:     file format binary


Disassembly of section .data:

00007e444469f344 <.data+0x1a344>:
    7e444469f344:	c5 e9 6b d3          	vpackssdw %xmm3,%xmm2,%xmm2
    7e444469f348:	c4 c1 79 6f 1b       	vmovdqa (%r11),%xmm3
    7e444469f34d:	c4 e2 79 00 f3       	vpshufb %xmm3,%xmm0,%xmm6
    7e444469f352:	c4 e2 19 00 fb       	vpshufb %xmm3,%xmm12,%xmm7
    7e444469f357:	c5 c1 62 f6          	vpunpckldq %xmm6,%xmm7,%xmm6
    7e444469f35b:	c5 e9 63 d2          	vpacksswb %xmm2,%xmm2,%xmm2
    7e444469f35f:	c4 e2 59 00 26       	vpshufb (%rsi),%xmm4,%xmm4
    7e444469f364:	c5 d9 71 f4 07       	vpsllw $0x7,%xmm4,%xmm4
    7e444469f369:	c4 c1 59 db 20       	vpand  (%r8),%xmm4,%xmm4
    7e444469f36e:	c5 b1 64 e4          	vpcmpgtb %xmm4,%xmm9,%xmm4
    7e444469f372:	c5 d9 db e6          	vpand  %xmm6,%xmm4,%xmm4
    7e444469f376:	c4 c1 79 6f 31       	vmovdqa (%r9),%xmm6
    7e444469f37b:	c5 e9 db d6          	vpand  %xmm6,%xmm2,%xmm2
    7e444469f37f:	c5 d9 db d2          	vpand  %xmm2,%xmm4,%xmm2
    7e444469f383:	c5 d9 df a4 24 20 06 	vpandn 0x620(%rsp),%xmm4,%xmm4
    7e444469f38a:	00 00 
    7e444469f38c:	c5 e9 eb d4          	vpor   %xmm4,%xmm2,%xmm2
    7e444469f390:	c4 c1 3c c2 e5 02    	vcmpleps %ymm13,%ymm8,%ymm4
    7e444469f396:	c4 e3 7d 19 e7 01    	vextractf128 $0x1,%ymm4,%xmm7
    7e444469f39c:	c5 d9 6b e7          	vpackssdw %xmm7,%xmm4,%xmm4
    7e444469f3a0:	c4 e3 7d 39 ef 01    	vextracti128 $0x1,%ymm5,%xmm7
    7e444469f3a6:	c4 e2 41 00 fb       	vpshufb %xmm3,%xmm7,%xmm7
    7e444469f3ab:	c4 e2 51 00 db       	vpshufb %xmm3,%xmm5,%xmm3
    7e444469f3b0:	c5 e1 62 df          	vpunpckldq %xmm7,%xmm3,%xmm3
    7e444469f3b4:	c5 d9 63 e4          	vpacksswb %xmm4,%xmm4,%xmm4
    7e444469f3b8:	c5 e1 db ee          	vpand  %xmm6,%xmm3,%xmm5
    7e444469f3bc:	c5 d1 db e4          	vpand  %xmm4,%xmm5,%xmm4
    7e444469f3c0:	c5 e1 df d2          	vpandn %xmm2,%xmm3,%xmm2
    7e444469f3c4:	c5 d9 eb da          	vpor   %xmm2,%xmm4,%xmm3
    7e444469f3c8:	c5 7c 28 84 24 60 07 	vmovaps 0x760(%rsp),%ymm8
    7e444469f3cf:	00 00 
    7e444469f3d1:	eb 1f                	jmp    0x7e444469f3f2
    7e444469f3d3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    7e444469f3da:	84 00 00 00 00 00 
    7e444469f3e0:	c5 7c 28 84 24 60 07 	vmovaps 0x760(%rsp),%ymm8
    7e444469f3e7:	00 00 
    7e444469f3e9:	c5 f9 6f 9c 24 20 06 	vmovdqa 0x620(%rsp),%xmm3
    7e444469f3f0:	00 00 
    7e444469f3f2:	c5 a1 ef c9          	vpxor  %xmm1,%xmm11,%xmm1
    7e444469f3f6:	c4 e2 71 00 0e       	vpshufb (%rsi),%xmm1,%xmm1
    7e444469f3fb:	c5 f1 71 f1 07       	vpsllw $0x7,%xmm1,%xmm1
    7e444469f400:	c4 c1 71 db        	vpand  (%r8),%xmm1,%xmm1
