
jit-code/7e4444685000-7e44446b1000.bin:     file format binary


Disassembly of section .data:

00007e44446a01f4 <.data+0x1b1f4>:
    7e44446a01f4:	c4 e3 7d 4a c3 10    	vblendvps %ymm1,%ymm3,%ymm0,%ymm0
    7e44446a01fa:	c5 7d 7f 8c 24 c0 10 	vmovdqa %ymm9,0x10c0(%rsp)
    7e44446a0201:	00 00 
    7e44446a0203:	c4 41 7c 5b d1       	vcvtdq2ps %ymm9,%ymm10
    7e44446a0208:	c5 ac 59 df          	vmulps %ymm7,%ymm10,%ymm3
    7e44446a020c:	c5 7c 28 bc 24 60 04 	vmovaps 0x460(%rsp),%ymm15
    7e44446a0213:	00 00 
    7e44446a0215:	c4 c1 64 5e df       	vdivps %ymm15,%ymm3,%ymm3
    7e44446a021a:	c5 fc 29 a4 24 c0 06 	vmovaps %ymm4,0x6c0(%rsp)
    7e44446a0221:	00 00 
    7e44446a0223:	c5 7c 29 b4 24 20 03 	vmovaps %ymm14,0x320(%rsp)
    7e44446a022a:	00 00 
    7e44446a022c:	c5 8c 58 e3          	vaddps %ymm3,%ymm14,%ymm4
    7e44446a0230:	c4 e3 65 4a cc 10    	vblendvps %ymm1,%ymm4,%ymm3,%ymm1
    7e44446a0236:	c4 e3 7d 08 d8 09    	vroundps $0x9,%ymm0,%ymm3
    7e44446a023c:	c5 ed db 54 24 20    	vpand  0x20(%rsp),%ymm2,%ymm2
    7e44446a0242:	c5 fc 5c e3          	vsubps %ymm3,%ymm0,%ymm4
    7e44446a0246:	c5 7c 28 8c 24 00 0a 	vmovaps 0xa00(%rsp),%ymm9
    7e44446a024d:	00 00 
    7e44446a024f:	c4 63 35 4a cc 20    	vblendvps %ymm2,%ymm4,%ymm9,%ymm9
    7e44446a0255:	c4 e3 7d 08 e1 09    	vroundps $0x9,%ymm1,%ymm4
    7e44446a025b:	c5 fc 29 b4 24 20 0a 	vmovaps %ymm6,0xa20(%rsp)
    7e44446a0262:	00 00 
    7e44446a0264:	c5 f4 5c f4          	vsubps %ymm4,%ymm1,%ymm6
    7e44446a0268:	c5 7c 29 84 24 60 07 	vmovaps %ymm8,0x760(%rsp)
    7e44446a026f:	00 00 
    7e44446a0271:	c5 7c 28 84 24 60 0e 	vmovaps 0xe60(%rsp),%ymm8
    7e44446a0278:	00 00 
    7e44446a027a:	c4 63 3d 4a c6 20    	vblendvps %ymm2,%ymm6,%ymm8,%ymm8
    7e44446a0280:	c5 fc 28 b4 24 20 0b 	vmovaps 0xb20(%rsp),%ymm6
    7e44446a0287:	00 00 
    7e44446a0289:	c4 e3 4d 4a f3 20    	vblendvps %ymm2,%ymm3,%ymm6,%ymm6
    7e44446a028f:	c5 fc 29 b4 24 20 0b 	vmovaps %ymm6,0xb20(%rsp)
    7e44446a0296:	00 00 
    7e44446a0298:	c5 fc 28 9c 24 a0 0b 	vmovaps 0xba0(%rsp),%ymm3
    7e44446a029f:	00 00 
    7e44446a02a1:	c4 e3 65 4a dc 20    	vblendvps %ymm2,%ymm4,%ymm3,%ymm3
    7e44446a02a7:	c5 fc 29 9c 24 a0 0b 	vmovaps %ymm3,0xba0(%rsp)
    7e44446a02ae:	00 00 
    7e44446a02b0:	48 b8 fc 24    	movabs $0x7e4447f024fc,%rax
    7e44446a02b7:	   
