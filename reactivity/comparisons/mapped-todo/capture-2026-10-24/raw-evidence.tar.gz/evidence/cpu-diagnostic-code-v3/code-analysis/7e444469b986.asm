
jit-code/7e4444685000-7e44446b1000.bin:     file format binary


Disassembly of section .data:

00007e444469b986 <.data+0x16986>:
    7e444469b986:	c5 fd 7f 9c 24 00 1a 	vmovdqa %ymm3,0x1a00(%rsp)
    7e444469b98d:	00 00 
    7e444469b98f:	c5 fd eb 84 24 40 01 	vpor   0x140(%rsp),%ymm0,%ymm0
    7e444469b996:	00 00 
    7e444469b998:	c4 e2 7d 3f c9       	vpmaxud %ymm1,%ymm0,%ymm1
    7e444469b99d:	c5 fd 76 c9          	vpcmpeqd %ymm1,%ymm0,%ymm1
    7e444469b9a1:	c5 85 ef c9          	vpxor  %ymm1,%ymm15,%ymm1
    7e444469b9a5:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
    7e444469b9a9:	c4 c2 75 90 14 80    	vpgatherdd %ymm1,(%r8,%ymm0,4),%ymm2
    7e444469b9af:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    7e444469b9b3:	c4 e2 7d 0e d2       	vtestps %ymm2,%ymm2
    7e444469b9b8:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
    7e444469b9bc:	c5 d9 ef e4          	vpxor  %xmm4,%xmm4,%xmm4
    7e444469b9c0:	c4 41 21 ef db       	vpxor  %xmm11,%xmm11,%xmm11
    7e444469b9c5:	48 bb 04 25 f0 47 44 	movabs $0x7e4447f02504,%rbx
    7e444469b9cc:	7e 00 00 
    7e444469b9cf:	49 bb 40 26 f0 47 44 	movabs $0x7e4447f02640,%r11
    7e444469b9d6:	7e 00 00 
    7e444469b9d9:	49 b9 50 26 f0 47 44 	movabs $0x7e4447f02650,%r9
    7e444469b9e0:	7e 00 00 
    7e444469b9e3:	49 b8 30 26 f0 47 44 	movabs $0x7e4447f02630,%r8
    7e444469b9ea:	7e 00 00 
    7e444469b9ed:	c5 fc 29 94 24 60 10 	vmovaps %ymm2,0x1060(%rsp)
    7e444469b9f4:	00 00 
    7e444469b9f6:	0f 84 44 0e 00 00    	je     0x7e444469c840
    7e444469b9fc:	c5 e5 72 e2 1f       	vpsrad $0x1f,%ymm2,%ymm3
    7e444469ba01:	8b 7c 24 1c          	mov    0x1c(%rsp),%edi
    7e444469ba05:	83 e7 08             	and    $0x8,%edi
    7e444469ba08:	40 c0 ef 03          	shr    $0x3,%dil
    7e444469ba0c:	c5 f9 6e c7          	vmovd  %edi,%xmm0
    7e444469ba10:	c4 e2 79 78 c0       	vpbroadcastb %xmm0,%xmm0
    7e444469ba15:	c4 e2 7d 33 c0       	vpmovzxwd %xmm0,%ymm0
    7e444469ba1a:	c5 fd 72 f0 1f       	vpslld $0x1f,%ymm0,%ymm0
    7e444469ba1f:	c5 fd 72 e0 1f       	vpsrad $0x1f,%ymm0,%ymm0
    7e444469ba24:	c5 7d db f3          	vpand  %ymm3,%ymm0,%ymm14
    7e444469ba28:	c4 e2 7d 17 c3       	vptest %ymm3,%ymm0
    7e444469ba2d:	c5 fd 6f 84 24 00 1a 	vmovdqa 0x1a00(%rsp),%ymm0
    7e444469ba34:	00 00 
    7e444469ba36:	c5 cd 72 e0 1f       	vpsrad $0x1f,%ymm0,%ymm6
    7e444469ba3b:	c5 9d 72 f0 04       	vpslld $0x4,%ymm0,%ymm12
    7e444469ba40:	0f 84 52 02 00 00    	je     0x7e444469bc98
