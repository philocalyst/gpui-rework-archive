
jit-code/7e4444685000-7e44446b1000.bin:     file format binary


Disassembly of section .data:

00007e444469f196 <.data+0x1a196>:
    7e444469f196:	c5 f5 72 e1 1f       	vpsrad $0x1f,%ymm1,%ymm1
    7e444469f19b:	c5 f5 df f0          	vpandn %ymm0,%ymm1,%ymm6
    7e444469f19f:	c5 ed db c6          	vpand  %ymm6,%ymm2,%ymm0
    7e444469f1a3:	c5 fd 7f 84 24 80 01 	vmovdqa %ymm0,0x180(%rsp)
    7e444469f1aa:	00 00 
    7e444469f1ac:	c5 95 76 c0          	vpcmpeqd %ymm0,%ymm13,%ymm0
    7e444469f1b0:	c5 fc 50 c0          	vmovmskps %ymm0,%eax
    7e444469f1b4:	35 ff 00 00 00       	xor    $0xff,%eax
    7e444469f1b9:	f3 0f bc c8          	tzcnt  %eax,%ecx
    7e444469f1bd:	0f 42 c8             	cmovb  %eax,%ecx
    7e444469f1c0:	83 e1 07             	and    $0x7,%ecx
    7e444469f1c3:	c1 e1 02             	shl    $0x2,%ecx
    7e444469f1c6:	44 8b bc 0c 60 1c 00 	mov    0x1c60(%rsp,%rcx,1),%r15d
    7e444469f1cd:	00 
    7e444469f1ce:	c4 c1 02 2a c7       	vcvtsi2ss %r15d,%xmm15,%xmm0
    7e444469f1d3:	c5 fa 10 94 24 fc 06 	vmovss 0x6fc(%rsp),%xmm2
    7e444469f1da:	00 00 
    7e444469f1dc:	c5 fa 58 c2          	vaddss %xmm2,%xmm0,%xmm0
    7e444469f1e0:	c5 fa 10 9c 24 f8 06 	vmovss 0x6f8(%rsp),%xmm3
    7e444469f1e7:	00 00 
    7e444469f1e9:	c5 fa 59 c3          	vmulss %xmm3,%xmm0,%xmm0
    7e444469f1ed:	c5 fa 10 a4 24 f4 06 	vmovss 0x6f4(%rsp),%xmm4
    7e444469f1f4:	00 00 
    7e444469f1f6:	c5 fa 58 c4          	vaddss %xmm4,%xmm0,%xmm0
    7e444469f1fa:	c4 e2 7d 18 c0       	vbroadcastss %xmm0,%ymm0
    7e444469f1ff:	c5 fc 29 ac 24 40 1f 	vmovaps %ymm5,0x1f40(%rsp)
    7e444469f206:	00 00 
    7e444469f208:	8b bc 0c 40 1f 00 00 	mov    0x1f40(%rsp,%rcx,1),%edi
    7e444469f20f:	c5 82 2a cf          	vcvtsi2ss %edi,%xmm15,%xmm1
    7e444469f213:	c5 f2 58 ca          	vaddss %xmm2,%xmm1,%xmm1
    7e444469f217:	c5 f2 59 cb          	vmulss %xmm3,%xmm1,%xmm1
    7e444469f21b:	c5 f2 58 cc          	vaddss %xmm4,%xmm1,%xmm1
    7e444469f21f:	c4 e2 7d 18 c9       	vbroadcastss %xmm1,%ymm1
    7e444469f224:	c5 fc 58 ac 24 a0 1b 	vaddps 0x1ba0(%rsp),%ymm0,%ymm5
    7e444469f22b:	00 00 
    7e444469f22d:	c5 f4 58 8c 24 80 1b 	vaddps 0x1b80(%rsp),%ymm1,%ymm1
    7e444469f234:	00 00 
    7e444469f236:	c5 fc 29 8c 24 80 00 	vmovaps %ymm1,0x80(%rsp)
    7e444469f23d:	00 00 
    7e444469f23f:	c5 fc 28 9c 24 00 0f 	vmovaps 0xf00(%rsp),%ymm3
    7e444469f246:	00 00 
    7e444469f248:	c5 d4 c2 c3 05       	vcmpnltps %ymm3,%ymm5,%ymm0
    7e444469f24d:	c5 f4 c2 8c 24 c0 0d 	vcmpnltps 0xdc0(%rsp),%ymm1,%ymm1
    7e444469f254:	00 00  
