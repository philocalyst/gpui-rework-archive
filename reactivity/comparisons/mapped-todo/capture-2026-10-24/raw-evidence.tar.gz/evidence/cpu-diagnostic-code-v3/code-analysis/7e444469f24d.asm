
jit-code/7e4444685000-7e44446b1000.bin:     file format binary


Disassembly of section .data:

00007e444469f24d <.data+0x1a24d>:
    7e444469f24d:	c5 f4 c2 8c 24 c0 0d 	vcmpnltps 0xdc0(%rsp),%ymm1,%ymm1
    7e444469f254:	00 00 05 
    7e444469f257:	c5 fc 54 c1          	vandps %ymm1,%ymm0,%ymm0
    7e444469f25b:	c4 e3 7d 19 c1 01    	vextractf128 $0x1,%ymm0,%xmm1
    7e444469f261:	c5 f9 6b c1          	vpackssdw %xmm1,%xmm0,%xmm0
    7e444469f265:	c5 a1 db c8          	vpand  %xmm0,%xmm11,%xmm1
    7e444469f269:	c4 e2 7d 33 c1       	vpmovzxwd %xmm1,%ymm0
    7e444469f26e:	c5 fd 72 f0 1f       	vpslld $0x1f,%ymm0,%ymm0
    7e444469f273:	c5 15 76 d6          	vpcmpeqd %ymm6,%ymm13,%ymm10
    7e444469f277:	c4 62 7d 0e d0       	vtestps %ymm0,%ymm10
    7e444469f27c:	c5 fd 7f 74 24 20    	vmovdqa %ymm6,0x20(%rsp)
    7e444469f282:	c4 e3 7d 39 f0 01    	vextracti128 $0x1,%ymm6,%xmm0
    7e444469f288:	c5 fd 6f 94 24 20 0f 	vmovdqa 0xf20(%rsp),%ymm2
    7e444469f28f:	00 00 
    7e444469f291:	c5 cd 72 f2 05       	vpslld $0x5,%ymm2,%ymm6
    7e444469f296:	c5 fc 29 ac 24 60 01 	vmovaps %ymm5,0x160(%rsp)
    7e444469f29d:	00 00 
    7e444469f29f:	c5 fd 7f b4 24 20 01 	vmovdqa %ymm6,0x120(%rsp)
    7e444469f2a6:	00 00 
    7e444469f2a8:	0f 82 32 01 00 00    	jb     0x7e444469f3e0
    7e444469f2ae:	c5 e4 58 a4 24 c0 05 	vaddps 0x5c0(%rsp),%ymm3,%ymm4
    7e444469f2b5:	00 00 
    7e444469f2b7:	c5 dc c2 d5 01       	vcmpltps %ymm5,%ymm4,%ymm2
    7e444469f2bc:	c4 e3 7d 19 d3 01    	vextractf128 $0x1,%ymm2,%xmm3
    7e444469f2c2:	c5 d4 c2 e4 0c       	vcmpneq_oqps %ymm4,%ymm5,%ymm4
    7e444469f2c7:	c4 e3 7d 19 e5 01    	vextractf128 $0x1,%ymm4,%xmm5
    7e444469f2cd:	c5 d9 6b e5          	vpackssdw %xmm5,%xmm4,%xmm4
    7e444469f2d1:	c5 f1 db e4          	vpand  %xmm4,%xmm1,%xmm4
    7e444469f2d5:	c5 d9 ef e9          	vpxor  %xmm1,%xmm4,%xmm5
    7e444469f2d9:	c4 e2 7d 33 ed       	vpmovzxwd %xmm5,%ymm5
    7e444469f2de:	c5 d5 72 f5 1f       	vpslld $0x1f,%ymm5,%ymm5
    7e444469f2e3:	c5 d5 72 e5 1f       	vpsrad $0x1f,%ymm5,%ymm5
    7e444469f2e8:	c5 7d 6f 64 24 20    	vmovdqa 0x20(%rsp),%ymm12
    7e444469f2ee:	c5 9d db ed          	vpand  %ymm5,%ymm12,%ymm5
    7e444469f2f2:	c5 cd 72 e6 02       	vpsrad $0x2,%ymm6,%ymm6
    7e444469f2f7:	c5 95 76 fd          	vpcmpeqd %ymm5,%ymm13,%ymm7
    7e444469f2fb:	41 8b 85 48 01 00 00 	mov    0x148(%r13),%eax
    7e444469f302:	49 8b 8d 40 01 00 00 	mov    0x140(%r13),%rcx
    7e444469f309:	c1 f8 02             	sar    $0x2,%eax
    7e444469f30c:	48       	movabs $0x7e4447f024bc,%rdx
    7e444469f313:	   
