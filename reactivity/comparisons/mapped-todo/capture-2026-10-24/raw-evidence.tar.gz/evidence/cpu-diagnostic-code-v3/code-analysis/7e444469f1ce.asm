
jit-code/7e4444685000-7e44446b1000.bin:     file format binary


Disassembly of section .data:

00007e444469f1ce <.data+0x1a1ce>:
    7e444469f1ce:	c4 c1 02 2a c7       	vcvtsi2ss %r15d,%xmm15,%xmm0
    7e444469f1d3:	c5 fa 10 94 24 fc 06 	vmovss 0x6fc(%rsp),%xmm2
    7e444469f1da:	00 00 
    7e444469f1dc:	c5 fa 58 c2          	vaddss %xmm2,%xmm0,%xmm0
    7e444469f1e0:	c5 fa 10 9c 24 f8 06 	vmovss 0x6f8(%rsp),%xmm3
    7e444469f1e7:	00 00 
    7e444469f1e9:	c5 fa 59 c3          	vmulss %xmm3,%xmm0,%xmm0
    7e444469f1ed:	c5 fa 10 a4 24 f4 06 	vmovss 0x6f4(%rsp),%xmm4
    7e444469f1f4:	00 00 
    7e444469f1f6:	c5 fa 58 c4          	vaddss %xmm4,%xmm0,%xmm0
    7e444469f1fa:	c4 e2 7d 18 c0       	vbroadcastss %xmm0,%ymm0
    7e444469f1ff:	c5 fc 29 ac 24 40 1f 	vmovaps %ymm5,0x1f40(%rsp)
    7e444469f206:	00 00 
    7e444469f208:	8b bc 0c 40 1f 00 00 	mov    0x1f40(%rsp,%rcx,1),%edi
    7e444469f20f:	c5 82 2a cf          	vcvtsi2ss %edi,%xmm15,%xmm1
    7e444469f213:	c5 f2 58 ca          	vaddss %xmm2,%xmm1,%xmm1
    7e444469f217:	c5 f2 59 cb          	vmulss %xmm3,%xmm1,%xmm1
    7e444469f21b:	c5 f2 58 cc          	vaddss %xmm4,%xmm1,%xmm1
    7e444469f21f:	c4 e2 7d 18 c9       	vbroadcastss %xmm1,%ymm1
    7e444469f224:	c5 fc 58 ac 24 a0 1b 	vaddps 0x1ba0(%rsp),%ymm0,%ymm5
    7e444469f22b:	00 00 
    7e444469f22d:	c5 f4 58 8c 24 80 1b 	vaddps 0x1b80(%rsp),%ymm1,%ymm1
    7e444469f234:	00 00 
    7e444469f236:	c5 fc 29 8c 24 80 00 	vmovaps %ymm1,0x80(%rsp)
    7e444469f23d:	00 00 
    7e444469f23f:	c5 fc 28 9c 24 00 0f 	vmovaps 0xf00(%rsp),%ymm3
    7e444469f246:	00 00 
    7e444469f248:	c5 d4 c2 c3 05       	vcmpnltps %ymm3,%ymm5,%ymm0
    7e444469f24d:	c5 f4 c2 8c 24 c0 0d 	vcmpnltps 0xdc0(%rsp),%ymm1,%ymm1
    7e444469f254:	00 00 05 
    7e444469f257:	c5 fc 54 c1          	vandps %ymm1,%ymm0,%ymm0
    7e444469f25b:	c4 e3 7d 19 c1 01    	vextractf128 $0x1,%ymm0,%xmm1
    7e444469f261:	c5 f9 6b c1          	vpackssdw %xmm1,%xmm0,%xmm0
    7e444469f265:	c5 a1 db c8          	vpand  %xmm0,%xmm11,%xmm1
    7e444469f269:	c4 e2 7d 33 c1       	vpmovzxwd %xmm1,%ymm0
    7e444469f26e:	c5 fd 72 f0 1f       	vpslld $0x1f,%ymm0,%ymm0
    7e444469f273:	c5 15 76 d6          	vpcmpeqd %ymm6,%ymm13,%ymm10
    7e444469f277:	c4 62 7d 0e d0       	vtestps %ymm0,%ymm10
    7e444469f27c:	c5 fd 7f 74 24 20    	vmovdqa %ymm6,0x20(%rsp)
    7e444469f282:	c4 e3 7d 39 f0 01    	vextracti128 $0x1,%ymm6,%xmm0
    7e444469f288:	c5 fd 6f 94 24 20  	vmovdqa 0xf20(%rsp),%ymm2
    7e444469f28f:	  
