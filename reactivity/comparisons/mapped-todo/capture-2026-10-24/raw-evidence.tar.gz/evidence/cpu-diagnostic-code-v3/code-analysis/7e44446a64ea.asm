
jit-code/7e4444685000-7e44446b1000.bin:     file format binary


Disassembly of section .data:

00007e44446a64ea <.data+0x214ea>:
    7e44446a64ea:	48 b9 c0 22 f0 47 44 	movabs $0x7e4447f022c0,%rcx
    7e44446a64f1:	7e 00 00 
    7e44446a64f4:	c5 fd eb 39          	vpor   (%rcx),%ymm0,%ymm7
    7e44446a64f8:	c5 f5 72 f7 02       	vpslld $0x2,%ymm7,%ymm1
    7e44446a64fd:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
    7e44446a6501:	c4 41 38 57 c0       	vxorps %xmm8,%xmm8,%xmm8
    7e44446a6506:	c4 62 6d 90 04 08    	vpgatherdd %ymm2,(%rax,%ymm1,1),%ymm8
    7e44446a650c:	48 b9 e0 22 f0 47 44 	movabs $0x7e4447f022e0,%rcx
    7e44446a6513:	7e 00 00 
    7e44446a6516:	c5 fd eb 21          	vpor   (%rcx),%ymm0,%ymm4
    7e44446a651a:	c5 f5 72 f4 02       	vpslld $0x2,%ymm4,%ymm1
    7e44446a651f:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
    7e44446a6523:	c5 d0 57 ed          	vxorps %xmm5,%xmm5,%xmm5
    7e44446a6527:	c4 e2 6d 90 2c 08    	vpgatherdd %ymm2,(%rax,%ymm1,1),%ymm5
    7e44446a652d:	48 b9 00 23 f0 47 44 	movabs $0x7e4447f02300,%rcx
    7e44446a6534:	7e 00 00 
    7e44446a6537:	c5 fd eb 09          	vpor   (%rcx),%ymm0,%ymm1
    7e44446a653b:	c5 fd 72 f1 02       	vpslld $0x2,%ymm1,%ymm0
    7e44446a6540:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
    7e44446a6544:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
    7e44446a6548:	c4 e2 4d 90 14 00    	vpgatherdd %ymm6,(%rax,%ymm0,1),%ymm2
    7e44446a654e:	c5 a1 ef 84 24 00 03 	vpxor  0x300(%rsp),%xmm11,%xmm0
    7e44446a6555:	00 00 
    7e44446a6557:	c4 e2 7d 33 c0       	vpmovzxwd %xmm0,%ymm0
    7e44446a655c:	c5 fd 72 f0 1f       	vpslld $0x1f,%ymm0,%ymm0
    7e44446a6561:	c5 85 ef 74 24 20    	vpxor  0x20(%rsp),%ymm15,%ymm6
    7e44446a6567:	c4 e3 05 4a f6 00    	vblendvps %ymm0,%ymm6,%ymm15,%ymm6
    7e44446a656d:	c5 1c 54 e6          	vandps %ymm6,%ymm12,%ymm12
    7e44446a6571:	c5 7c 28 5c 24 60    	vmovaps 0x60(%rsp),%ymm11
    7e44446a6577:	c5 24 54 de          	vandps %ymm6,%ymm11,%ymm11
    7e44446a657b:	c4 c2 7d 18 02       	vbroadcastss (%r10),%ymm0
    7e44446a6580:	c5 f9 7e d8          	vmovd  %xmm3,%eax
    7e44446a6584:	c4 c1 7c 5c dc       	vsubps %ymm12,%ymm0,%ymm3
    7e44446a6589:	c5 2c 59 d3          	vmulps %ymm3,%ymm10,%ymm10
    7e44446a658d:	c4 41 2c 58 d3       	vaddps %ymm11,%ymm10,%ymm10
    7e44446a6592:	c5 7d 6f bc 24 80 01 	vmovdqa 0x180(%rsp),%ymm15
    7e44446a6599:	00 00 
    7e44446a659b:	c4 61 f9 7e f9       	vmovq  %xmm15,%rcx
    7e44446a65a0:	f6 c1 01             	test   $0x1,%cl
    7e44446a65a3:	75 0b                	jne    0x7e44446a65b0
    7e44446a65a5:	8b 94 84 40 11   	mov    0x1140(%rsp,%rax,4),%edx
