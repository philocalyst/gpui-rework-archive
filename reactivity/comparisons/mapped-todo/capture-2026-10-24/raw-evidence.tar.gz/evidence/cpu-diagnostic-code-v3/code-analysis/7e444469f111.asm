
jit-code/7e4444685000-7e44446b1000.bin:     file format binary


Disassembly of section .data:

00007e444469f111 <.data+0x1a111>:
    7e444469f111:	c5 fd 72 e0 1f       	vpsrad $0x1f,%ymm0,%ymm0
    7e444469f116:	c5 fd df c1          	vpandn %ymm1,%ymm0,%ymm0
    7e444469f11a:	c5 fd 6f 94 24 80 0f 	vmovdqa 0xf80(%rsp),%ymm2
    7e444469f121:	00 00 
    7e444469f123:	c5 ed db c8          	vpand  %ymm0,%ymm2,%ymm1
    7e444469f127:	c5 fd 7f 8c 24 60 09 	vmovdqa %ymm1,0x960(%rsp)
    7e444469f12e:	00 00 
    7e444469f130:	c5 95 76 c9          	vpcmpeqd %ymm1,%ymm13,%ymm1
    7e444469f134:	c5 fc 50 c1          	vmovmskps %ymm1,%eax
    7e444469f138:	35 ff 00 00 00       	xor    $0xff,%eax
    7e444469f13d:	f3 0f bc c8          	tzcnt  %eax,%ecx
    7e444469f141:	0f 42 c8             	cmovb  %eax,%ecx
    7e444469f144:	83 e1 07             	and    $0x7,%ecx
    7e444469f147:	c1 e1 02             	shl    $0x2,%ecx
    7e444469f14a:	44 8b a4 0c 40 1c 00 	mov    0x1c40(%rsp,%rcx,1),%r12d
    7e444469f151:	00 
    7e444469f152:	41 83 ec 01          	sub    $0x1,%r12d
    7e444469f156:	44 8b b4 0c 20 1c 00 	mov    0x1c20(%rsp,%rcx,1),%r14d
    7e444469f15d:	00 
    7e444469f15e:	41 83 de 00          	sbb    $0x0,%r14d
    7e444469f162:	c5 fd 7f a4 24 40 0b 	vmovdqa %ymm4,0xb40(%rsp)
    7e444469f169:	00 00 
    7e444469f16b:	c5 fd 7f a4 24 60 1c 	vmovdqa %ymm4,0x1c60(%rsp)
    7e444469f172:	00 00 
    7e444469f174:	83 bc 0c 60 1c 00 00 	cmpl   $0x4,0x1c60(%rsp,%rcx,1)
    7e444469f17b:	04 
    7e444469f17c:	0f 9d c0             	setge  %al
    7e444469f17f:	c5 f9 6e c8          	vmovd  %eax,%xmm1
    7e444469f183:	c4 e2 79 78 c9       	vpbroadcastb %xmm1,%xmm1
    7e444469f188:	c5 a1 db c9          	vpand  %xmm1,%xmm11,%xmm1
    7e444469f18c:	c4 e2 7d 33 c9       	vpmovzxwd %xmm1,%ymm1
    7e444469f191:	c5 f5 72 f1 1f       	vpslld $0x1f,%ymm1,%ymm1
    7e444469f196:	c5 f5 72 e1 1f       	vpsrad $0x1f,%ymm1,%ymm1
    7e444469f19b:	c5 f5 df f0          	vpandn %ymm0,%ymm1,%ymm6
    7e444469f19f:	c5 ed db c6          	vpand  %ymm6,%ymm2,%ymm0
    7e444469f1a3:	c5 fd 7f 84 24 80 01 	vmovdqa %ymm0,0x180(%rsp)
    7e444469f1aa:	00 00 
    7e444469f1ac:	c5 95 76 c0          	vpcmpeqd %ymm0,%ymm13,%ymm0
    7e444469f1b0:	c5 fc 50 c0          	vmovmskps %ymm0,%eax
    7e444469f1b4:	35 ff 00 00 00       	xor    $0xff,%eax
    7e444469f1b9:	f3 0f bc c8          	tzcnt  %eax,%ecx
    7e444469f1bd:	0f 42 c8             	cmovb  %eax,%ecx
    7e444469f1c0:	83 e1 07             	and    $0x7,%ecx
    7e444469f1c3:	c1 e1 02             	shl    $0x2,%ecx
    7e444469f1c6:	44 8b bc 0c 60 1c 00 	mov    0x1c60(%rsp,%rcx,1),%r15d
    7e444469f1cd:	00 
    7e444469f1ce:	c4 c1 02         	vcvtsi2ss %r15d,%xmm15,%xmm0
