
jit-code/7e4444685000-7e44446b1000.bin:     file format binary


Disassembly of section .data:

00007e444469f440 <.data+0x1a440>:
    7e444469f440:	c4 e2 7d 33 d0       	vpmovzxwd %xmm0,%ymm2
    7e444469f445:	c5 ed 72 f2 1f       	vpslld $0x1f,%ymm2,%ymm2
    7e444469f44a:	c4 62 7d 0e d2       	vtestps %ymm2,%ymm10
    7e444469f44f:	0f 82 4b 01 00 00    	jb     0x7e444469f5a0
    7e444469f455:	c5 fc 28 8c 24 40 04 	vmovaps 0x440(%rsp),%ymm1
    7e444469f45c:	00 00 
    7e444469f45e:	c5 f4 58 94 24 c0 0d 	vaddps 0xdc0(%rsp),%ymm1,%ymm2
    7e444469f465:	00 00 
    7e444469f467:	c5 fc 28 8c 24 80 00 	vmovaps 0x80(%rsp),%ymm1
    7e444469f46e:	00 00 
    7e444469f470:	c5 ec c2 d9 01       	vcmpltps %ymm1,%ymm2,%ymm3
    7e444469f475:	c4 e3 7d 19 dc 01    	vextractf128 $0x1,%ymm3,%xmm4
    7e444469f47b:	c5 e1 6b dc          	vpackssdw %xmm4,%xmm3,%xmm3
    7e444469f47f:	c5 e1 63 db          	vpacksswb %xmm3,%xmm3,%xmm3
    7e444469f483:	c5 f4 c2 d2 0c       	vcmpneq_oqps %ymm2,%ymm1,%ymm2
    7e444469f488:	c4 e3 7d 19 d4 01    	vextractf128 $0x1,%ymm2,%xmm4
    7e444469f48e:	c5 e9 6b d4          	vpackssdw %xmm4,%xmm2,%xmm2
    7e444469f492:	c5 f9 db d2          	vpand  %xmm2,%xmm0,%xmm2
    7e444469f496:	c4 e2 69 00 26       	vpshufb (%rsi),%xmm2,%xmm4
    7e444469f49b:	c5 d9 71 f4 07       	vpsllw $0x7,%xmm4,%xmm4
    7e444469f4a0:	c4 c1 59 db 20       	vpand  (%r8),%xmm4,%xmm4
    7e444469f4a5:	c5 b1 64 e4          	vpcmpgtb %xmm4,%xmm9,%xmm4
    7e444469f4a9:	c5 7d 6f 74 24 20    	vmovdqa 0x20(%rsp),%ymm14
    7e444469f4af:	c4 c2 09 00 ec       	vpshufb %xmm12,%xmm14,%xmm5
    7e444469f4b4:	c5 d1 62 ee          	vpunpckldq %xmm6,%xmm5,%xmm5
    7e444469f4b8:	c5 d9 db e5          	vpand  %xmm5,%xmm4,%xmm4
    7e444469f4bc:	c5 d9 db db          	vpand  %xmm3,%xmm4,%xmm3
    7e444469f4c0:	c4 c1 61 db 19       	vpand  (%r9),%xmm3,%xmm3
    7e444469f4c5:	c5 d9 df a4 24 60 0c 	vpandn 0xc60(%rsp),%xmm4,%xmm4
    7e444469f4cc:	00 00 
    7e444469f4ce:	c5 e1 eb cc          	vpor   %xmm4,%xmm3,%xmm1
    7e444469f4d2:	c5 e9 ef d0          	vpxor  %xmm0,%xmm2,%xmm2
    7e444469f4d6:	c4 e2 7d 33 d2       	vpmovzxwd %xmm2,%ymm2
    7e444469f4db:	c5 ed 72 f2 1f       	vpslld $0x1f,%ymm2,%ymm2
    7e444469f4e0:	c5 ed 72 e2 1f       	vpsrad $0x1f,%ymm2,%ymm2
    7e444469f4e5:	c4 c2 7d 17 d6       	vptest %ymm14,%ymm2
    7e444469f4ea:	0f 84 b9 00 00 00    	je     0x7e444469f5a9
    7e444469f4f0:	c5 ed db 54 24 20    	vpand  0x20(%rsp),%ymm2,%ymm2
    7e444469f4f6:	c5 95 76 da          	vpcmpeqd %ymm2,%ymm13,%ymm3
    7e444469f4fa:	c5 fd 6f a4 24 20  	vmovdqa 0x120(%rsp),%ymm4
    7e444469f501:	  
