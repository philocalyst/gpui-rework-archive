
jit-code/7e4444685000-7e44446b1000.bin:     file format binary


Disassembly of section .data:

00007e44446a0255 <.data+0x1b255>:
    7e44446a0255:	c4 e3 7d 08 e1 09    	vroundps $0x9,%ymm1,%ymm4
    7e44446a025b:	c5 fc 29 b4 24 20 0a 	vmovaps %ymm6,0xa20(%rsp)
    7e44446a0262:	00 00 
    7e44446a0264:	c5 f4 5c f4          	vsubps %ymm4,%ymm1,%ymm6
    7e44446a0268:	c5 7c 29 84 24 60 07 	vmovaps %ymm8,0x760(%rsp)
    7e44446a026f:	00 00 
    7e44446a0271:	c5 7c 28 84 24 60 0e 	vmovaps 0xe60(%rsp),%ymm8
    7e44446a0278:	00 00 
    7e44446a027a:	c4 63 3d 4a c6 20    	vblendvps %ymm2,%ymm6,%ymm8,%ymm8
    7e44446a0280:	c5 fc 28 b4 24 20 0b 	vmovaps 0xb20(%rsp),%ymm6
    7e44446a0287:	00 00 
    7e44446a0289:	c4 e3 4d 4a f3 20    	vblendvps %ymm2,%ymm3,%ymm6,%ymm6
    7e44446a028f:	c5 fc 29 b4 24 20 0b 	vmovaps %ymm6,0xb20(%rsp)
    7e44446a0296:	00 00 
    7e44446a0298:	c5 fc 28 9c 24 a0 0b 	vmovaps 0xba0(%rsp),%ymm3
    7e44446a029f:	00 00 
    7e44446a02a1:	c4 e3 65 4a dc 20    	vblendvps %ymm2,%ymm4,%ymm3,%ymm3
    7e44446a02a7:	c5 fc 29 9c 24 a0 0b 	vmovaps %ymm3,0xba0(%rsp)
    7e44446a02ae:	00 00 
    7e44446a02b0:	48 b8 fc 24 f0 47 44 	movabs $0x7e4447f024fc,%rax
    7e44446a02b7:	7e 00 00 
    7e44446a02ba:	c4 e2 7d 18 10       	vbroadcastss (%rax),%ymm2
    7e44446a02bf:	c5 a4 5c dd          	vsubps %ymm5,%ymm11,%ymm3
    7e44446a02c3:	c5 e4 54 da          	vandps %ymm2,%ymm3,%ymm3
    7e44446a02c7:	c5 7c 29 9c 24 80 06 	vmovaps %ymm11,0x680(%rsp)
    7e44446a02ce:	00 00 
    7e44446a02d0:	c5 a4 54 e2          	vandps %ymm2,%ymm11,%ymm4
    7e44446a02d4:	c5 dc 5d db          	vminps %ymm3,%ymm4,%ymm3
    7e44446a02d8:	c4 c1 44 5c e7       	vsubps %ymm15,%ymm7,%ymm4
    7e44446a02dd:	c5 dc 54 e2          	vandps %ymm2,%ymm4,%ymm4
    7e44446a02e1:	c5 fc 29 bc 24 e0 05 	vmovaps %ymm7,0x5e0(%rsp)
    7e44446a02e8:	00 00 
    7e44446a02ea:	c5 c4 54 f2          	vandps %ymm2,%ymm7,%ymm6
    7e44446a02ee:	c5 cc 5d e4          	vminps %ymm4,%ymm6,%ymm4
    7e44446a02f2:	c5 fc 54 c2          	vandps %ymm2,%ymm0,%ymm0
    7e44446a02f6:	c5 f4 54 ca          	vandps %ymm2,%ymm1,%ymm1
    7e44446a02fa:	c5 7c 28 b4 24 e0 08 	vmovaps 0x8e0(%rsp),%ymm14
    7e44446a0301:	00 00 
    7e44446a0303:	c5 7c 29 ac 24 80 09 	vmovaps %ymm13,0x980(%rsp)
    7e44446a030a:	00 00 
    7e44446a030c:	c4 c1 0c 59 d5       	vmulps %ymm13,%ymm14,%ymm2
    7e44446a0311:	c5 fc 29 ac    	vmovaps %ymm5,0x600(%rsp)
    7e44446a0318:	  
