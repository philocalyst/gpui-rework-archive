
jit-code/7e4444685000-7e44446b1000.bin:     file format binary


Disassembly of section .data:

00007e44446a654e <.data+0x2154e>:
    7e44446a654e:	c5 a1 ef 84 24 00 03 	vpxor  0x300(%rsp),%xmm11,%xmm0
    7e44446a6555:	00 00 
    7e44446a6557:	c4 e2 7d 33 c0       	vpmovzxwd %xmm0,%ymm0
    7e44446a655c:	c5 fd 72 f0 1f       	vpslld $0x1f,%ymm0,%ymm0
    7e44446a6561:	c5 85 ef 74 24 20    	vpxor  0x20(%rsp),%ymm15,%ymm6
    7e44446a6567:	c4 e3 05 4a f6 00    	vblendvps %ymm0,%ymm6,%ymm15,%ymm6
    7e44446a656d:	c5 1c 54 e6          	vandps %ymm6,%ymm12,%ymm12
    7e44446a6571:	c5 7c 28 5c 24 60    	vmovaps 0x60(%rsp),%ymm11
    7e44446a6577:	c5 24 54 de          	vandps %ymm6,%ymm11,%ymm11
    7e44446a657b:	c4 c2 7d 18 02       	vbroadcastss (%r10),%ymm0
    7e44446a6580:	c5 f9 7e d8          	vmovd  %xmm3,%eax
    7e44446a6584:	c4 c1 7c 5c dc       	vsubps %ymm12,%ymm0,%ymm3
    7e44446a6589:	c5 2c 59 d3          	vmulps %ymm3,%ymm10,%ymm10
    7e44446a658d:	c4 41 2c 58 d3       	vaddps %ymm11,%ymm10,%ymm10
    7e44446a6592:	c5 7d 6f bc 24 80 01 	vmovdqa 0x180(%rsp),%ymm15
    7e44446a6599:	00 00 
    7e44446a659b:	c4 61 f9 7e f9       	vmovq  %xmm15,%rcx
    7e44446a65a0:	f6 c1 01             	test   $0x1,%cl
    7e44446a65a3:	75 0b                	jne    0x7e44446a65b0
    7e44446a65a5:	8b 94 84 40 11 00 00 	mov    0x1140(%rsp,%rax,4),%edx
    7e44446a65ac:	eb 08                	jmp    0x7e44446a65b6
    7e44446a65ae:	66 90                	xchg   %ax,%ax
    7e44446a65b0:	c4 63 79 17 d2 00    	vextractps $0x0,%xmm10,%edx
    7e44446a65b6:	89 94 84 40 11 00 00 	mov    %edx,0x1140(%rsp,%rax,4)
    7e44446a65bd:	c4 63 79 16 ca 01    	vpextrd $0x1,%xmm9,%edx
    7e44446a65c3:	48 0f ba e1 20       	bt     $0x20,%rcx
    7e44446a65c8:	72 16                	jb     0x7e44446a65e0
    7e44446a65ca:	8b b4 94 40 11 00 00 	mov    0x1140(%rsp,%rdx,4),%esi
    7e44446a65d1:	eb 13                	jmp    0x7e44446a65e6
    7e44446a65d3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    7e44446a65da:	84 00 00 00 00 00 
    7e44446a65e0:	c4 63 79 17 d6 01    	vextractps $0x1,%xmm10,%esi
    7e44446a65e6:	c4 63 f9 16 f8 01    	vpextrq $0x1,%xmm15,%rax
    7e44446a65ec:	89 b4 94 40 11 00 00 	mov    %esi,0x1140(%rsp,%rdx,4)
    7e44446a65f3:	c4 63 79 16 ca 02    	vpextrd $0x2,%xmm9,%edx
    7e44446a65f9:	a8 01                	test   $0x1,%al
    7e44446a65fb:	75 13                	jne    0x7e44446a6610
    7e44446a65fd:	8b b4 94 40 11 00 00 	mov    0x1140(%rsp,%rdx,4),%esi
    7e44446a6604:	eb 10                	jmp    0x7e44446a6616
    7e44446a6606:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7e44446a660d:	00   
