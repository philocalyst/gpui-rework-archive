
jit-code/7e4444685000-7e44446b1000.bin:     file format binary


Disassembly of section .data:

00007e44446a03e9 <.data+0x1b3e9>:
    7e44446a03e9:	c5 fd 72 e0 1f       	vpsrad $0x1f,%ymm0,%ymm0
    7e44446a03ee:	c4 e2 7d 17 44 24 20 	vptest 0x20(%rsp),%ymm0
    7e44446a03f5:	48 b8 40 22 f0 47 44 	movabs $0x7e4447f02240,%rax
    7e44446a03fc:	7e 00 00 
    7e44446a03ff:	c5 fc 28 08          	vmovaps (%rax),%ymm1
    7e44446a0403:	c5 fc 29 8c 24 40 03 	vmovaps %ymm1,0x340(%rsp)
    7e44446a040a:	00 00 
    7e44446a040c:	c5 fd 7f 94 24 a0 09 	vmovdqa %ymm2,0x9a0(%rsp)
    7e44446a0413:	00 00 
    7e44446a0415:	0f 84 46 09 00 00    	je     0x7e44446a0d61
    7e44446a041b:	c5 fd db 44 24 20    	vpand  0x20(%rsp),%ymm0,%ymm0
    7e44446a0421:	c5 fd 7f 84 24 40 02 	vmovdqa %ymm0,0x240(%rsp)
    7e44446a0428:	00 00 
    7e44446a042a:	c5 fd 76 f3          	vpcmpeqd %ymm3,%ymm0,%ymm6
    7e44446a042e:	c5 fd 6f 84 24 20 01 	vmovdqa 0x120(%rsp),%ymm0
    7e44446a0435:	00 00 
    7e44446a0437:	c5 bd 72 e0 02       	vpsrad $0x2,%ymm0,%ymm8
    7e44446a043c:	41 8b 8d 48 01 00 00 	mov    0x148(%r13),%ecx
    7e44446a0443:	49 8b 85 40 01 00 00 	mov    0x140(%r13),%rax
    7e44446a044a:	c1 f9 02             	sar    $0x2,%ecx
    7e44446a044d:	c5 f9 6e c9          	vmovd  %ecx,%xmm1
    7e44446a0451:	c4 62 7d 58 c9       	vpbroadcastd %xmm1,%ymm9
    7e44446a0456:	c4 c2 3d 3f c9       	vpmaxud %ymm9,%ymm8,%ymm1
    7e44446a045b:	c5 bd 76 c9          	vpcmpeqd %ymm1,%ymm8,%ymm1
    7e44446a045f:	c5 cd eb c9          	vpor   %ymm1,%ymm6,%ymm1
    7e44446a0463:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
    7e44446a0467:	c5 f5 ef c8          	vpxor  %ymm0,%ymm1,%ymm1
    7e44446a046b:	c4 a2 75 90 1c 80    	vpgatherdd %ymm1,(%rax,%ymm8,4),%ymm3
    7e44446a0471:	c5 bd eb 8c 24 40 01 	vpor   0x140(%rsp),%ymm8,%ymm1
    7e44446a0478:	00 00 
    7e44446a047a:	c4 c2 75 3f d1       	vpmaxud %ymm9,%ymm1,%ymm2
    7e44446a047f:	c5 f5 76 d2          	vpcmpeqd %ymm2,%ymm1,%ymm2
    7e44446a0483:	c5 cd eb d2          	vpor   %ymm2,%ymm6,%ymm2
    7e44446a0487:	c5 ed ef d0          	vpxor  %ymm0,%ymm2,%ymm2
    7e44446a048b:	c5 d8 57 e4          	vxorps %xmm4,%xmm4,%xmm4
    7e44446a048f:	c4 e2 6d 90 24 88    	vpgatherdd %ymm2,(%rax,%ymm1,4),%ymm4
    7e44446a0495:	48 b9 b8 24 f0 47 44 	movabs $0x7e4447f024b8,%rcx
    7e44446a049c:	7e 00 00 
    7e44446a049f:	c4 e2 7d 58 09       	vpbroadcastd (%rcx),%ymm1
    7e44446a04a4:	c5 bd eb d1          	vpor   %ymm1,%ymm8,%ymm2
    7e44446a04a8:	c4           	vpmaxud %ymm9,%ymm2,%ymm1
